import "@sentry/electron/preload";

import { createLooperAPI } from "@looper/electron/preload";
import { createWorktreeAPI } from "../worktree/preload";
import { electronAPI } from "@electron-toolkit/preload";
import { contextBridge, ipcRenderer } from "electron";
import { cloneDeep } from "es-toolkit/object";
import type {
  AgentType,
  BrainstormSettings,
  BrainstormSettingsPatch,
  ClarificationAgentType,
  ClaudeCodeEnvSettings,
  ClaudeCodeEnvSettingsPatch,
  GitSettings,
  GitSettingsPatch,
  LlmSettings,
  LlmSettingsPatch,
  SetupWorktreeCommands,
  SetupWorktreeCommandsPatch,
  TaskBreakdownSettings,
  TaskBreakdownSettingsPatch,
} from "../shared/global-settings";
import {
  DEFAULT_BRAINSTORM_SETTINGS,
  DEFAULT_CLAUDE_CODE_ENV_SETTINGS,
  DEFAULT_GIT_SETTINGS,
  DEFAULT_LLM_SETTINGS,
  DEFAULT_SETUP_WORKTREE_COMMANDS,
  DEFAULT_TASK_BREAKDOWN,
} from "../shared/global-settings";
import { invokeIpc, IpcInvokeError } from "../shared/ipc-client";
import type { RuntimeConfig } from "../shared/runtime-config";
import { IDE_COMMANDS, type IDEType } from "../shared/ide-types";
import type {
  UpdateCheckResult,
  UpdateDownloadedInfo,
  UpdateError,
  UpdateInfo,
  UpdateNotAvailableInfo,
  UpdateProgress,
  UpdateStatus,
} from "../shared/update-types";
import type {
  ArtifactDeletePayload,
  ArtifactIndexPayload,
  ArtifactListPayload,
  IssueStorageDeletePayload,
} from "./index.d";

let runtimeConfig: RuntimeConfig | undefined;
let runtimeConfigPromise: Promise<RuntimeConfig | undefined> | null = null;

const invoke = <T>(channel: string, ...args: unknown[]): Promise<T> => {
  return invokeIpc<T>(ipcRenderer, channel, ...args);
};

const fetchRuntimeConfig = () => {
  if (!runtimeConfigPromise) {
    runtimeConfigPromise = invoke<RuntimeConfig>("runtime-config:get")
      .then(config => {
        runtimeConfig = config;
        return runtimeConfig;
      })
      .catch(() => {
        // Error handled silently - runtime config get failed
        return runtimeConfig;
      });
  }

  return runtimeConfigPromise;
};

const initialRuntimeConfigPromise = fetchRuntimeConfig();

initialRuntimeConfigPromise.then(config => {
  // In non-isolated environments the renderer reads runtime config through
  // the bridged API below, so we avoid assigning a static global that would
  // become stale.
  // Runtime config loaded - no logging in production
  void (config && !process.contextIsolated);
});

// Custom APIs for renderer
const api = {
  selectDirectory: () =>
    invoke<string | null>("select-directory").catch(error => {
      console.warn("[PRELOAD] select-directory failed", error);
      return null;
    }),
  getGitRemoteOrigin: (directoryPath: string) =>
    invoke<string>("get-git-remote-origin", directoryPath),
  // Expose runtime config exclusively through the API to avoid stale globals
  // Use `getRuntimeConfigAsync` when you need a fresh value; this getter only returns
  // the latest cached config (if already fetched).
  getRuntimeConfig: () => runtimeConfig,
  getRuntimeConfigAsync: () => fetchRuntimeConfig(),
  onRuntimeConfig: (callback: (config: RuntimeConfig) => void) => {
    const listener = (_event: Electron.IpcRendererEvent, config: RuntimeConfig) => {
      runtimeConfig = config;
      callback(config);
    };
    ipcRenderer.on("runtime-config", listener);
    return () => ipcRenderer.removeListener("runtime-config", listener);
  },
  openExternal: async (url: string) => {
    await invoke<null>("open-external", url);
  },
  getAppVersion: () => invoke<string>("app:get-version"),
  windowControls: {
    getState: async () => {
      try {
        return await invoke<{
          isMaximized: boolean;
          isFullScreen: boolean;
          bounds: { x: number; y: number; width: number; height: number };
        }>("window:get-state");
      } catch (error) {
        console.warn("[PRELOAD] window:get-state failed", error);
        return {
          isMaximized: false,
          isFullScreen: false,
          bounds: { x: 0, y: 0, width: 800, height: 600 },
        };
      }
    },
    startDrag: async (params: { cursorX: number; cursorY: number; dragPointX: number }) => {
      try {
        return await invoke<{
          wasMaximized: boolean;
          newBounds: { x: number; y: number; width: number; height: number };
        }>("window:start-drag", params);
      } catch (error) {
        console.warn("[PRELOAD] window:start-drag failed", error);
        return { wasMaximized: false, newBounds: { x: 0, y: 0, width: 800, height: 600 } };
      }
    },
    updatePosition: async (x: number, y: number) => {
      try {
        await invoke<null>("window:update-position", x, y);
      } catch {
        // Silent fail - position updates are frequent during drag
      }
    },
    setTitleBarOverlay: async (params: {
      color?: string;
      symbolColor?: string;
      height?: number;
    }) => {
      try {
        await invoke<null>("window:set-titlebar-overlay", params);
      } catch (error) {
        console.warn("[PRELOAD] window:set-titlebar-overlay failed", error);
      }
    },
  },
  onDeepLinkToken: (callback: (token: string) => void) => {
    const listener = (_event: Electron.IpcRendererEvent, token: string) => callback(token);
    ipcRenderer.on("deep-link-token", listener);
    return () => ipcRenderer.removeListener("deep-link-token", listener);
  },
  onDeepLinkApiKey: (callback: (apiKey: string) => void) => {
    const listener = (_event: Electron.IpcRendererEvent, apiKey: string) => callback(apiKey);
    ipcRenderer.on("deep-link-api-key", listener);
    return () => ipcRenderer.removeListener("deep-link-api-key", listener);
  },
  getPendingDeepLinkApiKey: () =>
    invoke<{ apiKey: string | null }>("deep-link:get-pending-api-key")
      .then(response => response.apiKey ?? null)
      .catch(error => {
        console.warn("[PRELOAD] deep-link:get-pending-api-key failed", error);
        return null;
      }),
  ackDeepLinkApiKey: async (apiKey?: string) => {
    try {
      await invoke<null>("deep-link:ack-api-key", apiKey);
    } catch (error) {
      console.warn("[PRELOAD] deep-link:ack-api-key failed", error);
    }
  },

  // Auto-update API
  update: {
    checkForUpdates: async () => {
      try {
        const result = await invoke<UpdateCheckResult>("update:check");
        if (result.updateAvailable && !result.version) {
          console.warn("[PRELOAD] update:check returned updateAvailable without version");
          return { updateAvailable: false };
        }
        return result;
      } catch (error) {
        console.warn("[PRELOAD] update:check failed", error);
        return { updateAvailable: false };
      }
    },
    installAndRestart: async () => {
      try {
        await invoke<null>("update:install-and-restart");
      } catch (error) {
        console.warn("[PRELOAD] update:install-and-restart failed", error);
      }
    },
    getStatus: async () => {
      try {
        return await invoke<UpdateStatus>("update:get-status");
      } catch (error) {
        console.warn("[PRELOAD] update:get-status failed", error);
        return { autoDownload: true, autoInstallOnAppQuit: true };
      }
    },
    // Event listeners for update lifecycle
    onChecking: (callback: () => void) => {
      const listener = () => callback();
      ipcRenderer.on("update:checking", listener);
      return () => ipcRenderer.removeListener("update:checking", listener);
    },
    onAvailable: (callback: (info: UpdateInfo) => void) => {
      const listener = (_event: Electron.IpcRendererEvent, info: UpdateInfo) => callback(info);
      ipcRenderer.on("update:available", listener);
      return () => ipcRenderer.removeListener("update:available", listener);
    },
    onNotAvailable: (callback: (info: UpdateNotAvailableInfo) => void) => {
      const listener = (_event: Electron.IpcRendererEvent, info: UpdateNotAvailableInfo) =>
        callback(info);
      ipcRenderer.on("update:not-available", listener);
      return () => ipcRenderer.removeListener("update:not-available", listener);
    },
    onProgress: (callback: (progress: UpdateProgress) => void) => {
      const listener = (_event: Electron.IpcRendererEvent, progress: UpdateProgress) =>
        callback(progress);
      ipcRenderer.on("update:download-progress", listener);
      return () => ipcRenderer.removeListener("update:download-progress", listener);
    },
    onDownloaded: (callback: (info: UpdateDownloadedInfo) => void) => {
      const listener = (_event: Electron.IpcRendererEvent, info: UpdateDownloadedInfo) =>
        callback(info);
      ipcRenderer.on("update:downloaded", listener);
      return () => ipcRenderer.removeListener("update:downloaded", listener);
    },
    onError: (callback: (error: UpdateError) => void) => {
      const listener = (_event: Electron.IpcRendererEvent, error: UpdateError) => callback(error);
      ipcRenderer.on("update:error", listener);
      return () => ipcRenderer.removeListener("update:error", listener);
    },
  },

  settings: {
    getLlmSettings: (agentType: AgentType) =>
      invoke<{ settings: LlmSettings }>("global-settings:llm:get", agentType).catch(error => {
        console.warn("[PRELOAD] global-settings:llm:get failed", { agentType, error });
        return { settings: cloneDeep(DEFAULT_LLM_SETTINGS[agentType]) };
      }),
    getAllLlmSettings: () =>
      invoke<{ settings: Record<AgentType, LlmSettings> }>("global-settings:llm:get-all").catch(
        error => {
          console.warn("[PRELOAD] global-settings:llm:get-all failed", error);
          return { settings: cloneDeep(DEFAULT_LLM_SETTINGS) };
        }
      ),
    updateLlmSettings: (agentType: AgentType, patch: LlmSettingsPatch) =>
      invoke<{ settings: LlmSettings }>("global-settings:llm:update", { agentType, patch }).catch(
        error => {
          const message = error instanceof IpcInvokeError ? error.message : String(error);
          console.warn("[PRELOAD] global-settings:llm:update failed", { agentType, error });
          return { settings: cloneDeep(DEFAULT_LLM_SETTINGS[agentType]), error: message };
        }
      ) as Promise<{ settings: LlmSettings; error?: string }>,
    resetLlmSettings: (agentType: AgentType) =>
      invoke<{ settings: LlmSettings }>("global-settings:llm:reset", agentType).catch(error => {
        const message = error instanceof IpcInvokeError ? error.message : String(error);
        console.warn("[PRELOAD] global-settings:llm:reset failed", { agentType, error });
        return { settings: cloneDeep(DEFAULT_LLM_SETTINGS[agentType]), error: message };
      }) as Promise<{ settings: LlmSettings; error?: string }>,
    getBrainstormSettings: (agentType: ClarificationAgentType) =>
      invoke<{ settings: BrainstormSettings }>("global-settings:brainstorm:get", agentType).catch(
        error => {
          console.warn("[PRELOAD] global-settings:brainstorm:get failed", { agentType, error });
          return { settings: cloneDeep(DEFAULT_BRAINSTORM_SETTINGS[agentType]) };
        }
      ),
    updateBrainstormSettings: (agentType: ClarificationAgentType, patch: BrainstormSettingsPatch) =>
      invoke<{ settings: BrainstormSettings }>("global-settings:brainstorm:update", {
        agentType,
        patch,
      }).catch(error => {
        const message = error instanceof IpcInvokeError ? error.message : String(error);
        console.warn("[PRELOAD] global-settings:brainstorm:update failed", { agentType, error });
        return { settings: cloneDeep(DEFAULT_BRAINSTORM_SETTINGS[agentType]), error: message };
      }) as Promise<{ settings: BrainstormSettings; error?: string }>,
    getTaskBreakdownSettings: () =>
      invoke<{ settings: TaskBreakdownSettings }>("global-settings:task-breakdown:get").catch(
        error => {
          console.warn("[PRELOAD] global-settings:task-breakdown:get failed", error);
          return { settings: cloneDeep(DEFAULT_TASK_BREAKDOWN) };
        }
      ),
    updateTaskBreakdownSettings: (patch: TaskBreakdownSettingsPatch) =>
      invoke<{ settings: TaskBreakdownSettings }>(
        "global-settings:task-breakdown:update",
        patch
      ).catch(error => {
        const message = error instanceof IpcInvokeError ? error.message : String(error);
        console.warn("[PRELOAD] global-settings:task-breakdown:update failed", error);
        return { settings: cloneDeep(DEFAULT_TASK_BREAKDOWN), error: message };
      }) as Promise<{ settings: TaskBreakdownSettings; error?: string }>,
    getGitSettings: () =>
      invoke<{ settings: GitSettings }>("global-settings:git:get").catch(error => {
        console.warn("[PRELOAD] global-settings:git:get failed", error);
        return { settings: cloneDeep(DEFAULT_GIT_SETTINGS) };
      }),
    updateGitSettings: (patch: GitSettingsPatch) =>
      invoke<{ settings: GitSettings; error?: string }>("global-settings:git:update", patch).catch(
        error => {
          const message = error instanceof IpcInvokeError ? error.message : String(error);
          console.warn("[PRELOAD] global-settings:git:update failed", error);
          return { settings: cloneDeep(DEFAULT_GIT_SETTINGS), error: message };
        }
      ),
    getSetupWorktreeCommands: () =>
      invoke<{ settings: SetupWorktreeCommands }>("global-settings:setup-worktree:get").catch(
        error => {
          console.warn("[PRELOAD] global-settings:setup-worktree:get failed", error);
          return { settings: cloneDeep(DEFAULT_SETUP_WORKTREE_COMMANDS) };
        }
      ),
    updateSetupWorktreeCommands: (patch: SetupWorktreeCommandsPatch) =>
      invoke<{ settings: SetupWorktreeCommands; error?: string }>(
        "global-settings:setup-worktree:update",
        patch
      ).catch(error => {
        const message = error instanceof IpcInvokeError ? error.message : String(error);
        console.warn("[PRELOAD] global-settings:setup-worktree:update failed", error);
        return { settings: cloneDeep(DEFAULT_SETUP_WORKTREE_COMMANDS), error: message };
      }),
    getClaudeCodeEnvSettings: () =>
      invoke<{ settings: ClaudeCodeEnvSettings }>("global-settings:claude-code-env:get").catch(
        error => {
          console.warn("[PRELOAD] global-settings:claude-code-env:get failed", error);
          return { settings: cloneDeep(DEFAULT_CLAUDE_CODE_ENV_SETTINGS) };
        }
      ),
    updateClaudeCodeEnvSettings: (patch: ClaudeCodeEnvSettingsPatch) =>
      invoke<{ settings: ClaudeCodeEnvSettings; error?: string }>(
        "global-settings:claude-code-env:update",
        patch
      ).catch(error => {
        const message = error instanceof IpcInvokeError ? error.message : String(error);
        console.warn("[PRELOAD] global-settings:claude-code-env:update failed", error);
        return { settings: cloneDeep(DEFAULT_CLAUDE_CODE_ENV_SETTINGS), error: message };
      }),
  },

  worktree: createWorktreeAPI(ipcRenderer),

  artifacts: {
    index: (payload: ArtifactIndexPayload) => invoke("artifacts:index", payload),
    list: (payload: ArtifactListPayload) => invoke("artifacts:list", payload),
    getContext: (payload: ArtifactListPayload) => invoke("artifacts:get-context", payload),
    delete: (payload: ArtifactDeletePayload) => invoke("artifacts:delete", payload),
  },

  issues: {
    deleteStorage: (payload: IssueStorageDeletePayload) => invoke("issue-storage:delete", payload),
  },

  claudeCode: {
    detect: async () => {
      try {
        return await invoke<{ isInstalled: boolean; executablePath: string | undefined }>(
          "claude-code:detect"
        );
      } catch (error) {
        console.warn("[PRELOAD] claude-code:detect failed", error);
        return { isInstalled: false, executablePath: undefined };
      }
    },
    refreshDetection: async () => {
      try {
        return await invoke<{ isInstalled: boolean; executablePath: string | undefined }>(
          "claude-code:refresh-detection"
        );
      } catch (error) {
        console.warn("[PRELOAD] claude-code:refresh-detection failed", error);
        return { isInstalled: false, executablePath: undefined };
      }
    },
  },

  ide: {
    open: async (ideType: IDEType, path: string) => {
      try {
        await invoke<null>("ide:open", ideType, path);
      } catch (error) {
        console.warn("[PRELOAD] ide:open failed", { ideType, path, error });
        throw error;
      }
    },
    detect: async () => {
      try {
        return await invoke<Record<IDEType, boolean>>("ide:detect");
      } catch (error) {
        console.warn("[PRELOAD] ide:detect failed", { error });
        // Generate fallback from IDE_COMMANDS to avoid duplication
        return Object.fromEntries(Object.keys(IDE_COMMANDS).map(key => [key, false])) as Record<
          IDEType,
          boolean
        >;
      }
    },
  },

  clipboard: {
    writeText: async (text: string) => {
      try {
        await invoke<null>("clipboard:writeText", text);
      } catch (error) {
        console.warn("[PRELOAD] clipboard:writeText failed", { error });
        throw error;
      }
    },
  },

  finder: {
    reveal: async (path: string) => {
      try {
        await invoke<null>("finder:reveal", path);
      } catch (error) {
        console.warn("[PRELOAD] finder:reveal failed", { path, error });
        throw error;
      }
    },
  },
};

// Create Looper API for secure IPC communication
const looperAPI = createLooperAPI(ipcRenderer);

// Use `contextBridge` APIs to expose Electron APIs to
// renderer only if context isolation is enabled, otherwise
// just add to the DOM global.
if (process.contextIsolated) {
  try {
    contextBridge.exposeInMainWorld("electron", electronAPI);
    contextBridge.exposeInMainWorld("api", api);
    contextBridge.exposeInMainWorld("looper", looperAPI);
  } catch (error) {
    console.error(error);
  }
} else {
  // @ts-ignore (define in dts)
  window.electron = electronAPI;
  // @ts-ignore (define in dts)
  window.api = api;
  // @ts-ignore (define in dts)
  window.looper = looperAPI;
}
