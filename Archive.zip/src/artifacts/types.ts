import { artifactTypeSchema } from "@compozy/types";
import type { z } from "zod";

export { artifactTypeSchema };
export type ArtifactType = z.infer<typeof artifactTypeSchema>;

export type ArtifactFileName<T extends ArtifactType> = T extends "task"
  ? `${string}-${string}.md`
  : T extends "issue_context"
    ? "issue-context.md"
    : `${T}.md`;

export type ArtifactIndexInput<T extends ArtifactType = ArtifactType> = {
  issueId: string;
  type: T;
  content: string;
  title?: string;
  taskId?: T extends "task" ? string : never;
  taskSlug?: T extends "task" ? string : never;
  updatedAt?: number;
  syncedAt?: number | null;
};

export type ArtifactRecord = {
  id: string;
  type: ArtifactType;
  filePath: string;
  updatedAt: number;
  syncedAt: number | null;
  checksum: string;
};

export type ArtifactListItem = {
  id: string;
  type: ArtifactType;
  filePath: string;
};

/**
 * Warning information for artifact sync failures.
 * Issue 37: Provides visibility into sync failures that would otherwise be silent.
 */
export type ArtifactSyncWarning = {
  type: ArtifactType | "sync-failure";
  error: string;
};

export type ArtifactContextPaths = {
  artifactsDir: string;
  tasksDir: string;
  prdPath: string | null;
  techspecPath: string | null;
  issueContextPath: string | null;
  /**
   * Issue 37: Sync warnings for artifacts that failed to sync from disk.
   * Empty array when sync succeeds, contains warnings for failed syncs.
   */
  syncWarnings?: ArtifactSyncWarning[];
};
