import * as path from "node:path";
import { invariant } from "es-toolkit/util";
import { kebabCase, trim } from "es-toolkit/string";
import { ensureDir } from "../shared/ensure-dir";
import { getIssueDir, isValidIssueId } from "../shared/issue-path";
import type { ArtifactFileName, ArtifactType } from "./types";

const ARTIFACTS_DIR_NAME = "artifacts";
const TASKS_DIR_NAME = "tasks";
const DEFAULT_TASK_SLUG = "task";
const TASK_ID_MAX_LENGTH = 64;
const TASK_ID_PATTERN = /^[a-zA-Z0-9._-]+$/;

function normalizeSlug(value: string | undefined): string {
  const trimmed = value ? trim(value) : "";
  if (!trimmed) {
    return DEFAULT_TASK_SLUG;
  }
  const slug = kebabCase(trimmed);
  return slug || DEFAULT_TASK_SLUG;
}

export function isValidTaskId(taskId: string): boolean {
  return !getTaskIdValidationResult(taskId).error;
}

function normalizeTaskId(taskId: string): string {
  const normalized = trim(taskId);
  invariant(isValidTaskId(normalized), `Invalid task ID: ${taskId}`);
  return normalized;
}

function getTaskIdValidationResult(taskId: string): { normalized: string; error?: string } {
  const normalized = trim(taskId);
  if (!normalized) {
    return { normalized, error: "Task ID is required to resolve task artifact paths" };
  }
  if (normalized.length > TASK_ID_MAX_LENGTH) {
    return {
      normalized,
      error: `Task ID must be at most ${TASK_ID_MAX_LENGTH} characters`,
    };
  }
  if (!TASK_ID_PATTERN.test(normalized)) {
    return { normalized, error: "Task ID contains invalid characters" };
  }
  return { normalized };
}

/**
 * Gets the artifacts directory for a given issue.
 * Defense in depth: validates issueId format before path construction to prevent path traversal.
 * The underlying getIssueDir also validates, but boundary validation adds an extra safety layer.
 */
export function getArtifactsDir(issueId: string): string {
  // Defense in depth: validate issueId format to prevent path traversal
  invariant(isValidIssueId(issueId), `Invalid issue ID format: ${issueId}`);
  const issueDir = getIssueDir(issueId);
  return path.join(issueDir, ARTIFACTS_DIR_NAME);
}

export function ensureArtifactsDir(issueId: string): string {
  const artifactsDir = getArtifactsDir(issueId);
  ensureDir(artifactsDir);
  return artifactsDir;
}

export function getTasksDir(issueId: string): string {
  const artifactsDir = getArtifactsDir(issueId);
  return path.join(artifactsDir, TASKS_DIR_NAME);
}

export function ensureTasksDir(issueId: string): string {
  const tasksDir = getTasksDir(issueId);
  ensureDir(tasksDir);
  return tasksDir;
}

export function getArtifactsDbPath(issueId: string): string {
  return path.join(getArtifactsDir(issueId), "artifacts.db");
}

function buildTaskFileName(title: string | undefined, taskId: string, taskSlug?: string) {
  const slugBase = normalizeSlug(taskSlug ?? title);
  const fileName = `${slugBase}-${taskId}.md` as ArtifactFileName<"task">;
  return fileName;
}

export function getArtifactFilePath(input: {
  issueId: string;
  type: ArtifactType;
  title?: string;
  taskId?: string;
  taskSlug?: string;
}): string {
  const artifactsDir = getArtifactsDir(input.issueId);

  switch (input.type) {
    case "prd":
      return path.join(artifactsDir, "prd.md");
    case "techspec":
      return path.join(artifactsDir, "techspec.md");
    case "issue_context":
      return path.join(artifactsDir, "issue-context.md");
    case "task": {
      invariant(input.taskId, "taskId is required for task artifacts");
      const tasksDir = getTasksDir(input.issueId);
      const normalizedTaskId = normalizeTaskId(input.taskId);
      return path.join(tasksDir, buildTaskFileName(input.title, normalizedTaskId, input.taskSlug));
    }
    default: {
      const exhaustiveCheck: never = input.type;
      return exhaustiveCheck;
    }
  }
}
