import * as fs from "node:fs/promises";
import * as path from "node:path";
import crypto from "node:crypto";
import { head, tail, uniq } from "es-toolkit/array";
import { invariant } from "es-toolkit/util";
import { trim } from "es-toolkit/string";
import * as Effect from "effect/Effect";
import { getArtifactFilePath, getArtifactsDbPath, getArtifactsDir, getTasksDir } from "./paths";
import type {
  ArtifactContextPaths,
  ArtifactIndexInput,
  ArtifactListItem,
  ArtifactRecord,
  ArtifactType,
} from "./types";
import { createArtifactRepository, type ArtifactRepositoryWithClose } from "./sqlite/repository";

export type ArtifactIndexPayload = Omit<ArtifactIndexInput, "content"> & {
  content?: string;
};

const TASK_ID_PREFIX = "task:";

function getArtifactId(type: ArtifactType, taskId?: string): string {
  if (type === "task") {
    invariant(taskId, "taskId is required for task artifacts");
    return `${TASK_ID_PREFIX}${taskId}`;
  }
  return type;
}

function computeChecksum(content: string): string {
  return crypto.createHash("sha256").update(content).digest("hex");
}

const EMPTY_TASK_CHECKSUM = computeChecksum("");

async function fileExists(filePath: string): Promise<boolean> {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

async function ensureFileDir(filePath: string): Promise<void> {
  const dir = path.dirname(filePath);
  await fs.mkdir(dir, { recursive: true, mode: 0o700 });
}

async function cleanupTaskPlaceholder(
  payload: ArtifactIndexPayload,
  repository: ArtifactRepositoryWithClose
): Promise<void> {
  if (payload.type !== "task") return;
  if (!payload.taskId || !payload.taskSlug) return;
  if (payload.taskId === payload.taskSlug) return;

  const placeholderId = getArtifactId("task", payload.taskSlug);
  const placeholder = await Effect.runPromise(repository.getArtifactById(placeholderId));
  if (!placeholder) return;

  if (placeholder.checksum !== EMPTY_TASK_CHECKSUM) {
    return;
  }

  const placeholderPath =
    placeholder.filePath ??
    getArtifactFilePath({
      issueId: payload.issueId,
      type: "task",
      title: payload.title,
      taskId: payload.taskSlug,
      taskSlug: payload.taskSlug,
    });

  try {
    await Effect.runPromise(repository.deleteArtifact(placeholderId));
  } catch (error) {
    console.warn("Failed to delete placeholder task artifact record", {
      taskId: payload.taskId,
      placeholderId,
      error: error instanceof Error ? error.message : String(error),
    });
    return;
  }

  if (placeholderPath && (await fileExists(placeholderPath))) {
    try {
      await fs.unlink(placeholderPath);
    } catch (error) {
      console.warn("Failed to delete placeholder task artifact file", {
        taskId: payload.taskId,
        placeholderPath,
        error: error instanceof Error ? error.message : String(error),
      });
    }
  }
}

async function resolveContent(
  payload: ArtifactIndexPayload,
  existingPath?: string,
  fallbackPath?: string
): Promise<string | undefined> {
  if (payload.content !== undefined) {
    return payload.content;
  }

  if (existingPath && (await fileExists(existingPath))) {
    return await fs.readFile(existingPath, "utf-8");
  }

  if (fallbackPath && (await fileExists(fallbackPath))) {
    return await fs.readFile(fallbackPath, "utf-8");
  }

  return undefined;
}

/**
 * Wraps fs.writeFile with specific error handling for filesystem issues.
 * Throws descriptive errors for common failure conditions:
 * - ENOSPC: No space left on device
 * - EACCES: Permission denied
 */
async function safeWriteFile(filePath: string, content: string): Promise<void> {
  try {
    await fs.writeFile(filePath, content, "utf-8");
  } catch (error) {
    const nodeError = error as NodeJS.ErrnoException;
    if (nodeError.code === "ENOSPC") {
      throw new Error(`Insufficient disk space to write artifact: ${filePath}`);
    }
    if (nodeError.code === "EACCES") {
      throw new Error(`Permission denied writing artifact: ${filePath}`);
    }
    throw error;
  }
}

/**
 * Re-export for batch operations that manage their own repository lifecycle.
 */
export type { ArtifactRepositoryWithClose } from "./sqlite/repository";

/**
 * Indexes an artifact to the local SQLite database and writes/updates the markdown file.
 * Creates the artifact file and directory if they do not exist.
 * Updates the FTS search index for content discovery.
 *
 * @param payload - The artifact data to index including issueId, type, content, and timestamps
 * @param repository - Optional repository instance for batch operations. If not provided, a new connection is created and closed.
 * @returns The indexed artifact record with id, type, filePath, timestamps, and checksum
 * @throws Error if content is empty for non-task artifacts
 */
export async function indexArtifact(
  payload: ArtifactIndexPayload,
  repository?: ArtifactRepositoryWithClose
): Promise<ArtifactRecord> {
  const dbPath = getArtifactsDbPath(payload.issueId);
  const ownedRepo = repository ?? (await createArtifactRepository({ dbPath }));
  const shouldClose = !repository;

  try {
    const artifactId = getArtifactId(payload.type, payload.taskId);
    const existing = await Effect.runPromise(ownedRepo.getArtifactById(artifactId));
    const filePath = getArtifactFilePath({
      issueId: payload.issueId,
      type: payload.type,
      title: payload.title,
      taskId: payload.taskId,
      taskSlug: payload.taskSlug,
    });

    const resolvedContent = await resolveContent(payload, existing?.filePath, filePath);
    // Use empty string for task artifacts when content is undefined (tasks may be placeholders
    // awaiting enrichment or resolved later), otherwise require content for PRD/techspec/issue_context artifacts
    const content = resolvedContent ?? "";

    if (!trim(content) && payload.type !== "task") {
      throw new Error(`Artifact content is empty for type: ${payload.type}`);
    }

    await ensureFileDir(filePath);

    // Track if we need to clean up old file after successful operations
    const oldFilePath =
      existing?.filePath && existing.filePath !== filePath && (await fileExists(existing.filePath))
        ? existing.filePath
        : undefined;

    // Write file first (staging) - use safeWriteFile for disk space error handling
    await safeWriteFile(filePath, content);

    const updatedAt = payload.updatedAt ?? Date.now();
    // Default to null for unsynced artifacts - only set to timestamp after backend confirmation
    const syncedAt = payload.syncedAt ?? null;
    const checksum = computeChecksum(content);

    const record: ArtifactRecord = {
      id: artifactId,
      type: payload.type,
      filePath,
      updatedAt,
      syncedAt: syncedAt ?? null,
      checksum,
    };

    try {
      // Attempt DB upsert
      await Effect.runPromise(ownedRepo.upsertArtifact(record, content));
    } catch (dbError) {
      // Rollback: delete file if DB operation fails (only if we created a new file)
      if (!existing) {
        await fs.unlink(filePath).catch(() => {});
      }
      throw dbError;
    }

    // Only delete old file after successful DB upsert to prevent orphaned files
    // This prevents race conditions where rename succeeds but DB fails
    if (oldFilePath) {
      try {
        await fs.unlink(oldFilePath);
      } catch {
        // Best effort: log warning but don't fail the operation since DB is consistent
        console.warn(`Failed to delete old artifact file: ${oldFilePath}`);
      }
    }

    await cleanupTaskPlaceholder(payload, ownedRepo);

    return record;
  } finally {
    if (shouldClose) {
      ownedRepo.close();
    }
  }
}

/**
 * Indexes multiple artifacts in a batch using a single database connection.
 * This is more efficient than calling indexArtifact multiple times for batch operations.
 *
 * @param artifacts - Array of artifact payloads to index
 * @returns Array of indexed artifact records
 */
export async function indexArtifactBatch(
  artifacts: ArtifactIndexPayload[]
): Promise<ArtifactRecord[]> {
  if (artifacts.length === 0) {
    return [];
  }
  const firstArtifact = artifacts[0];
  if (!firstArtifact) {
    return [];
  }
  const issueIds = artifacts.map(artifact => trim(artifact.issueId));
  const uniqueIssueIds = uniq(issueIds);
  const expectedIssueId = head(uniqueIssueIds) ?? "";
  if (!expectedIssueId) {
    throw new Error("issueId is required for artifact batch indexing");
  }
  const mismatchedIssueId = head(tail(uniqueIssueIds));
  if (mismatchedIssueId !== undefined) {
    throw new Error(
      `All artifacts in batch must have the same issueId. Expected: ${expectedIssueId}, found: ${mismatchedIssueId}`
    );
  }
  const dbPath = getArtifactsDbPath(firstArtifact.issueId);
  const repository = await createArtifactRepository({ dbPath });
  try {
    const results: ArtifactRecord[] = [];
    for (const artifact of artifacts) {
      const record = await indexArtifact(artifact, repository);
      results.push(record);
    }
    return results;
  } finally {
    repository.close();
  }
}

/**
 * Syncs an artifact from disk to the database.
 * Reads the file from disk, computes checksum, and updates the DB if changed.
 * Removes the DB record if the file no longer exists.
 *
 * @param payload - Artifact identification including issueId, type, and optional taskId
 * @returns The synced artifact record, or undefined if file does not exist
 */
export async function syncArtifactFromDisk(payload: {
  issueId: string;
  type: ArtifactType;
  title?: string;
  taskId?: string;
  taskSlug?: string;
}): Promise<ArtifactRecord | undefined> {
  const dbPath = getArtifactsDbPath(payload.issueId);
  const repository = await createArtifactRepository({ dbPath });

  try {
    const artifactId = getArtifactId(payload.type, payload.taskId);
    const existing = await Effect.runPromise(repository.getArtifactById(artifactId));
    const filePath = getArtifactFilePath({
      issueId: payload.issueId,
      type: payload.type,
      title: payload.title,
      taskId: payload.taskId,
      taskSlug: payload.taskSlug,
    });

    let content: string;
    try {
      content = await fs.readFile(filePath, "utf-8");
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") {
        if (existing) {
          await Effect.runPromise(repository.deleteArtifact(artifactId));
        }
        return undefined;
      }
      throw error;
    }

    if (!trim(content) && payload.type !== "task") {
      return existing ?? undefined;
    }

    const checksum = computeChecksum(content);
    const shouldUpdate = !existing || existing.checksum !== checksum;

    if (!shouldUpdate) {
      return existing;
    }

    const stats = await fs.stat(filePath);
    const updatedAt = Number.isFinite(stats.mtimeMs) ? stats.mtimeMs : Date.now();

    const record: ArtifactRecord = {
      id: artifactId,
      type: payload.type,
      filePath,
      updatedAt,
      syncedAt: existing?.syncedAt ?? null,
      checksum,
    };

    await Effect.runPromise(repository.upsertArtifact(record, content));

    return record;
  } finally {
    repository.close();
  }
}

/**
 * Deletes an artifact from both the filesystem and database.
 *
 * @param payload - Artifact identification including issueId, type, and optional taskId
 */
export async function deleteArtifact(payload: {
  issueId: string;
  type: ArtifactType;
  taskId?: string;
}): Promise<void> {
  const dbPath = getArtifactsDbPath(payload.issueId);
  const repository = await createArtifactRepository({ dbPath });

  try {
    const artifactId = getArtifactId(payload.type, payload.taskId);
    const existing = await Effect.runPromise(repository.getArtifactById(artifactId));

    // Delete from DB first (source of truth) to ensure consistency
    await Effect.runPromise(repository.deleteArtifact(artifactId));

    // Then delete file (best effort) - if this fails, DB record is already gone
    // so the app won't try to use the orphaned file
    if (existing?.filePath && (await fileExists(existing.filePath))) {
      try {
        await fs.unlink(existing.filePath);
      } catch (error) {
        // Log orphaned file warning but app state is consistent since DB record is deleted
        console.warn(`Failed to delete artifact file (orphaned): ${existing.filePath}`, error);
      }
    }
  } finally {
    repository.close();
  }
}

/**
 * Lists all artifacts for an issue.
 *
 * @param issueId - The issue ID to list artifacts for
 * @returns Array of all artifacts with file paths
 */
export async function listArtifacts(issueId: string): Promise<ReadonlyArray<ArtifactListItem>> {
  const dbPath = getArtifactsDbPath(issueId);
  const repository = await createArtifactRepository({ dbPath });
  try {
    return await Effect.runPromise(repository.listArtifacts());
  } finally {
    repository.close();
  }
}

/**
 * Gets file paths for all artifact types for an issue.
 * Checks file existence but does NOT sync from disk to the database.
 * Call syncArtifactFromDisk separately if DB sync is needed.
 *
 * @param issueId - The issue ID
 * @returns Object containing artifact directory paths and optional file paths
 */
export async function getArtifactContextPaths(issueId: string): Promise<ArtifactContextPaths> {
  const artifactsDir = getArtifactsDir(issueId);
  const tasksDir = getTasksDir(issueId);

  const prdPath = path.join(artifactsDir, "prd.md");
  const techspecPath = path.join(artifactsDir, "techspec.md");
  const issueContextPath = path.join(artifactsDir, "issue-context.md");

  const [prdExists, techspecExists, issueContextExists] = await Promise.all([
    fileExists(prdPath),
    fileExists(techspecPath),
    fileExists(issueContextPath),
  ]);

  return {
    artifactsDir,
    tasksDir,
    prdPath: prdExists ? prdPath : null,
    techspecPath: techspecExists ? techspecPath : null,
    issueContextPath: issueContextExists ? issueContextPath : null,
  };
}
