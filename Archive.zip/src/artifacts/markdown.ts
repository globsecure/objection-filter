import { compact } from "es-toolkit/array";
import { trim } from "es-toolkit/string";

export function buildTaskArtifactMarkdown(input: {
  title: string;
  content?: string | null;
}): string {
  const title = trim(input.title ?? "");
  const content = trim(input.content ?? "");

  if (!title && !content) {
    return "";
  }

  if (!title) {
    return `${content}\n`;
  }

  if (!content) {
    return `# ${title}\n`;
  }

  return `# ${title}\n\n${content}\n`;
}

export function buildIssueContextMarkdown(input: {
  title?: string | null;
  summary?: string | null;
  mainRepositoryPath?: string | null;
  additionalRepositoryPaths?: Array<string | null | undefined>;
}): string {
  const title = trim(input.title ?? "");
  const summary = trim(input.summary ?? "");
  const mainRepositoryPath = trim(input.mainRepositoryPath ?? "");
  const additionalRepositories = compact(
    (input.additionalRepositoryPaths ?? []).map(path => trim(path ?? ""))
  );

  const lines: string[] = ["# Issue Context"];

  const issueLines = compact([
    title ? `- Title: ${title}` : "",
    summary ? `- Summary: ${summary}` : "",
  ]);

  if (issueLines.length > 0) {
    lines.push("", "## Issue", ...issueLines);
  }

  const repoLines = compact([
    mainRepositoryPath ? `- Main Repository: ${mainRepositoryPath}` : "",
    additionalRepositories.length > 0
      ? `- Additional Repositories: ${additionalRepositories.join(", ")}`
      : "",
  ]);

  if (repoLines.length > 0) {
    lines.push("", "## Repository Scope", ...repoLines);
  }

  return `${trim(lines.join("\n"))}\n`;
}
