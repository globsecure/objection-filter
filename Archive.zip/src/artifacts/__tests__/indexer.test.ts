import "@shared/test-utils/cleanup";
import { afterEach, describe, expect, it } from "vitest";
import * as fs from "node:fs/promises";

import { cleanupTestCompozyHomeDir } from "@shared/repository-key";
import { ensureArtifactsDir, getArtifactFilePath } from "../paths";
import {
  deleteArtifact,
  getArtifactContextPaths,
  indexArtifact,
  listArtifacts,
  syncArtifactFromDisk,
} from "../indexer";

const issueId = "123e4567-e89b-12d3-a456-426614174000";

afterEach(() => {
  cleanupTestCompozyHomeDir();
});

describe("artifact indexer", () => {
  it("indexes and lists document artifacts", async () => {
    const record = await indexArtifact({
      issueId,
      type: "prd",
      title: "PRD",
      content: "Hello world",
    });

    expect(record.id).toBe("prd");
    const fileContent = await fs.readFile(record.filePath, "utf-8");
    expect(fileContent).toBe("Hello world");

    const results = await listArtifacts(issueId);
    expect(results.length).toBe(1);
    expect(results[0]?.id).toBe("prd");
  });

  it("rejects empty content for non-task artifacts", async () => {
    await expect(
      indexArtifact({
        issueId,
        type: "techspec",
        title: "Spec",
        content: "   ",
      })
    ).rejects.toThrow("Artifact content is empty");
  });

  it("syncs artifacts from disk and deletes missing entries", async () => {
    const initial = await indexArtifact({
      issueId,
      type: "techspec",
      title: "Spec",
      content: "Initial content",
    });

    const filePath = getArtifactFilePath({ issueId, type: "techspec" });
    ensureArtifactsDir(issueId);
    await fs.writeFile(filePath, "Updated content", "utf-8");

    const synced = await syncArtifactFromDisk({ issueId, type: "techspec" });
    expect(synced).toBeDefined();
    expect(synced?.checksum).not.toBe(initial.checksum);

    await fs.unlink(filePath);
    const removed = await syncArtifactFromDisk({ issueId, type: "techspec" });
    expect(removed).toBeUndefined();
  });

  it("returns context paths for existing artifacts", async () => {
    await indexArtifact({
      issueId,
      type: "issue_context",
      title: "Context",
      content: "Some context",
    });

    const context = await getArtifactContextPaths(issueId);
    expect(context.artifactsDir).toContain("artifacts");
    expect(context.tasksDir).toContain("tasks");
    expect(context.issueContextPath).toMatch(/\/artifacts\/issue-context\.md$/);
  });

  it("deletes task artifacts from disk and database", async () => {
    const record = await indexArtifact({
      issueId,
      type: "task",
      title: "Task",
      taskId: "task-1",
      content: "",
    });

    await deleteArtifact({ issueId, type: "task", taskId: "task-1" });

    await expect(fs.access(record.filePath)).rejects.toThrow();
  });

  it("indexes from existing file content when payload content is undefined", async () => {
    await indexArtifact({
      issueId,
      type: "prd",
      title: "PRD",
      content: "Initial content",
    });

    const filePath = getArtifactFilePath({ issueId, type: "prd" });
    ensureArtifactsDir(issueId);
    await fs.writeFile(filePath, "Content from disk", "utf-8");

    const record = await indexArtifact({
      issueId,
      type: "prd",
      title: "PRD",
    });

    const fileContent = await fs.readFile(record.filePath, "utf-8");
    expect(fileContent).toBe("Content from disk");
  });

  it("uses fallback file content when no record exists", async () => {
    const filePath = getArtifactFilePath({ issueId, type: "techspec" });
    ensureArtifactsDir(issueId);
    await fs.writeFile(filePath, "Fallback content", "utf-8");

    const record = await indexArtifact({
      issueId,
      type: "techspec",
      title: "Spec",
    });

    const fileContent = await fs.readFile(record.filePath, "utf-8");
    expect(fileContent).toBe("Fallback content");
  });

  it("renames task artifacts when the title changes", async () => {
    const initial = await indexArtifact({
      issueId,
      type: "task",
      title: "First Task",
      taskId: "task-2",
      content: "Task content",
    });

    const updated = await indexArtifact({
      issueId,
      type: "task",
      title: "Renamed Task",
      taskId: "task-2",
      content: "Task content",
    });

    await expect(fs.access(initial.filePath)).rejects.toThrow();
    await expect(fs.access(updated.filePath)).resolves.toBeUndefined();
  });

  it("removes empty placeholder task artifacts when indexing real task IDs", async () => {
    const placeholder = await indexArtifact({
      issueId,
      type: "task",
      title: "Task",
      taskId: "task-slug",
      taskSlug: "task-slug",
      content: "",
    });

    const record = await indexArtifact({
      issueId,
      type: "task",
      title: "Task",
      taskId: "11111111-1111-4111-8111-111111111111",
      taskSlug: "task-slug",
      content: "Task content",
    });

    await expect(fs.access(placeholder.filePath)).rejects.toThrow();

    const results = await listArtifacts(issueId);
    const ids = results.map(item => item.id);
    expect(ids).toContain(record.id);
    expect(ids).not.toContain("task:task-slug");
  });

  it("returns existing record when sync content is empty", async () => {
    const initial = await indexArtifact({
      issueId,
      type: "techspec",
      title: "Spec",
      content: "Initial content",
    });

    const filePath = getArtifactFilePath({ issueId, type: "techspec" });
    ensureArtifactsDir(issueId);
    await fs.writeFile(filePath, "   ", "utf-8");

    const synced = await syncArtifactFromDisk({ issueId, type: "techspec" });
    expect(synced?.checksum).toBe(initial.checksum);
  });

  it("returns existing record when sync is up to date", async () => {
    const initial = await indexArtifact({
      issueId,
      type: "prd",
      title: "PRD",
      content: "Stable content",
    });

    const synced = await syncArtifactFromDisk({ issueId, type: "prd" });
    expect(synced?.checksum).toBe(initial.checksum);
  });

  it("skips deleting missing files when removing artifacts", async () => {
    const record = await indexArtifact({
      issueId,
      type: "task",
      title: "Task",
      taskId: "task-3",
      content: "Task body",
    });

    await fs.unlink(record.filePath);
    await expect(
      deleteArtifact({ issueId, type: "task", taskId: "task-3" })
    ).resolves.toBeUndefined();
  });

  it("includes PRD and techspec paths when files exist", async () => {
    await indexArtifact({
      issueId,
      type: "prd",
      title: "PRD",
      content: "PRD content",
    });

    await indexArtifact({
      issueId,
      type: "techspec",
      title: "Spec",
      content: "Spec content",
    });

    const context = await getArtifactContextPaths(issueId);
    expect(context.prdPath).toMatch(/\/artifacts\/prd\.md$/);
    expect(context.techspecPath).toMatch(/\/artifacts\/techspec\.md$/);
  });
});
