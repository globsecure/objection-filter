import "@shared/test-utils/cleanup";
import { afterEach, describe, expect, it } from "vitest";

import { cleanupTestCompozyHomeDir } from "@shared/repository-key";
import { getArtifactFilePath, isValidTaskId } from "../paths";

afterEach(() => {
  cleanupTestCompozyHomeDir();
});

describe("isValidTaskId", () => {
  it("accepts valid task IDs", () => {
    expect(isValidTaskId("task-123")).toBe(true);
    expect(isValidTaskId("task_123")).toBe(true);
    expect(isValidTaskId("task.123")).toBe(true);
    expect(isValidTaskId("a".repeat(64))).toBe(true);
  });

  it("rejects invalid task IDs", () => {
    expect(isValidTaskId("")).toBe(false);
    expect(isValidTaskId(" ")).toBe(false);
    expect(isValidTaskId("task 123")).toBe(false);
    expect(isValidTaskId("!bad")).toBe(false);
    expect(isValidTaskId("a".repeat(65))).toBe(false);
  });
});

describe("getArtifactFilePath", () => {
  const issueId = "123e4567-e89b-12d3-a456-426614174000";

  it("returns the expected paths for document artifacts", () => {
    expect(getArtifactFilePath({ issueId, type: "prd" })).toContain("/artifacts/prd.md");
    expect(getArtifactFilePath({ issueId, type: "techspec" })).toContain("/artifacts/techspec.md");
    expect(getArtifactFilePath({ issueId, type: "issue_context" })).toContain(
      "/artifacts/issue-context.md"
    );
  });

  it("normalizes task IDs and slugs for task artifacts", () => {
    const taskPath = getArtifactFilePath({
      issueId,
      type: "task",
      title: "Shipping Setup",
      taskId: "  task-42  ",
    });

    expect(taskPath).toContain("/artifacts/tasks/shipping-setup-task-42.md");
  });

  it("uses the default task slug when title is blank", () => {
    const taskPath = getArtifactFilePath({
      issueId,
      type: "task",
      title: " ",
      taskId: "task-1",
    });

    expect(taskPath).toContain("/artifacts/tasks/task-task-1.md");
  });

  it("uses the provided task slug when available", () => {
    const taskPath = getArtifactFilePath({
      issueId,
      type: "task",
      title: "Ignored Title",
      taskId: "task-2",
      taskSlug: "Custom Slug",
    });

    expect(taskPath).toContain("/artifacts/tasks/custom-slug-task-2.md");
  });

  it("throws when task ID is invalid", () => {
    expect(() => getArtifactFilePath({ issueId, type: "task", taskId: "bad id" })).toThrow(
      "Invalid task ID"
    );
  });

  it("throws when task ID is missing", () => {
    expect(() => getArtifactFilePath({ issueId, type: "task" })).toThrow("taskId");
  });
});
