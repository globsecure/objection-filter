import "@shared/test-utils/cleanup";
import { describe, expect, it } from "vitest";

import { buildIssueContextMarkdown, buildTaskArtifactMarkdown } from "../markdown";

describe("buildTaskArtifactMarkdown", () => {
  it("returns empty string when title and content are blank", () => {
    expect(buildTaskArtifactMarkdown({ title: " ", content: " " })).toBe("");
  });

  it("returns content-only markdown when title is blank", () => {
    expect(buildTaskArtifactMarkdown({ title: " ", content: "  Hello world  " })).toBe(
      "Hello world\n"
    );
  });

  it("returns title-only markdown when content is blank", () => {
    expect(buildTaskArtifactMarkdown({ title: "  New Task  " })).toBe("# New Task\n");
  });

  it("returns title-only markdown when content is null", () => {
    expect(buildTaskArtifactMarkdown({ title: "  Task  ", content: null })).toBe("# Task\n");
  });

  it("returns title and content markdown when both are provided", () => {
    expect(buildTaskArtifactMarkdown({ title: "  New Task  ", content: "  Do the thing  " })).toBe(
      "# New Task\n\nDo the thing\n"
    );
  });
});

describe("buildIssueContextMarkdown", () => {
  it("returns only the header when no values are provided", () => {
    expect(buildIssueContextMarkdown({})).toBe("# Issue Context\n");
  });

  it("includes issue and repository sections when provided", () => {
    const markdown = buildIssueContextMarkdown({
      title: "  Login fails  ",
      summary: "  Users cannot sign in  ",
      mainRepositoryPath: "  /repos/main  ",
      additionalRepositoryPaths: ["  /repos/extra ", null, undefined, " /repos/another "],
    });

    expect(markdown).toContain("# Issue Context");
    expect(markdown).toContain("## Issue");
    expect(markdown).toContain("- Title: Login fails");
    expect(markdown).toContain("- Summary: Users cannot sign in");
    expect(markdown).toContain("## Repository Scope");
    expect(markdown).toContain("- Main Repository: /repos/main");
    expect(markdown).toContain("- Additional Repositories: /repos/extra, /repos/another");
    expect(markdown.endsWith("\n")).toBe(true);
  });

  it("handles partial issue info without repositories", () => {
    const markdown = buildIssueContextMarkdown({ title: "Bug" });

    expect(markdown).toContain("# Issue Context");
    expect(markdown).toContain("- Title: Bug");
    expect(markdown).not.toContain("Repository Scope");
  });
});
