export const ARTIFACTS_SCHEMA_SQL = `
  CREATE TABLE IF NOT EXISTS artifacts (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    file_path TEXT NOT NULL UNIQUE,
    created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER) * 1000),
    updated_at INTEGER NOT NULL,
    synced_at INTEGER,
    checksum TEXT NOT NULL
  );

  CREATE INDEX IF NOT EXISTS idx_artifacts_type ON artifacts(type);
  CREATE INDEX IF NOT EXISTS idx_artifacts_updated ON artifacts(updated_at);

  CREATE VIRTUAL TABLE IF NOT EXISTS artifacts_fts USING fts5(
    id,
    type,
    file_path,
    content
  );
`;
