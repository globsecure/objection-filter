import { createClient, type Client } from "@libsql/client";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Schema from "effect/Schema";
import { ensureParentDir } from "../../shared/ensure-dir";
import { ARTIFACTS_SCHEMA_SQL } from "./schema";

export class ArtifactDbError extends Schema.TaggedError<ArtifactDbError>()("ArtifactDbError", {
  message: Schema.String,
  cause: Schema.optional(Schema.Defect),
}) {}

export interface ArtifactDb {
  readonly client: Client;
  readonly dbPath: string;
}

export const ArtifactDb = Context.GenericTag<ArtifactDb>("@compozy/artifacts/ArtifactDb");

const ARTIFACTS_TABLE_INFO_SQL = "PRAGMA table_info(artifacts)";

interface PragmaTableInfoRow {
  cid: number;
  name: string;
  type: string;
  notnull: number;
  dflt_value: unknown;
  pk: number;
}

function isPragmaTableInfoRow(row: unknown): row is PragmaTableInfoRow {
  return (
    typeof row === "object" &&
    row !== null &&
    "name" in row &&
    typeof (row as { name: unknown }).name === "string"
  );
}

function toLibsqlFileUrl(dbPath: string): string {
  if (dbPath === ":memory:") {
    return ":memory:";
  }

  if (dbPath.startsWith("file:")) {
    return dbPath;
  }

  return `file:${dbPath}`;
}

function ensureArtifactDbParentDir(filePath: string): void {
  const normalizedPath = filePath.startsWith("file:") ? filePath.slice("file:".length) : filePath;
  ensureParentDir(normalizedPath, { recursive: true, mode: 0o700 });
}

async function initializeClient(client: Client): Promise<void> {
  await client.executeMultiple(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    PRAGMA busy_timeout = 5000;
    ${ARTIFACTS_SCHEMA_SQL}
  `);
  await ensureArtifactsCreatedAtColumn(client);
}

async function ensureArtifactsCreatedAtColumn(client: Client): Promise<void> {
  const tableInfo = await client.execute(ARTIFACTS_TABLE_INFO_SQL);
  const rows = Array.isArray(tableInfo?.rows) ? tableInfo.rows : [];
  const hasCreatedAt = rows.some(row => isPragmaTableInfoRow(row) && row.name === "created_at");

  if (!hasCreatedAt) {
    // SQLite doesn't allow adding columns with non-constant defaults.
    // Add column with a constant default (0), then update existing rows.
    await client.execute("ALTER TABLE artifacts ADD COLUMN created_at INTEGER NOT NULL DEFAULT 0");
    // Update existing rows to use updated_at as created_at
    await client.execute("UPDATE artifacts SET created_at = updated_at");
  }
}

export function openArtifactDb(dbPath: string): Effect.Effect<ArtifactDb, ArtifactDbError> {
  return Effect.tryPromise({
    try: async () => {
      ensureArtifactDbParentDir(dbPath);
      const client = createClient({ url: toLibsqlFileUrl(dbPath) });
      try {
        await initializeClient(client);
        return { client, dbPath };
      } catch (error) {
        try {
          client.close();
        } catch {
          // ignore close failure
        }
        throw error;
      }
    },
    catch: cause =>
      ArtifactDbError.make({
        message: `Failed to open artifacts database at ${dbPath}`,
        cause,
      }),
  });
}

export function closeArtifactDb(db: ArtifactDb): Effect.Effect<void, never> {
  return Effect.try({
    try: () => db.client.close(),
    catch: error => error,
  }).pipe(
    Effect.tapError(error =>
      Effect.logDebug("Failed to close artifact DB", { error, dbPath: db.dbPath })
    ),
    Effect.ignore
  );
}

export function artifactDbLayer(dbPath: string): Layer.Layer<ArtifactDb, ArtifactDbError> {
  return Layer.scoped(ArtifactDb, Effect.acquireRelease(openArtifactDb(dbPath), closeArtifactDb));
}
