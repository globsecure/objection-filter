import "@shared/test-utils/cleanup";
import { afterEach, describe, expect, it } from "vitest";
import * as Effect from "effect/Effect";
import * as fs from "node:fs/promises";
import * as os from "node:os";
import path from "node:path";

import { cleanupTestCompozyHomeDir } from "@shared/repository-key";
import { createArtifactRepository } from "../repository";
import type { ArtifactRecord } from "../../types";

async function withTempDbPath(
  prefix: string
): Promise<{ tempDir: string; dbPath: string; cleanup: () => Promise<void> }> {
  const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), prefix));
  return {
    tempDir,
    dbPath: path.join(tempDir, "artifacts.db"),
    cleanup: async () => {
      await fs.rm(tempDir, { recursive: true, force: true });
    },
  };
}

afterEach(() => {
  cleanupTestCompozyHomeDir();
});

describe("ArtifactRepository", () => {
  it("upserts, queries, lists, and deletes artifacts", async () => {
    const { dbPath, cleanup } = await withTempDbPath("artifact-repo-");
    const repo = await createArtifactRepository({ dbPath });

    try {
      const now = Date.now();
      const prdRecord: ArtifactRecord = {
        id: "prd",
        type: "prd",
        filePath: "/tmp/prd.md",
        updatedAt: now,
        syncedAt: null,
        checksum: "checksum-prd",
      };

      const techspecRecord: ArtifactRecord = {
        id: "techspec",
        type: "techspec",
        filePath: "/tmp/techspec.md",
        updatedAt: now - 1000,
        syncedAt: null,
        checksum: "checksum-techspec",
      };

      await Effect.runPromise(repo.upsertArtifact(prdRecord, "Alpha details"));
      await Effect.runPromise(repo.upsertArtifact(techspecRecord, "Beta details"));

      const loaded = await Effect.runPromise(repo.getArtifactById("prd"));
      expect(loaded).toEqual(prdRecord);

      const listResults = await Effect.runPromise(repo.listArtifacts());
      expect(listResults.length).toBe(2);
      expect(listResults[0]?.id).toBe("prd");
      expect(listResults[1]?.id).toBe("techspec");

      await Effect.runPromise(repo.deleteArtifact("prd"));
      const deleted = await Effect.runPromise(repo.getArtifactById("prd"));
      expect(deleted).toBeNull();

      const afterDelete = await Effect.runPromise(repo.listArtifacts());
      expect(afterDelete.length).toBe(1);
      expect(afterDelete[0]?.id).toBe("techspec");
    } finally {
      repo.close();
      await cleanup();
    }
  });

  it("lists artifacts ordered by updated_at descending", async () => {
    const { dbPath, cleanup } = await withTempDbPath("artifact-repo-order-");
    const repo = await createArtifactRepository({ dbPath });

    try {
      const now = Date.now();
      const oldRecord: ArtifactRecord = {
        id: "old-prd",
        type: "prd",
        filePath: "/tmp/prd-old.md",
        updatedAt: now - 2000,
        syncedAt: null,
        checksum: "checksum-old",
      };

      const newRecord: ArtifactRecord = {
        id: "new-prd",
        type: "prd",
        filePath: "/tmp/prd-new.md",
        updatedAt: now,
        syncedAt: null,
        checksum: "checksum-new",
      };

      const midRecord: ArtifactRecord = {
        id: "mid-techspec",
        type: "techspec",
        filePath: "/tmp/techspec-mid.md",
        updatedAt: now - 1000,
        syncedAt: null,
        checksum: "checksum-mid",
      };

      await Effect.runPromise(repo.upsertArtifact(oldRecord, "Old content"));
      await Effect.runPromise(repo.upsertArtifact(newRecord, "New content"));
      await Effect.runPromise(repo.upsertArtifact(midRecord, "Mid content"));

      const results = await Effect.runPromise(repo.listArtifacts());
      expect(results.map(r => r.id)).toEqual(["new-prd", "mid-techspec", "old-prd"]);
    } finally {
      repo.close();
      await cleanup();
    }
  });

  it("returns empty array when no artifacts exist", async () => {
    const { dbPath, cleanup } = await withTempDbPath("artifact-repo-empty-");
    const repo = await createArtifactRepository({ dbPath });

    try {
      const results = await Effect.runPromise(repo.listArtifacts());
      expect(results).toEqual([]);
    } finally {
      repo.close();
      await cleanup();
    }
  });

  it("returns correct fields in list items", async () => {
    const { dbPath, cleanup } = await withTempDbPath("artifact-repo-fields-");
    const repo = await createArtifactRepository({ dbPath });

    try {
      const now = Date.now();
      const record: ArtifactRecord = {
        id: "task:abc-123",
        type: "task",
        filePath: "/tmp/task-abc.md",
        updatedAt: now,
        syncedAt: now,
        checksum: "checksum-task",
      };

      await Effect.runPromise(repo.upsertArtifact(record, "Task content"));

      const results = await Effect.runPromise(repo.listArtifacts());
      expect(results.length).toBe(1);
      expect(results[0]).toEqual({
        id: "task:abc-123",
        type: "task",
        filePath: "/tmp/task-abc.md",
      });
    } finally {
      repo.close();
      await cleanup();
    }
  });
});
