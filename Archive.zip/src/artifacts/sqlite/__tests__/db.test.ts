import "@shared/test-utils/cleanup";
import { afterEach, describe, expect, it, vi } from "vitest";
import * as Effect from "effect/Effect";
import * as fs from "node:fs/promises";
import * as os from "node:os";
import path from "node:path";

import { cleanupTestCompozyHomeDir } from "@shared/repository-key";

async function withTempDbPath(prefix: string): Promise<{ tempDir: string; dbPath: string }> {
  const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), prefix));
  return { tempDir, dbPath: path.join(tempDir, "artifacts.db") };
}

afterEach(() => {
  cleanupTestCompozyHomeDir();
  vi.resetModules();
  vi.clearAllMocks();
  vi.doUnmock("node:fs");
  vi.doUnmock("@libsql/client");
});

describe("artifact db", () => {
  it("opens and closes a memory database", async () => {
    const { openArtifactDb, closeArtifactDb } = await import("../db");

    const db = await Effect.runPromise(openArtifactDb(":memory:"));
    const tables = await db.client.execute(
      "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name ASC"
    );
    const tableNames = (tables.rows as unknown as Array<Record<string, unknown>>)
      .map(row => row["name"])
      .filter((value): value is string => typeof value === "string");

    expect(tableNames).toContain("artifacts");
    expect(tableNames).toContain("artifacts_fts");

    await Effect.runPromise(closeArtifactDb(db));
  });

  it("provides a database via artifactDbLayer", async () => {
    const { ArtifactDb, artifactDbLayer } = await import("../db");
    const { dbPath } = await withTempDbPath("artifact-layer-");

    const resolvedPath = await Effect.runPromise(
      Effect.gen(function* () {
        const db = yield* ArtifactDb;
        return db.dbPath;
      }).pipe(Effect.provide(artifactDbLayer(dbPath)), Effect.scoped)
    );

    expect(resolvedPath).toBe(dbPath);
  });

  it("wraps initialization failures in ArtifactDbError", async () => {
    vi.doMock("@libsql/client", () => ({
      createClient: () => ({
        execute: async () => {
          throw new Error("init failure");
        },
        executeMultiple: async () => {
          throw new Error("init failure");
        },
        close: vi.fn(),
      }),
    }));

    const { openArtifactDb } = await import("../db");

    await expect(Effect.runPromise(openArtifactDb(":memory:"))).rejects.toThrow(
      /Failed to open artifacts database/
    );
  });

  it("treats EEXIST as success when directory already exists", async () => {
    const existsSync = vi.fn().mockReturnValueOnce(false).mockReturnValueOnce(true);
    const mkdirSync = vi.fn(() => {
      const error = new Error("exists") as NodeJS.ErrnoException;
      error.code = "EEXIST";
      throw error;
    });

    vi.doMock("node:fs", () => ({
      existsSync,
      mkdirSync,
    }));

    const createClient = vi.fn(() => ({
      execute: vi.fn(async () => undefined),
      executeMultiple: vi.fn(async () => undefined),
      close: vi.fn(),
    }));

    vi.doMock("@libsql/client", () => ({
      createClient,
    }));

    const { openArtifactDb, closeArtifactDb } = await import("../db");

    const db = await Effect.runPromise(openArtifactDb("/tmp/artifacts.db"));
    await Effect.runPromise(closeArtifactDb(db));

    expect(mkdirSync).toHaveBeenCalled();
  });

  it("throws when EEXIST is reported but directory is still missing", async () => {
    const existsSync = vi.fn(() => false);
    const mkdirSync = vi.fn(() => {
      const error = new Error("exists") as NodeJS.ErrnoException;
      error.code = "EEXIST";
      throw error;
    });

    vi.doMock("node:fs", () => ({
      existsSync,
      mkdirSync,
    }));

    vi.doMock("@libsql/client", () => ({
      createClient: () => ({
        execute: vi.fn(async () => undefined),
        executeMultiple: vi.fn(async () => undefined),
        close: vi.fn(),
      }),
    }));

    const { openArtifactDb } = await import("../db");

    await expect(Effect.runPromise(openArtifactDb("/tmp/artifacts.db"))).rejects.toThrow(
      /Failed to open artifacts database/
    );
  });

  it("uses file URLs for database paths", async () => {
    const createClient = vi.fn(() => ({
      execute: vi.fn(async () => undefined),
      executeMultiple: vi.fn(async () => undefined),
      close: vi.fn(),
    }));

    vi.doMock("@libsql/client", () => ({
      createClient,
    }));

    const { dbPath } = await withTempDbPath("artifact-url-");

    const { closeArtifactDb, openArtifactDb } = await import("../db");

    const fileDb = await Effect.runPromise(openArtifactDb(dbPath));
    await Effect.runPromise(closeArtifactDb(fileDb));

    const filePrefixDb = await Effect.runPromise(openArtifactDb(`file:${dbPath}`));
    await Effect.runPromise(closeArtifactDb(filePrefixDb));

    const memoryDb = await Effect.runPromise(openArtifactDb(":memory:"));
    await Effect.runPromise(closeArtifactDb(memoryDb));

    expect(createClient).toHaveBeenNthCalledWith(1, { url: `file:${dbPath}` });
    expect(createClient).toHaveBeenNthCalledWith(2, { url: `file:${dbPath}` });
    expect(createClient).toHaveBeenNthCalledWith(3, { url: ":memory:" });
  });

  it("ignores close failures when initialization fails", async () => {
    vi.doMock("@libsql/client", () => ({
      createClient: () => ({
        execute: async () => {
          throw new Error("init failure");
        },
        executeMultiple: async () => {
          throw new Error("init failure");
        },
        close: () => {
          throw new Error("close failure");
        },
      }),
    }));

    const { openArtifactDb } = await import("../db");

    await expect(Effect.runPromise(openArtifactDb(":memory:"))).rejects.toThrow(
      /Failed to open artifacts database/
    );
  });
});
