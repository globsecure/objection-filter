import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import { pipe } from "effect/Function";
import * as Layer from "effect/Layer";
import { artifactTypeSchema } from "../types";
import type { ArtifactListItem, ArtifactRecord, ArtifactType } from "../types";
import { ArtifactDb, ArtifactDbError, artifactDbLayer, openArtifactDb } from "./db";

export interface ArtifactRepository {
  upsertArtifact: (record: ArtifactRecord, content: string) => Effect.Effect<void, ArtifactDbError>;
  getArtifactById: (id: string) => Effect.Effect<ArtifactRecord | null, ArtifactDbError>;
  deleteArtifact: (id: string) => Effect.Effect<void, ArtifactDbError>;
  listArtifacts: () => Effect.Effect<ReadonlyArray<ArtifactListItem>, ArtifactDbError>;
}

export const ArtifactRepository = Context.GenericTag<ArtifactRepository>(
  "@compozy/artifacts/ArtifactRepository"
);

function parseArtifactType(rawType: string): ArtifactType {
  const parsedType = artifactTypeSchema.safeParse(rawType);
  if (!parsedType.success) {
    throw new Error(`Invalid artifact type in database: ${rawType}`);
  }
  return parsedType.data;
}

function mapRowToArtifactRecord(row: {
  id: string;
  type: string;
  file_path: string;
  updated_at: number;
  synced_at: number | null;
  checksum: string;
}): ArtifactRecord {
  return {
    id: row.id,
    type: parseArtifactType(row.type),
    filePath: row.file_path,
    updatedAt: Number(row.updated_at),
    syncedAt: row.synced_at !== null ? Number(row.synced_at) : null,
    checksum: row.checksum,
  };
}

function makeUpsertArtifact(client: ArtifactDb["client"]) {
  return (record: ArtifactRecord, content: string): Effect.Effect<void, ArtifactDbError> =>
    Effect.tryPromise({
      try: async () => {
        await client.batch(
          [
            {
              sql: `
            INSERT INTO artifacts (id, type, file_path, created_at, updated_at, synced_at, checksum)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
              type = excluded.type,
              file_path = excluded.file_path,
              updated_at = excluded.updated_at,
              synced_at = excluded.synced_at,
              checksum = excluded.checksum
          `,
              args: [
                record.id,
                record.type,
                record.filePath,
                record.updatedAt,
                record.updatedAt,
                record.syncedAt,
                record.checksum,
              ],
            },
            {
              sql: "DELETE FROM artifacts_fts WHERE id = ?",
              args: [record.id],
            },
            {
              sql: "INSERT INTO artifacts_fts (id, type, file_path, content) VALUES (?, ?, ?, ?)",
              args: [record.id, record.type, record.filePath, content],
            },
          ],
          "write"
        );
      },
      catch: cause =>
        ArtifactDbError.make({
          message: `Failed to upsert artifact ${record.id}`,
          cause,
        }),
    }).pipe(Effect.asVoid);
}

function makeGetArtifactById(client: ArtifactDb["client"]) {
  return (id: string): Effect.Effect<ArtifactRecord | null, ArtifactDbError> =>
    Effect.tryPromise({
      try: async () => {
        const result = await client.execute({
          sql: "SELECT id, type, file_path, updated_at, synced_at, checksum FROM artifacts WHERE id = ?",
          args: [id],
        });
        const row = result.rows[0] as unknown as
          | {
              id: string;
              type: string;
              file_path: string;
              updated_at: number;
              synced_at: number | null;
              checksum: string;
            }
          | undefined;
        return row ? mapRowToArtifactRecord(row) : null;
      },
      catch: cause =>
        ArtifactDbError.make({
          message: `Failed to load artifact ${id}`,
          cause,
        }),
    });
}

function makeDeleteArtifact(client: ArtifactDb["client"]) {
  return (id: string): Effect.Effect<void, ArtifactDbError> =>
    Effect.tryPromise({
      try: async () => {
        await client.batch(
          [
            {
              sql: "DELETE FROM artifacts WHERE id = ?",
              args: [id],
            },
            {
              sql: "DELETE FROM artifacts_fts WHERE id = ?",
              args: [id],
            },
          ],
          "write"
        );
      },
      catch: cause =>
        ArtifactDbError.make({
          message: `Failed to delete artifact ${id}`,
          cause,
        }),
    }).pipe(Effect.asVoid);
}

function makeListArtifacts(client: ArtifactDb["client"]) {
  return (): Effect.Effect<ReadonlyArray<ArtifactListItem>, ArtifactDbError> =>
    Effect.tryPromise({
      try: async () => {
        const result = await client.execute({
          sql: "SELECT id, type, file_path FROM artifacts ORDER BY updated_at DESC",
          args: [],
        });
        return result.rows.map(row => ({
          id: row.id as string,
          type: parseArtifactType(String(row.type)),
          filePath: row.file_path as string,
        }));
      },
      catch: cause =>
        ArtifactDbError.make({
          message: "Failed to list artifacts",
          cause,
        }),
    });
}

export function makeArtifactRepository(db: ArtifactDb): ArtifactRepository {
  return {
    upsertArtifact: makeUpsertArtifact(db.client),
    getArtifactById: makeGetArtifactById(db.client),
    deleteArtifact: makeDeleteArtifact(db.client),
    listArtifacts: makeListArtifacts(db.client),
  };
}

export const ArtifactRepositoryLayer = (dbPath: string) =>
  pipe(
    Layer.scoped(
      ArtifactRepository,
      Effect.gen(function* () {
        const db = yield* ArtifactDb;
        return makeArtifactRepository(db);
      })
    ),
    Layer.provide(artifactDbLayer(dbPath))
  );

export type ArtifactRepositoryWithClose = ArtifactRepository & { close: () => void };

/**
 * Creates an artifact repository with a managed database connection.
 * This is a convenience function for consumers that need direct repository access
 * outside of the Effect layer system.
 *
 * @param options - Configuration options including dbPath
 * @returns Repository instance with close method for cleanup
 * @throws {ArtifactDbError} If database cannot be opened (e.g., disk full, permissions, corruption).
 *         Callers should handle this at the application boundary with appropriate error UI/logging.
 */
export async function createArtifactRepository(options: {
  dbPath: string;
}): Promise<ArtifactRepositoryWithClose> {
  const db = await Effect.runPromise(openArtifactDb(options.dbPath));
  const repository = makeArtifactRepository(db);

  return {
    ...repository,
    close: () => {
      try {
        db.client.close();
      } catch {
        // best effort
      }
    },
  };
}
