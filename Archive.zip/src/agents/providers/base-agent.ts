import type { SubagentRegistry } from "@compozy/prompts/built-in";
import type { PromptBuilder } from "@compozy/prompts";
import {
  createClaudeCode,
  createSdkMcpServer,
  tool,
  type HookCallback,
  type McpSdkServerConfigWithInstance,
  type McpServerConfig,
} from "@compozy/provider-claude-code";
import type { AgentTool, ToolStreamContext } from "@compozy/types";
import { DEFAULT_RETRY_CONFIG, ErrorClassifier, Tools, type RetryConfig } from "@compozy/types";
import { getLogger } from "@logtape/logtape";
import {
  createStopOnToolChunkHandler,
  processStreamWithIncrementalSaving,
  type ChatHistoryStore,
} from "@shared";
import {
  consumeStream,
  convertToModelMessages,
  createUIMessageStream,
  createUIMessageStreamResponse,
  isToolUIPart,
  streamText,
  type StreamTextResult,
  type ToolUIPart,
  type UIMessage,
} from "ai";
import { Effect } from "effect";
import { compact } from "es-toolkit/array";
import { isPlainObject } from "es-toolkit/predicate";
import { indexArtifact } from "../../artifacts/indexer";
import { getIssueDir } from "../../shared/issue-path";
import { detectClaudeCodeInstallation } from "../../main/utils/claude-detection";
import { buildClaudeCodeEnvVars } from "../../main/utils/claude-code-env-reader";
import {
  addDirectoryToPath,
  ensureNodeOnPath,
  getElectronBinaryDirectory,
  resolveNodeExecutablePath,
} from "../../main/utils/node-path-resolver";
import { createExaMcpServer } from "../mcp/servers";
import { createChatHistoryStore } from "../server/lib/chat-history-store";
import { extractAndFormatClarifications } from "../server/lib/clarification-extractor";
import { SessionTracker } from "../server/lib/session-tracker";
import type { SessionType } from "../server/modules/agents";
import { CombinedChunkHandler } from "./utils/combined-chunk-handler";
import {
  extractToolNamesFromTools,
  injectToolNamesIntoBuilder,
} from "./utils/prompt-tool-injector";
import { createToolStreamContext, type StreamContextOptions } from "./utils/stream-context-adapter";
import { ToolErrorNormalizer } from "./utils/tool-error-normalizer";
import { ToolErrorRetryHandler } from "./utils/tool-error-retry-handler";

const DISALLOWED_TOOLS = [
  "Write",
  "WebSearch",
  "AskUserQuestion",
  "EnterPlanMode",
  "ExitPlanMode",
] as const;

/**
 * Reasoning effort levels for extended thinking mode.
 * Maps to maxThinkingTokens in Claude Agent SDK.
 */
export type ReasoningEffort = "minimal" | "low" | "medium" | "high";

/**
 * Token budget mapping for reasoning effort levels.
 * Higher values allow more internal deliberation but increase latency and cost.
 */
const REASONING_TOKEN_BUDGET: Record<ReasoningEffort, number> = {
  minimal: 1000,
  low: 2000,
  medium: 4000,
  high: 8000,
};

export interface BaseArtifactCreatorOptions {
  issueId: string;
  mainRepositoryPath: string;
  additionalRepositoryPaths?: string[];
  instructions: PromptBuilder;
  loggerCategory: string[];
  sessionType: SessionType;
  tools: AgentTool<any, any, any>[]; // AgentTool instances for prompt building and tool registration
  model?: "sonnet" | "opus" | "haiku";
  /**
   * Reasoning effort level for extended thinking.
   * Controls internal reasoning depth via maxThinkingTokens.
   */
  reasoningEffort?: ReasoningEffort;
  hooks?: Partial<
    Record<
      string,
      Array<{
        matcher?: string;
        hooks: HookCallback[];
      }>
    >
  >;
  /**
   * Retry configuration for tool error handling
   */
  retryConfig?: RetryConfig;
}

export interface StreamOptions {
  messages: UIMessage[];
  system?: string;
  abortSignal: AbortSignal;
  onStreamFinish?: () => void;
}

export abstract class BaseAgent {
  protected readonly issueId: string;
  protected readonly sessionType: string;
  protected readonly mainRepositoryPath: string;
  protected readonly additionalRepositoryPaths?: string[];
  protected readonly issueDir: string;
  private readonly instructions: string;
  private readonly model: "sonnet" | "opus" | "haiku";
  private readonly reasoningEffort: ReasoningEffort | undefined;
  protected readonly logger;
  private readonly sessionTracker: SessionTracker;
  private readonly chatHistoryStore: ChatHistoryStore;
  protected readonly tools: Tools<McpSdkServerConfigWithInstance>;
  private claudeSessionId?: string;
  private mcpServers?: (
    streamContext: ToolStreamContext,
    tools: Tools<McpSdkServerConfigWithInstance>
  ) => Record<string, McpServerConfig | McpSdkServerConfigWithInstance>;
  private readonly retryConfig: Required<RetryConfig>;
  private readonly errorClassifier: ErrorClassifier;
  private readonly retryHandler?: ToolErrorRetryHandler;
  private readonly streamNormalizer: ToolErrorNormalizer;

  protected constructor(private readonly config: BaseArtifactCreatorOptions) {
    this.issueId = config.issueId;
    this.sessionType = config.sessionType;
    this.mainRepositoryPath = config.mainRepositoryPath;
    if (config.additionalRepositoryPaths !== undefined) {
      this.additionalRepositoryPaths = config.additionalRepositoryPaths;
    }
    this.issueDir = getIssueDir(this.issueId);
    const toolNames = extractToolNamesFromTools(config.tools);
    const builder = injectToolNamesIntoBuilder(config.instructions, toolNames);
    this.instructions = builder.build();
    this.model = config.model ?? "sonnet";
    this.reasoningEffort = config.reasoningEffort;
    this.logger = getLogger(config.loggerCategory);
    this.sessionTracker = new SessionTracker(config.issueId, config.mainRepositoryPath);
    this.chatHistoryStore = createChatHistoryStore(config.issueId, config.mainRepositoryPath);
    this.tools = new Tools<McpSdkServerConfigWithInstance>();
    this.retryConfig = { ...DEFAULT_RETRY_CONFIG, ...config.retryConfig };
    this.errorClassifier = new ErrorClassifier(config.retryConfig);

    // Create retry handler if retry is enabled
    if (this.retryConfig.enableAutoRetry) {
      this.retryHandler = new ToolErrorRetryHandler(
        this.retryConfig,
        this.errorClassifier,
        this.logger
      );
    }

    // Create stream normalizer
    this.streamNormalizer = new ToolErrorNormalizer();

    // Set the curry function for creating MCP servers
    this.tools.setCreateTools((toolDefinitions, config) => {
      const mcpTools = toolDefinitions.map(def =>
        tool(def.name, def.description, def.mcpInputShape, def.handler)
      );
      return createSdkMcpServer({
        name: config.name,
        ...(config.version !== undefined && { version: config.version }),
        tools: mcpTools,
      });
    });

    this.mcpServers = (
      streamContext: ToolStreamContext,
      tools: Tools<McpSdkServerConfigWithInstance>
    ) => {
      const sdkServers = this.buildSdkMcpServers(streamContext, tools);
      return {
        ...sdkServers,
        ...this.buildExaMcpServer(tools),
      };
    };
  }

  /**
   * Generate a safe chatId from issueId and sessionType
   * Format: {issueId}_{sessionType}
   * Sanitizes to match ChatHistoryStore pattern: /^[a-z0-9_-]{1,64}$/i
   */
  private getChatId(): string {
    const sanitize = (value: string): string => value.replace(/[^a-z0-9_-]/gi, "_").toLowerCase();
    const sanitizedIssueId = sanitize(this.issueId || "unknown");
    const sanitizedSessionType = sanitize(this.sessionType || "unknown");
    const combined = `${sanitizedIssueId}_${sanitizedSessionType}`;
    const truncated = combined.slice(0, 64);
    return truncated || "unknown";
  }

  protected abstract subagents(): SubagentRegistry | null;

  /**
   * Override to provide SDK MCP servers for this agent.
   * Each agent should register only the MCP servers it needs.
   */
  protected abstract buildSdkMcpServers(
    streamContext: ToolStreamContext,
    tools: Tools<McpSdkServerConfigWithInstance>
  ): Record<string, McpSdkServerConfigWithInstance>;

  protected formatInstructions(system?: string): string {
    if (system && system.trim() !== "") {
      return `${this.instructions}
        <task_context>
        ${system}
        </task_context>`.trim();
    }
    return this.instructions.trim();
  }

  private ensurePersistedMessageOrder(messages: UIMessage[]): UIMessage[] {
    return messages.map((message, index) => {
      const rawMetadata = (message as unknown as { metadata?: unknown }).metadata;
      const metadata = isPlainObject(rawMetadata) ? (rawMetadata as Record<string, unknown>) : {};
      const rawCompozy = metadata["compozy"];
      const compozy = isPlainObject(rawCompozy) ? (rawCompozy as Record<string, unknown>) : {};
      const existingOrder = compozy["order"];
      const order =
        typeof existingOrder === "number" && Number.isFinite(existingOrder) ? existingOrder : index;

      return {
        ...message,
        metadata: {
          ...metadata,
          compozy: {
            ...compozy,
            order,
          },
        },
      } as UIMessage;
    });
  }

  private async saveMessages(messages: UIMessage[]): Promise<void> {
    const chatId = this.getChatId();
    try {
      const normalized = this.ensurePersistedMessageOrder(messages);
      await this.chatHistoryStore.saveMessages(chatId, normalized);
      this.logger.debug("Saved messages for chat {chatId}", {
        chatId,
        messageCount: normalized.length,
      });
    } catch (error) {
      this.logger.error("Failed to save messages for chat {chatId}", { chatId, error });
    }
  }

  private async processStreamWithIncrementalSaving(
    uiMessageStream: AsyncIterable<any>,
    writer: Parameters<Parameters<typeof createUIMessageStream>[0]["execute"]>[0]["writer"],
    originalMessages: UIMessage[]
  ): Promise<void> {
    const stopOnToolNames = this.tools.getStopOnUseToolNames();
    const stopOnToolChunkHandler = createStopOnToolChunkHandler(stopOnToolNames);

    // Create combined chunk handler
    const chunkHandler = new CombinedChunkHandler(
      stopOnToolChunkHandler,
      this.retryHandler,
      this.retryConfig
    );

    await processStreamWithIncrementalSaving({
      uiMessageStream,
      writer,
      originalMessages,
      onChunk: chunk => chunkHandler.handle(chunk),
      saveCallback: async (messages: UIMessage[]) => {
        await this.saveMessages(messages);
      },
    });
  }

  async stream(options: StreamOptions) {
    // Reset retry handler at start
    this.retryHandler?.reset();

    const { messages, system, abortSignal, onStreamFinish } = options;
    const abortCleanup = () => this.retryHandler?.reset();
    abortSignal?.addEventListener("abort", abortCleanup, { once: true });

    await this.sessionTracker.load();

    const resumeSessionId =
      this.claudeSessionId ??
      this.sessionTracker.getClaudeSessionId(this.issueId, this.sessionType);

    // Extract clarifications from messages and append to system prompt
    const clarificationText = extractAndFormatClarifications(messages);
    const systemWithClarifications = clarificationText
      ? `${system}\n\n${clarificationText}`
      : system;

    const uiStream = createUIMessageStream({
      execute: async ({ writer }) => {
        const subagents = this.subagents();
        const handleArtifactIndexing = async (
          payload: Parameters<NonNullable<StreamContextOptions["onArtifactCreated"]>>[0],
          operation: "creation" | "update"
        ) => {
          const resolvedIssueId = payload.issueId ?? this.issueId;
          try {
            await indexArtifact({
              issueId: resolvedIssueId,
              type: payload.type,
              title: payload.title,
              content: payload.content,
              taskId: payload.taskId,
              taskSlug: payload.taskSlug,
              updatedAt: payload.updatedAt,
              syncedAt: payload.syncedAt,
            });
            this.logger.debug(`Indexed artifact after ${operation}`, {
              type: payload.type,
              issueId: resolvedIssueId,
            });
          } catch (error) {
            this.logger.warn(`Failed to index artifact after ${operation}`, {
              type: payload.type,
              issueId: resolvedIssueId,
              error: error instanceof Error ? error.message : String(error),
            });
          }
        };
        // Create artifact indexing callbacks for automatic local indexing after artifact operations
        const streamContextOptions: StreamContextOptions = {
          onArtifactCreated: payload => handleArtifactIndexing(payload, "creation"),
          onArtifactUpdated: payload => handleArtifactIndexing(payload, "update"),
        };
        const streamContext = createToolStreamContext(writer, streamContextOptions);
        const mcpServersRaw = this.mcpServers ? this.mcpServers(streamContext, this.tools) : {};
        const mcpServers: Record<string, McpServerConfig | McpSdkServerConfigWithInstance> = {};
        for (const [serverName, serverConfig] of Object.entries(mcpServersRaw)) {
          mcpServers[serverName] = serverConfig;
        }

        const { useElectronRuntime } = resolveNodeExecutablePath();
        const env: Record<string, string> = {};

        if (process.env.PATH) {
          env.PATH = process.env.PATH;
        }

        if (useElectronRuntime) {
          env.ELECTRON_RUN_AS_NODE = "1";
          const electronBinDir = getElectronBinaryDirectory();
          if (electronBinDir) {
            env.PATH = addDirectoryToPath(env.PATH, electronBinDir);
          }
          const shimDir = ensureNodeOnPath(env.PATH);
          if (shimDir) {
            env.PATH = addDirectoryToPath(env.PATH, shimDir);
          }
        }

        // Inject Claude Code env settings from global settings
        const claudeCodeEnv = buildClaudeCodeEnvVars();
        Object.assign(env, claudeCodeEnv);

        const { executablePath: claudeExecutablePath } = detectClaudeCodeInstallation();

        const modelProvider = createClaudeCode({
          defaultSettings: {
            verbose: true,
            cwd: this.mainRepositoryPath,
            settingSources: ["user", "project"],
            systemPrompt: {
              type: "preset",
              preset: "claude_code",
              append: this.formatInstructions(systemWithClarifications),
            },
            ...(() => {
              const dirs = compact([...(this.additionalRepositoryPaths ?? []), this.issueDir]);
              return dirs.length > 0 ? { additionalDirectories: dirs } : {};
            })(),
            mcpServers,
            permissionMode: "bypassPermissions",
            disallowedTools: [...DISALLOWED_TOOLS],
            streamingInput: "always",
            includePartialMessages: true,
            env,
            ...(claudeExecutablePath && {
              pathToClaudeCodeExecutable: claudeExecutablePath,
            }),
            canUseTool: async (_toolName, input) => ({
              behavior: "allow",
              updatedInput: input,
            }),
            ...(subagents && { agents: subagents }),
            ...(this.config.hooks && {
              hooks: this.config.hooks as Partial<
                Record<
                  string,
                  Array<{
                    matcher?: string;
                    hooks: Array<(...args: unknown[]) => Promise<unknown>>;
                  }>
                >
              >,
            }),
            ...(this.reasoningEffort !== undefined && {
              maxThinkingTokens: REASONING_TOKEN_BUDGET[this.reasoningEffort],
            }),
          },
        });

        const modelMessages = await convertToModelMessages(messages);
        const result = streamText({
          ...(system !== undefined && { system }),
          abortSignal,
          messages: modelMessages,
          model: modelProvider(this.model, {
            ...(resumeSessionId !== undefined && { resume: resumeSessionId }),
          }),
          onAbort: ({ steps }) => {
            this.logger.info("Stream aborted after {stepsCount} steps", {
              stepsCount: steps.length,
              issueId: this.issueId,
              sessionType: this.sessionType,
            });
          },
        });

        this.extractSessionId(result, abortSignal);
        const uiMessageStream = result.toUIMessageStream({
          sendStart: false,
          sendReasoning: true,
          sendFinish: true,
          sendSources: true,
          messageMetadata: () => ({
            createdAt: Date.now(),
            claudeSessionId: this.claudeSessionId,
          }),
        });

        const normalizedStream = this.streamNormalizer.normalize(uiMessageStream);
        await this.processStreamWithIncrementalSaving(normalizedStream, writer, messages);
      },
      originalMessages: messages,
      onFinish: async ({ isAborted, messages: allMessages }) => {
        abortSignal?.removeEventListener("abort", abortCleanup);
        this.retryHandler?.reset();
        // If aborted, mark any tool calls with "input-streaming" state as "output-error"
        if (isAborted && allMessages.length > 0) {
          const lastMessage = allMessages[allMessages.length - 1];
          if (lastMessage && lastMessage.role === "assistant" && lastMessage.parts) {
            for (const part of lastMessage.parts) {
              if (isToolUIPart(part) && part.state === "input-streaming") {
                (part as ToolUIPart).state = "output-error";
                (part as ToolUIPart).errorText = "Tool call was aborted before completion";
              }
            }
          }
        }
        // Process interactive tool calls before saving to mark them as executed
        await this.saveMessages(allMessages);

        // Call cleanup callback if provided (e.g., to remove abort handler from registry)
        onStreamFinish?.();
      },
    });

    return createUIMessageStreamResponse({
      stream: uiStream,
      consumeSseStream: consumeStream,
    });
  }

  private buildExaMcpServer(
    tools: Tools<McpSdkServerConfigWithInstance>
  ): Record<string, McpSdkServerConfigWithInstance> {
    return {
      exa: createExaMcpServer(tools),
    };
  }

  private extractSessionId(result: StreamTextResult<any, never>, abortSignal?: AbortSignal) {
    if (!this.claudeSessionId) {
      Effect.runFork(
        Effect.promise(async () => {
          const response = await result.response;
          return response.id;
        }).pipe(
          Effect.tap(sessionId =>
            sessionId
              ? Effect.promise(async () => {
                  this.claudeSessionId = sessionId;
                  await this.sessionTracker.setClaudeSessionId(
                    this.issueId,
                    this.sessionType,
                    sessionId
                  );
                })
              : Effect.void
          ),
          Effect.catchAllCause(cause => {
            const wasAborted = abortSignal?.aborted ?? false;
            const errorMessage = cause.toString();
            const isNoOutputError =
              errorMessage.includes("NoOutputGeneratedError") ||
              errorMessage.includes("No output generated") ||
              errorMessage.includes("AI_NoOutputGeneratedError");

            if (!wasAborted && !isNoOutputError) {
              this.logger.error("Failed to capture Claude session ID from response: {cause}", {
                cause,
              });
            } else {
              this.logger.debug("Stream was aborted before session ID could be captured");
            }
            return Effect.void;
          })
        )
      );
    }
  }
}
