import { getLogger } from "@logtape/logtape";
import { z } from "zod";
import { PRDCreator } from "./agents/prd-creator";
import type { TasksCreatorOptions } from "./agents/tasks-creator";
import { TasksCreator } from "./agents/tasks-creator";
import type { TechspecCreatorOptions } from "./agents/techspec-creator";
import { TechspecCreator } from "./agents/techspec-creator";
import type { ReasoningEffort } from "./base-agent";

export type ArtifactAgent = PRDCreator | TechspecCreator | TasksCreator;

/**
 * Snapshot of a generated artifact (PRD, TechSpec, or Tasks) at a specific version.
 * Used to pass validated artifact content between agents during orchestration.
 */
export interface ArtifactSnapshot {
  /** Unique identifier for the artifact snapshot */
  id: string;
  /** Display title for the artifact (e.g., PRD or TechSpec title) */
  title: string;
  /** Local file path for the artifact markdown */
  filePath: string;
  /** Incrementing version number for this artifact */
  version: number;
  /** Optional issue identifier the artifact is associated with */
  issueId?: string | null;
  /** Optional PRD reference (used by TechSpec and Tasks artifacts) */
  prdId?: string | null;
}

type SharedOptions = {
  issueId: string;
  mainRepositoryPath: string;
  additionalRepositoryPaths?: string[];
  model?: "sonnet" | "opus" | "haiku";
  reasoningEffort?: ReasoningEffort;
};

export interface OrchestratorContext {
  sessionType: string;
  issueId: string;
  mainRepositoryPath: string;
  additionalRepositoryPaths?: string[];
  prdClarifications?: string;
  prdArtifact?: ArtifactSnapshot;
  techspecArtifact?: ArtifactSnapshot;
  model?: "sonnet" | "opus" | "haiku";
  reasoningEffort?: ReasoningEffort;
}

function createSharedOptions(context: OrchestratorContext): SharedOptions {
  return {
    issueId: context.issueId,
    mainRepositoryPath: context.mainRepositoryPath,
    ...(context.additionalRepositoryPaths !== undefined && {
      additionalRepositoryPaths: context.additionalRepositoryPaths,
    }),
    ...(context.model !== undefined && {
      model: context.model,
    }),
    ...(context.reasoningEffort !== undefined && {
      reasoningEffort: context.reasoningEffort,
    }),
  };
}

export class ClaudeArtifactOrchestrator {
  private logger = getLogger(["claudecode", "orchestrator"]);

  create(context: OrchestratorContext): ArtifactAgent {
    // Validate that issueId is a UUID to prevent worktree names or other invalid identifiers
    const validatedIssueId = z.string().uuid().parse(context.issueId);
    const validatedContext = { ...context, issueId: validatedIssueId };

    const sharedOptions = createSharedOptions(validatedContext);
    this.logger.debug("Creating artifact agent", { context: validatedContext });
    switch (validatedContext.sessionType) {
      case "techspec-creator":
        const techspecOptions: TechspecCreatorOptions = {
          ...sharedOptions,
          ...(validatedContext.prdClarifications !== undefined && {
            prdClarifications: validatedContext.prdClarifications,
          }),
          ...(validatedContext.prdArtifact !== undefined && {
            prdArtifact: validatedContext.prdArtifact,
          }),
        };

        return new TechspecCreator(techspecOptions);
      case "prd-creator":
        return new PRDCreator(sharedOptions);
      case "tasks-creator":
        if (validatedContext.techspecArtifact === undefined) {
          throw new Error("TechSpec artifact is required for tasks-creator agent");
        }
        const tasksCreatorOptions: TasksCreatorOptions = {
          ...sharedOptions,
          ...(validatedContext.prdArtifact !== undefined && {
            prdArtifact: validatedContext.prdArtifact,
          }),
          techspecArtifact: validatedContext.techspecArtifact,
        };

        return new TasksCreator(tasksCreatorOptions);
      default:
        throw new Error(`Unsupported session type: ${validatedContext.sessionType}`);
    }
  }
}
