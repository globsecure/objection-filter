import * as Sentry from "@sentry/node";

function getDsn(): string | undefined {
  return process.env.SENTRY_DSN || process.env.VITE_SENTRY_DSN || undefined;
}

function getIsDev(): boolean {
  return process.env.NODE_ENV !== "production";
}

function getEnvironment(): "development" | "production" {
  return getIsDev() ? "development" : "production";
}

/**
 * Get app version from environment variable (passed from Electron main process)
 * Falls back to "unknown" if not provided
 */
function getAppVersion(): string {
  // APP_VERSION is passed from Electron main process via environment variable
  // This works correctly in both development and production builds
  return process.env.APP_VERSION || "unknown";
}

/**
 * Sensitive data patterns to filter from Sentry events
 */
const SENSITIVE_HEADERS = new Set([
  "x-api-key",
  "authorization",
  "x-auth-token",
  "cookie",
  "set-cookie",
]);

const SENSITIVE_CONTEXT_KEYS = new Set([
  "apikey",
  "api_key",
  "token",
  "password",
  "secret",
  "authtoken",
  "auth_token",
  "bearer",
  "accesstoken",
  "access_token",
  "refreshtoken",
  "refresh_token",
]);

const SENSITIVE_ENV_PATTERNS = [/KEY/i, /TOKEN/i, /SECRET/i, /PASSWORD/i, /AUTH/i, /CREDENTIAL/i];

/**
 * Recursively filters sensitive data from an object
 */
function filterSensitiveObject(obj: unknown, depth = 0): unknown {
  // Prevent infinite recursion
  if (depth > 10) {
    return "[Max depth reached]";
  }

  if (obj === null || obj === undefined) {
    return obj;
  }

  if (typeof obj !== "object") {
    return obj;
  }

  if (Array.isArray(obj)) {
    return obj.map(item => filterSensitiveObject(item, depth + 1));
  }

  const filtered: Record<string, unknown> = {};

  for (const [key, value] of Object.entries(obj)) {
    const lowerKey = key.toLowerCase();

    // Skip sensitive context keys
    if (SENSITIVE_CONTEXT_KEYS.has(lowerKey)) {
      filtered[key] = "[Filtered]";
      continue;
    }

    // Skip sensitive environment variables
    if (SENSITIVE_ENV_PATTERNS.some(pattern => pattern.test(key))) {
      filtered[key] = "[Filtered]";
      continue;
    }

    // Recursively filter nested objects
    filtered[key] = filterSensitiveObject(value, depth + 1);
  }

  return filtered;
}

/**
 * Filters sensitive headers from request data
 */
function filterSensitiveHeaders(
  headers: Record<string, unknown> | undefined
): Record<string, unknown> | undefined {
  if (!headers || typeof headers !== "object") {
    return headers;
  }

  const filtered: Record<string, unknown> = {};

  for (const [key, value] of Object.entries(headers)) {
    const lowerKey = key.toLowerCase();
    if (SENSITIVE_HEADERS.has(lowerKey)) {
      filtered[key] = "[Filtered]";
    } else {
      filtered[key] = value;
    }
  }

  return filtered;
}

/**
 * Filters sensitive data from Sentry events before sending
 */
function filterSensitiveData(event: Sentry.ErrorEvent): Sentry.ErrorEvent | null {
  // Create a shallow copy to avoid mutating Sentry's original event object.
  const filtered: Sentry.ErrorEvent = { ...event };

  // Filter request headers
  if (filtered.request?.headers) {
    filtered.request = {
      ...filtered.request,
      headers: filterSensitiveHeaders(
        filtered.request.headers as Record<string, unknown>
      ) as Record<string, string>,
    };
  }

  // Filter extra context data
  if (filtered.extra) {
    filtered.extra = filterSensitiveObject(filtered.extra) as Record<string, unknown>;
  }

  // Filter tags
  if (filtered.tags) {
    filtered.tags = filterSensitiveObject(filtered.tags) as Record<string, string>;
  }

  // Filter user data
  if (filtered.user) {
    const filteredUser: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(filtered.user)) {
      const lowerKey = key.toLowerCase();
      if (SENSITIVE_CONTEXT_KEYS.has(lowerKey)) {
        filteredUser[key] = "[Filtered]";
      } else {
        filteredUser[key] = value;
      }
    }
    filtered.user = filteredUser as typeof filtered.user;
  }

  // Filter breadcrumbs
  if (filtered.breadcrumbs) {
    filtered.breadcrumbs = filtered.breadcrumbs.map(breadcrumb => {
      if (breadcrumb.data) {
        return {
          ...breadcrumb,
          data: filterSensitiveObject(breadcrumb.data) as Record<string, unknown>,
        };
      }
      return breadcrumb;
    });
  }

  return filtered;
}

/**
 * Initialize Sentry in the agent service
 * Should be called before any other initialization
 */
export function initAgentSentry(): void {
  const dsn = getDsn();
  if (!dsn) return;
  if (Sentry.isInitialized()) return;

  const isDev = getIsDev();
  const environment = getEnvironment();
  const release = getAppVersion();

  Sentry.init({
    dsn,
    debug: isDev,
    environment,
    release,
    tracesSampleRate: isDev ? 1.0 : 0.1, // 100% in dev, 10% in prod
    beforeSend(event) {
      // Only filter error events, other event types pass through unchanged
      // ErrorEvent has type === undefined, transaction events have type === 'transaction'
      if (event.type === undefined) {
        return filterSensitiveData(event);
      }
      return event;
    },
    integrations: [
      // Automatically instrument Node.js http/https modules
      Sentry.httpIntegration(),
    ],
  });

  // NOTE: Global process-level handlers are safe in a dedicated Node.js process,
  // but NOT safe when embedding the agent service inside Electron main (it would
  // affect the entire app process).
  //
  // Callers must opt in explicitly.
}

let globalHandlersInstalled = false;

export function installAgentGlobalErrorHandlers(): void {
  if (globalHandlersInstalled) {
    return;
  }
  globalHandlersInstalled = true;
  const isDev = getIsDev();
  setupGlobalErrorHandlers(isDev);
}

/**
 * Set up global error handlers for uncaught exceptions and unhandled rejections
 */
function setupGlobalErrorHandlers(isDev: boolean): void {
  // Handle uncaught exceptions
  process.on("uncaughtException", (error: Error) => {
    captureAgentException(error, {
      source: "uncaughtException",
      fatal: true,
    });
    // Log to console as well
    console.error("Uncaught exception:", error);
    if (!isDev) {
      // Uncaught exceptions mean the process is in an undefined state.
      // Flush Sentry (best-effort) before exiting so the event is not lost.
      void Sentry.close(2000)
        .then(() => {
          process.exit(1);
        })
        .catch(() => {
          process.exit(1);
        });
    }
  });

  // Handle unhandled promise rejections
  process.on("unhandledRejection", (reason: unknown, promise: Promise<unknown>) => {
    const error = reason instanceof Error ? reason : new Error(String(reason));
    captureAgentException(error, {
      source: "unhandledRejection",
      promiseType: promise?.constructor?.name ?? "Promise",
    });
    // Log to console as well
    console.error("Unhandled rejection:", reason);
  });
}

/**
 * Capture an exception in the agent service
 * @param error - The error to capture
 * @param context - Additional context to include with the error
 */
export function captureAgentException(error: unknown, context?: Record<string, unknown>): void {
  if (!getDsn()) return;
  if (!Sentry.isInitialized()) return;

  Sentry.captureException(error, context ? { extra: context } : undefined);
}

/**
 * Set user context for Sentry events
 * Call this when user authentication state changes
 */
export function setSentryUser(
  user: { id: string; email?: string; username?: string } | null
): void {
  if (!getDsn()) return;
  if (!Sentry.isInitialized()) return;

  Sentry.setUser(user);
}
