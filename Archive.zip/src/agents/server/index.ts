import { createLoggerConfig } from "@shared";
import { serve, type ServerType } from "@hono/node-server";
import { configure, getLogger } from "@logtape/logtape";
import { AsyncLocalStorage } from "node:async_hooks";
import { createAgentApp } from "./app";
import { createAgentServerConfig, type AgentServerConfig } from "./config/server-config";
import { initAgentSentry } from "./sentry";
import { createAgentUseCases } from "./modules/agents/usecases";

export type StartAgentServerOptions = {
  host: string;
  port: number;
  backendUrl: string;
  allowedOrigins?: readonly string[];
  /**
   * Configure LogTape sinks/categories for the agent service.
   *
   * When embedding inside Electron main, the host app usually configures the
   * process logger already. In that case, set this to false to avoid
   * "Already configured" failures from LogTape.
   *
   * @default true
   */
  configureLogger?: boolean;
};

export type AgentServerHandle = {
  config: AgentServerConfig;
  server: ServerType;
  close: () => Promise<void>;
};

export async function startAgentServer(
  options: StartAgentServerOptions
): Promise<AgentServerHandle> {
  let logger: ReturnType<typeof getLogger> | undefined;

  try {
    // Keep env vars in sync for any internal modules that still rely on serverConfig.* getters.
    // This is particularly important when embedding the server in Electron (no child-process env).
    process.env.BACKEND_URL = options.backendUrl;

    initAgentSentry();

    if (options.configureLogger ?? true) {
      await configure(
        createLoggerConfig({
          categories: [
            { category: ["agent-service"] },
            { category: ["agent-service", "http"], lowestLevel: "info" },
            { category: ["agent-service", "error"], lowestLevel: "error" },
            { category: ["prd-creator"] },
            { category: ["session-tracker"] },
            { category: ["repository-key-service"] },
            { category: ["mcp", "prd-client"] },
            { category: ["scripts", "index-codebase"] },
            { category: ["techspec-creator"] },
          ],
          contextLocalStorage: new AsyncLocalStorage(),
        })
      );
    }

    const config = createAgentServerConfig({
      host: options.host,
      port: options.port,
      backendUrl: options.backendUrl,
      ...(options.allowedOrigins ? { allowedOrigins: options.allowedOrigins } : {}),
    });

    process.env.AGENT_SERVER_URL = config.url;

    logger = getLogger(["agent-service"]);
    logger.info("Starting agent service (embedded)...", {
      host: config.host,
      port: config.port,
      allowedOrigins: config.allowedOrigins,
    });

    const agentUseCases = createAgentUseCases({ backendUrl: config.backendUrl });
    const app = createAgentApp({
      port: config.port,
      allowedOrigins: config.allowedOrigins,
      agentUseCases,
    });

    let resolveServerStarted: (() => void) | null = null;
    const serverStarted = new Promise<void>(resolve => {
      resolveServerStarted = resolve;
    });

    const server = serve(
      {
        fetch: app.fetch,
        port: config.port,
        hostname: config.host,
      },
      info => {
        logger?.info("Agent service listening", { address: info.address, port: info.port });
        resolveServerStarted?.();
      }
    );

    await serverStarted;

    return {
      config,
      server,
      close: async () => {
        logger?.info("Shutting down agent service...");
        return new Promise<void>((resolve, reject) => {
          server.close(error => {
            if (error) {
              logger?.error("Error closing server", { error });
              reject(error);
              return;
            }
            logger?.info("Agent service shut down complete");
            resolve();
          });
        });
      },
    };
  } catch (error) {
    logger?.error("Failed to start agent service", { error });
    throw error;
  }
}
