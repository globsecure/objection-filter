import { createCorsMiddleware, createHostValidationMiddleware } from "@shared/security";
import { OpenAPIHono, createRoute } from "@hono/zod-openapi";
import { getLogger, withContext } from "@logtape/logtape";
import { HTTPException } from "hono/http-exception";
import { generateRequestId } from "./lib/request-id";
import { getCurrentTimestamp } from "./lib/timestamp";
import { healthResponseSchema } from "./modules/agents/models";
import { createAgentsModule } from "./modules/agents/route";
import type { AgentUseCasesApi } from "./modules/agents/usecases";
import { captureAgentException } from "./sentry";

type Variables = {
  requestId: string;
};

export type CreateAgentAppOptions = {
  port: number;
  allowedOrigins: readonly string[];
  agentUseCases: AgentUseCasesApi;
};

export function createAgentApp(
  options: CreateAgentAppOptions
): OpenAPIHono<{ Variables: Variables }> {
  const app = new OpenAPIHono<{ Variables: Variables }>();
  const httpLogger = getLogger(["agent-service", "http"]);
  const errorLogger = getLogger(["agent-service", "error"]);

  app.use("/*", createHostValidationMiddleware(options.port));
  app.use("/*", createCorsMiddleware(Array.from(options.allowedOrigins)));

  app.use("/*", async (c, next) => {
    const start = Date.now();
    // Generate or read request ID for distributed tracing
    const requestId = c.req.header("X-Request-ID") || generateRequestId();

    // Store in context for downstream handlers
    c.set("requestId", requestId);

    // Add to response headers
    c.header("X-Request-ID", requestId);

    // Set request context for all subsequent logs in this request
    await withContext(
      {
        requestId,
        method: c.req.method,
        path: c.req.path,
        url: c.req.url,
        userAgent: c.req.header("User-Agent"),
      },
      async () => {
        httpLogger.info("{method} {path}", {
          method: c.req.method,
          path: c.req.path,
        });

        await next();

        const elapsed = Date.now() - start;
        const status = c.res.status;
        httpLogger.info("{method} {path} - {status} ({elapsed}ms)", {
          method: c.req.method,
          path: c.req.path,
          status,
          elapsed,
        });
      }
    );
  });

  const healthRoute = createRoute({
    method: "get",
    path: "/health",
    responses: {
      200: {
        content: {
          "application/json": {
            schema: healthResponseSchema,
          },
        },
        description: "Service health status",
      },
    },
  });

  app.openapi(healthRoute, c => {
    return c.json({ status: "ok", service: "agent-service" });
  });

  app.route(
    "/api/v1",
    createAgentsModule({
      agentUseCases: options.agentUseCases,
    })
  );

  app.onError((err, c) => {
    const timestamp = getCurrentTimestamp();
    const errorId = generateRequestId();

    if (err instanceof HTTPException) {
      errorLogger.error("HTTP error", {
        error: {
          name: err.name,
          message: err.message,
          stack: err.stack,
        },
        method: c.req.method,
        path: c.req.path,
        status: err.status,
        errorId,
      });
      // Only capture 5xx errors in Sentry (client errors are expected)
      if (err.status >= 500) {
        captureAgentException(err, {
          source: "http_error",
          method: c.req.method,
          path: c.req.path,
          status: err.status,
          errorId,
        });
      }
      return c.json(
        {
          error: {
            code: `HTTP_${err.status}`,
            message: err.message,
          },
          errorId,
          timestamp,
          path: c.req.path,
        },
        err.status
      );
    }

    // Generic error handling
    errorLogger.error("Request error", {
      error: {
        name: err instanceof Error ? err.name : "Unknown",
        message: err instanceof Error ? err.message : String(err),
        stack: err instanceof Error ? err.stack : undefined,
      },
      method: c.req.method,
      path: c.req.path,
      errorId,
    });

    // Capture all non-HTTP errors in Sentry
    captureAgentException(err, {
      source: "request_error",
      method: c.req.method,
      path: c.req.path,
      errorId,
    });

    return c.json(
      {
        error: {
          code: "INTERNAL_ERROR",
          message: err instanceof Error ? err.message : "Internal server error",
        },
        errorId,
        timestamp,
        path: c.req.path,
      },
      500
    );
  });

  return app;
}
