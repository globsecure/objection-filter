import { getLogger } from "@logtape/logtape";
import { serverConfig } from "./config/server-config";
import { startAgentServer } from "./index";
import { installAgentGlobalErrorHandlers } from "./sentry";

async function main(): Promise<void> {
  const logger = getLogger(["agent-service", "cli"]);

  const handle = await startAgentServer({
    host: serverConfig.host,
    port: serverConfig.port,
    backendUrl: serverConfig.backendUrl,
    allowedOrigins: serverConfig.allowedOrigins,
  });
  installAgentGlobalErrorHandlers();

  const shutdown = async (signal: "SIGINT" | "SIGTERM") => {
    logger.info("Shutting down agent service...", { signal });
    try {
      await handle.close();
      logger.info("Agent service shut down successfully");
      process.exit(0);
    } catch (error) {
      logger.error("Error during shutdown", { error });
      process.exit(1);
    }
  };

  process.on("SIGINT", () => {
    shutdown("SIGINT").catch(error => {
      logger.error("Error handling SIGINT", { error });
      process.exit(1);
    });
  });
  process.on("SIGTERM", () => {
    shutdown("SIGTERM").catch(error => {
      logger.error("Error handling SIGTERM", { error });
      process.exit(1);
    });
  });
}

void main().catch(error => {
  // eslint-disable-next-line no-console
  console.error("[agent-service] fatal error starting server", error);
  process.exit(1);
});
