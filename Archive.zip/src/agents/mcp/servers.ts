import { type McpSdkServerConfigWithInstance } from "@compozy/provider-claude-code";
import { ApiClient } from "./tools/core/api-client";
import type { Tools, ToolStreamContext } from "@compozy/types";
import { createApproachesTools } from "./tools/approaches/operations";
import { TOOL_MIN_APPROACHES } from "./tools/approaches/schemas";
import { createPrdTools, createListPrdsTool, createGetPrdTool } from "./tools/prd/operations";
import {
  createTechspecTools,
  createListTechspecsTool,
  createGetTechspecTool,
} from "./tools/techspec/operations";
import { createTasksTools } from "./tools/tasks/operations";
import { createClarificationTools } from "./tools/clarification/operations";
import { createExaTools } from "./tools/exa/operations";
import { createArtifactTools } from "./tools/artifact/operations";
import type { BrainstormSettings } from "../../shared/global-settings";

export type McpServerName = "prd" | "techspec" | "tasks" | "exa" | "artifact";

export function createPrdMcpServer(
  tools: Tools<McpSdkServerConfigWithInstance>,
  apiClient: ApiClient,
  issueId: string,
  streamContext: ToolStreamContext | undefined,
  brainstormSettings: BrainstormSettings
): McpSdkServerConfigWithInstance {
  const minApproaches = TOOL_MIN_APPROACHES;
  const maxApproaches = brainstormSettings.approachCount;
  const toolDefinitions = [
    ...createPrdTools(apiClient, issueId, streamContext),
    ...createClarificationTools("prd", 1, 10, streamContext),
    ...createApproachesTools("prd", minApproaches, maxApproaches, streamContext),
  ];
  return tools.createTools(toolDefinitions, { name: "prd", version: "1.0.0" });
}

export function createTechspecMcpServer(
  tools: Tools<McpSdkServerConfigWithInstance>,
  apiClient: ApiClient,
  issueId: string,
  streamContext: ToolStreamContext | undefined,
  brainstormSettings: BrainstormSettings
): McpSdkServerConfigWithInstance {
  const minApproaches = TOOL_MIN_APPROACHES;
  const maxApproaches = brainstormSettings.approachCount;
  const toolDefinitions = [
    ...createTechspecTools(apiClient, issueId, streamContext),
    ...createClarificationTools("techspec", 1, 10, streamContext),
    ...createApproachesTools("techspec", minApproaches, maxApproaches, streamContext),
  ];
  return tools.createTools(toolDefinitions, { name: "techspec", version: "1.0.0" });
}

export function createTasksMcpServer(
  tools: Tools<McpSdkServerConfigWithInstance>,
  apiClient: ApiClient,
  issueId: string,
  streamContext?: ToolStreamContext
): McpSdkServerConfigWithInstance {
  const toolDefinitions = createTasksTools(apiClient, issueId, streamContext);
  return tools.createTools(toolDefinitions, { name: "tasks", version: "1.0.0" });
}

export function createExaMcpServer(
  tools: Tools<McpSdkServerConfigWithInstance>
): McpSdkServerConfigWithInstance {
  const toolDefinitions = createExaTools();
  return tools.createTools(toolDefinitions, { name: "exa", version: "1.0.0" });
}

export function createArtifactMcpServer(
  tools: Tools<McpSdkServerConfigWithInstance>,
  issueId: string
): McpSdkServerConfigWithInstance {
  const toolDefinitions = createArtifactTools(issueId);
  return tools.createTools(toolDefinitions, { name: "artifact", version: "1.0.0" });
}

/**
 * Creates a read-only PRD MCP server with only list/get tools (no create/update).
 * Used by TechspecCreator and TasksCreator to access PRD artifacts.
 */
export function createReadOnlyPrdMcpServer(
  tools: Tools<McpSdkServerConfigWithInstance>,
  apiClient: ApiClient,
  issueId?: string
): McpSdkServerConfigWithInstance {
  const toolDefinitions = [createListPrdsTool(apiClient, issueId), createGetPrdTool(apiClient)];
  return tools.createTools(toolDefinitions, { name: "prd", version: "1.0.0" });
}

/**
 * Creates a read-only Techspec MCP server with only list/get tools (no create/update).
 * Used by TasksCreator to access Techspec artifacts.
 */
export function createReadOnlyTechspecMcpServer(
  tools: Tools<McpSdkServerConfigWithInstance>,
  apiClient: ApiClient,
  issueId?: string
): McpSdkServerConfigWithInstance {
  const toolDefinitions = [
    createListTechspecsTool(apiClient, issueId),
    createGetTechspecTool(apiClient),
  ];
  return tools.createTools(toolDefinitions, { name: "techspec", version: "1.0.0" });
}
