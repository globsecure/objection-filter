import { is } from "@electron-toolkit/utils";
import { startAgentServer } from "../../agents/server";
import type { AgentServerHandle, StartAgentServerOptions } from "../../agents/server";
import { appConfig } from "../config/app-config";
import { waitForBackend } from "../utils/network";
import { captureMainException } from "../utils/sentry";
import { getLogger } from "@logtape/logtape";

const logger = getLogger(["frontend", "main", "agent-server"]);
type ElectronApp = {
  getAppPath(): string;
  getVersion(): string;
  isPackaged: boolean;
};

type AgentServiceDeps = {
  app: ElectronApp;
  waitForBackend?: typeof waitForBackend;
  backendUrl?: string;
  agentEventsUrl?: string;
  host?: string;
  port?: number;
  allowedOrigins?: readonly string[];
  getAppVersion?: () => string;
};

let agentServer: AgentServerHandle | null = null;

export async function startAgentService(deps: AgentServiceDeps): Promise<void> {
  if (agentServer) {
    return;
  }
  if (!deps.app) {
    throw new Error("startAgentService requires an Electron app instance");
  }
  const appInstance = deps.app;
  const waitForBackendFn = deps.waitForBackend ?? waitForBackend;
  const getAppVersionFn = deps.getAppVersion ?? (() => appInstance.getVersion());

  const inheritedNodeEnv = process.env.NODE_ENV;
  const nodeEnv =
    inheritedNodeEnv === "test"
      ? is.dev
        ? "development"
        : "production"
      : (inheritedNodeEnv ?? (is.dev ? "development" : "production"));

  // Keep agent-service-specific env vars aligned without changing Electron's NODE_ENV.
  // This preserves prior behavior where the child process could have its own NODE_ENV value.
  process.env.AGENT_EVENTS_URL = deps.agentEventsUrl ?? appConfig.agentEventsServer.url;
  process.env.DEV_MODE = is.dev ? "true" : "false";
  process.env.APP_VERSION = getAppVersionFn();

  // Propagate Sentry DSN to environment if available and not already set
  process.env.SENTRY_DSN ??= import.meta.env.VITE_SENTRY_DSN;
  process.env.VITE_SENTRY_DSN ??= import.meta.env.VITE_SENTRY_DSN;

  const host = deps.host ?? appConfig.agents.host;
  const port = deps.port ?? appConfig.agents.port;
  const backendUrl = deps.backendUrl ?? appConfig.backendProxy.url;

  logger.info("Starting agent service", {
    host,
    port,
    backendUrl,
    agentEventsUrl: deps.agentEventsUrl ?? appConfig.agentEventsServer.url,
  });

  try {
    const options: StartAgentServerOptions = {
      host,
      port,
      backendUrl,
      ...(deps.allowedOrigins ? { allowedOrigins: deps.allowedOrigins } : {}),
      configureLogger: false,
    };

    // Ensure any internal env-based config reads the right defaults (legacy compatibility).
    process.env.NODE_ENV ??= nodeEnv;

    agentServer = await startAgentServer(options);
    logger.info("Agent server started successfully", { host, port, backendUrl });
  } catch (error: unknown) {
    captureMainException(error, { service: "agents", phase: "start" });
    agentServer = null;
    throw error instanceof Error
      ? error
      : new Error(`[agents] failed to start embedded server: ${String(error)}`);
  }

  await waitForBackendFn({
    port,
    host,
    retries: is.dev
      ? appConfig.agents.healthCheck.retriesInDev
      : appConfig.agents.healthCheck.retriesInProd,
    delayMs: appConfig.agents.healthCheck.delayMs,
  });
}

export async function stopAgentService(): Promise<void> {
  if (!agentServer) {
    return;
  }
  const serverToClose = agentServer;
  agentServer = null;

  try {
    await serverToClose.close();
  } catch (error) {
    captureMainException(error, { service: "agents", phase: "shutdown" });
    console.error("[agents] failed to stop embedded server", error);
  }
}
