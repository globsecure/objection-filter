import { is } from "@electron-toolkit/utils";
import { getLogger } from "@logtape/logtape";
import { asIpcErrorResponse } from "@shared/ipc-client";
import type { IpcResponse } from "@shared/ipc-types";
import { createIpcSuccess } from "@shared/ipc-utils";
import type { BrowserWindow, IpcMain } from "electron";
import { app } from "electron";
import { autoUpdater } from "electron-updater";
import { gt } from "semver";
import type { UpdateInfo, UpdateProgress } from "../../shared/update-types";
import {
  areDevUpdatesEnabled,
  DEV_HINT_CHECK,
  DEV_HINT_DOWNLOAD,
  formatUpdaterError,
  isUpdater404Error,
  isUpdaterDevMode,
  sanitizeUpdaterLogArgs,
} from "./auto-updater-utils";

const logger = getLogger(["frontend", "auto-updater"]);

// Re-export types for convenience
export type { UpdateError, UpdateInfo, UpdateProgress } from "../../shared/update-types";

export interface AutoUpdaterService {
  checkForUpdates: () => Promise<void>;
  quitAndInstall: () => void;
  dispose: () => void;
}

// Module-level state for init-once guard
let isInitialized = false;
let serviceInstance: AutoUpdaterService | null = null;

/**
 * Sends a message to the renderer process via the window's webContents.
 * Includes defensive checks for both window and webContents destruction.
 */
function sendToRenderer(
  getWindow: () => BrowserWindow | null,
  channel: string,
  data?: unknown
): void {
  const window = getWindow();
  if (window && !window.isDestroyed() && !window.webContents.isDestroyed()) {
    window.webContents.send(channel, data);
  }
}

/**
 * Initializes the auto-updater service.
 *
 * @param getWindow - A getter function that returns the current main window.
 *                    Using a getter ensures the auto-updater always references
 *                    the current window, even after window recreation on macOS.
 * @param ipcMain - The Electron IpcMain instance for registering handlers.
 * @returns An AutoUpdaterService with methods to check for updates, install, and dispose.
 */
export function initializeAutoUpdater(
  getWindow: () => BrowserWindow | null,
  ipcMain: IpcMain
): AutoUpdaterService {
  // Guard against double-initialization
  if (isInitialized) {
    logger.warn("Auto-updater already initialized, returning existing service");
    return serviceInstance!;
  }

  isInitialized = true;

  const isDevMode = isUpdaterDevMode({
    isPackaged: app.isPackaged,
    nodeEnv: process.env.NODE_ENV,
  });
  const devUpdatesEnabled = areDevUpdatesEnabled(process.env);

  const sanitizeProperties = (
    properties?: Record<string, unknown> | (() => Record<string, unknown>)
  ): Record<string, unknown> | (() => Record<string, unknown>) | undefined => {
    if (!properties) return undefined;

    if (typeof properties === "function") {
      return () => {
        const next = properties();
        const sanitized = sanitizeUpdaterLogArgs([next])[0];
        return (sanitized ?? next) as Record<string, unknown>;
      };
    }

    const sanitized = sanitizeUpdaterLogArgs([properties])[0];
    return (sanitized ?? properties) as Record<string, unknown>;
  };

  const log = {
    debug: (
      message: string,
      properties?: Record<string, unknown> | (() => Record<string, unknown>)
    ) => logger.debug(message, sanitizeProperties(properties)),
    info: (
      message: string,
      properties?: Record<string, unknown> | (() => Record<string, unknown>)
    ) => logger.info(message, sanitizeProperties(properties)),
    warn: (
      message: string,
      properties?: Record<string, unknown> | (() => Record<string, unknown>)
    ) => logger.warn(message, sanitizeProperties(properties)),
    error: (
      message: string,
      properties?: Record<string, unknown> | (() => Record<string, unknown>)
    ) => logger.error(message, sanitizeProperties(properties)),
  };

  // Configure auto-updater
  autoUpdater.autoDownload = true;
  autoUpdater.autoInstallOnAppQuit = true;

  // In development, use dev-app-update.yml for testing
  if (is.dev) {
    autoUpdater.forceDevUpdateConfig = true;
    log.info("Auto-updater running in development mode");
  } else {
    // Configure R2 feed URL for production
    // Map platform to electron-builder path format
    const platformMap: Record<string, string> = {
      darwin: "mac",
      linux: "linux",
      win32: "win",
    };
    const platform = platformMap[process.platform];

    if (!platform) {
      log.warn(
        `Auto-updater: Unsupported platform "${process.platform}". Only macOS (darwin), Windows (win32), and Linux are supported. Update checks will be disabled.`
      );
      // Continue initialization to register IPC handlers, but updates won't work
    } else {
      // Map arch to electron-builder format
      const defaultArch = process.arch === "arm64" ? "arm64" : "x64";
      let arch = defaultArch;

      if (platform === "mac") {
        const override = process.env.UPDATE_FEED_MAC_ARCH?.toLowerCase();
        if (override) {
          if (override === "arm64" || override === "x64" || override === "universal") {
            arch = override;
          } else {
            log.warn("Auto-updater: Invalid UPDATE_FEED_MAC_ARCH override", { override });
          }
        }
      }

      // Construct R2 feed URL
      // Format: https://pub-{public-url-id}.r2.dev/{platform}/{arch}/
      // Note: r2.dev is for public access, r2.cloudflarestorage.com is for S3 API only
      // R2_PUBLIC_URL_ID (from bucket settings) is different from R2_ACCOUNT_ID (for S3 API)
      // IMPORTANT: The bucket name is NOT included in the path - the Public Development URL is already scoped to the bucket
      // The feed URL must point to a directory containing the manifest file:
      // - macOS: latest-mac.yml
      // - Windows: latest.yml
      // - Linux: latest-linux.yml or latest.yml
      const r2PublicUrlId = process.env.R2_PUBLIC_URL_ID || process.env.R2_ACCOUNT_ID;
      const r2BaseUrl =
        process.env.UPDATE_FEED_URL ||
        (r2PublicUrlId ? `https://pub-${r2PublicUrlId}.r2.dev` : null);

      if (!r2BaseUrl) {
        log.warn(
          "Auto-updater: R2_ACCOUNT_ID must be set or UPDATE_FEED_URL must be configured for production updates. Update checks will be disabled."
        );
        // Continue initialization to register IPC handlers, but updates won't work
      } else {
        // Ensure base URL doesn't have trailing slash (we'll add it with the path)
        const baseUrl = r2BaseUrl.replace(/\/$/, "");
        const feedPath = `${platform}/${arch}`;
        const feedUrl = `${baseUrl}/${feedPath}/`;

        // Set feed URL for generic provider (R2)
        // electron-updater's generic provider expects the URL to point to a directory
        // containing the platform-specific manifest file (latest-mac.yml or latest-linux.yml)
        autoUpdater.setFeedURL({
          provider: "generic",
          url: feedUrl,
        });

        log.info("Auto-updater configured for R2", {
          platform,
          arch,
          feedUrl: feedUrl.replace(/https?:\/\//, "[REDACTED]://"), // Redact URL in logs
        });
      }
    }
  }

  if (isDevMode && !devUpdatesEnabled) {
    log.debug("Auto-updater disabled in development mode", { hint: DEV_HINT_CHECK });
  }

  // Event: Checking for updates
  autoUpdater.on("checking-for-update", () => {
    log.info("Checking for updates...");
    sendToRenderer(getWindow, "update:checking");
  });

  // Event: Update available
  autoUpdater.on("update-available", info => {
    const currentVersion = app.getVersion();
    const updateVersion = info.version;

    // Validate that the update version is actually newer than the current version
    // This prevents false positive notifications when versions match or update is older
    if (!gt(updateVersion, currentVersion)) {
      log.debug("Update version is not newer than current version, ignoring", {
        currentVersion,
        updateVersion,
      });
      return;
    }

    log.info("Update available", { version: updateVersion, currentVersion });
    sendToRenderer(getWindow, "update:available", {
      version: updateVersion,
      releaseDate: info.releaseDate,
      releaseNotes:
        typeof info.releaseNotes === "string"
          ? info.releaseNotes
          : Array.isArray(info.releaseNotes)
            ? info.releaseNotes.map(n => n.note).join("\n")
            : undefined,
    } satisfies UpdateInfo);
  });

  // Event: No update available
  autoUpdater.on("update-not-available", info => {
    log.info("No update available", { currentVersion: info.version });
    sendToRenderer(getWindow, "update:not-available", {
      version: info.version,
    });
  });

  // Event: Download progress
  autoUpdater.on("download-progress", progress => {
    log.debug("Download progress", {
      percent: progress.percent.toFixed(2),
      transferred: progress.transferred,
      total: progress.total,
    });
    sendToRenderer(getWindow, "update:download-progress", {
      percent: progress.percent,
      bytesPerSecond: progress.bytesPerSecond,
      transferred: progress.transferred,
      total: progress.total,
    } satisfies UpdateProgress);
  });

  // Event: Update downloaded
  autoUpdater.on("update-downloaded", info => {
    log.info("Update downloaded", { version: info.version });
    sendToRenderer(getWindow, "update:downloaded", {
      version: info.version,
      releaseDate: info.releaseDate,
    });
  });

  // Event: Error
  autoUpdater.on("error", error => {
    // 404 errors are expected when the repository doesn't exist, has no releases,
    // or is private and requires authentication. Suppress these errors in both
    // development and production to avoid noise and breaking the app.
    if (isUpdater404Error(error)) {
      log.debug("Auto-updater: No update server found (expected when no releases exist)", {
        message: error.message,
      });
      // Don't send error event to renderer for expected 404s
      return;
    }

    const message = formatUpdaterError(error);

    log.error("Auto-updater error", {
      message,
      stack: error.stack,
    });
    sendToRenderer(getWindow, "update:error", {
      message,
    });
  });

  // IPC handler: Manual check for updates
  ipcMain.handle(
    "update:check",
    async (): Promise<
      IpcResponse<{
        updateAvailable: boolean;
        version?: string;
        devDisabled?: boolean;
        devHint?: string;
      }>
    > => {
      log.info("Manual update check requested");

      if (isDevMode && !devUpdatesEnabled) {
        return asIpcErrorResponse(DEV_HINT_CHECK, "IPC_UPDATE_DEV_MODE_DISABLED");
      }

      try {
        const result = await autoUpdater.checkForUpdates();
        const updateInfo = result?.updateInfo;
        const updateVersion = updateInfo?.version;
        const currentVersion = app.getVersion();

        const updateAvailable =
          typeof result?.isUpdateAvailable === "boolean"
            ? result.isUpdateAvailable
            : typeof updateVersion === "string"
              ? gt(updateVersion, currentVersion)
              : false;

        if (updateVersion && !updateAvailable) {
          log.debug("Update check returned a non-newer version, ignoring", {
            currentVersion,
            updateVersion,
          });
        }

        return createIpcSuccess({
          updateAvailable,
          version: updateAvailable ? updateVersion : undefined,
        });
      } catch (error) {
        const baseError = error instanceof Error ? error : new Error(String(error));

        // Common case: GitHub feed returns 404 when no releases exist, repository is private,
        // or requires authentication. Suppress these errors in both development and production
        // to avoid noise and breaking the app.
        if (isUpdater404Error(error)) {
          log.debug("Update check failed (expected when no releases exist)", {
            error: baseError.message,
          });
          // Don't send error event to renderer for expected 404s
          return createIpcSuccess({ updateAvailable: false });
        }

        // For non-404 errors, log as warning and notify renderer
        const message = formatUpdaterError(baseError);
        log.warn("Failed to check for updates", { error: message });
        sendToRenderer(getWindow, "update:error", { message });
        return asIpcErrorResponse(message, "IPC_UPDATE_CHECK_FAILED");
      }
    }
  );

  // IPC handler: Install update and restart
  ipcMain.handle("update:install-and-restart", (): IpcResponse<null> => {
    try {
      if (isDevMode && !devUpdatesEnabled) {
        return asIpcErrorResponse(DEV_HINT_DOWNLOAD, "IPC_UPDATE_DEV_MODE_DISABLED");
      }

      log.info("Installing update and restarting...");
      setImmediate(() => autoUpdater.quitAndInstall());
      return createIpcSuccess(null);
    } catch (error: unknown) {
      return asIpcErrorResponse(error, "IPC_UPDATE_INSTALL_AND_RESTART_FAILED");
    }
  });

  // IPC handler: Get current update status
  ipcMain.handle(
    "update:get-status",
    (): IpcResponse<{ autoDownload: boolean; autoInstallOnAppQuit: boolean }> => {
      try {
        return createIpcSuccess({
          autoDownload: autoUpdater.autoDownload,
          autoInstallOnAppQuit: autoUpdater.autoInstallOnAppQuit,
        });
      } catch (error: unknown) {
        return asIpcErrorResponse(error, "IPC_UPDATE_GET_STATUS_FAILED");
      }
    }
  );

  serviceInstance = createService();
  return serviceInstance;
}

/**
 * Creates the service object with methods to interact with the auto-updater.
 */
function createService(): AutoUpdaterService {
  return {
    checkForUpdates: async () => {
      const isDevMode = isUpdaterDevMode({
        isPackaged: app.isPackaged,
        nodeEnv: process.env.NODE_ENV,
      });
      const devUpdatesEnabled = areDevUpdatesEnabled(process.env);

      if (isDevMode && !devUpdatesEnabled) {
        logger.debug("Skipping auto-update check in development mode", { hint: DEV_HINT_CHECK });
        return;
      }

      await autoUpdater.checkForUpdatesAndNotify();
    },
    quitAndInstall: () => {
      autoUpdater.quitAndInstall();
    },
    dispose: () => {
      disposeAutoUpdater();
    },
  };
}

/**
 * Disposes the auto-updater by removing all listeners and IPC handlers.
 * Call this before reinitializing or during app cleanup.
 */
function disposeAutoUpdater(): void {
  if (!isInitialized) {
    return;
  }

  logger.info("Disposing auto-updater service");

  // Remove all autoUpdater event listeners
  autoUpdater.removeAllListeners();

  // Note: isInitialized remains true to prevent reinitialization.
  // IPC handlers cannot be safely removed, so the app must be restarted
  // for full cleanup. This is acceptable for production usage.
  serviceInstance = null;
}
