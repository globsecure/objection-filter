import { getLogger } from "@logtape/logtape";
import { app, nativeImage } from "electron";
import { existsSync } from "fs";

const logger = getLogger(["frontend", "main", "mac-dock-icon"]);

export class MacDockIconService {
  private readonly iconPath: string;

  constructor(iconPath: string) {
    this.iconPath = iconPath;
  }

  private getMacIconPath(): string | null {
    if (process.platform !== "darwin") {
      return null;
    }

    const iconPath = this.iconPath;
    if (!existsSync(iconPath)) {
      logger.warn("Icon file does not exist", { iconPath });
      return null;
    }

    return iconPath;
  }

  setDockIcon(): void {
    if (process.platform !== "darwin") {
      return;
    }

    try {
      if (!app.dock) {
        logger.warn("app.dock is not available");
        return;
      }

      const iconPath = this.getMacIconPath();
      if (!iconPath) {
        logger.warn("Could not resolve macOS icon path");
        return;
      }

      const icon = nativeImage.createFromPath(iconPath);
      if (icon.isEmpty()) {
        logger.warn("Failed to create icon from path - icon is empty", { iconPath });
        return;
      }

      app.dock.setIcon(icon);
      logger.info("Successfully set macOS dock icon", { iconPath });
    } catch (error) {
      logger.error("Failed to set macOS dock icon", { error, iconPath: this.iconPath });
    }
  }
}
