import { asIpcErrorResponse } from "@shared/ipc-client";
import type { IpcResponse } from "@shared/ipc-types";
import { createIpcSuccess } from "@shared/ipc-utils";
import { getLogger } from "@logtape/logtape";
import type { BrowserWindow, IpcMain } from "electron";
import type { Disposable } from "./disposable";
import type { DeepLinkService } from "./deep-link-handler";

const logger = getLogger(["frontend", "main", "deep-link-ipc"]);

export interface DeepLinkIpcServiceOptions {
  deepLinkService: DeepLinkService;
  ipcMain: IpcMain;
  getMainWindow: () => BrowserWindow | null;
}

export class DeepLinkIpcService implements Disposable {
  private readonly deepLinkService: DeepLinkService;
  private readonly ipcMain: IpcMain;
  private readonly getMainWindow: () => BrowserWindow | null;

  constructor(options: DeepLinkIpcServiceOptions) {
    this.deepLinkService = options.deepLinkService;
    this.ipcMain = options.ipcMain;
    this.getMainWindow = options.getMainWindow;
    this.registerHandlers();
  }

  dispose(): void {
    this.unregisterHandlers();
  }

  private unregisterHandlers(): void {
    const ipcMainWithRemoveHandler = this.ipcMain as unknown as {
      removeHandler?: (channel: string) => void;
    };
    ipcMainWithRemoveHandler.removeHandler?.("deep-link:get-pending-api-key");
    ipcMainWithRemoveHandler.removeHandler?.("deep-link:ack-api-key");
  }

  private isTrustedSender(event: Electron.IpcMainInvokeEvent): boolean {
    const mainWindow = this.getMainWindow();
    if (!mainWindow) {
      return false;
    }

    return event.sender.id === mainWindow.webContents.id;
  }

  private registerHandlers(): void {
    this.unregisterHandlers();

    this.ipcMain.handle(
      "deep-link:get-pending-api-key",
      async (event): Promise<IpcResponse<{ apiKey: string | null }>> => {
        if (!this.isTrustedSender(event)) {
          logger.warn("Rejected deep link pending API key request from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        return createIpcSuccess({ apiKey: this.deepLinkService.getPendingApiKey() });
      }
    );

    this.ipcMain.handle(
      "deep-link:ack-api-key",
      async (event, apiKey?: unknown): Promise<IpcResponse<null>> => {
        if (!this.isTrustedSender(event)) {
          logger.warn("Rejected deep link ack request from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        const pending = this.deepLinkService.getPendingApiKey();
        if (typeof apiKey === "string" && pending && apiKey !== pending) {
          logger.warn("Rejected deep link ack due to API key mismatch", {
            pendingLength: pending.length,
          });
          return asIpcErrorResponse("Pending API key mismatch", "IPC_DEEPLINK_KEY_MISMATCH");
        }

        this.deepLinkService.clearPendingApiKey();
        return createIpcSuccess(null);
      }
    );

    logger.info("Deep link IPC handlers registered");
  }
}
