import { once } from "node:events";
import http, { type IncomingMessage, type ServerResponse } from "node:http";

import {
  API_KEY_HEADER,
  TRUSTED_ORIGINS,
  createCorsHandler,
  createHostValidationHandler,
} from "@shared/security";
import { getLogger } from "@logtape/logtape";
import { trim } from "es-toolkit/string";

const logger = getLogger(["frontend", "main", "backend-proxy"]);

class PayloadTooLargeError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PayloadTooLargeError";
  }
}

const HOP_BY_HOP_HEADERS = new Set([
  "connection",
  "keep-alive",
  "proxy-authenticate",
  "proxy-authorization",
  "te",
  "trailer",
  "transfer-encoding",
  "upgrade",
]);

type UpstreamFetch = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;

export interface BackendProxyServiceOptions {
  port: number;
  backendBaseUrl: string;
  allowedOrigins?: string[];
  upstreamTimeoutMs?: number;
  maxBodyBytes?: number;
  fetchUpstream: UpstreamFetch;
  getApiKey: () => Promise<string | null>;
}

export class BackendProxyService {
  private readonly port: number;
  private readonly backendBaseUrl: string;
  private readonly allowedOrigins: string[];
  private readonly upstreamTimeoutMs: number;
  private readonly maxBodyBytes: number;
  private readonly fetchUpstream: UpstreamFetch;
  private readonly getApiKey: () => Promise<string | null>;

  private server: http.Server | null = null;
  private hasDisposed = false;

  constructor(options: BackendProxyServiceOptions) {
    this.port = options.port;
    this.backendBaseUrl = options.backendBaseUrl.replace(/\/+$/, "");
    this.allowedOrigins = options.allowedOrigins ?? TRUSTED_ORIGINS;
    this.upstreamTimeoutMs = options.upstreamTimeoutMs ?? 30_000;
    this.maxBodyBytes = options.maxBodyBytes ?? 10 * 1024 * 1024;
    this.fetchUpstream = options.fetchUpstream;
    this.getApiKey = options.getApiKey;
  }

  private isAbortError(error: unknown): boolean {
    return error instanceof Error && (error.name === "AbortError" || error.name === "TimeoutError");
  }

  async start(): Promise<void> {
    if (this.server) {
      return;
    }

    const hostValidation = createHostValidationHandler(this.port);
    const cors = createCorsHandler(this.allowedOrigins);

    this.server = http.createServer((req, res) => {
      hostValidation(req, res, () => {
        cors(req, res, () => {
          const existingHeaders = res.getHeader("Access-Control-Allow-Headers");
          const headersToAllow =
            typeof existingHeaders === "string"
              ? `${existingHeaders}, ${API_KEY_HEADER}`
              : `Content-Type, ${API_KEY_HEADER}`;
          res.setHeader("Access-Control-Allow-Headers", headersToAllow);

          void this.handleRequest(req, res);
        });
      });
    });

    await new Promise<void>((resolve, reject) => {
      this.server!.once("error", reject);
      this.server!.listen(this.port, "127.0.0.1", () => resolve());
    });
  }

  async stop(): Promise<void> {
    const server = this.server;
    this.server = null;
    if (!server) return;

    await new Promise<void>(resolve => {
      server.close(() => resolve());
    });
  }

  async dispose(): Promise<void> {
    if (this.hasDisposed) {
      return;
    }
    this.hasDisposed = true;

    const server = this.server;
    try {
      await this.stop();
    } finally {
      try {
        server?.removeAllListeners();
      } catch {
        // Best-effort cleanup only.
      }
    }
  }

  getPort(): number {
    return this.port;
  }

  private isAllowedPath(pathname: string): boolean {
    return (
      pathname === "/api" ||
      pathname.startsWith("/api/") ||
      pathname === "/auth" ||
      pathname.startsWith("/auth/")
    );
  }

  private async handleRequest(req: IncomingMessage, res: ServerResponse): Promise<void> {
    try {
      const method = req.method ?? "GET";
      const requestUrl = new URL(req.url ?? "/", `http://127.0.0.1:${this.port}`);

      if (!this.isAllowedPath(requestUrl.pathname)) {
        res.writeHead(404, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: "Not found" }));
        return;
      }

      const upstreamUrl = `${this.backendBaseUrl}${requestUrl.pathname}${requestUrl.search}`;
      const body = await this.readBody(req);
      const headers = await this.buildUpstreamHeaders(req);

      const headersPlain: Record<string, string> = {};
      headers.forEach((value, key) => {
        const lower = key.toLowerCase();
        if (lower === "accept-encoding") {
          headersPlain[key] = "gzip, deflate";
        } else if (typeof value === "string" && value.length > 0) {
          headersPlain[key] = value;
        }
      });

      const bodyArrayBuffer: ArrayBuffer | undefined =
        body.length > 0
          ? (body.buffer.slice(body.byteOffset, body.byteOffset + body.byteLength) as ArrayBuffer)
          : undefined;

      const abortController = new AbortController();
      req.once("close", () => abortController.abort());
      const timeoutId = setTimeout(() => abortController.abort(), this.upstreamTimeoutMs);

      let upstreamResponse: Response;
      try {
        upstreamResponse = await this.fetchUpstream(upstreamUrl, {
          method,
          headers: headersPlain,
          body: bodyArrayBuffer,
          signal: abortController.signal,
        });
      } catch (error: unknown) {
        if (this.isAbortError(error)) {
          logger.warn("Backend proxy request timeout", {
            method,
            pathname: requestUrl.pathname,
            upstreamUrl,
          });
          res.writeHead(504, { "Content-Type": "application/json" });
          res.end(JSON.stringify({ error: "Gateway timeout" }));
          return;
        }
        logger.error("Backend proxy upstream request failed", {
          method,
          pathname: requestUrl.pathname,
          upstreamUrl,
          error: error instanceof Error ? error.message : String(error),
          errorName: error instanceof Error ? error.name : undefined,
        });
        throw error;
      } finally {
        clearTimeout(timeoutId);
      }

      res.statusCode = upstreamResponse.status;
      res.statusMessage = upstreamResponse.statusText;

      const EXCLUDED_HEADERS = new Set([
        "set-cookie",
        "content-length",
        "access-control-allow-origin",
        "access-control-allow-credentials",
        "access-control-allow-methods",
        "access-control-allow-headers",
        "access-control-expose-headers",
        "access-control-max-age",
      ]);

      upstreamResponse.headers.forEach((value, key) => {
        const lower = key.toLowerCase();
        if (HOP_BY_HOP_HEADERS.has(lower)) return;
        if (EXCLUDED_HEADERS.has(lower)) return;
        res.setHeader(key, value);
      });

      const upstreamBody = upstreamResponse.body;
      if (!upstreamBody) {
        res.end();
        return;
      }

      const reader = upstreamBody.getReader();
      res.once("close", () => {
        void reader.cancel();
      });

      while (true) {
        const { done, value } = await reader.read();
        if (done) {
          break;
        }

        if (!value || value.length === 0) {
          continue;
        }

        if (!res.write(Buffer.from(value))) {
          await once(res, "drain");
        }
      }

      res.end();
    } catch (error: unknown) {
      if (res.headersSent || res.writableEnded) {
        res.destroy();
        return;
      }

      if (error instanceof PayloadTooLargeError) {
        res.writeHead(413, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: "Payload too large" }));
        return;
      }

      const errorMessage = error instanceof Error ? error.message : String(error);
      const isConnectionError =
        errorMessage.includes("ECONNREFUSED") ||
        errorMessage.includes("ENOTFOUND") ||
        errorMessage.includes("ETIMEDOUT") ||
        errorMessage.includes("fetch failed");

      logger.error("Backend proxy request error", {
        method: req.method,
        pathname: req.url,
        error: errorMessage,
        isConnectionError,
        backendBaseUrl: this.backendBaseUrl,
      });

      res.writeHead(502, { "Content-Type": "application/json" });
      res.end(
        JSON.stringify({
          error: "Bad gateway",
          details: isConnectionError
            ? `Cannot connect to backend API at ${this.backendBaseUrl}. Please ensure the backend service is running.`
            : errorMessage,
        })
      );
    }
  }

  private async buildUpstreamHeaders(req: IncomingMessage): Promise<Headers> {
    const headers = new Headers();

    const BLOCKED_HEADERS = new Set([
      "host",
      "origin",
      "referer",
      "content-length",
      API_KEY_HEADER,
      "sec-ch-ua",
      "sec-ch-ua-mobile",
      "sec-ch-ua-platform",
      "sec-fetch-dest",
      "sec-fetch-mode",
      "sec-fetch-site",
      "sec-fetch-user",
      "sec-fetch-storage-access",
    ]);

    Object.entries(req.headers).forEach(([key, value]) => {
      const lower = key.toLowerCase();
      if (HOP_BY_HOP_HEADERS.has(lower)) return;
      if (BLOCKED_HEADERS.has(lower)) return;

      if (typeof value === "string") {
        headers.set(key, value);
        return;
      }

      if (Array.isArray(value)) {
        headers.set(key, value.join(", "));
      }
    });

    const apiKey = await this.getApiKey();
    if (typeof apiKey === "string" && trim(apiKey).length > 0) {
      headers.set(API_KEY_HEADER, trim(apiKey));
    }

    return headers;
  }

  private async readBody(req: IncomingMessage): Promise<Buffer> {
    if (req.method === "GET" || req.method === "HEAD") {
      return Buffer.alloc(0);
    }

    const contentLengthHeader = req.headers["content-length"];
    if (typeof contentLengthHeader === "string") {
      const contentLength = Number.parseInt(contentLengthHeader, 10);
      if (Number.isFinite(contentLength) && contentLength > this.maxBodyBytes) {
        throw new PayloadTooLargeError("Request body too large");
      }
    }

    return await new Promise<Buffer>((resolve, reject) => {
      const chunks: Buffer[] = [];
      let totalBytes = 0;
      let settled = false;

      const cleanup = () => {
        req.off("data", onData);
        req.off("end", onEnd);
        req.off("error", onError);
      };

      const settleReject = (error: Error) => {
        if (settled) return;
        settled = true;
        cleanup();
        reject(error);
      };

      const onData = (chunk: Buffer | string) => {
        if (settled) return;

        const buf = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
        totalBytes += buf.length;

        if (totalBytes > this.maxBodyBytes) {
          const error = new PayloadTooLargeError("Request body too large");
          // Pause the request to stop reading more data, but don't destroy it
          // so the error handler can send a proper response
          req.pause();
          settleReject(error);
          return;
        }

        chunks.push(buf);
      };

      const onEnd = () => {
        if (settled) return;
        settled = true;
        cleanup();
        resolve(Buffer.concat(chunks));
      };

      const onError = (error: Error) => {
        settleReject(error);
      };

      req.on("data", onData);
      req.on("end", onEnd);
      req.on("error", onError);
    });
  }
}
