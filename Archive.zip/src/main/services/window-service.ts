import { getLogger } from "@logtape/logtape";
import { asIpcErrorResponse } from "@shared/ipc-client";
import type { IpcResponse } from "@shared/ipc-types";
import { createIpcSuccess } from "@shared/ipc-utils";
import type { BrowserWindow, IpcMain } from "electron";

const logger = getLogger(["frontend", "main", "window-service"]);

// Title bar height offset in pixels
const TITLE_BAR_HEIGHT_OFFSET = 20;

type TitleBarOverlayParams = {
  color?: string;
  symbolColor?: string;
  height?: number;
};

function sanitizeTitleBarOverlayParams(raw: unknown): TitleBarOverlayParams | null {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return null;

  const params = raw as Partial<TitleBarOverlayParams>;

  const next: TitleBarOverlayParams = {};

  if (typeof params.color === "string" && params.color.trim().length > 0) {
    next.color = params.color;
  }

  if (typeof params.symbolColor === "string" && params.symbolColor.trim().length > 0) {
    next.symbolColor = params.symbolColor;
  }

  if (typeof params.height === "number" && Number.isFinite(params.height)) {
    const rounded = Math.round(params.height);
    if (rounded >= 24 && rounded <= 120) {
      next.height = rounded;
    }
  }

  if (Object.keys(next).length === 0) {
    return null;
  }

  return next;
}

export interface WindowServiceOptions {
  mainWindow: BrowserWindow;
  ipcMain: IpcMain;
  BrowserWindow: typeof BrowserWindow;
}

/**
 * Service for managing window operations
 */
export class WindowService {
  private readonly mainWindow: BrowserWindow;
  private readonly ipcMain: IpcMain;
  private readonly BrowserWindow: typeof BrowserWindow;

  private static readonly channels = [
    "window:get-state",
    "window:start-drag",
    "window:update-position",
    "window:set-titlebar-overlay",
  ] as const;

  constructor(options: WindowServiceOptions) {
    this.mainWindow = options.mainWindow;
    this.ipcMain = options.ipcMain;
    this.BrowserWindow = options.BrowserWindow;
    this.registerHandlers();
  }

  public dispose(): void {
    this.unregisterHandlers();
  }

  private registerHandlers(): void {
    this.unregisterHandlers();

    this.ipcMain.handle(
      "window:get-state",
      async (
        event: Electron.IpcMainInvokeEvent
      ): Promise<
        IpcResponse<{
          isMaximized: boolean;
          isFullScreen: boolean;
          bounds: { x: number; y: number; width: number; height: number };
        }>
      > => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected window:get-state from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        try {
          const window = this.BrowserWindow.fromWebContents(event.sender);
          if (!window) {
            return asIpcErrorResponse("No active BrowserWindow for IPC sender", "IPC_NO_WINDOW");
          }

          return createIpcSuccess({
            isMaximized: window.isMaximized(),
            isFullScreen: window.isFullScreen(),
            bounds: window.getBounds(),
          });
        } catch (error: unknown) {
          logger.error("Failed to get window state", {
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_WINDOW_GET_STATE_FAILED");
        }
      }
    );

    this.ipcMain.handle(
      "window:start-drag",
      async (
        event: Electron.IpcMainInvokeEvent,
        params: { cursorX: number; cursorY: number; dragPointX: number }
      ): Promise<
        IpcResponse<{
          wasMaximized: boolean;
          newBounds: { x: number; y: number; width: number; height: number };
        }>
      > => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected window:start-drag from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        try {
          const window = this.BrowserWindow.fromWebContents(event.sender);
          if (!window) {
            return asIpcErrorResponse("No active BrowserWindow for IPC sender", "IPC_NO_WINDOW");
          }

          const wasMaximized = window.isMaximized();

          if (wasMaximized && !window.isFullScreen()) {
            const oldBounds = window.getBounds();
            window.unmaximize();
            const newBounds = window.getBounds();

            // Position window so cursor stays at proportional position in title bar
            const proportionalX = params.dragPointX / oldBounds.width;
            const newDragPointX = proportionalX * newBounds.width;
            const newX = params.cursorX - newDragPointX;
            const newY = params.cursorY - TITLE_BAR_HEIGHT_OFFSET;

            window.setPosition(Math.round(newX), Math.round(newY));

            return createIpcSuccess({
              wasMaximized: true,
              newBounds: window.getBounds(),
            });
          }

          return createIpcSuccess({
            wasMaximized: false,
            newBounds: window.getBounds(),
          });
        } catch (error: unknown) {
          logger.error("Failed to start window drag", {
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_WINDOW_START_DRAG_FAILED");
        }
      }
    );

    this.ipcMain.handle(
      "window:update-position",
      async (
        event: Electron.IpcMainInvokeEvent,
        x: number,
        y: number
      ): Promise<IpcResponse<null>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected window:update-position from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        try {
          const window = this.BrowserWindow.fromWebContents(event.sender);
          if (!window) {
            return asIpcErrorResponse("No active BrowserWindow for IPC sender", "IPC_NO_WINDOW");
          }

          window.setPosition(Math.round(x), Math.round(y));
          return createIpcSuccess(null);
        } catch (error: unknown) {
          logger.error("Failed to update window position", {
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_WINDOW_UPDATE_POSITION_FAILED");
        }
      }
    );

    this.ipcMain.handle(
      "window:set-titlebar-overlay",
      async (
        event: Electron.IpcMainInvokeEvent,
        rawParams: unknown
      ): Promise<IpcResponse<null>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected window:set-titlebar-overlay from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        const params = sanitizeTitleBarOverlayParams(rawParams);
        if (!params) {
          return asIpcErrorResponse("Invalid overlay params", "IPC_WINDOW_SET_OVERLAY_INVALID");
        }

        try {
          const window = this.BrowserWindow.fromWebContents(event.sender);
          if (!window) {
            return asIpcErrorResponse("No active BrowserWindow for IPC sender", "IPC_NO_WINDOW");
          }

          const maybeSetTitleBarOverlay = (
            window as unknown as { setTitleBarOverlay?: (options: TitleBarOverlayParams) => void }
          ).setTitleBarOverlay;

          // This API is only available on Windows/Linux. On other platforms (or older builds),
          // it's not present, so we treat it as a no-op.
          if (typeof maybeSetTitleBarOverlay !== "function") {
            return createIpcSuccess(null);
          }

          try {
            maybeSetTitleBarOverlay(params);
          } catch (error: unknown) {
            const message = error instanceof Error ? error.message : String(error);

            // Electron throws when the overlay wasn't enabled in the BrowserWindow constructor.
            // Since the renderer may probe capabilities, treat this as a safe no-op.
            if (message.toLowerCase().includes("titlebar overlay is not enabled")) {
              return createIpcSuccess(null);
            }
            throw error;
          }
          return createIpcSuccess(null);
        } catch (error: unknown) {
          logger.error("Failed to set title bar overlay", {
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_WINDOW_SET_OVERLAY_FAILED");
        }
      }
    );
  }

  private unregisterHandlers(): void {
    for (const channel of WindowService.channels) {
      this.ipcMain.removeHandler(channel);
    }
  }
}
