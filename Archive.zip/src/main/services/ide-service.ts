import { getLogger } from "@logtape/logtape";
import { asIpcErrorResponse } from "@shared/ipc-client";
import type { IpcResponse } from "@shared/ipc-types";
import { createIpcSuccess } from "@shared/ipc-utils";
import { IDE_COMMANDS, type IDEType } from "@shared/ide-types";
import type { BrowserWindow, IpcMain } from "electron";
import { exec, spawn } from "child_process";
import { promisify } from "util";
import { existsSync } from "fs";

const execAsync = promisify(exec);
const logger = getLogger(["frontend", "main", "ide-service"]);

export interface IDEServiceOptions {
  mainWindow: BrowserWindow;
  ipcMain: IpcMain;
}

type IDEDetectionResult = Record<IDEType, boolean>;

/**
 * Service for managing IDE detection and launching
 */
export class IDEService {
  private readonly mainWindow: BrowserWindow;
  private readonly ipcMain: IpcMain;

  private static readonly channels = ["ide:detect", "ide:open"] as const;

  constructor(options: IDEServiceOptions) {
    this.mainWindow = options.mainWindow;
    this.ipcMain = options.ipcMain;
    this.registerHandlers();
  }

  public dispose(): void {
    this.unregisterHandlers();
  }

  /**
   * Detects if an IDE is installed on the system
   */
  private async isIDEInstalled(ideType: IDEType): Promise<boolean> {
    try {
      const command = IDE_COMMANDS[ideType];
      if (!command) return false;

      // Use platform-specific command lookup: where on Windows, which on Unix
      const lookupCmd = process.platform === "win32" ? "where" : "which";
      const { stdout } = await execAsync(`${lookupCmd} ${command}`);
      return stdout.trim().length > 0;
    } catch {
      return false;
    }
  }

  /**
   * Detects all installed IDEs in parallel
   */
  public async detectInstalledIDEs(): Promise<IDEDetectionResult> {
    // Derive IDE list from IDE_COMMANDS to avoid duplication
    const ideTypes = Object.keys(IDE_COMMANDS) as IDEType[];

    const results = await Promise.all(ideTypes.map(ideType => this.isIDEInstalled(ideType)));

    const installed: Record<IDEType, boolean> = {} as Record<IDEType, boolean>;
    ideTypes.forEach((ideType, index) => {
      installed[ideType] = results[index] ?? false;
    });

    return installed;
  }

  /**
   * Opens a project in the specified IDE
   */
  public async openInIDE(ideType: IDEType, path: string): Promise<void> {
    // Validate path argument
    if (!path || typeof path !== "string" || path.trim().length === 0) {
      throw new Error("Path is required and must be a non-empty string");
    }

    // Check if path exists
    if (!existsSync(path)) {
      throw new Error(`Path does not exist: ${path}`);
    }

    const command = IDE_COMMANDS[ideType];
    if (!command) {
      throw new Error(`Unsupported IDE type: ${ideType}`);
    }

    logger.info("Opening path in IDE", { ideType, path });

    // Spawn the IDE command with the path
    const child = spawn(command, [path], {
      detached: true,
      stdio: "ignore",
    });

    // Unref the child so the parent process can exit independently
    child.unref();
  }

  private registerHandlers(): void {
    this.unregisterHandlers();

    this.ipcMain.handle(
      "ide:detect",
      async (event: Electron.IpcMainInvokeEvent): Promise<IpcResponse<IDEDetectionResult>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected ide:detect from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        try {
          const installed = await this.detectInstalledIDEs();
          return createIpcSuccess(installed);
        } catch (error: unknown) {
          logger.error("Failed to detect installed IDEs", {
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_IDE_DETECT_FAILED");
        }
      }
    );

    this.ipcMain.handle(
      "ide:open",
      async (
        event: Electron.IpcMainInvokeEvent,
        ideType: unknown,
        path: unknown
      ): Promise<IpcResponse<null>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected ide:open from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        // Validate IDE type
        if (typeof ideType !== "string" || !(ideType in IDE_COMMANDS)) {
          return asIpcErrorResponse(`Invalid IDE type: ${ideType}`, "IPC_IDE_OPEN_INVALID_TYPE");
        }

        // Validate path
        if (typeof path !== "string") {
          return asIpcErrorResponse("Path must be a string", "IPC_IDE_OPEN_INVALID_PATH");
        }

        try {
          await this.openInIDE(ideType as IDEType, path);
          return createIpcSuccess(null);
        } catch (error: unknown) {
          const message = error instanceof Error ? error.message : String(error);
          logger.error("Failed to open IDE", {
            ideType,
            path,
            error: message,
          });
          return asIpcErrorResponse(message, "IPC_IDE_OPEN_FAILED");
        }
      }
    );
  }

  private unregisterHandlers(): void {
    for (const channel of IDEService.channels) {
      this.ipcMain.removeHandler(channel);
    }
  }
}
