import { getLogger } from "@logtape/logtape";
import { asIpcErrorResponse } from "@shared/ipc-client";
import type { IpcResponse } from "@shared/ipc-types";
import { createIpcSuccess } from "@shared/ipc-utils";
import type { BrowserWindow, IpcMain } from "electron";
import {
  clearClaudeCodeDetectionCache,
  detectClaudeCodeInstallation,
  type ClaudeCodeDetectionResult,
} from "../utils/claude-detection";

const logger = getLogger(["frontend", "main", "claude-code-service"]);

export interface ClaudeCodeServiceOptions {
  mainWindow: BrowserWindow;
  ipcMain: IpcMain;
}

/**
 * Service for managing Claude Code detection operations
 */
export class ClaudeCodeService {
  private readonly mainWindow: BrowserWindow;
  private readonly ipcMain: IpcMain;

  private static readonly channels = [
    "claude-code:detect",
    "claude-code:refresh-detection",
  ] as const;

  constructor(options: ClaudeCodeServiceOptions) {
    this.mainWindow = options.mainWindow;
    this.ipcMain = options.ipcMain;
    this.registerHandlers();
  }

  public dispose(): void {
    this.unregisterHandlers();
  }

  private registerHandlers(): void {
    this.unregisterHandlers();

    this.ipcMain.handle(
      "claude-code:detect",
      async (
        event: Electron.IpcMainInvokeEvent
      ): Promise<IpcResponse<ClaudeCodeDetectionResult>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected claude-code:detect from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        try {
          const result = detectClaudeCodeInstallation();
          return createIpcSuccess(result);
        } catch (error: unknown) {
          logger.error("Failed to detect Claude Code installation", {
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_CLAUDE_CODE_DETECT_FAILED");
        }
      }
    );

    this.ipcMain.handle(
      "claude-code:refresh-detection",
      async (
        event: Electron.IpcMainInvokeEvent
      ): Promise<IpcResponse<ClaudeCodeDetectionResult>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected claude-code:refresh-detection from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        try {
          clearClaudeCodeDetectionCache();
          const result = detectClaudeCodeInstallation();
          return createIpcSuccess(result);
        } catch (error: unknown) {
          logger.error("Failed to refresh Claude Code detection", {
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_CLAUDE_CODE_REFRESH_FAILED");
        }
      }
    );
  }

  private unregisterHandlers(): void {
    for (const channel of ClaudeCodeService.channels) {
      this.ipcMain.removeHandler(channel);
    }
  }
}
