/**
 * Encrypted API Key Store
 * Uses electron-store with encryptionKey for secure storage
 * Stores encrypted API keys using AES-256 encryption with build-time key
 */

import { getLogger } from "@logtape/logtape";
import { getCompozyHomeDir } from "@shared/repository-key";
import { validateApiKey } from "@shared/security";
import Store from "electron-store";
import { trim } from "es-toolkit/string";
import { mkdirSync } from "node:fs";
import { chmod } from "node:fs/promises";
import { join } from "path";

const logger = getLogger(["frontend", "main", "encrypted-api-key-store"]);

type ErrnoErrorLike = {
  code?: unknown;
  message?: unknown;
};

function getErrorMessage(error: unknown): string {
  if (error instanceof Error) {
    return error.message;
  }

  if (typeof error === "object" && error !== null && "message" in error) {
    const message = (error as ErrnoErrorLike).message;
    if (typeof message === "string") {
      return message;
    }
  }

  return String(error);
}

function getErrorCode(error: unknown): string | undefined {
  if (typeof error === "object" && error !== null && "code" in error) {
    const code = (error as ErrnoErrorLike).code;
    if (typeof code === "string") {
      return code;
    }
  }

  return undefined;
}

/**
 * Get encryption key from environment variable
 * Uses APP_CONFIG_SEED environment variable (obfuscated name)
 *
 * @throws Error if APP_CONFIG_SEED is not configured
 */
function getEncryptionKey(): string {
  const envKey = process.env.APP_CONFIG_SEED;

  if (!envKey || envKey.trim() === "") {
    throw new Error(
      "APP_CONFIG_SEED environment variable is required for API key encryption. " +
        "Please set it in your .env file. " +
        "For development, you can use the default value from env.example. " +
        "For production, this must be set via CI/CD environment variables."
    );
  }

  // Validate key format (should be 64-character hex string = 32 bytes)
  const trimmedKey = envKey.trim();
  if (trimmedKey.length !== 64 || !/^[0-9a-fA-F]+$/.test(trimmedKey)) {
    throw new Error(
      `Invalid APP_CONFIG_SEED format. Expected 64-character hexadecimal string (32 bytes), got ${trimmedKey.length} characters. ` +
        "Please check your .env file configuration."
    );
  }

  return trimmedKey;
}

/**
 * Store schema for API key data
 */
interface ApiKeyStoreData {
  apiKey: string;
  startTime: number;
  lastUpdate: number;
}

/**
 * Custom error for API key not found
 */
export class ApiKeyNotFoundError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ApiKeyNotFoundError";
  }
}

/**
 * Get API key expiration time in milliseconds from environment variable
 * Reads APP_CONFIG_KEY_EXPIRATION_DAYS (in days) or defaults to 30 days
 */
function getKeyExpirationMs(): number {
  const daysStr = process.env.APP_CONFIG_KEY_EXPIRATION_DAYS;
  if (daysStr) {
    const days = Number.parseInt(daysStr, 10);
    if (Number.isNaN(days) || days <= 0) {
      console.warn(
        `Invalid APP_CONFIG_KEY_EXPIRATION_DAYS value: ${daysStr}. Using default 30 days.`
      );
      return 30 * 24 * 60 * 60 * 1000;
    }
    return days * 24 * 60 * 60 * 1000;
  }
  // Default: 30 days
  return 30 * 24 * 60 * 60 * 1000;
}

/**
 * Encrypted electron-store-based API key storage implementation
 * Uses AES-256 encryption with build-time encryption key
 * Implements in-memory caching to avoid repeated file I/O and decryption
 */
export class EncryptedApiKeyStore {
  private readonly store: Store<ApiKeyStoreData>;
  private readonly storePath: string;
  private cachedApiKey: string | null = null;
  private cacheTimestamp: number = 0;
  private cachedExpirationTime: number = 0; // Expiration timestamp for cached key
  private readonly CACHE_TTL_MS = 60 * 1000; // 1 minute cache to balance performance and freshness
  private permissionError: Error | null = null; // Track permission errors for security validation

  constructor() {
    const compozyHome = getCompozyHomeDir();
    const statsigDir = join(compozyHome, "statsig");

    // Ensure directory exists (electron-store may not create it automatically)
    // Use sync mkdir to avoid async constructor issues
    try {
      mkdirSync(statsigDir, { recursive: true, mode: 0o700 });
    } catch (error: unknown) {
      const code = getErrorCode(error);
      // EEXIST is acceptable - directory already exists
      if (code !== "EEXIST") {
        throw new Error(`Failed to create statsig directory: ${getErrorMessage(error)}`);
      }
    }

    // Create store with encryption
    this.store = new Store<ApiKeyStoreData>({
      cwd: statsigDir,
      name: "config",
      encryptionKey: getEncryptionKey(),
      clearInvalidConfig: true,
    });

    // Store path for setting permissions
    this.storePath = this.store.path;

    // Set file permissions to 0o600 (owner read/write only)
    // electron-store may not set restrictive permissions by default
    this.ensureFilePermissions().catch(error => {
      const errorMessage = getErrorMessage(error);
      const errorCode = getErrorCode(error);
      this.permissionError = error instanceof Error ? error : new Error(errorMessage);
      logger.error(
        "Failed to set file permissions on encrypted store - security boundary weakened",
        {
          error: errorMessage,
          code: errorCode,
          storePath: this.storePath,
        }
      );
    });
  }

  /**
   * Ensure config file has restrictive permissions (0o600)
   * This is the primary security boundary
   */
  private async ensureFilePermissions(): Promise<void> {
    try {
      await chmod(this.storePath, 0o600);
    } catch (error: unknown) {
      const code = getErrorCode(error);
      // ENOENT is acceptable - file may not exist yet
      if (code !== "ENOENT") {
        throw new Error(`Failed to set file permissions: ${getErrorMessage(error)}`);
      }
    }
  }

  /**
   * Check if stored API key is expired based on lastUpdate timestamp
   */
  private isKeyExpired(data: ApiKeyStoreData): boolean {
    const now = Date.now();
    const timeSinceUpdate = now - data.lastUpdate;
    return timeSinceUpdate > getKeyExpirationMs();
  }

  /**
   * Check if file permissions were set successfully
   * @throws Error if permission setup failed (security boundary weakened)
   */
  private checkPermissions(): void {
    if (this.permissionError !== null) {
      throw new Error(
        `Cannot proceed with insecure file permissions: ${getErrorMessage(this.permissionError)}`
      );
    }
  }

  /**
   * Save API key to encrypted storage
   * Encrypts the key using electron-store with encryptionKey
   *
   * @param apiKey - API key to store (must start with compozy_)
   * @throws Error if API key format is invalid or write fails
   * @throws Error if file permissions were not set successfully
   */
  async saveApiKey(apiKey: string): Promise<void> {
    this.checkPermissions();
    const normalizedKey = trim(apiKey);

    // Validate API key format: must start with compozy_
    if (!validateApiKey(normalizedKey)) {
      throw new Error("Invalid API key format. Expected: compozy_*");
    }

    try {
      const now = Date.now();
      const existing = this.store.store;

      // Set startTime only if it doesn't exist (first time saving)
      const startTime = existing?.startTime ?? now;
      const lastUpdate = now;

      // Save encrypted data
      this.store.set({
        apiKey: normalizedKey,
        startTime,
        lastUpdate,
      });

      // Ensure file permissions after write
      await this.ensureFilePermissions();

      // Invalidate cache after save to ensure next load gets fresh data
      this.invalidateCache();
    } catch (error: unknown) {
      this.invalidateCache();
      throw new Error(`Failed to save API key: ${getErrorMessage(error)}`);
    }
  }

  /**
   * Load API key from encrypted storage
   * Decrypts the stored key using electron-store
   * Uses in-memory cache to avoid repeated file I/O and decryption
   *
   * @returns API key string (must start with compozy_)
   * @throws ApiKeyNotFoundError if key doesn't exist or is expired
   * @throws Error if decryption fails or key format is invalid
   * @throws Error if file permissions were not set successfully
   */
  async loadApiKey(): Promise<string> {
    this.checkPermissions();
    const now = Date.now();

    // Return cached key if still valid (within TTL and not expired)
    if (
      this.cachedApiKey !== null &&
      now - this.cacheTimestamp < this.CACHE_TTL_MS &&
      now < this.cachedExpirationTime
    ) {
      return this.cachedApiKey;
    }

    try {
      const data = this.store.store;

      // Check if data exists
      if (!data || !data.apiKey) {
        this.invalidateCache();
        throw new ApiKeyNotFoundError(
          "No API key found. Please sign in to Compozy to authenticate."
        );
      }

      // Check if key is expired
      if (this.isKeyExpired(data)) {
        this.invalidateCache();
        // Delete expired key
        await this.deleteApiKey();
        throw new ApiKeyNotFoundError("API key has expired. Please sign in again to authenticate.");
      }

      const trimmedKey = trim(data.apiKey);

      // Validate format
      if (!validateApiKey(trimmedKey)) {
        this.invalidateCache();
        throw new Error("Invalid API key format. Expected: compozy_*");
      }

      // Cache the decrypted key with expiration timestamp
      this.cachedApiKey = trimmedKey;
      this.cacheTimestamp = now;
      // Calculate expiration time: lastUpdate + expiration period
      this.cachedExpirationTime = data.lastUpdate + getKeyExpirationMs();

      return trimmedKey;
    } catch (error: unknown) {
      // Clear cache on error
      this.invalidateCache();
      if (error instanceof ApiKeyNotFoundError) {
        throw error;
      }
      const code = getErrorCode(error);
      if (code === "EACCES") {
        throw new Error("Cannot access API key file. Check file permissions.");
      }
      throw new Error(`Failed to load API key: ${getErrorMessage(error)}`);
    }
  }

  /**
   * Invalidate the in-memory cache
   * Called after save/delete operations to ensure consistency
   * Public for testing purposes
   */
  invalidateCache(): void {
    this.cachedApiKey = null;
    this.cacheTimestamp = 0;
    this.cachedExpirationTime = 0;
  }

  /**
   * Delete API key from encrypted storage
   * Removes all stored data and clears cache
   *
   * @throws Error if deletion fails
   * @throws Error if file permissions were not set successfully
   */
  async deleteApiKey(): Promise<void> {
    this.checkPermissions();
    try {
      this.store.clear();
      // Clear cache after deletion
      this.invalidateCache();
    } catch (error: unknown) {
      this.invalidateCache();
      throw new Error(`Failed to delete API key: ${getErrorMessage(error)}`);
    }
  }

  /**
   * Check if valid API key exists
   * Verifies encrypted data exists and contains properly formatted, non-expired key
   *
   * @returns true if valid API key exists, false otherwise
   */
  async hasApiKey(): Promise<boolean> {
    try {
      await this.loadApiKey();
      return true;
    } catch (error: unknown) {
      // Log unexpected errors (but not ApiKeyNotFoundError - missing/expired key is expected)
      if (!(error instanceof ApiKeyNotFoundError)) {
        console.warn("hasApiKey check failed due to unexpected error:", error);
      }
      return false;
    }
  }
}
