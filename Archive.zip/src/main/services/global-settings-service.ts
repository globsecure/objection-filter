import { getLogger } from "@logtape/logtape";
import { asIpcErrorResponse } from "@shared/ipc-client";
import type { IpcResponse } from "@shared/ipc-types";
import { createIpcSuccess } from "@shared/ipc-utils";
import { getCompozyHomeDir } from "@shared/repository-key";
import type { BrowserWindow, IpcMain } from "electron";
import Store from "electron-store";
import { cloneDeep, merge } from "es-toolkit/object";
import { isPlainObject } from "es-toolkit/predicate";
import { mkdirSync } from "node:fs";
import {
  BRANCH_PREFIX_TYPES,
  DEFAULT_BRAINSTORM_SETTINGS,
  DEFAULT_CLAUDE_CODE_ENV_SETTINGS,
  DEFAULT_GLOBAL_SETTINGS,
  DEFAULT_LLM_SETTINGS,
  DEFAULT_TASK_BREAKDOWN,
  isAgentType,
  isBrainstormSettingsPatch,
  isClarificationAgentType,
  isClaudeCodeEnvSettingsPatch,
  isGitSettingsPatch,
  isLlmSettingsPatch,
  isSetupWorktreeCommandsPatch,
  isTaskBreakdownSettingsPatch,
  isWorktreeInfo,
  sanitizeClaudeCodeEnvSettings,
  sanitizeGitSettings,
  sanitizeSetupWorktreeCommands,
  validateWorktreeBaseDirectory,
  WORKTREE_SETUP_COMMANDS_STATUSES,
  WORKTREE_STATUSES,
  type AgentType,
  type BrainstormSettings,
  type BrainstormSettingsPatch,
  type ClarificationAgentType,
  type ClaudeCodeEnvSettings,
  type ClaudeCodeEnvSettingsPatch,
  type GitSettings,
  type GitSettingsPatch,
  type GlobalSettings,
  type LlmSettings,
  type LlmSettingsPatch,
  type SetupWorktreeCommands,
  type SetupWorktreeCommandsPatch,
  type TaskBreakdownSettings,
  type TaskBreakdownSettingsPatch,
  type WorktreeInfo,
} from "../../shared/global-settings";

const logger = getLogger(["frontend", "main", "global-settings-service"]);

export interface GlobalSettingsServiceOptions {
  mainWindow: BrowserWindow;
  ipcMain: IpcMain;
}

type GetLlmSettingsResult = {
  settings: LlmSettings;
};

type GetAllLlmSettingsResult = {
  settings: Record<AgentType, LlmSettings>;
};

type MutateLlmSettingsResult = {
  settings: LlmSettings;
};

type GetBrainstormSettingsResult = {
  settings: BrainstormSettings;
};

type MutateBrainstormSettingsResult = {
  settings: BrainstormSettings;
};

type GetTaskBreakdownSettingsResult = {
  settings: TaskBreakdownSettings;
};

type MutateTaskBreakdownSettingsResult = {
  settings: TaskBreakdownSettings;
};

type GetGitSettingsResult = {
  settings: GitSettings;
};

type MutateGitSettingsResult = {
  settings: GitSettings;
  error?: string;
};

type GetSetupWorktreeCommandsResult = {
  settings: SetupWorktreeCommands;
};

type MutateSetupWorktreeCommandsResult = {
  settings: SetupWorktreeCommands;
  error?: string;
};

type GetClaudeCodeEnvSettingsResult = {
  settings: ClaudeCodeEnvSettings;
};

type MutateClaudeCodeEnvSettingsResult = {
  settings: ClaudeCodeEnvSettings;
  error?: string;
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return isPlainObject(value);
}

export class GlobalSettingsService {
  private readonly mainWindow: BrowserWindow;
  private readonly ipcMain: IpcMain;
  private readonly store: Store<GlobalSettings>;
  private static readonly channels = [
    "global-settings:llm:get",
    "global-settings:llm:get-all",
    "global-settings:llm:update",
    "global-settings:llm:reset",
    "global-settings:brainstorm:get",
    "global-settings:brainstorm:update",
    "global-settings:task-breakdown:get",
    "global-settings:task-breakdown:update",
    "global-settings:git:get",
    "global-settings:git:update",
    "global-settings:setup-worktree:get",
    "global-settings:setup-worktree:update",
    "global-settings:claude-code-env:get",
    "global-settings:claude-code-env:update",
  ] as const;

  constructor(options: GlobalSettingsServiceOptions) {
    this.mainWindow = options.mainWindow;
    this.ipcMain = options.ipcMain;
    this.store = this.createStore();
    this.registerHandlers();
  }

  public dispose(): void {
    this.unregisterHandlers();
  }

  public getGitSettings(): GitSettings {
    try {
      const storedRaw: unknown = this.store.get("git");
      return sanitizeGitSettings(storedRaw);
    } catch (error: unknown) {
      logger.warn("Failed to read git settings from store; falling back to defaults", {
        error: error instanceof Error ? error.message : String(error),
      });
      return sanitizeGitSettings(undefined);
    }
  }

  public getSetupWorktreeCommands(): SetupWorktreeCommands {
    try {
      const storedRaw: unknown = this.store.get("setupWorktree");
      return sanitizeSetupWorktreeCommands(storedRaw);
    } catch (error: unknown) {
      logger.warn("Failed to read setup worktree commands from store; falling back to defaults", {
        error: error instanceof Error ? error.message : String(error),
      });
      return sanitizeSetupWorktreeCommands(undefined);
    }
  }

  public getWorktrees(): WorktreeInfo[] {
    try {
      const storedRaw: unknown = this.store.get("worktrees");
      const stored = Array.isArray(storedRaw) ? storedRaw : [];
      return cloneDeep(stored.filter(isWorktreeInfo));
    } catch (error: unknown) {
      logger.warn("Failed to read worktrees from store; falling back to empty list", {
        error: error instanceof Error ? error.message : String(error),
      });
      return [];
    }
  }

  /**
   * Updates the list of worktrees in the store.
   *
   * **Note:** Invalid worktree entries (those not matching the `WorktreeInfo` schema)
   * are silently filtered out for resilience against data corruption. A warning is
   * logged when entries are rejected, but no error is thrown to allow partial saves.
   *
   * @param worktrees - The worktrees to persist.
   * @returns The sanitized list of worktrees that were actually persisted.
   */
  public updateWorktrees(worktrees: WorktreeInfo[]): WorktreeInfo[] {
    const next = worktrees.filter(isWorktreeInfo);
    if (next.length !== worktrees.length) {
      logger.warn("Ignoring invalid worktree entries during updateWorktrees()", {
        requested: worktrees.length,
        accepted: next.length,
      });
    }

    this.store.set("worktrees", cloneDeep(next));
    return cloneDeep(next);
  }

  /**
   * Gets Claude Code environment settings for custom provider integration.
   * This is a public method so it can be accessed from executor/agents.
   */
  public getClaudeCodeEnvSettings(): ClaudeCodeEnvSettings {
    try {
      const storedRaw: unknown = this.store.get("claudeCodeEnv");
      return sanitizeClaudeCodeEnvSettings(storedRaw);
    } catch (error: unknown) {
      logger.warn("Failed to read claudeCodeEnv from store; falling back to defaults", {
        error: error instanceof Error ? error.message : String(error),
      });
      return cloneDeep(DEFAULT_CLAUDE_CODE_ENV_SETTINGS);
    }
  }

  private updateClaudeCodeEnvSettings(patch: ClaudeCodeEnvSettingsPatch): {
    next: ClaudeCodeEnvSettings;
    error?: string;
  } {
    const current = this.getClaudeCodeEnvSettings();
    const merged = { ...current, ...patch };
    if (patch.customEnvVars !== undefined) {
      // Merge customEnvVars instead of replacing to preserve existing entries
      merged.customEnvVars = {
        ...current.customEnvVars,
        ...patch.customEnvVars,
      };
    }
    const next = sanitizeClaudeCodeEnvSettings(merged);
    this.store.set("claudeCodeEnv", cloneDeep(next));
    return { next };
  }

  private createStore(): Store<GlobalSettings> {
    const cwd = getCompozyHomeDir();
    mkdirSync(cwd, { recursive: true });

    const llmSettingsSchema = {
      type: "object",
      additionalProperties: false,
      properties: {
        model: { type: "string", enum: ["haiku", "sonnet", "opus"] },
        reasoningEffort: { type: "string", enum: ["minimal", "low", "medium", "high"] },
        codeAssistant: { type: "string", enum: ["claude-code", "codex", "gemini"] },
      },
      required: ["model", "reasoningEffort", "codeAssistant"],
    } as const;

    const agentRecordSchema = {
      type: "object",
      additionalProperties: false,
      properties: {
        "prd-creator": llmSettingsSchema,
        "techspec-creator": llmSettingsSchema,
        "tasks-creator": llmSettingsSchema,
        looper: llmSettingsSchema,
      },
      required: ["prd-creator", "techspec-creator", "tasks-creator", "looper"],
    } as const;

    const brainstormSettingsSchema = {
      type: "object",
      additionalProperties: false,
      properties: {
        maxQuestionsPerRound: { type: "integer", minimum: 1, maximum: 10 },
        approachCount: { type: "integer", minimum: 2, maximum: 5 },
        requireTradeoffs: { type: "boolean" },
      },
      required: ["maxQuestionsPerRound", "approachCount", "requireTradeoffs"],
    } as const;

    const brainstormRecordSchema = {
      type: "object",
      additionalProperties: false,
      properties: {
        prd: brainstormSettingsSchema,
        techspec: brainstormSettingsSchema,
      },
      required: ["prd", "techspec"],
    } as const;

    const taskBreakdownSchema = {
      type: "object",
      additionalProperties: false,
      properties: {
        minTasks: { type: "integer", minimum: 1, maximum: 20 },
        maxTasks: { type: "integer", minimum: 1, maximum: 20 },
        noLimit: { type: "boolean" },
      },
    } as const;

    const gitSettingsSchema = {
      type: "object",
      additionalProperties: false,
      properties: {
        branchPrefixType: { type: "string", enum: BRANCH_PREFIX_TYPES },
        customBranchPrefix: { type: "string" },
        deleteBranchOnArchive: { type: "boolean" },
        createWorktreeByDefault: { type: "boolean" },
        worktreeBaseDirectory: { type: "string" },
      },
      required: [
        "branchPrefixType",
        "deleteBranchOnArchive",
        "createWorktreeByDefault",
        "worktreeBaseDirectory",
      ],
    } as const;

    const setupWorktreeSchema = {
      type: "object",
      additionalProperties: false,
      properties: {
        perRepository: {
          type: "object",
          additionalProperties: {
            type: "array",
            items: { type: "string" },
          },
        },
      },
      required: ["perRepository"],
    } as const;

    const worktreesSchema = {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          id: { type: "string" },
          name: { type: "string" },
          branch: { type: "string" },
          path: { type: "string" },
          repositoryId: { type: "string" },
          issueId: { type: "string" },
          status: { type: "string", enum: WORKTREE_STATUSES },
          createdAt: { type: "string" },
          lastActivity: { type: "string" },
          setupCommandsStatus: { type: "string", enum: WORKTREE_SETUP_COMMANDS_STATUSES },
        },
        required: ["id", "name", "branch", "path", "repositoryId", "status", "createdAt"],
      },
    } as const;

    const claudeCodeEnvSchema = {
      type: "object",
      additionalProperties: false,
      properties: {
        anthropicBaseUrl: { type: "string" },
        anthropicAuthToken: { type: "string" },
        anthropicApiKey: { type: "string" },
        defaultHaikuModel: { type: "string" },
        defaultSonnetModel: { type: "string" },
        defaultOpusModel: { type: "string" },
        customEnvVars: {
          type: "object",
          additionalProperties: { type: "string" },
        },
      },
    } as const;

    return new Store<GlobalSettings>({
      cwd,
      name: "settings",
      fileExtension: "json",
      clearInvalidConfig: true,
      // Intentionally store everything under a single top-level key.
      schema: {
        llmSettings: agentRecordSchema,
        brainstormSettings: brainstormRecordSchema,
        taskBreakdown: taskBreakdownSchema,
        git: gitSettingsSchema,
        setupWorktree: setupWorktreeSchema,
        worktrees: worktreesSchema,
        claudeCodeEnv: claudeCodeEnvSchema,
      },
      defaults: DEFAULT_GLOBAL_SETTINGS,
    });
  }

  private getAllLlmSettings(): Record<AgentType, LlmSettings> {
    try {
      const storedRaw: unknown = this.store.get("llmSettings");
      const stored: Partial<Record<AgentType, Partial<LlmSettings>>> = isRecord(storedRaw)
        ? (storedRaw as Partial<Record<AgentType, Partial<LlmSettings>>>)
        : {};
      // Merge stored values onto defaults (ensures all agents always exist).
      return merge(cloneDeep(DEFAULT_LLM_SETTINGS), stored) as Record<AgentType, LlmSettings>;
    } catch (error: unknown) {
      logger.warn("Failed to read llmSettings from store; falling back to defaults", {
        error: error instanceof Error ? error.message : String(error),
      });
      return cloneDeep(DEFAULT_LLM_SETTINGS);
    }
  }

  private getLlmSettings(agentType: AgentType): LlmSettings {
    const all = this.getAllLlmSettings();
    return all[agentType] ?? cloneDeep(DEFAULT_LLM_SETTINGS[agentType]);
  }

  private setLlmSettings(agentType: AgentType, next: LlmSettings): void {
    this.store.set(`llmSettings.${agentType}`, next);
  }

  private validateBrainstormSettings(next: BrainstormSettings): string | null {
    if (next.maxQuestionsPerRound < 1 || next.maxQuestionsPerRound > 10) {
      return "maxQuestionsPerRound must be between 1 and 10";
    }
    if (next.approachCount < 2 || next.approachCount > 5) {
      return "approachCount must be between 2 and 5";
    }
    if (typeof next.requireTradeoffs !== "boolean") {
      return "requireTradeoffs must be a boolean";
    }
    return null;
  }

  private getBrainstormSettings(agentType: ClarificationAgentType): BrainstormSettings {
    try {
      const storedRaw: unknown = this.store.get(`brainstormSettings.${agentType}`);
      const stored: Partial<BrainstormSettings> = isRecord(storedRaw)
        ? (storedRaw as Partial<BrainstormSettings>)
        : {};
      const defaults = cloneDeep(DEFAULT_BRAINSTORM_SETTINGS[agentType]);
      const merged = merge(defaults, stored) as BrainstormSettings;
      const error = this.validateBrainstormSettings(merged);
      return error ? cloneDeep(DEFAULT_BRAINSTORM_SETTINGS[agentType]) : merged;
    } catch (error: unknown) {
      logger.warn("Failed to read brainstormSettings from store; falling back to defaults", {
        error: error instanceof Error ? error.message : String(error),
      });
      return cloneDeep(DEFAULT_BRAINSTORM_SETTINGS[agentType]);
    }
  }

  private setBrainstormSettings(agentType: ClarificationAgentType, next: BrainstormSettings): void {
    this.store.set(`brainstormSettings.${agentType}`, next);
  }

  private updateBrainstormSettings(
    agentType: ClarificationAgentType,
    patch: BrainstormSettingsPatch
  ): { next: BrainstormSettings; error?: string } {
    const current = this.getBrainstormSettings(agentType);
    const next: BrainstormSettings = { ...current, ...patch };
    const error = this.validateBrainstormSettings(next);
    if (error) return { next: current, error };
    this.setBrainstormSettings(agentType, next);
    return { next };
  }

  private getTaskBreakdownSettings(): TaskBreakdownSettings {
    try {
      const storedRaw: unknown = this.store.get("taskBreakdown");
      const stored: Partial<TaskBreakdownSettings> = isRecord(storedRaw)
        ? (storedRaw as Partial<TaskBreakdownSettings>)
        : {};
      return merge(cloneDeep(DEFAULT_TASK_BREAKDOWN), stored) as TaskBreakdownSettings;
    } catch (error: unknown) {
      logger.warn("Failed to read taskBreakdown from store; falling back to defaults", {
        error: error instanceof Error ? error.message : String(error),
      });
      return cloneDeep(DEFAULT_TASK_BREAKDOWN);
    }
  }

  private setTaskBreakdownSettings(next: TaskBreakdownSettings): void {
    this.store.set("taskBreakdown", next);
  }

  private updateTaskBreakdownSettings(patch: TaskBreakdownSettingsPatch): {
    next: TaskBreakdownSettings;
    error?: string;
  } {
    const current = this.getTaskBreakdownSettings();
    const next = { ...current, ...patch };

    if ("minTasks" in patch && patch.minTasks === undefined) {
      delete next.minTasks;
    }
    if ("maxTasks" in patch && patch.maxTasks === undefined) {
      delete next.maxTasks;
    }
    if ("noLimit" in patch && patch.noLimit === undefined) {
      delete next.noLimit;
    }

    if (next.minTasks !== undefined) {
      if (!Number.isInteger(next.minTasks) || next.minTasks < 1 || next.minTasks > 20) {
        return { next: current, error: "minTasks must be an integer between 1 and 20" };
      }
    }

    if (next.maxTasks !== undefined) {
      if (!Number.isInteger(next.maxTasks) || next.maxTasks < 1 || next.maxTasks > 20) {
        return { next: current, error: "maxTasks must be an integer between 1 and 20" };
      }
    }

    if (next.noLimit !== undefined && typeof next.noLimit !== "boolean") {
      return { next: current, error: "noLimit must be a boolean" };
    }

    if (next.minTasks !== undefined && next.maxTasks !== undefined) {
      if (next.minTasks > next.maxTasks) {
        return {
          next: current,
          error: "minTasks cannot be greater than maxTasks",
        };
      }
    }

    this.setTaskBreakdownSettings(next);
    return { next };
  }

  private resetLlmSettings(agentType: AgentType): LlmSettings {
    const defaults = cloneDeep(DEFAULT_LLM_SETTINGS[agentType]);
    this.setLlmSettings(agentType, defaults);
    return defaults;
  }

  private updateLlmSettings(agentType: AgentType, patch: LlmSettingsPatch): LlmSettings {
    const current = this.getLlmSettings(agentType);
    const next: LlmSettings = {
      ...current,
      ...patch,
    };
    this.setLlmSettings(agentType, next);
    return next;
  }

  private unregisterHandlers(): void {
    // Electron's `IpcMain` type doesn't currently expose `removeHandler`, even though it exists
    // at runtime. We keep the optional call to avoid crashing on older Electron versions.
    const ipcMainWithRemoveHandler = this.ipcMain as unknown as {
      removeHandler?: (channel: string) => void;
    };

    for (const channel of GlobalSettingsService.channels) {
      ipcMainWithRemoveHandler.removeHandler?.(channel);
    }
  }

  private registerHandlers(): void {
    this.unregisterHandlers();

    this.ipcMain.handle(
      "global-settings:llm:get",
      async (
        event: Electron.IpcMainInvokeEvent,
        agentType: unknown
      ): Promise<IpcResponse<GetLlmSettingsResult>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected global-settings:llm:get from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        if (!isAgentType(agentType)) {
          return asIpcErrorResponse("Invalid agentType", "IPC_INVALID_PARAMS");
        }

        return createIpcSuccess({ settings: this.getLlmSettings(agentType) });
      }
    );

    this.ipcMain.handle(
      "global-settings:llm:get-all",
      async (event: Electron.IpcMainInvokeEvent): Promise<IpcResponse<GetAllLlmSettingsResult>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected global-settings:llm:get-all from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        return createIpcSuccess({ settings: this.getAllLlmSettings() });
      }
    );

    this.ipcMain.handle(
      "global-settings:llm:update",
      async (
        event: Electron.IpcMainInvokeEvent,
        params: unknown
      ): Promise<IpcResponse<MutateLlmSettingsResult>> => {
        try {
          if (event.sender.id !== this.mainWindow.webContents.id) {
            logger.warn("Rejected global-settings:llm:update from untrusted sender", {
              senderId: event.sender.id,
            });
            return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
          }

          if (!isRecord(params) || !("agentType" in params) || !("patch" in params)) {
            return asIpcErrorResponse("Invalid parameters", "IPC_INVALID_PARAMS");
          }

          const { agentType, patch } = params as Record<string, unknown>;
          if (!isAgentType(agentType)) {
            return asIpcErrorResponse("Invalid agentType", "IPC_INVALID_PARAMS");
          }
          if (!isLlmSettingsPatch(patch)) {
            return asIpcErrorResponse("Invalid patch", "IPC_INVALID_PARAMS");
          }

          const next = this.updateLlmSettings(agentType, patch);
          return createIpcSuccess({ settings: next });
        } catch (error: unknown) {
          logger.error("Failed to update llm settings", {
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_GLOBAL_SETTINGS_LLM_UPDATE_FAILED");
        }
      }
    );

    this.ipcMain.handle(
      "global-settings:llm:reset",
      async (
        event: Electron.IpcMainInvokeEvent,
        agentType: unknown
      ): Promise<IpcResponse<MutateLlmSettingsResult>> => {
        try {
          if (event.sender.id !== this.mainWindow.webContents.id) {
            logger.warn("Rejected global-settings:llm:reset from untrusted sender", {
              senderId: event.sender.id,
            });
            return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
          }

          if (!isAgentType(agentType)) {
            return asIpcErrorResponse("Invalid agentType", "IPC_INVALID_PARAMS");
          }

          const next = this.resetLlmSettings(agentType);
          return createIpcSuccess({ settings: next });
        } catch (error: unknown) {
          logger.error("Failed to reset llm settings", {
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_GLOBAL_SETTINGS_LLM_RESET_FAILED");
        }
      }
    );

    this.ipcMain.handle(
      "global-settings:brainstorm:get",
      async (
        event: Electron.IpcMainInvokeEvent,
        agentType: unknown
      ): Promise<IpcResponse<GetBrainstormSettingsResult>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected global-settings:brainstorm:get from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        if (!isClarificationAgentType(agentType)) {
          return asIpcErrorResponse("Invalid agentType", "IPC_INVALID_PARAMS");
        }

        return createIpcSuccess({ settings: this.getBrainstormSettings(agentType) });
      }
    );

    this.ipcMain.handle(
      "global-settings:brainstorm:update",
      async (
        event: Electron.IpcMainInvokeEvent,
        params: unknown
      ): Promise<IpcResponse<MutateBrainstormSettingsResult>> => {
        try {
          if (event.sender.id !== this.mainWindow.webContents.id) {
            logger.warn("Rejected global-settings:brainstorm:update from untrusted sender", {
              senderId: event.sender.id,
            });
            return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
          }

          if (!isRecord(params) || !("agentType" in params) || !("patch" in params)) {
            return asIpcErrorResponse("Invalid parameters", "IPC_INVALID_PARAMS");
          }

          const { agentType, patch } = params as Record<string, unknown>;
          if (!isClarificationAgentType(agentType)) {
            return asIpcErrorResponse("Invalid agentType", "IPC_INVALID_PARAMS");
          }
          if (!isBrainstormSettingsPatch(patch)) {
            return asIpcErrorResponse("Invalid patch", "IPC_INVALID_PARAMS");
          }

          const result = this.updateBrainstormSettings(agentType, patch);
          if (result.error) {
            return asIpcErrorResponse(result.error, "IPC_VALIDATION_ERROR");
          }

          return createIpcSuccess({ settings: result.next });
        } catch (error: unknown) {
          logger.error("Failed to update brainstorm settings", {
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_GLOBAL_SETTINGS_BRAINSTORM_UPDATE_FAILED");
        }
      }
    );

    this.ipcMain.handle(
      "global-settings:task-breakdown:get",
      async (
        event: Electron.IpcMainInvokeEvent
      ): Promise<IpcResponse<GetTaskBreakdownSettingsResult>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected global-settings:task-breakdown:get from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        return createIpcSuccess({ settings: this.getTaskBreakdownSettings() });
      }
    );

    this.ipcMain.handle(
      "global-settings:task-breakdown:update",
      async (
        event: Electron.IpcMainInvokeEvent,
        patch: unknown
      ): Promise<IpcResponse<MutateTaskBreakdownSettingsResult>> => {
        try {
          if (event.sender.id !== this.mainWindow.webContents.id) {
            logger.warn("Rejected global-settings:task-breakdown:update from untrusted sender", {
              senderId: event.sender.id,
            });
            return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
          }

          if (!isTaskBreakdownSettingsPatch(patch)) {
            return asIpcErrorResponse("Invalid patch", "IPC_INVALID_PARAMS");
          }

          const result = this.updateTaskBreakdownSettings(patch);
          if (result.error) {
            return asIpcErrorResponse(result.error, "IPC_VALIDATION_ERROR");
          }

          return createIpcSuccess({ settings: result.next });
        } catch (error: unknown) {
          logger.error("Failed to update task breakdown settings", {
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_GLOBAL_SETTINGS_TASK_BREAKDOWN_UPDATE_FAILED");
        }
      }
    );

    this.ipcMain.handle(
      "global-settings:git:get",
      async (event: Electron.IpcMainInvokeEvent): Promise<IpcResponse<GetGitSettingsResult>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected global-settings:git:get from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        return createIpcSuccess({ settings: this.getGitSettings() });
      }
    );

    this.ipcMain.handle(
      "global-settings:git:update",
      async (
        event: Electron.IpcMainInvokeEvent,
        patch: unknown
      ): Promise<IpcResponse<MutateGitSettingsResult>> => {
        try {
          if (event.sender.id !== this.mainWindow.webContents.id) {
            logger.warn("Rejected global-settings:git:update from untrusted sender", {
              senderId: event.sender.id,
            });
            return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
          }

          const current = this.getGitSettings();
          if (!isGitSettingsPatch(patch)) {
            return asIpcErrorResponse("Invalid patch", "IPC_INVALID_PARAMS");
          }

          if (
            "worktreeBaseDirectory" in (patch as GitSettingsPatch) &&
            typeof (patch as GitSettingsPatch).worktreeBaseDirectory === "string"
          ) {
            const error = validateWorktreeBaseDirectory(
              (patch as GitSettingsPatch).worktreeBaseDirectory as string
            );
            if (error) {
              return asIpcErrorResponse(error, "IPC_VALIDATION_ERROR");
            }
          }

          const next = sanitizeGitSettings({ ...current, ...(patch as GitSettingsPatch) });
          this.store.set("git", cloneDeep(next));
          return createIpcSuccess({ settings: next });
        } catch (error: unknown) {
          logger.error("Failed to update git settings", {
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_GLOBAL_SETTINGS_GIT_UPDATE_FAILED");
        }
      }
    );

    this.ipcMain.handle(
      "global-settings:setup-worktree:get",
      async (
        event: Electron.IpcMainInvokeEvent
      ): Promise<IpcResponse<GetSetupWorktreeCommandsResult>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected global-settings:setup-worktree:get from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        return createIpcSuccess({ settings: this.getSetupWorktreeCommands() });
      }
    );

    this.ipcMain.handle(
      "global-settings:setup-worktree:update",
      async (
        event: Electron.IpcMainInvokeEvent,
        patch: unknown
      ): Promise<IpcResponse<MutateSetupWorktreeCommandsResult>> => {
        try {
          if (event.sender.id !== this.mainWindow.webContents.id) {
            logger.warn("Rejected global-settings:setup-worktree:update from untrusted sender", {
              senderId: event.sender.id,
            });
            return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
          }

          const current = this.getSetupWorktreeCommands();
          if (!isSetupWorktreeCommandsPatch(patch)) {
            return asIpcErrorResponse("Invalid patch", "IPC_INVALID_PARAMS");
          }

          const patchValue = patch as SetupWorktreeCommandsPatch;
          const next = sanitizeSetupWorktreeCommands({
            ...current,
            ...patchValue,
            ...(patchValue.perRepository
              ? { perRepository: { ...current.perRepository, ...patchValue.perRepository } }
              : {}),
          });

          this.store.set("setupWorktree", cloneDeep(next));
          return createIpcSuccess({ settings: next });
        } catch (error: unknown) {
          logger.error("Failed to update setup worktree commands", {
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_GLOBAL_SETTINGS_SETUP_WORKTREE_UPDATE_FAILED");
        }
      }
    );

    this.ipcMain.handle(
      "global-settings:claude-code-env:get",
      async (
        event: Electron.IpcMainInvokeEvent
      ): Promise<IpcResponse<GetClaudeCodeEnvSettingsResult>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected global-settings:claude-code-env:get from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        return createIpcSuccess({ settings: this.getClaudeCodeEnvSettings() });
      }
    );

    this.ipcMain.handle(
      "global-settings:claude-code-env:update",
      async (
        event: Electron.IpcMainInvokeEvent,
        patch: unknown
      ): Promise<IpcResponse<MutateClaudeCodeEnvSettingsResult>> => {
        try {
          if (event.sender.id !== this.mainWindow.webContents.id) {
            logger.warn("Rejected global-settings:claude-code-env:update from untrusted sender", {
              senderId: event.sender.id,
            });
            return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
          }

          if (!isClaudeCodeEnvSettingsPatch(patch)) {
            return asIpcErrorResponse("Invalid patch", "IPC_INVALID_PARAMS");
          }

          const result = this.updateClaudeCodeEnvSettings(patch);
          if (result.error) {
            return asIpcErrorResponse(result.error, "IPC_VALIDATION_ERROR");
          }

          return createIpcSuccess({ settings: result.next });
        } catch (error: unknown) {
          logger.error("Failed to update claude code env settings", {
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_GLOBAL_SETTINGS_CLAUDE_CODE_ENV_UPDATE_FAILED");
        }
      }
    );

    logger.info("Global settings IPC handlers registered", {
      channels: GlobalSettingsService.channels,
    });
  }
}
