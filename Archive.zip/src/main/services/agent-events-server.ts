import { TRUSTED_ORIGINS, createCorsHandler, createHostValidationHandler } from "@shared/security";
import { getLogger } from "@logtape/logtape";
import { BrowserWindow } from "electron";
import http from "node:http";
import type { Socket } from "node:net";
import { appConfig } from "../config/app-config";
import { isPlainObject, isString } from "es-toolkit/predicate";
import { trim } from "es-toolkit/string";
import type { AgentEvent } from "../../agents/mcp/tools/core/event-emitter";

const logger = getLogger(["frontend", "main", "agent-events-server"]);
let server: http.Server | null = null;
const sockets = new Set<Socket>();
let stopPromise: Promise<void> | null = null;

const REQUEST_TIMEOUT_MS = 30_000;
const MAX_BODY_SIZE_BYTES = 1_024 * 1_024; // 1MB
const FORCE_CLOSE_TIMEOUT_MS = 5_000;

type Middleware = (req: http.IncomingMessage, res: http.ServerResponse, next: () => void) => void;

type AgentEventValidationResult =
  | { success: true; event: AgentEvent }
  | { success: false; issues: string[] };

const validateAgentEvent = (value: unknown): AgentEventValidationResult => {
  if (!isPlainObject(value)) {
    return { success: false, issues: ["Event payload must be an object"] };
  }

  const raw = value as Record<string, unknown>;
  const issues: string[] = [];
  const tool = isString(raw.tool) ? trim(raw.tool) : "";
  const eventType = isString(raw.eventType) ? trim(raw.eventType) : "";
  const hasData = Object.prototype.hasOwnProperty.call(raw, "data");
  const issueIdRaw = raw.issueId;
  const issueId = isString(issueIdRaw) ? trim(issueIdRaw) : undefined;

  if (!tool) {
    issues.push("tool must be a non-empty string");
  }

  if (!eventType) {
    issues.push("eventType must be a non-empty string");
  }

  if (!hasData) {
    issues.push("data is required");
  }

  if (issueIdRaw !== undefined && !isString(issueIdRaw)) {
    issues.push("issueId must be a string when provided");
  }

  if (issues.length > 0) {
    return { success: false, issues };
  }

  return {
    success: true,
    event: {
      tool,
      eventType,
      data: raw.data,
      ...(issueId ? { issueId } : {}),
    },
  };
};

const runMiddlewares = async (
  req: http.IncomingMessage,
  res: http.ServerResponse,
  middlewares: Middleware[]
): Promise<void> =>
  new Promise((resolve, reject) => {
    const resolveMiddleware = () => {
      res.off("finish", resolveMiddleware);
      res.off("close", resolveMiddleware);
      resolve();
    };

    const rejectMiddleware = (error: unknown) => {
      res.off("finish", resolveMiddleware);
      res.off("close", resolveMiddleware);
      reject(error);
    };

    const invoke = (index: number) => {
      if (index >= middlewares.length || res.writableEnded || req.destroyed) {
        resolveMiddleware();
        return;
      }

      try {
        middlewares[index](req, res, () => invoke(index + 1));

        if (res.writableEnded || req.destroyed) {
          resolveMiddleware();
        }
      } catch (error) {
        rejectMiddleware(error);
      }
    };

    res.once("finish", resolveMiddleware);
    res.once("close", resolveMiddleware);

    invoke(0);
  });

export interface AgentEventsServerConfig {
  port: number;
  host: string;
}

export interface AgentEventsServerOptions {
  onEvent?: (event: AgentEvent) => void | Promise<void>;
}

export async function startAgentEventsServer(
  mainWindow: BrowserWindow,
  config?: AgentEventsServerConfig,
  options?: AgentEventsServerOptions
): Promise<number> {
  if (server) {
    const address = server.address();
    if (address && typeof address === "object") {
      return address.port;
    }
    return appConfig.agentEventsServer.port;
  }

  const { port, host } = config ?? appConfig.agentEventsServer;
  const hostValidationHandler = createHostValidationHandler(port);
  const corsHandler = createCorsHandler(TRUSTED_ORIGINS);

  const middlewareChain: Middleware[] = [hostValidationHandler, corsHandler];

  server = http.createServer((req, res) => {
    let hasEnded = false;

    const handleFinish = () => {
      hasEnded = true;
      cleanup();
    };

    const cleanup = () => {
      req.off("timeout", handleTimeout);
      req.off("error", handleRequestError);
      res.off("finish", handleFinish);
      res.off("close", cleanup);
    };

    const endWith = (statusCode: number, payload: Record<string, unknown>) => {
      if (hasEnded || res.writableEnded) return;
      hasEnded = true;
      if (!res.headersSent) {
        res.writeHead(statusCode, { "Content-Type": "application/json" });
      }
      res.end(JSON.stringify(payload));
    };

    const handleTimeout = () => {
      logger.warn("Agent events request timed out");
      endWith(408, { success: false, error: "Request timeout" });
      req.destroy();
    };

    const handleRequestError = (error: Error) => {
      logger.error("Agent events request errored", { error });
      if (!hasEnded) {
        endWith(400, { success: false, error: "Request aborted" });
      }
    };

    req.setTimeout(REQUEST_TIMEOUT_MS);
    req.on("timeout", handleTimeout);
    req.on("error", handleRequestError);
    res.on("finish", handleFinish);
    res.on("close", cleanup);

    const handleRequest = async () => {
      try {
        await runMiddlewares(req, res, middlewareChain);

        if (hasEnded || res.writableEnded || req.destroyed) {
          return;
        }

        if (req.method === "GET" && req.url === "/health") {
          endWith(200, { status: "ok" });
          return;
        }

        if (req.method === "POST" && req.url === "/api/agent-events") {
          let body = "";
          let bodySize = 0;

          req.on("data", chunk => {
            if (hasEnded) {
              return;
            }

            bodySize += chunk.length;

            if (bodySize > MAX_BODY_SIZE_BYTES) {
              logger.warn("Rejecting agent event: payload too large", {
                size: bodySize,
              });
              endWith(413, { success: false, error: "Payload too large" });
              req.destroy();
              return;
            }

            body += chunk.toString();
          });

          req.on("end", () => {
            if (hasEnded) {
              return;
            }

            try {
              const eventData = JSON.parse(body);
              const validation = validateAgentEvent(eventData);
              if (!validation.success) {
                logger.warn("Rejected agent event: invalid payload", {
                  issues: validation.issues,
                });
                endWith(400, { success: false, error: "Invalid event payload" });
                return;
              }

              const agentEvent = validation.event;
              logger.info("Received agent event", { event: agentEvent });

              if (options?.onEvent) {
                Promise.resolve(options.onEvent(agentEvent)).catch(error => {
                  logger.warn("Agent events handler failed", {
                    error: error instanceof Error ? error.message : String(error),
                  });
                });
              }

              // Forward event to renderer
              if (!mainWindow.isDestroyed() && !mainWindow.webContents.isDestroyed()) {
                mainWindow.webContents.send("agent:tool-event", agentEvent);
              }

              endWith(200, { success: true });
            } catch (error) {
              logger.error("Failed to process agent event", { error });
              endWith(400, { success: false, error: "Invalid JSON" });
            }
          });

          return;
        }

        endWith(404, { success: false, error: "Not found" });
      } catch (error) {
        logger.error("Agent events middleware chain failed", { error });
        if (!hasEnded) {
          endWith(500, { success: false, error: "Internal server error" });
        }
      }
    };

    void handleRequest();
  });

  server.requestTimeout = REQUEST_TIMEOUT_MS;

  await new Promise<void>((resolve, reject) => {
    if (!server) {
      reject(new Error("Agent events server not initialized"));
      return;
    }

    const handleError = (error: Error) => {
      reject(error);
    };

    server.once("error", handleError);
    server.listen(port, host, () => {
      server?.off("error", handleError);
      resolve();
    });
  });

  logger.info(`Agent events server listening on http://${host}:${port}`);

  server.on("error", error => {
    logger.error("Agent events server error", { error });
  });

  server.on("connection", socket => {
    sockets.add(socket);
    socket.on("close", () => sockets.delete(socket));
  });

  return port;
}

export async function stopAgentEventsServer(): Promise<void> {
  if (stopPromise) {
    return stopPromise;
  }

  const currentServer = server;
  if (!currentServer) {
    return;
  }

  // Prevent new calls from trying to close the server again while shutdown runs.
  server = null;

  stopPromise = new Promise<void>(resolve => {
    let hasSettled = false;
    const resolveOnce = () => {
      if (hasSettled) return;
      hasSettled = true;
      resolve();
    };

    const closeTimeout = setTimeout(() => {
      logger.warn("Forcing agent events server to close");
      sockets.forEach(socket => socket.destroy());
      try {
        currentServer.closeAllConnections?.();
      } catch (error) {
        logger.warn("Failed to close all agent events server connections", {
          error: error instanceof Error ? error.message : String(error),
        });
      }
      resolveOnce();
    }, FORCE_CLOSE_TIMEOUT_MS);

    try {
      currentServer.close(error => {
        clearTimeout(closeTimeout);
        if (error) {
          logger.warn("Agent events server close failed", {
            error: error instanceof Error ? error.message : String(error),
          });
        }
        resolveOnce();
      });
    } catch (error) {
      clearTimeout(closeTimeout);
      logger.warn("Agent events server shutdown failed", {
        error: error instanceof Error ? error.message : String(error),
      });
      resolveOnce();
    }
  }).finally(() => {
    stopPromise = null;
    sockets.clear();
    logger.info("Agent events server stopped");
  });

  return stopPromise;
}
