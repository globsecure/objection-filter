import {
  prdCreatedEventSchema,
  prdDeletedEventSchema,
  prdUpdatedEventSchema,
  taskCreatedEventSchema,
  taskDeletedEventSchema,
  tasksCreatedEventSchema,
  taskUpdatedEventSchema,
  techspecCreatedEventSchema,
  techspecDeletedEventSchema,
  techspecUpdatedEventSchema,
} from "@compozy/types";
import { getLogger } from "@logtape/logtape";
import { asIpcErrorResponse } from "@shared/ipc-client";
import type { IpcResponse } from "@shared/ipc-types";
import { createIpcSuccess } from "@shared/ipc-utils";
import { isValidIssueId } from "@shared/issue-path";
import type { BrowserWindow, IpcMain } from "electron";
import { isPlainObject } from "es-toolkit/predicate";
import { trim } from "es-toolkit/string";
import * as fs from "node:fs/promises";
import type { AgentEvent } from "../../agents/mcp/tools/core/event-emitter";
import {
  deleteArtifact,
  getArtifactContextPaths,
  indexArtifact,
  listArtifacts,
  syncArtifactFromDisk,
} from "../../artifacts/indexer";
import { buildTaskArtifactMarkdown } from "../../artifacts/markdown";
import { getArtifactFilePath, isValidTaskId } from "../../artifacts/paths";
import {
  artifactTypeSchema,
  type ArtifactContextPaths,
  type ArtifactIndexInput,
  type ArtifactListItem,
  type ArtifactSyncWarning,
  type ArtifactType,
} from "../../artifacts/types";

const logger = getLogger(["frontend", "main", "artifact-index-service"]);

export interface ArtifactIndexServiceOptions {
  mainWindow: BrowserWindow;
  ipcMain: IpcMain;
}

type IndexPayload = Omit<ArtifactIndexInput, "content"> & {
  content?: string;
};

type ListPayload = {
  issueId: string;
};

type ContextPayload = {
  issueId: string;
};

type DeletePayload = {
  issueId: string;
  type: ArtifactIndexInput["type"];
  taskId?: string;
};

function parseIndexPayload(payload: unknown): IndexPayload | null {
  if (!isPlainObject(payload)) return null;
  const raw = payload as Record<string, unknown>;
  const issueId = typeof raw.issueId === "string" ? trim(raw.issueId) : "";
  if (!isValidIssueId(issueId)) return null;

  const parsedType = artifactTypeSchema.safeParse(raw.type);
  if (!parsedType.success) return null;

  const hasContent = Object.prototype.hasOwnProperty.call(raw, "content");
  if (hasContent && typeof raw.content !== "string") return null;
  const content = hasContent ? (raw.content as string) : undefined;
  const title = typeof raw.title === "string" ? raw.title : undefined;
  const taskId = typeof raw.taskId === "string" ? trim(raw.taskId) : undefined;
  if (taskId && !isValidTaskId(taskId)) return null;
  const taskSlug = typeof raw.taskSlug === "string" ? raw.taskSlug : undefined;
  const updatedAt = typeof raw.updatedAt === "number" ? raw.updatedAt : undefined;
  const syncedAt =
    typeof raw.syncedAt === "number" || raw.syncedAt === null ? raw.syncedAt : undefined;

  if (parsedType.data === "task" && !taskId) {
    return null;
  }

  return {
    issueId,
    type: parsedType.data,
    ...(content !== undefined && { content }),
    ...(title !== undefined && { title }),
    ...(taskId !== undefined && { taskId }),
    ...(taskSlug !== undefined && { taskSlug }),
    ...(updatedAt !== undefined && { updatedAt }),
    ...(syncedAt !== undefined && { syncedAt }),
  };
}

function parseListPayload(payload: unknown): ListPayload | null {
  if (!isPlainObject(payload)) return null;
  const raw = payload as Record<string, unknown>;
  const issueId = typeof raw.issueId === "string" ? trim(raw.issueId) : "";
  if (!isValidIssueId(issueId)) return null;

  return {
    issueId,
  };
}

function parseContextPayload(payload: unknown): ContextPayload | null {
  if (!isPlainObject(payload)) return null;
  const raw = payload as Record<string, unknown>;
  const issueId = typeof raw.issueId === "string" ? trim(raw.issueId) : "";
  if (!isValidIssueId(issueId)) return null;

  return {
    issueId,
  };
}

function parseDeletePayload(payload: unknown): DeletePayload | null {
  if (!isPlainObject(payload)) return null;
  const raw = payload as Record<string, unknown>;
  const issueId = typeof raw.issueId === "string" ? trim(raw.issueId) : "";
  if (!isValidIssueId(issueId)) return null;

  const parsedType = artifactTypeSchema.safeParse(raw.type);
  if (!parsedType.success) return null;

  const taskId = typeof raw.taskId === "string" ? trim(raw.taskId) : undefined;
  if (taskId && !isValidTaskId(taskId)) return null;

  if (parsedType.data === "task" && !taskId) {
    return null;
  }

  return {
    issueId,
    type: parsedType.data,
    ...(taskId !== undefined && { taskId }),
  };
}

type TaskRecord = Record<string, unknown>;

function getTaskString(task: TaskRecord, key: string): string | undefined {
  const value = task[key];
  return typeof value === "string" && trim(value).length > 0 ? value : undefined;
}

function getTaskTimestamp(task: TaskRecord, key: string): number | undefined {
  const value = task[key];
  if (typeof value === "number") return value;
  if (value instanceof Date) return value.getTime();
  if (typeof value === "string") {
    const parsed = Date.parse(value);
    return Number.isNaN(parsed) ? undefined : parsed;
  }
  return undefined;
}

async function hasExistingArtifactFile(
  issueId: string,
  type: "prd" | "techspec"
): Promise<boolean> {
  const filePath = getArtifactFilePath({ issueId, type });
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

async function indexDocumentArtifact(params: {
  issueId: string;
  type: "prd" | "techspec";
  title?: string;
  content?: string;
}): Promise<void> {
  const trimmedContent = params.content !== undefined ? trim(params.content) : "";
  if (params.content !== undefined && trimmedContent.length === 0) {
    return;
  }

  if (params.content === undefined) {
    const hasFile = await hasExistingArtifactFile(params.issueId, params.type);
    if (!hasFile) {
      return;
    }
  }

  const timestamp = Date.now();

  await indexArtifact({
    issueId: params.issueId,
    type: params.type,
    ...(params.title !== undefined && { title: params.title }),
    ...(params.content !== undefined && { content: params.content }),
    updatedAt: timestamp,
    syncedAt: timestamp,
  });
}

/**
 * Sync artifacts from disk and return any sync warnings.
 * Warnings are returned instead of silently swallowed so the renderer
 * can be informed about partial sync failures.
 */
async function syncArtifactsOnOpen(issueId: string): Promise<ArtifactSyncWarning[]> {
  const warnings: ArtifactSyncWarning[] = [];
  const targets: Array<{ type: "prd" | "techspec" | "issue_context" }> = [
    { type: "prd" },
    { type: "techspec" },
    { type: "issue_context" },
  ];

  for (const target of targets) {
    try {
      await syncArtifactFromDisk({ issueId, type: target.type });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger.warn("Failed to sync artifact on open", {
        issueId,
        type: target.type,
        error: errorMessage,
      });
      warnings.push({ type: target.type, error: errorMessage });
    }
  }

  return warnings;
}

async function indexTaskRecord(issueId: string, task: TaskRecord) {
  const taskId = getTaskString(task, "id");
  if (!taskId || !isValidTaskId(taskId)) return;

  const title = getTaskString(task, "title") ?? "Task";
  const content = typeof task.content === "string" ? task.content : "";
  const markdown = buildTaskArtifactMarkdown({ title, content });
  if (!trim(markdown)) return;

  await indexArtifact({
    issueId,
    type: "task",
    taskId,
    taskSlug: getTaskString(task, "slug"),
    title,
    content: markdown,
    updatedAt: getTaskTimestamp(task, "updatedAt"),
    syncedAt: getTaskTimestamp(task, "updatedAt"),
  });
}

export class ArtifactIndexService {
  private readonly mainWindow: BrowserWindow;
  private readonly ipcMain: IpcMain;
  // Track service readiness to prevent IPC calls during initialization window
  private isReady = false;

  /**
   * Per-artifact operation queues to prevent race conditions.
   * Operations on the same artifact are serialized to avoid concurrent
   * file system operations (fs.rename, fs.writeFile) and data races.
   */
  private readonly artifactQueues = new Map<string, Promise<unknown>>();

  private static readonly channels = [
    "artifacts:index",
    "artifacts:list",
    "artifacts:get-context",
    "artifacts:delete",
  ] as const;

  constructor(options: ArtifactIndexServiceOptions) {
    this.mainWindow = options.mainWindow;
    this.ipcMain = options.ipcMain;
    this.registerHandlers();
  }

  /**
   * Generate a unique key for artifact operations.
   */
  private getArtifactQueueKey(issueId: string, type: ArtifactType, taskId?: string): string {
    return taskId ? `${issueId}:${type}:${taskId}` : `${issueId}:${type}`;
  }

  /**
   * Queue an artifact operation to prevent concurrent updates.
   * Operations on the same artifact are serialized using promise chaining.
   */
  private async queueArtifactOperation<T>(key: string, operation: () => Promise<T>): Promise<T> {
    const previousPromise = this.artifactQueues.get(key) ?? Promise.resolve();

    const newPromise = previousPromise
      .catch(() => {
        // Ignore previous errors to continue with new operation
      })
      .then(() => operation());

    this.artifactQueues.set(key, newPromise);

    try {
      return await newPromise;
    } finally {
      // Clean up completed promises to prevent memory leaks
      if (this.artifactQueues.get(key) === newPromise) {
        this.artifactQueues.delete(key);
      }
    }
  }

  /**
   * Mark the service as ready to accept IPC calls.
   * This should be called after the agent events server is fully started
   * to prevent partial system state issues during initialization.
   */
  public markReady(): void {
    this.isReady = true;
    logger.debug("ArtifactIndexService marked as ready");
  }

  public dispose(): void {
    this.unregisterHandlers();
  }

  public handleAgentEvent = async (event: AgentEvent): Promise<void> => {
    if (!event || typeof event !== "object") {
      return;
    }

    const issueId = typeof event.issueId === "string" ? event.issueId : undefined;

    // All artifact operations are queued to prevent race conditions

    if (event.eventType === "PRD_CREATED") {
      const parsed = prdCreatedEventSchema.safeParse(event.data);
      if (!parsed.success) return;
      const { prd } = parsed.data;
      const resolvedIssueId = prd.issueId ?? parsed.data.issueId ?? issueId;
      if (!resolvedIssueId) return;

      const queueKey = this.getArtifactQueueKey(resolvedIssueId, "prd");
      await this.queueArtifactOperation(queueKey, () =>
        indexDocumentArtifact({
          issueId: resolvedIssueId,
          type: "prd",
          title: prd.title,
          content: prd.content,
        })
      );
      return;
    }

    if (event.eventType === "PRD_UPDATED") {
      const parsed = prdUpdatedEventSchema.safeParse(event.data);
      if (!parsed.success) return;
      const resolvedIssueId = parsed.data.issueId ?? issueId;
      if (!resolvedIssueId) return;

      const queueKey = this.getArtifactQueueKey(resolvedIssueId, "prd");
      await this.queueArtifactOperation(queueKey, () =>
        indexDocumentArtifact({
          issueId: resolvedIssueId,
          type: "prd",
          ...(parsed.data.changes.title !== undefined && {
            title: parsed.data.changes.title,
          }),
          ...(parsed.data.changes.content !== undefined && {
            content: parsed.data.changes.content,
          }),
        })
      );
      return;
    }

    if (event.eventType === "PRD_DELETED") {
      const parsed = prdDeletedEventSchema.safeParse(event.data);
      if (!parsed.success) return;
      const resolvedIssueId = parsed.data.issueId ?? issueId;
      if (!resolvedIssueId) return;

      const queueKey = this.getArtifactQueueKey(resolvedIssueId, "prd");
      await this.queueArtifactOperation(queueKey, () =>
        deleteArtifact({
          issueId: resolvedIssueId,
          type: "prd",
        })
      );
      return;
    }

    if (event.eventType === "TECHSPEC_CREATED") {
      const parsed = techspecCreatedEventSchema.safeParse(event.data);
      if (!parsed.success) return;
      const { techspec } = parsed.data;
      const resolvedIssueId = techspec.issueId ?? parsed.data.issueId ?? issueId;
      if (!resolvedIssueId) return;

      const queueKey = this.getArtifactQueueKey(resolvedIssueId, "techspec");
      await this.queueArtifactOperation(queueKey, () =>
        indexDocumentArtifact({
          issueId: resolvedIssueId,
          type: "techspec",
          title: techspec.title,
          content: techspec.content,
        })
      );
      return;
    }

    if (event.eventType === "TECHSPEC_UPDATED") {
      const parsed = techspecUpdatedEventSchema.safeParse(event.data);
      if (!parsed.success) return;
      const resolvedIssueId = parsed.data.issueId ?? issueId;
      if (!resolvedIssueId) return;

      const queueKey = this.getArtifactQueueKey(resolvedIssueId, "techspec");
      await this.queueArtifactOperation(queueKey, () =>
        indexDocumentArtifact({
          issueId: resolvedIssueId,
          type: "techspec",
          ...(parsed.data.changes.title !== undefined && {
            title: parsed.data.changes.title,
          }),
          ...(parsed.data.changes.content !== undefined && {
            content: parsed.data.changes.content,
          }),
        })
      );
      return;
    }

    if (event.eventType === "TECHSPEC_DELETED") {
      const parsed = techspecDeletedEventSchema.safeParse(event.data);
      if (!parsed.success) return;
      const resolvedIssueId = parsed.data.issueId ?? issueId;
      if (!resolvedIssueId) return;

      const queueKey = this.getArtifactQueueKey(resolvedIssueId, "techspec");
      await this.queueArtifactOperation(queueKey, () =>
        deleteArtifact({
          issueId: resolvedIssueId,
          type: "techspec",
        })
      );
      return;
    }

    if (event.eventType === "TASK_UPDATED") {
      const parsed = taskUpdatedEventSchema.safeParse(event.data);
      if (!parsed.success) {
        return;
      }

      const updatedTask = parsed.data.updatedTask;
      if (!updatedTask || typeof updatedTask !== "object") {
        return;
      }

      const taskRecord = updatedTask as TaskRecord;
      const resolvedIssueId = getTaskString(taskRecord, "issueId") ?? issueId;

      if (!resolvedIssueId) {
        // Log when issueId is missing instead of failing silently
        logger.error("TASK_UPDATED event missing issueId", {
          taskId: getTaskString(taskRecord, "id"),
          eventType: event.eventType,
        });
        return;
      }

      const taskId = getTaskString(taskRecord, "id");
      const queueKey = this.getArtifactQueueKey(resolvedIssueId, "task", taskId);
      await this.queueArtifactOperation(queueKey, () =>
        indexTaskRecord(resolvedIssueId, taskRecord)
      );
      return;
    }

    if (event.eventType === "TASK_CREATED") {
      const parsed = taskCreatedEventSchema.safeParse(event.data);
      if (!parsed.success) return;
      const task = parsed.data.task as TaskRecord;
      const taskId = getTaskString(task, "id");
      const queueKey = this.getArtifactQueueKey(parsed.data.issueId, "task", taskId);
      await this.queueArtifactOperation(queueKey, () => indexTaskRecord(parsed.data.issueId, task));
      return;
    }

    if (event.eventType === "TASKS_CREATED") {
      const parsed = tasksCreatedEventSchema.safeParse(event.data);
      if (!parsed.success) return;
      await Promise.all(
        parsed.data.tasks.map(task => {
          const taskRecord = task as TaskRecord;
          const taskId = getTaskString(taskRecord, "id");
          const queueKey = this.getArtifactQueueKey(parsed.data.issueId, "task", taskId);
          return this.queueArtifactOperation(queueKey, () =>
            indexTaskRecord(parsed.data.issueId, taskRecord)
          );
        })
      );
      return;
    }

    if (event.eventType === "TASK_DELETED") {
      const parsed = taskDeletedEventSchema.safeParse(event.data);
      if (!parsed.success) return;
      const resolvedIssueId = parsed.data.issueId ?? issueId;
      if (!resolvedIssueId) return;

      const queueKey = this.getArtifactQueueKey(resolvedIssueId, "task", parsed.data.taskId);
      await this.queueArtifactOperation(queueKey, () =>
        deleteArtifact({
          issueId: resolvedIssueId,
          type: "task",
          taskId: parsed.data.taskId,
        })
      );
    }
  };

  private registerHandlers(): void {
    this.unregisterHandlers();

    this.ipcMain.handle(
      "artifacts:index",
      async (
        event: Electron.IpcMainInvokeEvent,
        payload: unknown
      ): Promise<IpcResponse<unknown>> => {
        // Check service readiness before processing IPC calls
        if (!this.isReady) {
          return asIpcErrorResponse("Service not ready", "IPC_SERVICE_NOT_READY");
        }

        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected artifacts:index from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        const parsed = parseIndexPayload(payload);
        if (!parsed) {
          return asIpcErrorResponse("Invalid payload", "IPC_INVALID_PAYLOAD");
        }

        // Validate content before calling indexer
        if (parsed.content !== undefined) {
          const trimmedContent = trim(parsed.content);
          if (trimmedContent.length === 0 && parsed.type !== "task") {
            return asIpcErrorResponse(
              `Empty content for ${parsed.type}`,
              "IPC_EMPTY_ARTIFACT_CONTENT"
            );
          }
        }

        // Queue artifact operations to prevent race conditions
        const queueKey = this.getArtifactQueueKey(parsed.issueId, parsed.type, parsed.taskId);

        try {
          const record = await this.queueArtifactOperation(queueKey, () => indexArtifact(parsed));
          return createIpcSuccess(record);
        } catch (error) {
          logger.error("Failed to index artifact", {
            error: error instanceof Error ? error.message : String(error),
            issueId: parsed.issueId,
            type: parsed.type,
          });
          return asIpcErrorResponse(error, "IPC_ARTIFACT_INDEX_FAILED");
        }
      }
    );

    this.ipcMain.handle(
      "artifacts:list",
      async (
        event: Electron.IpcMainInvokeEvent,
        payload: unknown
      ): Promise<IpcResponse<ReadonlyArray<ArtifactListItem>>> => {
        // Check service readiness before processing IPC calls
        if (!this.isReady) {
          return asIpcErrorResponse("Service not ready", "IPC_SERVICE_NOT_READY");
        }

        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected artifacts:list from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        const parsed = parseListPayload(payload);
        if (!parsed) {
          return asIpcErrorResponse("Invalid payload", "IPC_INVALID_PAYLOAD");
        }

        try {
          const results = await listArtifacts(parsed.issueId);
          return createIpcSuccess(results);
        } catch (error) {
          logger.error("Failed to list artifacts", {
            error: error instanceof Error ? error.message : String(error),
            issueId: parsed.issueId,
          });
          return asIpcErrorResponse(error, "IPC_ARTIFACT_LIST_FAILED");
        }
      }
    );

    this.ipcMain.handle(
      "artifacts:get-context",
      async (
        event: Electron.IpcMainInvokeEvent,
        payload: unknown
      ): Promise<IpcResponse<ArtifactContextPaths>> => {
        // Check service readiness before processing IPC calls
        if (!this.isReady) {
          return asIpcErrorResponse("Service not ready", "IPC_SERVICE_NOT_READY");
        }

        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected artifacts:get-context from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        const parsed = parseContextPayload(payload);
        if (!parsed) {
          return asIpcErrorResponse("Invalid payload", "IPC_INVALID_PAYLOAD");
        }

        try {
          // Capture sync warnings instead of silently swallowing failures
          let syncWarnings: ArtifactSyncWarning[] = [];
          try {
            syncWarnings = await syncArtifactsOnOpen(parsed.issueId);
          } catch (syncError) {
            // If the entire sync fails, log and include as a general warning
            const errorMessage = syncError instanceof Error ? syncError.message : String(syncError);
            logger.error("Failed to run artifact sync on open", {
              issueId: parsed.issueId,
              error: errorMessage,
            });
            syncWarnings = [{ type: "sync-failure", error: `Sync failed: ${errorMessage}` }];
          }
          const contextPaths = await getArtifactContextPaths(parsed.issueId);
          // Include sync warnings in the response
          return createIpcSuccess({ ...contextPaths, syncWarnings });
        } catch (error) {
          logger.error("Failed to get artifact context", {
            error: error instanceof Error ? error.message : String(error),
            issueId: parsed.issueId,
          });
          return asIpcErrorResponse(error, "IPC_ARTIFACT_CONTEXT_FAILED");
        }
      }
    );

    this.ipcMain.handle(
      "artifacts:delete",
      async (
        event: Electron.IpcMainInvokeEvent,
        payload: unknown
      ): Promise<IpcResponse<unknown>> => {
        // Check service readiness before processing IPC calls
        if (!this.isReady) {
          return asIpcErrorResponse("Service not ready", "IPC_SERVICE_NOT_READY");
        }

        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected artifacts:delete from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        const parsed = parseDeletePayload(payload);
        if (!parsed) {
          return asIpcErrorResponse("Invalid payload", "IPC_INVALID_PAYLOAD");
        }

        try {
          const queueKey = this.getArtifactQueueKey(parsed.issueId, parsed.type, parsed.taskId);
          await this.queueArtifactOperation(queueKey, () =>
            deleteArtifact({
              issueId: parsed.issueId,
              type: parsed.type,
              ...(parsed.taskId !== undefined && { taskId: parsed.taskId }),
            })
          );
          return createIpcSuccess({ status: "deleted", type: parsed.type });
        } catch (error) {
          logger.error("Failed to delete artifact", {
            error: error instanceof Error ? error.message : String(error),
            issueId: parsed.issueId,
            type: parsed.type,
          });
          return asIpcErrorResponse(error, "IPC_ARTIFACT_DELETE_FAILED");
        }
      }
    );
  }

  private unregisterHandlers(): void {
    for (const channel of ArtifactIndexService.channels) {
      this.ipcMain.removeHandler(channel);
    }
  }
}
