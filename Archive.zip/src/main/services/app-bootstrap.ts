import { electronApp, optimizer } from "@electron-toolkit/utils";
import { getLogger } from "@logtape/logtape";
import type { ApiKeyProviderRef } from "@shared/api-key-provider";
import * as Effect from "effect/Effect";
import { app, BrowserWindow, ipcMain } from "electron";
import path from "path";
import { LooperSDK } from "../../looper";
import { buildRuntimeConfig, type RuntimeConfig } from "../../shared/runtime-config";
import { appConfig } from "../config/app-config";
import { waitForBackend } from "../utils/network";
import { captureMainException } from "../utils/sentry";
import { startAgentEventsServer } from "./agent-events-server";
import type { AgentEvent } from "../../agents/mcp/tools/core/event-emitter";
import { startAgentService } from "./agent-server";
import type { ApiKeyService } from "./api-key-service";
import { initializeAutoUpdater, type AutoUpdaterService } from "./auto-updater";
import { BackendProxyService } from "./backend-proxy-service";
import { DeepLinkBridgeService } from "./deep-link-bridge";
import type { DeepLinkService } from "./deep-link-handler";
import type { MacDockIconService } from "./mac-dock-icon";
import { registerNavigationShortcuts, unregisterNavigationShortcuts } from "./navigation-shortcuts";
import { PortManager } from "./port-manager";
import { loadWindowContent } from "./window-manager";

const logger = getLogger(["frontend", "main", "app-bootstrap"]);

export interface AppBootstrapServiceOptions {
  apiKeyRef: ApiKeyProviderRef;
  apiKeyService: ApiKeyService;
  deepLinkService: DeepLinkService;
  macDockIconService: MacDockIconService;
  portManager: PortManager;
  backendBaseUrl: string;
  getMainWindow: () => BrowserWindow | null;
  setBackendProxyService: (service: BackendProxyService | null) => void;
  setAutoUpdaterService: (service: AutoUpdaterService | null) => void;
  setRuntimeConfig: (config: RuntimeConfig) => void;
  onAgentEvent?: (event: AgentEvent) => void | Promise<void>;
}

export class AppBootstrapService {
  private readonly apiKeyRef: ApiKeyProviderRef;
  private readonly apiKeyService: ApiKeyService;
  private readonly deepLinkService: DeepLinkService;
  private readonly macDockIconService: MacDockIconService;
  private readonly portManager: PortManager;
  private readonly backendBaseUrl: string;
  private readonly getMainWindow: () => BrowserWindow | null;
  private readonly setBackendProxyService: (service: BackendProxyService | null) => void;
  private readonly setAutoUpdaterService: (service: AutoUpdaterService | null) => void;
  private readonly setRuntimeConfig: (config: RuntimeConfig) => void;
  private readonly onAgentEvent?: (event: AgentEvent) => void | Promise<void>;
  private runtimeConfig: RuntimeConfig | undefined;
  private hasDisposed = false;
  private deepLinkBridgeService: DeepLinkBridgeService | null = null;
  private browserWindowCreatedHandler:
    | ((event: Electron.Event, window: BrowserWindow) => void)
    | null = null;

  constructor(options: AppBootstrapServiceOptions) {
    this.apiKeyRef = options.apiKeyRef;
    this.apiKeyService = options.apiKeyService;
    this.deepLinkService = options.deepLinkService;
    this.macDockIconService = options.macDockIconService;
    this.portManager = options.portManager;
    this.backendBaseUrl = options.backendBaseUrl;
    this.getMainWindow = options.getMainWindow;
    this.setBackendProxyService = options.setBackendProxyService;
    this.setAutoUpdaterService = options.setAutoUpdaterService;
    this.setRuntimeConfig = options.setRuntimeConfig;
    this.onAgentEvent = options.onAgentEvent;
  }

  dispose(): void {
    if (this.hasDisposed) {
      return;
    }
    this.hasDisposed = true;

    if (this.browserWindowCreatedHandler) {
      app.off("browser-window-created", this.browserWindowCreatedHandler);
      this.browserWindowCreatedHandler = null;
    }

    // Best-effort cleanup: safe to call multiple times.
    unregisterNavigationShortcuts();
    this.portManager.clear();

    if (this.deepLinkBridgeService) {
      // Best-effort cleanup: fire-and-forget disposal with error logging
      this.deepLinkBridgeService.dispose().catch(error => {
        logger.warn("Failed to dispose deep link bridge service", {
          error: error instanceof Error ? error.message : String(error),
        });
      });
      this.deepLinkBridgeService = null;
    }
  }

  private broadcastRuntimeConfig(target?: BrowserWindow | null): void {
    if (target && !target.isDestroyed() && !target.webContents.isDestroyed()) {
      try {
        const config = this.getRuntimeConfig();
        target.webContents.send("runtime-config", config);
        logger.debug("Runtime config broadcasted to renderer", {
          agentsPort: config.agents.port,
          backendProxyPort: config.backendProxy.port,
        });
      } catch (error) {
        logger.error("Failed to broadcast runtime config", {
          error: error instanceof Error ? error.message : String(error),
        });
      }
    }
  }

  private fetchUpstreamViaSession(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
    const mainWindow = this.getMainWindow();
    if (!mainWindow) {
      throw new Error("Main window is not available");
    }

    const sessionFetch = mainWindow.webContents.session.fetch as unknown as (
      input: RequestInfo | URL,
      init?: RequestInit
    ) => Promise<Response>;

    const urlString =
      typeof input === "string"
        ? input
        : input instanceof URL
          ? input.toString()
          : typeof Request !== "undefined" && input instanceof Request
            ? input.url
            : String(input);

    const fetchInit: RequestInit = {};
    if (init?.method) {
      fetchInit.method = init.method;
    }
    if (init?.headers) {
      fetchInit.headers = init.headers;
    }
    if (init?.body !== undefined && init?.body !== null) {
      fetchInit.body = init.body;
    }
    if (init?.signal) {
      fetchInit.signal = init.signal;
    }

    return sessionFetch(urlString, fetchInit);
  }

  async initialize(): Promise<void> {
    electronApp.setAppUserModelId(appConfig.app.userModelId);

    // Register protocol handler for deep links (compozy://)
    // - macOS production: primary registration via Info.plist (electron-builder)
    // - Windows/Linux: relies on runtime registration below
    // - Development: use local HTTP bridge for web auth; protocol still available for manual testing
    const protocol = appConfig.deepLink.protocol;
    const isDev = !app.isPackaged;

    if (isDev) {
      // Development: try to register but expect failure on macOS
      const mainScript = process.argv[1];
      const args = mainScript ? [path.resolve(mainScript)] : [];
      app.setAsDefaultProtocolClient(protocol, process.execPath, args);
    } else {
      // Production: cross-platform registration (primary on Windows/Linux, fallback on macOS)
      app.setAsDefaultProtocolClient(protocol);
    }

    const registered = app.isDefaultProtocolClient(protocol);
    logger.info("Protocol registration attempted", {
      protocol,
      isDev,
      registered,
      mechanism:
        process.platform === "darwin" && !isDev
          ? "Info.plist (primary) + runtime (fallback)"
          : "runtime",
    });

    if (isDev) {
      this.deepLinkBridgeService = new DeepLinkBridgeService({
        deepLinkService: this.deepLinkService,
        port: appConfig.deepLink.bridgePort,
        allowedOrigins: appConfig.deepLink.bridgeAllowedOrigins,
      });

      try {
        await this.deepLinkBridgeService.start();
      } catch (error: unknown) {
        logger.warn("Deep link bridge failed to start", {
          error: error instanceof Error ? error.message : String(error),
        });
      }
    }

    // Allocate ports for all services
    const agentsPort = await this.portManager.allocatePort("agents", appConfig.agents.port);
    const looperPort = await this.portManager.allocatePort("looper", appConfig.looper.port);
    const agentEventsPort = await this.portManager.allocatePort(
      "agentEvents",
      appConfig.agentEventsServer.port
    );
    const backendProxyPort = await this.portManager.allocatePort(
      "backendProxy",
      appConfig.backendProxy.port
    );

    // Build runtime config with allocated ports
    const runtimeConfig = buildRuntimeConfig({
      host: appConfig.agents.host,
      agentsPort,
      looperPort,
      agentEventsPort,
      backendProxyPort,
    });
    this.runtimeConfig = runtimeConfig;
    this.setRuntimeConfig(runtimeConfig);

    process.env.LOOPER_SERVER_URL = runtimeConfig.looper.baseUrl;

    // Set macOS dock icon
    this.macDockIconService.setDockIcon();

    // Register window shortcuts
    this.browserWindowCreatedHandler = (_event, window) => {
      optimizer.watchWindowShortcuts(window);
    };
    app.on("browser-window-created", this.browserWindowCreatedHandler);

    // Register global keyboard shortcuts for browser navigation
    registerNavigationShortcuts();

    const mainWindow = this.getMainWindow();
    if (!mainWindow) {
      throw new Error("Main window must be created before bootstrap initialization");
    }

    // Broadcast runtime config immediately after allocation so renderer can use correct ports
    this.broadcastRuntimeConfig(mainWindow);
    logger.info("Runtime config broadcasted after port allocation", {
      agentsPort,
      looperPort,
      agentEventsPort,
      backendProxyPort,
    });
    const pendingApiKey = this.deepLinkService.getPendingApiKey();
    await Effect.runPromise(this.apiKeyService.hydrateApiKey(pendingApiKey));

    // Optional: Check backend API health before starting proxy
    try {
      const backendHealthUrl = `${this.backendBaseUrl}/health`;
      const abortController = new AbortController();
      const timeoutId = setTimeout(() => abortController.abort(), 5000); // 5 second timeout

      try {
        const healthResponse = await this.fetchUpstreamViaSession(backendHealthUrl, {
          method: "GET",
          signal: abortController.signal,
        });

        if (healthResponse.ok) {
          logger.info("Backend API health check passed", { url: this.backendBaseUrl });
        } else {
          logger.warn("Backend API health check returned non-OK status", {
            url: this.backendBaseUrl,
            status: healthResponse.status,
          });
        }
      } finally {
        clearTimeout(timeoutId);
      }
    } catch (error) {
      // Don't fail startup if backend is unavailable, but log a warning
      const isTimeout = error instanceof Error && error.name === "AbortError";
      logger.warn("Backend API health check failed - backend may be unavailable", {
        url: this.backendBaseUrl,
        error: error instanceof Error ? error.message : String(error),
        isTimeout,
        note: "Backend proxy will still start, but requests may fail until backend is available",
      });
    }

    const backendProxyService = new BackendProxyService({
      port: backendProxyPort,
      backendBaseUrl: this.backendBaseUrl,
      fetchUpstream: this.fetchUpstreamViaSession.bind(this),
      getApiKey: () => Effect.runPromise(this.apiKeyService.getApiKey()),
    });

    await backendProxyService.start();
    this.setBackendProxyService(backendProxyService);
    logger.info("Backend proxy service started", { port: backendProxyPort });

    logger.info("Starting agent service", {
      backendUrl: runtimeConfig.backendProxy.baseUrl,
      agentEventsUrl: runtimeConfig.agentEvents.baseUrl,
      host: runtimeConfig.agents.host,
      port: runtimeConfig.agents.port,
    });

    await startAgentService({
      app,
      backendUrl: runtimeConfig.backendProxy.baseUrl,
      agentEventsUrl: runtimeConfig.agentEvents.baseUrl,
      host: runtimeConfig.agents.host,
      port: runtimeConfig.agents.port,
      getAppVersion: () => app.getVersion(),
      waitForBackend: async ({ retries, delayMs }) =>
        waitForBackend({
          host: runtimeConfig.agents.host,
          port: runtimeConfig.agents.port,
          retries,
          delayMs,
        }),
    });

    logger.info("Agent service started successfully", { port: runtimeConfig.agents.port });

    try {
      const sdk = new LooperSDK();
      await Effect.runPromise(
        sdk.initialize(ipcMain, mainWindow, {
          apiKeyRef: this.apiKeyRef,
          captureException: captureMainException,
        })
      );
    } catch (error: unknown) {
      captureMainException(error, { phase: "bootstrap", component: "looper" });
      logger.error("Failed to initialize Looper SDK", {
        message: error instanceof Error ? error.message : String(error),
        name: error instanceof Error ? error.name : undefined,
      });
      throw error;
    }

    loadWindowContent(mainWindow);
    this.broadcastRuntimeConfig(mainWindow);
    const initialLink = process.argv.find(arg => arg.startsWith(`${protocol}://`));
    if (initialLink) {
      await this.deepLinkService.handleDeepLink(initialLink);
    }

    const remainingPendingApiKey = this.deepLinkService.getPendingApiKey();
    if (remainingPendingApiKey && mainWindow) {
      mainWindow.webContents.send("deep-link-api-key", remainingPendingApiKey);
    }

    await startAgentEventsServer(mainWindow, runtimeConfig.agentEvents, {
      ...(this.onAgentEvent && { onEvent: this.onAgentEvent }),
    });
    this.broadcastRuntimeConfig(mainWindow);

    const autoUpdaterService = initializeAutoUpdater(() => this.getMainWindow(), ipcMain);
    this.setAutoUpdaterService(autoUpdaterService);
    autoUpdaterService.checkForUpdates().catch(error => {
      logger.warn("Initial update check failed", {
        error: error instanceof Error ? error.message : String(error),
      });
    });
  }

  getRuntimeConfig(): RuntimeConfig {
    if (!this.runtimeConfig) {
      throw new Error("RuntimeConfig not initialized. Call initialize() first.");
    }
    return this.runtimeConfig;
  }
}
