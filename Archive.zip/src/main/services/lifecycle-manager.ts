import { getLogger } from "@logtape/logtape";
import { app, BrowserWindow } from "electron";
import { appConfig } from "../config/app-config";
import { stopAgentEventsServer } from "./agent-events-server";
import { stopAgentService } from "./agent-server";
import type { AutoUpdaterService } from "./auto-updater";
import type { BackendProxyService } from "./backend-proxy-service";
import type { DeepLinkService } from "./deep-link-handler";
import { unregisterNavigationShortcuts } from "./navigation-shortcuts";
import { createWindow } from "./window-manager";
import type { Disposable } from "./disposable";

const logger = getLogger(["frontend", "main", "lifecycle-manager"]);
const SHUTDOWN_TIMEOUT_MS = 5_000;

export interface LifecycleManagerOptions {
  deepLinkService: DeepLinkService;
  getMainWindow: () => BrowserWindow | null;
  setMainWindow: (window: BrowserWindow | null) => void;
  getBackendProxyService: () => BackendProxyService | null;
  getAutoUpdaterService: () => AutoUpdaterService | null;
  getApiKeyService?: () => Disposable | null;
  getGlobalSettingsService?: () => Disposable | null;
  getIDEService?: () => Disposable | null;
  getWorktreeService?: () => Disposable | null;
  getDeepLinkIpcService?: () => Disposable | null;
  getAppBootstrapService?: () => Disposable | null;
  getWindowService?: () => Disposable | null;
  getDirectoryService?: () => Disposable | null;
  getGitService?: () => Disposable | null;
  getSystemService?: () => Disposable | null;
  getRuntimeConfigService?: () => Disposable | null;
  getClaudeCodeService?: () => Disposable | null;
  getArtifactIndexService?: () => Disposable | null;
  getIssueStorageService?: () => Disposable | null;
}

export class LifecycleManager {
  private readonly deepLinkService: DeepLinkService;
  private readonly getMainWindow: () => BrowserWindow | null;
  private readonly setMainWindow: (window: BrowserWindow | null) => void;
  private readonly getBackendProxyService: () => BackendProxyService | null;
  private readonly getAutoUpdaterService: () => AutoUpdaterService | null;
  private readonly getApiKeyService: (() => Disposable | null) | null;
  private readonly getGlobalSettingsService: (() => Disposable | null) | null;
  private readonly getIDEService: (() => Disposable | null) | null;
  private readonly getWorktreeService: (() => Disposable | null) | null;
  private readonly getDeepLinkIpcService: (() => Disposable | null) | null;
  private readonly getAppBootstrapService: (() => Disposable | null) | null;
  private readonly getWindowService: (() => Disposable | null) | null;
  private readonly getDirectoryService: (() => Disposable | null) | null;
  private readonly getGitService: (() => Disposable | null) | null;
  private readonly getSystemService: (() => Disposable | null) | null;
  private readonly getRuntimeConfigService: (() => Disposable | null) | null;
  private readonly getClaudeCodeService: (() => Disposable | null) | null;
  private readonly getArtifactIndexService: (() => Disposable | null) | null;
  private readonly getIssueStorageService: (() => Disposable | null) | null;
  private isQuitting = false;

  constructor(options: LifecycleManagerOptions) {
    this.deepLinkService = options.deepLinkService;
    this.getMainWindow = options.getMainWindow;
    this.setMainWindow = options.setMainWindow;
    this.getBackendProxyService = options.getBackendProxyService;
    this.getAutoUpdaterService = options.getAutoUpdaterService;
    this.getApiKeyService = options.getApiKeyService ?? null;
    this.getGlobalSettingsService = options.getGlobalSettingsService ?? null;
    this.getIDEService = options.getIDEService ?? null;
    this.getWorktreeService = options.getWorktreeService ?? null;
    this.getDeepLinkIpcService = options.getDeepLinkIpcService ?? null;
    this.getAppBootstrapService = options.getAppBootstrapService ?? null;
    this.getWindowService = options.getWindowService ?? null;
    this.getDirectoryService = options.getDirectoryService ?? null;
    this.getGitService = options.getGitService ?? null;
    this.getSystemService = options.getSystemService ?? null;
    this.getRuntimeConfigService = options.getRuntimeConfigService ?? null;
    this.getClaudeCodeService = options.getClaudeCodeService ?? null;
    this.getArtifactIndexService = options.getArtifactIndexService ?? null;
    this.getIssueStorageService = options.getIssueStorageService ?? null;
  }

  private async shutdownWithTimeout<T>(
    promise: Promise<T>,
    label: string,
    timeoutMs: number = SHUTDOWN_TIMEOUT_MS
  ): Promise<T | null> {
    let timeoutId: ReturnType<typeof setTimeout> | null = null;
    const timeout = new Promise<null>(resolve => {
      timeoutId = setTimeout(() => resolve(null), timeoutMs);
    });

    try {
      const result = await Promise.race([promise, timeout]);
      if (result === null) {
        logger.warn("Shutdown step timed out", { step: label, timeoutMs });
        return null;
      }
      return result;
    } finally {
      if (timeoutId !== null) {
        clearTimeout(timeoutId);
      }
    }
  }

  private async shutdownServices(): Promise<void> {
    const shutdownStep = async (label: string, fn: () => void | Promise<void>): Promise<void> => {
      logger.info("Shutdown step started", { step: label });
      try {
        await this.shutdownWithTimeout(Promise.resolve(fn()), label);
      } catch (error: unknown) {
        logger.warn("Shutdown step failed", {
          step: label,
          error: error instanceof Error ? error.message : String(error),
        });
      } finally {
        logger.info("Shutdown step completed", { step: label });
      }
    };

    const apiKeyService = this.getApiKeyService?.();
    if (apiKeyService) {
      await shutdownStep("apiKeyService.dispose()", () => apiKeyService.dispose());
    }

    const globalSettingsService = this.getGlobalSettingsService?.();
    if (globalSettingsService) {
      await shutdownStep("globalSettingsService.dispose()", () => globalSettingsService.dispose());
    }

    const ideService = this.getIDEService?.();
    if (ideService) {
      await shutdownStep("ideService.dispose()", () => ideService.dispose());
    }

    const worktreeService = this.getWorktreeService?.();
    if (worktreeService) {
      await shutdownStep("worktreeService.dispose()", () => worktreeService.dispose());
    }

    const deepLinkIpcService = this.getDeepLinkIpcService?.();
    if (deepLinkIpcService) {
      await shutdownStep("deepLinkIpcService.dispose()", () => deepLinkIpcService.dispose());
    }

    const windowService = this.getWindowService?.();
    if (windowService) {
      await shutdownStep("windowService.dispose()", () => windowService.dispose());
    }

    const directoryService = this.getDirectoryService?.();
    if (directoryService) {
      await shutdownStep("directoryService.dispose()", () => directoryService.dispose());
    }

    const gitService = this.getGitService?.();
    if (gitService) {
      await shutdownStep("gitService.dispose()", () => gitService.dispose());
    }

    const systemService = this.getSystemService?.();
    if (systemService) {
      await shutdownStep("systemService.dispose()", () => systemService.dispose());
    }

    const runtimeConfigService = this.getRuntimeConfigService?.();
    if (runtimeConfigService) {
      await shutdownStep("runtimeConfigService.dispose()", () => runtimeConfigService.dispose());
    }

    const claudeCodeService = this.getClaudeCodeService?.();
    if (claudeCodeService) {
      await shutdownStep("claudeCodeService.dispose()", () => claudeCodeService.dispose());
    }

    const artifactIndexService = this.getArtifactIndexService?.();
    if (artifactIndexService) {
      await shutdownStep("artifactIndexService.dispose()", () => artifactIndexService.dispose());
    }

    const issueStorageService = this.getIssueStorageService?.();
    if (issueStorageService) {
      await shutdownStep("issueStorageService.dispose()", () => issueStorageService.dispose());
    }

    unregisterNavigationShortcuts();

    const autoUpdaterService = this.getAutoUpdaterService();
    await shutdownStep("autoUpdaterService.dispose()", () => autoUpdaterService?.dispose());

    const backendProxyService = this.getBackendProxyService();
    if (backendProxyService) {
      await shutdownStep(
        "backendProxyService.dispose()",
        () => backendProxyService.dispose?.() ?? backendProxyService.stop()
      );
    }

    await shutdownStep("stopAgentService()", () => stopAgentService());
    await shutdownStep("stopAgentEventsServer()", () => stopAgentEventsServer());

    const appBootstrapService = this.getAppBootstrapService?.();
    if (appBootstrapService) {
      await shutdownStep("appBootstrapService.dispose()", () => appBootstrapService.dispose());
    }
  }

  registerHandlers(): void {
    app.on("activate", () => {
      if (BrowserWindow.getAllWindows().length === 0) {
        const newWindow = createWindow();
        this.setMainWindow(newWindow);
      }
    });

    app.on("open-url", (event, url) => {
      event.preventDefault();
      void this.deepLinkService.handleDeepLink(url);
    });

    app.on("second-instance", (_event, argv) => {
      const deeplink = argv.find(arg => arg.startsWith(`${appConfig.deepLink.protocol}://`));
      if (deeplink) {
        void this.deepLinkService.handleDeepLink(deeplink);
      }
      const mainWindow = this.getMainWindow();
      if (mainWindow) {
        if (mainWindow.isMinimized()) mainWindow.restore();
        mainWindow.focus();
      }
    });

    app.on("window-all-closed", () => {
      if (process.platform !== "darwin") {
        void app.quit();
      }
    });

    app.on("before-quit", event => {
      if (this.isQuitting) {
        return;
      }

      this.isQuitting = true;
      event.preventDefault();

      void (async () => {
        try {
          await this.shutdownServices();
        } catch (error: unknown) {
          logger.error("Unexpected shutdown error", {
            error: error instanceof Error ? error.message : String(error),
          });
        } finally {
          // Exit explicitly to avoid leaving shutdown work unfinished when Electron continues quitting.
          app.exit(0);
        }
      })();
    });

    process.on("exit", () => {
      stopAgentService();
    });

    logger.info("Lifecycle event handlers registered");
  }
}
