import { getLogger } from "@logtape/logtape";
import type { ApiKeyProviderRef } from "@shared/api-key-provider";
import { setApiKeyProviderRef } from "@shared/api-key-provider";
import { asIpcErrorResponse } from "@shared/ipc-client";
import type { IpcResponse } from "@shared/ipc-types";
import { createIpcSuccess } from "@shared/ipc-utils";
import * as Effect from "effect/Effect";
import * as SubscriptionRef from "effect/SubscriptionRef";
import type { BrowserWindow, IpcMain } from "electron";
import { ApiKeyNotFoundError, type EncryptedApiKeyStore } from "./encrypted-api-key-store";

const logger = getLogger(["frontend", "main", "api-key-service"]);

function isValidSaveApiKeyParams(params: unknown): params is { apiKey: string } {
  return (
    typeof params === "object" &&
    params !== null &&
    "apiKey" in params &&
    typeof (params as { apiKey?: unknown }).apiKey === "string"
  );
}

export interface ApiKeyServiceOptions {
  apiKeyRef: ApiKeyProviderRef;
  apiKeyStore: EncryptedApiKeyStore;
  mainWindow: BrowserWindow;
  ipcMain: IpcMain;
}

export class ApiKeyService {
  private readonly apiKeyRef: ApiKeyProviderRef;
  private readonly apiKeyStore: EncryptedApiKeyStore;
  private readonly mainWindow: BrowserWindow;
  private readonly ipcMain: IpcMain;

  constructor(options: ApiKeyServiceOptions) {
    this.apiKeyRef = options.apiKeyRef;
    this.apiKeyStore = options.apiKeyStore;
    this.mainWindow = options.mainWindow;
    this.ipcMain = options.ipcMain;
    this.registerHandlers();
  }

  dispose(): void {
    this.unregisterHandlers();
  }

  getApiKey(): Effect.Effect<string | null> {
    return SubscriptionRef.get(this.apiKeyRef).pipe(Effect.map(apiKey => apiKey ?? null));
  }

  setApiKey(nextApiKey: string | undefined): Effect.Effect<void> {
    return setApiKeyProviderRef(this.apiKeyRef, nextApiKey);
  }

  private unregisterHandlers(): void {
    // Electron's IpcMain type definitions don't expose removeHandler, but it exists at runtime.
    // We cast to an extended shape so we can unregister handlers and avoid duplicate registrations.
    const ipcMainWithRemoveHandler = this.ipcMain as unknown as {
      removeHandler?: (channel: string) => void;
    };
    ipcMainWithRemoveHandler.removeHandler?.("saveApiKey");
    ipcMainWithRemoveHandler.removeHandler?.("getApiKey");
    ipcMainWithRemoveHandler.removeHandler?.("getApiKeyStatus");
    ipcMainWithRemoveHandler.removeHandler?.("hasApiKey");
    ipcMainWithRemoveHandler.removeHandler?.("deleteApiKey");
  }

  private registerHandlers(): void {
    this.unregisterHandlers();
    this.ipcMain.handle(
      "saveApiKey",
      async (event: Electron.IpcMainInvokeEvent, params: unknown): Promise<IpcResponse<null>> => {
        try {
          if (event.sender.id !== this.mainWindow.webContents.id) {
            logger.warn("Rejected saveApiKey IPC request from untrusted sender", {
              senderId: event.sender.id,
            });
            return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
          }

          if (!isValidSaveApiKeyParams(params)) {
            return asIpcErrorResponse(
              "Invalid parameters: apiKey must be a string",
              "IPC_INVALID_PARAMS"
            );
          }

          const { apiKey } = params;
          await this.apiKeyStore.saveApiKey(apiKey);
          await Effect.runPromise(this.setApiKey(apiKey));
          return createIpcSuccess(null);
        } catch (error: unknown) {
          return asIpcErrorResponse(error, "IPC_SAVE_API_KEY_FAILED");
        }
      }
    );

    // Register getApiKey handler
    this.ipcMain.handle(
      "getApiKey",
      async (
        event: Electron.IpcMainInvokeEvent
      ): Promise<IpcResponse<{ apiKey: string | null }>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected getApiKey IPC request from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        const apiKey = await Effect.runPromise(this.getApiKey());
        return createIpcSuccess({ apiKey });
      }
    );

    // Register getApiKeyStatus handler
    this.ipcMain.handle(
      "getApiKeyStatus",
      async (
        event: Electron.IpcMainInvokeEvent
      ): Promise<IpcResponse<{ hasKey: boolean; isValid: boolean }>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected getApiKeyStatus IPC request from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        const apiKey = await Effect.runPromise(this.getApiKey());
        const hasKey = apiKey !== null;
        return createIpcSuccess({ hasKey, isValid: hasKey });
      }
    );

    // Register hasApiKey handler
    this.ipcMain.handle(
      "hasApiKey",
      async (event: Electron.IpcMainInvokeEvent): Promise<IpcResponse<{ hasKey: boolean }>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected hasApiKey IPC request from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        const apiKey = await Effect.runPromise(this.getApiKey());
        return createIpcSuccess({ hasKey: apiKey !== null });
      }
    );

    // Register deleteApiKey handler
    this.ipcMain.handle(
      "deleteApiKey",
      async (event: Electron.IpcMainInvokeEvent): Promise<IpcResponse<null>> => {
        try {
          if (event.sender.id !== this.mainWindow.webContents.id) {
            logger.warn("Rejected deleteApiKey IPC request from untrusted sender", {
              senderId: event.sender.id,
            });
            return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
          }

          // Delete from secure storage
          await this.apiKeyStore.deleteApiKey();
          // Clear in-memory reference
          await Effect.runPromise(this.setApiKey(undefined));

          logger.info("API key deleted successfully from secure storage and memory");
          return createIpcSuccess(null);
        } catch (error: unknown) {
          logger.error("Failed to delete API key", {
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_DELETE_API_KEY_FAILED");
        }
      }
    );

    logger.info(
      "API key IPC handlers registered: saveApiKey, getApiKey, getApiKeyStatus, hasApiKey, deleteApiKey"
    );
  }

  hydrateApiKey(pendingApiKey: string | null): Effect.Effect<void> {
    if (pendingApiKey) {
      return Effect.tryPromise({
        try: () => this.apiKeyStore.saveApiKey(pendingApiKey),
        catch: (error): unknown => error,
      }).pipe(
        Effect.catchAll((error: unknown) => {
          logger.warn("Failed to persist pending API key to encrypted store", {
            error: error instanceof Error ? error.message : String(error),
          });
          return Effect.succeed(undefined);
        }),
        Effect.zipRight(this.setApiKey(pendingApiKey))
      );
    }

    return Effect.tryPromise({
      try: () => this.apiKeyStore.loadApiKey(),
      catch: (error): unknown => error,
    }).pipe(
      Effect.catchAll((error: unknown) => {
        if (!(error instanceof ApiKeyNotFoundError)) {
          logger.warn("Failed to hydrate API key from encrypted store; continuing without it", {
            error: error instanceof Error ? error.message : String(error),
          });
        }
        return Effect.succeed<string | undefined>(undefined);
      }),
      Effect.flatMap(apiKey => this.setApiKey(apiKey))
    );
  }
}
