import { getLogger } from "@logtape/logtape";
import { asIpcErrorResponse } from "@shared/ipc-client";
import type { IpcResponse } from "@shared/ipc-types";
import { createIpcSuccess } from "@shared/ipc-utils";
import { trim } from "es-toolkit/string";
import { app, clipboard, type BrowserWindow, type IpcMain, type Shell } from "electron";
import { access, constants } from "fs/promises";

const logger = getLogger(["frontend", "main", "system-service"]);

export interface SystemServiceOptions {
  mainWindow: BrowserWindow;
  ipcMain: IpcMain;
  shell: Shell;
  clipboard: typeof clipboard;
  app: typeof app;
}

/**
 * Service for managing system operations (external URLs, app version, clipboard, finder)
 */
export class SystemService {
  private readonly mainWindow: BrowserWindow;
  private readonly ipcMain: IpcMain;
  private readonly shell: Shell;
  private readonly clipboard: typeof clipboard;
  private readonly app: typeof app;

  private static readonly channels = [
    "open-external",
    "app:get-version",
    "clipboard:writeText",
    "finder:reveal",
  ] as const;

  constructor(options: SystemServiceOptions) {
    this.mainWindow = options.mainWindow;
    this.ipcMain = options.ipcMain;
    this.shell = options.shell;
    this.clipboard = options.clipboard;
    this.app = options.app;
    this.registerHandlers();
  }

  public dispose(): void {
    this.unregisterHandlers();
  }

  private registerHandlers(): void {
    this.unregisterHandlers();

    this.ipcMain.handle(
      "open-external",
      async (event: Electron.IpcMainInvokeEvent, url: string): Promise<IpcResponse<null>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected open-external from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        try {
          // Validate URL protocol to prevent opening dangerous links
          const parsedUrl = new URL(url);
          const allowedProtocols = ["http:", "https:", "mailto:"];
          if (!allowedProtocols.includes(parsedUrl.protocol)) {
            logger.warn("Rejected open-external with disallowed protocol", {
              protocol: parsedUrl.protocol,
            });
            return asIpcErrorResponse(
              `Protocol '${parsedUrl.protocol}' is not allowed`,
              "IPC_OPEN_EXTERNAL_INVALID_PROTOCOL"
            );
          }

          await this.shell.openExternal(url);
          return createIpcSuccess(null);
        } catch (error: unknown) {
          logger.error("Failed to open external URL", {
            url,
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_OPEN_EXTERNAL_FAILED");
        }
      }
    );

    this.ipcMain.handle(
      "app:get-version",
      async (event: Electron.IpcMainInvokeEvent): Promise<IpcResponse<string>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected app:get-version from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        try {
          return createIpcSuccess(this.app.getVersion());
        } catch (error: unknown) {
          logger.error("Failed to get app version", {
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_APP_GET_VERSION_FAILED");
        }
      }
    );

    this.ipcMain.handle(
      "clipboard:writeText",
      async (event: Electron.IpcMainInvokeEvent, text: string): Promise<IpcResponse<null>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected clipboard:writeText from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        try {
          this.clipboard.writeText(text);
          return createIpcSuccess(null);
        } catch (error: unknown) {
          logger.error("Failed to write to clipboard", {
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_CLIPBOARD_WRITE_FAILED");
        }
      }
    );

    this.ipcMain.handle(
      "finder:reveal",
      async (event: Electron.IpcMainInvokeEvent, path: string): Promise<IpcResponse<null>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected finder:reveal from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        try {
          // Validate path argument
          if (!path || typeof path !== "string" || trim(path).length === 0) {
            return asIpcErrorResponse(
              "Path is required and must be a non-empty string",
              "IPC_FINDER_REVEAL_INVALID_PATH"
            );
          }

          // Check if path exists
          try {
            await access(path, constants.F_OK);
          } catch {
            return asIpcErrorResponse(
              `Path does not exist: ${path}`,
              "IPC_FINDER_REVEAL_INVALID_PATH"
            );
          }

          await this.shell.showItemInFolder(path);
          return createIpcSuccess(null);
        } catch (error: unknown) {
          logger.error("Failed to reveal path in finder", {
            path,
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_FINDER_REVEAL_FAILED");
        }
      }
    );
  }

  private unregisterHandlers(): void {
    for (const channel of SystemService.channels) {
      this.ipcMain.removeHandler(channel);
    }
  }
}
