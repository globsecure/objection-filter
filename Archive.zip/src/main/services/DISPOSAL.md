# Service disposal patterns

Services in `packages/frontend/src/main/services/` should implement `dispose()` when they manage resources that outlive a single method call, such as:

- timers / intervals
- Electron event listeners (e.g. `app.on`, `ipcMain.handle`, `ipcMain.on`)
- Node servers / sockets
- child processes / long-lived handles

## Current services with disposal

- `AutoUpdaterService` (`auto-updater.ts`): removes `autoUpdater` listeners (best-effort).
- `GlobalSettingsService` (`global-settings-service.ts`): unregisters IPC handlers.
- `ApiKeyService` (`api-key-service.ts`): unregisters IPC handlers.
- `BackendProxyService` (`backend-proxy-service.ts`): closes the HTTP server and removes listeners.
- `AppBootstrapService` (`app-bootstrap.ts`): removes app listeners, unregisters shortcuts, clears port locks.

## Shutdown orchestration

`LifecycleManager` is responsible for calling `dispose()` (with timeout protection) during shutdown and continuing even when a dispose step errors or times out.
