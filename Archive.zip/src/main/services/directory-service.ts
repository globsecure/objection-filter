import { getLogger } from "@logtape/logtape";
import { asIpcErrorResponse } from "@shared/ipc-client";
import type { IpcResponse } from "@shared/ipc-types";
import { createIpcSuccess } from "@shared/ipc-utils";
import { head } from "es-toolkit/array";
import type { BrowserWindow, Dialog, IpcMain } from "electron";

const logger = getLogger(["frontend", "main", "directory-service"]);

export interface DirectoryServiceOptions {
  mainWindow: BrowserWindow;
  ipcMain: IpcMain;
  BrowserWindow: typeof BrowserWindow;
  dialog: Dialog;
}

/**
 * Service for managing directory selection operations
 */
export class DirectoryService {
  private readonly mainWindow: BrowserWindow;
  private readonly ipcMain: IpcMain;
  private readonly BrowserWindow: typeof BrowserWindow;
  private readonly dialog: Dialog;

  private static readonly channels = ["select-directory"] as const;

  constructor(options: DirectoryServiceOptions) {
    this.mainWindow = options.mainWindow;
    this.ipcMain = options.ipcMain;
    this.BrowserWindow = options.BrowserWindow;
    this.dialog = options.dialog;
    this.registerHandlers();
  }

  public dispose(): void {
    this.unregisterHandlers();
  }

  private registerHandlers(): void {
    this.unregisterHandlers();

    this.ipcMain.handle(
      "select-directory",
      async (event: Electron.IpcMainInvokeEvent): Promise<IpcResponse<string | null>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected select-directory from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        try {
          // E2E Testing support: bypass file picker dialog if test path is provided
          const e2eTestPath = process.env.COMPOZY_E2E_TEST_REPO_PATH;
          if (e2eTestPath) {
            logger.debug("E2E test mode: returning test repository path", { path: e2eTestPath });
            return createIpcSuccess(e2eTestPath);
          }

          const window = this.BrowserWindow.fromWebContents(event.sender);
          if (!window) {
            return asIpcErrorResponse("No active BrowserWindow for IPC sender", "IPC_NO_WINDOW");
          }

          const result = await this.dialog.showOpenDialog(window, {
            properties: ["openDirectory"],
            title: "Select Project Directory",
            buttonLabel: "Select Directory",
          });

          if (result.canceled || result.filePaths.length === 0) {
            return createIpcSuccess(null);
          }

          return createIpcSuccess(head(result.filePaths) ?? null);
        } catch (error: unknown) {
          logger.error("Failed to select directory", {
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_SELECT_DIRECTORY_FAILED");
        }
      }
    );
  }

  private unregisterHandlers(): void {
    for (const channel of DirectoryService.channels) {
      this.ipcMain.removeHandler(channel);
    }
  }
}
