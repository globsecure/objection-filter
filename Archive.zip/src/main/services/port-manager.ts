import getPort, { clearLockedPorts, portNumbers } from "get-port";
import type { RuntimeService } from "../../shared/runtime-config";

const DEFAULT_HOST = "127.0.0.1";

export interface PortManagerOptions {
  host?: string;
}

export class PortManager {
  private readonly host: string;
  private readonly allocatedPorts = new Map<RuntimeService, number>();

  constructor(options?: PortManagerOptions) {
    this.host = options?.host ?? DEFAULT_HOST;
  }

  async allocatePort(service: RuntimeService, preferredPort: number): Promise<number> {
    const exclude = this.getAllocatedPorts();
    const fallbackStart = Math.min(preferredPort + 1, 65_535);
    const fallbackEnd = Math.min(fallbackStart + 50, 65_535);
    const fallbackRange = fallbackStart < 65_535 ? portNumbers(fallbackStart, fallbackEnd) : [];
    const preferredPorts = [preferredPort, ...fallbackRange];

    const port = await getPort({
      port: preferredPorts,
      exclude,
      host: this.host,
    });

    this.allocatedPorts.set(service, port);
    return port;
  }

  getAllocatedPort(service: RuntimeService): number | undefined {
    return this.allocatedPorts.get(service);
  }

  getAllocatedPorts(): number[] {
    return Array.from(this.allocatedPorts.values());
  }

  clear(): void {
    this.allocatedPorts.clear();
    clearLockedPorts();
  }
}
