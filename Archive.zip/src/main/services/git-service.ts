import { getLogger } from "@logtape/logtape";
import { asIpcErrorResponse } from "@shared/ipc-client";
import type { IpcResponse } from "@shared/ipc-types";
import { createIpcSuccess } from "@shared/ipc-utils";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import type { BrowserWindow, IpcMain } from "electron";

const logger = getLogger(["frontend", "main", "git-service"]);
const execFileAsync = promisify(execFile);

export interface GitServiceOptions {
  mainWindow: BrowserWindow;
  ipcMain: IpcMain;
}

/**
 * Service for managing Git operations
 */
export class GitService {
  private readonly mainWindow: BrowserWindow;
  private readonly ipcMain: IpcMain;

  private static readonly channels = ["get-git-remote-origin"] as const;

  constructor(options: GitServiceOptions) {
    this.mainWindow = options.mainWindow;
    this.ipcMain = options.ipcMain;
    this.registerHandlers();
  }

  public dispose(): void {
    this.unregisterHandlers();
  }

  private registerHandlers(): void {
    this.unregisterHandlers();

    this.ipcMain.handle(
      "get-git-remote-origin",
      async (
        event: Electron.IpcMainInvokeEvent,
        directoryPath: string
      ): Promise<IpcResponse<string>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected get-git-remote-origin from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        try {
          const origin = await this.getGitRemoteOrigin(directoryPath);
          return createIpcSuccess(origin);
        } catch (error: unknown) {
          logger.error("Failed to get git remote origin", {
            directoryPath,
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_GIT_REMOTE_ORIGIN_FAILED");
        }
      }
    );
  }

  private async getGitRemoteOrigin(directoryPath: string): Promise<string> {
    // E2E Testing support: return mock git remote if test repo name is provided
    const e2eTestRepoName = process.env.COMPOZY_E2E_TEST_REPO_NAME;
    if (e2eTestRepoName) {
      const mockRemote = `git@github.com:test/${e2eTestRepoName}.git`;
      logger.debug("E2E test mode: returning mock git remote", { remote: mockRemote });
      return mockRemote;
    }

    try {
      const { stdout } = await execFileAsync("git", ["config", "--get", "remote.origin.url"], {
        cwd: directoryPath,
        timeout: 5000,
      });
      const origin = stdout.trim();
      if (!origin) {
        throw new Error("No remote origin configured for this Git repository");
      }
      return origin;
    } catch (error) {
      if (error instanceof Error && "code" in error && error.code === "ENOENT") {
        throw new Error("Git is not installed on this system");
      }
      if (error instanceof Error && "stderr" in error && typeof error.stderr === "string") {
        const stderr = error.stderr.toLowerCase();
        if (stderr.includes("not a git repository")) {
          throw new Error("The selected directory is not a Git repository");
        }
      }
      if (error instanceof Error && error.message.includes("No remote origin configured")) {
        throw error;
      }
      throw new Error(
        "Failed to get Git remote origin. Ensure this is a Git repository with a remote origin configured."
      );
    }
  }

  private unregisterHandlers(): void {
    for (const channel of GitService.channels) {
      this.ipcMain.removeHandler(channel);
    }
  }
}
