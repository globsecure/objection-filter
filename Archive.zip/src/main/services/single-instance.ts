import type { App } from "electron";

export function ensureSingleInstance(app: App): boolean {
  const gotLock = app.requestSingleInstanceLock();

  if (!gotLock) {
    app.quit();
    return false;
  }

  return true;
}
