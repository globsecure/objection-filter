import { getLogger } from "@logtape/logtape";
import { asIpcErrorResponse } from "@shared/ipc-client";
import type { IpcResponse } from "@shared/ipc-types";
import { createIpcSuccess } from "@shared/ipc-utils";
import type { BrowserWindow, IpcMain } from "electron";
import type { RuntimeConfig } from "../../shared/runtime-config";

const logger = getLogger(["frontend", "main", "runtime-config-service"]);

export interface RuntimeConfigServiceOptions {
  mainWindow: BrowserWindow;
  ipcMain: IpcMain;
  getRuntimeConfig: () => RuntimeConfig;
}

/**
 * Service for managing runtime configuration access
 */
export class RuntimeConfigService {
  private readonly mainWindow: BrowserWindow;
  private readonly ipcMain: IpcMain;
  private readonly getRuntimeConfig: () => RuntimeConfig;

  private static readonly channels = ["runtime-config:get"] as const;

  constructor(options: RuntimeConfigServiceOptions) {
    this.mainWindow = options.mainWindow;
    this.ipcMain = options.ipcMain;
    this.getRuntimeConfig = options.getRuntimeConfig;
    this.registerHandlers();
  }

  public dispose(): void {
    this.unregisterHandlers();
  }

  private registerHandlers(): void {
    this.unregisterHandlers();

    this.ipcMain.handle(
      "runtime-config:get",
      async (event: Electron.IpcMainInvokeEvent): Promise<IpcResponse<RuntimeConfig>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected runtime-config:get from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        try {
          return createIpcSuccess(this.getRuntimeConfig());
        } catch (error: unknown) {
          logger.error("Failed to get runtime config", {
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_RUNTIME_CONFIG_GET_FAILED");
        }
      }
    );
  }

  private unregisterHandlers(): void {
    for (const channel of RuntimeConfigService.channels) {
      this.ipcMain.removeHandler(channel);
    }
  }
}
