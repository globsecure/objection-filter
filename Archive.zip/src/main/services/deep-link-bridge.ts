import http from "node:http";

import { getLogger } from "@logtape/logtape";
import { createCorsHandler, createHostValidationHandler } from "@shared/security";
import { trim } from "es-toolkit/string";

import { appConfig } from "../config/app-config";
import type { DeepLinkService } from "./deep-link-handler";

const logger = getLogger(["frontend", "main", "deep-link-bridge"]);
const REQUEST_TIMEOUT_MS = 5_000;

export interface DeepLinkBridgeServiceOptions {
  deepLinkService: DeepLinkService;
  port: number;
  allowedOrigins?: string[];
}

export class DeepLinkBridgeService {
  private readonly deepLinkService: DeepLinkService;
  private readonly port: number;
  private readonly allowedOrigins: string[];
  private server: http.Server | null = null;
  private hasDisposed = false;

  constructor(options: DeepLinkBridgeServiceOptions) {
    this.deepLinkService = options.deepLinkService;
    this.port = options.port;
    this.allowedOrigins = options.allowedOrigins ?? appConfig.deepLink.bridgeAllowedOrigins;
  }

  async start(): Promise<void> {
    if (this.server) {
      return;
    }

    const hostValidation = createHostValidationHandler(this.port);
    const cors = createCorsHandler(this.allowedOrigins);

    this.server = http.createServer((req, res) => {
      hostValidation(req, res, () => {
        cors(req, res, () => {
          void this.handleRequest(req, res);
        });
      });
    });

    await new Promise<void>((resolve, reject) => {
      const onError = (err: Error) => reject(err);
      this.server!.once("error", onError);
      this.server!.listen(this.port, "127.0.0.1", () => {
        this.server!.removeListener("error", onError);
        resolve();
      });
    });

    logger.info("Deep link bridge listening", { port: this.port });
  }

  async stop(): Promise<void> {
    const server = this.server;
    this.server = null;
    if (!server) return;

    await new Promise<void>(resolve => {
      server.close(() => resolve());
      // Force-close in-flight connections for graceful shutdown (Node 18.2+)
      if (typeof server.closeAllConnections === "function") {
        server.closeAllConnections();
      }
    });
  }

  async dispose(): Promise<void> {
    if (this.hasDisposed) {
      return;
    }
    this.hasDisposed = true;

    const server = this.server;
    try {
      await this.stop();
    } finally {
      try {
        server?.removeAllListeners();
      } catch {
        // Best-effort cleanup only.
      }
    }
  }

  private async handleRequest(req: http.IncomingMessage, res: http.ServerResponse): Promise<void> {
    const endJson = (status: number, payload: Record<string, unknown>) => {
      if (res.writableEnded) return;
      res.writeHead(status, { "Content-Type": "application/json" });
      res.end(JSON.stringify(payload));
    };

    req.setTimeout(REQUEST_TIMEOUT_MS);

    const requestUrl = new URL(req.url ?? "/", `http://127.0.0.1:${this.port}`);

    if (req.method === "GET" && requestUrl.pathname === "/health") {
      endJson(200, { status: "ok" });
      return;
    }

    if (req.method !== "GET") {
      endJson(405, { error: "Method not allowed" });
      return;
    }

    if (requestUrl.pathname !== "/deep-link") {
      endJson(404, { error: "Not found" });
      return;
    }

    // Note: searchParams.get() automatically URL-decodes the parameter value per the URL Standard.
    // No explicit decodeURIComponent() call is needed.
    const rawToken = requestUrl.searchParams.get("token") ?? "";
    const token = trim(rawToken);

    if (!token) {
      endJson(400, { error: "Token is required" });
      return;
    }

    const deeplinkUrl = `${appConfig.deepLink.protocol}://auth?token=${encodeURIComponent(token)}`;

    try {
      const result = await this.deepLinkService.handleDeepLink(deeplinkUrl);

      if (!result.ok) {
        endJson(400, { error: result.error });
        return;
      }

      endJson(200, { ok: true });
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : String(error);
      logger.error("Failed to process deep link bridge request", { error: message });
      endJson(500, { error: "Failed to process deep link" });
    }
  }
}
