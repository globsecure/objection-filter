import { getLogger } from "@logtape/logtape";
import { validateApiKey } from "@shared/security";
import { BrowserWindow } from "electron";
import { appConfig } from "../config/app-config";
import type { EncryptedApiKeyStore } from "./encrypted-api-key-store";

const logger = getLogger(["frontend", "main", "deep-link-handler"]);

const DEEP_LINK_RATE_LIMIT_WINDOW_MS = 10_000;
const DEEP_LINK_RATE_LIMIT_MAX_CALLS = 5;
const DEEP_LINK_RATE_LIMIT_LOCKOUT_MS = 30_000;

export interface DeepLinkServiceOptions {
  apiKeyStore: EncryptedApiKeyStore | null;
  getMainWindow: () => BrowserWindow | null;
  setApiKey: (apiKey: string | undefined) => void;
  backendBaseUrl: string;
  requestTimeoutMs?: number;
}

export type HandleDeepLinkResult = { ok: true } | { ok: false; error: string };

export class DeepLinkService {
  private readonly apiKeyStore: EncryptedApiKeyStore | null;
  private readonly getMainWindow: () => BrowserWindow | null;
  private readonly setApiKey: (apiKey: string | undefined) => void;
  private readonly backendBaseUrl: string;
  private readonly requestTimeoutMs: number;
  private recentInvocations: number[] = [];
  private rateLimitedUntilMs = 0;
  private pendingApiKey: string | null = null;

  constructor(options: DeepLinkServiceOptions) {
    this.apiKeyStore = options.apiKeyStore;
    this.getMainWindow = options.getMainWindow;
    this.setApiKey = options.setApiKey;
    this.backendBaseUrl = options.backendBaseUrl.replace(/\/+$/, "");
    this.requestTimeoutMs = options.requestTimeoutMs ?? 30_000;
  }

  getPendingApiKey(): string | null {
    return this.pendingApiKey;
  }

  clearPendingApiKey(): void {
    this.pendingApiKey = null;
  }

  private formatDeepLinkForLogging(urlString: string): string {
    try {
      const parsed = new URL(urlString);
      const keys = Array.from(parsed.searchParams.keys());
      keys.sort();
      const location = `${parsed.protocol}//${parsed.host}${parsed.pathname}`;
      return keys.length === 0 ? location : `${location} (params: ${keys.join(", ")})`;
    } catch {
      return "(unparseable deep link)";
    }
  }

  private isRateLimited(nowMs: number): boolean {
    if (this.rateLimitedUntilMs > nowMs) {
      return true;
    }

    this.recentInvocations = this.recentInvocations.filter(
      timestampMs => nowMs - timestampMs < DEEP_LINK_RATE_LIMIT_WINDOW_MS
    );

    if (this.recentInvocations.length >= DEEP_LINK_RATE_LIMIT_MAX_CALLS) {
      this.rateLimitedUntilMs = nowMs + DEEP_LINK_RATE_LIMIT_LOCKOUT_MS;
      this.recentInvocations = [];
      return true;
    }

    this.recentInvocations.push(nowMs);
    return false;
  }

  private isValidCompozyApiKey(apiKey: string): boolean {
    return validateApiKey(apiKey);
  }

  /**
   * Exchanges a one-time token for an API key by calling the backend
   * @throws Error with user-friendly message for various failure scenarios
   */
  private async exchangeTokenForApiKey(token: string): Promise<string> {
    if (!token || token.trim().length === 0) {
      throw new Error("Token is required but was not provided");
    }

    let response: Response;
    try {
      response = await fetch(`${this.backendBaseUrl}/api/v1/api-keys/create-from-token`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ token }),
        signal: AbortSignal.timeout(this.requestTimeoutMs),
      });
    } catch (error) {
      if (error instanceof Error) {
        if (error.name === "TimeoutError" || error.name === "AbortError") {
          throw new Error(
            "Request timed out. Please check your internet connection and try again."
          );
        }
        if (error.message.includes("fetch")) {
          throw new Error(
            "Failed to connect to server. Please check your internet connection and try again."
          );
        }
      }
      throw new Error(`Network error: ${error instanceof Error ? error.message : String(error)}`);
    }

    if (!response.ok) {
      const errorText = await response.text().catch(() => "Unknown error");
      let errorMessage = "Failed to exchange token for API key";

      // Handle specific HTTP status codes
      if (response.status === 401) {
        errorMessage = "Token is invalid or has expired. Please request a new authentication link.";
      } else if (response.status === 400) {
        errorMessage = "Invalid token or request. Please request a new authentication link.";
      } else if (response.status === 404) {
        errorMessage = "Token exchange endpoint not found. Please contact support.";
      } else if (response.status === 429) {
        errorMessage = "Too many requests. Please wait a moment and try again.";
      } else if (response.status >= 500) {
        errorMessage = "Server error. Please try again later or contact support.";
      }

      // Try to parse error message from response
      try {
        const errorJson = JSON.parse(errorText) as {
          ok?: boolean;
          error?: { message?: string; code?: string };
        };
        if (errorJson.error?.message) {
          errorMessage = errorJson.error.message;
        }
      } catch {
        // If parsing fails, use the status-based message or raw text
        if (response.status < 500 && errorText && errorText.length < 200) {
          errorMessage = errorText;
        }
      }

      throw new Error(errorMessage);
    }

    let result: {
      ok: boolean;
      data?: { apiKey?: { key?: string } };
    };
    try {
      result = (await response.json()) as {
        ok: boolean;
        data?: { apiKey?: { key?: string } };
      };
    } catch (error) {
      throw new Error(
        `Invalid response format from server: ${error instanceof Error ? error.message : String(error)}`
      );
    }

    if (!result.ok || !result.data?.apiKey?.key) {
      throw new Error("Token exchange succeeded but no API key was returned");
    }

    return result.data.apiKey.key;
  }

  async handleDeepLink(urlString: string): Promise<HandleDeepLinkResult> {
    const nowMs = Date.now();
    if (this.isRateLimited(nowMs)) {
      logger.warn("Deep link processing rate limited", {
        url: this.formatDeepLinkForLogging(urlString),
      });
      return { ok: false, error: "Deep link processing rate limited" };
    }

    let parsed: URL;
    try {
      parsed = new URL(urlString);
    } catch {
      logger.warn("Deep link processing aborted: URL could not be parsed", {
        url: this.formatDeepLinkForLogging(urlString),
      });
      return { ok: false, error: "Invalid deep link URL" };
    }

    if (parsed.protocol !== `${appConfig.deepLink.protocol}:`) {
      return { ok: true };
    }

    const token = parsed.searchParams.get("token");
    if (!token) {
      const message = "Token is required. Deep link must include a token parameter.";
      logger.error("Deep link received without required token", {
        url: this.formatDeepLinkForLogging(urlString),
        error: message,
      });
      return { ok: false, error: message };
    }

    logger.info("Exchanging one-time token for API key", {
      url: this.formatDeepLinkForLogging(urlString),
    });

    let apiKey: string;
    try {
      apiKey = await this.exchangeTokenForApiKey(token);
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : String(error);
      logger.error("Failed to exchange token for API key", {
        url: this.formatDeepLinkForLogging(urlString),
        error: message,
      });
      return { ok: false, error: message };
    }

    // Validate API key format without exposing the key in logs or errors.
    if (!this.isValidCompozyApiKey(apiKey)) {
      logger.error("Token exchange returned invalid API key format", {
        url: this.formatDeepLinkForLogging(urlString),
        apiKeyLength: apiKey.length,
      });
      return {
        ok: false,
        error: "Invalid API key format received from token exchange. Expected format: compozy_*",
      };
    }

    this.pendingApiKey = apiKey;

    if (this.apiKeyStore) {
      try {
        await this.apiKeyStore.saveApiKey(apiKey);
        this.setApiKey(apiKey);
      } catch (error: unknown) {
        const message = error instanceof Error ? error.message : String(error);
        logger.error("Failed to persist API key from deep link", {
          url: this.formatDeepLinkForLogging(urlString),
          error: message,
        });
        return { ok: false, error: message };
      }
    }

    const mainWindow = this.getMainWindow();
    if (mainWindow) {
      mainWindow.webContents.send("deep-link-api-key", apiKey);
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }

    return { ok: true };
  }
}
