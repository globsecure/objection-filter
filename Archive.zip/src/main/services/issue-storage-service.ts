import { getLogger } from "@logtape/logtape";
import { asIpcErrorResponse } from "@shared/ipc-client";
import type { IpcResponse } from "@shared/ipc-types";
import { createIpcSuccess } from "@shared/ipc-utils";
import { getIssueDir, isValidIssueId } from "@shared/issue-path";
import type { BrowserWindow, IpcMain } from "electron";
import { trim } from "es-toolkit/string";
import * as fs from "node:fs/promises";

const logger = getLogger(["frontend", "main", "issue-storage-service"]);

export interface IssueStorageServiceOptions {
  mainWindow: BrowserWindow;
  ipcMain: IpcMain;
}

type IssueStorageDeletePayload = {
  issueId: string;
};

type IssueStorageDeleteResult = {
  issueId: string;
  status: "deleted" | "missing";
};

function parseDeletePayload(payload: unknown): IssueStorageDeletePayload | null {
  if (!payload || typeof payload !== "object") return null;
  const raw = payload as Record<string, unknown>;
  const issueId = typeof raw.issueId === "string" ? trim(raw.issueId) : "";
  if (!isValidIssueId(issueId)) return null;
  return { issueId };
}

export class IssueStorageService {
  private readonly mainWindow: BrowserWindow;
  private readonly ipcMain: IpcMain;

  private static readonly channels = ["issue-storage:delete"] as const;

  constructor(options: IssueStorageServiceOptions) {
    this.mainWindow = options.mainWindow;
    this.ipcMain = options.ipcMain;
    this.registerHandlers();
  }

  public dispose(): void {
    this.unregisterHandlers();
  }

  private registerHandlers(): void {
    this.unregisterHandlers();

    this.ipcMain.handle(
      "issue-storage:delete",
      async (
        event: Electron.IpcMainInvokeEvent,
        payload: unknown
      ): Promise<IpcResponse<IssueStorageDeleteResult>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected issue-storage:delete from untrusted sender", {
            senderId: event.sender.id,
          });
          return asIpcErrorResponse("Unauthorized sender", "IPC_UNAUTHORIZED_SENDER");
        }

        const parsed = parseDeletePayload(payload);
        if (!parsed) {
          return asIpcErrorResponse("Invalid payload", "IPC_INVALID_PAYLOAD");
        }

        try {
          const issueDir = getIssueDir(parsed.issueId);
          let status: IssueStorageDeleteResult["status"] = "deleted";

          try {
            await fs.rm(issueDir, { recursive: true });
          } catch (error) {
            const nodeError = error as NodeJS.ErrnoException;
            if (nodeError.code === "ENOENT") {
              status = "missing";
            } else {
              throw error;
            }
          }

          return createIpcSuccess({ issueId: parsed.issueId, status });
        } catch (error: unknown) {
          logger.error("Failed to delete issue storage", {
            issueId: parsed.issueId,
            error: error instanceof Error ? error.message : String(error),
          });
          return asIpcErrorResponse(error, "IPC_ISSUE_STORAGE_DELETE_FAILED");
        }
      }
    );
  }

  private unregisterHandlers(): void {
    for (const channel of IssueStorageService.channels) {
      this.ipcMain.removeHandler(channel);
    }
  }
}
