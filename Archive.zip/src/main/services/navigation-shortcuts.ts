import { BrowserWindow, globalShortcut } from "electron";
import { getLogger } from "@logtape/logtape";

const logger = getLogger(["frontend", "main", "navigation-shortcuts"]);

/**
 * Registers global keyboard shortcuts for browser navigation
 * - Cmd+[ (or Ctrl+[ on Windows/Linux) for back navigation
 * - Cmd+] (or Ctrl+] on Windows/Linux) for forward navigation
 *
 * These shortcuts work system-wide and integrate with TanStack Router's
 * browser history through webContents.goBack() and webContents.goForward()
 */
export function registerNavigationShortcuts(): void {
  // Use CommandOrControl for cross-platform support
  // On macOS: Command+[ and Command+]
  // On Windows/Linux: Ctrl+[ and Ctrl+]
  const backAccelerator = "CommandOrControl+[";
  const forwardAccelerator = "CommandOrControl+]";

  // Register back navigation shortcut
  const backRegistered = globalShortcut.register(backAccelerator, () => {
    const focusedWindow = BrowserWindow.getFocusedWindow();
    if (!focusedWindow) {
      logger.debug("No focused window for back navigation");
      return;
    }

    const webContents = focusedWindow.webContents;
    if (webContents.canGoBack()) {
      webContents.goBack();
      logger.debug("Navigated back via keyboard shortcut");
    } else {
      logger.debug("Cannot go back - no history");
    }
  });

  if (!backRegistered) {
    logger.warn("Failed to register back navigation shortcut", {
      accelerator: backAccelerator,
    });
  } else {
    logger.info("Registered back navigation shortcut", { accelerator: backAccelerator });
  }

  // Register forward navigation shortcut
  const forwardRegistered = globalShortcut.register(forwardAccelerator, () => {
    const focusedWindow = BrowserWindow.getFocusedWindow();
    if (!focusedWindow) {
      logger.debug("No focused window for forward navigation");
      return;
    }

    const webContents = focusedWindow.webContents;
    if (webContents.canGoForward()) {
      webContents.goForward();
      logger.debug("Navigated forward via keyboard shortcut");
    } else {
      logger.debug("Cannot go forward - no history");
    }
  });

  if (!forwardRegistered) {
    logger.warn("Failed to register forward navigation shortcut", {
      accelerator: forwardAccelerator,
    });
  } else {
    logger.info("Registered forward navigation shortcut", { accelerator: forwardAccelerator });
  }
}

/**
 * Unregisters all navigation shortcuts
 * Should be called when the app is quitting to prevent memory leaks
 */
export function unregisterNavigationShortcuts(): void {
  globalShortcut.unregister("CommandOrControl+[");
  globalShortcut.unregister("CommandOrControl+]");
  logger.info("Unregistered navigation shortcuts");
}
