import { isPlainObject } from "es-toolkit/predicate";
import { trim } from "es-toolkit/string";

export const DEV_HINT_CHECK =
  "Auto-updates are disabled in development. Build the app to test updates, or set COMPOZY_DEV_UPDATES=1 to enable dev update checks.";

export const DEV_HINT_DOWNLOAD =
  "Auto-updates are disabled in development. Build the app to download/install updates.";

function isTruthyEnvValue(value: string | undefined): boolean {
  if (!value) return false;
  const normalized = value.toLowerCase();
  return normalized === "1" || normalized === "true" || normalized === "yes" || normalized === "on";
}

export function isUpdaterDevMode(options: { isPackaged: boolean; nodeEnv?: string }): boolean {
  return !options.isPackaged || options.nodeEnv === "development";
}

export function areDevUpdatesEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  return isTruthyEnvValue(env.COMPOZY_DEV_UPDATES);
}

export function isUpdater404Error(error: unknown): boolean {
  if (!error) return false;
  if (error instanceof Error) {
    const statusCode = (error as { statusCode?: number }).statusCode;
    const code = (error as { code?: string }).code;
    if (statusCode === 404) return true;
    if (code === "ERR_UPDATER_CHANNEL_FILE_NOT_FOUND") return true;
    if (code === "ERR_UPDATER_LATEST_VERSION_NOT_FOUND") return true;
    if (code === "ERR_UPDATER_NO_PUBLISHED_VERSIONS") return true;
    return error.message.toLowerCase().includes("404");
  }

  if (isPlainObject(error)) {
    const statusCode = (error as { statusCode?: number }).statusCode;
    const message = (error as { message?: unknown }).message;
    if (statusCode === 404) return true;
    if (typeof message === "string" && message.toLowerCase().includes("404")) return true;
  }

  if (typeof error === "string") {
    return error.toLowerCase().includes("404");
  }

  return false;
}

function isNetworkError(error: Error): boolean {
  const code = (error as { code?: unknown }).code;
  if (typeof code === "string") {
    if (code === "ECONNRESET") return true;
    if (code === "ECONNREFUSED") return true;
    if (code === "ENOTFOUND") return true;
    if (code === "EAI_AGAIN") return true;
    if (code === "ETIMEDOUT") return true;
  }

  const message = error.message.toLowerCase();
  if (message.includes("net::")) return true;
  if (message.includes("network")) return true;
  if (message.includes("socket hang up")) return true;
  if (message.includes("econnreset")) return true;
  if (message.includes("econnrefused")) return true;
  if (message.includes("enotfound")) return true;
  if (message.includes("timed out")) return true;
  return false;
}

function redactSecrets(text: string): string {
  let result = text;

  // Query string / key-value secrets
  result = result.replace(
    /(token|access_token|authorization|auth|api_key|apikey)=([^\s&#]+)/gi,
    (_match, key) => `${key}=[REDACTED]`
  );

  // Authorization headers
  result = result.replace(/(authorization:\s*)([^\s]+)/gi, (_m, prefix) => `${prefix}[REDACTED]`);
  result = result.replace(/(bearer\s+)([^\s]+)/gi, (_m, prefix) => `${prefix}[REDACTED]`);

  // GitHub token formats
  result = result.replace(/\bgh[pousr]_[A-Za-z0-9]{20,}\b/g, "[REDACTED]");

  return result;
}

function sanitizeTextForUser(text: string): string {
  const redacted = redactSecrets(text);
  // Keep user display single-line and short-ish.
  return trim(redacted.replace(/\s+/g, " "));
}

function sanitizeValue(value: unknown): unknown {
  if (typeof value === "string") return redactSecrets(value);
  if (value instanceof Error) {
    return {
      name: value.name,
      message: redactSecrets(value.message),
      stack: value.stack ? redactSecrets(value.stack) : undefined,
      code: (value as { code?: unknown }).code,
      statusCode: (value as { statusCode?: unknown }).statusCode,
    };
  }
  if (Array.isArray(value)) return value.map(item => sanitizeValue(item));
  if (isPlainObject(value)) {
    const record = value as Record<string, unknown>;
    const sanitized: Record<string, unknown> = {};
    for (const [key, entry] of Object.entries(record)) {
      const keyLower = key.toLowerCase();
      if (
        keyLower.includes("token") ||
        keyLower.includes("authorization") ||
        keyLower.includes("api")
      ) {
        sanitized[key] = "[REDACTED]";
      } else {
        sanitized[key] = sanitizeValue(entry);
      }
    }
    return sanitized;
  }
  return value;
}

export function sanitizeUpdaterLogArgs(args: unknown[]): unknown[] {
  return args.map(arg => sanitizeValue(arg));
}

export function formatUpdaterError(error: Error): string {
  if (isUpdater404Error(error)) {
    return "No updates available.";
  }

  if (isNetworkError(error)) {
    return "Network error while checking for updates. Please check your connection and try again.";
  }

  const message = error.message.length > 0 ? error.message : String(error);
  const sanitized = sanitizeTextForUser(message);
  return sanitized.length > 0 ? sanitized : "Unexpected error while checking for updates.";
}
