import { is } from "@electron-toolkit/utils";
import { getLogger } from "@logtape/logtape";
import { app, BrowserWindow, dialog, shell, type RenderProcessGoneDetails } from "electron";
import { join } from "path";
import { getWindowConfig } from "../config/window-config";
import { captureMainException } from "../utils/sentry";

const logger = getLogger(["frontend", "main", "window-manager"]);

// Constants
const WINDOW_TITLE = "Compozy";
const FILE_PROTOCOL = "file://";
const RELOAD_KEY = "r";
const RELOAD_RESET_DELAY_MS = 1_000;

// Environment variable names
const ENV_RENDERER_CRASH_RECOVERY = "COMPOZY_RENDERER_CRASH_RECOVERY";
const ENV_ELECTRON_RENDERER_URL = "ELECTRON_RENDERER_URL";

// Recovery mode values
const RECOVERY_MODE_OFF = "off";
const RECOVERY_MODE_RELOAD = "reload";
const RECOVERY_MODE_RECREATE = "recreate";
const RECOVERY_MODE_DISABLED_VALUES = ["0", "false"];

// Crash reason values
const CRASH_REASON_CLEAN_EXIT = "clean-exit";
const CRASH_REASON_KILLED = "killed";

// Sentry tags
const SENTRY_PHASE_RUNTIME = "runtime";
const SENTRY_COMPONENT_RENDERER = "renderer";

// Dialog messages
const DIALOG_TITLE_WINDOW_LOAD_ERROR = "Window Load Error";
const DIALOG_MESSAGE_LOAD_FAILED =
  "Failed to load the application after multiple attempts. Please restart the application.\n\n";
const DIALOG_ERROR_PREFIX = "Error: ";
const DIALOG_ERROR_CODE_PREFIX = " (code: ";
const DIALOG_ERROR_CODE_SUFFIX = ")";

// Electron event names
const EVENT_BEFORE_QUIT = "before-quit";
const EVENT_RENDER_PROCESS_GONE = "render-process-gone";
const EVENT_PAGE_TITLE_UPDATED = "page-title-updated";
const EVENT_READY_TO_SHOW = "ready-to-show";
const EVENT_CLOSED = "closed";
const EVENT_DID_FINISH_LOAD = "did-finish-load";
const EVENT_DID_FAIL_LOAD = "did-fail-load";
const EVENT_BEFORE_INPUT_EVENT = "before-input-event";

// Window action values
const WINDOW_ACTION_DENY = "deny";

type RendererCrashRecoveryMode = "off" | "reload" | "recreate";

let hasRegisteredQuitListener = false;
let isAppQuitting = false;

const hasAttachedCrashHandler = new WeakSet<BrowserWindow>();
const recoveryAttemptedForWindow = new WeakSet<BrowserWindow>();
let lastRecoveryAttemptAtMs = 0;
const RECOVERY_COOLDOWN_MS = 5_000;

function ensureQuitListenerRegistered(): void {
  if (hasRegisteredQuitListener) return;
  hasRegisteredQuitListener = true;

  app.on(EVENT_BEFORE_QUIT, () => {
    isAppQuitting = true;
  });
}

function readEnv(key: string): string | undefined {
  const env = import.meta.env as Record<string, string | undefined>;
  return env[key] ?? process.env[key];
}

function getRendererCrashRecoveryMode(): RendererCrashRecoveryMode {
  const raw = readEnv(ENV_RENDERER_CRASH_RECOVERY)?.trim().toLowerCase();
  if (!raw || raw === RECOVERY_MODE_OFF || RECOVERY_MODE_DISABLED_VALUES.includes(raw)) {
    return RECOVERY_MODE_OFF;
  }
  if (raw === RECOVERY_MODE_RECREATE) return RECOVERY_MODE_RECREATE;
  if (raw === RECOVERY_MODE_RELOAD) return RECOVERY_MODE_RELOAD;
  return RECOVERY_MODE_RELOAD;
}

function shouldAttemptRecovery(details: RenderProcessGoneDetails): boolean {
  if (details.reason === CRASH_REASON_CLEAN_EXIT) return false;
  if (details.reason === CRASH_REASON_KILLED) return false;
  return true;
}

function safeGetWindowId(window: BrowserWindow): number | undefined {
  try {
    return window.id;
  } catch {
    return undefined;
  }
}

function safeGetWindowUrl(window: BrowserWindow): string | undefined {
  try {
    return window.webContents.getURL();
  } catch {
    return undefined;
  }
}

async function loadWindowContentAsync(window: BrowserWindow): Promise<void> {
  if (is.dev && process.env[ENV_ELECTRON_RENDERER_URL]) {
    await window.loadURL(process.env[ENV_ELECTRON_RENDERER_URL]);
    return;
  }

  // Use CommonJS __dirname directly
  await window.loadFile(join(__dirname, "../renderer/index.html"));
}

function recoverByReload(window: BrowserWindow, details: RenderProcessGoneDetails): void {
  void loadWindowContentAsync(window).catch((error: unknown) => {
    logger.error("Failed to recover from renderer crash (reload)", {
      reason: details.reason,
      exitCode: details.exitCode,
      windowId: safeGetWindowId(window),
      error: error instanceof Error ? error.message : String(error),
    });
  });
}

function attachRenderProcessCrashHandler(
  window: BrowserWindow,
  options?: {
    onWindowRecreated?: (nextWindow: BrowserWindow, previousWindow: BrowserWindow) => void;
  }
): void {
  if (hasAttachedCrashHandler.has(window)) return;
  hasAttachedCrashHandler.add(window);

  ensureQuitListenerRegistered();

  window.webContents.on(EVENT_RENDER_PROCESS_GONE, (_event, details) => {
    const { reason, exitCode } = details;

    if (reason === CRASH_REASON_CLEAN_EXIT) {
      logger.debug("Renderer process exited cleanly", {
        reason,
        exitCode,
        windowId: safeGetWindowId(window),
      });
      return;
    }

    logger.error("Renderer process unexpectedly disappeared", {
      reason,
      exitCode,
      url: safeGetWindowUrl(window),
      windowId: safeGetWindowId(window),
    });

    captureMainException(new Error(`Renderer process gone: ${reason} (exit code: ${exitCode})`), {
      phase: SENTRY_PHASE_RUNTIME,
      component: SENTRY_COMPONENT_RENDERER,
      reason,
      exitCode,
      url: safeGetWindowUrl(window),
      windowId: safeGetWindowId(window),
    });

    if (isAppQuitting) {
      logger.info("Skipping renderer crash recovery because the app is quitting", {
        reason,
        exitCode,
      });
      return;
    }

    if (window.isDestroyed() || window.webContents.isDestroyed()) {
      logger.info("Skipping renderer crash recovery because the window is destroyed", {
        reason,
        exitCode,
      });
      return;
    }

    const mode = getRendererCrashRecoveryMode();
    if (mode === RECOVERY_MODE_OFF) {
      logger.info("Renderer crash recovery is disabled", { reason, exitCode });
      return;
    }

    if (!shouldAttemptRecovery(details)) {
      logger.info("Renderer crash recovery skipped for this reason", { reason, exitCode });
      return;
    }

    if (recoveryAttemptedForWindow.has(window)) {
      logger.info("Renderer crash recovery already attempted for this window", {
        reason,
        exitCode,
      });
      return;
    }
    recoveryAttemptedForWindow.add(window);

    const now = Date.now();
    if (now - lastRecoveryAttemptAtMs < RECOVERY_COOLDOWN_MS) {
      logger.info("Skipping renderer crash recovery because it recently ran", {
        reason,
        exitCode,
        cooldownMs: RECOVERY_COOLDOWN_MS,
      });
      return;
    }
    lastRecoveryAttemptAtMs = now;

    logger.info("Attempting renderer crash recovery", { mode, reason, exitCode });

    if (mode === RECOVERY_MODE_RELOAD) {
      recoverByReload(window, details);
      return;
    }

    if (options?.onWindowRecreated) {
      try {
        const nextWindow = createWindow();
        options.onWindowRecreated(nextWindow, window);
      } catch (error: unknown) {
        logger.error("Failed to recover from renderer crash (recreate)", {
          reason,
          exitCode,
          error: error instanceof Error ? error.message : String(error),
        });
      }
      return;
    }

    logger.warn(
      "Renderer crash recovery mode is 'recreate' but no handler is configured; falling back to reload",
      {
        reason,
        exitCode,
      }
    );
    recoverByReload(window, details);
  });
}

// Reload retry configuration
const MAX_RELOAD_RETRIES = 3;
const BASE_RELOAD_DELAY_MS = 100;

// Per-window retry state (keyed by window id)
const reloadRetryState = new Map<number, { count: number; lastAttempt: number }>();

/**
 * Gets the retry state for a window, initializing if needed
 */
function getRetryState(windowId: number): { count: number; lastAttempt: number } {
  if (!reloadRetryState.has(windowId)) {
    reloadRetryState.set(windowId, { count: 0, lastAttempt: 0 });
  }
  return reloadRetryState.get(windowId)!;
}

/**
 * Resets the retry state for a window (called on successful load)
 */
function resetRetryState(windowId: number): void {
  reloadRetryState.set(windowId, { count: 0, lastAttempt: 0 });
}

/**
 * Cleans up retry state when a window is destroyed
 */
function cleanupRetryState(windowId: number): void {
  reloadRetryState.delete(windowId);
}

/**
 * Calculates exponential backoff delay for retry attempts
 */
function getExponentialBackoffDelay(retryCount: number): number {
  return BASE_RELOAD_DELAY_MS * Math.pow(2, retryCount);
}

/**
 * Creates the main application window object without loading content
 * Used when window reference is needed before content loading (e.g., for IPC layer setup)
 */
export function createWindowObject(options?: {
  onWindowRecreated?: (nextWindow: BrowserWindow, previousWindow: BrowserWindow) => void;
}): BrowserWindow {
  const config = getWindowConfig();
  const mainWindow = new BrowserWindow(config);

  attachRenderProcessCrashHandler(mainWindow, options);

  // Prevent page title from overriding window title
  mainWindow.webContents.on(EVENT_PAGE_TITLE_UPDATED, event => {
    event.preventDefault();
    mainWindow.setTitle(WINDOW_TITLE);
  });

  mainWindow.on(EVENT_READY_TO_SHOW, () => {
    mainWindow.maximize();
    mainWindow.show();
  });

  // Clean up retry state when window is destroyed
  mainWindow.on(EVENT_CLOSED, () => {
    cleanupRetryState(mainWindow.id);
  });

  // Reset retry state on successful load
  mainWindow.webContents.on(EVENT_DID_FINISH_LOAD, () => {
    resetRetryState(mainWindow.id);
  });

  mainWindow.webContents.setWindowOpenHandler(details => {
    shell.openExternal(details.url);
    return { action: WINDOW_ACTION_DENY };
  });

  // Handle reload failures in production (file:// protocol)
  // When Cmd+R is pressed, Electron reloads the page, but browser history mode
  // router doesn't work well with file:// protocol reloads, causing blank screens.
  // We intercept failed loads and reload the file properly with retry protection.
  mainWindow.webContents.on(
    EVENT_DID_FAIL_LOAD,
    (_event, errorCode, errorDescription, validatedURL, isMainFrame) => {
      // Only handle main frame failures in production (file:// protocol)
      if (!isMainFrame || is.dev) {
        return;
      }

      const url = validatedURL;
      // Check if this is a file:// URL failure (production build)
      if (url.startsWith(FILE_PROTOCOL)) {
        const retryState = getRetryState(mainWindow.id);

        // Check if we've exceeded max retries
        if (retryState.count >= MAX_RELOAD_RETRIES) {
          logger.error("Max reload retries exceeded, showing error to user", {
            url,
            errorCode,
            errorDescription,
            retryCount: retryState.count,
          });

          // Show error dialog to user
          dialog.showErrorBox(
            DIALOG_TITLE_WINDOW_LOAD_ERROR,
            DIALOG_MESSAGE_LOAD_FAILED +
              `${DIALOG_ERROR_PREFIX}${errorDescription}${DIALOG_ERROR_CODE_PREFIX}${errorCode}${DIALOG_ERROR_CODE_SUFFIX}`
          );

          // Reset retry state after showing error to allow manual recovery
          resetRetryState(mainWindow.id);
          return;
        }

        // Increment retry count
        retryState.count++;
        retryState.lastAttempt = Date.now();

        const delay = getExponentialBackoffDelay(retryState.count - 1);

        logger.warn("Failed to load file:// URL, retrying with exponential backoff", {
          url,
          errorCode,
          errorDescription,
          retryCount: retryState.count,
          maxRetries: MAX_RELOAD_RETRIES,
          delayMs: delay,
        });

        // Reload with exponential backoff
        setTimeout(() => {
          if (!mainWindow.isDestroyed() && !mainWindow.webContents.isDestroyed()) {
            loadWindowContent(mainWindow);
          }
        }, delay);
      }
    }
  );

  // Intercept reload attempts to ensure proper reload behavior
  // This handles cases where the default reload might not work correctly with file:// protocol
  let isReloading = false;
  mainWindow.webContents.on(EVENT_BEFORE_INPUT_EVENT, (event, input) => {
    // Intercept Cmd+R (macOS) or Ctrl+R (Windows/Linux)
    const isReloadShortcut =
      (input.control || input.meta) &&
      input.key.toLowerCase() === RELOAD_KEY &&
      !input.shift &&
      !input.alt;

    if (isReloadShortcut && !isReloading) {
      // In production, use our custom reload to ensure proper file loading
      if (!is.dev) {
        event.preventDefault();
        isReloading = true;

        // Reload using loadWindowContent instead of default reload
        // This ensures the file:// URL is loaded correctly
        loadWindowContent(mainWindow);

        // Reset flag after a delay to allow reload to complete
        setTimeout(() => {
          isReloading = false;
        }, RELOAD_RESET_DELAY_MS);
      }
    }
  });

  return mainWindow;
}

/**
 * Loads content into an existing window
 */
export function loadWindowContent(window: BrowserWindow): void {
  void loadWindowContentAsync(window);
}

/**
 * Creates the main application window and loads content
 *
 * NOTE: On macOS in development mode, the Dock and menu bar will show "Electron" as the app name
 * even though the window title is correctly set to "Compozy". This is because macOS uses the
 * executable name from the Electron.app bundle (CFBundleName in Info.plist), which is only
 * customized when packaging the app. The window title itself IS set correctly to "Compozy".
 *
 * In production builds, electron-builder sets the proper CFBundleName/CFBundleDisplayName,
 * so the app name will show correctly everywhere.
 */
export function createWindow(options?: {
  onWindowRecreated?: (nextWindow: BrowserWindow, previousWindow: BrowserWindow) => void;
}): BrowserWindow {
  const window = createWindowObject(options);
  attachRenderProcessCrashHandler(window, options);
  loadWindowContent(window);
  return window;
}
