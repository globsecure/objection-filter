/**
 * Claude Code Environment Settings Reader
 * Provides direct access to Claude Code env settings from electron-store
 * for use in executors and agents running in the main process.
 */

import { getLogger } from "@logtape/logtape";
import { mkdirSync } from "node:fs";
import Store from "electron-store";
import { getCompozyHomeDir } from "@shared/repository-key";
import {
  DEFAULT_CLAUDE_CODE_ENV_SETTINGS,
  sanitizeClaudeCodeEnvSettings,
  type ClaudeCodeEnvSettings,
  type GlobalSettings,
} from "../../shared/global-settings";

const logger = getLogger(["frontend", "main", "claude-code-env-reader"]);

let cachedStore: Store<GlobalSettings> | null = null;

function getSettingsStore(): Store<GlobalSettings> {
  if (cachedStore) {
    return cachedStore;
  }

  const cwd = getCompozyHomeDir();
  mkdirSync(cwd, { recursive: true });

  cachedStore = new Store<GlobalSettings>({
    cwd,
    name: "settings",
    fileExtension: "json",
    clearInvalidConfig: false,
  });

  return cachedStore;
}

/**
 * Reads Claude Code environment settings from the global settings store.
 * This function is safe to call from executors and agents in the main process.
 */
export function getClaudeCodeEnvSettings(): ClaudeCodeEnvSettings {
  try {
    const store = getSettingsStore();
    const storedRaw: unknown = store.get("claudeCodeEnv");
    return sanitizeClaudeCodeEnvSettings(storedRaw);
  } catch (error: unknown) {
    logger.warn("Failed to read claudeCodeEnv from store; falling back to defaults", {
      error: error instanceof Error ? error.message : String(error),
    });
    return { ...DEFAULT_CLAUDE_CODE_ENV_SETTINGS };
  }
}

/**
 * Builds environment variables from Claude Code settings.
 * Returns a record that can be spread into the process environment.
 */
export function buildClaudeCodeEnvVars(): Record<string, string> {
  const settings = getClaudeCodeEnvSettings();
  const env: Record<string, string> = {};

  if (settings.anthropicBaseUrl) {
    env.ANTHROPIC_BASE_URL = settings.anthropicBaseUrl;
  }
  if (settings.anthropicAuthToken) {
    env.ANTHROPIC_AUTH_TOKEN = settings.anthropicAuthToken;
  }
  if (settings.anthropicApiKey !== undefined && settings.anthropicApiKey !== "") {
    env.ANTHROPIC_API_KEY = settings.anthropicApiKey;
  }
  if (settings.defaultHaikuModel) {
    env.ANTHROPIC_DEFAULT_HAIKU_MODEL = settings.defaultHaikuModel;
  }
  if (settings.defaultSonnetModel) {
    env.ANTHROPIC_DEFAULT_SONNET_MODEL = settings.defaultSonnetModel;
  }
  if (settings.defaultOpusModel) {
    env.ANTHROPIC_DEFAULT_OPUS_MODEL = settings.defaultOpusModel;
  }
  if (settings.customEnvVars) {
    Object.assign(env, settings.customEnvVars);
  }

  return env;
}
