import net from "node:net";
import { setTimeout as sleep } from "node:timers/promises";

export async function waitForBackend({
  port,
  host,
  retries = 40,
  delayMs = 250,
}: {
  port: number;
  host: string;
  retries?: number;
  delayMs?: number;
}) {
  for (let attempt = 0; attempt < retries; attempt += 1) {
    const isReachable = await new Promise<boolean>(resolvePromise => {
      const socket = net.createConnection({ port, host }, () => {
        socket.destroy();
        resolvePromise(true);
      });
      socket.on("error", () => {
        socket.destroy();
        resolvePromise(false);
      });
    });
    if (isReachable) {
      return;
    }
    await sleep(delayMs);
  }
  throw new Error(`Backend not reachable at http://${host}:${port} after startup window`);
}
