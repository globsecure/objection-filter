import type * as Sentry from "@sentry/electron/main";

/**
 * Sensitive data patterns to filter from Sentry events
 */
const SENSITIVE_HEADERS = new Set([
  "x-api-key",
  "authorization",
  "x-auth-token",
  "cookie",
  "set-cookie",
]);

const SENSITIVE_CONTEXT_KEYS = new Set([
  "apikey",
  "api_key",
  "token",
  "password",
  "secret",
  "authtoken",
  "auth_token",
  "bearer",
  "accesstoken",
  "access_token",
  "refreshtoken",
  "refresh_token",
]);

const SENSITIVE_ENV_PATTERNS = [/KEY/i, /TOKEN/i, /SECRET/i, /PASSWORD/i, /AUTH/i, /CREDENTIAL/i];

/**
 * Recursively filters sensitive data from an object
 */
function filterSensitiveObject(obj: unknown, depth = 0): unknown {
  // Prevent infinite recursion
  if (depth > 10) {
    return "[Max depth reached]";
  }

  if (obj === null || obj === undefined) {
    return obj;
  }

  if (typeof obj !== "object") {
    return obj;
  }

  if (Array.isArray(obj)) {
    return obj.map(item => filterSensitiveObject(item, depth + 1));
  }

  const filtered: Record<string, unknown> = {};

  for (const [key, value] of Object.entries(obj)) {
    const lowerKey = key.toLowerCase();

    // Skip sensitive context keys
    if (SENSITIVE_CONTEXT_KEYS.has(lowerKey)) {
      filtered[key] = "[Filtered]";
      continue;
    }

    // Skip sensitive environment variables
    if (SENSITIVE_ENV_PATTERNS.some(pattern => pattern.test(key))) {
      filtered[key] = "[Filtered]";
      continue;
    }

    // Recursively filter nested objects
    filtered[key] = filterSensitiveObject(value, depth + 1);
  }

  return filtered;
}

/**
 * Filters sensitive headers from request data
 */
function filterSensitiveHeaders(
  headers: Record<string, unknown> | undefined
): Record<string, unknown> | undefined {
  if (!headers || typeof headers !== "object") {
    return headers;
  }

  const filtered: Record<string, unknown> = {};

  for (const [key, value] of Object.entries(headers)) {
    const lowerKey = key.toLowerCase();
    if (SENSITIVE_HEADERS.has(lowerKey)) {
      filtered[key] = "[Filtered]";
    } else {
      filtered[key] = value;
    }
  }

  return filtered;
}

/**
 * Filters sensitive data from Sentry events before sending
 * Removes API keys, tokens, passwords, and other sensitive information
 */
export function filterSensitiveData(event: Sentry.ErrorEvent): Sentry.ErrorEvent | null {
  // Create a shallow copy to avoid mutating Sentry's original event object.
  const filtered: Sentry.ErrorEvent = { ...event };

  // Filter request headers
  if (filtered.request?.headers) {
    filtered.request = {
      ...filtered.request,
      headers: filterSensitiveHeaders(
        filtered.request.headers as Record<string, unknown>
      ) as Record<string, string>,
    };
  }

  // Filter extra context data
  if (filtered.extra) {
    filtered.extra = filterSensitiveObject(filtered.extra) as Record<string, unknown>;
  }

  // Filter tags (shouldn't contain sensitive data, but be safe)
  if (filtered.tags) {
    filtered.tags = filterSensitiveObject(filtered.tags) as Record<string, string>;
  }

  // Filter user data (preserve structure but filter sensitive fields)
  if (filtered.user) {
    const filteredUser: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(filtered.user)) {
      const lowerKey = key.toLowerCase();
      if (SENSITIVE_CONTEXT_KEYS.has(lowerKey)) {
        filteredUser[key] = "[Filtered]";
      } else {
        filteredUser[key] = value;
      }
    }
    filtered.user = filteredUser as typeof filtered.user;
  }

  // Filter breadcrumbs that might contain sensitive data
  if (filtered.breadcrumbs) {
    filtered.breadcrumbs = filtered.breadcrumbs.map(breadcrumb => {
      if (breadcrumb.data) {
        return {
          ...breadcrumb,
          data: filterSensitiveObject(breadcrumb.data) as Record<string, unknown>,
        };
      }
      return breadcrumb;
    });
  }

  return filtered;
}
