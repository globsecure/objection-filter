import { dirname } from "path";
import { fileURLToPath } from "url";

/**
 * Gets the __filename and __dirname for ES modules
 *
 * NOTE: This utility is for ESM modules. The main process now uses CommonJS format,
 * so __dirname is available directly without this utility. This function is kept
 * for potential future ESM code that might need it.
 *
 * @param importMetaUrl - The import.meta.url value from the calling module
 * @returns An object with __filename and __dirname
 */
export function getModulePaths(importMetaUrl: string) {
  const __filename = fileURLToPath(importMetaUrl);
  const __dirname = dirname(__filename);
  return { __filename, __dirname };
}
