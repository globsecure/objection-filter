/**
 * Claude Code Detection Utility
 *
 * Detects whether Claude Code CLI is installed and accessible on the system.
 * Uses the same multi-stage fallback resolution as the Claude executor.
 */

import { accessSync, existsSync, constants as fsConstants } from "node:fs";
import { createRequire } from "node:module";
import path from "node:path";

const nodeRequire = createRequire(import.meta.url);

const WINDOWS_PATH_EXTENSIONS = process.env.PATHEXT?.split(";").filter(Boolean) ?? [
  ".exe",
  ".cmd",
  ".bat",
  ".com",
];

const PATH_DELIMITER = process.platform === "win32" ? ";" : ":";

const MANUAL_PATH_ENV_KEYS = [
  "CLAUDE_CODE_EXECUTABLE",
  "CLAUDE_CODE_PATH",
  "ANTHROPIC_CLAUDE_CODE_PATH",
];

const FALLBACK_PATHS = [
  "/opt/homebrew/bin/claude",
  "/usr/local/bin/claude",
  process.env.HOME ? path.join(process.env.HOME, ".npm-global/bin/claude") : undefined,
  process.env.USERPROFILE
    ? path.join(process.env.USERPROFILE, ".npm-global/bin/claude")
    : undefined,
].filter((candidate): candidate is string => Boolean(candidate));

export interface ClaudeCodeDetectionResult {
  isInstalled: boolean;
  executablePath: string | undefined;
}

function isExecutable(candidate: string | undefined): candidate is string {
  if (!candidate) {
    return false;
  }
  try {
    accessSync(candidate, fsConstants.X_OK);
    return true;
  } catch {
    return existsSync(candidate);
  }
}

function resolveFromEnv(): string | undefined {
  for (const key of MANUAL_PATH_ENV_KEYS) {
    const value = process.env[key];
    if (isExecutable(value)) {
      return value;
    }
  }
  return undefined;
}

function resolveFromModuleInstall(): string | undefined {
  try {
    const resolved = nodeRequire.resolve("@anthropic-ai/claude-agent-sdk/cli.js");
    if (isExecutable(resolved)) {
      return resolved;
    }
  } catch {
    // Module may be bundled elsewhere
  }
  return undefined;
}

function resolveFromSystemPath(): string | undefined {
  const pathEnv = process.env.PATH;
  if (!pathEnv) {
    return undefined;
  }
  const extensions = process.platform === "win32" ? WINDOWS_PATH_EXTENSIONS : [""];
  for (const directory of pathEnv.split(PATH_DELIMITER)) {
    if (!directory) continue;
    for (const ext of extensions) {
      const candidate = path.join(directory, `claude${ext}`);
      if (isExecutable(candidate)) {
        return candidate;
      }
    }
  }
  return undefined;
}

function resolveFromFallbacks(): string | undefined {
  for (const candidate of FALLBACK_PATHS) {
    if (isExecutable(candidate)) {
      return candidate;
    }
  }
  return undefined;
}

let cachedResult: ClaudeCodeDetectionResult | undefined;

/**
 * Detects whether Claude Code is installed and returns the result.
 * Result is cached for the app lifetime to avoid repeated filesystem checks.
 */
export function detectClaudeCodeInstallation(): ClaudeCodeDetectionResult {
  if (cachedResult) {
    return cachedResult;
  }
  const executablePath =
    resolveFromEnv() ??
    resolveFromModuleInstall() ??
    resolveFromSystemPath() ??
    resolveFromFallbacks();
  cachedResult = {
    isInstalled: executablePath !== undefined,
    executablePath,
  };
  return cachedResult;
}

/**
 * Clears the cached detection result.
 * Call this when user requests a fresh detection after installing Claude Code.
 */
export function clearClaudeCodeDetectionCache(): void {
  cachedResult = undefined;
}
