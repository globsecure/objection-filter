import * as Sentry from "@sentry/electron/main";
import { app } from "electron";
import { filterSensitiveData } from "./sentry-filter";

const dsn = import.meta.env?.VITE_SENTRY_DSN;
const isDev = import.meta.env?.DEV ?? false;
const environment = isDev ? "development" : "production";

/**
 * Initialize Sentry in the Electron main process
 * Sets up error tracking, performance monitoring, and global error handlers
 */
export function initMainSentry(): void {
  if (!dsn) return;
  if (Sentry.isInitialized()) return;

  const release = app.getVersion();

  Sentry.init({
    dsn,
    debug: isDev,
    environment,
    release,
    tracesSampleRate: isDev ? 1.0 : 0.1, // 100% in dev, 10% in prod
    beforeSend(event) {
      // Only filter error events, other event types pass through unchanged
      // ErrorEvent has type === undefined, transaction events have type === 'transaction'
      if (event.type === undefined) {
        return filterSensitiveData(event);
      }
      return event;
    },
    initialScope: {
      tags: {
        "app.name": app.getName(),
        "app.version": release,
      },
    },
  });

  // Set up global error handlers
  setupGlobalErrorHandlers();
}

/**
 * Set up global error handlers for uncaught exceptions and unhandled rejections
 */
function setupGlobalErrorHandlers(): void {
  // Handle uncaught exceptions
  process.on("uncaughtException", (error: Error) => {
    captureMainException(error, {
      source: "uncaughtException",
      fatal: true,
    });
    // Log to console as well
    console.error("Uncaught exception:", error);
    // In production, we might want to allow the process to crash
    // In development, we can continue for debugging
    if (!isDev) {
      // Optionally crash the process for critical errors
      // process.exit(1);
    }
  });

  // Handle unhandled promise rejections
  process.on("unhandledRejection", (reason: unknown, promise: Promise<unknown>) => {
    const error = reason instanceof Error ? reason : new Error(String(reason));
    captureMainException(error, {
      source: "unhandledRejection",
      promiseType: promise?.constructor?.name ?? "Promise",
    });
    // Log to console as well
    console.error("Unhandled rejection:", reason);
  });
}

/**
 * Capture an exception in the main process
 * @param error - The error to capture
 * @param context - Additional context to include with the error
 */
export function captureMainException(error: unknown, context?: Record<string, unknown>): void {
  if (!dsn) return;
  if (!Sentry.isInitialized()) return;

  Sentry.captureException(error, {
    extra: context,
  });
}

/**
 * Set user context for Sentry events
 * Call this when user authentication state changes
 */
export function setSentryUser(
  user: { id: string; email?: string; username?: string } | null
): void {
  if (!dsn) return;
  if (!Sentry.isInitialized()) return;

  Sentry.setUser(user);
}
