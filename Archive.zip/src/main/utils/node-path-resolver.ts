import { getLogger } from "@logtape/logtape";
import { spawnSync } from "node:child_process";
import { chmodSync, existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";

const logger = getLogger(["frontend", "main", "node-path-resolver"]);

/** Application name used for production detection and user directory paths */
const APP_NAME = "compozy";

const WINDOWS_NODE_EXTENSIONS = process.env.PATHEXT?.split(";").filter(Boolean) ?? [
  ".exe",
  ".cmd",
  ".bat",
  ".com",
];

function isElectronProduction(): boolean {
  if (typeof process.resourcesPath !== "undefined" && process.resourcesPath) {
    return true;
  }

  if (typeof process.execPath === "string") {
    const execPath = process.execPath.toLowerCase();
    if (execPath.includes(".app/contents/macos") || execPath.includes(APP_NAME)) {
      return true;
    }
  }

  return false;
}

function resolveSystemNodePath(): string | undefined {
  const commonPaths = [
    "/usr/local/bin/node",
    "/opt/homebrew/bin/node",
    "/usr/bin/node",
    process.env.HOME
      ? path.join(process.env.HOME, ".nvm/versions/node/current/bin/node")
      : undefined,
    process.env.HOME
      ? path.join(process.env.HOME, ".fnm/node-versions/current/installation/bin/node")
      : undefined,
  ].filter((p): p is string => Boolean(p));

  for (const nodePath of commonPaths) {
    if (existsSync(nodePath)) {
      logger.debug("Found Node.js at system path", { path: nodePath });
      return nodePath;
    }
  }

  try {
    const command = process.platform === "win32" ? "where" : "which";
    const whichResult = spawnSync(command, ["node"], {
      encoding: "utf-8",
      timeout: 1000,
    });
    if (whichResult.status === 0 && whichResult.stdout) {
      const resolvedPath = whichResult.stdout.trim().split(/\r?\n/)[0];
      if (resolvedPath && existsSync(resolvedPath)) {
        logger.debug(`Found Node.js via '${command}' command`, { path: resolvedPath });
        return resolvedPath;
      }
    }
  } catch (error) {
    logger.debug("Failed to use path lookup command to find node", { error });
  }

  return undefined;
}

export function resolveNodeExecutablePath(): {
  executable: string;
  useElectronRuntime: boolean;
} {
  const isProduction = isElectronProduction();

  if (isProduction) {
    logger.debug("Using Electron bundled Node.js runtime for production build", {
      execPath: process.execPath,
    });
    return {
      executable: "node",
      useElectronRuntime: true,
    };
  }

  const systemNodePath = resolveSystemNodePath();
  if (systemNodePath) {
    logger.debug("Using system Node.js for development", { path: systemNodePath });
    return {
      executable: systemNodePath,
      useElectronRuntime: false,
    };
  }

  logger.warn(
    "Could not resolve Node.js path, falling back to 'node' from PATH. This may fail in production builds."
  );
  return {
    executable: "node",
    useElectronRuntime: false,
  };
}

function resolveNodeFromPath(pathValue?: string): string | undefined {
  const separator = process.platform === "win32" ? ";" : ":";
  const currentPath = pathValue ?? process.env.PATH ?? "";
  if (!currentPath) {
    return undefined;
  }

  const parts = currentPath.split(separator).filter(Boolean);
  const extensions = process.platform === "win32" ? WINDOWS_NODE_EXTENSIONS : [""];

  for (const directory of parts) {
    for (const ext of extensions) {
      const candidate = path.join(directory, `node${ext}`);
      if (existsSync(candidate)) {
        return candidate;
      }
    }
  }

  return undefined;
}

function buildNodeShimContent(executablePath: string): string {
  if (process.platform === "win32") {
    return ["@echo off", 'set "ELECTRON_RUN_AS_NODE=1"', `"${executablePath}" %*`, ""].join("\r\n");
  }

  return ["#!/bin/sh", "export ELECTRON_RUN_AS_NODE=1", `exec "${executablePath}" "$@"`, ""].join(
    "\n"
  );
}

function getNodeShimDirectory(): string {
  return path.join(os.homedir(), `.${APP_NAME}`, "bin");
}

/**
 * Ensures a `node` command is available on PATH when running the packaged Electron app.
 *
 * Creates a shim in the user's ~/.compozy/bin directory that forwards to the Electron
 * binary with ELECTRON_RUN_AS_NODE enabled. Returns the shim directory if created.
 */
export function ensureNodeOnPath(pathValue?: string): string | undefined {
  if (!isElectronProduction()) {
    return undefined;
  }

  // Always ensure our Electron-backed `node` shim is first on PATH in production.
  //
  // Why: Claude Agent SDK spawns `node <path-to-cli.js>` and checks existence of
  // the CLI path using Electron's patched fs (supports `app.asar`). If the spawned
  // `node` is a system Node (e.g. from nvm), it won't understand `.asar` paths and
  // will fail at runtime with "Claude Code process exited with code 1".
  //
  // On machines that already have `node` on PATH (nvm/homebrew), we still need to
  // prefer the Electron shim so that CLI execution can read `app.asar` files.
  const existingNode = resolveNodeFromPath(pathValue);
  if (existingNode) {
    logger.debug("Node runtime available on PATH; ensuring Electron shim takes precedence", {
      existingNode,
    });
  }

  const shimDir = getNodeShimDirectory();
  const shimName = process.platform === "win32" ? "node.cmd" : "node";
  const shimPath = path.join(shimDir, shimName);
  const shimContent = buildNodeShimContent(process.execPath);

  try {
    mkdirSync(shimDir, { recursive: true });

    const shouldWrite = !existsSync(shimPath) || readFileSync(shimPath, "utf8") !== shimContent;

    if (shouldWrite) {
      writeFileSync(shimPath, shimContent, { encoding: "utf8" });
      if (process.platform !== "win32") {
        chmodSync(shimPath, 0o755);
      }
      logger.debug("Created Node shim for Electron runtime", { shimPath });
    } else {
      logger.debug("Node shim already up to date", { shimPath });
    }

    return shimDir;
  } catch (error) {
    logger.warn("Failed to create Node shim for Electron runtime", {
      error: error instanceof Error ? error.message : String(error),
      shimPath,
    });
    return undefined;
  }
}

/**
 * Gets the directory containing the Electron binary.
 * This directory should be added to PATH so that "node" resolves to the Electron binary.
 *
 * @returns Directory path containing the Electron binary, or undefined if not in production
 */
export function getElectronBinaryDirectory(): string | undefined {
  const isProduction = isElectronProduction();
  if (!isProduction) {
    return undefined;
  }
  return path.dirname(process.execPath);
}

/**
 * Adds a directory to PATH environment variable, handling platform-specific separators.
 *
 * @param pathValue - Current PATH value
 * @param directory - Directory to add to PATH
 * @returns Updated PATH value with directory prepended
 */
export function addDirectoryToPath(pathValue: string | undefined, directory: string): string {
  const separator = process.platform === "win32" ? ";" : ":";
  const currentPath = pathValue || process.env.PATH || "";
  const parts = currentPath.split(separator).filter(Boolean);

  if (!parts.includes(directory)) {
    parts.unshift(directory);
  }

  return parts.join(separator);
}
