import { getLogger } from "@logtape/logtape";
import { compact } from "es-toolkit/array";
import { trim } from "es-toolkit/string";
import { execSync } from "node:child_process";
import os from "node:os";
import path from "node:path";

const logger = getLogger(["frontend", "main", "fix-path"]);

export function fixPathForElectron(): void {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const fixPath = require("fix-path");
    if (typeof fixPath === "function") {
      fixPath();
      logger.debug("Applied fix-path library");
    }
  } catch (error) {
    logger.debug("fix-path library not available or failed", {
      error: error instanceof Error ? error.message : String(error),
    });
  }

  if (process.platform === "darwin") {
    fixPathForMacOS();
  } else if (process.platform === "linux") {
    fixPathForLinux();
  } else if (process.platform === "win32") {
    fixPathForWindows();
  }
}

function splitPathEntries(rawPath: string, delimiter: string): string[] {
  return compact(
    rawPath.split(delimiter).map(entry => {
      const cleaned = trim(entry);
      return cleaned.length > 0 ? cleaned : null;
    })
  );
}

function prependPathEntries(
  currentParts: string[],
  extras: string[]
): { parts: string[]; added: string[] } {
  const parts = [...currentParts];
  const added: string[] = [];

  for (const extraPath of extras) {
    if (!parts.includes(extraPath)) {
      parts.unshift(extraPath);
      added.push(extraPath);
    }
  }

  return { parts, added };
}

function mergeShellPath(shell: string): void {
  const delimiter = process.platform === "win32" ? ";" : ":";
  const currentPath = process.env.PATH ?? "";
  const currentParts = splitPathEntries(currentPath, delimiter);

  logger.debug("Attempting to merge PATH from login shell", {
    shell,
    currentEntries: currentParts.length,
  });

  try {
    const loginPath = execSync(`${shell} -ilc 'echo -n $PATH'`, {
      encoding: "utf8",
      // Some user shells (oh-my-zsh, nvm, asdf) can take a couple seconds to initialize.
      // Keep this bounded but generous enough to avoid missing PATH entries for CLIs.
      timeout: 5000,
      maxBuffer: 1024 * 1024,
      windowsHide: true,
      stdio: ["ignore", "pipe", "ignore"],
    });

    const trimmedLoginPath = trim(loginPath);
    if (!trimmedLoginPath) {
      logger.debug("Login shell PATH query returned empty output", { shell });
      return;
    }

    const loginParts = splitPathEntries(trimmedLoginPath, delimiter);
    // Prefer login-shell PATH ordering so GUI-launched Electron apps behave like the user's shell.
    // This mirrors patterns used by similar Electron apps (e.g., emdash) to ensure nvm/homebrew
    // binaries resolve consistently.
    const merged = new Set<string>();
    const added: string[] = [];

    for (const entry of loginParts) {
      if (!merged.has(entry)) {
        merged.add(entry);
        if (!currentParts.includes(entry)) {
          added.push(entry);
        }
      }
    }

    for (const entry of currentParts) {
      if (!merged.has(entry)) {
        merged.add(entry);
      }
    }

    const mergedPath = Array.from(merged).join(delimiter);
    if (mergedPath === currentPath) {
      logger.debug("PATH already matches login shell ordering", {
        shell,
        loginEntries: loginParts.length,
      });
      return;
    }

    process.env.PATH = mergedPath;
    logger.debug("Merged PATH from login shell", {
      shell,
      addedEntries: added.length,
      loginEntries: loginParts.length,
      previousEntries: currentParts.length,
    });
  } catch (error) {
    logger.debug("Failed to query login shell for PATH", {
      shell,
      error: error instanceof Error ? error.message : String(error),
    });
  }
}

export function fixPathForMacOS(): void {
  const extras = ["/opt/homebrew/bin", "/usr/local/bin", "/opt/homebrew/sbin", "/usr/local/sbin"];

  const currentPath = process.env.PATH || "";
  const { parts, added } = prependPathEntries(splitPathEntries(currentPath, ":"), extras);

  process.env.PATH = parts.join(":");
  logger.debug("Augmented PATH for macOS", {
    extras,
    addedExtras: added,
  });

  const shell = process.env.SHELL || "/bin/zsh";
  mergeShellPath(shell);
}

export function fixPathForLinux(): void {
  try {
    const homeDir = os.homedir();
    const extras = [
      path.join(homeDir, ".nvm/versions/node", process.version, "bin"),
      path.join(homeDir, ".npm-global/bin"),
      path.join(homeDir, ".local/bin"),
      path.join(homeDir, ".cargo/bin"),
      path.join(homeDir, ".asdf/shims"),
      "/usr/local/bin",
    ];

    const currentPath = process.env.PATH || "";
    const { parts, added } = prependPathEntries(splitPathEntries(currentPath, ":"), extras);

    process.env.PATH = parts.join(":");
    logger.debug("Augmented PATH for Linux", {
      extras,
      addedExtras: added,
    });

    const shell = process.env.SHELL || "/bin/bash";
    mergeShellPath(shell);
  } catch (error) {
    logger.warn("Failed to fix PATH for Linux", {
      error: error instanceof Error ? error.message : String(error),
    });
  }
}

function getWindowsNpmPathCandidates(): string[] {
  const candidates: string[] = [];

  const appData = process.env.APPDATA;
  if (appData) {
    candidates.push(path.win32.join(appData, "npm"));
  }

  const npmPrefix = process.env.npm_config_prefix ?? process.env.NPM_CONFIG_PREFIX;
  if (npmPrefix) {
    // npm prefix is user-configurable; global binaries might live in the prefix root or prefix\\bin.
    candidates.push(npmPrefix, path.win32.join(npmPrefix, "bin"));
  }

  return candidates;
}

export function fixPathForWindows(): void {
  try {
    const appData = process.env.APPDATA;
    if (!appData && !process.env.npm_config_prefix && !process.env.NPM_CONFIG_PREFIX) {
      logger.debug("APPDATA and npm_config_prefix not set, skipping npm path fix");
      return;
    }

    const currentPath = process.env.PATH || "";
    const extras = getWindowsNpmPathCandidates();

    if (extras.length === 0) {
      logger.debug("No npm path candidates found, skipping PATH augmentation");
      return;
    }

    const { parts, added } = prependPathEntries(splitPathEntries(currentPath, ";"), extras);

    process.env.PATH = parts.join(";");
    logger.debug("Augmented PATH for Windows", {
      extras,
      addedExtras: added,
    });
  } catch (error) {
    logger.warn("Failed to fix PATH for Windows", {
      error: error instanceof Error ? error.message : String(error),
    });
  }
}
