import type { BrowserWindowConstructorOptions } from "electron";
import { screen } from "electron";
import { join } from "path";
// Import icons using ?asset suffix - electron-vite handles path resolution automatically
// Note: BrowserWindow icon property only works on Windows and Linux, NOT macOS
// macOS icon must be set via electron-builder configuration and app.dock.setIcon()
import winIcon from "../../../build/icon.ico?asset";
import linuxIcon from "../../../build/icon.png?asset";

function shouldEnableTitleBarOverlay(): boolean {
  return process.platform === "linux";
}

/**
 * Gets the icon path for the current platform
 * IMPORTANT: BrowserWindow icon property only works on Windows and Linux
 * macOS icon must be configured via electron-builder and app.dock.setIcon()
 * See: https://electron-vite.org/guide/dev.html#importing-asset-as-file-path
 */
function getIconPath(): string | undefined {
  // Don't set icon for macOS - it doesn't work in BrowserWindow
  if (process.platform === "darwin") {
    return undefined;
  }

  // Use ?asset imports which electron-vite handles correctly
  // in both dev and production
  if (process.platform === "win32") {
    return winIcon;
  } else if (process.platform === "linux") {
    return linuxIcon;
  }

  return undefined;
}

export function getWindowConfig(): BrowserWindowConstructorOptions {
  const iconPath = getIconPath();
  const isWindows = process.platform === "win32";
  const isMac = process.platform === "darwin";
  // Get primary display work area size (excludes taskbar/dock)
  const { width, height } = screen.getPrimaryDisplay().workAreaSize;

  return {
    width,
    height,
    show: false,
    title: "Compozy",
    autoHideMenuBar: true,
    titleBarStyle: isWindows ? "default" : "hidden",
    ...(isMac ? { trafficLightPosition: { x: 16, y: 16 } } : {}),
    ...(shouldEnableTitleBarOverlay() ? { titleBarOverlay: true } : {}),
    ...(iconPath ? { icon: iconPath } : {}),
    webPreferences: {
      // Preload script uses CommonJS format
      preload: join(__dirname, "../preload/index.js"),
      // Security: Enable sandbox for renderer process isolation
      sandbox: true,
      // Security: Context isolation is enabled by default in Electron 12+
      contextIsolation: true,
      // Security: Disable Node.js integration in renderer
      nodeIntegration: false,
    },
  };
}
