import { createUrl, parseUrl } from "@shared/server-config";
import toInteger from "es-toolkit/compat/toInteger";
import { compact, uniq } from "es-toolkit/array";
import { trim } from "es-toolkit/string";

import {
  DEFAULT_AGENT_EVENTS_PORT,
  DEFAULT_AGENT_PORT,
  DEFAULT_BACKEND_PORT,
  DEFAULT_BACKEND_PROXY_PORT,
  DEFAULT_LOOPER_PORT,
} from "../../shared/config/defaultPorts";

const readEnv = (
  key:
    | "VITE_BACKEND_URL"
    | "VITE_BACKEND_PROXY_URL"
    | "VITE_AGENT_API_URL"
    | "VITE_LOOPER_API_URL"
    | "VITE_AGENT_EVENTS_URL"
    | "VITE_DESKTOP_PROTOCOL"
    | "VITE_DEEP_LINK_BRIDGE_PORT"
    | "VITE_DEEP_LINK_BRIDGE_ALLOWED_ORIGINS"
    | "VITE_WEB_APP_URL"
): string | undefined => {
  const env = import.meta.env as Record<string, string | undefined>;
  return env[key] ?? process.env[key];
};

function createServiceConfig(
  envUrl: string | undefined,
  defaultPort: number,
  defaultHost = "127.0.0.1"
) {
  const url = envUrl ?? createUrl(defaultHost, defaultPort);
  const parsed = parseUrl(url, defaultPort);

  let _url = url;
  let _host = parsed.host;
  let _port = parsed.port;

  return {
    get url() {
      return _url;
    },
    set url(value: string) {
      _url = value;
      const parsed = parseUrl(value, defaultPort);
      _host = parsed.host;
      _port = parsed.port;
    },
    get host() {
      return _host;
    },
    set host(value: string) {
      _host = value;
      _url = createUrl(value, _port);
    },
    get port() {
      return _port;
    },
    set port(value: number) {
      _port = value;
      _url = createUrl(_host, value);
    },
  };
}

function withServiceOptions<T extends Record<string, unknown>>(
  config: ReturnType<typeof createServiceConfig>,
  options: T
): ReturnType<typeof createServiceConfig> & T {
  const reservedKeys = ["url", "host", "port"] as const;
  const conflictingKeys = Object.keys(options).filter(key =>
    reservedKeys.includes(key as (typeof reservedKeys)[number])
  );

  if (conflictingKeys.length > 0) {
    throw new Error(`Options cannot override reserved keys: ${conflictingKeys.join(", ")}`);
  }

  Object.entries(options).forEach(([key, value]) => {
    Object.defineProperty(config, key, {
      value,
      enumerable: true,
      configurable: true,
      writable: true,
    });
  });

  return config as ReturnType<typeof createServiceConfig> & T;
}

const DEFAULT_DEEP_LINK_BRIDGE_PORT = 24_861;
const DEFAULT_DEEP_LINK_BRIDGE_ALLOWED_ORIGINS = [
  "http://localhost:3001",
  "http://127.0.0.1:3001",
  "https://app.compozy.com",
  "https://app-staging.compozy.com",
  "https://compozy.com",
];

const parseOrigin = (value: string | undefined): string | null => {
  if (!value) return null;
  const cleaned = trim(value);
  if (!cleaned) return null;
  try {
    return new URL(cleaned).origin;
  } catch (error) {
    console.warn(`[app-config] Invalid origin URL ignored: "${cleaned}"`, error);
    return null;
  }
};

const parseOriginList = (value: string | undefined): string[] => {
  if (!value) return [];
  const parts = value.split(/[,\s]+/);
  return compact(parts.map(entry => parseOrigin(entry)));
};

const deepLinkProtocol = readEnv("VITE_DESKTOP_PROTOCOL") ?? "compozy";
const deepLinkBridgePortCandidate = toInteger(
  readEnv("VITE_DEEP_LINK_BRIDGE_PORT") ?? DEFAULT_DEEP_LINK_BRIDGE_PORT
);
const deepLinkBridgePort =
  deepLinkBridgePortCandidate > 0 ? deepLinkBridgePortCandidate : DEFAULT_DEEP_LINK_BRIDGE_PORT;
const deepLinkBridgeAllowedOrigins = uniq(
  compact([
    ...DEFAULT_DEEP_LINK_BRIDGE_ALLOWED_ORIGINS,
    parseOrigin(readEnv("VITE_WEB_APP_URL")),
    ...parseOriginList(readEnv("VITE_DEEP_LINK_BRIDGE_ALLOWED_ORIGINS")),
  ])
);

export const appConfig = {
  backend: withServiceOptions(
    createServiceConfig(readEnv("VITE_BACKEND_URL"), DEFAULT_BACKEND_PORT),
    {
      healthCheck: {
        retriesInDev: 40,
        retriesInProd: 80,
        delayMs: 250,
      },
    }
  ),
  backendProxy: createServiceConfig(readEnv("VITE_BACKEND_PROXY_URL"), DEFAULT_BACKEND_PROXY_PORT),
  agents: withServiceOptions(
    createServiceConfig(readEnv("VITE_AGENT_API_URL"), DEFAULT_AGENT_PORT),
    {
      healthCheck: {
        retriesInDev: 30,
        retriesInProd: 60,
        delayMs: 500,
      },
    }
  ),
  looper: createServiceConfig(readEnv("VITE_LOOPER_API_URL"), DEFAULT_LOOPER_PORT),
  agentEventsServer: createServiceConfig(
    readEnv("VITE_AGENT_EVENTS_URL"),
    DEFAULT_AGENT_EVENTS_PORT
  ),
  app: {
    userModelId: "com.electron",
  },
  deepLink: {
    protocol: deepLinkProtocol,
    bridgePort: deepLinkBridgePort,
    bridgeAllowedOrigins: deepLinkBridgeAllowedOrigins,
  },
};

export type AppConfig = typeof appConfig;
