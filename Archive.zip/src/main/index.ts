// APP_CONFIG_SEED is automatically injected by Vite at build time via electron.vite.config.ts
// In development: reads from .env file automatically
// In production: embedded from CI/CD environment variables (cannot be overridden)

import {
  makeApiKeyProviderRef,
  setApiKeyProviderRef,
  type ApiKeyProviderRef,
} from "@shared/api-key-provider";
import * as Effect from "effect/Effect";
import { app, BrowserWindow, clipboard, dialog, ipcMain, shell } from "electron";
import macIcon from "../../build/icon.icns?asset";
import { buildRuntimeConfig, type RuntimeConfig } from "../shared/runtime-config";
import { WorktreeService } from "../worktree/services/worktree-service";
import { appConfig } from "./config/app-config";
import { ApiKeyService } from "./services/api-key-service";
import { AppBootstrapService } from "./services/app-bootstrap";
import { ArtifactIndexService } from "./services/artifact-index-service";
import type { AutoUpdaterService } from "./services/auto-updater";
import type { BackendProxyService } from "./services/backend-proxy-service";
import { ClaudeCodeService } from "./services/claude-code-service";
import { DeepLinkService } from "./services/deep-link-handler";
import { DeepLinkIpcService } from "./services/deep-link-ipc-service";
import { DirectoryService } from "./services/directory-service";
import { EncryptedApiKeyStore } from "./services/encrypted-api-key-store";
import { GitService } from "./services/git-service";
import { GlobalSettingsService } from "./services/global-settings-service";
import { IDEService } from "./services/ide-service";
import { IssueStorageService } from "./services/issue-storage-service";
import { LifecycleManager } from "./services/lifecycle-manager";
import { MacDockIconService } from "./services/mac-dock-icon";
import { PortManager } from "./services/port-manager";
import { RuntimeConfigService } from "./services/runtime-config-service";
import { ensureSingleInstance } from "./services/single-instance";
import { SystemService } from "./services/system-service";
import { createWindowObject } from "./services/window-manager";
import { WindowService } from "./services/window-service";
import { fixPathForElectron } from "./utils/fix-path";
import { captureMainException, initMainSentry } from "./utils/sentry";

const API_URL = (
  import.meta.env.VITE_BACKEND_URL ??
  process.env.VITE_BACKEND_URL ??
  "http://127.0.0.1:3002"
).replace(/\/+$/, "");

// Global state
let mainWindow: BrowserWindow | null = null;
let backendProxyService: BackendProxyService | null = null;
let autoUpdaterService: AutoUpdaterService | null = null;
let globalSettingsService: GlobalSettingsService | null = null;
let ideService: IDEService | null = null;
let worktreeService: WorktreeService | null = null;
let deepLinkIpcService: DeepLinkIpcService | null = null;
let windowService: WindowService | null = null;
let directoryService: DirectoryService | null = null;
let gitService: GitService | null = null;
let systemService: SystemService | null = null;
let runtimeConfigService: RuntimeConfigService | null = null;
let claudeCodeService: ClaudeCodeService | null = null;
let artifactIndexService: ArtifactIndexService | null = null;
let issueStorageService: IssueStorageService | null = null;
let runtimeConfig!: RuntimeConfig;

initMainSentry();

fixPathForElectron();

// Ensure single instance
const hasSingleInstanceLock = ensureSingleInstance(app);
if (!hasSingleInstanceLock) {
  app.quit();
}

if (hasSingleInstanceLock) {
  // Initialize port manager and initial runtime config
  const portManager = new PortManager();
  runtimeConfig = buildRuntimeConfig({
    host: appConfig.agents.host,
    agentsPort: appConfig.agents.port,
    looperPort: appConfig.looper.port,
    agentEventsPort: appConfig.agentEventsServer.port,
    backendProxyPort: appConfig.backendProxy.port,
  });

  // Set app name early - must happen before app.whenReady() to affect window titles and menus
  // NOTE: On macOS in development mode, the Dock and menu bar will show "Electron" because
  // macOS uses the executable name from Electron.app bundle. app.setName() only affects
  // internal Electron APIs, not the OS-level app name. In production, electron-builder
  // sets CFBundleName/CFBundleDisplayName in Info.plist, so the app name shows correctly.
  app.setName("Compozy");

  // Initialize services
  app.whenReady().then(async () => {
    // Create API key store
    const apiKeyStore = new EncryptedApiKeyStore();

    mainWindow = createWindowObject();

    // Register IPC handler services (instantiated to register handlers)
    windowService = new WindowService({
      mainWindow,
      ipcMain,
      BrowserWindow,
    });

    directoryService = new DirectoryService({
      mainWindow,
      ipcMain,
      BrowserWindow,
      dialog,
    });

    artifactIndexService = new ArtifactIndexService({
      mainWindow,
      ipcMain,
    });

    issueStorageService = new IssueStorageService({
      mainWindow,
      ipcMain,
    });

    gitService = new GitService({
      mainWindow,
      ipcMain,
    });

    systemService = new SystemService({
      mainWindow,
      ipcMain,
      shell,
      clipboard,
      app,
    });

    runtimeConfigService = new RuntimeConfigService({
      mainWindow,
      ipcMain,
      getRuntimeConfig: () => runtimeConfig,
    });

    claudeCodeService = new ClaudeCodeService({
      mainWindow,
      ipcMain,
    });

    globalSettingsService = new GlobalSettingsService({
      mainWindow,
      ipcMain,
    });

    // Instantiate IDEService to register IDE IPC handlers
    ideService = new IDEService({
      mainWindow,
      ipcMain,
    });

    // Instantiate WorktreeService to register IPC handlers
    worktreeService = new WorktreeService({
      globalSettingsService,
      ipcMain,
      mainWindow,
    });

    let apiKeyRef: ApiKeyProviderRef;
    try {
      apiKeyRef = Effect.runSync(makeApiKeyProviderRef());
    } catch (error: unknown) {
      captureMainException(error, { phase: "bootstrap", component: "apiKeyProviderRef" });
      // If API key ref initialization fails, the app can't safely continue.
      // This should never happen in normal conditions (SubscriptionRef creation),
      // but keeping this inside whenReady avoids blocking module load.
      await dialog.showMessageBox({
        type: "error",
        title: "Compozy failed to start",
        message: "Failed to initialize app state.",
        detail: error instanceof Error ? error.message : String(error),
      });
      app.quit();
      return;
    }

    const setApiKey = (apiKey: string | undefined): void => {
      Effect.runSync(setApiKeyProviderRef(apiKeyRef, apiKey));
    };

    const deepLinkService = new DeepLinkService({
      apiKeyStore,
      getMainWindow: () => mainWindow,
      setApiKey,
      backendBaseUrl: API_URL,
    });

    deepLinkIpcService = new DeepLinkIpcService({
      deepLinkService,
      ipcMain,
      getMainWindow: () => mainWindow,
    });

    const apiKeyService = new ApiKeyService({
      apiKeyRef,
      apiKeyStore,
      mainWindow,
      ipcMain,
    });

    const macDockIconService = new MacDockIconService(macIcon);

    const appBootstrapService = new AppBootstrapService({
      apiKeyRef,
      apiKeyService,
      deepLinkService,
      macDockIconService,
      portManager,
      backendBaseUrl: API_URL,
      getMainWindow: () => mainWindow,
      setBackendProxyService: (service: BackendProxyService | null) => {
        backendProxyService = service;
      },
      setAutoUpdaterService: (service: AutoUpdaterService | null) => {
        autoUpdaterService = service;
      },
      setRuntimeConfig: (config: RuntimeConfig) => {
        runtimeConfig = config;
      },
      onAgentEvent: artifactIndexService?.handleAgentEvent,
    });

    const lifecycleManager = new LifecycleManager({
      deepLinkService,
      getMainWindow: () => mainWindow,
      setMainWindow: (window: BrowserWindow | null) => {
        mainWindow = window;
      },
      getBackendProxyService: () => backendProxyService,
      getAutoUpdaterService: () => autoUpdaterService,
      getApiKeyService: () => apiKeyService,
      getGlobalSettingsService: () => globalSettingsService,
      getIDEService: () => ideService,
      getWorktreeService: () => worktreeService,
      getDeepLinkIpcService: () => deepLinkIpcService,
      getAppBootstrapService: () => appBootstrapService,
      getWindowService: () => windowService,
      getDirectoryService: () => directoryService,
      getGitService: () => gitService,
      getSystemService: () => systemService,
      getRuntimeConfigService: () => runtimeConfigService,
      getClaudeCodeService: () => claudeCodeService,
      getArtifactIndexService: () => artifactIndexService,
      getIssueStorageService: () => issueStorageService,
    });

    lifecycleManager.registerHandlers();
    try {
      await appBootstrapService.initialize();
      // Mark artifact index service as ready after bootstrap completes to ensure IPC handlers are active only after agent events server is running
      artifactIndexService?.markReady();
    } catch (error: unknown) {
      captureMainException(error, { phase: "bootstrap", component: "appBootstrapService" });
      console.error("Failed to initialize app:", error);
      await dialog.showMessageBox({
        type: "error",
        title: "Compozy failed to start",
        message: "Failed to initialize application services.",
        detail: error instanceof Error ? error.message : String(error),
      });
      app.quit();
      return;
    }
  });
}
