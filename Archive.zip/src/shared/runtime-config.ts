export type RuntimeService = "agents" | "looper" | "agentEvents" | "backendProxy";

export interface RuntimeServiceConfig {
  host: string;
  port: number;
  baseUrl: string;
}

export interface RuntimeConfig {
  agents: RuntimeServiceConfig;
  looper: RuntimeServiceConfig;
  agentEvents: RuntimeServiceConfig;
  backendProxy: RuntimeServiceConfig;
}

export interface RuntimeConfigInput {
  host: string;
  agentsPort: number;
  looperPort: number;
  agentEventsPort: number;
  backendProxyPort: number;
  secure?: boolean;
}

export function buildRuntimeConfig({
  host,
  agentsPort,
  looperPort,
  agentEventsPort,
  backendProxyPort,
  secure = false,
}: RuntimeConfigInput): RuntimeConfig {
  const protocol = secure ? "https" : "http";
  const toConfig = (port: number): RuntimeServiceConfig => ({
    host,
    port,
    baseUrl: `${protocol}://${host}:${port}`,
  });

  return {
    agents: toConfig(agentsPort),
    looper: toConfig(looperPort),
    agentEvents: toConfig(agentEventsPort),
    backendProxy: toConfig(backendProxyPort),
  };
}
