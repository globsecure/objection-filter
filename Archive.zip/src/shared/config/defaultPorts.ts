export const DEFAULT_BACKEND_PORT = 3002;
export const DEFAULT_AGENT_PORT = 21230;
export const DEFAULT_LOOPER_PORT = 21231;
export const DEFAULT_BACKEND_PROXY_PORT = 21232;
export const DEFAULT_AGENT_EVENTS_PORT = 18435;

// Development service ports
export const DEFAULT_MINIO_PORT = 4567;
export const DEFAULT_VITE_PORT = 5173;
export const DEFAULT_WEB_APP_PORT = 3001;
