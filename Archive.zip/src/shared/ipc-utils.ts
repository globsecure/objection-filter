import type { IpcErrorResponse, IpcResponse, IpcSuccessResponse } from "./ipc-types";
import { isIpcErrorResponse, isIpcResponse, isIpcSuccessResponse } from "./ipc-types";

export function createIpcSuccess<T>(data: T): IpcSuccessResponse<T> {
  return { success: true, data };
}

export function createIpcError(error: string, code?: string): IpcErrorResponse {
  return { success: false, error, ...(code ? { code } : {}) };
}

export function getIpcErrorMessage(error: unknown): string {
  if (error instanceof Error) return error.message;
  return String(error);
}

export function ensureIpcResponse<T>(value: unknown): IpcResponse<T> | undefined {
  if (isIpcResponse<T>(value)) return value;
  return undefined;
}

export { isIpcErrorResponse, isIpcResponse, isIpcSuccessResponse };
