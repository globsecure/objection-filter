import { isPlainObject } from "es-toolkit/predicate";

export interface IpcErrorResponse {
  success: false;
  error: string;
  code?: string;
}

export interface IpcSuccessResponse<T> {
  success: true;
  data: T;
}

export type IpcResponse<T> = IpcSuccessResponse<T> | IpcErrorResponse;

export function isIpcErrorResponse(value: unknown): value is IpcErrorResponse {
  if (!isPlainObject(value)) return false;
  if (value.success !== false) return false;
  if (typeof value.error !== "string") return false;
  if ("code" in value && typeof value.code !== "string" && typeof value.code !== "undefined") {
    return false;
  }
  return true;
}

export function isIpcSuccessResponse<T = unknown>(value: unknown): value is IpcSuccessResponse<T> {
  if (!isPlainObject(value)) return false;
  if (value.success !== true) return false;
  return "data" in value;
}

export function isIpcResponse<T = unknown>(value: unknown): value is IpcResponse<T> {
  return isIpcErrorResponse(value) || isIpcSuccessResponse<T>(value);
}
