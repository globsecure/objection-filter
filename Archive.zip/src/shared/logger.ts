/**
 * Pure helper functions for @logtape/logtape configuration
 * Each package should use these helpers to configure their own logger instance
 */

import type { ContextLocalStorage } from "@logtape/logtape";
import { getConsoleSink } from "@logtape/logtape";
import { getPrettyFormatter } from "@logtape/pretty";

const isDevelopment = process.env.NODE_ENV !== "production";

type LogLevel = "debug" | "info" | "warning" | "trace" | "error" | "fatal";

export interface LoggerCategory {
  category: string[];
  lowestLevel?: LogLevel;
  sinks?: string[];
}

export interface LoggerConfig {
  categories: LoggerCategory[];
  contextLocalStorage?: ContextLocalStorage<Record<string, unknown>>;
}

/**
 * Creates a console sink configuration for logtape
 * Pure function - returns configuration object
 */
export function createConsoleSink() {
  return getConsoleSink({
    formatter: getPrettyFormatter({
      properties: true, // Enable display of structured data properties
      timestamp: "time", // Show time in HH:MM:SS format
      categoryColor: "white",
    }),
  });
}

/**
 * Normalizes logger categories with default values
 * Pure function - returns normalized categories array
 */
export function normalizeCategories(categories: LoggerCategory[]): Array<{
  category: string[];
  lowestLevel: LogLevel;
  sinks: string[];
}> {
  const lowestLevel: LogLevel = isDevelopment ? "debug" : "info";

  return [
    // Suppress logtape meta messages
    { category: ["logtape", "meta"], lowestLevel: "warning", sinks: ["console"] },
    ...categories.map(cat => ({
      category: cat.category,
      lowestLevel: cat.lowestLevel ?? lowestLevel,
      sinks: cat.sinks ?? ["console"],
    })),
  ];
}

/**
 * Creates a complete logtape configuration object
 * Pure function - returns configuration that can be passed to logtape's configure()
 */
export function createLoggerConfig(config: LoggerConfig) {
  return {
    sinks: {
      console: createConsoleSink(),
    },
    loggers: normalizeCategories(config.categories),
    ...(config.contextLocalStorage && { contextLocalStorage: config.contextLocalStorage }),
  };
}
