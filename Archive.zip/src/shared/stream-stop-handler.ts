/**
 * Stream chunk types that are relevant for stop-on-tool functionality.
 * These chunks are part of the AI SDK UI message stream and use toolCallId consistently.
 */
type ToolStreamChunk =
  | { type: "tool-input-start"; toolCallId: string; toolName: string }
  | { type: "tool-input-end"; toolCallId: string }
  | { type: "tool-call"; toolCallId: string; toolName: string }
  | { type: "tool-output-available"; toolCallId: string }
  | { type?: string; [key: string]: unknown }; // Fallback for other chunk types (AI SDK can emit chunks with missing/unknown type)

/**
 * Type guard to check if a chunk is a tool-input-start chunk.
 */
function isToolInputStartChunk(
  chunk: ToolStreamChunk
): chunk is { type: "tool-input-start"; toolCallId: string; toolName: string } {
  return (
    chunk.type === "tool-input-start" &&
    "toolCallId" in chunk &&
    "toolName" in chunk &&
    typeof chunk.toolCallId === "string" &&
    typeof chunk.toolName === "string"
  );
}

/**
 * Type guard to check if a chunk is a tool-output-available chunk.
 */
function isToolOutputAvailableChunk(
  chunk: ToolStreamChunk
): chunk is { type: "tool-output-available"; toolCallId: string } {
  return (
    chunk.type === "tool-output-available" &&
    "toolCallId" in chunk &&
    typeof chunk.toolCallId === "string"
  );
}

/**
 * Creates a chunk handler that stops the stream when tools with stopOnUse: true are called.
 *
 * Matches the original working behavior: tracks tool IDs on tool-input-start and stops
 * only when tool-output-available is received. This ensures the tool has finished executing
 * and the output is ready before stopping the stream.
 *
 * @param stopOnToolNames - Set of namespaced tool names (mcp__server__tool) that should stop the stream
 * @returns onChunk callback function that returns true to break stream, undefined otherwise
 */
export function createStopOnToolChunkHandler(
  stopOnToolNames: Set<string>
): (chunk: ToolStreamChunk) => boolean | undefined {
  // Early return optimization: if no tools need to stop, return a no-op handler
  if (stopOnToolNames.size === 0) {
    return () => undefined;
  }

  const breakToolCallIds = new Set<string>();

  return (chunk: ToolStreamChunk) => {
    // Track tool IDs when tool-input-start is received for stopOnUse tools
    if (isToolInputStartChunk(chunk) && stopOnToolNames.has(chunk.toolName)) {
      breakToolCallIds.add(chunk.toolCallId);
    }

    // Stop only when tool-output-available is received (tool has finished executing)
    // This matches the original working behavior
    if (isToolOutputAvailableChunk(chunk) && breakToolCallIds.has(chunk.toolCallId)) {
      return true;
    }

    return undefined;
  };
}
