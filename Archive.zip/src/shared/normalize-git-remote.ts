/**
 * Normalize git remote URL to consistent format
 * Handles: SSH, HTTPS, git://, file:// protocols
 *
 * Uses improved logic from looper package that handles trailing slashes better.
 *
 * @example
 *   git@github.com:user/repo.git -> github.com/user/repo
 *   https://github.com/user/repo -> github.com/user/repo
 *   git://github.com/user/repo.git -> github.com/user/repo
 *
 * @param remote - Git remote URL
 * @returns Normalized URL without protocol and .git suffix
 */
export function normalizeGitRemote(remote: string): string {
  let normalized = remote.trim();

  // Remove protocol prefixes (order matters - ssh:// must come before git@)
  normalized = normalized
    .replace(/^ssh:\/\/git@/, "git@") // Handle ssh://git@ format first
    .replace(/^git@/, "")
    .replace(/^https?:\/\//, "")
    .replace(/^git:\/\//, "")
    .replace(/^ssh:\/\//, "")
    .replace(/^file:\/\//, "");

  // Convert SSH format (host:user/repo) to HTTPS format (host/user/repo)
  // Handle GitHub shorthand with colon separator
  const colonIndex = normalized.indexOf(":");
  if (colonIndex > 0) {
    const beforeColon = normalized.slice(0, colonIndex);
    const afterColon = normalized.slice(colonIndex + 1);

    // Only replace colon if it's after hostname and before first slash
    if (!beforeColon.includes("/")) {
      // Check if this is a port number (digits followed by optional slash)
      // Examples of ports: "8080/path", "22/path", "443"
      const slashAfterColon = afterColon.indexOf("/");
      const potentialPort = slashAfterColon > 0 ? afterColon.slice(0, slashAfterColon) : afterColon;
      const isPort = /^\d+$/.test(potentialPort);

      // Only convert colon to slash if it's NOT a port number (SSH scp-style format)
      if (!isPort) {
        normalized = normalized.slice(0, colonIndex) + "/" + normalized.slice(colonIndex + 1);
      }
    }
  }

  // Remove .git suffix
  normalized = normalized.replace(/\.git$/, "");

  // Remove trailing slash
  normalized = normalized.replace(/\/$/, "");

  return normalized;
}
