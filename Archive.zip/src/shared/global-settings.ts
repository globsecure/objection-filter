import { trim } from "es-toolkit/string";
import type { ReasoningEffort } from "../looper/types";

export const AGENT_TYPES = ["prd-creator", "techspec-creator", "tasks-creator", "looper"] as const;
export type AgentType = (typeof AGENT_TYPES)[number];

export const MODEL_TYPES = ["haiku", "sonnet", "opus"] as const;
export type ModelType = (typeof MODEL_TYPES)[number];

export const CODE_ASSISTANTS = ["claude-code", "codex", "gemini"] as const;
export type CodeAssistant = (typeof CODE_ASSISTANTS)[number];

export const REASONING_EFFORTS = ["minimal", "low", "medium", "high"] as const;

export interface LlmSettings {
  model: ModelType;
  reasoningEffort: ReasoningEffort;
  codeAssistant: CodeAssistant;
}

export type LlmSettingsPatch = Partial<LlmSettings>;

export const CLARIFICATION_AGENT_TYPES = ["prd", "techspec"] as const;
export type ClarificationAgentType = (typeof CLARIFICATION_AGENT_TYPES)[number];

export interface BrainstormSettings {
  maxQuestionsPerRound: number;
  approachCount: number;
  requireTradeoffs: boolean;
}

export type BrainstormSettingsPatch = Partial<BrainstormSettings>;

export interface TaskBreakdownSettings {
  /**
   * Guideline only (not enforced). When set, prompts should recommend staying
   * within this range of tasks.
   */
  minTasks?: number;
  maxTasks?: number;
  /**
   * When true, the min/max task limits are ignored and the agent can generate
   * any number of tasks.
   */
  noLimit?: boolean;
}

export type TaskBreakdownSettingsPatch = Partial<TaskBreakdownSettings>;

export const BRANCH_PREFIX_TYPES = ["github-username", "custom", "none"] as const;
export type BranchPrefixType = (typeof BRANCH_PREFIX_TYPES)[number];

export interface GitSettings {
  branchPrefixType: BranchPrefixType;
  customBranchPrefix?: string;
  deleteBranchOnArchive: boolean;
  createWorktreeByDefault: boolean;
  worktreeBaseDirectory: string;
}

export type GitSettingsPatch = Partial<GitSettings>;

export interface SetupWorktreeCommands {
  perRepository: Record<string, string[]>;
}

export type SetupWorktreeCommandsPatch = Partial<SetupWorktreeCommands>;

/**
 * Claude Code environment settings for configuring alternative providers (OpenRouter, Z.AI, etc.)
 * and model overrides.
 */
export interface ClaudeCodeEnvSettings {
  // Core connection variables
  anthropicBaseUrl?: string;
  anthropicAuthToken?: string;
  anthropicApiKey?: string;
  // Model override variables
  defaultHaikuModel?: string;
  defaultSonnetModel?: string;
  defaultOpusModel?: string;
  // Arbitrary custom environment variables
  customEnvVars?: Record<string, string>;
}

export type ClaudeCodeEnvSettingsPatch = Partial<ClaudeCodeEnvSettings>;

export const WORKTREE_STATUSES = ["active", "paused", "completed", "archived", "error"] as const;
export type WorktreeStatus = (typeof WORKTREE_STATUSES)[number];

export const WORKTREE_SETUP_COMMANDS_STATUSES = ["success", "failed", "skipped"] as const;
export type WorktreeSetupCommandsStatus = (typeof WORKTREE_SETUP_COMMANDS_STATUSES)[number];

/**
 * WorktreeInfo is defined in shared/global-settings.ts (not main/types) because it is persisted
 * in GlobalSettings.worktrees and needs to be shared between main and renderer processes.
 */
export interface WorktreeInfo {
  id: string;
  name: string;
  branch: string;
  path: string;
  repositoryId: string;
  issueId?: string;
  status: WorktreeStatus;
  createdAt: string;
  lastActivity?: string;
  setupCommandsStatus?: WorktreeSetupCommandsStatus;
}

export interface GlobalSettings {
  llmSettings: Record<AgentType, LlmSettings>;
  brainstormSettings?: {
    prd?: BrainstormSettings;
    techspec?: BrainstormSettings;
  };
  taskBreakdown?: TaskBreakdownSettings;
  git?: GitSettings;
  setupWorktree?: SetupWorktreeCommands;
  worktrees?: WorktreeInfo[];
  claudeCodeEnv?: ClaudeCodeEnvSettings;
}

export const DEFAULT_LLM_SETTINGS: Record<AgentType, LlmSettings> = {
  "prd-creator": {
    model: "opus",
    reasoningEffort: "low",
    codeAssistant: "claude-code",
  },
  "techspec-creator": {
    model: "opus",
    reasoningEffort: "medium",
    codeAssistant: "claude-code",
  },
  "tasks-creator": {
    model: "sonnet",
    reasoningEffort: "high",
    codeAssistant: "claude-code",
  },
  looper: {
    model: "sonnet",
    reasoningEffort: "medium",
    codeAssistant: "claude-code",
  },
};

export const DEFAULT_BRAINSTORM_SETTINGS: Record<ClarificationAgentType, BrainstormSettings> = {
  prd: { maxQuestionsPerRound: 3, approachCount: 3, requireTradeoffs: true },
  techspec: { maxQuestionsPerRound: 3, approachCount: 3, requireTradeoffs: true },
};

export const DEFAULT_TASK_BREAKDOWN: TaskBreakdownSettings = {
  minTasks: 4,
  maxTasks: 10,
  noLimit: false,
};

export const DEFAULT_GIT_SETTINGS: GitSettings = {
  branchPrefixType: "github-username",
  customBranchPrefix: "",
  deleteBranchOnArchive: false,
  createWorktreeByDefault: true,
  worktreeBaseDirectory: "$HOME/.compozy/worktrees",
};

export const DEFAULT_SETUP_WORKTREE_COMMANDS: SetupWorktreeCommands = {
  perRepository: {},
};

export const DEFAULT_CLAUDE_CODE_ENV_SETTINGS: ClaudeCodeEnvSettings = {};

export const DEFAULT_GLOBAL_SETTINGS: GlobalSettings = {
  llmSettings: DEFAULT_LLM_SETTINGS,
  brainstormSettings: DEFAULT_BRAINSTORM_SETTINGS,
  taskBreakdown: DEFAULT_TASK_BREAKDOWN,
  git: DEFAULT_GIT_SETTINGS,
  setupWorktree: DEFAULT_SETUP_WORKTREE_COMMANDS,
  worktrees: [],
  claudeCodeEnv: DEFAULT_CLAUDE_CODE_ENV_SETTINGS,
};

export function isAgentType(value: unknown): value is AgentType {
  return typeof value === "string" && (AGENT_TYPES as readonly string[]).includes(value);
}

export function isClarificationAgentType(value: unknown): value is ClarificationAgentType {
  return (
    typeof value === "string" && (CLARIFICATION_AGENT_TYPES as readonly string[]).includes(value)
  );
}

export function isModelType(value: unknown): value is ModelType {
  return typeof value === "string" && (MODEL_TYPES as readonly string[]).includes(value);
}

export function isCodeAssistant(value: unknown): value is CodeAssistant {
  return typeof value === "string" && (CODE_ASSISTANTS as readonly string[]).includes(value);
}

export function isReasoningEffort(value: unknown): value is ReasoningEffort {
  return (
    typeof value === "string" &&
    REASONING_EFFORTS.includes(value as (typeof REASONING_EFFORTS)[number])
  );
}

function isPlainRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isStringArray(value: unknown): value is string[] {
  return Array.isArray(value) && value.every(item => typeof item === "string");
}

export function isBranchPrefixType(value: unknown): value is BranchPrefixType {
  return typeof value === "string" && (BRANCH_PREFIX_TYPES as readonly string[]).includes(value);
}

export function isWorktreeStatus(value: unknown): value is WorktreeStatus {
  return typeof value === "string" && (WORKTREE_STATUSES as readonly string[]).includes(value);
}

export function isWorktreeSetupCommandsStatus(
  value: unknown
): value is WorktreeSetupCommandsStatus {
  return (
    typeof value === "string" &&
    (WORKTREE_SETUP_COMMANDS_STATUSES as readonly string[]).includes(value)
  );
}

export function isGitSettings(value: unknown): value is GitSettings {
  if (!isPlainRecord(value)) return false;

  if (!("branchPrefixType" in value) || !isBranchPrefixType(value.branchPrefixType)) return false;
  if ("customBranchPrefix" in value && value.customBranchPrefix !== undefined) {
    if (typeof value.customBranchPrefix !== "string") return false;
  }
  if (!("deleteBranchOnArchive" in value) || typeof value.deleteBranchOnArchive !== "boolean")
    return false;
  if (!("createWorktreeByDefault" in value) || typeof value.createWorktreeByDefault !== "boolean") {
    return false;
  }
  if (!("worktreeBaseDirectory" in value) || typeof value.worktreeBaseDirectory !== "string") {
    return false;
  }

  // Note: Unknown keys are allowed for forward compatibility.
  // This permits new optional fields from future versions without breaking validation.

  return true;
}

export function isSetupWorktreeCommands(value: unknown): value is SetupWorktreeCommands {
  if (!isPlainRecord(value)) return false;

  if (!("perRepository" in value) || !isPlainRecord(value.perRepository)) return false;

  for (const commands of Object.values(value.perRepository)) {
    if (!isStringArray(commands)) return false;
  }

  for (const key of Object.keys(value)) {
    if (key !== "perRepository") {
      return false;
    }
  }

  return true;
}

export function isSetupWorktreeCommandsPatch(value: unknown): value is SetupWorktreeCommandsPatch {
  if (typeof value !== "object" || value === null) return false;
  const patch = value as Record<string, unknown>;

  if ("perRepository" in patch && patch.perRepository !== undefined) {
    if (!isPlainRecord(patch.perRepository)) return false;
    for (const commands of Object.values(patch.perRepository)) {
      if (!isStringArray(commands)) return false;
    }
  }

  for (const key of Object.keys(patch)) {
    if (key !== "perRepository") {
      return false;
    }
  }

  return true;
}

export function isWorktreeInfo(value: unknown): value is WorktreeInfo {
  if (!isPlainRecord(value)) return false;

  // Required fields validation
  if (typeof value.id !== "string") return false;
  if (typeof value.name !== "string") return false;
  if (typeof value.branch !== "string") return false;
  if (typeof value.path !== "string") return false;
  if (typeof value.repositoryId !== "string") return false;
  if (!isWorktreeStatus(value.status)) return false;
  if (typeof value.createdAt !== "string") return false;

  // Optional fields validation (only validate if present)
  if ("issueId" in value && value.issueId !== undefined && typeof value.issueId !== "string")
    return false;
  if (
    "lastActivity" in value &&
    value.lastActivity !== undefined &&
    typeof value.lastActivity !== "string"
  ) {
    return false;
  }
  if (
    "setupCommandsStatus" in value &&
    value.setupCommandsStatus !== undefined &&
    !isWorktreeSetupCommandsStatus(value.setupCommandsStatus)
  ) {
    return false;
  }

  // Note: Unknown keys are allowed for forward compatibility.
  // This permits new optional fields from future versions without breaking validation.

  return true;
}

export function sanitizeGitSettings(candidate: unknown): GitSettings {
  const defaults: GitSettings = { ...DEFAULT_GIT_SETTINGS };
  if (!isPlainRecord(candidate)) return defaults;

  const branchPrefixType = isBranchPrefixType(candidate.branchPrefixType)
    ? candidate.branchPrefixType
    : defaults.branchPrefixType;

  const customBranchPrefix =
    typeof candidate.customBranchPrefix === "string"
      ? candidate.customBranchPrefix
      : defaults.customBranchPrefix;

  const deleteBranchOnArchive =
    typeof candidate.deleteBranchOnArchive === "boolean"
      ? candidate.deleteBranchOnArchive
      : defaults.deleteBranchOnArchive;

  const createWorktreeByDefault =
    typeof candidate.createWorktreeByDefault === "boolean"
      ? candidate.createWorktreeByDefault
      : defaults.createWorktreeByDefault;

  const worktreeBaseDirectoryRaw =
    typeof candidate.worktreeBaseDirectory === "string"
      ? candidate.worktreeBaseDirectory
      : defaults.worktreeBaseDirectory;
  const worktreeBaseDirectory =
    validateWorktreeBaseDirectory(worktreeBaseDirectoryRaw) === null
      ? trim(worktreeBaseDirectoryRaw)
      : defaults.worktreeBaseDirectory;

  return {
    branchPrefixType,
    customBranchPrefix,
    deleteBranchOnArchive,
    createWorktreeByDefault,
    worktreeBaseDirectory,
  };
}

export function validateWorktreeBaseDirectory(value: string): string | null {
  const next = trim(value);
  if (!next) {
    return "Worktree base directory is required";
  }
  if (next.includes("\u0000")) {
    return "Worktree base directory cannot include null characters";
  }
  if (/[\r\n]/.test(next)) {
    return "Worktree base directory cannot include newlines";
  }
  if (next.length > 500) {
    return "Worktree base directory must be 500 characters or less";
  }
  return null;
}

export function sanitizeSetupWorktreeCommands(candidate: unknown): SetupWorktreeCommands {
  const defaults: SetupWorktreeCommands = {
    perRepository: {},
  };

  if (!isPlainRecord(candidate)) return defaults;

  const perRepository: Record<string, string[]> = {};
  if (isPlainRecord(candidate.perRepository)) {
    for (const [gitRemote, commands] of Object.entries(candidate.perRepository)) {
      if (isStringArray(commands)) {
        perRepository[gitRemote] = [...commands];
      }
    }
  }

  return {
    perRepository,
  };
}

export function isLlmSettingsPatch(value: unknown): value is LlmSettingsPatch {
  if (typeof value !== "object" || value === null) return false;
  const patch = value as Record<string, unknown>;

  if ("model" in patch && patch.model !== undefined && !isModelType(patch.model)) return false;
  if (
    "reasoningEffort" in patch &&
    patch.reasoningEffort !== undefined &&
    !isReasoningEffort(patch.reasoningEffort)
  ) {
    return false;
  }
  if (
    "codeAssistant" in patch &&
    patch.codeAssistant !== undefined &&
    !isCodeAssistant(patch.codeAssistant)
  ) {
    return false;
  }

  // Reject unknown keys to keep the IPC surface tight and future-safe.
  for (const key of Object.keys(patch)) {
    if (key !== "model" && key !== "reasoningEffort" && key !== "codeAssistant") {
      return false;
    }
  }

  return true;
}

export function isGitSettingsPatch(value: unknown): value is GitSettingsPatch {
  if (typeof value !== "object" || value === null) return false;
  const patch = value as Record<string, unknown>;

  if (
    "branchPrefixType" in patch &&
    patch.branchPrefixType !== undefined &&
    !isBranchPrefixType(patch.branchPrefixType)
  ) {
    return false;
  }
  if ("customBranchPrefix" in patch && patch.customBranchPrefix !== undefined) {
    if (typeof patch.customBranchPrefix !== "string") return false;
  }
  if ("deleteBranchOnArchive" in patch && patch.deleteBranchOnArchive !== undefined) {
    if (typeof patch.deleteBranchOnArchive !== "boolean") return false;
  }
  if ("createWorktreeByDefault" in patch && patch.createWorktreeByDefault !== undefined) {
    if (typeof patch.createWorktreeByDefault !== "boolean") return false;
  }
  if ("worktreeBaseDirectory" in patch && patch.worktreeBaseDirectory !== undefined) {
    if (typeof patch.worktreeBaseDirectory !== "string") return false;
  }

  for (const key of Object.keys(patch)) {
    if (
      key !== "branchPrefixType" &&
      key !== "customBranchPrefix" &&
      key !== "deleteBranchOnArchive" &&
      key !== "createWorktreeByDefault" &&
      key !== "worktreeBaseDirectory"
    ) {
      return false;
    }
  }

  return true;
}

export function isBrainstormSettingsPatch(value: unknown): value is BrainstormSettingsPatch {
  if (typeof value !== "object" || value === null) return false;
  const patch = value as Record<string, unknown>;

  if ("maxQuestionsPerRound" in patch && patch.maxQuestionsPerRound !== undefined) {
    if (
      typeof patch.maxQuestionsPerRound !== "number" ||
      !Number.isInteger(patch.maxQuestionsPerRound)
    )
      return false;
    if (patch.maxQuestionsPerRound < 1 || patch.maxQuestionsPerRound > 10) return false;
  }
  if ("approachCount" in patch && patch.approachCount !== undefined) {
    if (typeof patch.approachCount !== "number" || !Number.isInteger(patch.approachCount))
      return false;
    if (patch.approachCount < 2 || patch.approachCount > 5) return false;
  }
  if ("requireTradeoffs" in patch && patch.requireTradeoffs !== undefined) {
    if (typeof patch.requireTradeoffs !== "boolean") return false;
  }

  for (const key of Object.keys(patch)) {
    if (key !== "maxQuestionsPerRound" && key !== "approachCount" && key !== "requireTradeoffs") {
      return false;
    }
  }

  return true;
}

export function isTaskBreakdownSettingsPatch(value: unknown): value is TaskBreakdownSettingsPatch {
  if (typeof value !== "object" || value === null) return false;
  const patch = value as Record<string, unknown>;

  if ("minTasks" in patch && patch.minTasks !== undefined) {
    if (typeof patch.minTasks !== "number" || !Number.isInteger(patch.minTasks)) return false;
  }
  if ("maxTasks" in patch && patch.maxTasks !== undefined) {
    if (typeof patch.maxTasks !== "number" || !Number.isInteger(patch.maxTasks)) return false;
  }
  if ("noLimit" in patch && patch.noLimit !== undefined) {
    if (typeof patch.noLimit !== "boolean") return false;
  }

  for (const key of Object.keys(patch)) {
    if (key !== "minTasks" && key !== "maxTasks" && key !== "noLimit") {
      return false;
    }
  }

  return true;
}

function isStringRecord(value: unknown): value is Record<string, string> {
  if (!isPlainRecord(value)) return false;
  for (const val of Object.values(value)) {
    if (typeof val !== "string") return false;
  }
  return true;
}

export function isClaudeCodeEnvSettingsPatch(value: unknown): value is ClaudeCodeEnvSettingsPatch {
  if (typeof value !== "object" || value === null) return false;
  const patch = value as Record<string, unknown>;
  const allowedKeys = [
    "anthropicBaseUrl",
    "anthropicAuthToken",
    "anthropicApiKey",
    "defaultHaikuModel",
    "defaultSonnetModel",
    "defaultOpusModel",
    "customEnvVars",
  ];
  if ("anthropicBaseUrl" in patch && patch.anthropicBaseUrl !== undefined) {
    if (typeof patch.anthropicBaseUrl !== "string") return false;
  }
  if ("anthropicAuthToken" in patch && patch.anthropicAuthToken !== undefined) {
    if (typeof patch.anthropicAuthToken !== "string") return false;
  }
  if ("anthropicApiKey" in patch && patch.anthropicApiKey !== undefined) {
    if (typeof patch.anthropicApiKey !== "string") return false;
  }
  if ("defaultHaikuModel" in patch && patch.defaultHaikuModel !== undefined) {
    if (typeof patch.defaultHaikuModel !== "string") return false;
  }
  if ("defaultSonnetModel" in patch && patch.defaultSonnetModel !== undefined) {
    if (typeof patch.defaultSonnetModel !== "string") return false;
  }
  if ("defaultOpusModel" in patch && patch.defaultOpusModel !== undefined) {
    if (typeof patch.defaultOpusModel !== "string") return false;
  }
  if ("customEnvVars" in patch && patch.customEnvVars !== undefined) {
    if (!isStringRecord(patch.customEnvVars)) return false;
  }
  for (const key of Object.keys(patch)) {
    if (!allowedKeys.includes(key)) {
      return false;
    }
  }
  return true;
}

export function sanitizeClaudeCodeEnvSettings(candidate: unknown): ClaudeCodeEnvSettings {
  const defaults: ClaudeCodeEnvSettings = { ...DEFAULT_CLAUDE_CODE_ENV_SETTINGS };
  if (!isPlainRecord(candidate)) return defaults;
  const result: ClaudeCodeEnvSettings = {};
  if (typeof candidate.anthropicBaseUrl === "string" && candidate.anthropicBaseUrl.length > 0) {
    result.anthropicBaseUrl = candidate.anthropicBaseUrl;
  }
  if (typeof candidate.anthropicAuthToken === "string" && candidate.anthropicAuthToken.length > 0) {
    result.anthropicAuthToken = candidate.anthropicAuthToken;
  }
  if (typeof candidate.anthropicApiKey === "string") {
    result.anthropicApiKey = candidate.anthropicApiKey;
  }
  if (typeof candidate.defaultHaikuModel === "string" && candidate.defaultHaikuModel.length > 0) {
    result.defaultHaikuModel = candidate.defaultHaikuModel;
  }
  if (typeof candidate.defaultSonnetModel === "string" && candidate.defaultSonnetModel.length > 0) {
    result.defaultSonnetModel = candidate.defaultSonnetModel;
  }
  if (typeof candidate.defaultOpusModel === "string" && candidate.defaultOpusModel.length > 0) {
    result.defaultOpusModel = candidate.defaultOpusModel;
  }
  if (isStringRecord(candidate.customEnvVars)) {
    result.customEnvVars = { ...candidate.customEnvVars };
  }
  return result;
}
