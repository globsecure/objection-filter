/**
 * Issue Path Resolution
 * Generates issue-specific storage directories in $HOME/.compozy/issues/
 */

import { trim } from "es-toolkit/string";
import { invariant } from "es-toolkit/util";
import * as fs from "fs";
import * as path from "path";
import { z } from "zod";
import { ensureDir } from "./ensure-dir";
import { getCompozyHomeDir } from "./repository-key";

const ISSUE_DIR_NAME = "issues";
/**
 * Maximum length for issue IDs to ensure filesystem compatibility.
 */
export const ISSUE_ID_MAX_LENGTH = 55;
const ISSUE_ID_SCHEMA = z.string().uuid();
/** UUID v4 regex for hot-path validation (avoids Zod object allocation) */
const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function isValidIssueId(issueId: string): boolean {
  const normalized = trim(issueId);
  return (
    normalized.length > 0 && normalized.length <= ISSUE_ID_MAX_LENGTH && UUID_REGEX.test(normalized)
  );
}

function normalizeIssueId(issueId: string): string {
  const normalized = trim(issueId);
  invariant(normalized.length > 0, "Issue ID is required to resolve issue directories");
  invariant(
    normalized.length <= ISSUE_ID_MAX_LENGTH,
    `Issue ID must be at most ${ISSUE_ID_MAX_LENGTH} characters`
  );
  invariant(ISSUE_ID_SCHEMA.safeParse(normalized).success, "Issue ID must be a valid UUID");
  return normalized;
}

function getIssueBaseDir(): string {
  const compozyHome = getCompozyHomeDir();
  const issuesBaseDir = path.join(compozyHome, ISSUE_DIR_NAME);
  ensureDir(issuesBaseDir, { recursive: true, mode: 0o700, skipInTestEnv: true });

  return issuesBaseDir;
}

function findExistingIssueDir(baseDir: string, issueId: string): string | undefined {
  if (!fs.existsSync(baseDir)) {
    return undefined;
  }

  try {
    const entries = fs.readdirSync(baseDir, { withFileTypes: true });

    // First, check for exact match (new format: just issueId)
    const exactMatch = entries.find(entry => entry.isDirectory() && entry.name === issueId);
    if (exactMatch) {
      return path.join(baseDir, exactMatch.name);
    }

    // Fallback: check for old slug-based format (ending with -{issueId})
    const suffix = `-${issueId}`;
    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      if (entry.name.endsWith(suffix)) {
        return path.join(baseDir, entry.name);
      }
    }
  } catch {
    return undefined;
  }

  return undefined;
}

/**
 * Resolve the issue-specific directory path.
 *
 * @returns $HOME/.compozy/issues/{issue-id}/
 */
export function getIssueDir(issueId: string): string {
  const normalizedIssueId = normalizeIssueId(issueId);
  const issuesBaseDir = getIssueBaseDir();

  // Check for existing directory (supports both new format and old slug-based format)
  const existing = findExistingIssueDir(issuesBaseDir, normalizedIssueId);
  if (existing) {
    return existing;
  }

  // Create new directory using simple issueId format
  const resolvedBaseDir = path.resolve(issuesBaseDir);
  const resolvedIssueDir = path.resolve(resolvedBaseDir, normalizedIssueId);
  const basePrefix = resolvedBaseDir.endsWith(path.sep)
    ? resolvedBaseDir
    : `${resolvedBaseDir}${path.sep}`;
  invariant(
    resolvedIssueDir.startsWith(basePrefix),
    "Resolved issue directory escapes the base issues directory"
  );

  // Ensure the issue directory exists before returning
  ensureDir(resolvedIssueDir, { recursive: true, mode: 0o700, skipInTestEnv: true });

  return resolvedIssueDir;
}
