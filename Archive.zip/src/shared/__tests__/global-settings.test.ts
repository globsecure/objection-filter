import { describe, expect, it } from "vitest";
import {
  AGENT_TYPES,
  CODE_ASSISTANTS,
  DEFAULT_BRAINSTORM_SETTINGS,
  DEFAULT_GIT_SETTINGS,
  DEFAULT_GLOBAL_SETTINGS,
  MODEL_TYPES,
  REASONING_EFFORTS,
  isBrainstormSettingsPatch,
  isGitSettings,
  isGitSettingsPatch,
  isLlmSettingsPatch,
  isTaskBreakdownSettingsPatch,
  sanitizeGitSettings,
} from "../global-settings";

describe("shared/global-settings", () => {
  it("defines defaults for every agent type", () => {
    for (const agentType of AGENT_TYPES) {
      const settings = DEFAULT_GLOBAL_SETTINGS.llmSettings[agentType];
      expect(settings).toBeDefined();
      expect(MODEL_TYPES).toContain(settings.model);
      expect(CODE_ASSISTANTS).toContain(settings.codeAssistant);
      expect(REASONING_EFFORTS).toContain(settings.reasoningEffort);
    }
  });

  it("validates llm settings patches", () => {
    expect(isLlmSettingsPatch({ model: "sonnet" })).toBe(true);
    expect(isLlmSettingsPatch({ reasoningEffort: "minimal" })).toBe(true);
    expect(isLlmSettingsPatch({ codeAssistant: "codex" })).toBe(true);
    expect(isLlmSettingsPatch({ model: "unknown" })).toBe(false);
    expect(isLlmSettingsPatch({ foo: "bar" })).toBe(false);
    expect(isLlmSettingsPatch("nope")).toBe(false);
  });

  it("defines brainstorm defaults for PRD and TechSpec", () => {
    expect(DEFAULT_GLOBAL_SETTINGS.brainstormSettings?.prd).toEqual(
      DEFAULT_BRAINSTORM_SETTINGS.prd
    );
    expect(DEFAULT_GLOBAL_SETTINGS.brainstormSettings?.techspec).toEqual(
      DEFAULT_BRAINSTORM_SETTINGS.techspec
    );
  });

  it("validates brainstorm settings patches", () => {
    expect(isBrainstormSettingsPatch({ maxQuestionsPerRound: 3 })).toBe(true);
    expect(isBrainstormSettingsPatch({ approachCount: 3 })).toBe(true);
    expect(isBrainstormSettingsPatch({ requireTradeoffs: true })).toBe(true);
    expect(isBrainstormSettingsPatch({ requireTradeoffs: false })).toBe(true);
    expect(
      isBrainstormSettingsPatch({
        maxQuestionsPerRound: 3,
        approachCount: 3,
        requireTradeoffs: true,
      })
    ).toBe(true);
    expect(isBrainstormSettingsPatch({ maxQuestionsPerRound: "3" })).toBe(false);
    expect(isBrainstormSettingsPatch({ maxQuestionsPerRound: 3.14 })).toBe(false);
    expect(isBrainstormSettingsPatch({ maxQuestionsPerRound: 0 })).toBe(false);
    expect(isBrainstormSettingsPatch({ maxQuestionsPerRound: 11 })).toBe(false);
    expect(isBrainstormSettingsPatch({ maxQuestionsPerRound: 1 })).toBe(true);
    expect(isBrainstormSettingsPatch({ maxQuestionsPerRound: 10 })).toBe(true);
    expect(isBrainstormSettingsPatch({ approachCount: 1 })).toBe(false);
    expect(isBrainstormSettingsPatch({ approachCount: 6 })).toBe(false);
    expect(isBrainstormSettingsPatch({ approachCount: 2 })).toBe(true);
    expect(isBrainstormSettingsPatch({ approachCount: 5 })).toBe(true);
    expect(isBrainstormSettingsPatch({ requireTradeoffs: "true" })).toBe(false);
    expect(isBrainstormSettingsPatch({ foo: "bar" })).toBe(false);
  });

  it("validates task breakdown settings patches", () => {
    expect(isTaskBreakdownSettingsPatch({ minTasks: 4 })).toBe(true);
    expect(isTaskBreakdownSettingsPatch({ maxTasks: 10 })).toBe(true);
    expect(isTaskBreakdownSettingsPatch({ minTasks: 4, maxTasks: 10 })).toBe(true);
    expect(isTaskBreakdownSettingsPatch({ minTasks: undefined })).toBe(true);
    expect(isTaskBreakdownSettingsPatch({ maxTasks: undefined })).toBe(true);
    expect(isTaskBreakdownSettingsPatch({ minTasks: "4" })).toBe(false);
    expect(isTaskBreakdownSettingsPatch({ maxTasks: "10" })).toBe(false);
    expect(isTaskBreakdownSettingsPatch({ minTasks: 3.14 })).toBe(false);
    expect(isTaskBreakdownSettingsPatch({ maxTasks: 3.14 })).toBe(false);
    expect(isTaskBreakdownSettingsPatch({ foo: "bar" })).toBe(false);
    expect(isTaskBreakdownSettingsPatch({ noLimit: true })).toBe(true);
    expect(isTaskBreakdownSettingsPatch({ noLimit: false })).toBe(true);
    expect(isTaskBreakdownSettingsPatch({ noLimit: undefined })).toBe(true);
    expect(isTaskBreakdownSettingsPatch({ noLimit: "true" })).toBe(false);
    expect(isTaskBreakdownSettingsPatch({ noLimit: 1 })).toBe(false);
    expect(isTaskBreakdownSettingsPatch({ minTasks: 4, maxTasks: 10, noLimit: true })).toBe(true);
  });

  it("defines git settings defaults", () => {
    expect(DEFAULT_GIT_SETTINGS).toEqual({
      branchPrefixType: "github-username",
      customBranchPrefix: "",
      deleteBranchOnArchive: false,
      createWorktreeByDefault: true,
      worktreeBaseDirectory: "$HOME/.compozy/worktrees",
    });
  });

  it("validates git settings objects", () => {
    expect(
      isGitSettings({
        branchPrefixType: "custom",
        customBranchPrefix: "team",
        deleteBranchOnArchive: true,
        createWorktreeByDefault: true,
        worktreeBaseDirectory: "/tmp/worktrees",
      })
    ).toBe(true);

    expect(
      isGitSettings({
        branchPrefixType: "nope",
        deleteBranchOnArchive: true,
        createWorktreeByDefault: true,
        worktreeBaseDirectory: "/tmp/worktrees",
      })
    ).toBe(false);
  });

  it("validates git settings patches", () => {
    expect(isGitSettingsPatch({ branchPrefixType: "none" })).toBe(true);
    expect(isGitSettingsPatch({ customBranchPrefix: "custom" })).toBe(true);
    expect(isGitSettingsPatch({ deleteBranchOnArchive: true })).toBe(true);
    expect(isGitSettingsPatch({ createWorktreeByDefault: true })).toBe(true);
    expect(isGitSettingsPatch({ worktreeBaseDirectory: "/tmp/worktrees" })).toBe(true);

    expect(isGitSettingsPatch({ branchPrefixType: "unknown" })).toBe(false);
    expect(isGitSettingsPatch({ deleteBranchOnArchive: "true" })).toBe(false);
    expect(isGitSettingsPatch({ worktreeBaseDirectory: 123 })).toBe(false);
    expect(isGitSettingsPatch({ foo: "bar" })).toBe(false);
  });

  it("sanitizes git settings with defaults", () => {
    expect(sanitizeGitSettings(undefined)).toEqual(DEFAULT_GIT_SETTINGS);
    expect(sanitizeGitSettings({ branchPrefixType: "none" })).toEqual({
      ...DEFAULT_GIT_SETTINGS,
      branchPrefixType: "none",
    });

    expect(
      sanitizeGitSettings({
        branchPrefixType: "custom",
        customBranchPrefix: "team",
        deleteBranchOnArchive: true,
      })
    ).toEqual({
      branchPrefixType: "custom",
      customBranchPrefix: "team",
      deleteBranchOnArchive: true,
      createWorktreeByDefault: true,
      worktreeBaseDirectory: "$HOME/.compozy/worktrees",
    });
  });
});
