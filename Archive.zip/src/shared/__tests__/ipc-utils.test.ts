import { describe, expect, it } from "vitest";

import { IpcInvokeError, invokeIpc, invokeIpcResponse, normalizeIpcResponse } from "../ipc-client";
import { isIpcErrorResponse, isIpcResponse, isIpcSuccessResponse } from "../ipc-types";
import { createIpcError, createIpcSuccess } from "../ipc-utils";

describe("IPC response utilities", () => {
  it("createIpcSuccess wraps data", () => {
    const response = createIpcSuccess({ ok: true });
    expect(response).toEqual({ success: true, data: { ok: true } });
    expect(isIpcSuccessResponse(response)).toBe(true);
    expect(isIpcErrorResponse(response)).toBe(false);
  });

  it("createIpcError wraps error and optional code", () => {
    const response = createIpcError("Boom", "E_BOOM");
    expect(response).toEqual({ success: false, error: "Boom", code: "E_BOOM" });
    expect(isIpcErrorResponse(response)).toBe(true);
    expect(isIpcSuccessResponse(response)).toBe(false);
  });

  it("type guards identify IpcResponse variants", () => {
    expect(isIpcResponse(createIpcSuccess(123))).toBe(true);
    expect(isIpcResponse(createIpcError("Nope"))).toBe(true);
    expect(isIpcResponse({})).toBe(false);
    expect(isIpcResponse({ success: true })).toBe(false);
    expect(isIpcResponse({ success: false, error: 123 })).toBe(false);
  });

  it("normalizeIpcResponse preserves already-standardized responses", () => {
    const original = createIpcSuccess({ value: "x" });
    expect(normalizeIpcResponse(original)).toEqual(original);
  });

  it("normalizeIpcResponse converts legacy `{ error }` objects into IpcErrorResponse", () => {
    const normalized = normalizeIpcResponse<{ ok: true }>({ error: "Legacy error" });
    expect(isIpcErrorResponse(normalized)).toBe(true);
    if (normalized.success === false) {
      expect(normalized.error).toBe("Legacy error");
    }
  });

  it("invokeIpcResponse returns success for legacy raw values", async () => {
    const invoker = {
      invoke: async () => 42,
    };
    const response = await invokeIpcResponse<number>(invoker, "legacy:value");
    expect(response).toEqual({ success: true, data: 42 });
  });

  it("invokeIpc throws IpcInvokeError for error responses", async () => {
    const invoker = {
      invoke: async () => createIpcError("Bad", "E_BAD"),
    };

    await expect(invokeIpc(invoker, "test:error")).rejects.toBeInstanceOf(IpcInvokeError);
    await expect(invokeIpc(invoker, "test:error")).rejects.toMatchObject({
      channel: "test:error",
      code: "E_BAD",
    });
  });
});
