import { afterEach, describe, expect, it } from "vitest";
import * as fs from "fs";
import * as path from "path";
import { cleanupTestCompozyHomeDir, getCompozyHomeDir } from "../repository-key";
import { getIssueDir } from "../issue-path";

const ISSUE_ID = "123e4567-e89b-12d3-a456-426614174000";

describe("issue-path", () => {
  afterEach(() => {
    cleanupTestCompozyHomeDir();
  });

  describe("getIssueDir", () => {
    it("returns existing issue directory when present (old slug format)", () => {
      const baseDir = path.join(getCompozyHomeDir(), "issues");
      fs.mkdirSync(baseDir, { recursive: true });
      const existingDir = path.join(baseDir, `123e4567-existing-${ISSUE_ID}`);
      fs.mkdirSync(existingDir, { recursive: true });

      const resolved = getIssueDir(ISSUE_ID);

      expect(resolved).toBe(existingDir);
    });

    it("returns existing issue directory when present (new format)", () => {
      const baseDir = path.join(getCompozyHomeDir(), "issues");
      fs.mkdirSync(baseDir, { recursive: true });
      const existingDir = path.join(baseDir, ISSUE_ID);
      fs.mkdirSync(existingDir, { recursive: true });

      const resolved = getIssueDir(ISSUE_ID);

      expect(resolved).toBe(existingDir);
    });

    it("generates new directory path when not present and creates it", () => {
      const baseDir = path.join(getCompozyHomeDir(), "issues");
      fs.mkdirSync(baseDir, { recursive: true });
      const newIssueId = "123e4567-e89b-12d3-a456-426614174999";

      const resolved = getIssueDir(newIssueId);

      expect(resolved.startsWith(`${baseDir}${path.sep}`)).toBe(true);
      expect(resolved).toBe(path.join(baseDir, newIssueId));
      expect(fs.existsSync(resolved)).toBe(true);
      expect(fs.statSync(resolved).isDirectory()).toBe(true);
    });
  });
});
