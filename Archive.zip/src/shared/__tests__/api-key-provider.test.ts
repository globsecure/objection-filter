import { describe, expect, it } from "vitest";

import * as Effect from "effect/Effect";
import * as Fiber from "effect/Fiber";
import * as SubscriptionRef from "effect/SubscriptionRef";

import {
  makeApiKeyProviderRef,
  normalizeApiKey,
  onApiKeyProviderRefChange,
  setApiKeyProviderRef,
} from "../api-key-provider";

describe("api-key-provider", () => {
  describe("normalizeApiKey", () => {
    it("returns undefined for missing or invalid keys", () => {
      expect(normalizeApiKey(undefined)).toBeUndefined();
      expect(normalizeApiKey("")).toBeUndefined();
      expect(normalizeApiKey("not-a-compozy-key")).toBeUndefined();
    });

    it("trims and returns keys with compozy_ prefix", () => {
      expect(normalizeApiKey("  compozy_test  ")).toBe("compozy_test");
    });
  });

  it("stores a validated key in memory and updates it", () => {
    const ref = Effect.runSync(makeApiKeyProviderRef("  compozy_initial  "));

    expect(Effect.runSync(SubscriptionRef.get(ref))).toBe("compozy_initial");

    Effect.runSync(setApiKeyProviderRef(ref, "compozy_next"));
    expect(Effect.runSync(SubscriptionRef.get(ref))).toBe("compozy_next");

    Effect.runSync(setApiKeyProviderRef(ref, "invalid"));
    expect(Effect.runSync(SubscriptionRef.get(ref))).toBeUndefined();
  });

  it("can observe updates via onApiKeyProviderRefChange", async () => {
    const events: Array<string | undefined> = [];

    await Effect.runPromise(
      Effect.gen(function* () {
        const ref = yield* makeApiKeyProviderRef();

        const fiber = yield* onApiKeyProviderRefChange(ref, apiKey => events.push(apiKey));
        yield* Effect.yieldNow();

        yield* setApiKeyProviderRef(ref, "compozy_changed");
        yield* Effect.yieldNow();

        yield* Fiber.interrupt(fiber);
      })
    );

    expect(events).toContain("compozy_changed");
  });
});
