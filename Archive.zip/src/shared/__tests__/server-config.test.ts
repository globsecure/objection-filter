import { afterEach, beforeEach, describe, expect, it } from "vitest";

import { createLazyServerConfig, createServerConfig, parseUrl } from "../server-config";

const SERVER_ENV = "TEST_SERVER_CONFIG_URL";
const LAZY_ENV = "TEST_LAZY_SERVER_CONFIG_URL";

const restoreEnv = (key: string, value: string | undefined) => {
  if (typeof value === "undefined") {
    delete process.env[key];
  } else {
    process.env[key] = value;
  }
};

describe("server-config", () => {
  let originalServerEnv: string | undefined;
  let originalLazyEnv: string | undefined;

  beforeEach(() => {
    ({ [SERVER_ENV]: originalServerEnv, [LAZY_ENV]: originalLazyEnv } = {
      [SERVER_ENV]: process.env[SERVER_ENV],
      [LAZY_ENV]: process.env[LAZY_ENV],
    });

    delete process.env[SERVER_ENV];
    delete process.env[LAZY_ENV];
  });

  afterEach(() => {
    restoreEnv(SERVER_ENV, originalServerEnv);
    restoreEnv(LAZY_ENV, originalLazyEnv);
  });

  describe("parseUrl", () => {
    it("parses a valid URL with an explicit port", () => {
      const result = parseUrl("http://127.0.0.1:21230", 80);

      expect(result).toEqual({ host: "127.0.0.1", port: 21230 });
    });

    it("uses the default port when the URL omits one", () => {
      const result = parseUrl("http://127.0.0.1", 21230);

      expect(result).toEqual({ host: "127.0.0.1", port: 21230 });
    });

    it("falls back to localhost when parsing fails in non-strict mode", () => {
      const result = parseUrl("not-a-url", 3000);

      expect(result).toEqual({ host: "127.0.0.1", port: 3000 });
    });

    it("throws when parsing fails in strict mode", () => {
      expect(() => parseUrl("not-a-url", 3000, true)).toThrow();
    });
  });

  describe("createServerConfig", () => {
    it("throws when the environment variable is missing", () => {
      delete process.env[SERVER_ENV];

      expect(() =>
        createServerConfig({
          urlEnvVar: SERVER_ENV,
          defaultPort: 21230,
        })
      ).toThrow(new RegExp(`${SERVER_ENV} environment variable is required`));
    });

    it("throws when the environment variable is only whitespace", () => {
      process.env[SERVER_ENV] = "   \n";

      expect(() =>
        createServerConfig({
          urlEnvVar: SERVER_ENV,
          defaultPort: 21230,
        })
      ).toThrow();
    });

    it("trims whitespace and strips trailing slashes", () => {
      process.env[SERVER_ENV] = "  http://127.0.0.1:5555/  ";

      const config = createServerConfig({
        urlEnvVar: SERVER_ENV,
        defaultPort: 21230,
      });

      expect(config.url).toBe("http://127.0.0.1:5555");
      expect(config.host).toBe("127.0.0.1");
      expect(config.port).toBe(5555);
    });
  });

  describe("createLazyServerConfig", () => {
    it("reads the value set after creation on first access", () => {
      const config = createLazyServerConfig({
        urlEnvVar: LAZY_ENV,
        defaultPort: 21231,
      });

      process.env[LAZY_ENV] = "http://127.0.0.1:6001";

      expect(config.url).toBe("http://127.0.0.1:6001");
      expect(config.port).toBe(6001);
    });

    it("recomputes when the environment variable changes between calls", () => {
      process.env[LAZY_ENV] = "http://127.0.0.1:6101";

      const config = createLazyServerConfig({
        urlEnvVar: LAZY_ENV,
        defaultPort: 21231,
      });

      expect(config.host).toBe("127.0.0.1");
      expect(config.port).toBe(6101);

      process.env[LAZY_ENV] = "http://127.0.0.1:6202";

      expect(config.port).toBe(6202);
      expect(config.host).toBe("127.0.0.1");
    });
  });
});
