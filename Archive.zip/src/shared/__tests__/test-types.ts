import type { UIMessage } from "ai";

/**
 * Extended message part types for tool calls that aren't fully covered
 * in the base UIMessage type from the 'ai' library.
 */
export interface ToolCallInputStreamingPart {
  type: string;
  toolCallId: string;
  state: "input-streaming";
  input: Record<string, unknown>;
}

export interface ToolCallOutputAvailablePart {
  type: string;
  toolCallId: string;
  state: "output-available";
  input: Record<string, unknown>;
  output: Record<string, unknown>;
}

export type ToolCallMessagePart = ToolCallInputStreamingPart | ToolCallOutputAvailablePart;

/**
 * Extended UIMessage type that includes tool-call message parts
 */
export type ExtendedUIMessage =
  | UIMessage
  | {
      id: string;
      role: "assistant";
      parts: Array<ToolCallMessagePart>;
    };
