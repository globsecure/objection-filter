import { describe, expect, it } from "vitest";
import type { Context } from "hono";
import { Hono } from "hono";
import type { IncomingMessage, ServerResponse } from "node:http";

import { isAllowedOrigin } from "../security/cors-validation";
import { createCorsMiddleware, createHostValidationMiddleware } from "../security/hono-middleware";
import { validateHostHeader } from "../security/host-validation";
import { createCorsHandler, createHostValidationHandler } from "../security/node-http-handlers";

type MockResponse = {
  statusCode?: number;
  headers: Record<string, string>;
  body?: string;
};

const createMockResponse = (): MockResponse & ServerResponse => {
  const response = {
    headers: {} as Record<string, string>,
    writeHead(status: number, headers?: Record<string, string>) {
      this.statusCode = status;
      if (headers) {
        this.headers = { ...this.headers, ...headers };
      }
      return this as unknown as ServerResponse;
    },
    setHeader(key: string, value: string) {
      this.headers[key] = value;
    },
    end(body?: string) {
      this.body = body ?? "";
    },
  } as MockResponse & ServerResponse;

  return response;
};

describe("host-validation", () => {
  it("accepts 127.0.0.1 with port", () => {
    expect(validateHostHeader("127.0.0.1:4000", 4000)).toBe(true);
  });

  it("accepts localhost with port", () => {
    expect(validateHostHeader("localhost:8080", 8080)).toBe(true);
  });

  it("rejects mismatched host", () => {
    expect(validateHostHeader("example.com:8080", 8080)).toBe(false);
  });

  it("rejects undefined host", () => {
    expect(validateHostHeader(undefined, 8080)).toBe(false);
  });
});

describe("cors-validation", () => {
  const origins = ["https://allowed.com", "app://main"];

  it("allows null/undefined origins", () => {
    expect(isAllowedOrigin(undefined, origins)).toBe(true);
  });

  it("allows configured origins", () => {
    expect(isAllowedOrigin("app://main", origins)).toBe(true);
  });

  it("rejects unknown origins", () => {
    expect(isAllowedOrigin("https://evil.com", origins)).toBe(false);
  });
});

describe("hono middleware", () => {
  const port = 3100;
  const allowedOrigins = ["http://localhost:5173", "app://main"];

  it("rejects invalid host headers", async () => {
    const app = new Hono();
    app.use("*", createHostValidationMiddleware(port));
    app.get("/", (c: Context) => c.text("ok"));

    const res = await app.request("http://malicious:3100/");
    expect(res.status).toBe(403);
  });

  it("rejects disallowed origins", async () => {
    const app = new Hono();
    app.use("*", createCorsMiddleware(allowedOrigins));
    app.get("/", (c: Context) => c.text("ok"));

    const res = await app.request(`http://localhost:${port}/`, {
      headers: { Origin: "https://evil.com" },
    });

    expect(res.status).toBe(403);
  });
});

describe("node http handlers", () => {
  const allowedOrigins = ["https://allowed.com"];

  it("rejects invalid hosts", () => {
    const handler = createHostValidationHandler(5050);
    const res = createMockResponse();
    let called = false;
    const next = () => {
      called = true;
    };

    handler({ headers: { host: "evil:5050" } } as unknown as IncomingMessage, res, next);

    expect(res.statusCode).toBe(403);
    expect(called).toBe(false);
  });

  it("sets CORS headers for allowed origins", () => {
    const handler = createCorsHandler(allowedOrigins);
    const res = createMockResponse();
    let called = false;
    const next = () => {
      called = true;
    };

    handler(
      {
        method: "GET",
        headers: { origin: "https://allowed.com" },
      } as unknown as IncomingMessage,
      res,
      next
    );

    expect(res.headers["Access-Control-Allow-Origin"]).toBe("https://allowed.com");
    expect(called).toBe(true);
  });

  it("handles OPTIONS requests and ends response", () => {
    const handler = createCorsHandler(allowedOrigins);
    const res = createMockResponse();
    let called = false;
    const next = () => {
      called = true;
    };

    handler(
      {
        method: "OPTIONS",
        headers: { origin: "https://allowed.com" },
      } as unknown as IncomingMessage,
      res,
      next
    );

    expect(res.statusCode).toBe(200);
    expect(called).toBe(false);
  });
});
