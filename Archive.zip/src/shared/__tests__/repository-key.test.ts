/**
 * Tests for repository-key.ts
 * Consolidated tests from both packages/agents and packages/looper
 */

import { afterEach, beforeEach, describe, expect, it } from "vitest";
import * as fs from "fs";
import * as os from "os";
import * as path from "path";
import {
  getGitRemoteOrigin,
  normalizeGitRemote,
  generateRepositoryKey,
  generateRepositoryKeyFromNormalized,
  getRepositoryInfo,
  getCompozyHomeDir,
  getRepositoryDir,
} from "../repository-key";

describe("Repository Key Generation", () => {
  let tempDir: string;

  beforeEach(() => {
    tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "repo-key-test-"));
  });

  afterEach(() => {
    if (fs.existsSync(tempDir)) {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  describe("normalizeGitRemote", () => {
    it("normalizes SSH format with git@", () => {
      expect(normalizeGitRemote("git@github.com:user/repo.git")).toBe("github.com/user/repo");
    });

    it("normalizes HTTPS format", () => {
      expect(normalizeGitRemote("https://github.com/user/repo.git")).toBe("github.com/user/repo");
    });

    it("normalizes HTTP format", () => {
      expect(normalizeGitRemote("http://github.com/user/repo.git")).toBe("github.com/user/repo");
    });

    it("handles URLs without .git suffix", () => {
      expect(normalizeGitRemote("https://github.com/user/repo")).toBe("github.com/user/repo");
    });

    it("handles git:// protocol", () => {
      expect(normalizeGitRemote("git://github.com/user/repo.git")).toBe("github.com/user/repo");
    });

    it("handles ssh:// protocol", () => {
      expect(normalizeGitRemote("ssh://git@github.com/user/repo.git")).toBe("github.com/user/repo");
    });

    it("handles file:// protocol", () => {
      expect(normalizeGitRemote("file:///path/to/repo.git")).toBe("/path/to/repo");
    });

    it("handles GitLab SSH URLs", () => {
      expect(normalizeGitRemote("git@gitlab.com:user/repo.git")).toBe("gitlab.com/user/repo");
    });

    it("handles Bitbucket SSH URLs", () => {
      expect(normalizeGitRemote("git@bitbucket.org:user/repo.git")).toBe("bitbucket.org/user/repo");
    });

    it("preserves subdirectories in URL", () => {
      expect(normalizeGitRemote("https://github.com/org/team/repo.git")).toBe(
        "github.com/org/team/repo"
      );
    });

    it("handles trailing whitespace", () => {
      expect(normalizeGitRemote("  git@github.com:user/repo.git  ")).toBe("github.com/user/repo");
    });

    it("handles URLs with trailing slash", () => {
      expect(normalizeGitRemote("https://github.com/user/repo/")).toBe("github.com/user/repo");
    });
  });

  describe("generateRepositoryKey", () => {
    it("generates consistent keys for the same remote", () => {
      const remote = "git@github.com:user/repo.git";
      const key1 = generateRepositoryKey(remote);
      const key2 = generateRepositoryKey(remote);
      expect(key1).toBe(key2);
    });

    it("produces same key for equivalent URLs", () => {
      const key1 = generateRepositoryKey("git@github.com:user/repo.git");
      const key2 = generateRepositoryKey("https://github.com/user/repo");
      expect(key1).toBe(key2);
    });

    it("produces different keys for different repos", () => {
      const key1 = generateRepositoryKey("git@github.com:user/repo1.git");
      const key2 = generateRepositoryKey("git@github.com:user/repo2.git");
      expect(key1).not.toBe(key2);
    });

    it("returns 32-character hex string", () => {
      const key = generateRepositoryKey("git@github.com:user/repo.git");
      expect(key).toMatch(/^[a-f0-9]{32}$/);
    });

    it("handles normalized remotes correctly", () => {
      const key1 = generateRepositoryKey("github.com/user/repo");
      const key2 = generateRepositoryKey("git@github.com:user/repo.git");
      expect(key1).toBe(key2);
    });
  });

  describe("generateRepositoryKeyFromNormalized", () => {
    it("generates consistent keys for normalized remotes", () => {
      const normalized = "github.com/user/repo";
      const key1 = generateRepositoryKeyFromNormalized(normalized);
      const key2 = generateRepositoryKeyFromNormalized(normalized);
      expect(key1).toBe(key2);
    });

    it("produces same result as generateRepositoryKey for normalized input", () => {
      const normalized = "github.com/user/repo";
      const key1 = generateRepositoryKeyFromNormalized(normalized);
      const key2 = generateRepositoryKey(normalized);
      expect(key1).toBe(key2);
    });
  });

  describe("getCompozyHomeDir", () => {
    it("returns temporary directory path in test mode", () => {
      // In test mode (NODE_ENV === 'test'), should return temp directory
      const homeDir = getCompozyHomeDir();
      expect(homeDir).toContain(os.tmpdir());
      expect(homeDir).toContain("compozy-test");
    });

    it("returns same path on multiple calls", () => {
      const homeDir1 = getCompozyHomeDir();
      const homeDir2 = getCompozyHomeDir();
      expect(homeDir1).toBe(homeDir2);
    });

    it("returns consistent path across test runs", () => {
      // Should return same temp directory for the same process
      const homeDir1 = getCompozyHomeDir();
      const homeDir2 = getCompozyHomeDir();
      expect(homeDir1).toBe(homeDir2);
    });
  });

  describe("getRepositoryInfo", () => {
    it("generates fallback key for non-git directory", () => {
      const info = getRepositoryInfo(tempDir);

      expect(info.key).toBeTruthy();
      expect(info.displayName).toBe(path.basename(tempDir));
      expect(info.gitRemote).toContain("local:");
      expect(info.storagePath).toContain(info.key);
    });

    it("fallback key includes slug and hash", () => {
      const info = getRepositoryInfo(tempDir);
      // Key format: {slug}-{hash} where hash is 32-character hex
      expect(info.key).toMatch(/^[a-z0-9-]+-[a-f0-9]{32}$/);
    });

    it("storage path includes key", () => {
      const info = getRepositoryInfo(tempDir);
      expect(info.storagePath).toContain(info.key);
      // In test mode, path will be in temp directory (compozy-test-...)
      // In production, path will contain .compozy
      const homeDir = getCompozyHomeDir();
      expect(info.storagePath).toContain(homeDir);
    });

    it("returns consistent info for same path", () => {
      const info1 = getRepositoryInfo(tempDir);
      const info2 = getRepositoryInfo(tempDir);

      expect(info1.key).toBe(info2.key);
      expect(info1.displayName).toBe(info2.displayName);
      expect(info1.storagePath).toBe(info2.storagePath);
    });
  });

  describe("getRepositoryDir", () => {
    it("returns path in compozy home directory", () => {
      const repoDir = getRepositoryDir(tempDir);
      const homeDir = getCompozyHomeDir();

      expect(repoDir).toContain(homeDir);
      // In test mode, directories are not automatically created
      // Tests can create them as needed
    });

    it("returns absolute path", () => {
      const repoDir = getRepositoryDir(tempDir);
      expect(path.isAbsolute(repoDir)).toBe(true);
    });

    it("returns same path for same project on multiple calls", () => {
      const repoDir1 = getRepositoryDir(tempDir);
      const repoDir2 = getRepositoryDir(tempDir);

      expect(repoDir1).toBe(repoDir2);
    });

    it("does not fail on multiple calls", () => {
      const repoDir1 = getRepositoryDir(tempDir);
      const repoDir2 = getRepositoryDir(tempDir);

      expect(repoDir1).toBe(repoDir2);
      // In test mode, directory may not exist yet - that's fine
    });

    it("includes repository key in the path", () => {
      const repoDir = getRepositoryDir(tempDir);
      const parts = repoDir.split(path.sep || "/");
      // The last part should be in format: {slug}-{hash} where hash is 32-character hex
      const lastPart = parts[parts.length - 1] || "";
      expect(/^[a-z0-9-]+-[a-f0-9]{32}$/.test(lastPart)).toBe(true);
      // Path should contain the compozy home directory
      const homeDir = getCompozyHomeDir();
      expect(repoDir).toContain(homeDir);
    });
  });

  describe("getGitRemoteOrigin", () => {
    it("returns null for non-git directory", () => {
      const remote = getGitRemoteOrigin(tempDir);
      expect(remote).toBeNull();
    });

    it("handles missing directory gracefully", () => {
      const nonExistentDir = path.join(tempDir, "does-not-exist");
      const remote = getGitRemoteOrigin(nonExistentDir);
      expect(remote).toBeNull();
    });
  });

  describe("edge cases", () => {
    it("handles very long paths", () => {
      const longPath = path.join(tempDir, "a".repeat(100), "b".repeat(100));
      const info = getRepositoryInfo(longPath);

      expect(info.key).toBeTruthy();
      expect(info.storagePath).toBeTruthy();
    });

    it("handles paths with special characters", () => {
      const specialPath = path.join(tempDir, "test-project_v1.2.3");
      const info = getRepositoryInfo(specialPath);

      expect(info.key).toBeTruthy();
      expect(info.displayName).toBe("test-project_v1.2.3");
    });

    it("handles paths with spaces", () => {
      const spacePath = path.join(tempDir, "my project folder");
      const info = getRepositoryInfo(spacePath);

      expect(info.key).toBeTruthy();
      expect(info.displayName).toBe("my project folder");
    });
  });
});
