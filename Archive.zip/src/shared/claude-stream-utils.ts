/**
 * Claude Stream Message Handling Utilities
 *
 * Provides reusable utilities for processing Claude stream messages with incremental saving.
 * Supports both Effect-based and Promise-based persistence patterns.
 */

import type { UIMessageStreamWriter } from "ai";
import { readUIMessageStream, type UIMessage } from "ai";
import { randomUUID } from "crypto";

const SAVE_INTERVAL_MS = 2000;

/**
 * Updates messages array with an incremental message update.
 * If a message with the same ID exists, it replaces it; otherwise, appends it.
 *
 * @param currentMessages - Current array of messages
 * @param incrementalMessage - New or updated message to merge
 * @returns Updated messages array
 */
export function updateMessagesWithIncremental(
  currentMessages: UIMessage[],
  incrementalMessage: UIMessage
): UIMessage[] {
  const existingIndex = currentMessages.findIndex(m => m.id === incrementalMessage.id);
  if (existingIndex >= 0) {
    return [
      ...currentMessages.slice(0, existingIndex),
      incrementalMessage,
      ...currentMessages.slice(existingIndex + 1),
    ];
  }
  return [...currentMessages, incrementalMessage];
}

/**
 * Options for processing stream with incremental saving
 */
export interface ProcessStreamOptions<TChunk = unknown> {
  /** Async iterable stream of UI message chunks */
  uiMessageStream: AsyncIterable<TChunk>;
  /** Writer to write chunks to */
  writer: UIMessageStreamWriter;
  /** Original messages array to start with */
  originalMessages: UIMessage[];
  /** Callback to save messages (supports both Effect.runFork and async/await patterns) */
  saveCallback: (messages: UIMessage[]) => Promise<void> | void;
  /** Optional callback called for each chunk (e.g., for breakToolCallIds logic) */
  onChunk?: (chunk: TChunk) => void | boolean;
}

/**
 * Processes a stream of UI message chunks with incremental saving.
 *
 * Uses a ReadableStream tee pattern to:
 * 1. Write chunks to the writer
 * 2. Parse incremental messages from the stream
 * 3. Save messages incrementally every 2 seconds (or on completion)
 *
 * Supports optional chunk handling (e.g., for breakToolCallIds feature).
 *
 * @param options - Processing options
 * @returns Promise that resolves when stream processing is complete
 */
export async function processStreamWithIncrementalSaving<TChunk = unknown>(
  options: ProcessStreamOptions<TChunk>
): Promise<void> {
  const { uiMessageStream, writer, originalMessages, saveCallback, onChunk } = options;
  let currentMessages = originalMessages;
  let lastSaveTime = Date.now();
  let shouldStop = false;
  const stream = new ReadableStream({
    async start(controller) {
      try {
        for await (const chunk of uiMessageStream) {
          // Stop reading new chunks when shouldStop is true
          if (shouldStop) {
            break;
          }
          controller.enqueue(chunk);
        }
        controller.close();
      } catch (error) {
        controller.error(error);
      }
    },
  });
  const [chunkStream, messageStream] = stream.tee();
  const messageStreamReader = messageStream.getReader();
  const chunkWriter = (async () => {
    const reader = chunkStream.getReader();
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        if (onChunk) {
          const shouldBreak = onChunk(value);
          if (shouldBreak === true) {
            shouldStop = true;
            // Don't cancel immediately - let messageStream process buffered messages
            break;
          }
        }
        writer.write(value);
      }
    } finally {
      reader.releaseLock();
    }
  })();
  try {
    // Process messages from messageStream, but stop reading new chunks when shouldStop is true
    const cancellableMessageStream = new ReadableStream({
      async pull(controller) {
        // Continue reading until the reader is done, even if shouldStop is true
        // This ensures we process all buffered messages
        const { done, value } = await messageStreamReader.read();
        if (done) {
          controller.close();
        } else {
          controller.enqueue(value);
        }
      },
      cancel() {
        messageStreamReader.cancel().catch(() => {});
      },
    });

    // Process messages until the stream ends or we've processed everything
    for await (const output of readUIMessageStream({ stream: cancellableMessageStream })) {
      // Stop processing new messages if shouldStop is true and we've processed the current one
      // But continue processing messages that are already in the stream buffer
      let incrementalMessage = output;
      if (
        output &&
        typeof output === "object" &&
        !("id" in output) &&
        "type" in output &&
        typeof (output as any).type === "string" &&
        (output as any).type.startsWith("data-")
      ) {
        const lastMessage = currentMessages[currentMessages.length - 1];
        const dataPart = output as unknown;
        if (lastMessage && lastMessage.role === "assistant") {
          incrementalMessage = {
            ...lastMessage,
            parts: [...(lastMessage.parts || []), dataPart],
          } as UIMessage;
        } else {
          incrementalMessage = {
            id: randomUUID(),
            role: "assistant",
            content: "",
            parts: [dataPart],
            createdAt: Date.now(),
          } as UIMessage;
        }
      }

      // Filter out new messages that arrive after stop signal
      // This prevents confirmation messages from being saved after tool completion
      if (shouldStop) {
        const messageExists = currentMessages.some(m => m.id === incrementalMessage.id);
        // If it's a new message that appeared after we triggered stop, discard it
        // This handles confirmation messages that the agent generates after tool completion
        if (!messageExists) {
          continue;
        }
      }

      currentMessages = updateMessagesWithIncremental(currentMessages, incrementalMessage);
      const now = Date.now();
      if (now - lastSaveTime >= SAVE_INTERVAL_MS) {
        lastSaveTime = now;
        await saveCallback(currentMessages);
      }
    }
  } finally {
    messageStreamReader.releaseLock();
  }
  await chunkWriter;
  await saveCallback(currentMessages);
}
