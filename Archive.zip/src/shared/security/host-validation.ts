/**
 * Validates an incoming HTTP `Host` header against a strict localhost allow-list.
 *
 * @param host - Raw `Host` header value (e.g. "127.0.0.1:3000"), or `undefined` when absent.
 * @param port - The listening port that must match the host value.
 * @returns `true` only when the host is an allowed localhost variant for the given port.
 */
export function validateHostHeader(host: string | undefined, port: number): boolean {
  if (!host) return false;

  const allowedHosts = [`127.0.0.1:${port}`, `localhost:${port}`, `[::1]:${port}`];
  return allowedHosts.includes(host);
}
