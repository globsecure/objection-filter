/**
 * API Key Validation
 * Simple validation that checks for compozy_ prefix.
 * Backend (Better Auth) will enforce stricter validation if needed.
 */

/**
 * Validates that an API key has the correct prefix.
 * Only checks for "compozy_" prefix - backend will enforce stricter validation.
 *
 * @param apiKey - API key to validate
 * @returns true if the key starts with "compozy_", false otherwise
 */
export function validateApiKey(apiKey: string): boolean {
  if (typeof apiKey !== "string") {
    return false;
  }
  const trimmedKey = apiKey.trim();
  return trimmedKey.startsWith("compozy_");
}
