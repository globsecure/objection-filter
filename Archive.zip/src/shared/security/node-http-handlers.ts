import type { IncomingMessage, ServerResponse } from "node:http";

import { isAllowedOrigin } from "./cors-validation";
import { validateHostHeader } from "./host-validation";

type NextHandler = () => void;

const JSON_HEADERS = { "Content-Type": "application/json" } as const;

export function createHostValidationHandler(port: number) {
  return (req: IncomingMessage, res: ServerResponse, next: NextHandler) => {
    const host = req.headers.host;

    if (!validateHostHeader(host, port)) {
      res.writeHead(403, JSON_HEADERS);
      res.end(JSON.stringify({ error: "Invalid Host header" }));
      return;
    }

    next();
  };
}

export function createCorsHandler(allowedOrigins: string[]) {
  return (req: IncomingMessage, res: ServerResponse, next: NextHandler) => {
    const origin = req.headers.origin as string | undefined;

    if (!isAllowedOrigin(origin, allowedOrigins)) {
      res.writeHead(403, JSON_HEADERS);
      res.end(JSON.stringify({ error: "CORS not allowed" }));
      return;
    }

    if (origin) {
      res.setHeader("Access-Control-Allow-Origin", origin);
    } else {
      res.setHeader("Access-Control-Allow-Origin", "null");
    }

    const varyHeader = typeof res.getHeader === "function" ? res.getHeader("Vary") : undefined;
    const originVaryValue = "Origin";

    if (!varyHeader) {
      res.setHeader("Vary", originVaryValue);
    } else if (typeof varyHeader === "string") {
      const values = varyHeader.split(/\s*,\s*/);

      if (!values.includes(originVaryValue)) {
        res.setHeader("Vary", `${varyHeader}, ${originVaryValue}`);
      }
    } else if (Array.isArray(varyHeader)) {
      const values = varyHeader.flatMap(value => value.split(/\s*,\s*/));

      if (!values.includes(originVaryValue)) {
        res.setHeader("Vary", [...varyHeader, originVaryValue]);
      }
    }

    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");

    if (req.method === "OPTIONS") {
      res.writeHead(200);
      res.end();
      return;
    }

    next();
  };
}
