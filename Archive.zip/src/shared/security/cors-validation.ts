/**
 * Determines whether a request origin is permitted.
 *
 * Treats `undefined` (non-CORS requests) and the literal string `"null"`
 * as allowed so that local file/testing contexts are not blocked.
 *
 * @param origin - Raw `Origin` header value or `undefined` when absent.
 * @param allowedOrigins - Whitelist of allowed origins.
 * @returns `true` when the origin should be allowed for CORS handling.
 */
export function isAllowedOrigin(origin: string | undefined, allowedOrigins: string[]): boolean {
  if (!origin || origin === "null") return true;

  return allowedOrigins.includes(origin);
}
