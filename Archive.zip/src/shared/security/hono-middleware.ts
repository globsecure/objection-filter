import type { Context, Next } from "hono";
import { cors } from "hono/cors";

import { isAllowedOrigin } from "./cors-validation";
import { validateHostHeader } from "./host-validation";

export function createHostValidationMiddleware(port: number) {
  return async (c: Context, next: Next) => {
    const host = c.req.header("Host");

    if (!validateHostHeader(host, port)) {
      return c.json({ error: "Invalid Host header" }, 403);
    }

    return next();
  };
}

export function createCorsMiddleware(allowedOrigins: string[]) {
  const corsMiddleware = cors({
    origin: (origin: string | undefined) => {
      if (!origin || origin === "null") {
        return "null";
      }

      return origin;
    },
    credentials: true,
    allowHeaders: ["Content-Type"],
    allowMethods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  });

  return async (c: Context, next: Next) => {
    const origin = c.req.header("Origin");

    if (!isAllowedOrigin(origin, allowedOrigins)) {
      return c.json({ error: "CORS not allowed" }, 403);
    }

    return corsMiddleware(c, next);
  };
}
