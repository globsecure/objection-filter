/**
 * List of allowed origins for CORS and related security checks.
 */
export type AllowedOrigins = string[];

/**
 * Shared security configuration for HTTP servers.
 */
export interface SecurityConfig {
  allowedOrigins: AllowedOrigins;
  expectedToken: string;
  port: number;
}

// Safely read environment variables in both browser and Node contexts without
// assuming `process` is globally available (e.g. when bundled for the web).
const runtimeEnv = typeof process !== "undefined" && process?.env ? process.env : undefined;

const readEnv = (key: string): string | undefined => runtimeEnv?.[key];

// Determine development mode without depending on Electron being present.
// `electron-is-dev` throws when Electron isn't available (e.g. in server/unit tests),
// so rely solely on environment flags that work in both Electron and browser contexts.
const isDevelopmentMode = readEnv("DEV_MODE") === "true" || readEnv("NODE_ENV") === "development";

const devPortPrimary = readEnv("VITE_DEV_PORT_1") ?? "5173";
const devPortSecondary = readEnv("VITE_DEV_PORT_2") ?? "5174";

export const DEV_SERVER_PORTS = {
  primary: devPortPrimary,
  secondary: devPortSecondary,
};

/**
 * Trusted origins that are always allowed to talk to internal services.
 * Includes Electron app/file schemes, and localhost dev origins when in development mode.
 */
export const TRUSTED_ORIGINS: AllowedOrigins = [
  "app://main",
  "file://",
  ...(isDevelopmentMode
    ? [`http://localhost:${devPortPrimary}`, `http://localhost:${devPortSecondary}`]
    : []),
];
