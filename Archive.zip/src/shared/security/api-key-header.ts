/**
 * Shared API key header name used by the backend proxy and Looper HTTP clients.
 */
export const API_KEY_HEADER = "x-api-key" as const;
