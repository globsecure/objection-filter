/**
 * API Key Provider
 * Shared types and helpers for working with Compozy API keys across packages.
 */

import * as Effect from "effect/Effect";
import type * as Fiber from "effect/Fiber";
import { pipe } from "effect/Function";
import * as Stream from "effect/Stream";
import * as SubscriptionRef from "effect/SubscriptionRef";
import { trim } from "es-toolkit/string";
import { validateApiKey } from "./security";

export type ApiKey = string;
export type ApiKeyValue = ApiKey | undefined;

/**
 * API Key Provider function type (legacy)
 *
 * Prefer using {@link ApiKeyProviderRef} for in-memory, reactive key management.
 */
export type ApiKeyProvider = () => Promise<ApiKeyValue>;

/**
 * In-memory, reactive API key store based on Effect `SubscriptionRef`.
 *
 * Use this as the single source of truth inside a process.
 */
export type ApiKeyProviderRef = SubscriptionRef.SubscriptionRef<ApiKeyValue>;

export function normalizeApiKey(input: string | undefined): ApiKeyValue {
  if (input === undefined) return undefined;
  const normalized = trim(input);
  return validateApiKey(normalized) ? normalized : undefined;
}

export function makeApiKeyProviderRef(initialApiKey?: string): Effect.Effect<ApiKeyProviderRef> {
  return SubscriptionRef.make(normalizeApiKey(initialApiKey));
}

export function setApiKeyProviderRef(
  ref: ApiKeyProviderRef,
  nextApiKey: string | undefined
): Effect.Effect<void> {
  return SubscriptionRef.set(ref, normalizeApiKey(nextApiKey));
}

/**
 * Subscribe to API key changes. Returns a forked fiber that must be interrupted by the caller when
 * the subscription is no longer needed.
 */
export function onApiKeyProviderRefChange(
  ref: ApiKeyProviderRef,
  listener: (apiKey: ApiKeyValue) => void
): Effect.Effect<Fiber.RuntimeFiber<void, never>> {
  return pipe(
    ref.changes,
    Stream.runForEach(apiKey => Effect.sync(() => listener(apiKey))),
    Effect.fork
  );
}

/**
 * Create an API key provider that reads from environment variable.
 *
 * @deprecated Prefer using {@link ApiKeyProviderRef} via {@link makeApiKeyProviderRef}.
 */
export function createEnvVarApiKeyProvider(): ApiKeyProvider {
  return async (): Promise<ApiKeyValue> => normalizeApiKey(process.env.COMPOZY_API_KEY);
}
