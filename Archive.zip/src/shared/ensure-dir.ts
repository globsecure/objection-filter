import * as fs from "node:fs";
import * as path from "node:path";

export type EnsureDirOptions = {
  recursive?: boolean;
  mode?: number;
  skipInTestEnv?: boolean;
};

const DEFAULT_DIR_MODE = 0o700;

export function ensureDir(dirPath: string, options: EnsureDirOptions = {}): string {
  const { recursive = true, mode = DEFAULT_DIR_MODE, skipInTestEnv = false } = options;

  if (
    skipInTestEnv &&
    process.env.NODE_ENV === "test" &&
    process.env.SKIP_DIR_CREATION_IN_TEST === "true"
  ) {
    return dirPath;
  }

  if (!fs.existsSync(dirPath)) {
    try {
      fs.mkdirSync(dirPath, { recursive, mode });
    } catch (error) {
      const nodeError = error as NodeJS.ErrnoException;
      if (nodeError.code === "EEXIST") {
        if (!fs.existsSync(dirPath)) {
          throw error;
        }
        return dirPath;
      }
      throw error;
    }
  }

  return dirPath;
}

export function ensureParentDir(filePath: string, options?: EnsureDirOptions): string {
  return ensureDir(path.dirname(filePath), options);
}
