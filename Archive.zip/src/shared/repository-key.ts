/**
 * Repository Key Generation
 * Generates unique, stable repository identifiers from git remotes
 * Used to create per-repository storage directories in $HOME/.compozy/
 */

import { execSync } from "child_process";
import * as crypto from "crypto";
import * as fs from "fs";
import * as os from "os";
import * as path from "path";
import { normalizeGitRemote } from "./normalize-git-remote";

/**
 * Repository information derived from git remote
 */
export interface RepositoryInfo {
  /** Repository key in format: {slug}-{hash} (e.g., "user-repo-abc123...") */
  key: string;
  /** Human-readable repository name (e.g., "user/repo") */
  displayName: string;
  /** Normalized git remote URL */
  gitRemote: string;
  /** Full path to repository storage directory in Compozy home */
  storagePath: string;
}

/**
 * Get git remote origin URL for a repository
 * @param projectPath - Absolute path to the project directory
 * @returns Remote URL or null if not a git repository
 */
export function getGitRemoteOrigin(projectPath: string): string | null {
  try {
    const remote = execSync("git remote get-url origin", {
      cwd: projectPath,
      encoding: "utf-8",
      stdio: ["pipe", "pipe", "ignore"], // Suppress stderr
    }).trim();

    return remote || null;
  } catch {
    // Not a git repository or no remote configured
    return null;
  }
}

// Re-export normalizeGitRemote for convenience
export { normalizeGitRemote } from "./normalize-git-remote";

/**
 * Generate stable repository key from normalized git remote URL
 * Uses MD5 hash of normalized remote URL for stable, deterministic keys
 *
 * @param normalizedGitRemote - Already normalized git remote URL
 * @returns 32-character hexadecimal hash
 */
export function generateRepositoryKeyFromNormalized(normalizedGitRemote: string): string {
  return crypto.createHash("md5").update(normalizedGitRemote).digest("hex");
}

/**
 * Generate stable repository key from git remote
 * Accepts raw git remote and normalizes internally for convenience
 * Uses MD5 hash of normalized remote URL
 *
 * @param gitRemote - Raw git remote URL (will be normalized internally)
 * @returns 32-character hexadecimal hash
 */
export function generateRepositoryKey(gitRemote: string): string {
  const normalized = normalizeGitRemote(gitRemote);
  return generateRepositoryKeyFromNormalized(normalized);
}

/**
 * Generate a URL-friendly slug from repository name
 * Converts display name to a filesystem-safe identifier
 *
 * @param name - Repository display name (e.g., "user/repo" or directory basename)
 * @returns URL-safe slug (e.g., "user-repo" or "my-project")
 */
function generateRepositorySlug(name: string): string {
  // Custom slugify implementation that works in Electron Main process
  // Handles Unicode by normalizing and converting to ASCII-safe characters
  // Limit length to 50 characters to avoid filesystem path length issues
  return name
    .toLowerCase()
    .trim()
    .normalize("NFD") // Decompose Unicode characters
    .replace(/[\u0300-\u036f]/g, "") // Remove diacritics
    .replace(/[^a-z0-9]+/g, "-") // Replace non-alphanumeric chars with hyphens
    .replace(/^-+|-+$/g, "") // Remove leading/trailing hyphens
    .replace(/-+/g, "-") // Replace consecutive hyphens with single hyphen
    .slice(0, 50); // Limit length
}

/**
 * Extract display name from normalized git remote
 * @param normalized - Normalized git remote URL
 * @returns Display name (e.g., "user/repo" from "github.com/user/repo")
 */
function extractDisplayName(normalized: string): string {
  // Extract last two path segments (e.g., "user/repo" from "github.com/user/repo")
  const parts = normalized.split("/");
  if (parts.length >= 2) {
    return parts.slice(-2).join("/");
  }
  return normalized;
}

/**
 * Get repository information including key and display name
 * Falls back to directory-based key for non-git projects
 *
 * @param projectPath - Absolute path to the project directory
 * @returns Repository information with key, display name, and storage path
 */
export function getRepositoryInfo(projectPath: string): RepositoryInfo {
  const gitRemote = getGitRemoteOrigin(projectPath);
  const compozyHome = getCompozyHomeDir();

  if (gitRemote) {
    // Git repository: use remote-based key
    const normalized = normalizeGitRemote(gitRemote);
    const hash = generateRepositoryKeyFromNormalized(normalized);

    // Extract display name from normalized URL (last two path components)
    const displayName = extractDisplayName(normalized);
    const slug = generateRepositorySlug(displayName);

    // Key format: {slug}-{hash} for easy identification
    const key = `${slug}-${hash}`;

    return {
      key,
      displayName,
      gitRemote: normalized,
      storagePath: path.join(compozyHome, key),
    };
  }

  // Non-git directory: use directory basename + full path hash
  // Hash the combined string for consistency (like looper)
  const basename = path.basename(projectPath);
  const fullPathHash = crypto.createHash("md5").update(projectPath).digest("hex").slice(0, 8);
  const hash = generateRepositoryKeyFromNormalized(`${basename}-${fullPathHash}`);
  const displayName = basename;
  const slug = generateRepositorySlug(displayName);

  // Key format: {slug}-{hash} for easy identification
  const key = `${slug}-${hash}`;

  return {
    key,
    displayName,
    gitRemote: `local:${projectPath}`,
    storagePath: path.join(compozyHome, key),
  };
}

let testBaseDir: string | undefined;

/**
 * Get Compozy home directory ($HOME/.compozy)
 * Automatically uses temporary directory when NODE_ENV === 'test'
 * Creates directory if it doesn't exist (only when NOT in test mode)
 *
 * @returns Absolute path to Compozy home directory
 */
export function getCompozyHomeDir(): string {
  // Auto-detect test environment
  if (process.env.NODE_ENV === "test") {
    if (!testBaseDir) {
      testBaseDir = path.join(os.tmpdir(), `compozy-test-${process.pid}-${Date.now()}`);
    }
    return testBaseDir;
  }

  const homeDir = os.homedir();
  const compozyHome = path.join(homeDir, ".compozy");

  // Only create directory in non-test mode
  if (!fs.existsSync(compozyHome)) {
    try {
      fs.mkdirSync(compozyHome, { recursive: true, mode: 0o700 });
    } catch (error) {
      const nodeError = error as NodeJS.ErrnoException;
      // EEXIST can happen in race conditions - another process created the directory
      // between existsSync check and mkdirSync call. This is safe to ignore.
      if (nodeError.code === "EEXIST") {
        // Directory was created by another process, verify it exists now
        if (!fs.existsSync(compozyHome)) {
          throw error; // Re-throw if directory still doesn't exist
        }
        return compozyHome; // Directory exists, success
      }
      // Re-throw other errors (permissions, disk space, etc.)
      throw error;
    }
  }

  return compozyHome;
}

/**
 * Cleanup function for test environments
 * Removes the temporary .compozy directory created during tests
 * Should be called in test afterEach hooks
 */
export function cleanupTestCompozyHomeDir(): void {
  if (testBaseDir) {
    // NOTE: Test files may run in parallel, and this module-level `testBaseDir`
    // is shared within the same process. Deleting the directory here can race
    // with other concurrently running tests that are still using it.
    //
    // Instead of deleting eagerly, just reset the pointer so the *next* test
    // that calls `getCompozyHomeDir()` gets a fresh directory. The old directory
    // is left for the OS to clean up from temp (or can be cleaned manually).
    testBaseDir = undefined;
  }
}

/**
 * Get repository-specific directory in Compozy home
 * Creates directory if it doesn't exist (only when NOT in test mode)
 *
 * @param projectPath - Absolute path to the project directory
 * @returns Absolute path to repository storage directory ($HOME/.compozy/{repo-key}/)
 */
export function getRepositoryDir(projectPath: string): string {
  const info = getRepositoryInfo(projectPath);
  const repoDir = info.storagePath;

  // Only create directory when NOT in test mode
  if (process.env.NODE_ENV !== "test" && !fs.existsSync(repoDir)) {
    try {
      fs.mkdirSync(repoDir, { recursive: true, mode: 0o700 });
    } catch (error) {
      const nodeError = error as NodeJS.ErrnoException;
      // EEXIST can happen in race conditions - another process created the directory
      // between existsSync check and mkdirSync call. This is safe to ignore.
      if (nodeError.code === "EEXIST") {
        // Directory was created by another process, verify it exists now
        if (!fs.existsSync(repoDir)) {
          throw error; // Re-throw if directory still doesn't exist
        }
        return repoDir; // Directory exists, success
      }
      // Re-throw other errors (permissions, disk space, etc.)
      throw error;
    }
  }

  return repoDir;
}
