import { isPlainObject } from "es-toolkit/predicate";

import type { IpcErrorResponse, IpcResponse } from "./ipc-types";
import { isIpcResponse } from "./ipc-types";
import { createIpcError, createIpcSuccess, getIpcErrorMessage } from "./ipc-utils";

export type IpcInvoker = {
  invoke(channel: string, ...args: unknown[]): Promise<unknown>;
};

export class IpcInvokeError extends Error {
  public readonly channel: string;
  public readonly code?: string;

  constructor(options: { channel: string; message: string; code?: string }) {
    super(options.message);
    this.name = "IpcInvokeError";
    this.channel = options.channel;
    this.code = options.code;
  }
}

function isLegacyErrorShape(value: unknown): value is { error: string; code?: string } {
  if (!isPlainObject(value)) return false;
  if (typeof value.error !== "string") return false;
  if ("code" in value && typeof value.code !== "string" && typeof value.code !== "undefined") {
    return false;
  }
  return true;
}

export function normalizeIpcResponse<T>(value: unknown): IpcResponse<T> {
  if (isIpcResponse<T>(value)) return value;

  // Backward compatibility: some handlers historically returned `{ error: string }` or `{ error, code }`.
  if (isLegacyErrorShape(value)) {
    return createIpcError(value.error, value.code);
  }

  return createIpcSuccess(value as T);
}

export async function invokeIpcResponse<T>(
  invoker: IpcInvoker,
  channel: string,
  ...args: unknown[]
): Promise<IpcResponse<T>> {
  try {
    const raw = await invoker.invoke(channel, ...args);
    return normalizeIpcResponse<T>(raw);
  } catch (error) {
    return createIpcError(getIpcErrorMessage(error), `IPC_INVOKE_FAILED:${channel}`);
  }
}

export async function invokeIpc<T>(
  invoker: IpcInvoker,
  channel: string,
  ...args: unknown[]
): Promise<T> {
  const response = await invokeIpcResponse<T>(invoker, channel, ...args);
  if (response.success) return response.data;

  throw new IpcInvokeError({ channel, message: response.error, code: response.code });
}

export function asIpcErrorResponse(error: unknown, code?: string): IpcErrorResponse {
  return createIpcError(getIpcErrorMessage(error), code);
}
