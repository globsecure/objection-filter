import * as http from "node:http";
import type { AddressInfo } from "node:net";

export interface HttpTestResponse {
  status: number;
  data: string;
  headers: http.IncomingHttpHeaders;
}

/**
 * Allocate a free TCP port on localhost. Useful for spinning up ephemeral
 * servers during tests without port collisions.
 */
export const getAvailablePort = async (): Promise<number> => {
  return await new Promise((resolve, reject) => {
    const tempServer = http.createServer();

    tempServer.listen(0, "127.0.0.1", () => {
      const address = tempServer.address() as AddressInfo;
      tempServer.close(() => resolve(address.port));
    });

    tempServer.on("error", reject);
  });
};

/**
 * Minimal HTTP request helper for integration tests. Sends the request and
 * returns status, response body, and headers.
 */
export const sendRequest = async (
  options: http.RequestOptions,
  body?: string
): Promise<HttpTestResponse> => {
  return await new Promise<HttpTestResponse>((resolve, reject) => {
    const req = http.request(options, res => {
      let data = "";

      res.on("data", chunk => {
        data += chunk.toString();
      });

      res.on("end", () => {
        resolve({ status: res.statusCode ?? 0, data, headers: res.headers });
      });
    });

    req.on("error", reject);

    if (body) {
      req.write(body);
    }

    req.end();
  });
};
