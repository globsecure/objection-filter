import * as matchers from "@testing-library/jest-dom/matchers";
import { expect } from "vitest";
import { JSDOM } from "jsdom";

if (typeof globalThis.window === "undefined") {
  const dom = new JSDOM("<!doctype html><html><body></body></html>", {
    url: "http://localhost/",
  });

  globalThis.window = dom.window as any;
  globalThis.document = dom.window.document;
  globalThis.navigator = dom.window.navigator;

  // Copy other window properties to global
  Object.getOwnPropertyNames(dom.window).forEach(property => {
    if (!(property in globalThis)) {
      (globalThis as any)[property] = (dom.window as any)[property];
    }
  });
}

// Mock requestAnimationFrame and cancelAnimationFrame (not provided by JSDOM)
// Must be set on both globalThis.window AND globalThis for base-ui compatibility
let rafId = 0;
const rafHandles = new Map<number, ReturnType<typeof setTimeout>>();

const requestAnimationFrameImpl = function (callback: FrameRequestCallback): number {
  rafId++;
  const currentId = rafId;
  // Use setTimeout to simulate async behavior
  const handle = setTimeout(() => {
    try {
      const timestamp =
        typeof performance !== "undefined" && performance.now ? performance.now() : Date.now();
      callback(timestamp);
    } finally {
      // Clean up the handle after execution (even if callback throws)
      rafHandles.delete(currentId);
    }
  }, 0);
  rafHandles.set(currentId, handle);
  return currentId;
};

const cancelAnimationFrameImpl = function (id: number): void {
  const handle = rafHandles.get(id);
  if (handle !== undefined) {
    clearTimeout(handle);
    rafHandles.delete(id);
  }
};

if (typeof globalThis.window.requestAnimationFrame === "undefined") {
  globalThis.window.requestAnimationFrame = requestAnimationFrameImpl;
}

if (typeof globalThis.window.cancelAnimationFrame === "undefined") {
  globalThis.window.cancelAnimationFrame = cancelAnimationFrameImpl;
}

// Also set on globalThis for modules that access requestAnimationFrame directly.
// JSDOM does not provide RAF, and some libraries (React 19, base-ui, and other modules)
// reference requestAnimationFrame directly on globalThis rather than window.
// We set both window and globalThis for compatibility.
if (typeof globalThis.requestAnimationFrame === "undefined") {
  (globalThis as any).requestAnimationFrame = requestAnimationFrameImpl;
}

if (typeof globalThis.cancelAnimationFrame === "undefined") {
  (globalThis as any).cancelAnimationFrame = cancelAnimationFrameImpl;
}

// Polyfill window.event for React DOM 19 compatibility
// React DOM 19's resolveUpdatePriority tries to access window.event
// which doesn't exist in jsdom. This provides a safe fallback.
Object.defineProperty(globalThis.window, "event", {
  configurable: true,
  enumerable: true,
  get: () => undefined,
  set: () => {
    // Allow setting but ignore (for compatibility)
  },
});

// Mock window.matchMedia (not provided by JSDOM)
// Required for components that use media queries (e.g., useIsMobile hook in SidebarProvider)
// Default mock returns false for all queries; individual tests can override window.matchMedia
// when specific responsive behavior needs verification
if (typeof globalThis.window.matchMedia === "undefined") {
  globalThis.window.matchMedia = function (query: string): MediaQueryList {
    return {
      matches: false,
      media: query,
      onchange: null,
      addListener: () => {},
      removeListener: () => {},
      addEventListener: () => {},
      removeEventListener: () => {},
      dispatchEvent: () => true,
    } as MediaQueryList;
  };
}

// Mock ResizeObserver (not provided by JSDOM).
if (typeof globalThis.window.ResizeObserver === "undefined") {
  globalThis.window.ResizeObserver = class {
    observe() {}
    unobserve() {}
    disconnect() {}
  } as unknown as typeof ResizeObserver;
}

if (typeof globalThis.ResizeObserver === "undefined") {
  globalThis.ResizeObserver = globalThis.window.ResizeObserver;
}

// JSDOM does not implement Element.getAnimations, but Base UI expects it.
if (typeof globalThis.Element !== "undefined" && !globalThis.Element.prototype.getAnimations) {
  globalThis.Element.prototype.getAnimations = () => [];
}

// CRITICAL: Extend Vitest's expect with jest-dom matchers
// Cast to any to work around type incompatibility between Vitest's expect and jest-dom types
expect.extend(matchers as any);
