/**
 * Shared localStorage mock for tests
 * This provides a consistent localStorage implementation across all test files
 */
export function createLocalStorageMock() {
  let store: Record<string, string> = {};

  return {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => {
      store[key] = value.toString();
    },
    removeItem: (key: string) => {
      delete store[key];
    },
    clear: () => {
      store = {};
    },
    get length() {
      return Object.keys(store).length;
    },
    key: (index: number) => {
      const keys = Object.keys(store);
      return keys[index] || null;
    },
  };
}

/**
 * Setup localStorage mock globally
 * Call this in test setup files
 */
export function setupLocalStorageMock() {
  const localStorageMock = createLocalStorageMock();
  Object.defineProperty(global, "localStorage", {
    value: localStorageMock,
    writable: true,
    configurable: true,
  });
  return localStorageMock;
}
