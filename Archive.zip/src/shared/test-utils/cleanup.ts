/**
 * Root-level test cleanup utility
 * This file cleans up temporary compozy-test directories created during test runs
 * Prevents bloat in the temp directory from test directories that weren't cleaned up
 * (e.g., due to test crashes or interrupted test runs)
 *
 * Import this file as a side-effect in your Vitest setupFiles (recommended),
 * or at the top of a test file:
 * ```ts
 * import "@shared/test-utils/cleanup";
 * ```
 */

import { afterAll } from "vitest";
import * as fs from "fs";
import * as os from "os";
import * as path from "path";

const STALE_DIR_MAX_AGE_MS = 1000 * 60 * 60; // 1 hour

afterAll(() => {
  try {
    const tmpDir = os.tmpdir();
    const entries = fs.readdirSync(tmpDir, { withFileTypes: true });
    const now = Date.now();

    for (const entry of entries) {
      // Only process directories that match the compozy-test pattern
      if (entry.isDirectory() && entry.name.startsWith("compozy-test-")) {
        const dirPath = path.join(tmpDir, entry.name);
        try {
          const stats = fs.statSync(dirPath);
          const ageMs = now - stats.mtimeMs;
          if (ageMs < STALE_DIR_MAX_AGE_MS) {
            continue;
          }
          fs.rmSync(dirPath, { recursive: true, force: true });
        } catch (error) {
          // Log but don't throw - cleanup errors shouldn't fail tests
          // Some directories might be in use or have permission issues
          console.warn(`Failed to cleanup test directory ${dirPath}: ${error}`);
        }
      }
    }
  } catch (error) {
    // Log but don't throw - cleanup errors shouldn't fail tests
    console.warn(`Failed to cleanup test directories: ${error}`);
  }
});
