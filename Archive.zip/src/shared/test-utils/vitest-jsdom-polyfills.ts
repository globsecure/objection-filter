// Vitest + JSDOM global polyfills and jest-dom matchers.
// This file exists to provide a stable import path for Vitest setups.
import "./vitest-jsdom";
