import type { TestingLibraryMatchers } from "@testing-library/jest-dom/matchers";
import { cleanup } from "@testing-library/react";
import { afterEach, beforeAll, vi } from "vitest";

declare module "vitest" {
  // Extend Vitest's assertions with jest-dom matchers.
  // Type conflicts are suppressed via skipLibCheck in tsconfig.json.
  interface Assertion<T = any> extends TestingLibraryMatchers<any, T> {}

  interface AsymmetricMatchersContaining extends TestingLibraryMatchers<any, unknown> {}
}

if (!(globalThis as any).jest) {
  // Some libraries still look for a Jest-compatible global.
  // Vitest's `vi` provides compatible timer/mocking APIs for most cases.
  (globalThis as any).jest = vi;
}

beforeAll(() => {
  Object.defineProperty(window, "env", {
    writable: true,
    value: {
      apiUrl: "http://localhost:3002",
    },
  });
  if (typeof HTMLFormElement.prototype.requestSubmit !== "function") {
    HTMLFormElement.prototype.requestSubmit = function requestSubmit(
      this: HTMLFormElement,
      submitter?: HTMLElement
    ) {
      if (submitter) {
        submitter.click();
        return;
      }
      const event = new Event("submit", { bubbles: true, cancelable: true });
      const defaultNotPrevented = this.dispatchEvent(event);
      if (defaultNotPrevented && typeof HTMLFormElement.prototype.submit === "function") {
        HTMLFormElement.prototype.submit.call(this);
      }
    };
  }
});

afterEach(() => {
  cleanup();
});
