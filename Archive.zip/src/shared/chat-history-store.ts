import type { UIMessage } from "ai";

/**
 * Artifact reference tracked in chat history.
 * Provides recovery mechanism if indexing fails.
 */
export interface ChatHistoryArtifact {
  id: string;
  type: "prd" | "techspec" | "task";
  filePath: string;
  createdAt: number;
}

/**
 * ChatHistoryStore interface for chat history persistence.
 * Provides methods to load, save, update, and delete chat messages.
 *
 * This is a pure interface definition with no implementation dependencies.
 * Implementations should be provided by specific storage backends (e.g., SQLite).
 */
export interface ChatHistoryStore {
  /**
   * Load all messages for a given chat ID.
   * @param chatId - The chat identifier
   * @param toolSchemas - Optional tool schemas (for backward compatibility)
   * @returns Promise resolving to an array of UI messages
   */
  loadMessages(chatId: string, toolSchemas?: unknown[]): Promise<UIMessage[]>;

  /**
   * Save messages for a given chat ID.
   * @param chatId - The chat identifier
   * @param messages - Array of UI messages to save
   * @param toolSchemas - Optional tool schemas (for backward compatibility)
   * @returns Promise that resolves when messages are saved
   */
  saveMessages(chatId: string, messages: UIMessage[], toolSchemas?: unknown[]): Promise<void>;

  /**
   * Update a specific message in a chat.
   * @param chatId - The chat identifier
   * @param messageId - The message identifier
   * @param updater - Function that takes the existing message and returns the updated message
   * @returns Promise that resolves when the message is updated
   */
  updateMessage(
    chatId: string,
    messageId: string,
    updater: (message: UIMessage) => UIMessage
  ): Promise<void>;

  /**
   * Delete all messages for a given chat ID.
   * @param chatId - The chat identifier
   * @returns Promise that resolves when the chat is deleted
   */
  deleteChat(chatId: string): Promise<void>;

  /**
   * List all chat IDs that have stored messages.
   * @returns Promise resolving to an array of chat IDs
   */
  listChats(): Promise<string[]>;

  /**
   * Add an artifact reference to the chat history for recovery purposes.
   * This allows re-indexing artifacts if the SQLite index is lost or corrupted.
   * @param chatId - The chat identifier
   * @param artifact - The artifact reference to add
   * @returns Promise that resolves when the artifact is added
   */
  addArtifact(chatId: string, artifact: ChatHistoryArtifact): Promise<void>;

  /**
   * Get all artifact references from a chat history.
   * Returns empty array if chat doesn't exist or has no artifacts.
   * @param chatId - The chat identifier
   * @returns Promise resolving to an array of artifact references
   */
  getArtifacts(chatId: string): Promise<ChatHistoryArtifact[]>;
}
