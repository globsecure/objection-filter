/**
 * Supported IDE types for opening projects
 */
export type IDEType =
  | "vscode"
  | "cursor"
  | "fleet"
  | "zed"
  | "windsurf"
  | "antigravity"
  | "idea"
  | "pycharm"
  | "webstorm"
  | "sublime"
  | "android-studio"
  | "xcode"
  | "eclipse"
  | "atom";

/**
 * Display labels for each IDE
 */
export const IDE_LABELS: Record<IDEType, string> = {
  vscode: "VS Code",
  cursor: "Cursor",
  fleet: "Fleet",
  zed: "Zed",
  windsurf: "Windsurf",
  antigravity: "Antigravity",
  idea: "IntelliJ IDEA",
  pycharm: "PyCharm",
  webstorm: "WebStorm",
  sublime: "Sublime Text",
  "android-studio": "Android Studio",
  xcode: "Xcode",
  eclipse: "Eclipse",
  atom: "Atom",
};

/**
 * CLI command mappings for each IDE
 */
export const IDE_COMMANDS: Record<IDEType, string> = {
  vscode: "code",
  cursor: "cursor",
  fleet: "fleet",
  zed: "zed",
  windsurf: "windsurf",
  antigravity: "antigravity",
  idea: "idea",
  pycharm: "charm",
  webstorm: "webstorm",
  sublime: "subl",
  "android-studio": "studio",
  xcode: "xed",
  eclipse: "eclipse",
  atom: "atom",
};
