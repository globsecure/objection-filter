/**
 * Server Configuration Utilities
 * Provides reusable functions for parsing URLs and creating server configurations
 */

import { invariant } from "es-toolkit/util";
import { trim } from "es-toolkit/string";

/**
 * Parses a URL and extracts host and port.
 * Defaults to localhost:port if URL parsing fails unless strict parsing is requested.
 *
 * @param url - URL string to parse (e.g., "http://127.0.0.1:21230")
 * @param defaultPort - Default port to use if URL parsing fails or port is missing
 * @param strict - When true, rethrows parsing errors instead of falling back
 * @returns Object with host and port
 *
 * @example
 * ```ts
 * const { host, port } = parseUrl("http://127.0.0.1:21230", 21230);
 * // { host: "127.0.0.1", port: 21230 }
 * ```
 */
export function parseUrl(
  url: string,
  defaultPort: number,
  strict = false
): { host: string; port: number } {
  try {
    const parsed = new URL(url);
    return {
      host: parsed.hostname,
      port: parsed.port ? Number(parsed.port) : defaultPort,
    };
  } catch (error) {
    if (strict) {
      throw error;
    }

    return {
      host: "127.0.0.1",
      port: defaultPort,
    };
  }
}

/**
 * Removes trailing slashes from a URL string.
 *
 * @param value - URL string to process
 * @returns URL string without trailing slashes
 *
 * @example
 * ```ts
 * stripTrailingSlash("http://localhost:3002/") // "http://localhost:3002"
 * ```
 */
export function stripTrailingSlash(value: string): string {
  return value.replace(/\/+$/, "");
}

/**
 * Creates a URL from host and port.
 *
 * @param host - Hostname or IP address
 * @param port - Port number
 * @param protocol - Protocol (default: "http")
 * @returns Complete URL string
 *
 * @example
 * ```ts
 * createUrl("127.0.0.1", 21230) // "http://127.0.0.1:21230"
 * createUrl("localhost", 3002, "https") // "https://localhost:3002"
 * ```
 */
export function createUrl(host: string, port: number, protocol: "http" | "https" = "http"): string {
  return `${protocol}://${host}:${port}`;
}

/**
 * Options for creating a server configuration
 */
export interface CreateServerConfigOptions {
  /** Environment variable name for the server URL (e.g., "AGENT_SERVER_URL") */
  urlEnvVar: string;
  /** Default port to use if URL parsing fails */
  defaultPort: number;
}

/**
 * Server configuration result
 */
export interface ServerConfig {
  /** Full server URL without trailing slashes */
  url: string;
  /** Hostname or IP address */
  host: string;
  /** Port number */
  port: number;
}

/**
 * Creates a server configuration from environment variables.
 * Requires the specified URL environment variable to be set.
 *
 * @param options - Configuration options
 * @returns Server configuration object with url, host, and port
 * @throws Error if the required environment variable is not set
 *
 * @example
 * ```ts
 * const config = createServerConfig({
 *   urlEnvVar: "AGENT_SERVER_URL",
 *   defaultPort: 21230,
 * });
 * // Returns { url: "http://127.0.0.1:21230", host: "127.0.0.1", port: 21230 }
 * ```
 */
export function createServerConfig(options: CreateServerConfigOptions): ServerConfig {
  const { urlEnvVar, defaultPort } = options;

  const rawUrl = process.env[urlEnvVar];
  const serverUrl = rawUrl ? trim(rawUrl) : "";

  invariant(
    serverUrl,
    `${urlEnvVar} environment variable is required. Example: ${urlEnvVar}=http://127.0.0.1:${defaultPort}`
  );

  const parsed = parseUrl(serverUrl, defaultPort, true);
  return {
    url: stripTrailingSlash(serverUrl),
    host: parsed.host,
    port: parsed.port,
  };
}

/**
 * Creates a lazy server configuration that evaluates on first access.
 * Useful for tests that set environment variables after module load.
 *
 * @param options - Configuration options
 * @returns Server configuration object with lazy getters for url, host, and port
 *
 * @example
 * ```ts
 * const config = createLazyServerConfig({
 *   urlEnvVar: "LOOPER_SERVER_URL",
 *   defaultPort: 21231,
 * });
 * // Accessing config.url will evaluate the config at that time
 * ```
 */
export function createLazyServerConfig(options: CreateServerConfigOptions): {
  get url(): string;
  get host(): string;
  get port(): number;
} {
  let cachedConfig: ServerConfig | null = null;
  let cachedEnvValue: string | undefined;

  function getCachedConfig(): ServerConfig {
    const currentEnvValue = process.env[options.urlEnvVar];

    // Recompute when the backing environment variable changes between calls.
    // This is important in test environments where different suites set
    // different URLs (e.g., random free ports) and expect the server to bind
    // to the updated value.
    if (!cachedConfig || currentEnvValue !== cachedEnvValue) {
      cachedConfig = createServerConfig(options);
      cachedEnvValue = currentEnvValue;
    }
    return cachedConfig;
  }

  return {
    get url() {
      return getCachedConfig().url;
    },
    get host() {
      return getCachedConfig().host;
    },
    get port() {
      return getCachedConfig().port;
    },
  };
}
