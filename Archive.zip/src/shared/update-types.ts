/**
 * Shared types for the auto-update system.
 * Used across main process, preload, and renderer.
 */

export interface UpdateProgress {
  percent: number;
  bytesPerSecond: number;
  transferred: number;
  total: number;
}

export interface UpdateInfo {
  version: string;
  releaseDate?: string;
  releaseNotes?: string;
}

export interface UpdateError {
  message: string;
}

export interface UpdateCheckResult {
  updateAvailable: boolean;
  version?: string;
}

export interface UpdateStatus {
  autoDownload: boolean;
  autoInstallOnAppQuit: boolean;
}

export interface UpdateDownloadedInfo {
  version: string;
  releaseDate?: string;
}

export interface UpdateNotAvailableInfo {
  version: string;
}
