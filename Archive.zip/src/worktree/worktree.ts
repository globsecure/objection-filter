import type { WorktreeInfo, WorktreeSetupCommandsStatus } from "../shared/global-settings";

/**
 * Information about a git branch.
 */
export interface BranchInfo {
  /** Branch name (without refs/heads/ or refs/remotes/ prefix) */
  name: string;
  /** Whether this is the currently checked out branch */
  isCurrent: boolean;
  /** Whether this is a remote branch */
  isRemote: boolean;
  /** The remote name if this is a remote branch (e.g., "origin") */
  remoteName?: string;
}

/**
 * Options for listing branches in a repository.
 */
export interface WorktreeBranchListOptions {
  /** Absolute path to the repository root directory */
  repositoryPath: string;
  /** Whether to include remote branches (default: true) */
  includeRemote?: boolean;
}

/**
 * Options for creating a new git worktree.
 */
export interface WorktreeCreateOptions {
  /** Absolute path to the repository root directory */
  repositoryPath: string;
  /** Unique identifier for the repository in the application */
  repositoryId: string;
  /** Human-readable display name for the worktree */
  name: string;
  /** Issue slug used to generate the branch name (e.g., "fix-login-bug") */
  issueSlug: string;
  /** Optional issue identifier for external linking (e.g., GitHub issue number) */
  issueId?: string;
  /** Optional branch name prefix (e.g., "pedro" results in "pedro/fix-login-bug") */
  branchPrefix?: string;
  /** Optional explicit branch name (overrides slug-based generation) */
  branchName?: string;
  /** Optional base branch to create the worktree from (defaults to current HEAD) */
  baseBranch?: string;
  /** Whether to run setup commands after worktree creation */
  runSetupCommands?: boolean;
  /** Array of shell commands to execute in the worktree after creation */
  setupCommands?: string[];
}

/**
 * Result of a successful worktree creation operation.
 */
export interface WorktreeCreateResult {
  /** The created worktree metadata */
  worktree: WorktreeInfo;
  /** The final branch name used (may differ from requested if collision occurred) */
  branchName: string;
  /** Absolute path to the worktree directory */
  worktreePath: string;
  /** Status of setup commands execution, if any were run */
  setupCommandsStatus?: WorktreeSetupCommandsStatus;
  /** Combined stdout/stderr output from setup commands execution */
  setupCommandsOutput?: string;
}

/**
 * Git status information for a worktree.
 */
export interface WorktreeGitStatus {
  /** Whether the worktree has any uncommitted changes */
  hasChanges: boolean;
  /** Files that are staged for commit */
  stagedFiles: string[];
  /** Files that are modified but not staged */
  unstagedFiles: string[];
  /** Files that are not tracked by git */
  untrackedFiles: string[];
}

/**
 * Options for listing worktrees in a repository.
 */
export interface WorktreeListOptions {
  /** Absolute path to the repository root directory */
  repositoryPath: string;
  /** Unique identifier for the repository in the application */
  repositoryId: string;
}

/**
 * Options for archiving a worktree.
 * Archiving removes the worktree directory but keeps the metadata.
 */
export interface WorktreeArchiveOptions {
  /** Absolute path to the repository root directory */
  repositoryPath: string;
  /** Unique identifier of the worktree to archive */
  worktreeId: string;
}

/**
 * Options for removing a worktree permanently.
 * Removes both the worktree directory and its metadata.
 */
export interface WorktreeRemoveOptions {
  /** Absolute path to the repository root directory */
  repositoryPath: string;
  /** Unique identifier of the worktree to remove */
  worktreeId: string;
  /** Whether to also delete the remote branch (default: false) */
  deleteRemoteBranch?: boolean;
}

/**
 * Options for running setup commands in a worktree.
 * Supports variable substitution for $ROOT_WORKTREE_PATH, $WORKTREE_PATH, and $BRANCH_NAME.
 */
export interface WorktreeRunSetupCommandsOptions {
  /** Absolute path to the repository root directory */
  repositoryPath: string;
  /** Absolute path to the worktree directory */
  worktreePath: string;
  /** Name of the branch checked out in the worktree */
  branchName: string;
  /** Array of shell commands to execute (supports variable substitution) */
  commands: string[];
}

/**
 * Options for retrieving setup commands for a repository.
 */
export interface WorktreeGetSetupCommandsOptions {
  /** Absolute path to the repository root directory */
  repositoryPath: string;
  /** Unique identifier for the repository in the application */
  repositoryId: string;
}

/**
 * Configuration for worktrees stored in project config files.
 * Can be placed in `.compozy/worktrees.json` or `.cursor/worktrees.json`.
 */
export interface ProjectWorktreeConfig {
  /**
   * Array of shell commands to run after worktree creation.
   *
   * NOTE: The hyphenated property name `"setup-worktree"` is intentional and must
   * match the expected key in the external JSON config files (`.compozy/worktrees.json`
   * or `.cursor/worktrees.json`). Do not change to camelCase.
   */
  "setup-worktree"?: string[];
}

/**
 * Type of conflict detected when checking for worktree/branch collisions.
 */
export type WorktreeConflictType = "branch" | "directory" | "both";

/**
 * Options for checking if a worktree/branch name conflicts with existing ones.
 */
export interface WorktreeCheckConflictOptions {
  /** Absolute path to the repository root directory */
  repositoryPath: string;
  /** Unique identifier for the repository in the application */
  repositoryId: string;
  /** The branch name to check for conflicts */
  branchName: string;
}

/**
 * Result of checking for worktree/branch conflicts.
 */
export interface WorktreeConflictResult {
  /** Whether there is a conflict */
  hasConflict: boolean;
  /** Type of conflict detected (null if no conflict) */
  conflictType: WorktreeConflictType | null;
  /** ID of existing worktree if one exists with this branch (null otherwise) */
  existingWorktreeId: string | null;
  /** The sanitized branch name that was checked */
  checkedBranchName: string;
}
