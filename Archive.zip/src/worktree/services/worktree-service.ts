import { getLogger } from "@logtape/logtape";
import type { BrowserWindow, IpcMain } from "electron";
import { cloneDeep } from "es-toolkit/object";
import { kebabCase, trim } from "es-toolkit/string";
import { execFile } from "node:child_process";
import crypto from "node:crypto";
import { existsSync, realpathSync } from "node:fs";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { promisify } from "node:util";
import {
  DEFAULT_GIT_SETTINGS,
  DEFAULT_SETUP_WORKTREE_COMMANDS,
  sanitizeGitSettings,
  sanitizeSetupWorktreeCommands,
  type GitSettings,
  type SetupWorktreeCommands,
  type WorktreeInfo,
} from "../../shared/global-settings";
import { normalizeGitRemote } from "../../shared/normalize-git-remote";
import { getGitRemoteOrigin } from "../../shared/repository-key";
import { resolveWorktreesRoot as resolveWorktreesRootUtil } from "../utils/path-utils";
import type {
  BranchInfo,
  ProjectWorktreeConfig,
  WorktreeArchiveOptions,
  WorktreeBranchListOptions,
  WorktreeCheckConflictOptions,
  WorktreeConflictResult,
  WorktreeConflictType,
  WorktreeCreateOptions,
  WorktreeCreateResult,
  WorktreeGetSetupCommandsOptions,
  WorktreeGitStatus,
  WorktreeListOptions,
  WorktreeRemoveOptions,
  WorktreeRunSetupCommandsOptions,
} from "../worktree";

type ExecFileResult = { stdout: string; stderr: string };
type ExecFileAsync = (
  file: string,
  args: readonly string[],
  options: { cwd?: string; timeout?: number; env?: NodeJS.ProcessEnv; shell?: boolean | string }
) => Promise<ExecFileResult>;

const defaultExecFileAsync = promisify(execFile) as unknown as ExecFileAsync;

const logger = getLogger(["frontend", "main", "worktree-service"]);

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isNonEmptyString(value: unknown): value is string {
  return typeof value === "string" && trim(value) !== "";
}

function isStringArray(value: unknown): value is string[] {
  return Array.isArray(value) && value.every(item => typeof item === "string");
}

function safeErrorMessage(error: unknown): string {
  if (error instanceof Error) return error.message;
  return String(error);
}

export interface WorktreeServiceGlobalSettings {
  getWorktrees(): WorktreeInfo[];
  updateWorktrees(worktrees: WorktreeInfo[]): WorktreeInfo[];
  getGitSettings?: () => GitSettings;
  getSetupWorktreeCommands?: () => SetupWorktreeCommands;
}

export interface WorktreeServiceOptions {
  globalSettingsService: WorktreeServiceGlobalSettings;
  ipcMain: IpcMain;
  mainWindow: BrowserWindow;
  execFileAsync?: ExecFileAsync;
  platform?: NodeJS.Platform;
}

type WorktreeListPorcelainEntry = {
  path: string;
  head?: string;
  branch?: string;
  detached?: boolean;
};

type WorktreeServiceResult<T> = { success: true; data: T } | { success: false; error: string };

export function slugify(input: string): string {
  return kebabCase(trim(input));
}

export function stableWorktreeIdFromPath(worktreePath: string): string {
  const abs = path.resolve(worktreePath);
  let canonical = abs;

  // Best-effort canonicalization for stable IDs.
  // Git can return worktree paths with symlink-resolved prefixes (e.g. macOS `/private/var`),
  // so we prefer hashing the realpath when the path exists.
  try {
    if (existsSync(abs)) {
      canonical = realpathSync(abs);
    }
  } catch {
    canonical = abs;
  }

  const hash = crypto.createHash("sha1").update(canonical).digest("hex").slice(0, 12);
  return `wt-${hash}`;
}

export function sanitizeBranchName(name: string): string {
  const raw = trim(name);
  if (raw === "") {
    throw new Error("Branch name cannot be empty");
  }

  // Normalize separators and strip obviously dangerous sequences.
  // Git forbids ASCII control chars, spaces, and several special characters in ref names.
  let next = raw.replace(/[\\\p{Cc}]/gu, "-").replace(/[[ ~^:?*]/g, "-");

  // Collapse whitespace to dashes.
  next = next.replace(/\s+/g, "-");

  // Collapse invalid refname sequences.
  next = next.replace(/@{/g, "-");
  next = next.replace(/\.{2,}/g, "."); // prevent consecutive dots
  next = next.replace(/\/{2,}/g, "/"); // prevent empty components

  // Disallow leading/trailing slashes and dots/spaces.
  next = trim(next);
  next = next.replace(/^\/+/, "").replace(/\/+$/, "");
  next = next.replace(/^\.+/, "").replace(/\.+$/, "");
  next = next.replace(/^-+/, "").replace(/-+$/, "");

  // Disallow ref prefixes and reserved names.
  const lower = next.toLowerCase();
  if (lower === "head") {
    throw new Error("Branch name cannot be HEAD");
  }
  if (lower === "@" || lower === "." || lower === "..") {
    throw new Error(`Branch name "${next}" is reserved`);
  }
  if (lower.startsWith("refs/")) {
    throw new Error('Branch name cannot start with "refs/"');
  }

  // Clean up path components: no leading dot, no trailing dot, no ".lock" suffix.
  const parts = next.split("/").filter(part => part !== "");
  const cleanedParts = parts.map(part => {
    let segment = part.replace(/^\.+/, "").replace(/\.+$/, "");
    segment = segment.replace(/\.lock$/i, "-lock");
    segment = segment.replace(/^-+/, "").replace(/-+$/, "");
    return segment;
  });

  next = cleanedParts.filter(part => part !== "").join("/");

  if (next === "") {
    throw new Error("Branch name cannot be empty after sanitization");
  }
  if (next.includes("..")) {
    throw new Error('Branch name cannot contain ".."');
  }
  if (next.includes("@{")) {
    throw new Error('Branch name cannot contain "@{"');
  }
  if (next.endsWith(".") || next.endsWith("/") || next.endsWith(".lock")) {
    throw new Error('Branch name cannot end with ".", "/", or ".lock"');
  }
  if (next.length > 255) {
    throw new Error("Branch name must be 255 characters or less");
  }
  if (next.startsWith("-")) {
    throw new Error("Branch name cannot start with '-'");
  }
  if (next.includes("//")) {
    throw new Error("Branch name cannot contain consecutive slashes");
  }

  return next;
}

export function generateBranchName(issueSlug: string, prefix: string): string {
  const rawPrefix = trim(prefix);
  const rawSlug = trim(issueSlug);

  const base = rawPrefix !== "" ? `${rawPrefix}/${rawSlug}` : rawSlug;
  return sanitizeBranchName(base);
}

export class WorktreeService {
  private readonly globalSettingsService: WorktreeServiceGlobalSettings;
  private readonly ipcMain: IpcMain;
  private readonly mainWindow: BrowserWindow;
  private readonly execFileAsync: ExecFileAsync;
  private readonly platform: NodeJS.Platform;

  private static readonly channels = [
    "worktree:create",
    "worktree:list",
    "worktree:listBranches",
    "worktree:get",
    "worktree:getAll",
    "worktree:status",
    "worktree:archive",
    "worktree:remove",
    "worktree:generateBranch",
    "worktree:getSetupCommands",
    "worktree:runSetupCommands",
    "worktree:checkConflict",
  ] as const;

  constructor(options: WorktreeServiceOptions) {
    this.globalSettingsService = options.globalSettingsService;
    this.ipcMain = options.ipcMain;
    this.mainWindow = options.mainWindow;
    this.execFileAsync = options.execFileAsync ?? defaultExecFileAsync;
    this.platform = options.platform ?? process.platform;

    this.registerHandlers();
    void this.syncWorktreesWithGit();
  }

  public dispose(): void {
    this.unregisterHandlers();
  }

  private unregisterHandlers(): void {
    // Electron's `IpcMain` type doesn't currently expose `removeHandler`, even though it exists
    // at runtime. We keep the optional call to avoid crashing on older Electron versions.
    const ipcMainWithRemoveHandler = this.ipcMain as unknown as {
      removeHandler?: (channel: string) => void;
    };

    for (const channel of WorktreeService.channels) {
      ipcMainWithRemoveHandler.removeHandler?.(channel);
    }
  }

  private registerHandlers(): void {
    this.unregisterHandlers();

    this.ipcMain.handle(
      "worktree:generateBranch",
      async (
        event: Electron.IpcMainInvokeEvent,
        params: unknown
      ): Promise<WorktreeServiceResult<{ branchName: string }>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected worktree:generateBranch from untrusted sender", {
            senderId: event.sender.id,
          });
          return { success: false, error: "Unauthorized sender" };
        }

        if (!isRecord(params) || !isNonEmptyString(params.issueSlug)) {
          return { success: false, error: "Invalid parameters" };
        }

        if (!("branchPrefix" in params) || typeof params.branchPrefix !== "string") {
          return { success: false, error: "branchPrefix is required (can be empty string)" };
        }

        const prefix = params.branchPrefix;
        try {
          const branchName = generateBranchName(params.issueSlug, prefix);
          return { success: true, data: { branchName } };
        } catch (error: unknown) {
          return { success: false, error: safeErrorMessage(error) };
        }
      }
    );

    this.ipcMain.handle(
      "worktree:getSetupCommands",
      async (
        event: Electron.IpcMainInvokeEvent,
        params: unknown
      ): Promise<WorktreeServiceResult<{ commands: string[] }>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected worktree:getSetupCommands from untrusted sender", {
            senderId: event.sender.id,
          });
          return { success: false, error: "Unauthorized sender" };
        }

        if (
          !isRecord(params) ||
          !isNonEmptyString(params.repositoryPath) ||
          !isNonEmptyString(params.repositoryId)
        ) {
          return { success: false, error: "Invalid parameters" };
        }

        try {
          const commands = await this.getSetupWorktreeCommands({
            repositoryPath: params.repositoryPath,
            repositoryId: params.repositoryId,
          });
          return { success: true, data: { commands } };
        } catch (error: unknown) {
          return { success: false, error: safeErrorMessage(error) };
        }
      }
    );

    this.ipcMain.handle(
      "worktree:create",
      async (
        event: Electron.IpcMainInvokeEvent,
        params: unknown
      ): Promise<WorktreeServiceResult<WorktreeCreateResult>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected worktree:create from untrusted sender", {
            senderId: event.sender.id,
          });
          return { success: false, error: "Unauthorized sender" };
        }

        if (!isRecord(params)) return { success: false, error: "Invalid parameters" };

        if (!("branchPrefix" in params) || typeof params.branchPrefix !== "string") {
          return { success: false, error: "branchPrefix is required (can be empty string)" };
        }

        try {
          if (
            !isNonEmptyString(params.repositoryPath) ||
            !isNonEmptyString(params.repositoryId) ||
            !isNonEmptyString(params.name) ||
            !isNonEmptyString(params.issueSlug)
          ) {
            return { success: false, error: "Invalid parameters" };
          }

          const options: WorktreeCreateOptions = {
            repositoryPath: params.repositoryPath,
            repositoryId: params.repositoryId,
            name: params.name,
            issueSlug: params.issueSlug,
            ...(typeof params.issueId === "string" ? { issueId: params.issueId } : {}),
            branchPrefix: params.branchPrefix,
            ...(typeof params.branchName === "string" ? { branchName: params.branchName } : {}),
            ...(typeof params.baseBranch === "string" ? { baseBranch: params.baseBranch } : {}),
            ...(typeof params.runSetupCommands === "boolean"
              ? { runSetupCommands: params.runSetupCommands }
              : {}),
            ...(isStringArray(params.setupCommands) ? { setupCommands: params.setupCommands } : {}),
          };

          const result = await this.createWorktree(options);
          return { success: true, data: result };
        } catch (error: unknown) {
          return { success: false, error: safeErrorMessage(error) };
        }
      }
    );

    this.ipcMain.handle(
      "worktree:list",
      async (
        event: Electron.IpcMainInvokeEvent,
        params: unknown
      ): Promise<WorktreeServiceResult<{ worktrees: WorktreeInfo[] }>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected worktree:list from untrusted sender", {
            senderId: event.sender.id,
          });
          return { success: false, error: "Unauthorized sender" };
        }

        if (
          !isRecord(params) ||
          !isNonEmptyString(params.repositoryPath) ||
          !isNonEmptyString(params.repositoryId)
        ) {
          return { success: false, error: "Invalid parameters" };
        }

        try {
          const worktrees = await this.listWorktrees({
            repositoryPath: params.repositoryPath,
            repositoryId: params.repositoryId,
          });
          return { success: true, data: { worktrees } };
        } catch (error: unknown) {
          return { success: false, error: safeErrorMessage(error) };
        }
      }
    );

    this.ipcMain.handle(
      "worktree:listBranches",
      async (
        event: Electron.IpcMainInvokeEvent,
        params: unknown
      ): Promise<WorktreeServiceResult<{ branches: BranchInfo[] }>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected worktree:listBranches from untrusted sender", {
            senderId: event.sender.id,
          });
          return { success: false, error: "Unauthorized sender" };
        }

        if (!isRecord(params) || !isNonEmptyString(params.repositoryPath)) {
          return { success: false, error: "Invalid parameters" };
        }

        try {
          const branches = await this.listBranches({
            repositoryPath: params.repositoryPath,
            includeRemote: params.includeRemote !== false,
          });
          return { success: true, data: { branches } };
        } catch (error: unknown) {
          return { success: false, error: safeErrorMessage(error) };
        }
      }
    );

    this.ipcMain.handle(
      "worktree:get",
      async (
        event: Electron.IpcMainInvokeEvent,
        worktreeId: unknown
      ): Promise<WorktreeServiceResult<{ worktree: WorktreeInfo | null }>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected worktree:get from untrusted sender", {
            senderId: event.sender.id,
          });
          return { success: false, error: "Unauthorized sender" };
        }

        if (!isNonEmptyString(worktreeId)) {
          return { success: false, error: "Invalid worktreeId" };
        }

        const worktree = this.getWorktreeById(worktreeId);
        return { success: true, data: { worktree } };
      }
    );

    this.ipcMain.handle(
      "worktree:getAll",
      async (
        event: Electron.IpcMainInvokeEvent
      ): Promise<WorktreeServiceResult<{ worktrees: WorktreeInfo[] }>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected worktree:getAll from untrusted sender", {
            senderId: event.sender.id,
          });
          return { success: false, error: "Unauthorized sender" };
        }

        return { success: true, data: { worktrees: this.globalSettingsService.getWorktrees() } };
      }
    );

    this.ipcMain.handle(
      "worktree:status",
      async (
        event: Electron.IpcMainInvokeEvent,
        worktreePath: unknown
      ): Promise<WorktreeServiceResult<{ status: WorktreeGitStatus }>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected worktree:status from untrusted sender", {
            senderId: event.sender.id,
          });
          return { success: false, error: "Unauthorized sender" };
        }

        if (!isNonEmptyString(worktreePath)) {
          return { success: false, error: "Invalid worktreePath" };
        }

        try {
          const status = await this.getWorktreeStatus(worktreePath);
          return { success: true, data: { status } };
        } catch (error: unknown) {
          return { success: false, error: safeErrorMessage(error) };
        }
      }
    );

    this.ipcMain.handle(
      "worktree:archive",
      async (
        event: Electron.IpcMainInvokeEvent,
        params: unknown
      ): Promise<WorktreeServiceResult<{ worktree: WorktreeInfo }>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected worktree:archive from untrusted sender", {
            senderId: event.sender.id,
          });
          return { success: false, error: "Unauthorized sender" };
        }

        if (
          !isRecord(params) ||
          !isNonEmptyString(params.repositoryPath) ||
          !isNonEmptyString(params.worktreeId)
        ) {
          return { success: false, error: "Invalid parameters" };
        }

        try {
          const worktree = await this.archiveWorktree({
            repositoryPath: params.repositoryPath,
            worktreeId: params.worktreeId,
          });
          return { success: true, data: { worktree } };
        } catch (error: unknown) {
          return { success: false, error: safeErrorMessage(error) };
        }
      }
    );

    this.ipcMain.handle(
      "worktree:remove",
      async (
        event: Electron.IpcMainInvokeEvent,
        params: unknown
      ): Promise<WorktreeServiceResult<{ worktreeId: string }>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected worktree:remove from untrusted sender", {
            senderId: event.sender.id,
          });
          return { success: false, error: "Unauthorized sender" };
        }

        if (
          !isRecord(params) ||
          !isNonEmptyString(params.repositoryPath) ||
          !isNonEmptyString(params.worktreeId)
        ) {
          return { success: false, error: "Invalid parameters" };
        }

        try {
          await this.removeWorktree({
            repositoryPath: params.repositoryPath,
            worktreeId: params.worktreeId,
            ...(typeof params.deleteRemoteBranch === "boolean"
              ? { deleteRemoteBranch: params.deleteRemoteBranch }
              : {}),
          });
          return { success: true, data: { worktreeId: params.worktreeId } };
        } catch (error: unknown) {
          return { success: false, error: safeErrorMessage(error) };
        }
      }
    );

    this.ipcMain.handle(
      "worktree:runSetupCommands",
      async (
        event: Electron.IpcMainInvokeEvent,
        params: unknown
      ): Promise<
        WorktreeServiceResult<{ status: WorktreeInfo["setupCommandsStatus"]; output: string }>
      > => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected worktree:runSetupCommands from untrusted sender", {
            senderId: event.sender.id,
          });
          return { success: false, error: "Unauthorized sender" };
        }

        if (!isRecord(params)) return { success: false, error: "Invalid parameters" };

        if (
          !isNonEmptyString(params.repositoryPath) ||
          !isNonEmptyString(params.worktreePath) ||
          !isNonEmptyString(params.branchName) ||
          !isStringArray(params.commands)
        ) {
          return { success: false, error: "Invalid parameters" };
        }

        try {
          const result = await this.runSetupCommands({
            repositoryPath: params.repositoryPath,
            worktreePath: params.worktreePath,
            branchName: params.branchName,
            commands: params.commands,
          });
          return { success: true, data: result };
        } catch (error: unknown) {
          return { success: false, error: safeErrorMessage(error) };
        }
      }
    );

    this.ipcMain.handle(
      "worktree:checkConflict",
      async (
        event: Electron.IpcMainInvokeEvent,
        params: unknown
      ): Promise<WorktreeServiceResult<WorktreeConflictResult>> => {
        if (event.sender.id !== this.mainWindow.webContents.id) {
          logger.warn("Rejected worktree:checkConflict from untrusted sender", {
            senderId: event.sender.id,
          });
          return { success: false, error: "Unauthorized sender" };
        }

        if (
          !isRecord(params) ||
          !isNonEmptyString(params.repositoryPath) ||
          !isNonEmptyString(params.repositoryId) ||
          !isNonEmptyString(params.branchName)
        ) {
          return { success: false, error: "Invalid parameters" };
        }

        try {
          const result = await this.checkConflict({
            repositoryPath: params.repositoryPath,
            repositoryId: params.repositoryId,
            branchName: params.branchName,
          });
          return { success: true, data: result };
        } catch (error: unknown) {
          return { success: false, error: safeErrorMessage(error) };
        }
      }
    );

    logger.info("Worktree IPC handlers registered", { channels: WorktreeService.channels });
  }

  private getGitSettings(): GitSettings {
    const fromService = this.globalSettingsService.getGitSettings?.();
    if (fromService) return sanitizeGitSettings(fromService);
    return cloneDeep(DEFAULT_GIT_SETTINGS);
  }

  private getSetupCommandsFromSettings(): SetupWorktreeCommands {
    const fromService = this.globalSettingsService.getSetupWorktreeCommands?.();
    if (fromService) return sanitizeSetupWorktreeCommands(fromService);
    return cloneDeep(DEFAULT_SETUP_WORKTREE_COMMANDS);
  }

  private getWorktreeById(worktreeId: string): WorktreeInfo | null {
    const stored = this.globalSettingsService.getWorktrees();
    return stored.find(worktree => worktree.id === worktreeId) ?? null;
  }

  private async execGit(
    repositoryPath: string,
    args: readonly string[],
    options?: { timeout?: number; logErrors?: boolean }
  ): Promise<ExecFileResult> {
    logger.debug("Executing git command", { repositoryPath, args });
    try {
      // Default timeout of 10 seconds to prevent hanging git commands
      const timeout = options?.timeout ?? 10_000;
      return await this.execFileAsync("git", args, {
        cwd: repositoryPath,
        timeout,
      });
    } catch (error: unknown) {
      const shouldLog = options?.logErrors !== false;
      if (shouldLog) {
        logger.error("Git command failed", {
          repositoryPath,
          args,
          error: safeErrorMessage(error),
        });
      }
      throw error;
    }
  }

  private async isGitRepository(repositoryPath: string): Promise<boolean> {
    try {
      const { stdout } = await this.execGit(
        repositoryPath,
        ["rev-parse", "--is-inside-work-tree"],
        { timeout: 5_000, logErrors: false }
      );
      return trim(stdout) === "true";
    } catch (error: unknown) {
      logger.warn("Repository path is not a git repository", {
        repositoryPath,
        error: safeErrorMessage(error),
      });
      return false;
    }
  }

  public async checkBranchExists(branchName: string, repositoryPath: string): Promise<boolean> {
    const candidate = sanitizeBranchName(branchName);

    // 1) Local heads check (fast, offline).
    try {
      await this.execGit(
        repositoryPath,
        ["show-ref", "--verify", "--quiet", `refs/heads/${candidate}`],
        { logErrors: false }
      );
      return true;
    } catch {
      // ignore: branch not found locally
    }

    // 2) Remote check (origin) – best-effort (may fail if no remote).
    try {
      const { stdout } = await this.execGit(
        repositoryPath,
        ["ls-remote", "--heads", "origin", candidate],
        { timeout: 10_000, logErrors: false }
      );
      return trim(stdout) !== "";
    } catch (error: unknown) {
      logger.warn("Remote branch existence check failed; assuming branch does not exist remotely", {
        repositoryPath,
        branchName: candidate,
        error: safeErrorMessage(error),
      });
      return false;
    }
  }

  /**
   * Checks if a branch name conflicts with an existing branch or worktree directory.
   * Returns conflict information including type and any existing worktree ID.
   */
  public async checkConflict(
    options: WorktreeCheckConflictOptions
  ): Promise<WorktreeConflictResult> {
    const { repositoryPath, repositoryId, branchName } = options;

    let sanitizedBranch: string;
    try {
      sanitizedBranch = sanitizeBranchName(branchName);
    } catch {
      // If the branch name is invalid, there's no conflict (it will fail at creation time)
      return {
        hasConflict: false,
        conflictType: null,
        existingWorktreeId: null,
        checkedBranchName: branchName,
      };
    }

    const worktreesRoot = this.resolveWorktreesRoot(repositoryPath);
    const worktreePath = path.join(worktreesRoot, sanitizedBranch);

    // Check for branch existence
    const branchExists = await this.checkBranchExists(sanitizedBranch, repositoryPath);

    // Check for directory existence
    const directoryExists = existsSync(worktreePath);

    // Find existing worktree in our metadata
    const stored = this.globalSettingsService.getWorktrees();
    const existingWorktree = stored.find(
      wt => wt.repositoryId === repositoryId && wt.branch === sanitizedBranch
    );

    // Determine conflict type
    let conflictType: WorktreeConflictType | null = null;
    if (branchExists && directoryExists) {
      conflictType = "both";
    } else if (branchExists) {
      conflictType = "branch";
    } else if (directoryExists) {
      conflictType = "directory";
    }

    return {
      hasConflict: conflictType !== null,
      conflictType,
      existingWorktreeId: existingWorktree?.id ?? null,
      checkedBranchName: sanitizedBranch,
    };
  }

  /**
   * Lists all branches (local and optionally remote) in a repository.
   * Returns branches sorted with local branches first, then remote branches.
   * The current branch is marked with isCurrent: true.
   */
  public async listBranches(options: WorktreeBranchListOptions): Promise<BranchInfo[]> {
    const { repositoryPath, includeRemote = true } = options;
    const branches: BranchInfo[] = [];

    // Get current branch name
    const currentBranch = await this.getCurrentRef(repositoryPath);

    // List local branches
    try {
      const { stdout } = await this.execGit(
        repositoryPath,
        ["branch", "--list", "--format=%(refname:short)"],
        {
          logErrors: false,
        }
      );

      for (const line of stdout.split("\n")) {
        const name = trim(line);
        if (name === "") continue;

        branches.push({
          name,
          isCurrent: name === currentBranch,
          isRemote: false,
        });
      }
    } catch (error: unknown) {
      logger.warn("Failed to list local branches", {
        repositoryPath,
        error: safeErrorMessage(error),
      });
    }

    // List remote branches if requested
    if (includeRemote) {
      try {
        const { stdout } = await this.execGit(
          repositoryPath,
          ["branch", "-r", "--list", "--format=%(refname:short)"],
          { logErrors: false }
        );

        for (const line of stdout.split("\n")) {
          const fullName = trim(line);
          if (fullName === "") continue;

          // Skip HEAD pointers (e.g., "origin/HEAD")
          if (fullName.endsWith("/HEAD")) continue;

          // Parse remote name and branch name (e.g., "origin/main" -> remote: "origin", name: "main")
          const slashIndex = fullName.indexOf("/");
          if (slashIndex === -1) continue;

          const remoteName = fullName.slice(0, slashIndex);
          const branchNameWithoutRemote = fullName.slice(slashIndex + 1);

          // Skip if we already have a local branch with the same name
          const hasLocal = branches.some(b => !b.isRemote && b.name === branchNameWithoutRemote);
          if (hasLocal) continue;

          branches.push({
            name: branchNameWithoutRemote,
            isCurrent: false,
            isRemote: true,
            remoteName,
          });
        }
      } catch (error: unknown) {
        logger.warn("Failed to list remote branches", {
          repositoryPath,
          error: safeErrorMessage(error),
        });
      }
    }

    // Sort: current branch first, then local branches, then remote branches
    branches.sort((a, b) => {
      if (a.isCurrent && !b.isCurrent) return -1;
      if (!a.isCurrent && b.isCurrent) return 1;
      if (!a.isRemote && b.isRemote) return -1;
      if (a.isRemote && !b.isRemote) return 1;
      return a.name.localeCompare(b.name);
    });

    return branches;
  }

  private resolveWorktreesRoot(repositoryPath: string): string {
    const baseDir = this.resolveWorktreeBaseDirectory();
    return resolveWorktreesRootUtil(baseDir, repositoryPath);
  }

  private resolveWorktreePath(repositoryPath: string, branchName: string): string {
    return path.join(this.resolveWorktreesRoot(repositoryPath), branchName);
  }

  private resolveWorktreeBaseDirectory(): string {
    const gitSettings = this.getGitSettings();
    const baseDirectory = trim(gitSettings.worktreeBaseDirectory);
    const homeDir = os.homedir();

    if (baseDirectory === "") {
      return path.join(homeDir, ".compozy", "worktrees");
    }

    const normalized = this.expandHomeDirectory(baseDirectory, homeDir);
    if (!path.isAbsolute(normalized)) {
      return path.resolve(homeDir, normalized);
    }

    return path.resolve(normalized);
  }

  private expandHomeDirectory(input: string, homeDir: string): string {
    if (input === "~") return homeDir;
    if (input.startsWith("~/") || input.startsWith("~\\")) {
      return path.join(homeDir, input.slice(2));
    }
    if (input.startsWith("$HOME/") || input.startsWith("$HOME\\")) {
      return path.join(homeDir, input.slice(6));
    }
    if (input === "$HOME") return homeDir;
    if (input.startsWith("${HOME}/") || input.startsWith("${HOME}\\")) {
      return path.join(homeDir, input.slice(7));
    }
    if (input === "${HOME}") return homeDir;
    return input;
  }

  /**
   * @deprecated This method is no longer used by createWorktree.
   * Conflict resolution should happen in the UI via checkConflict() and WorktreeConflictDialog.
   * This method is kept for backwards compatibility but will be removed in a future version.
   */
  public async resolveBranchNameCollision(
    baseName: string,
    repositoryPath: string
  ): Promise<string> {
    const base = sanitizeBranchName(baseName);
    const worktreesRoot = this.resolveWorktreesRoot(repositoryPath);

    for (let attempt = 0; attempt < 100; attempt++) {
      const candidate = attempt === 0 ? base : `${base}-${attempt}`;
      const exists = await this.checkBranchExists(candidate, repositoryPath);
      if (exists) continue;

      const candidatePath = path.join(worktreesRoot, candidate);
      if (existsSync(candidatePath)) continue;

      return candidate;
    }

    throw new Error("Could not find unique branch name after 100 attempts");
  }

  /**
   * Get the current branch name or commit hash from the repository.
   * Returns the branch name if on a branch, or the commit hash if in detached HEAD state.
   * Returns null if unable to determine the current ref.
   */
  private async getCurrentRef(repositoryPath: string): Promise<string | null> {
    try {
      // First, try to get the branch name
      const { stdout: branchOut } = await this.execGit(
        repositoryPath,
        ["rev-parse", "--abbrev-ref", "HEAD"],
        { logErrors: false }
      );
      const branchName = trim(branchOut);

      // If we got "HEAD", it means we're in detached HEAD state
      if (branchName === "HEAD") {
        // Get the commit hash instead
        const { stdout: commitOut } = await this.execGit(repositoryPath, ["rev-parse", "HEAD"], {
          logErrors: false,
        });
        return trim(commitOut) || null;
      }

      return branchName || null;
    } catch (error: unknown) {
      logger.warn("Failed to get current ref", {
        repositoryPath,
        error: safeErrorMessage(error),
      });
      return null;
    }
  }

  public async createWorktree(options: WorktreeCreateOptions): Promise<WorktreeCreateResult> {
    if (!isNonEmptyString(options.repositoryPath)) {
      throw new Error("repositoryPath is required");
    }
    if (!isNonEmptyString(options.repositoryId)) {
      throw new Error("repositoryId is required");
    }
    if (!isNonEmptyString(options.name)) {
      throw new Error("name is required");
    }
    if (!isNonEmptyString(options.issueSlug)) {
      throw new Error("issueSlug is required");
    }

    const repositoryPath = options.repositoryPath;
    const name = options.name;
    const issueId = options.issueId;
    const branchPrefix = options.branchPrefix ?? "";

    // Use the branch name directly - conflict resolution should happen in the UI
    const branchName = isNonEmptyString(options.branchName)
      ? sanitizeBranchName(options.branchName)
      : generateBranchName(options.issueSlug, branchPrefix);

    const worktreePath = this.resolveWorktreePath(repositoryPath, branchName);

    // Check for branch name conflicts - throw if branch already exists
    // User should resolve conflicts via UI before calling create
    const targetBranchExists = await this.checkBranchExists(branchName, repositoryPath);
    if (targetBranchExists) {
      throw new Error(
        `Branch "${branchName}" already exists. Please choose a different branch name or replace the existing worktree.`
      );
    }

    // Use provided baseBranch or fall back to current ref
    const baseBranch = isNonEmptyString(options.baseBranch)
      ? sanitizeBranchName(options.baseBranch)
      : null;

    // Validate that baseBranch exists before attempting to create worktree
    if (baseBranch) {
      const baseBranchExists = await this.checkBranchExists(baseBranch, repositoryPath);
      if (!baseBranchExists) {
        throw new Error(
          `Base branch "${baseBranch}" does not exist in repository "${path.basename(repositoryPath)}". ` +
            `Please select a different base branch or ensure the branch exists locally or on remote.`
        );
      }
    }

    logger.info("Creating worktree", {
      repositoryId: options.repositoryId,
      repositoryPath,
      worktreePath,
      branchName,
      baseBranch: baseBranch ?? "(current HEAD)",
      name,
    });

    if (existsSync(worktreePath)) {
      throw new Error(`Worktree directory already exists: ${worktreePath}`);
    }

    // Ensure parent directories exist (worktree branch names may include '/').
    await fs.mkdir(path.dirname(worktreePath), { recursive: true });

    // Capture the current branch/commit before creating worktree
    const previousRef = await this.getCurrentRef(repositoryPath);

    // Use baseBranch if provided, otherwise fall back to previousRef (current HEAD)
    const baseRef = baseBranch ?? previousRef;

    // Create worktree with explicit base reference
    // If baseRef is null, git will default to HEAD (existing behavior)
    const worktreeArgs = baseRef
      ? ["worktree", "add", "-b", branchName, worktreePath, baseRef]
      : ["worktree", "add", "-b", branchName, worktreePath];

    await this.execGit(repositoryPath, worktreeArgs);

    if (!existsSync(worktreePath)) {
      throw new Error(`Worktree directory was not created: ${worktreePath}`);
    }

    // Restore the original branch/commit state
    if (previousRef && previousRef !== branchName) {
      try {
        await this.execGit(repositoryPath, ["checkout", previousRef], { logErrors: false });
        logger.debug("Restored original branch/commit after worktree creation", {
          repositoryPath,
          previousRef,
        });
      } catch (error: unknown) {
        // Log warning but don't fail - worktree was created successfully
        logger.warn("Failed to restore original branch/commit after worktree creation", {
          repositoryPath,
          previousRef,
          error: safeErrorMessage(error),
        });
      }
    }

    const id = stableWorktreeIdFromPath(worktreePath);
    const createdAt = new Date().toISOString();

    let worktree: WorktreeInfo = {
      id,
      name,
      branch: branchName,
      path: worktreePath,
      repositoryId: options.repositoryId,
      ...(issueId ? { issueId } : {}),
      status: "active",
      createdAt,
    };

    this.upsertWorktreeMetadata(worktree);

    let setupCommandsOutput: string | undefined;
    let setupCommandsStatus: WorktreeInfo["setupCommandsStatus"] | undefined;

    if (
      options.runSetupCommands &&
      isStringArray(options.setupCommands) &&
      options.setupCommands.length > 0
    ) {
      try {
        const result = await this.runSetupCommands({
          repositoryPath,
          worktreePath,
          branchName,
          commands: options.setupCommands,
        });

        setupCommandsStatus = result.status;
        setupCommandsOutput = result.output;
      } catch (error: unknown) {
        setupCommandsStatus = "failed";
        setupCommandsOutput = safeErrorMessage(error);
      }

      worktree = {
        ...worktree,
        setupCommandsStatus,
      };

      this.upsertWorktreeMetadata(worktree);
    }

    return {
      worktree,
      branchName,
      worktreePath,
      ...(setupCommandsStatus ? { setupCommandsStatus } : {}),
      ...(setupCommandsOutput ? { setupCommandsOutput } : {}),
    };
  }

  private upsertWorktreeMetadata(next: WorktreeInfo): void {
    const existing = this.globalSettingsService.getWorktrees();
    const updated: WorktreeInfo[] = [];
    let replaced = false;

    for (const worktree of existing) {
      if (worktree.id === next.id) {
        updated.push(next);
        replaced = true;
      } else {
        updated.push(worktree);
      }
    }

    if (!replaced) {
      updated.push(next);
    }

    this.globalSettingsService.updateWorktrees(updated);
  }

  public async syncWorktreesWithGit(): Promise<void> {
    const stored = this.globalSettingsService.getWorktrees();
    if (stored.length === 0) return;

    const candidates = stored.filter(worktree => worktree.status !== "archived");
    if (candidates.length === 0) return;

    const grouped = new Map<string, { repositoryPath: string; repositoryId: string }>();
    let resolveFailures = 0;

    for (const worktree of candidates) {
      try {
        const repositoryPath = await this.resolveRepositoryPathForWorktree(worktree.path);
        const key = `${worktree.repositoryId}::${repositoryPath}`;
        if (!grouped.has(key)) {
          grouped.set(key, { repositoryPath, repositoryId: worktree.repositoryId });
        }
      } catch (error: unknown) {
        resolveFailures++;
        logger.warn(
          "Failed to resolve repository path for stored worktree; skipping sync for this entry",
          {
            worktreeId: worktree.id,
            worktreePath: worktree.path,
            error: safeErrorMessage(error),
          }
        );
      }
    }

    let syncSuccesses = 0;
    let syncFailures = 0;

    for (const { repositoryPath, repositoryId } of grouped.values()) {
      try {
        await this.syncWorktreesWithGitForRepository({ repositoryPath, repositoryId });
        syncSuccesses++;
      } catch (error: unknown) {
        syncFailures++;
        logger.warn("Failed to sync worktrees with git for repository", {
          repositoryPath,
          repositoryId,
          error: safeErrorMessage(error),
        });
      }
    }

    // Log a summary so users are aware if sync had issues
    const totalRepositories = grouped.size;
    if (syncFailures > 0 || resolveFailures > 0) {
      logger.warn("Worktree sync completed with errors; worktree state may be stale", {
        totalRepositories,
        syncSuccesses,
        syncFailures,
        resolveFailures,
        totalWorktrees: candidates.length,
      });
    } else if (syncSuccesses > 0) {
      logger.info("Worktree sync completed successfully", {
        totalRepositories,
        syncSuccesses,
        totalWorktrees: candidates.length,
      });
    }
  }

  private async syncWorktreesWithGitForRepository(
    options: WorktreeListOptions
  ): Promise<WorktreeInfo[]> {
    const gitWorktrees = await this.getGitWorktrees(options.repositoryPath);
    const storedAll = this.globalSettingsService.getWorktrees();

    const storedForRepo = storedAll.filter(wt => wt.repositoryId === options.repositoryId);
    const storedForRepoById = new Map(storedForRepo.map(wt => [wt.id, wt]));

    const gitPaths = new Set(gitWorktrees.map(entry => entry.path));

    const mergedActive: WorktreeInfo[] = [];
    for (const entry of gitWorktrees) {
      const id = stableWorktreeIdFromPath(entry.path);
      const existing = storedForRepoById.get(id);
      const branch = entry.branch ?? (entry.detached ? "detached" : "");
      const now = new Date().toISOString();

      if (existing) {
        mergedActive.push({
          ...existing,
          path: entry.path,
          ...(branch ? { branch } : {}),
          lastActivity: now,
        });
      } else {
        mergedActive.push({
          id,
          name: branch || path.basename(entry.path),
          branch: branch || path.basename(entry.path),
          path: entry.path,
          repositoryId: options.repositoryId,
          status: "active",
          createdAt: now,
          lastActivity: now,
        });
      }
    }

    const mergedArchived = storedForRepo.filter(wt => wt.status === "archived");

    const pruned = storedForRepo.filter(wt => wt.status !== "archived" && !gitPaths.has(wt.path));

    if (pruned.length > 0) {
      logger.info("Pruning orphaned worktree metadata entries", {
        repositoryId: options.repositoryId,
        count: pruned.length,
        worktreeIds: pruned.map(wt => wt.id),
      });
    }

    const nextForRepo = [...mergedActive, ...mergedArchived];

    const nextAll = [
      ...storedAll.filter(wt => wt.repositoryId !== options.repositoryId),
      ...nextForRepo,
    ];

    this.globalSettingsService.updateWorktrees(nextAll);

    return nextForRepo;
  }

  public async listWorktrees(options: WorktreeListOptions): Promise<WorktreeInfo[]> {
    const stored = this.globalSettingsService
      .getWorktrees()
      .filter(worktree => worktree.repositoryId === options.repositoryId);
    const isGitRepository = await this.isGitRepository(options.repositoryPath);
    if (!isGitRepository) {
      return stored;
    }
    return this.syncWorktreesWithGitForRepository(options);
  }

  private async getGitWorktrees(repositoryPath: string): Promise<WorktreeListPorcelainEntry[]> {
    const { stdout } = await this.execGit(repositoryPath, ["worktree", "list", "--porcelain"], {
      timeout: 10_000,
    });
    const parsed = this.parseWorktreeListPorcelain(stdout);

    // Exclude the root worktree (repositoryPath itself).
    const rootId = stableWorktreeIdFromPath(repositoryPath);
    return parsed.filter(entry => stableWorktreeIdFromPath(entry.path) !== rootId);
  }

  private parseWorktreeListPorcelain(output: string): WorktreeListPorcelainEntry[] {
    const lines = output.split("\n");
    const entries: WorktreeListPorcelainEntry[] = [];

    let current: Partial<WorktreeListPorcelainEntry> = {};
    const flush = () => {
      if (current.path) {
        entries.push(current as WorktreeListPorcelainEntry);
      }
      current = {};
    };

    for (const line of lines) {
      const trimmedLine = trim(line);
      if (trimmedLine === "") {
        flush();
        continue;
      }

      const [key, ...rest] = trimmedLine.split(" ");
      const value = rest.join(" ");

      if (key === "worktree") {
        current.path = value;
      } else if (key === "HEAD") {
        current.head = value;
      } else if (key === "branch") {
        current.branch = value.startsWith("refs/heads/")
          ? value.slice("refs/heads/".length)
          : value;
      } else if (key === "detached") {
        current.detached = true;
      }
    }

    flush();
    return entries;
  }

  public async getWorktreeStatus(worktreePath: string): Promise<WorktreeGitStatus> {
    const cwd = path.resolve(worktreePath);
    const { stdout } = await this.execGit(cwd, ["status", "--porcelain"]);

    const stagedFiles: string[] = [];
    const unstagedFiles: string[] = [];
    const untrackedFiles: string[] = [];

    for (const line of stdout.split("\n")) {
      if (trim(line) === "") continue;
      if (line.startsWith("??")) {
        untrackedFiles.push(trim(line.slice(2)));
        continue;
      }

      const x = line[0];
      const y = line[1];
      const file = trim(line.slice(2));

      if (x && x !== " ") stagedFiles.push(file);
      if (y && y !== " ") unstagedFiles.push(file);
    }

    return {
      hasChanges: stagedFiles.length > 0 || unstagedFiles.length > 0 || untrackedFiles.length > 0,
      stagedFiles,
      unstagedFiles,
      untrackedFiles,
    };
  }

  public async archiveWorktree(options: WorktreeArchiveOptions): Promise<WorktreeInfo> {
    const stored = this.globalSettingsService.getWorktrees();
    const worktree = stored.find(wt => wt.id === options.worktreeId);
    if (!worktree) {
      throw new Error(`Worktree not found: ${options.worktreeId}`);
    }

    logger.info("Archiving worktree", {
      repositoryPath: options.repositoryPath,
      worktreeId: worktree.id,
      worktreePath: worktree.path,
      branchName: worktree.branch,
    });

    await this.execGit(options.repositoryPath, ["worktree", "remove", "-f", worktree.path]);

    const settings = this.getGitSettings();
    if (settings.deleteBranchOnArchive) {
      await this.deleteLocalBranch(options.repositoryPath, worktree.branch);
    }

    const next: WorktreeInfo = {
      ...worktree,
      status: "archived",
      lastActivity: new Date().toISOString(),
    };

    this.upsertWorktreeMetadata(next);
    return next;
  }

  private async deleteLocalBranch(repositoryPath: string, branchName: string): Promise<void> {
    const branch = sanitizeBranchName(branchName);
    try {
      await this.execGit(repositoryPath, ["branch", "-D", branch], { logErrors: false });
    } catch (error: unknown) {
      logger.warn("Failed to delete local branch; ignoring", {
        repositoryPath,
        branchName: branch,
        error: safeErrorMessage(error),
      });
    }
  }

  private async deleteRemoteBranch(repositoryPath: string, branchName: string): Promise<void> {
    const branch = sanitizeBranchName(branchName);
    try {
      await this.execGit(repositoryPath, ["push", "origin", "--delete", branch], {
        timeout: 20_000,
        logErrors: false,
      });
    } catch (error: unknown) {
      const message = safeErrorMessage(error).toLowerCase();
      const isNotFound =
        message.includes("remote ref does not exist") || message.includes("not found");
      if (!isNotFound) {
        logger.warn("Failed to delete remote branch; ignoring", {
          repositoryPath,
          branchName: branch,
          error: safeErrorMessage(error),
        });
      }
    }
  }

  public async removeWorktree(options: WorktreeRemoveOptions): Promise<void> {
    const stored = this.globalSettingsService.getWorktrees();
    const worktree = stored.find(wt => wt.id === options.worktreeId);
    if (!worktree) {
      throw new Error(`Worktree not found: ${options.worktreeId}`);
    }

    logger.info("Removing worktree", {
      repositoryPath: options.repositoryPath,
      worktreeId: worktree.id,
      worktreePath: worktree.path,
      branchName: worktree.branch,
      deleteRemoteBranch: options.deleteRemoteBranch ?? false,
    });

    try {
      await this.execGit(options.repositoryPath, ["worktree", "remove", "-f", worktree.path]);
    } catch (error: unknown) {
      const message = safeErrorMessage(error).toLowerCase();
      const isMissingWorktree =
        message.includes("is not a working tree") ||
        message.includes("not a worktree") ||
        message.includes("not a work tree");

      if (worktree.status === "archived" || isMissingWorktree) {
        logger.warn("Worktree already removed from git; continuing cleanup", {
          repositoryPath: options.repositoryPath,
          worktreeId: worktree.id,
          worktreePath: worktree.path,
          error: safeErrorMessage(error),
        });
      } else {
        throw error;
      }
    }

    // Ensure directory removal on Windows (git worktree remove can fail to delete read-only files).
    await this.removeDirectoryWithRetries(worktree.path);

    await this.deleteLocalBranch(options.repositoryPath, worktree.branch);
    if (options.deleteRemoteBranch) {
      await this.deleteRemoteBranch(options.repositoryPath, worktree.branch);
    }

    const nextAll = stored.filter(wt => wt.id !== worktree.id);
    this.globalSettingsService.updateWorktrees(nextAll);
  }

  private async removeDirectoryWithRetries(targetPath: string): Promise<void> {
    const abs = path.resolve(targetPath);
    if (!existsSync(abs)) return;

    const attempts = 3;
    for (let attempt = 1; attempt <= attempts; attempt++) {
      try {
        if (this.platform === "win32") {
          await this.clearWindowsReadonlyAttributes(abs);
        }

        await fs.rm(abs, { recursive: true, force: true });
        return;
      } catch (error: unknown) {
        logger.warn("Failed to remove worktree directory", {
          path: abs,
          attempt,
          attempts,
          error: safeErrorMessage(error),
        });
        await this.sleep(200 * attempt);
      }
    }

    if (existsSync(abs)) {
      throw new Error(`Failed to remove worktree directory after ${attempts} attempts: ${abs}`);
    }
  }

  private async clearWindowsReadonlyAttributes(directoryPath: string): Promise<void> {
    try {
      await this.execFileAsync("attrib", ["-R", "/S", "/D", path.join(directoryPath, "*")], {
        shell: false,
      });
    } catch (error: unknown) {
      logger.warn("Failed to clear Windows read-only attributes; continuing", {
        directoryPath,
        error: safeErrorMessage(error),
      });
    }
  }

  private async sleep(ms: number): Promise<void> {
    await new Promise(resolve => setTimeout(resolve, ms));
  }

  public async getSetupWorktreeCommands(
    options: WorktreeGetSetupCommandsOptions
  ): Promise<string[]> {
    const settings = this.getSetupCommandsFromSettings();

    // Get git remote from repository path and normalize it
    const gitRemote = getGitRemoteOrigin(options.repositoryPath);
    if (gitRemote) {
      const normalizedGitRemote = normalizeGitRemote(gitRemote);
      if (Object.prototype.hasOwnProperty.call(settings.perRepository, normalizedGitRemote)) {
        return cloneDeep(settings.perRepository[normalizedGitRemote] ?? []);
      }
    }

    // Fall back to project-level config files
    const fromCompozy = await this.readProjectWorktreeConfig(
      path.join(options.repositoryPath, ".compozy", "worktrees.json")
    );
    if (fromCompozy) return fromCompozy;

    const fromCursor = await this.readProjectWorktreeConfig(
      path.join(options.repositoryPath, ".cursor", "worktrees.json")
    );
    if (fromCursor) return fromCursor;

    // No global fallback - return empty array
    return [];
  }

  private async readProjectWorktreeConfig(filePath: string): Promise<string[] | null> {
    try {
      const raw = await fs.readFile(filePath, "utf-8");
      const parsed: unknown = JSON.parse(raw) as unknown;
      if (!isRecord(parsed)) return null;

      const config = parsed as ProjectWorktreeConfig;
      if (!("setup-worktree" in config)) return null;
      if (!isStringArray(config["setup-worktree"])) return null;

      return cloneDeep(config["setup-worktree"]);
    } catch (error: unknown) {
      const nodeError = error as NodeJS.ErrnoException;
      if (nodeError?.code === "ENOENT") return null;

      logger.warn("Failed to read project worktree config; ignoring", {
        filePath,
        error: safeErrorMessage(error),
      });
      return null;
    }
  }

  /**
   * Runs setup commands for a worktree.
   *
   * **Security Model / Trust Boundary:**
   * Commands are sourced from project configuration files (`.compozy/worktrees.json` or
   * `.cursor/worktrees.json`) which are part of the repository. This means:
   * - Configuration files are trusted as part of the repository code
   * - A malicious repository could include harmful commands in its configuration
   * - Users should only run worktree setup on repositories they trust (same trust model as cloning)
   *
   * Variable values ($WORKTREE_PATH, etc.) are shell-escaped using single quotes to prevent
   * injection through variable values, but the command template itself is executed as-is.
   */
  public async runSetupCommands(options: WorktreeRunSetupCommandsOptions): Promise<{
    status: WorktreeInfo["setupCommandsStatus"];
    output: string;
  }> {
    if (options.commands.length === 0) {
      return { status: "skipped", output: "" };
    }

    const output: string[] = [];
    for (const command of options.commands) {
      const substituted = this.substituteSetupCommand(command, {
        rootWorktreePath: options.repositoryPath,
        worktreePath: options.worktreePath,
        branchName: options.branchName,
      });

      logger.info("Running setup command", {
        worktreePath: options.worktreePath,
        command: substituted,
      });

      try {
        const result = await this.execFileAsync(substituted, [], {
          cwd: options.worktreePath,
          shell: true,
          env: process.env,
        });
        if (trim(result.stdout) !== "") output.push(result.stdout);
        if (trim(result.stderr) !== "") output.push(result.stderr);
      } catch (error: unknown) {
        output.push(safeErrorMessage(error));
        return { status: "failed", output: output.join("\n") };
      }
    }

    return { status: "success", output: output.join("\n") };
  }

  /**
   * Substitutes variables in a setup command with properly shell-escaped values.
   *
   * Uses POSIX single-quote escaping which prevents all shell interpretation:
   * - Variable expansion ($VAR, ${VAR})
   * - Command substitution ($(cmd), `cmd`)
   * - Glob expansion
   * - Other shell metacharacters
   *
   * The only character that needs escaping inside single quotes is the single quote itself,
   * which is done by ending the quote, adding an escaped quote, and starting a new quote.
   */
  private substituteSetupCommand(
    command: string,
    vars: { rootWorktreePath: string; worktreePath: string; branchName: string }
  ): string {
    // Use single quotes for robust shell escaping. Single quotes prevent all shell expansion
    // including $(), ``, ${}, and special characters. The only character needing escape is
    // the single quote itself, done via: close quote, escaped quote, open quote ('\'')
    const shellEscape = (value: string): string => `'${value.replaceAll("'", "'\\''")}'`;

    return command
      .replaceAll("$ROOT_WORKTREE_PATH", shellEscape(vars.rootWorktreePath))
      .replaceAll("$WORKTREE_PATH", shellEscape(vars.worktreePath))
      .replaceAll("$BRANCH_NAME", shellEscape(vars.branchName))
      .replaceAll("${ROOT_WORKTREE_PATH}", shellEscape(vars.rootWorktreePath))
      .replaceAll("${WORKTREE_PATH}", shellEscape(vars.worktreePath))
      .replaceAll("${BRANCH_NAME}", shellEscape(vars.branchName));
  }

  private async resolveRepositoryPathForWorktree(worktreePath: string): Promise<string> {
    const gitMeta = path.join(worktreePath, ".git");
    try {
      const stat = await fs.stat(gitMeta);
      if (!stat.isFile()) {
        // Root worktrees have a .git directory, not a file.
        return path.resolve(worktreePath);
      }
    } catch {
      throw new Error(`Missing .git metadata for worktree: ${worktreePath}`);
    }

    const content = await fs.readFile(gitMeta, "utf-8");
    const match = content.match(/gitdir:\s*(.*)\s*$/i);
    if (!match || !match[1]) {
      throw new Error(`Invalid .git file in worktree: ${worktreePath}`);
    }

    const gitDirPath = path.resolve(worktreePath, trim(match[1]));
    const normalized = gitDirPath.replace(/\\/g, "/");
    const marker = "/.git/worktrees/";
    const index = normalized.indexOf(marker);
    if (index === -1) {
      throw new Error(`Unable to resolve repository root from gitdir: ${gitDirPath}`);
    }

    return path.normalize(normalized.slice(0, index));
  }
}
