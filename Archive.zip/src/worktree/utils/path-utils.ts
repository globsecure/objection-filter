import path from "node:path";
import { getRepositoryInfo } from "../../shared/repository-key";

/**
 * Resolves the worktrees root directory for a given repository.
 *
 * Combines the base worktrees directory with a repository-specific subdirectory
 * derived from the repository's unique key. This ensures worktrees for different
 * repositories are stored in isolated directories.
 *
 * @param baseDir - The base directory where all worktrees are stored
 * @param repositoryPath - Absolute path to the git repository root
 * @returns The absolute path to the worktrees root for this repository
 *
 * @example
 * ```ts
 * const root = resolveWorktreesRoot("~/.compozy/worktrees", "/path/to/repo");
 * // Returns: "~/.compozy/worktrees/owner-repo" (based on repository key)
 * ```
 */
export function resolveWorktreesRoot(baseDir: string, repositoryPath: string): string {
  const repositoryKey = getRepositoryInfo(repositoryPath).key;
  return path.join(baseDir, repositoryKey);
}
