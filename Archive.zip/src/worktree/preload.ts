/**
 * Preload bridge for Worktree IPC
 * Provides a typed, minimal surface for renderer → main worktree operations.
 */

import type { IpcRenderer as ElectronIpcRenderer } from "electron";
import type { WorktreeInfo } from "../shared/global-settings";
import type {
  BranchInfo,
  WorktreeArchiveOptions,
  WorktreeBranchListOptions,
  WorktreeCheckConflictOptions,
  WorktreeConflictResult,
  WorktreeCreateOptions,
  WorktreeCreateResult,
  WorktreeGetSetupCommandsOptions,
  WorktreeGitStatus,
  WorktreeListOptions,
  WorktreeRemoveOptions,
  WorktreeRunSetupCommandsOptions,
} from "./worktree";

export type IpcResult<T> = { success: true; data: T } | { success: false; error: string };

export type WorktreeCreateIpcOptions = Omit<WorktreeCreateOptions, "branchPrefix"> & {
  /**
   * Renderer must always decide the prefix (can be empty string) and pass it explicitly
   * so the main process never needs to fetch GitHub username or other UI-derived values.
   */
  branchPrefix: string;
  /**
   * Optional base branch to create the worktree from.
   * If not provided, the worktree will be created from the current HEAD.
   */
  baseBranch?: string;
};

export interface WorktreeAPI {
  generateBranch: (params: {
    issueSlug: string;
    branchPrefix: string;
  }) => Promise<IpcResult<{ branchName: string }>>;
  getSetupCommands: (
    params: WorktreeGetSetupCommandsOptions
  ) => Promise<IpcResult<{ commands: string[] }>>;
  listBranches: (
    options: WorktreeBranchListOptions
  ) => Promise<IpcResult<{ branches: BranchInfo[] }>>;
  checkConflict: (
    options: WorktreeCheckConflictOptions
  ) => Promise<IpcResult<WorktreeConflictResult>>;
  create: (options: WorktreeCreateIpcOptions) => Promise<IpcResult<WorktreeCreateResult>>;
  list: (options: WorktreeListOptions) => Promise<IpcResult<{ worktrees: WorktreeInfo[] }>>;
  get: (worktreeId: string) => Promise<IpcResult<{ worktree: WorktreeInfo | null }>>;
  getAll: () => Promise<IpcResult<{ worktrees: WorktreeInfo[] }>>;
  status: (worktreePath: string) => Promise<IpcResult<{ status: WorktreeGitStatus }>>;
  archive: (options: WorktreeArchiveOptions) => Promise<IpcResult<{ worktree: WorktreeInfo }>>;
  remove: (options: WorktreeRemoveOptions) => Promise<IpcResult<{ worktreeId: string }>>;
  runSetupCommands: (
    options: WorktreeRunSetupCommandsOptions
  ) => Promise<IpcResult<{ status: WorktreeInfo["setupCommandsStatus"]; output: string }>>;
}

/**
 * Minimal IpcRenderer interface for the preload bridge.
 * Uses Electron's type via Pick for type safety while allowing testing with mocks.
 */
type IpcRenderer = Pick<ElectronIpcRenderer, "invoke">;

export function createWorktreeAPI(ipcRenderer: IpcRenderer): WorktreeAPI {
  return {
    generateBranch: params => {
      return ipcRenderer.invoke("worktree:generateBranch", params) as Promise<
        IpcResult<{ branchName: string }>
      >;
    },
    getSetupCommands: params => {
      return ipcRenderer.invoke("worktree:getSetupCommands", params) as Promise<
        IpcResult<{ commands: string[] }>
      >;
    },
    listBranches: options => {
      return ipcRenderer.invoke("worktree:listBranches", options) as Promise<
        IpcResult<{ branches: BranchInfo[] }>
      >;
    },
    checkConflict: options => {
      return ipcRenderer.invoke("worktree:checkConflict", options) as Promise<
        IpcResult<WorktreeConflictResult>
      >;
    },
    create: options => {
      return ipcRenderer.invoke("worktree:create", options) as Promise<
        IpcResult<WorktreeCreateResult>
      >;
    },
    list: options => {
      return ipcRenderer.invoke("worktree:list", options) as Promise<
        IpcResult<{ worktrees: WorktreeInfo[] }>
      >;
    },
    get: worktreeId => {
      return ipcRenderer.invoke("worktree:get", worktreeId) as Promise<
        IpcResult<{ worktree: WorktreeInfo | null }>
      >;
    },
    getAll: () => {
      return ipcRenderer.invoke("worktree:getAll") as Promise<
        IpcResult<{ worktrees: WorktreeInfo[] }>
      >;
    },
    status: worktreePath => {
      return ipcRenderer.invoke("worktree:status", worktreePath) as Promise<
        IpcResult<{ status: WorktreeGitStatus }>
      >;
    },
    archive: options => {
      return ipcRenderer.invoke("worktree:archive", options) as Promise<
        IpcResult<{ worktree: WorktreeInfo }>
      >;
    },
    remove: options => {
      return ipcRenderer.invoke("worktree:remove", options) as Promise<
        IpcResult<{ worktreeId: string }>
      >;
    },
    runSetupCommands: options => {
      return ipcRenderer.invoke("worktree:runSetupCommands", options) as Promise<
        IpcResult<{ status: WorktreeInfo["setupCommandsStatus"]; output: string }>
      >;
    },
  };
}
