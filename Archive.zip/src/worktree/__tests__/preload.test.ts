import { describe, expect, it, vi } from "vitest";
import { createWorktreeAPI } from "../preload";

describe("Worktree Preload Bridge", () => {
  it("should create API with all required methods", () => {
    const api = createWorktreeAPI({ invoke: vi.fn(() => Promise.resolve()) });

    expect(api).toHaveProperty("create");
    expect(api).toHaveProperty("list");
    expect(api).toHaveProperty("get");
    expect(api).toHaveProperty("getAll");
    expect(api).toHaveProperty("status");
    expect(api).toHaveProperty("archive");
    expect(api).toHaveProperty("remove");
    expect(api).toHaveProperty("generateBranch");
    expect(api).toHaveProperty("getSetupCommands");
    expect(api).toHaveProperty("runSetupCommands");
  });

  it("should invoke worktree:create with correct arguments", async () => {
    const mockInvoke = vi.fn(() => Promise.resolve({ success: true, data: {} }));
    const api = createWorktreeAPI({ invoke: mockInvoke });

    const options = {
      repositoryPath: "/repo",
      repositoryId: "repo-1",
      name: "Fix login bug",
      issueSlug: "fix-login-bug",
      branchPrefix: "",
    };

    await api.create(options);

    expect(mockInvoke).toHaveBeenCalledWith("worktree:create", options);
  });

  it("should invoke worktree:getAll with no args", async () => {
    const mockInvoke = vi.fn(() => Promise.resolve({ success: true, data: { worktrees: [] } }));
    const api = createWorktreeAPI({ invoke: mockInvoke });

    await api.getAll();

    expect(mockInvoke).toHaveBeenCalledWith("worktree:getAll");
  });

  it("should invoke worktree:get with correct arguments", async () => {
    const mockInvoke = vi.fn(() => Promise.resolve({ success: true, data: { worktree: null } }));
    const api = createWorktreeAPI({ invoke: mockInvoke });

    await api.get("wt-123");

    expect(mockInvoke).toHaveBeenCalledWith("worktree:get", "wt-123");
  });

  it("should invoke worktree:list with correct arguments", async () => {
    const mockInvoke = vi.fn(() => Promise.resolve({ success: true, data: { worktrees: [] } }));
    const api = createWorktreeAPI({ invoke: mockInvoke });

    const options = {
      repositoryPath: "/repo",
      repositoryId: "repo-1",
    };

    await api.list(options);

    expect(mockInvoke).toHaveBeenCalledWith("worktree:list", options);
  });

  it("should invoke worktree:status with correct arguments", async () => {
    const mockInvoke = vi.fn(() =>
      Promise.resolve({
        success: true,
        data: {
          status: { hasChanges: false, stagedFiles: [], unstagedFiles: [], untrackedFiles: [] },
        },
      })
    );
    const api = createWorktreeAPI({ invoke: mockInvoke });

    await api.status("/path/to/worktree");

    expect(mockInvoke).toHaveBeenCalledWith("worktree:status", "/path/to/worktree");
  });

  it("should invoke worktree:archive with correct arguments", async () => {
    const mockInvoke = vi.fn(() =>
      Promise.resolve({
        success: true,
        data: {
          worktree: {
            id: "wt-123",
            name: "feature",
            branch: "feature-branch",
            path: "/path",
            repositoryId: "repo-1",
            status: "archived",
            createdAt: "2024-01-01T00:00:00.000Z",
          },
        },
      })
    );
    const api = createWorktreeAPI({ invoke: mockInvoke });

    const options = {
      repositoryPath: "/repo",
      worktreeId: "wt-123",
    };

    await api.archive(options);

    expect(mockInvoke).toHaveBeenCalledWith("worktree:archive", options);
  });

  it("should invoke worktree:remove with correct arguments", async () => {
    const mockInvoke = vi.fn(() =>
      Promise.resolve({ success: true, data: { worktreeId: "wt-123" } })
    );
    const api = createWorktreeAPI({ invoke: mockInvoke });

    const options = {
      repositoryPath: "/repo",
      worktreeId: "wt-123",
    };

    await api.remove(options);

    expect(mockInvoke).toHaveBeenCalledWith("worktree:remove", options);
  });

  it("should invoke worktree:generateBranch with correct arguments", async () => {
    const mockInvoke = vi.fn(() =>
      Promise.resolve({ success: true, data: { branchName: "feature/fix-bug" } })
    );
    const api = createWorktreeAPI({ invoke: mockInvoke });

    const params = {
      issueSlug: "fix-bug",
      branchPrefix: "feature",
    };

    await api.generateBranch(params);

    expect(mockInvoke).toHaveBeenCalledWith("worktree:generateBranch", params);
  });

  it("should invoke worktree:getSetupCommands with correct arguments", async () => {
    const mockInvoke = vi.fn(() =>
      Promise.resolve({ success: true, data: { commands: ["npm install"] } })
    );
    const api = createWorktreeAPI({ invoke: mockInvoke });

    const params = {
      repositoryPath: "/repo",
      repositoryId: "repo-1",
    };

    await api.getSetupCommands(params);

    expect(mockInvoke).toHaveBeenCalledWith("worktree:getSetupCommands", params);
  });

  it("should invoke worktree:runSetupCommands with correct arguments", async () => {
    const mockInvoke = vi.fn(() =>
      Promise.resolve({ success: true, data: { status: "success", output: "Done" } })
    );
    const api = createWorktreeAPI({ invoke: mockInvoke });

    const options = {
      repositoryPath: "/repo",
      worktreePath: "/path/to/worktree",
      branchName: "feature-branch",
      commands: ["npm install", "npm run build"],
    };

    await api.runSetupCommands(options);

    expect(mockInvoke).toHaveBeenCalledWith("worktree:runSetupCommands", options);
  });

  describe("error handling", () => {
    it("should return error result for worktree:create failure", async () => {
      const mockInvoke = vi.fn(() =>
        Promise.resolve({ success: false, error: "Failed to create worktree" })
      );
      const api = createWorktreeAPI({ invoke: mockInvoke });

      const result = await api.create({
        repositoryPath: "/repo",
        repositoryId: "repo-1",
        name: "Feature",
        issueSlug: "feature",
        branchPrefix: "",
      });

      expect(result).toEqual({ success: false, error: "Failed to create worktree" });
    });

    it("should return error result for worktree:list failure", async () => {
      const mockInvoke = vi.fn(() =>
        Promise.resolve({ success: false, error: "Failed to list worktrees" })
      );
      const api = createWorktreeAPI({ invoke: mockInvoke });

      const result = await api.list({
        repositoryPath: "/repo",
        repositoryId: "repo-1",
      });

      expect(result).toEqual({ success: false, error: "Failed to list worktrees" });
    });

    it("should return error result for worktree:get failure", async () => {
      const mockInvoke = vi.fn(() =>
        Promise.resolve({ success: false, error: "Worktree not found" })
      );
      const api = createWorktreeAPI({ invoke: mockInvoke });

      const result = await api.get("wt-invalid");

      expect(result).toEqual({ success: false, error: "Worktree not found" });
    });

    it("should return error result for worktree:getAll failure", async () => {
      const mockInvoke = vi.fn(() =>
        Promise.resolve({ success: false, error: "Failed to get worktrees" })
      );
      const api = createWorktreeAPI({ invoke: mockInvoke });

      const result = await api.getAll();

      expect(result).toEqual({ success: false, error: "Failed to get worktrees" });
    });

    it("should return error result for worktree:status failure", async () => {
      const mockInvoke = vi.fn(() =>
        Promise.resolve({ success: false, error: "Failed to get status" })
      );
      const api = createWorktreeAPI({ invoke: mockInvoke });

      const result = await api.status("/invalid/path");

      expect(result).toEqual({ success: false, error: "Failed to get status" });
    });

    it("should return error result for worktree:archive failure", async () => {
      const mockInvoke = vi.fn(() =>
        Promise.resolve({ success: false, error: "Failed to archive worktree" })
      );
      const api = createWorktreeAPI({ invoke: mockInvoke });

      const result = await api.archive({
        repositoryPath: "/repo",
        worktreeId: "wt-invalid",
      });

      expect(result).toEqual({ success: false, error: "Failed to archive worktree" });
    });

    it("should return error result for worktree:remove failure", async () => {
      const mockInvoke = vi.fn(() =>
        Promise.resolve({ success: false, error: "Failed to remove worktree" })
      );
      const api = createWorktreeAPI({ invoke: mockInvoke });

      const result = await api.remove({
        repositoryPath: "/repo",
        worktreeId: "wt-invalid",
      });

      expect(result).toEqual({ success: false, error: "Failed to remove worktree" });
    });

    it("should return error result for worktree:generateBranch failure", async () => {
      const mockInvoke = vi.fn(() =>
        Promise.resolve({ success: false, error: "Invalid branch name" })
      );
      const api = createWorktreeAPI({ invoke: mockInvoke });

      const result = await api.generateBranch({
        issueSlug: "",
        branchPrefix: "",
      });

      expect(result).toEqual({ success: false, error: "Invalid branch name" });
    });

    it("should return error result for worktree:getSetupCommands failure", async () => {
      const mockInvoke = vi.fn(() =>
        Promise.resolve({ success: false, error: "Failed to get setup commands" })
      );
      const api = createWorktreeAPI({ invoke: mockInvoke });

      const result = await api.getSetupCommands({
        repositoryPath: "/repo",
        repositoryId: "repo-1",
      });

      expect(result).toEqual({ success: false, error: "Failed to get setup commands" });
    });

    it("should return error result for worktree:runSetupCommands failure", async () => {
      const mockInvoke = vi.fn(() =>
        Promise.resolve({ success: false, error: "Command execution failed" })
      );
      const api = createWorktreeAPI({ invoke: mockInvoke });

      const result = await api.runSetupCommands({
        repositoryPath: "/repo",
        worktreePath: "/path/to/worktree",
        branchName: "feature-branch",
        commands: ["npm install"],
      });

      expect(result).toEqual({ success: false, error: "Command execution failed" });
    });
  });
});
