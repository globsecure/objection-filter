import { eq } from "drizzle-orm";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import { pipe } from "effect/Function";
import * as Layer from "effect/Layer";
import * as Option from "effect/Option";
import {
  type DrizzleDb,
  SqliteDatabase,
  SqliteDatabaseLayer,
  SqliteError,
  getDefaultSqliteDbPath,
  openDatabase,
} from "./db";
import { sessions } from "./schema";

export interface SqliteSessionRepository {
  getSessionId: (taskId: string) => Effect.Effect<Option.Option<string>, SqliteError>;
  setSessionId: (taskId: string, claudeSessionId: string) => Effect.Effect<void, SqliteError>;
  deleteSession: (taskId: string) => Effect.Effect<void, SqliteError>;
}

export const SqliteSessionRepository = Context.GenericTag<SqliteSessionRepository>(
  "@compozy/looper/SqliteSessionRepository"
);

function makeGetSessionId(db: DrizzleDb) {
  return (taskId: string): Effect.Effect<Option.Option<string>, SqliteError> =>
    Effect.tryPromise({
      try: async () => {
        const [row] = await db
          .select({ claudeSessionId: sessions.claudeSessionId })
          .from(sessions)
          .where(eq(sessions.taskId, taskId))
          .limit(1);
        return row ? Option.some(row.claudeSessionId) : Option.none<string>();
      },
      catch: cause =>
        SqliteError.make({
          message: `Failed to get session id for task ${taskId}`,
          cause,
        }),
    });
}

function makeSetSessionId(db: DrizzleDb) {
  return (taskId: string, claudeSessionId: string): Effect.Effect<void, SqliteError> =>
    Effect.tryPromise({
      try: async () => {
        const now = Date.now();
        await db
          .insert(sessions)
          .values({
            taskId,
            claudeSessionId,
            createdAt: now,
            updatedAt: now,
          })
          .onConflictDoUpdate({
            target: sessions.taskId,
            set: {
              claudeSessionId,
              updatedAt: now,
            },
          });
      },
      catch: cause =>
        SqliteError.make({
          message: `Failed to set session id for task ${taskId}`,
          cause,
        }),
    }).pipe(Effect.asVoid);
}

function makeDeleteSession(db: DrizzleDb) {
  return (taskId: string): Effect.Effect<void, SqliteError> =>
    Effect.tryPromise({
      try: async () => {
        await db.delete(sessions).where(eq(sessions.taskId, taskId));
      },
      catch: cause =>
        SqliteError.make({
          message: `Failed to delete session for task ${taskId}`,
          cause,
        }),
    }).pipe(Effect.asVoid);
}

export function makeSqliteSessionRepository(db: DrizzleDb): SqliteSessionRepository {
  return {
    getSessionId: makeGetSessionId(db),
    setSessionId: makeSetSessionId(db),
    deleteSession: makeDeleteSession(db),
  };
}

export const SqliteSessionRepositoryLayer = (dbPath: string) =>
  pipe(
    Layer.scoped(
      SqliteSessionRepository,
      Effect.gen(function* () {
        const sqlite = yield* SqliteDatabase;
        return makeSqliteSessionRepository(sqlite.db);
      })
    ),
    Layer.provide(SqliteDatabaseLayer(dbPath))
  );

export type SqliteSessionRepositoryWithClose = SqliteSessionRepository & { close: () => void };

export async function createSqliteSessionRepository(options: {
  dbPath: string;
}): Promise<SqliteSessionRepositoryWithClose> {
  const { db, client } = await openDatabase(options.dbPath);
  const repository = makeSqliteSessionRepository(db);
  return {
    ...repository,
    close: () => {
      try {
        client.close();
      } catch {
        // Best effort - close should not throw in cleanup paths.
      }
    },
  };
}

export async function createSqliteSessionRepositoryForWorkingDirectory(
  workingDirectory: string
): Promise<SqliteSessionRepositoryWithClose> {
  return await createSqliteSessionRepository({ dbPath: getDefaultSqliteDbPath(workingDirectory) });
}
