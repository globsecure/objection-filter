import { index, integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const messages = sqliteTable(
  "messages",
  {
    id: text("id").primaryKey(),
    taskId: text("task_id").notNull(),
    seqNum: integer("seq_num").notNull(),
    role: text("role").notNull(),
    partsJson: text("parts_json").notNull(),
    createdAt: integer("created_at", { mode: "number" })
      .notNull()
      .$defaultFn(() => Date.now()),
  },
  table => [
    index("idx_messages_task_seq").on(table.taskId, table.seqNum),
    index("idx_messages_task_created").on(table.taskId, table.createdAt),
    uniqueIndex("idx_messages_task_id_unique").on(table.taskId, table.id),
  ]
);

export const taskSequences = sqliteTable("task_sequences", {
  taskId: text("task_id").primaryKey(),
  lastSeqNum: integer("last_seq_num").notNull().default(0),
});

export const sessions = sqliteTable("sessions", {
  taskId: text("task_id").primaryKey(),
  claudeSessionId: text("claude_session_id").notNull(),
  createdAt: integer("created_at", { mode: "number" })
    .notNull()
    .$defaultFn(() => Date.now()),
  updatedAt: integer("updated_at", { mode: "number" })
    .notNull()
    .$defaultFn(() => Date.now()),
});

export const taskTelemetry = sqliteTable(
  "task_telemetry",
  {
    taskId: text("task_id").primaryKey(),
    issueId: text("issue_id").notNull(),
    status: text("status").notNull(),
    startedAt: integer("started_at", { mode: "number" }).notNull(),
    completedAt: integer("completed_at", { mode: "number" }),
    updatedAt: integer("updated_at", { mode: "number" }).notNull(),
    phasesJson: text("phases_json").notNull(),
    totalsDurationMs: integer("totals_duration_ms").notNull(),
  },
  table => [
    index("idx_telemetry_status").on(table.status),
    index("idx_telemetry_issue").on(table.issueId),
    index("idx_telemetry_started").on(table.startedAt),
  ]
);

export const jobs = sqliteTable(
  "jobs",
  {
    jobId: text("job_id").primaryKey(),
    issueId: text("issue_id").notNull(),
    status: text("status").notNull(), // running|completed|failed|canceled|interrupted
    totalTasks: integer("total_tasks").notNull().default(0),
    completedTasks: integer("completed_tasks").notNull().default(0),
    failedTasks: integer("failed_tasks").notNull().default(0),
    currentTaskId: text("current_task_id"),
    currentTaskAttempt: integer("current_task_attempt"),
    currentTaskMaxAttempts: integer("current_task_max_attempts"),
    failedTaskErrorsJson: text("failed_task_errors_json").notNull().default("[]"),
    orchestratorError: text("orchestrator_error"),
    taskIdsJson: text("task_ids_json").notNull().default("[]"),
    createdAt: integer("created_at", { mode: "number" })
      .notNull()
      .$defaultFn(() => Date.now()),
    updatedAt: integer("updated_at", { mode: "number" })
      .notNull()
      .$defaultFn(() => Date.now()),
    completedAt: integer("completed_at", { mode: "number" }),
  },
  table => [
    uniqueIndex("idx_jobs_issue_id").on(table.issueId),
    index("idx_jobs_status").on(table.status),
    index("idx_jobs_updated").on(table.updatedAt),
  ]
);

export type Message = typeof messages.$inferSelect;
export type NewMessage = typeof messages.$inferInsert;
export type TaskSequence = typeof taskSequences.$inferSelect;
export type Session = typeof sessions.$inferSelect;
export type NewSession = typeof sessions.$inferInsert;
export type TaskTelemetryRow = typeof taskTelemetry.$inferSelect;
export type NewTaskTelemetryRow = typeof taskTelemetry.$inferInsert;
export type JobRow = typeof jobs.$inferSelect;
export type NewJobRow = typeof jobs.$inferInsert;
