import { desc, eq } from "drizzle-orm";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import { pipe } from "effect/Function";
import * as Layer from "effect/Layer";
import * as Option from "effect/Option";
import * as Schema from "effect/Schema";
import {
  type DrizzleDb,
  SqliteDatabase,
  SqliteDatabaseLayer,
  SqliteError,
  getDefaultSqliteDbPath,
  openDatabase,
} from "./db";
import { jobs } from "./schema";

export type JobStatus = "running" | "completed" | "failed" | "canceled" | "interrupted";

export interface PersistedJobData {
  readonly jobId: string;
  readonly issueId: string;
  readonly status: JobStatus;
  readonly totalTasks: number;
  readonly completedTasks: number;
  readonly failedTasks: number;
  readonly currentTaskId?: string | undefined;
  readonly currentTaskAttempt?: number | undefined;
  readonly currentTaskMaxAttempts?: number | undefined;
  readonly failedTaskErrors: ReadonlyArray<string>;
  readonly orchestratorError?: string | undefined;
  readonly taskIds: ReadonlyArray<string>;
  readonly createdAt: number;
  readonly updatedAt: number;
  readonly completedAt?: number | undefined;
}

export interface JobProgress {
  readonly completedTasks?: number;
  readonly failedTasks?: number;
  readonly currentTaskId?: string | undefined;
  readonly currentTaskAttempt?: number | undefined;
  readonly currentTaskMaxAttempts?: number | undefined;
  readonly failedTaskErrors?: ReadonlyArray<string> | undefined;
}

export interface SqliteJobRepository {
  save: (job: PersistedJobData) => Effect.Effect<void, SqliteError>;
  load: (jobId: string) => Effect.Effect<Option.Option<PersistedJobData>, SqliteError>;
  loadByIssueId: (issueId: string) => Effect.Effect<Option.Option<PersistedJobData>, SqliteError>;
  loadRunningJobs: (limit?: number) => Effect.Effect<ReadonlyArray<PersistedJobData>, SqliteError>;
  loadAll: (limit?: number) => Effect.Effect<ReadonlyArray<PersistedJobData>, SqliteError>;
  delete: (jobId: string) => Effect.Effect<void, SqliteError>;
  updateStatus: (
    jobId: string,
    status: JobStatus,
    error?: string
  ) => Effect.Effect<void, SqliteError>;
  updateProgress: (jobId: string, progress: JobProgress) => Effect.Effect<void, SqliteError>;
}

export const SqliteJobRepository = Context.GenericTag<SqliteJobRepository>(
  "@compozy/looper/SqliteJobRepository"
);

const JobStatusSchema = Schema.Literal("running", "completed", "failed", "canceled", "interrupted");
const PersistedJobDataSchema = Schema.Struct({
  jobId: Schema.String,
  issueId: Schema.String,
  status: JobStatusSchema,
  totalTasks: Schema.Number,
  completedTasks: Schema.Number,
  failedTasks: Schema.Number,
  currentTaskId: Schema.optional(Schema.String),
  currentTaskAttempt: Schema.optional(Schema.Number),
  currentTaskMaxAttempts: Schema.optional(Schema.Number),
  failedTaskErrors: Schema.Array(Schema.String),
  orchestratorError: Schema.optional(Schema.String),
  taskIds: Schema.Array(Schema.String),
  createdAt: Schema.Number,
  updatedAt: Schema.Number,
  completedAt: Schema.optional(Schema.Number),
});

const StringArraySchema = Schema.Array(Schema.String);

function parseStringArrayJson(
  json: string,
  options: { field: string; jobId: string }
): Effect.Effect<ReadonlyArray<string>, SqliteError> {
  return Effect.try({
    try: () => JSON.parse(json) as unknown,
    catch: cause =>
      SqliteError.make({
        message: `Failed to parse ${options.field} JSON for job ${options.jobId}`,
        cause,
      }),
  }).pipe(
    Effect.flatMap(parsed =>
      Schema.decodeUnknown(StringArraySchema, { onExcessProperty: "error" })(parsed).pipe(
        Effect.mapError(cause =>
          SqliteError.make({
            message: `Failed to validate ${options.field} JSON for job ${options.jobId}`,
            cause,
          })
        )
      )
    )
  );
}

function parseJobStatus(status: string, jobId: string): Effect.Effect<JobStatus, SqliteError> {
  return Schema.decodeUnknown(JobStatusSchema, { onExcessProperty: "error" })(status).pipe(
    Effect.mapError(cause =>
      SqliteError.make({
        message: `Invalid job status for job ${jobId}`,
        cause,
      })
    )
  );
}

function buildOptionalParts(row: {
  currentTaskId: string | null;
  currentTaskAttempt: number | null;
  currentTaskMaxAttempts: number | null;
  orchestratorError: string | null;
  completedAt: number | null;
}): Partial<PersistedJobData> {
  const currentTaskIdPart: Partial<PersistedJobData> =
    row.currentTaskId === null ? {} : { currentTaskId: row.currentTaskId };
  const currentTaskAttemptPart: Partial<PersistedJobData> =
    typeof row.currentTaskAttempt === "number"
      ? { currentTaskAttempt: row.currentTaskAttempt }
      : {};
  const currentTaskMaxAttemptsPart: Partial<PersistedJobData> =
    typeof row.currentTaskMaxAttempts === "number"
      ? { currentTaskMaxAttempts: row.currentTaskMaxAttempts }
      : {};
  const orchestratorErrorPart: Partial<PersistedJobData> =
    row.orchestratorError === null ? {} : { orchestratorError: row.orchestratorError };
  const completedAtPart: Partial<PersistedJobData> =
    typeof row.completedAt === "number" ? { completedAt: row.completedAt } : {};

  return {
    ...currentTaskIdPart,
    ...currentTaskAttemptPart,
    ...currentTaskMaxAttemptsPart,
    ...orchestratorErrorPart,
    ...completedAtPart,
  };
}

function validateJobData(
  job: PersistedJobData,
  jobId: string
): Effect.Effect<PersistedJobData, SqliteError> {
  return Schema.decodeUnknown(PersistedJobDataSchema, { onExcessProperty: "error" })(job).pipe(
    Effect.mapError(cause =>
      SqliteError.make({
        message: `Job row has invalid schema for job ${jobId}`,
        cause,
      })
    )
  );
}

function rowToPersistedJobData(row: {
  jobId: string;
  issueId: string;
  status: string;
  totalTasks: number;
  completedTasks: number;
  failedTasks: number;
  currentTaskId: string | null;
  currentTaskAttempt: number | null;
  currentTaskMaxAttempts: number | null;
  failedTaskErrorsJson: string;
  orchestratorError: string | null;
  taskIdsJson: string;
  createdAt: number;
  updatedAt: number;
  completedAt: number | null;
}): Effect.Effect<PersistedJobData, SqliteError> {
  return Effect.gen(function* () {
    const status = yield* parseJobStatus(row.status, row.jobId);
    const failedTaskErrors = yield* parseStringArrayJson(row.failedTaskErrorsJson, {
      field: "failedTaskErrors",
      jobId: row.jobId,
    });
    const taskIds = yield* parseStringArrayJson(row.taskIdsJson, {
      field: "taskIds",
      jobId: row.jobId,
    });
    const optionalParts = buildOptionalParts({
      currentTaskId: row.currentTaskId,
      currentTaskAttempt: row.currentTaskAttempt,
      currentTaskMaxAttempts: row.currentTaskMaxAttempts,
      orchestratorError: row.orchestratorError,
      completedAt: row.completedAt,
    });

    const job: PersistedJobData = {
      jobId: row.jobId,
      issueId: row.issueId,
      status,
      totalTasks: row.totalTasks,
      completedTasks: row.completedTasks,
      failedTasks: row.failedTasks,
      ...optionalParts,
      failedTaskErrors,
      taskIds,
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
    };

    return yield* validateJobData(job, row.jobId);
  });
}

const selectJobRow = {
  jobId: jobs.jobId,
  issueId: jobs.issueId,
  status: jobs.status,
  totalTasks: jobs.totalTasks,
  completedTasks: jobs.completedTasks,
  failedTasks: jobs.failedTasks,
  currentTaskId: jobs.currentTaskId,
  currentTaskAttempt: jobs.currentTaskAttempt,
  currentTaskMaxAttempts: jobs.currentTaskMaxAttempts,
  failedTaskErrorsJson: jobs.failedTaskErrorsJson,
  orchestratorError: jobs.orchestratorError,
  taskIdsJson: jobs.taskIdsJson,
  createdAt: jobs.createdAt,
  updatedAt: jobs.updatedAt,
  completedAt: jobs.completedAt,
};

function buildJobValues(parsed: PersistedJobData) {
  return {
    jobId: parsed.jobId,
    issueId: parsed.issueId,
    status: parsed.status,
    totalTasks: parsed.totalTasks,
    completedTasks: parsed.completedTasks,
    failedTasks: parsed.failedTasks,
    currentTaskId: parsed.currentTaskId ?? null,
    currentTaskAttempt: parsed.currentTaskAttempt ?? null,
    currentTaskMaxAttempts: parsed.currentTaskMaxAttempts ?? null,
    failedTaskErrorsJson: JSON.stringify(parsed.failedTaskErrors),
    orchestratorError: parsed.orchestratorError ?? null,
    taskIdsJson: JSON.stringify(parsed.taskIds),
    createdAt: parsed.createdAt,
    updatedAt: parsed.updatedAt,
    completedAt: parsed.completedAt ?? null,
  };
}

function buildJobUpdateSet(parsed: PersistedJobData) {
  return {
    jobId: parsed.jobId,
    issueId: parsed.issueId,
    status: parsed.status,
    totalTasks: parsed.totalTasks,
    completedTasks: parsed.completedTasks,
    failedTasks: parsed.failedTasks,
    currentTaskId: parsed.currentTaskId ?? null,
    currentTaskAttempt: parsed.currentTaskAttempt ?? null,
    currentTaskMaxAttempts: parsed.currentTaskMaxAttempts ?? null,
    failedTaskErrorsJson: JSON.stringify(parsed.failedTaskErrors),
    orchestratorError: parsed.orchestratorError ?? null,
    taskIdsJson: JSON.stringify(parsed.taskIds),
    updatedAt: parsed.updatedAt,
    completedAt: parsed.completedAt ?? null,
  };
}

function makeSaveJob(db: DrizzleDb) {
  return (job: PersistedJobData): Effect.Effect<void, SqliteError> =>
    Schema.decodeUnknown(PersistedJobDataSchema, { onExcessProperty: "error" })(job).pipe(
      Effect.mapError(cause =>
        SqliteError.make({
          message: `Failed to validate job data for job ${job.jobId}`,
          cause,
        })
      ),
      Effect.flatMap(parsed =>
        Effect.tryPromise({
          try: async () => {
            await db
              .insert(jobs)
              .values(buildJobValues(parsed))
              .onConflictDoUpdate({
                target: jobs.issueId,
                set: buildJobUpdateSet(parsed),
              });
          },
          catch: cause =>
            SqliteError.make({
              message: `Failed to save job ${job.jobId}`,
              cause,
            }),
        }).pipe(Effect.asVoid)
      )
    );
}

function makeLoadJob(db: DrizzleDb) {
  return (jobId: string): Effect.Effect<Option.Option<PersistedJobData>, SqliteError> =>
    Effect.tryPromise({
      try: async () => {
        const [row] = await db
          .select(selectJobRow)
          .from(jobs)
          .where(eq(jobs.jobId, jobId))
          .limit(1);
        return row ?? null;
      },
      catch: cause =>
        SqliteError.make({
          message: `Failed to load job ${jobId}`,
          cause,
        }),
    }).pipe(
      Effect.flatMap(row => {
        if (!row) {
          return Effect.succeed(Option.none<PersistedJobData>());
        }
        return rowToPersistedJobData(row).pipe(Effect.map(Option.some));
      })
    );
}

function makeLoadByIssueId(db: DrizzleDb) {
  return (issueId: string): Effect.Effect<Option.Option<PersistedJobData>, SqliteError> =>
    Effect.tryPromise({
      try: async () => {
        const [row] = await db
          .select(selectJobRow)
          .from(jobs)
          .where(eq(jobs.issueId, issueId))
          .limit(1);
        return row ?? null;
      },
      catch: cause =>
        SqliteError.make({
          message: `Failed to load job for issue ${issueId}`,
          cause,
        }),
    }).pipe(
      Effect.flatMap(row => {
        if (!row) {
          return Effect.succeed(Option.none<PersistedJobData>());
        }
        return rowToPersistedJobData(row).pipe(Effect.map(Option.some));
      })
    );
}

// Default limit for loadRunningJobs - typically few running jobs at once
const DEFAULT_RUNNING_JOBS_LIMIT = 100;

function makeLoadRunningJobs(db: DrizzleDb) {
  return (limit?: number): Effect.Effect<ReadonlyArray<PersistedJobData>, SqliteError> =>
    Effect.tryPromise({
      try: async () =>
        await db
          .select(selectJobRow)
          .from(jobs)
          .where(eq(jobs.status, "running"))
          .orderBy(desc(jobs.updatedAt))
          .limit(limit ?? DEFAULT_RUNNING_JOBS_LIMIT),
      catch: cause =>
        SqliteError.make({
          message: "Failed to load running jobs",
          cause,
        }),
    }).pipe(
      Effect.flatMap(rows =>
        Effect.gen(function* () {
          const result: Array<PersistedJobData> = [];
          for (const row of rows) {
            result.push(yield* rowToPersistedJobData(row));
          }
          return result as ReadonlyArray<PersistedJobData>;
        })
      )
    );
}

// Default limit for loadAll - high limit for job history while preventing memory issues
const DEFAULT_ALL_JOBS_LIMIT = 1000;

function makeLoadAll(db: DrizzleDb) {
  return (limit?: number): Effect.Effect<ReadonlyArray<PersistedJobData>, SqliteError> =>
    Effect.tryPromise({
      try: async () =>
        await db
          .select(selectJobRow)
          .from(jobs)
          .orderBy(desc(jobs.updatedAt))
          .limit(limit ?? DEFAULT_ALL_JOBS_LIMIT),
      catch: cause =>
        SqliteError.make({
          message: "Failed to load all jobs",
          cause,
        }),
    }).pipe(
      Effect.flatMap(rows =>
        Effect.gen(function* () {
          const result: Array<PersistedJobData> = [];
          for (const row of rows) {
            result.push(yield* rowToPersistedJobData(row));
          }
          return result as ReadonlyArray<PersistedJobData>;
        })
      )
    );
}

function makeDeleteJob(db: DrizzleDb) {
  return (jobId: string): Effect.Effect<void, SqliteError> =>
    Effect.tryPromise({
      try: async () => {
        await db.delete(jobs).where(eq(jobs.jobId, jobId));
      },
      catch: cause =>
        SqliteError.make({
          message: `Failed to delete job ${jobId}`,
          cause,
        }),
    }).pipe(Effect.asVoid);
}

function makeUpdateStatus(db: DrizzleDb) {
  return (jobId: string, status: JobStatus, error?: string): Effect.Effect<void, SqliteError> =>
    Schema.decodeUnknown(JobStatusSchema, { onExcessProperty: "error" })(status).pipe(
      Effect.mapError(cause =>
        SqliteError.make({
          message: `Invalid job status for updateStatus(${jobId})`,
          cause,
        })
      ),
      Effect.flatMap(parsedStatus =>
        Effect.tryPromise({
          try: async () => {
            const now = Date.now();
            const completedAt = parsedStatus === "running" ? null : now;
            await db
              .update(jobs)
              .set({
                status: parsedStatus,
                updatedAt: now,
                completedAt,
                ...(typeof error === "string" ? { orchestratorError: error } : {}),
              })
              .where(eq(jobs.jobId, jobId));
          },
          catch: cause =>
            SqliteError.make({
              message: `Failed to update status for job ${jobId}`,
              cause,
            }),
        }).pipe(Effect.asVoid)
      )
    );
}

function makeUpdateProgress(db: DrizzleDb) {
  return (jobId: string, progress: JobProgress): Effect.Effect<void, SqliteError> =>
    Effect.tryPromise({
      try: async () => {
        const now = Date.now();
        await db
          .update(jobs)
          .set({
            updatedAt: now,
            ...(typeof progress.completedTasks === "number"
              ? { completedTasks: progress.completedTasks }
              : {}),
            ...(typeof progress.failedTasks === "number"
              ? { failedTasks: progress.failedTasks }
              : {}),
            ...(typeof progress.currentTaskId === "string"
              ? { currentTaskId: progress.currentTaskId }
              : {}),
            ...(typeof progress.currentTaskAttempt === "number"
              ? { currentTaskAttempt: progress.currentTaskAttempt }
              : {}),
            ...(typeof progress.currentTaskMaxAttempts === "number"
              ? { currentTaskMaxAttempts: progress.currentTaskMaxAttempts }
              : {}),
            ...(Array.isArray(progress.failedTaskErrors)
              ? { failedTaskErrorsJson: JSON.stringify(progress.failedTaskErrors) }
              : {}),
          })
          .where(eq(jobs.jobId, jobId));
      },
      catch: cause =>
        SqliteError.make({
          message: `Failed to update progress for job ${jobId}`,
          cause,
        }),
    }).pipe(Effect.asVoid);
}

export function makeSqliteJobRepository(db: DrizzleDb): SqliteJobRepository {
  return {
    save: makeSaveJob(db),
    load: makeLoadJob(db),
    loadByIssueId: makeLoadByIssueId(db),
    loadRunningJobs: makeLoadRunningJobs(db),
    loadAll: makeLoadAll(db),
    delete: makeDeleteJob(db),
    updateStatus: makeUpdateStatus(db),
    updateProgress: makeUpdateProgress(db),
  };
}

export const SqliteJobRepositoryLayer = (dbPath: string) =>
  pipe(
    Layer.scoped(
      SqliteJobRepository,
      Effect.gen(function* () {
        const sqlite = yield* SqliteDatabase;
        return makeSqliteJobRepository(sqlite.db);
      })
    ),
    Layer.provide(SqliteDatabaseLayer(dbPath))
  );

export type SqliteJobRepositoryWithClose = SqliteJobRepository & { close: () => void };

export async function createSqliteJobRepository(options: {
  dbPath: string;
}): Promise<SqliteJobRepositoryWithClose> {
  const { db, client } = await openDatabase(options.dbPath);
  const repository = makeSqliteJobRepository(db);

  return {
    ...repository,
    close: () => {
      try {
        client.close();
      } catch {
        // Best effort - close should not throw in cleanup paths.
      }
    },
  };
}

export async function createSqliteJobRepositoryForWorkingDirectory(
  workingDirectory: string
): Promise<SqliteJobRepositoryWithClose> {
  return await createSqliteJobRepository({ dbPath: getDefaultSqliteDbPath(workingDirectory) });
}
