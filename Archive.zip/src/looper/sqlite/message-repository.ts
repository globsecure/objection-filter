import type { UIMessage } from "ai";
import { and, asc, desc, eq, gt, lt, sql } from "drizzle-orm";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import { pipe } from "effect/Function";
import * as Layer from "effect/Layer";
import { chunk, compact } from "es-toolkit/array";
import { trim } from "es-toolkit/string";
import {
  type DrizzleDb,
  SqliteDatabase,
  SqliteDatabaseLayer,
  SqliteError,
  getDefaultSqliteDbPath,
  openDatabase,
} from "./db";
import { messages, taskSequences } from "./schema";

export interface PaginatedMessages {
  readonly messages: ReadonlyArray<UIMessage>;
  readonly nextCursor: number | null;
  readonly prevCursor: number | null;
  readonly hasMore: boolean;
}

export interface SqliteMessageRepository {
  insertMessage: (taskId: string, message: UIMessage) => Effect.Effect<void, SqliteError>;
  insertMessages: (
    taskId: string,
    messages: ReadonlyArray<UIMessage>
  ) => Effect.Effect<void, SqliteError>;
  updateMessage: (
    taskId: string,
    messageId: string,
    message: UIMessage
  ) => Effect.Effect<void, SqliteError>;

  getMessages: (
    taskId: string,
    options?: {
      cursor?: number;
      limit?: number;
      direction?: "before" | "after";
    }
  ) => Effect.Effect<PaginatedMessages, SqliteError>;

  getMessageById: (
    taskId: string,
    messageId: string
  ) => Effect.Effect<UIMessage | null, SqliteError>;
  getMessageCount: (taskId: string) => Effect.Effect<number, SqliteError>;
  getLatestSeqNum: (taskId: string) => Effect.Effect<number, SqliteError>;

  deleteTaskMessages: (taskId: string) => Effect.Effect<void, SqliteError>;
  deleteMessage: (taskId: string, messageId: string) => Effect.Effect<void, SqliteError>;

  listTaskIds: () => Effect.Effect<ReadonlyArray<string>, SqliteError>;
}

export const SqliteMessageRepository = Context.GenericTag<SqliteMessageRepository>(
  "@compozy/looper/SqliteMessageRepository"
);

function rowToUIMessage(row: { id: string; role: string; partsJson: string }): UIMessage {
  const parts = JSON.parse(row.partsJson) as UIMessage["parts"];
  return {
    id: row.id,
    role: row.role as UIMessage["role"],
    parts,
  };
}

function normalizeParts(message: UIMessage): UIMessage["parts"] {
  const record = message as unknown as Record<string, unknown>;
  if (Array.isArray(record.parts)) {
    return record.parts as UIMessage["parts"];
  }

  const content = record.content;
  if (typeof content === "string" && trim(content) !== "") {
    return [{ type: "text", text: content }] as UIMessage["parts"];
  }

  return [] as UIMessage["parts"];
}

function makeInsertMessage(db: DrizzleDb) {
  return (taskId: string, message: UIMessage): Effect.Effect<void, SqliteError> =>
    Effect.tryPromise({
      try: async () => {
        await db.transaction(async tx => {
          await tx.insert(taskSequences).values({ taskId, lastSeqNum: 0 }).onConflictDoNothing();

          const [seq] = await tx
            .select({ lastSeqNum: taskSequences.lastSeqNum })
            .from(taskSequences)
            .where(eq(taskSequences.taskId, taskId));
          const nextSeq = Number(seq?.lastSeqNum ?? 0) + 1;

          await tx.insert(messages).values({
            id: message.id,
            taskId,
            seqNum: nextSeq,
            role: message.role,
            partsJson: JSON.stringify(normalizeParts(message)),
            createdAt: Date.now(),
          });

          await tx
            .update(taskSequences)
            .set({ lastSeqNum: nextSeq })
            .where(eq(taskSequences.taskId, taskId));
        });
      },
      catch: cause =>
        SqliteError.make({
          message: `Failed to insert message ${message.id} for task ${taskId}`,
          cause,
        }),
    }).pipe(Effect.asVoid);
}

function makeInsertMessages(db: DrizzleDb) {
  return (taskId: string, msgs: ReadonlyArray<UIMessage>): Effect.Effect<void, SqliteError> =>
    Effect.tryPromise({
      try: async () => {
        if (msgs.length === 0) return;
        await db.transaction(async tx => {
          await tx.insert(taskSequences).values({ taskId, lastSeqNum: 0 }).onConflictDoNothing();

          const [seq] = await tx
            .select({ lastSeqNum: taskSequences.lastSeqNum })
            .from(taskSequences)
            .where(eq(taskSequences.taskId, taskId));
          const current = Number(seq?.lastSeqNum ?? 0);

          const now = Date.now();
          const values = msgs.map((msg, index) => ({
            id: msg.id,
            taskId,
            seqNum: current + index + 1,
            role: msg.role,
            partsJson: JSON.stringify(normalizeParts(msg)),
            createdAt: now + index,
          }));

          for (const batch of chunk(values, 500)) {
            await tx.insert(messages).values(batch);
          }

          await tx
            .update(taskSequences)
            .set({ lastSeqNum: current + msgs.length })
            .where(eq(taskSequences.taskId, taskId));
        });
      },
      catch: cause =>
        SqliteError.make({
          message: `Failed to insert ${msgs.length} messages for task ${taskId}`,
          cause,
        }),
    }).pipe(Effect.asVoid);
}

function makeUpdateMessage(db: DrizzleDb) {
  return (
    taskId: string,
    messageId: string,
    message: UIMessage
  ): Effect.Effect<void, SqliteError> =>
    Effect.tryPromise({
      try: async () => {
        const [existing] = await db
          .select({ id: messages.id })
          .from(messages)
          .where(and(eq(messages.taskId, taskId), eq(messages.id, messageId)))
          .limit(1);
        if (!existing) {
          throw new Error(`Message ${messageId} not found for task ${taskId}`);
        }

        await db
          .update(messages)
          .set({
            role: message.role,
            partsJson: JSON.stringify(normalizeParts(message)),
          })
          .where(and(eq(messages.taskId, taskId), eq(messages.id, messageId)));
      },
      catch: cause =>
        SqliteError.make({
          message: `Failed to update message ${messageId} for task ${taskId}`,
          cause,
        }),
    }).pipe(Effect.asVoid);
}

const messageSelectFields = {
  id: messages.id,
  role: messages.role,
  partsJson: messages.partsJson,
  seqNum: messages.seqNum,
};

function queryMessagesAfter(
  db: DrizzleDb,
  taskId: string,
  cursor: number | null,
  limit: number
): Promise<Array<{ id: string; role: string; partsJson: string; seqNum: number }>> {
  return db
    .select(messageSelectFields)
    .from(messages)
    .where(
      cursor !== null
        ? and(eq(messages.taskId, taskId), gt(messages.seqNum, cursor))
        : eq(messages.taskId, taskId)
    )
    .orderBy(asc(messages.seqNum))
    .limit(limit);
}

function queryMessagesBefore(
  db: DrizzleDb,
  taskId: string,
  cursor: number | null,
  limit: number
): Promise<Array<{ id: string; role: string; partsJson: string; seqNum: number }>> {
  return db
    .select(messageSelectFields)
    .from(messages)
    .where(
      cursor !== null
        ? and(eq(messages.taskId, taskId), lt(messages.seqNum, cursor))
        : eq(messages.taskId, taskId)
    )
    .orderBy(desc(messages.seqNum))
    .limit(limit);
}

function buildPaginatedResult(
  rows: Array<{ id: string; role: string; partsJson: string; seqNum: number }>,
  limit: number,
  direction: "before" | "after"
): PaginatedMessages {
  const hasMore = rows.length > limit;
  const pageRows = hasMore ? rows.slice(0, limit) : rows;
  const ordered = direction === "after" ? pageRows : [...pageRows].reverse();
  const uiMessages = ordered.map(rowToUIMessage);
  const seqNums = ordered.map(r => r.seqNum);
  const oldestSeq = seqNums.length > 0 ? Math.min(...seqNums) : null;
  const newestSeq = seqNums.length > 0 ? Math.max(...seqNums) : null;

  if (direction === "after") {
    return {
      messages: uiMessages,
      nextCursor: oldestSeq,
      prevCursor: hasMore ? newestSeq : null,
      hasMore,
    };
  }

  return {
    messages: uiMessages,
    nextCursor: hasMore ? oldestSeq : null,
    prevCursor: newestSeq,
    hasMore,
  };
}

function makeGetMessages(db: DrizzleDb) {
  return (
    taskId: string,
    options: { cursor?: number; limit?: number; direction?: "before" | "after" } = {}
  ): Effect.Effect<PaginatedMessages, SqliteError> =>
    Effect.tryPromise({
      try: async () => {
        const limit = typeof options.limit === "number" && options.limit > 0 ? options.limit : 50;
        const direction = options.direction ?? "before";
        const cursor = typeof options.cursor === "number" ? options.cursor : null;
        const requestedLimit = limit + 1;

        const rows =
          direction === "after"
            ? await queryMessagesAfter(db, taskId, cursor, requestedLimit)
            : await queryMessagesBefore(db, taskId, cursor, requestedLimit);

        return buildPaginatedResult(rows, limit, direction);
      },
      catch: cause =>
        SqliteError.make({
          message: `Failed to get messages for task ${taskId}`,
          cause,
        }),
    });
}

function makeGetMessageById(db: DrizzleDb) {
  return (taskId: string, messageId: string): Effect.Effect<UIMessage | null, SqliteError> =>
    Effect.tryPromise({
      try: async () => {
        const [row] = await db
          .select({
            id: messages.id,
            role: messages.role,
            partsJson: messages.partsJson,
          })
          .from(messages)
          .where(and(eq(messages.taskId, taskId), eq(messages.id, messageId)))
          .limit(1);
        return row ? rowToUIMessage(row) : null;
      },
      catch: cause =>
        SqliteError.make({
          message: `Failed to get message ${messageId} for task ${taskId}`,
          cause,
        }),
    });
}

function makeGetMessageCount(db: DrizzleDb) {
  return (taskId: string): Effect.Effect<number, SqliteError> =>
    Effect.tryPromise({
      try: async () => {
        const [result] = await db
          .select({ count: sql<number>`COUNT(1)` })
          .from(messages)
          .where(eq(messages.taskId, taskId))
          .limit(1);
        return Number(result?.count ?? 0);
      },
      catch: cause =>
        SqliteError.make({
          message: `Failed to get message count for task ${taskId}`,
          cause,
        }),
    });
}

function makeGetLatestSeqNum(db: DrizzleDb) {
  return (taskId: string): Effect.Effect<number, SqliteError> =>
    Effect.tryPromise({
      try: async () => {
        const [result] = await db
          .select({ lastSeqNum: taskSequences.lastSeqNum })
          .from(taskSequences)
          .where(eq(taskSequences.taskId, taskId))
          .limit(1);
        return Number(result?.lastSeqNum ?? 0);
      },
      catch: cause =>
        SqliteError.make({
          message: `Failed to get latest seq num for task ${taskId}`,
          cause,
        }),
    });
}

function makeDeleteTaskMessages(db: DrizzleDb) {
  return (taskId: string): Effect.Effect<void, SqliteError> =>
    Effect.tryPromise({
      try: async () => {
        await db.transaction(async tx => {
          await tx.delete(messages).where(eq(messages.taskId, taskId));
          await tx.delete(taskSequences).where(eq(taskSequences.taskId, taskId));
        });
      },
      catch: cause =>
        SqliteError.make({
          message: `Failed to delete messages for task ${taskId}`,
          cause,
        }),
    }).pipe(Effect.asVoid);
}

function makeDeleteMessage(db: DrizzleDb) {
  return (taskId: string, messageId: string): Effect.Effect<void, SqliteError> =>
    Effect.tryPromise({
      try: async () => {
        const [existing] = await db
          .select({ id: messages.id })
          .from(messages)
          .where(and(eq(messages.taskId, taskId), eq(messages.id, messageId)))
          .limit(1);
        if (!existing) {
          throw new Error(`Message ${messageId} not found for task ${taskId}`);
        }

        await db
          .delete(messages)
          .where(and(eq(messages.taskId, taskId), eq(messages.id, messageId)));
      },
      catch: cause =>
        SqliteError.make({
          message: `Failed to delete message ${messageId} for task ${taskId}`,
          cause,
        }),
    }).pipe(Effect.asVoid);
}

function makeListTaskIds(db: DrizzleDb) {
  return (): Effect.Effect<ReadonlyArray<string>, SqliteError> =>
    Effect.tryPromise({
      try: async () => {
        const rows = await db
          .select({ taskId: sql<string>`DISTINCT ${messages.taskId}` })
          .from(messages)
          .orderBy(asc(messages.taskId));

        return compact(
          rows.map(row => {
            const cleaned = trim(row.taskId);
            return cleaned === "" ? null : cleaned;
          })
        );
      },
      catch: cause =>
        SqliteError.make({
          message: "Failed to list task ids from SQLite messages table",
          cause,
        }),
    });
}

export function makeSqliteMessageRepository(db: DrizzleDb): SqliteMessageRepository {
  return {
    insertMessage: makeInsertMessage(db),
    insertMessages: makeInsertMessages(db),
    updateMessage: makeUpdateMessage(db),
    getMessages: makeGetMessages(db),
    getMessageById: makeGetMessageById(db),
    getMessageCount: makeGetMessageCount(db),
    getLatestSeqNum: makeGetLatestSeqNum(db),
    deleteTaskMessages: makeDeleteTaskMessages(db),
    deleteMessage: makeDeleteMessage(db),
    listTaskIds: makeListTaskIds(db),
  };
}

export const SqliteMessageRepositoryLayer = (dbPath: string) =>
  pipe(
    Layer.scoped(
      SqliteMessageRepository,
      Effect.gen(function* () {
        const sqlite = yield* SqliteDatabase;
        return makeSqliteMessageRepository(sqlite.db);
      })
    ),
    Layer.provide(SqliteDatabaseLayer(dbPath))
  );

export type SqliteMessageRepositoryWithClose = SqliteMessageRepository & { close: () => void };

export async function createSqliteMessageRepository(options: {
  dbPath: string;
}): Promise<SqliteMessageRepositoryWithClose> {
  const { db, client } = await openDatabase(options.dbPath);
  const repository = makeSqliteMessageRepository(db);

  return {
    ...repository,
    close: () => {
      try {
        client.close();
      } catch {
        // Best effort - close should not throw in cleanup paths.
      }
    },
  };
}

export async function createSqliteMessageRepositoryForWorkingDirectory(
  workingDirectory: string
): Promise<SqliteMessageRepositoryWithClose> {
  return await createSqliteMessageRepository({ dbPath: getDefaultSqliteDbPath(workingDirectory) });
}
