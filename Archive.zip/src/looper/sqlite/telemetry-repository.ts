import { eq } from "drizzle-orm";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import { pipe } from "effect/Function";
import * as Layer from "effect/Layer";
import * as Option from "effect/Option";
import * as Schema from "effect/Schema";
import {
  type DrizzleDb,
  SqliteDatabase,
  SqliteDatabaseLayer,
  SqliteError,
  getDefaultSqliteDbPath,
  openDatabase,
} from "./db";
import { taskTelemetry } from "./schema";

export interface TelemetrySummary {
  readonly durationMs: number;
}

export type TaskTelemetryStatus = "running" | "completed" | "failed" | "canceled";

export interface TaskTelemetryData {
  readonly taskId: string;
  readonly issueId: string;
  readonly status: TaskTelemetryStatus;
  readonly startedAt: string;
  readonly completedAt?: string | undefined;
  readonly updatedAt: number;
  readonly phases: Partial<Record<string, TelemetrySummary>>;
  readonly totals: TelemetrySummary;
}

const TelemetrySummarySchema = Schema.Struct({
  durationMs: Schema.Number,
});

const TaskTelemetryStatusSchema = Schema.Literal("running", "completed", "failed", "canceled");

const TaskTelemetryDataSchema = Schema.Struct({
  taskId: Schema.String,
  issueId: Schema.String,
  status: TaskTelemetryStatusSchema,
  startedAt: Schema.String,
  completedAt: Schema.optional(Schema.String),
  updatedAt: Schema.Number,
  phases: Schema.Record({ key: Schema.String, value: TelemetrySummarySchema }),
  totals: TelemetrySummarySchema,
});

function parseIsoToMillis(iso: string, field: string): number {
  const millis = Date.parse(iso);
  if (!Number.isFinite(millis)) {
    throw new Error(`Invalid ISO timestamp for ${field}: ${iso}`);
  }
  return millis;
}

function millisToIso(millis: number, field: string): string {
  if (!Number.isFinite(millis)) {
    throw new Error(`Invalid timestamp millis for ${field}: ${millis}`);
  }
  return new Date(millis).toISOString();
}

export interface SqliteTelemetryRepository {
  save: (taskId: string, telemetry: TaskTelemetryData) => Effect.Effect<void, SqliteError>;
  load: (taskId: string) => Effect.Effect<Option.Option<TaskTelemetryData>, SqliteError>;
  delete: (taskId: string) => Effect.Effect<void, SqliteError>;
}

export const SqliteTelemetryRepository = Context.GenericTag<SqliteTelemetryRepository>(
  "@compozy/looper/SqliteTelemetryRepository"
);

function buildTelemetryValues(
  taskId: string,
  parsed: TaskTelemetryData,
  startedAtMs: number,
  completedAtMs: number | null,
  totalsDurationMs: number
) {
  return {
    taskId,
    issueId: parsed.issueId,
    status: parsed.status,
    startedAt: startedAtMs,
    completedAt: completedAtMs,
    updatedAt: parsed.updatedAt,
    phasesJson: JSON.stringify(parsed.phases),
    totalsDurationMs,
  };
}

function makeSaveTelemetry(db: DrizzleDb) {
  return (taskId: string, telemetry: TaskTelemetryData): Effect.Effect<void, SqliteError> =>
    Schema.decodeUnknown(TaskTelemetryDataSchema, { onExcessProperty: "error" })(telemetry).pipe(
      Effect.mapError(cause =>
        SqliteError.make({
          message: `Failed to validate task telemetry data for task ${taskId}`,
          cause,
        })
      ),
      Effect.flatMap(parsed =>
        Effect.tryPromise({
          try: async () => {
            if (parsed.taskId !== taskId) {
              throw new Error(
                `Task telemetry taskId mismatch: expected ${taskId}, got ${parsed.taskId}`
              );
            }
            const startedAtMs = parseIsoToMillis(parsed.startedAt, "startedAt");
            const completedAtMs =
              typeof parsed.completedAt === "string"
                ? parseIsoToMillis(parsed.completedAt, "completedAt")
                : null;
            const totalsDurationMs = parsed.totals.durationMs;
            if (!Number.isFinite(totalsDurationMs)) {
              throw new Error(`Invalid totals.durationMs: ${String(totalsDurationMs)}`);
            }
            const values = buildTelemetryValues(
              taskId,
              parsed,
              startedAtMs,
              completedAtMs,
              totalsDurationMs
            );
            await db.insert(taskTelemetry).values(values).onConflictDoUpdate({
              target: taskTelemetry.taskId,
              set: values,
            });
          },
          catch: cause =>
            SqliteError.make({
              message: `Failed to save task telemetry for task ${taskId}`,
              cause,
            }),
        }).pipe(Effect.asVoid)
      )
    );
}

function rowToTelemetryData(
  row: {
    taskId: string;
    issueId: string;
    status: string;
    startedAt: number;
    completedAt: number | null;
    updatedAt: number;
    phasesJson: string;
    totalsDurationMs: number;
  },
  taskId: string
): Effect.Effect<TaskTelemetryData, SqliteError> {
  return Effect.gen(function* () {
    const phasesUnknown = yield* Effect.try({
      try: () => JSON.parse(row.phasesJson) as unknown,
      catch: cause =>
        SqliteError.make({
          message: `Failed to parse telemetry phases JSON for task ${taskId}`,
          cause,
        }),
    });
    const startedAtIso = millisToIso(row.startedAt, "startedAt");
    const completedAtIso =
      typeof row.completedAt === "number" ? millisToIso(row.completedAt, "completedAt") : undefined;
    const telemetry: TaskTelemetryData = {
      taskId: row.taskId,
      issueId: row.issueId,
      status: row.status as TaskTelemetryStatus,
      startedAt: startedAtIso,
      ...(completedAtIso ? { completedAt: completedAtIso } : {}),
      updatedAt: row.updatedAt,
      phases: phasesUnknown as TaskTelemetryData["phases"],
      totals: { durationMs: row.totalsDurationMs },
    };
    return yield* Schema.decodeUnknown(TaskTelemetryDataSchema, {
      onExcessProperty: "error",
    })(telemetry).pipe(
      Effect.mapError(cause =>
        SqliteError.make({
          message: `Task telemetry row has invalid schema for task ${taskId}`,
          cause,
        })
      )
    );
  });
}

function makeLoadTelemetry(db: DrizzleDb) {
  return (taskId: string): Effect.Effect<Option.Option<TaskTelemetryData>, SqliteError> =>
    Effect.tryPromise({
      try: async () => {
        const [row] = await db
          .select({
            taskId: taskTelemetry.taskId,
            issueId: taskTelemetry.issueId,
            status: taskTelemetry.status,
            startedAt: taskTelemetry.startedAt,
            completedAt: taskTelemetry.completedAt,
            updatedAt: taskTelemetry.updatedAt,
            phasesJson: taskTelemetry.phasesJson,
            totalsDurationMs: taskTelemetry.totalsDurationMs,
          })
          .from(taskTelemetry)
          .where(eq(taskTelemetry.taskId, taskId))
          .limit(1);
        return row ?? null;
      },
      catch: cause =>
        SqliteError.make({
          message: `Failed to load task telemetry for task ${taskId}`,
          cause,
        }),
    }).pipe(
      Effect.flatMap(row => {
        if (!row) {
          return Effect.succeed(Option.none<TaskTelemetryData>());
        }
        return rowToTelemetryData(row, taskId).pipe(Effect.map(Option.some));
      })
    );
}

function makeDeleteTelemetry(db: DrizzleDb) {
  return (taskId: string): Effect.Effect<void, SqliteError> =>
    Effect.tryPromise({
      try: async () => {
        await db.delete(taskTelemetry).where(eq(taskTelemetry.taskId, taskId));
      },
      catch: cause =>
        SqliteError.make({
          message: `Failed to delete task telemetry for task ${taskId}`,
          cause,
        }),
    }).pipe(Effect.asVoid);
}

export function makeSqliteTelemetryRepository(db: DrizzleDb): SqliteTelemetryRepository {
  return {
    save: makeSaveTelemetry(db),
    load: makeLoadTelemetry(db),
    delete: makeDeleteTelemetry(db),
  };
}

export const SqliteTelemetryRepositoryLayer = (dbPath: string) =>
  pipe(
    Layer.scoped(
      SqliteTelemetryRepository,
      Effect.gen(function* () {
        const sqlite = yield* SqliteDatabase;
        return makeSqliteTelemetryRepository(sqlite.db);
      })
    ),
    Layer.provide(SqliteDatabaseLayer(dbPath))
  );

export type SqliteTelemetryRepositoryWithClose = SqliteTelemetryRepository & { close: () => void };

export async function createSqliteTelemetryRepository(options: {
  dbPath: string;
}): Promise<SqliteTelemetryRepositoryWithClose> {
  const { db, client } = await openDatabase(options.dbPath);
  const repository = makeSqliteTelemetryRepository(db);
  return {
    ...repository,
    close: () => {
      try {
        client.close();
      } catch {
        // Best effort - close should not throw in cleanup paths.
      }
    },
  };
}

export async function createSqliteTelemetryRepositoryForWorkingDirectory(
  workingDirectory: string
): Promise<SqliteTelemetryRepositoryWithClose> {
  return await createSqliteTelemetryRepository({
    dbPath: getDefaultSqliteDbPath(workingDirectory),
  });
}
