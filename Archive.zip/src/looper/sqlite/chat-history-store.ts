import type { ChatHistoryArtifact, ChatHistoryStore } from "@shared";
import { getLogger } from "@logtape/logtape";
import type { UIMessage } from "ai";
import * as Effect from "effect/Effect";
import { last } from "es-toolkit/array";
import { trim } from "es-toolkit/string";
import path from "node:path";
import { getDefaultSqliteDbPath, openDatabase } from "./db";
import {
  makeSqliteMessageRepository,
  type PaginatedMessages,
  type SqliteMessageRepository,
} from "./message-repository";

const logger = getLogger(["chat-history-store"]);

const CHAT_ID_MAX_LENGTH = 64;

function sanitizeChatId(chatId: string): string {
  const cleaned = trim(chatId);
  if (cleaned === "") {
    throw new Error("chatId cannot be empty");
  }

  return cleaned
    .replace(/[^a-z0-9_-]/gi, "_")
    .toLowerCase()
    .slice(0, CHAT_ID_MAX_LENGTH);
}

function normalizeMessageParts(message: UIMessage): UIMessage {
  const record = message as unknown as Record<string, unknown>;
  if (Array.isArray(record.parts)) {
    return message;
  }

  const content = record.content;
  if (typeof content === "string" && trim(content) !== "") {
    return {
      ...message,
      parts: [{ type: "text", text: content }],
    } as UIMessage;
  }

  return { ...message, parts: [] } as UIMessage;
}

async function loadAllMessages(
  repo: SqliteMessageRepository,
  chatId: string
): Promise<UIMessage[]> {
  const pageLimit = 500;
  let cursor: number | undefined = undefined;
  let all: UIMessage[] = [];

  while (true) {
    const effect = repo.getMessages(
      chatId,
      typeof cursor === "number"
        ? { cursor, limit: pageLimit, direction: "before" }
        : { limit: pageLimit, direction: "before" }
    );
    const page: PaginatedMessages = await Effect.runPromise(effect);

    if (page.messages.length === 0) {
      break;
    }

    if (all.length === 0) {
      all = [...page.messages] as UIMessage[];
    } else {
      all = [...(page.messages as UIMessage[]), ...all];
    }

    if (!page.hasMore || page.nextCursor == null) {
      break;
    }

    cursor = page.nextCursor;
  }

  return all;
}

/**
 * SqliteChatHistoryStore - SQLite-backed chat history persistence.
 *
 * Backward-compatibility notes:
 * - The old implementation stored one JSON file per chat under "chat-histories/".
 * - This implementation stores all chat histories in the per-repository SQLite database.
 * - The constructor accepts either the legacy cache directory path or a direct .db path.
 */
export class SqliteChatHistoryStore implements ChatHistoryStore {
  private readonly dbPath: string;
  private readonly persistedMessageCounts = new Map<string, number>();

  constructor(cachePathOrDbPath: string) {
    const cleaned = trim(cachePathOrDbPath);
    if (cleaned === "") {
      throw new Error("cachePath cannot be empty");
    }

    this.dbPath = cleaned.endsWith(".db")
      ? cleaned
      : path.join(path.dirname(cleaned), "compozy.db");
  }

  async loadMessages(chatId: string, _toolSchemas: unknown[] = []): Promise<UIMessage[]> {
    const sanitizedId = sanitizeChatId(chatId);
    const { db, client } = await openDatabase(this.dbPath);
    const repo = makeSqliteMessageRepository(db);

    try {
      const messages = await loadAllMessages(repo, sanitizedId);
      const normalized = messages.map(normalizeMessageParts);
      this.persistedMessageCounts.set(sanitizedId, normalized.length);
      return normalized;
    } finally {
      client.close();
    }
  }

  async saveMessages(
    chatId: string,
    messages: UIMessage[],
    _toolSchemas: unknown[] = []
  ): Promise<void> {
    const sanitizedId = sanitizeChatId(chatId);
    const normalized = messages.map(normalizeMessageParts);

    const { db, client } = await openDatabase(this.dbPath);
    const repo = makeSqliteMessageRepository(db);

    try {
      let persistedCount = this.persistedMessageCounts.get(sanitizedId);
      if (typeof persistedCount !== "number") {
        persistedCount = await Effect.runPromise(repo.getMessageCount(sanitizedId));
        this.persistedMessageCounts.set(sanitizedId, persistedCount);
      }

      // If the caller passes a truncated history, re-sync from the DB to avoid miscount drift.
      if (persistedCount > normalized.length) {
        persistedCount = await Effect.runPromise(repo.getMessageCount(sanitizedId));
        this.persistedMessageCounts.set(sanitizedId, persistedCount);
      }

      const newMessages = normalized.slice(persistedCount);
      if (newMessages.length > 0) {
        await Effect.runPromise(repo.insertMessages(sanitizedId, newMessages));
        persistedCount += newMessages.length;
        this.persistedMessageCounts.set(sanitizedId, persistedCount);
      }

      const lastMessage = last(normalized);
      if (lastMessage) {
        // Always update the last message: streaming updates re-use IDs and mutate parts incrementally.
        await Effect.runPromise(repo.updateMessage(sanitizedId, lastMessage.id, lastMessage));
      }
    } catch (error) {
      logger.error("Failed to save chat history for {chatId}", { chatId: sanitizedId, error });
      throw error;
    } finally {
      client.close();
    }
  }

  async updateMessage(
    chatId: string,
    messageId: string,
    updater: (message: UIMessage) => UIMessage
  ): Promise<void> {
    const sanitizedId = sanitizeChatId(chatId);
    const { db, client } = await openDatabase(this.dbPath);
    const repo = makeSqliteMessageRepository(db);

    try {
      const existing = await Effect.runPromise(repo.getMessageById(sanitizedId, messageId));
      if (!existing) {
        throw new Error(`Message ${messageId} not found in chat ${sanitizedId}`);
      }
      const updated = normalizeMessageParts(updater(existing));
      await Effect.runPromise(repo.updateMessage(sanitizedId, messageId, updated));
    } finally {
      client.close();
    }
  }

  async deleteChat(chatId: string): Promise<void> {
    const sanitizedId = sanitizeChatId(chatId);
    const { db, client } = await openDatabase(this.dbPath);
    const repo = makeSqliteMessageRepository(db);

    try {
      await Effect.runPromise(repo.deleteTaskMessages(sanitizedId));
      this.persistedMessageCounts.delete(sanitizedId);
    } finally {
      client.close();
    }
  }

  async listChats(): Promise<string[]> {
    const { db, client } = await openDatabase(this.dbPath);
    const repo = makeSqliteMessageRepository(db);
    try {
      const taskIds = await Effect.runPromise(repo.listTaskIds());
      return [...taskIds];
    } finally {
      client.close();
    }
  }

  /**
   * Add an artifact reference to the chat history.
   * Note: Not implemented for SQLite looper store as it's used only for task execution,
   * not for agent sessions that create artifacts.
   */
  async addArtifact(_chatId: string, _artifact: ChatHistoryArtifact): Promise<void> {
    // No-op for SQLite looper store - artifact tracking is handled by the JSON-based
    // ChatHistoryStore used for agent sessions
    logger.debug("addArtifact called on SqliteChatHistoryStore - skipping (not implemented)");
  }

  /**
   * Get all artifact references from a chat history.
   * Note: Not implemented for SQLite looper store.
   */
  async getArtifacts(_chatId: string): Promise<ChatHistoryArtifact[]> {
    // No-op for SQLite looper store - always return empty array
    return [];
  }
}

/**
 * Creates a SqliteChatHistoryStore instance using the default SQLite database path.
 *
 * @param mainRepositoryPath - Path to the main repository directory
 * @returns A SqliteChatHistoryStore instance
 */
export function createSqliteChatHistoryStoreDirect(
  mainRepositoryPath: string
): SqliteChatHistoryStore {
  return new SqliteChatHistoryStore(getDefaultSqliteDbPath(mainRepositoryPath));
}
