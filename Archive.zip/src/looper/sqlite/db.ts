import { getRepositoryDir } from "@shared/repository-key";
import { createClient, type Client } from "@libsql/client";
import { drizzle, type LibSQLDatabase } from "drizzle-orm/libsql";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Schema from "effect/Schema";
import fs from "node:fs";
import path from "node:path";
import * as schema from "./schema";

export class SqliteError extends Schema.TaggedError<SqliteError>()("SqliteError", {
  message: Schema.String,
  cause: Schema.optional(Schema.Defect),
}) {}

export type DrizzleDb = LibSQLDatabase<typeof schema>;

export interface SqliteDatabase {
  readonly db: DrizzleDb;
  readonly client: Client;
  readonly dbPath: string;
}

export const SqliteDatabase = Context.GenericTag<SqliteDatabase>("@compozy/looper/SqliteDatabase");

export function getDefaultSqliteDbPath(workingDirectory: string): string {
  const repoDir = getRepositoryDir(workingDirectory);
  return path.join(repoDir, "compozy.db");
}

function ensureParentDir(filePath: string): void {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) {
    try {
      fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    } catch (error) {
      const nodeError = error as NodeJS.ErrnoException;
      // EEXIST can happen in race conditions - another process created the directory
      // between existsSync check and mkdirSync call. This is safe to ignore.
      if (nodeError.code === "EEXIST") {
        // Directory was created by another process, verify it exists now
        if (!fs.existsSync(dir)) {
          throw new Error(
            `Directory creation race condition: ${dir} was created but doesn't exist`,
            {
              cause: error,
            }
          );
        }
        return; // Directory exists, success
      }
      // Re-throw other errors (permissions, disk space, etc.) with better message
      throw new Error(`Failed to create directory ${dir}: ${nodeError.message || String(error)}`, {
        cause: error,
      });
    }
  }
}

async function createMessagesTable(client: Client): Promise<void> {
  await client.executeMultiple(`
    CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      task_id TEXT NOT NULL,
      seq_num INTEGER NOT NULL,
      role TEXT NOT NULL,
      parts_json TEXT NOT NULL,
      created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
      UNIQUE(task_id, id)
    );
    CREATE INDEX IF NOT EXISTS idx_messages_task_seq ON messages(task_id, seq_num DESC);
    CREATE INDEX IF NOT EXISTS idx_messages_task_created ON messages(task_id, created_at DESC);
  `);
}

async function createOtherTables(client: Client): Promise<void> {
  await client.executeMultiple(`
    CREATE TABLE IF NOT EXISTS task_sequences (
      task_id TEXT PRIMARY KEY,
      last_seq_num INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS sessions (
      task_id TEXT PRIMARY KEY,
      claude_session_id TEXT NOT NULL,
      created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
      updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000)
    );
    CREATE TABLE IF NOT EXISTS task_telemetry (
      task_id TEXT PRIMARY KEY,
      issue_id TEXT NOT NULL,
      status TEXT NOT NULL,
      started_at INTEGER NOT NULL,
      completed_at INTEGER,
      updated_at INTEGER NOT NULL,
      phases_json TEXT NOT NULL,
      totals_duration_ms INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_telemetry_status ON task_telemetry(status);
    CREATE INDEX IF NOT EXISTS idx_telemetry_issue ON task_telemetry(issue_id);
    CREATE INDEX IF NOT EXISTS idx_telemetry_started ON task_telemetry(started_at);
  `);
}

async function createJobsTable(client: Client): Promise<void> {
  await client.executeMultiple(`
    CREATE TABLE IF NOT EXISTS jobs (
      job_id TEXT PRIMARY KEY,
      issue_id TEXT NOT NULL,
      status TEXT NOT NULL,
      total_tasks INTEGER NOT NULL DEFAULT 0,
      completed_tasks INTEGER NOT NULL DEFAULT 0,
      failed_tasks INTEGER NOT NULL DEFAULT 0,
      current_task_id TEXT,
      current_task_attempt INTEGER,
      current_task_max_attempts INTEGER,
      failed_task_errors_json TEXT NOT NULL DEFAULT '[]',
      orchestrator_error TEXT,
      task_ids_json TEXT NOT NULL DEFAULT '[]',
      created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
      updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
      completed_at INTEGER
    );
    CREATE UNIQUE INDEX IF NOT EXISTS idx_jobs_issue_id ON jobs(issue_id);
    CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
    CREATE INDEX IF NOT EXISTS idx_jobs_updated ON jobs(updated_at);
  `);
}

async function createDatabaseSchema(client: Client): Promise<void> {
  await createMessagesTable(client);
  await createOtherTables(client);
  await createJobsTable(client);
}

function toLibsqlFileUrl(dbPath: string): string {
  if (dbPath === ":memory:") {
    return ":memory:";
  }

  // libsql "file:" urls accept both relative (`file:local.db`) and absolute (`file:/abs/path.db`) paths.
  if (dbPath.startsWith("file:")) {
    return dbPath;
  }

  return `file:${dbPath}`;
}

async function initializeClient(client: Client): Promise<void> {
  await client.execute("PRAGMA journal_mode = WAL");
  await client.execute("PRAGMA foreign_keys = ON");
  await client.execute("PRAGMA busy_timeout = 5000");
  await createDatabaseSchema(client);
}

async function openInMemoryDatabase(): Promise<{ db: DrizzleDb; client: Client }> {
  const client = createClient({ url: ":memory:" });
  try {
    await initializeClient(client);
    const db = drizzle(client, { schema });
    return { db, client };
  } catch (error) {
    try {
      client.close();
    } catch {
      // ignore close failure - we're already failing database initialization
    }
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to open in-memory SQLite database: ${errorMessage}`, {
      cause: error,
    });
  }
}

function validateParentDirectory(dbPath: string): void {
  ensureParentDir(dbPath);

  const parentDir = path.dirname(dbPath);
  if (!fs.existsSync(parentDir)) {
    throw new Error(`Parent directory does not exist: ${parentDir}`);
  }

  try {
    fs.accessSync(parentDir, fs.constants.W_OK);
  } catch (error) {
    const nodeError = error as NodeJS.ErrnoException;
    throw new Error(`Parent directory is not writable: ${parentDir}`, {
      cause: nodeError,
    });
  }
}

async function openFileDatabase(dbPath: string): Promise<{ db: DrizzleDb; client: Client }> {
  validateParentDirectory(dbPath);

  const client = createClient({ url: toLibsqlFileUrl(dbPath) });
  try {
    await initializeClient(client);
    const db = drizzle(client, { schema });
    return { db, client };
  } catch (error) {
    try {
      client.close();
    } catch {
      // ignore close failure - we're already failing database initialization
    }

    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(
      `Failed to open SQLite database at ${dbPath} using @libsql/client: ${errorMessage}`,
      {
        cause: error,
      }
    );
  }
}

export async function openDatabase(dbPath: string): Promise<{ db: DrizzleDb; client: Client }> {
  if (dbPath === ":memory:") {
    return openInMemoryDatabase();
  }
  return openFileDatabase(dbPath);
}

export const SqliteDatabaseLayer = (dbPath: string) =>
  Layer.scoped(
    SqliteDatabase,
    Effect.acquireRelease(
      Effect.tryPromise({
        try: async () => {
          const { db, client } = await openDatabase(dbPath);
          return { db, client, dbPath };
        },
        catch: cause => {
          const causeMessage =
            cause instanceof Error
              ? cause.message
              : typeof cause === "string"
                ? cause
                : String(cause);

          return SqliteError.make({
            message: `Failed to open SQLite database at ${dbPath} using @libsql/client: ${causeMessage}`,
            cause,
          });
        },
      }),
      ({ client }) => Effect.sync(() => client.close())
    )
  );

export type {
  JobRow,
  Message,
  NewJobRow,
  NewMessage,
  NewSession,
  NewTaskTelemetryRow,
  Session,
  TaskSequence,
  TaskTelemetryRow,
} from "./schema";
export { schema };
