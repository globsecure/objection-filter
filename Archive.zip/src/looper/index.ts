/**
 * Looper SDK - Main Entry Point
 * Provider-agnostic SDK for iterating over tasks and executing them with local code assistants
 *
 * @packageDocumentation
 */

// =============================================================================
// Electron Integration (Primary Use Case)
// =============================================================================

/**
 * Electron integration for main process initialization
 */
export { LooperSDK, type LooperSDKOptions } from "./electron/main";

/**
 * Electron integration for renderer process (preload)
 */
export { createLooperAPI } from "./electron/preload";

/**
 * Electron IPC handlers and utilities
 */
export { IPCRegister, JobManager, SDKLifecycleManager } from "./electron/main";

// =============================================================================
// Types and Interfaces
// =============================================================================

/**
 * Electron IPC contract types
 */
export type {
  IssueContext,
  JobStatus,
  LooperAPI,
  LooperIPCContract,
  RunnerOptions,
} from "./electron/ipc-contract";

/**
 * IPC validation service
 */
export { IpcValidatorService } from "./electron/services/ipc-validator";

/**
 * Provider types and enums
 */
export {
  Provider,
  type Capabilities,
  type Executor,
  type ExecutorForId,
  type LogChunk,
  type MessageForId,
  type OptionsForId,
  type PromptComponents,
  type ProviderOptsBase,
  type ReasoningEffort,
  type RunInput,
  type RunResult,
} from "./providers/types";

/**
 * Executor factory for creating provider instances
 */
export { createExecutorFactory, type ExecutorFactory } from "./providers/index";

/**
 * Claude provider types and enums
 */
export { ClaudeModel, type ClaudeAgentOptions } from "./providers/claude";

/**
 * Provider errors
 */
export {
  BackendError,
  ExecutorError,
  ExecutorNotFoundError,
  ProcessError,
  TimeoutError,
  ValidationError,
  mapBackendError,
  mapExecutorError,
  mapProcessError,
  mapTimeoutError,
  mapValidationError,
} from "./providers/errors";

/**
 * Task source types and interfaces
 */
export type {
  BackendTask,
  BackendTaskStatus,
  TaskSource as TaskSourceInterface,
  TaskSummary,
} from "./core/tasks/source";

/**
 * Task source utilities
 */
export { buildErrorMessage, mapSdkStateToBackendStatus } from "./core/tasks/source";

/**
 * Effect layers for dependency injection
 */
export {
  AllLayers,
  AllLayersDebug,
  CommandExecutor,
  FileSystem,
  FileSystemLayer,
  IpcLayer,
  IpcService,
  IpcServiceMock,
  ProcessLayer,
  RetryLayerWithTime,
  SignalLayer,
  SignalService,
  SignalServiceLive,
  TimeLayer,
  TimeService,
  TimeServiceLive,
} from "./core/layers";
