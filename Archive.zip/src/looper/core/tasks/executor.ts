/**
 * Task Executor
 * Provides stateless task execution with retry and cancellation support
 * Thin service layer with per-execution state
 * Class-based implementation with dependency injection
 */

import type { RetryContext } from "@compozy/prompts/built-in";
import * as Cause from "effect/Cause";
import * as Clock from "effect/Clock";
import * as Context from "effect/Context";
import * as Duration from "effect/Duration";
import * as Effect from "effect/Effect";
import * as Option from "effect/Option";
import * as Ref from "effect/Ref";
import * as Schedule from "effect/Schedule";
import * as Scope from "effect/Scope";
import * as Stream from "effect/Stream";
import type { ExecutorFactory } from "../../providers/index";
import {
  ExitCode,
  Provider,
  type ExecutorForId,
  type OptionsForId,
  type PromptComponents,
  type RunInput,
  type RunResult,
} from "../../providers/types";
import { IpcService } from "../layers/ipc";
import type { RetryService } from "../layers/retry";
import type { TimeService } from "../layers/time";
import { appendRetryContext } from "../retry-helpers";
import { TaskTelemetryService, type TelemetryDelta } from "./telemetry-service";

const STREAM_IDLE_TIMEOUT = Duration.minutes(10);
const STREAM_IDLE_CHECK_INTERVAL = Duration.seconds(30);

const getWorkingDirectory = (opts: unknown): string | undefined => {
  if (opts && typeof opts === "object" && "workingDirectory" in opts) {
    const value = (opts as { workingDirectory?: unknown }).workingDirectory;
    return typeof value === "string" ? value : undefined;
  }
  return undefined;
};

/**
 * Execution result with attempt tracking and metadata
 */
export interface ExecutionResult {
  exitCode: number;
  attempt: number;
  error?: Error;
  startedAt: Date;
  completedAt: Date;
  /**
   * Aggregated telemetry for this execution (across retry attempts).
   * Always populated; values may be zero if provider does not report metering.
   */
  telemetry: {
    durationMs: number;
  };
}

/**
 * Runner options for task execution
 * Extends IPC contract RunnerOptions with task-specific fields
 */
export interface RunnerOptions<TId extends Provider = Provider> {
  taskId: string;
  issueId: string;
  executorId: TId;
  options: OptionsForId<TId>;
  promptComponents: PromptComponents;
  maxAttempts?: number;
  /** Force the executor to drop any persisted session before running */
  resetSession?: boolean;
  /**
   * Optional stream idle timeout override.
   *
   * Default: `STREAM_IDLE_TIMEOUT` (10 minutes).
   *
   * Note: This timer starts when the stream wrapper is created (before the first chunk arrives).
   * Callers should ensure the executor produces its first chunk within this timeout or the
   * execution will be treated as stalled and retried.
   */
  streamIdleTimeout?: Duration.Duration;
  /**
   * Optional stream idle polling interval override.
   *
   * Default: `STREAM_IDLE_CHECK_INTERVAL` (30 seconds).
   */
  streamIdleCheckInterval?: Duration.Duration;
  /** Optional callback to receive the message stream before consumption */
  onStream?: <TMessage = unknown, R = unknown>(
    stream: Stream.Stream<TMessage, Error, R>
  ) => Effect.Effect<void, never>;
}

/**
 * Dependencies interface for TaskExecutor
 */
export interface TaskExecutorDependencies {
  retryService: Context.Tag.Service<typeof RetryService>;
  timeService: Context.Tag.Service<typeof TimeService>;
  ipcService: Context.Tag.Service<typeof IpcService>;
  telemetryService: Context.Tag.Service<typeof TaskTelemetryService>;
}

/**
 * Execution state for task execution
 * Groups all state refs used during task execution
 */
interface ExecutionState {
  readonly attemptRef: Ref.Ref<number>;
  readonly errorRef: Ref.Ref<Error | undefined>;
  readonly lastExitCodeRef: Ref.Ref<number | undefined>;
  readonly startedAt: Date;
  readonly telemetryRef: Ref.Ref<ExecutionTelemetry>;
  readonly lastSeenRef: Ref.Ref<ExecutionTelemetry>;
}

/**
 * Internal accumulator for telemetry across retry attempts.
 */
interface ExecutionTelemetry {
  durationMs: number;
}

/**
 * Task Executor
 * Provides stateless task execution with retry and cancellation support
 * Class-based implementation with dependency injection
 */
export class TaskExecutor {
  private readonly deps: TaskExecutorDependencies;

  constructor(dependencies: TaskExecutorDependencies) {
    this.deps = dependencies;
  }

  /**
   * Create idle detection effect that polls stream activity.
   *
   * The returned effect never completes while activity continues, and fails with an `Error`
   * (to trigger a retry) once the stream has been idle for at least `idleTimeoutMs`.
   *
   * Uses `Clock` for testability. Polling occurs every `idleCheckInterval`.
   *
   * @param taskId - Task identifier used in the error message.
   * @param lastChunkAtRef - Ref tracking the timestamp (ms) of the most recent chunk.
   * @param idleTimeoutMs - Idle timeout in milliseconds.
   * @param idleCheckInterval - Polling interval for idle detection.
   */
  private createStreamIdleInterrupt(
    taskId: string,
    lastChunkAtRef: Ref.Ref<number>,
    idleTimeoutMs: number,
    idleCheckInterval: Duration.Duration
  ): Effect.Effect<void, Error> {
    return Effect.gen(function* () {
      while (true) {
        yield* Effect.sleep(idleCheckInterval);
        const lastSeenAt = yield* Ref.get(lastChunkAtRef);
        const now = yield* Clock.currentTimeMillis;
        const idleForMs = Math.max(0, now - lastSeenAt);
        if (idleForMs >= idleTimeoutMs) {
          return yield* Effect.fail(
            new Error(
              [
                `Stream idle timeout for task ${taskId}.`,
                `No stream chunks received for ${Math.round(idleForMs / 60000)}m.`,
                `This is treated as a stalled execution and will trigger a retry.`,
              ].join(" ")
            )
          );
        }
      }
    });
  }

  /**
   * Create an effect that marks stream activity by updating the "last seen" timestamp ref.
   *
   * This should be called for every stream chunk to reset the idle timer.
   *
   * @param lastChunkAtRef - Ref to update with the current timestamp (ms).
   * @returns Effect that updates the timestamp.
   */
  private createMarkStreamActivityEffect(
    lastChunkAtRef: Ref.Ref<number>
  ): Effect.Effect<void, never> {
    return Clock.currentTimeMillis.pipe(
      Effect.flatMap(now => Ref.set(lastChunkAtRef, now)),
      Effect.asVoid
    );
  }

  /**
   * Wrap raw stream with idle detection, activity tracking, and telemetry.
   *
   * Idle timeout is measured from stream creation (when `startedAt` is captured), not from the
   * first chunk arrival. Callers should ensure the executor produces its first chunk within
   * the configured timeout (default: `STREAM_IDLE_TIMEOUT`).
   *
   * - `telemetryRef` accumulates telemetry across attempts.
   * - `lastSeenRef` tracks the per-attempt deltas used to compute incremental telemetry.
   * - `lastChunkAtRef` is updated on every chunk to reset idle detection.
   */
  private createMessageStream<TMessage, TId extends Provider, R>(
    rawStream: Stream.Stream<TMessage, Error, R>,
    params: RunnerOptions<TId>,
    telemetryRef: Ref.Ref<ExecutionTelemetry>,
    lastSeenRef: Ref.Ref<ExecutionTelemetry>
  ): Effect.Effect<Stream.Stream<TMessage, Error, R>, never> {
    const executor = this;
    return Effect.gen(function* () {
      const startedAt = yield* Clock.currentTimeMillis;
      const lastChunkAtRef = yield* Ref.make(startedAt);
      const idleTimeout = params.streamIdleTimeout ?? STREAM_IDLE_TIMEOUT;
      const idleCheckInterval = params.streamIdleCheckInterval ?? STREAM_IDLE_CHECK_INTERVAL;
      const idleTimeoutMs = Duration.toMillis(idleTimeout);

      const interruptWhenIdle = executor.createStreamIdleInterrupt(
        params.taskId,
        lastChunkAtRef,
        idleTimeoutMs,
        idleCheckInterval
      );
      const markStreamActivity = executor.createMarkStreamActivityEffect(lastChunkAtRef);

      return rawStream.pipe(
        Stream.mapEffect((chunk: TMessage) =>
          executor
            .handleTelemetryChunk(chunk, telemetryRef, lastSeenRef, params)
            .pipe(Effect.as(chunk))
        ),
        Stream.tap(() => markStreamActivity),
        Stream.interruptWhen(interruptWhenIdle)
      );
    });
  }

  /**
   * Execute a task with automatic retry and cancellation support
   *
   * Creates per-execution state for attempt tracking and error accumulation.
   * State is scoped to each execution and not shared across calls.
   */
  execute<TId extends Provider>(
    params: RunnerOptions<TId>,
    executorFactory: ExecutorFactory
  ): Effect.Effect<ExecutionResult, Error> {
    return this.buildExecutionState(params).pipe(
      Effect.flatMap(state =>
        this.executeWithRetry(params, executorFactory, state).pipe(
          Effect.flatMap(result =>
            this.buildExecutionResult(
              result,
              state.attemptRef,
              state.errorRef,
              state.startedAt,
              state.telemetryRef
            )
          )
        )
      )
    );
  }

  /**
   * Build execution state with all required refs
   * Creates per-execution state (fresh for each call)
   */
  private buildExecutionState<TId extends Provider>(
    _params: RunnerOptions<TId>
  ): Effect.Effect<ExecutionState, never> {
    return Effect.gen(function* () {
      const attemptRef = yield* Ref.make(1);
      const errorRef = yield* Ref.make<Error | undefined>(undefined);
      const lastExitCodeRef = yield* Ref.make<number | undefined>(undefined);
      const telemetryRef = yield* Ref.make<ExecutionTelemetry>({
        durationMs: 0,
      });
      const lastSeenRef = yield* Ref.make<ExecutionTelemetry>({
        durationMs: 0,
      });
      const startedAt = new Date();

      return {
        attemptRef,
        errorRef,
        lastExitCodeRef,
        startedAt,
        telemetryRef,
        lastSeenRef,
      };
    });
  }

  /**
   * Map finish reason from AI SDK to exit code
   * Maps finish reasons to appropriate ExitCode values
   */
  private mapFinishReasonToExitCode(finishReason: string): number {
    switch (finishReason) {
      case "stop":
        return ExitCode.SUCCESS;
      case "tool-calls":
        return ExitCode.SUCCESS;
      case "pause":
        return ExitCode.SUCCESS;
      case "error":
        return ExitCode.EXECUTION_ERROR;
      case "length":
        return ExitCode.EXECUTION_ERROR;
      case "content-filter":
        return ExitCode.EXECUTION_ERROR;
      case "other":
        return ExitCode.EXECUTION_ERROR;
      case "unknown":
        return ExitCode.EXECUTION_ERROR;
      default:
        return ExitCode.EXECUTION_ERROR;
    }
  }

  private extractProviderMetadata(
    chunkObj: Record<string, unknown>
  ): RunResult["providerMetadata"] | undefined {
    const isRecord = (value: unknown): value is Record<string, unknown> =>
      typeof value === "object" && value !== null;

    const providerMetadata = chunkObj["providerMetadata"];
    if (isRecord(providerMetadata)) {
      return providerMetadata;
    }

    const response = chunkObj["response"];
    if (isRecord(response)) {
      const responseProviderMetadata = response["providerMetadata"];
      if (isRecord(responseProviderMetadata)) {
        return responseProviderMetadata;
      }
    }

    return undefined;
  }

  private processFinishChunk(chunk: unknown): RunResult | null {
    if (typeof chunk === "object" && chunk !== null && "type" in chunk && chunk.type === "finish") {
      const finishReason =
        "finishReason" in chunk && typeof chunk.finishReason === "string"
          ? chunk.finishReason
          : "reason" in chunk && typeof chunk.reason === "string"
            ? chunk.reason
            : "unknown";
      const exitCode = this.mapFinishReasonToExitCode(finishReason);

      const chunkObj = chunk as Record<string, unknown>;

      const providerMetadata = this.extractProviderMetadata(chunkObj);

      return {
        exitCode,
        ...(providerMetadata ? { providerMetadata } : {}),
      } as RunResult;
    }
    return null;
  }

  /**
   * Process completion stream to detect finish chunks
   * Returns Effect that processes the stream and tracks results in a Ref
   * Handles both finish chunks and stream errors/interruptions
   * Stops consuming the stream after detecting the finish chunk using takeUntil
   *
   * Interruption handling: Uses catchAllCause to catch interruptions and set resultRef
   * to USER_CANCELLED, ensuring interrupted tasks are not marked as completed
   */
  private processCompletionStream<R>(
    stream: Stream.Stream<unknown, Error, R>,
    resultRef: Ref.Ref<Option.Option<RunResult>>,
    telemetryRef: Ref.Ref<ExecutionTelemetry>,
    lastSeenRef: Ref.Ref<ExecutionTelemetry>,
    params: RunnerOptions<Provider>
  ): Effect.Effect<void, never, R> {
    const executor = this;
    // Stop consuming the stream after we detect the finish chunk
    // takeUntil includes the element that makes the predicate true, so the finish chunk will be processed
    const streamUntilFinish = stream.pipe(
      Stream.takeUntil((chunk: unknown) => {
        // Check if this is a finish chunk - predicate returns true to stop after this chunk
        return (
          typeof chunk === "object" && chunk !== null && "type" in chunk && chunk.type === "finish"
        );
      })
    );

    return Stream.runForEach(streamUntilFinish, (chunk: unknown) =>
      Effect.gen(function* () {
        // CRITICAL: Extract telemetry from finish chunks before processing them
        // This ensures we capture duration telemetry even if handleTelemetryChunk missed it
        const isFinishChunk =
          typeof chunk === "object" && chunk !== null && "type" in chunk && chunk.type === "finish";

        if (isFinishChunk) {
          yield* executor.handleTelemetryChunk(chunk, telemetryRef, lastSeenRef, params);
        }

        const result = executor.processFinishChunk(chunk);
        if (result !== null) {
          yield* Ref.set(resultRef, Option.some(result));
        }
      })
    ).pipe(
      // If stream completes successfully without a finish chunk, set resultRef to SUCCESS
      // This handles cases where executors don't emit finish chunks (e.g., mock executors in tests)
      Effect.ensuring(
        Effect.gen(function* () {
          const currentResult = yield* Ref.get(resultRef);
          if (Option.isNone(currentResult)) {
            // Stream completed without finish chunk - treat as success
            yield* Ref.set(resultRef, Option.some({ exitCode: ExitCode.SUCCESS } as RunResult));
          }
        })
      ),
      Effect.catchAllCause(cause =>
        executor
          .handleExecutionCause(cause)
          .pipe(
            Effect.flatMap(errorResult =>
              Ref.set(resultRef, Option.some(errorResult)).pipe(Effect.asVoid)
            )
          )
      )
    );
  }

  /**
   * Run stream processing with error handling
   *
   * Catches all causes (including interruptions) and ensures resultRef is set.
   * This ensures that if stream processing is interrupted, the resultRef is
   * populated with USER_CANCELLED before getResultFromRef is called.
   */
  private runStreamProcessing<R>(
    streamProcessingEffect: Effect.Effect<void, never, R>,
    resultRef: Ref.Ref<Option.Option<RunResult>>
  ): Effect.Effect<void, never, R> {
    const executor = this;
    return streamProcessingEffect.pipe(
      Effect.catchAllCause(cause =>
        executor
          .handleExecutionCause(cause)
          .pipe(
            Effect.flatMap(errorResult =>
              Ref.set(resultRef, Option.some(errorResult)).pipe(Effect.asVoid)
            )
          )
      )
    );
  }

  /**
   * Get result from Ref
   *
   * This should never return an empty result if interruption handlers work correctly.
   * If resultRef is empty, it indicates a programming error - return EXECUTION_ERROR
   * to make bugs visible instead of silently succeeding.
   */
  private getResultFromRef(
    resultRef: Ref.Ref<Option.Option<RunResult>>
  ): Effect.Effect<RunResult, never> {
    return Effect.gen(function* () {
      const resultOption = yield* Ref.get(resultRef);
      return Option.match(resultOption, {
        onNone: () => {
          // This should never happen if interruption handlers work correctly
          // Return EXECUTION_ERROR to make bugs visible instead of silently succeeding
          return { exitCode: ExitCode.EXECUTION_ERROR } as RunResult;
        },
        onSome: result => result,
      });
    });
  }

  /**
   * Build retry schedule using exponential backoff
   */
  private buildRetrySchedule(): Schedule.Schedule<Duration.Duration, unknown, never> {
    return this.deps.timeService.exponentialBackoff(250, 2, 30000);
  }

  /**
   * Execute task with retry logic using the provided execution state
   */
  private executeWithRetry<TId extends Provider>(
    params: RunnerOptions<TId>,
    executorFactory: ExecutorFactory,
    state: ExecutionState
  ): Effect.Effect<RunResult, Error> {
    const executor = this;
    const maxAttempts = params.maxAttempts ?? 3;
    const schedule = this.buildRetrySchedule();

    const effectFactory = executor.createRetryEffectFactory(
      params,
      executorFactory,
      state.attemptRef,
      state.errorRef,
      state.lastExitCodeRef,
      state.telemetryRef,
      state.lastSeenRef
    );

    return executor.deps.retryService.retryWithContext(effectFactory, {
      schedule,
      maxAttempts,
      shouldRetry: (result: RunResult) =>
        result.exitCode !== ExitCode.SUCCESS && result.exitCode !== ExitCode.USER_CANCELLED,
      onRetry: (
        _attempt: number,
        _lastError: Error | undefined,
        _lastResult: RunResult | undefined,
        _delay: Duration.Duration
      ) => {
        return Effect.void;
      },
    });
  }

  /**
   * Modify prompt components for retry attempts
   * Preserves all fields from originalPrompt (including subagents) and only modifies userPrompt
   */
  private buildRetryPrompt(
    originalPrompt: PromptComponents,
    attempt: number,
    lastError: Error | undefined,
    lastExitCode: number | undefined
  ): PromptComponents {
    const retryContext: RetryContext = {
      attempt: attempt - 1,
      ...(lastError && { error: lastError }),
      ...(lastExitCode !== undefined && { exitCode: lastExitCode }),
    };

    return {
      ...originalPrompt,
      userPrompt: appendRetryContext(originalPrompt.userPrompt, retryContext),
    };
  }

  /**
   * Execute executor with error handling
   * Note: errorRef is managed by executeSingleAttempt to avoid duplicate writes
   */
  private runExecutor<TId extends Provider>(
    params: RunnerOptions<TId>,
    executorFactory: ExecutorFactory,
    _attemptRef: Ref.Ref<number>,
    _errorRef: Ref.Ref<Error | undefined>,
    promptComponents: PromptComponents,
    telemetryRef: Ref.Ref<ExecutionTelemetry>,
    lastSeenRef: Ref.Ref<ExecutionTelemetry>
  ): Effect.Effect<RunResult, Error> {
    const executor = this;
    return Effect.gen(function* () {
      const workingDirectory = getWorkingDirectory(params.options) ?? process.cwd();
      const executorInstance = yield* executorFactory.get(params.executorId, workingDirectory);
      const result = yield* executor
        .executeExecutor(executorInstance, params, promptComponents, telemetryRef, lastSeenRef)
        .pipe(Effect.scoped);

      return result;
    });
  }

  /**
   * Handle cause and convert to RunResult
   * Uses Effect's Cause inspection to determine the execution outcome
   */
  private handleExecutionCause(cause: Cause.Cause<Error>): Effect.Effect<RunResult, never> {
    if (Cause.isInterruptedOnly(cause) || Cause.isInterrupted(cause)) {
      return Effect.succeed({ exitCode: ExitCode.USER_CANCELLED } as RunResult);
    }
    return Effect.succeed({ exitCode: ExitCode.EXECUTION_ERROR } as RunResult);
  }

  /**
   * Fork stream hook in background with error handling
   * Errors are logged but don't break task execution
   * Handles all failures including defects and interrupts
   */
  private forkStreamHook<TId extends Provider, R>(
    params: RunnerOptions<TId>,
    stream: Stream.Stream<unknown, Error, R>
  ): Effect.Effect<void, never, Scope.Scope> {
    return Effect.forkDaemon(
      params.onStream!(stream).pipe(
        Effect.catchAll((error: unknown) => {
          const errorMessage = error instanceof Error ? error.message : String(error);
          console.error(`Stream hook error for task ${params.taskId}: ${errorMessage}`);
          return Effect.void;
        }),
        Effect.catchAllCause((cause: Cause.Cause<Error>) => {
          const errorMessage = Cause.isFailure(cause)
            ? Option.match(Cause.failureOption(cause), {
                onNone: () => "Unknown error",
                onSome: error => (error instanceof Error ? error.message : String(error)),
              })
            : Cause.isInterrupted(cause)
              ? "Stream hook interrupted"
              : "Stream hook defect";
          console.error(`Stream hook error for task ${params.taskId}: ${errorMessage}`);
          return Effect.void;
        })
      )
    ).pipe(Effect.asVoid);
  }

  /**
   * Execute executor instance
   * Uses Effect's built-in cancellation mechanisms
   * Streams directly to Hono server via onStream hook if provided
   *
   * Interruption handling flow:
   * 1. processCompletionStream catches interruptions and sets resultRef to USER_CANCELLED
   * 2. runStreamProcessing also catches interruptions as a safety net
   * 3. Top-level catchAllCause handler ensures that if the entire Effect.gen is interrupted
   *    before inner handlers complete, we return USER_CANCELLED
   * 4. getResultFromRef returns EXECUTION_ERROR if resultRef is empty (should never happen)
   *
   * This multi-layer approach ensures interrupted tasks are never marked as completed.
   */
  private executeExecutor<TId extends Provider>(
    executorInstance: ExecutorForId<TId>,
    params: RunnerOptions<TId>,
    promptComponents: PromptComponents,
    telemetryRef: Ref.Ref<ExecutionTelemetry>,
    lastSeenRef: Ref.Ref<ExecutionTelemetry>
  ): Effect.Effect<RunResult, Error, Scope.Scope> {
    const runInput: RunInput = {
      promptComponents,
    };
    const executorOptions = {
      ...params.options,
      issueId: params.issueId,
    };
    const rawStream = executorInstance.run(runInput, executorOptions);
    const executor = this;
    return Effect.gen(function* () {
      const messageStream = yield* executor.createMessageStream(
        rawStream,
        params,
        telemetryRef,
        lastSeenRef
      );
      // Bounded capacity to prevent unbounded memory growth if hook consumer is slow
      // Uses backpressure strategy: if buffer is full, the producer will wait
      const [streamForHook, streamForCompletion] = params.onStream
        ? yield* Stream.broadcast(messageStream, 2, {
            capacity: 64,
          })
        : [null, messageStream];
      if (params.onStream && streamForHook) {
        yield* executor.forkStreamHook(params, streamForHook);
      }
      const resultRef = yield* Ref.make<Option.Option<RunResult>>(Option.none());
      const streamProcessingEffect = executor.processCompletionStream(
        streamForCompletion,
        resultRef,
        telemetryRef,
        lastSeenRef,
        params
      );
      yield* executor.runStreamProcessing(streamProcessingEffect, resultRef);
      // Get result - resultRef should always be set by now (either by stream processing or interruption handlers)
      const result = yield* executor.getResultFromRef(resultRef);
      return result;
    }).pipe(
      Effect.catchAllCause(cause => {
        // If interrupted and no result was set, return USER_CANCELLED
        // This is a fallback handler in case the entire Effect.gen is interrupted before
        // inner handlers (processCompletionStream/runStreamProcessing) can set resultRef
        if (Cause.isInterruptedOnly(cause) || Cause.isInterrupted(cause)) {
          return Effect.succeed({ exitCode: ExitCode.USER_CANCELLED } as RunResult);
        }
        return executor.handleExecutionCause(cause);
      })
    );
  }

  private executeSingleAttempt<TId extends Provider>(
    params: RunnerOptions<TId>,
    executorFactory: ExecutorFactory,
    attemptRef: Ref.Ref<number>,
    errorRef: Ref.Ref<Error | undefined>,
    promptComponents: PromptComponents,
    telemetryRef: Ref.Ref<ExecutionTelemetry>,
    lastSeenRef: Ref.Ref<ExecutionTelemetry>
  ): Effect.Effect<RunResult, Error> {
    const executor = this;
    return Effect.gen(function* () {
      // Reset last-seen metering for this attempt so deltas are computed correctly.
      yield* Ref.set(lastSeenRef, {
        durationMs: 0,
      });
      const result = yield* executor.runExecutor(
        params,
        executorFactory,
        attemptRef,
        errorRef,
        promptComponents,
        telemetryRef,
        lastSeenRef
      );
      if (result.exitCode !== 0) {
        const error = new Error(`Execution failed with exit code ${result.exitCode}`);
        yield* Ref.set(errorRef, error);
      }
      return result;
    }).pipe(
      Effect.catchAll((error: Error) => {
        return Effect.gen(function* () {
          yield* Ref.set(errorRef, error);
          return {
            exitCode: ExitCode.EXECUTION_ERROR,
          } as RunResult;
        });
      })
    );
  }

  /**
   * Create effect factory for retryWithContext
   * Rebuilds the effect with modified prompt on each retry
   */
  private createRetryEffectFactory<TId extends Provider>(
    params: RunnerOptions<TId>,
    executorFactory: ExecutorFactory,
    attemptRef: Ref.Ref<number>,
    errorRef: Ref.Ref<Error | undefined>,
    lastExitCodeRef: Ref.Ref<number | undefined>,
    telemetryRef: Ref.Ref<ExecutionTelemetry>,
    lastSeenRef: Ref.Ref<ExecutionTelemetry>
  ) {
    const executor = this;
    return (
      attempt: number,
      lastError: Error | undefined,
      lastResult: RunResult | undefined
    ): Effect.Effect<RunResult, Error> => {
      return Effect.gen(function* () {
        yield* Ref.set(attemptRef, attempt);
        let promptForAttempt = params.promptComponents;
        if (attempt > 1) {
          const lastExitCode = lastResult?.exitCode;
          promptForAttempt = executor.buildRetryPrompt(
            params.promptComponents,
            attempt,
            lastError,
            lastExitCode
          );
        }
        if (lastResult) {
          yield* Ref.set(lastExitCodeRef, lastResult.exitCode);
        }
        return yield* executor.executeSingleAttempt(
          params,
          executorFactory,
          attemptRef,
          errorRef,
          promptForAttempt,
          telemetryRef,
          lastSeenRef
        );
      });
    };
  }

  /**
   * Build final execution result from retry result and state
   */
  private buildExecutionResult(
    result: RunResult,
    attemptRef: Ref.Ref<number>,
    errorRef: Ref.Ref<Error | undefined>,
    startedAt: Date,
    telemetryRef: Ref.Ref<ExecutionTelemetry>
  ): Effect.Effect<ExecutionResult, never> {
    return Effect.gen(function* () {
      const finalAttempt = yield* Ref.get(attemptRef);
      const finalError = yield* Ref.get(errorRef);
      const telemetry = yield* Ref.get(telemetryRef);

      return {
        exitCode: result.exitCode,
        attempt: finalAttempt,
        error: result.exitCode !== 0 ? finalError : undefined,
        startedAt,
        completedAt: new Date(),
        telemetry: {
          durationMs: telemetry.durationMs,
        },
      } as ExecutionResult;
    });
  }

  /**
   * Process any stream chunk for telemetry in realtime.
   * Extracts usage/provider metadata when present and converts cumulative values into deltas.
   * Emits deltas to the TaskTelemetryService and updates the local accumulator.
   */
  private extractTelemetrySample(chunk: unknown): {
    durationCurrent: number;
  } | null {
    if (!chunk || typeof chunk !== "object") {
      return null;
    }

    const chunkObj = chunk as Record<string, unknown>;
    const providerMetadata = this.extractProviderMetadata(chunkObj);

    const safe = (value: unknown): number =>
      typeof value === "number" && Number.isFinite(value) ? value : 0;

    let durationCurrent: number | undefined = undefined;
    if (providerMetadata && typeof providerMetadata === "object") {
      const claudePm = (providerMetadata as Record<string, unknown>)["claude-code"];
      if (claudePm && typeof claudePm === "object" && claudePm !== null) {
        const claudePmObj = claudePm as Record<string, unknown>;
        const rawDuration = "durationMs" in claudePmObj ? claudePmObj.durationMs : undefined;
        // Only extract if durationMs exists (allow 0ms as valid value)
        if (rawDuration !== undefined && rawDuration !== null) {
          durationCurrent = safe(rawDuration);
        }
      }
    }

    // Return null only if duration is missing, not if it's 0ms
    if (durationCurrent === undefined) {
      return null;
    }

    return { durationCurrent };
  }

  private handleTelemetryChunk<TId extends Provider>(
    chunk: unknown,
    telemetryRef: Ref.Ref<ExecutionTelemetry>,
    lastSeenRef: Ref.Ref<ExecutionTelemetry>,
    params: RunnerOptions<TId>
  ): Effect.Effect<void, never> {
    const sample = this.extractTelemetrySample(chunk);
    if (!sample) {
      return Effect.void;
    }

    const executor = this;
    return Effect.gen(function* () {
      const last = yield* Ref.get(lastSeenRef);

      const durationDelta = Math.max(0, sample.durationCurrent - last.durationMs);

      // Early return if no duration change to avoid unnecessary updates
      if (durationDelta === 0) {
        return;
      }

      const nextSeen: ExecutionTelemetry = {
        durationMs: Math.max(last.durationMs, sample.durationCurrent),
      };

      yield* Ref.set(lastSeenRef, nextSeen);

      const delta: TelemetryDelta = { durationMs: durationDelta };

      yield* Ref.update(telemetryRef, current => ({
        durationMs: current.durationMs + durationDelta,
      })).pipe(Effect.asVoid);

      yield* executor.deps.telemetryService.recordDelta(params.taskId, delta);
    });
  }
}
