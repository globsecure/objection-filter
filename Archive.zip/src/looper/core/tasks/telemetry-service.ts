/**
 * TaskTelemetryService
 * Centralized realtime telemetry aggregation with throttled persistence.
 *
 * - Executor emits telemetry deltas from streaming chunks.
 * - Orchestrator sets current phase and final status.
 * - Service flushes to disk on a fixed tick (throttle).
 * - Frontend fetches persisted telemetry via API and calculates duration client-side.
 */

import * as Clock from "effect/Clock";
import * as Context from "effect/Context";
import * as Duration from "effect/Duration";
import * as Effect from "effect/Effect";
import * as Fiber from "effect/Fiber";
import * as Layer from "effect/Layer";
import * as Option from "effect/Option";
import * as Ref from "effect/Ref";
import * as Stream from "effect/Stream";
import * as SynchronizedRef from "effect/SynchronizedRef";

import {
  SqliteError,
  SqliteTelemetryRepository,
  SqliteTelemetryRepositoryLayer,
  getDefaultSqliteDbPath,
  type TaskTelemetryData,
  type TaskTelemetryStatus,
  type TelemetrySummary,
} from "../../sqlite";
import type { StreamPhase } from "./types";

export interface TelemetryDelta {
  readonly durationMs?: number;
}

interface RuntimeState {
  readonly taskId: string;
  readonly issueId: string;
  readonly workingDirectory: string;
  readonly status: TaskTelemetryStatus;
  readonly startedAt: string;
  readonly startedAtMs: number;
  readonly completedAt?: string;
  readonly updatedAt: number;
  readonly currentPhase: StreamPhase;
  readonly phases: Partial<Record<StreamPhase, TelemetrySummary>>;
  readonly totals: TelemetrySummary;
}

const emptySummary = (): TelemetrySummary => ({
  durationMs: 0,
});

const safe = (value: unknown): number =>
  typeof value === "number" && Number.isFinite(value) ? value : 0;

const buildUpdateState =
  (stateRef: Ref.Ref<Map<string, RuntimeState>>) =>
  (taskId: string, updater: (current: RuntimeState) => RuntimeState): Effect.Effect<void, never> =>
    Ref.update(stateRef, map => {
      const current = map.get(taskId);
      if (!current) return map;
      const next = new Map(map);
      next.set(taskId, updater(current));
      return next;
    }).pipe(Effect.asVoid);

const toData = (state: RuntimeState, now: number): TaskTelemetryData => {
  const runningDuration =
    state.status === "running"
      ? Math.max(state.totals.durationMs, now - state.startedAtMs)
      : state.totals.durationMs;

  return {
    taskId: state.taskId,
    issueId: state.issueId,
    status: state.status,
    startedAt: state.startedAt,
    ...(state.status !== "running"
      ? { completedAt: state.completedAt ?? new Date(now).toISOString() }
      : {}),
    updatedAt: now,
    phases: state.phases,
    totals: { ...state.totals, durationMs: runningDuration },
  };
};

const buildFlush =
  (stateRef: Ref.Ref<Map<string, RuntimeState>>, lastFlushedAtRef: Ref.Ref<Map<string, number>>) =>
  (taskId: string): Effect.Effect<void, never, SqliteTelemetryRepository> =>
    Effect.gen(function* () {
      const map = yield* Ref.get(stateRef);
      const state = map.get(taskId);
      if (!state) return;

      const now = yield* Clock.currentTimeMillis;
      const lastMap = yield* Ref.get(lastFlushedAtRef);
      const last = lastMap.get(taskId) ?? 0;
      // Use strict inequality so we don't skip a flush when the state update and the last flush
      // happen within the same millisecond (clock resolution). This avoids flakiness where
      // finalize() updates the status but the persisted file remains "running".
      if (state.updatedAt < last) return;

      const data = toData(state, now);

      const repo = yield* SqliteTelemetryRepository;
      yield* repo.save(taskId, data).pipe(
        Effect.tap(() =>
          Ref.update(lastFlushedAtRef, m => {
            const next = new Map(m);
            next.set(taskId, now);
            return next;
          })
        ),
        Effect.catchAll(() => Effect.void)
      );
    }).pipe(Effect.catchAll(() => Effect.void));

const buildEnsureFlushFiber =
  (
    flushFibersRef: SynchronizedRef.SynchronizedRef<Map<string, Fiber.RuntimeFiber<void, never>>>,
    flush: (taskId: string) => Effect.Effect<void, never, SqliteTelemetryRepository>
  ) =>
  (params: { taskId: string; workingDirectory: string }): Effect.Effect<void, never> =>
    // Use SynchronizedRef.modifyEffect for atomic check-and-create to prevent race conditions
    SynchronizedRef.modifyEffect(flushFibersRef, fibers => {
      if (fibers.has(params.taskId)) {
        // Already exists, return same map without modification
        return Effect.succeed([undefined, fibers] as const);
      }
      // Create fiber and update map atomically
      // Use forkDaemon to create a long-lived fiber that runs independently.
      // Each flush tick opens its own scoped SQLite connection.
      const dbPath = getDefaultSqliteDbPath(params.workingDirectory);
      return Stream.tick(Duration.millis(1000)).pipe(
        Stream.runForEach(() =>
          flush(params.taskId).pipe(
            Effect.provide(SqliteTelemetryRepositoryLayer(dbPath)),
            Effect.scoped,
            Effect.catchAll(() => Effect.void)
          )
        ),
        Effect.catchAll(() => Effect.void),
        Effect.forkDaemon,
        Effect.map(fiber => {
          const next = new Map(fibers);
          next.set(params.taskId, fiber);
          return [undefined, next] as const;
        })
      );
    });

const buildInit =
  (
    stateRef: Ref.Ref<Map<string, RuntimeState>>,
    ensureFlushFiber: (params: {
      taskId: string;
      workingDirectory: string;
    }) => Effect.Effect<void, never>,
    flush: (taskId: string) => Effect.Effect<void, never, SqliteTelemetryRepository>
  ) =>
  (params: {
    taskId: string;
    issueId: string;
    workingDirectory: string;
    initialPhase?: StreamPhase;
  }): Effect.Effect<void, never> =>
    Effect.gen(function* () {
      const now = yield* Clock.currentTimeMillis;
      const phase = params.initialPhase ?? "primary";
      const dbPath = getDefaultSqliteDbPath(params.workingDirectory);
      const runtimeState: RuntimeState = {
        taskId: params.taskId,
        issueId: params.issueId,
        workingDirectory: params.workingDirectory,
        status: "running",
        startedAt: new Date(now).toISOString(),
        startedAtMs: now,
        updatedAt: now,
        currentPhase: phase,
        phases: { [phase]: emptySummary() },
        totals: emptySummary(),
      };

      yield* Ref.update(stateRef, map => {
        const next = new Map(map);
        next.set(params.taskId, runtimeState);
        return next;
      }).pipe(Effect.asVoid);

      yield* ensureFlushFiber({ taskId: params.taskId, workingDirectory: params.workingDirectory });
      yield* flush(params.taskId).pipe(
        Effect.provide(SqliteTelemetryRepositoryLayer(dbPath)),
        Effect.scoped,
        Effect.catchAll(() => Effect.void)
      );
    });

const buildSetPhase =
  (updateState: ReturnType<typeof buildUpdateState>) =>
  (taskId: string, phase: StreamPhase): Effect.Effect<void, never> =>
    Clock.currentTimeMillis.pipe(
      Effect.flatMap(now =>
        updateState(taskId, current => ({
          ...current,
          currentPhase: phase,
          updatedAt: now,
          phases: {
            ...current.phases,
            ...(current.phases[phase] ? {} : { [phase]: emptySummary() }),
          },
        }))
      )
    );

const buildRecordDelta =
  (updateState: ReturnType<typeof buildUpdateState>) =>
  (taskId: string, delta: TelemetryDelta): Effect.Effect<void, never> =>
    Clock.currentTimeMillis.pipe(
      Effect.flatMap(now =>
        updateState(taskId, current => {
          const phase = current.currentPhase;
          const prevPhase = current.phases[phase] ?? emptySummary();
          const nextPhase: TelemetrySummary = {
            durationMs: prevPhase.durationMs + safe(delta.durationMs),
          };

          const nextTotals: TelemetrySummary = {
            durationMs: current.totals.durationMs + safe(delta.durationMs),
          };

          return {
            ...current,
            updatedAt: now,
            phases: { ...current.phases, [phase]: nextPhase },
            totals: nextTotals,
          };
        })
      )
    );

const deleteFromRefMap =
  <T>(ref: Ref.Ref<Map<string, T>>) =>
  (key: string): Effect.Effect<void, never> =>
    Ref.update(ref, map => {
      if (!map.has(key)) return map;
      const next = new Map(map);
      next.delete(key);
      return next;
    }).pipe(Effect.asVoid);

const buildFinalizeStateUpdater =
  (now: number, status: Exclude<TaskTelemetryStatus, "running">) =>
  (current: RuntimeState): RuntimeState => {
    // Ensure completed tasks always have a non-zero duration even when
    // provider telemetry doesn't report timing deltas.
    const wallClockDurationMs = Math.max(0, now - current.startedAtMs);
    const durationMs = Math.max(current.totals.durationMs, wallClockDurationMs);
    const durationDelta = Math.max(0, durationMs - current.totals.durationMs);

    const phase = current.currentPhase;
    const prevPhase = current.phases[phase] ?? emptySummary();

    return {
      ...current,
      status,
      completedAt: new Date(now).toISOString(),
      updatedAt: now,
      phases:
        durationDelta === 0
          ? current.phases
          : {
              ...current.phases,
              [phase]: { durationMs: prevPhase.durationMs + durationDelta },
            },
      totals: { ...current.totals, durationMs },
    };
  };

const stopFlushFiber = (
  flushFibersRef: SynchronizedRef.SynchronizedRef<Map<string, Fiber.RuntimeFiber<void, never>>>,
  taskId: string
): Effect.Effect<void, never> =>
  SynchronizedRef.modify(flushFibersRef, fibers => {
    const existing = fibers.get(taskId);
    if (!existing) return [undefined, fibers] as const;
    const next = new Map(fibers);
    next.delete(taskId);
    return [existing, next] as const;
  }).pipe(
    Effect.flatMap(fiber =>
      fiber ? Fiber.interrupt(fiber).pipe(Effect.catchAll(() => Effect.void)) : Effect.void
    ),
    Effect.asVoid
  );

const buildCleanupRuntimeState =
  (
    stateRef: Ref.Ref<Map<string, RuntimeState>>,
    flushFibersRef: SynchronizedRef.SynchronizedRef<Map<string, Fiber.RuntimeFiber<void, never>>>,
    lastFlushedAtRef: Ref.Ref<Map<string, number>>
  ) =>
  (taskId: string): Effect.Effect<void, never> =>
    Effect.gen(function* () {
      yield* stopFlushFiber(flushFibersRef, taskId);
      yield* deleteFromRefMap(stateRef)(taskId);
      yield* deleteFromRefMap(lastFlushedAtRef)(taskId);
    });

const buildFinalize =
  (
    stateRef: Ref.Ref<Map<string, RuntimeState>>,
    updateState: ReturnType<typeof buildUpdateState>,
    flushFibersRef: SynchronizedRef.SynchronizedRef<Map<string, Fiber.RuntimeFiber<void, never>>>,
    lastFlushedAtRef: Ref.Ref<Map<string, number>>,
    flush: (taskId: string) => Effect.Effect<void, never, SqliteTelemetryRepository>
  ) =>
  (taskId: string, status: Exclude<TaskTelemetryStatus, "running">): Effect.Effect<void, never> =>
    Effect.gen(function* () {
      const stateMap = yield* Ref.get(stateRef);
      const existing = stateMap.get(taskId);
      const dbPath = existing ? getDefaultSqliteDbPath(existing.workingDirectory) : null;

      const now = yield* Clock.currentTimeMillis;
      yield* updateState(taskId, buildFinalizeStateUpdater(now, status));

      if (dbPath) {
        yield* flush(taskId).pipe(
          Effect.provide(SqliteTelemetryRepositoryLayer(dbPath)),
          Effect.scoped,
          Effect.catchAll(() => Effect.void)
        );
      }
      yield* stopFlushFiber(flushFibersRef, taskId);
      yield* deleteFromRefMap(stateRef)(taskId);
      yield* deleteFromRefMap(lastFlushedAtRef)(taskId);
    });

export class TaskTelemetryService extends Context.Tag("@looper/TaskTelemetryService")<
  TaskTelemetryService,
  {
    readonly init: (params: {
      taskId: string;
      issueId: string;
      workingDirectory: string;
      initialPhase?: StreamPhase;
    }) => Effect.Effect<void, never>;
    readonly loadPersisted: (params: {
      taskId: string;
      workingDirectory: string;
    }) => Effect.Effect<Option.Option<TaskTelemetryData>, SqliteError>;
    readonly setPhase: (taskId: string, phase: StreamPhase) => Effect.Effect<void, never>;
    readonly recordDelta: (taskId: string, delta: TelemetryDelta) => Effect.Effect<void, never>;
    readonly finalize: (
      taskId: string,
      status: Exclude<TaskTelemetryStatus, "running">
    ) => Effect.Effect<void, never>;
    readonly cleanupRuntimeState: (taskId: string) => Effect.Effect<void, never>;
  }
>() {}

export const TaskTelemetryServiceLive = Layer.effect(
  TaskTelemetryService,
  Effect.gen(function* () {
    const stateRef = yield* Ref.make<Map<string, RuntimeState>>(new Map());
    const flushFibersRef = yield* SynchronizedRef.make<
      Map<string, Fiber.RuntimeFiber<void, never>>
    >(new Map());
    const lastFlushedAtRef = yield* Ref.make<Map<string, number>>(new Map());

    const updateState = buildUpdateState(stateRef);
    const flush = buildFlush(stateRef, lastFlushedAtRef);
    const ensureFlushFiber = buildEnsureFlushFiber(flushFibersRef, flush);

    return {
      init: buildInit(stateRef, ensureFlushFiber, flush),
      loadPersisted: params => {
        const dbPath = getDefaultSqliteDbPath(params.workingDirectory);
        return Effect.gen(function* () {
          const repo = yield* SqliteTelemetryRepository;
          return yield* repo.load(params.taskId);
        }).pipe(Effect.provide(SqliteTelemetryRepositoryLayer(dbPath)), Effect.scoped);
      },
      setPhase: buildSetPhase(updateState),
      recordDelta: buildRecordDelta(updateState),
      finalize: buildFinalize(stateRef, updateState, flushFibersRef, lastFlushedAtRef, flush),
      cleanupRuntimeState: buildCleanupRuntimeState(stateRef, flushFibersRef, lastFlushedAtRef),
    };
  })
);

export const TaskTelemetryServiceMock = Layer.succeed(TaskTelemetryService, {
  init: () => Effect.void,
  loadPersisted: () => Effect.succeed(Option.none()),
  setPhase: () => Effect.void,
  recordDelta: () => Effect.void,
  finalize: () => Effect.void,
  cleanupRuntimeState: () => Effect.void,
});

/**
 * Default layer is a no-op (tests / non-electron environments can override).
 * Electron runtime provides TaskTelemetryServiceLive explicitly.
 */
export const TaskTelemetryLayer = TaskTelemetryServiceMock;
