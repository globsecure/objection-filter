/**
 * Task Source
 * Provides task state management and backend synchronization
 * Class-based implementation with dependency injection
 */

import { Context, Effect, Layer } from "effect";
import { ApiClientService } from "../../data/api-client/api-client";
import { RetryService } from "../layers/retry";
import { TimeService } from "../layers/time";

/**
 * Backend task status values (mirrors backend schema)
 */
export type BackendTaskStatus =
  | "pending"
  | "in_progress"
  | "completed"
  | "failed"
  | "canceled"
  | "saved";

/**
 * Backend task complexity values (mirrors backend schema)
 */
export type BackendTaskComplexity = "low" | "medium" | "high" | "critical";

/**
 * Backend task schema shape returned by the API.
 */
export interface BackendTask {
  readonly id: string;
  readonly issueId: string;
  readonly slug?: string | undefined;
  readonly title: string;
  readonly content: string;
  readonly complexity: BackendTaskComplexity;
  readonly status: BackendTaskStatus;
  readonly position: number;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

/**
 * Task summary returned when listing tasks (includes subtask count metadata).
 */
export interface TaskSummary {
  readonly task: BackendTask;
  readonly subtaskCount: number;
}

/**
 * Paginated list response for tasks endpoint.
 */
export interface ListTasksResponse {
  readonly tasks: TaskSummary[];
  readonly pagination: {
    readonly total: number;
    readonly limit: number;
    readonly offset: number;
  };
}

/**
 * Task update payload for backend PATCH operations
 */
export interface TaskUpdate {
  /** Backend status (explicit 'failed' for failures, not 'completed' with error_message) */
  status?: BackendTaskStatus;
  /** Error message (only for failed/canceled states) */
  error_message?: string | null;
  /** Retry count (incremented on each attempt) */
  retry_count?: number;
}

/**
 * Dependencies interface for TaskSource
 */
export interface TaskSourceDependencies {
  apiClient: Context.Tag.Service<typeof ApiClientService>;
  retryService: Context.Tag.Service<typeof RetryService>;
  timeService: Context.Tag.Service<typeof TimeService>;
}

/**
 * Task Source
 * Provides task state management and backend synchronization
 * Class-based implementation with dependency injection
 *
 * Backend State Mapping (CANONICAL):
 * - SDK 'completed' (exitCode 0) → backend status: 'completed', error_message: null
 * - SDK 'failed' (exitCode !== 0) → backend status: 'failed', error_message: <error details>
 * - SDK 'canceled' → backend status: 'canceled', error_message: 'Execution canceled'
 *
 * CRITICAL: Backend MUST use explicit 'failed' status for failures (not 'completed' with error_message)
 */
export class TaskSource {
  private readonly deps: TaskSourceDependencies;
  private readonly serviceLayer: Layer.Layer<RetryService | TimeService>;

  constructor(dependencies: TaskSourceDependencies) {
    this.deps = dependencies;
    // Create service layer once in constructor to avoid repeated allocations
    this.serviceLayer = Layer.mergeAll(
      Layer.succeed(RetryService, this.deps.retryService),
      Layer.succeed(TimeService, this.deps.timeService)
    );
  }

  /**
   * Get the cached service layer for ApiClient calls
   * ApiClient methods require RetryService and TimeService from Effect context
   */
  private getServiceLayer(): Layer.Layer<RetryService | TimeService> {
    return this.serviceLayer;
  }

  /**
   * Enrich error with context while preserving stack traces and original error
   * Preserves the original error's stack trace and sets it as the cause
   *
   * @param context - Context message describing the operation that failed
   * @param error - The original error (can be Error instance or unknown)
   * @returns Enriched Error with preserved stack trace and cause
   */
  private enrichError(context: string, error: unknown): Error {
    if (error instanceof Error) {
      const enriched = new Error(`${context}: ${error.message}`);
      if (error.stack !== undefined) {
        enriched.stack = error.stack;
      }
      enriched.cause = error;
      return enriched;
    }
    return new Error(`${context}: ${String(error)}`);
  }

  /**
   * Fetch pending and in-progress tasks for a given issue.
   * Includes in-progress tasks to allow resuming stopped tasks.
   * Tasks are ordered by status (in_progress first) then position ASC.
   *
   * @param issueId - Issue identifier
   * @returns Task summaries with status 'pending' or 'in_progress'
   */
  listPending(issueId: string): Effect.Effect<TaskSummary[], Error> {
    return this.deps.apiClient.fetchPendingTasks(issueId).pipe(
      Effect.provide(this.getServiceLayer()),
      Effect.mapError((error): Error => this.enrichError("Failed to list pending tasks", error))
    );
  }

  /**
   * Mark task as in progress (status: 'in_progress')
   * Called when task execution starts
   *
   * @param taskId - Task identifier
   * @returns Effect that succeeds when status is updated
   */
  markInProgress(taskId: string): Effect.Effect<void, Error> {
    return this.deps.apiClient.updateTask(taskId, { status: "in_progress" }).pipe(
      Effect.provide(this.getServiceLayer()),
      Effect.mapError((error): Error => this.enrichError("Failed to mark task in progress", error))
    );
  }

  /**
   * Mark task as completed (status: 'completed', error_message: null)
   * Called when task completes successfully (exitCode 0)
   *
   * @param taskId - Task identifier
   * @returns Effect that succeeds when status is updated
   */
  markCompleted(taskId: string): Effect.Effect<void, Error> {
    return this.deps.apiClient
      .updateTask(taskId, {
        status: "completed",
        error_message: null,
      })
      .pipe(
        Effect.provide(this.getServiceLayer()),
        Effect.mapError((error): Error => this.enrichError("Failed to mark task completed", error))
      );
  }

  /**
   * Mark task as failed with error message (status: 'failed', error_message: <error>)
   * Called when task fails (exitCode !== 0) or times out
   *
   * CRITICAL: Uses explicit 'failed' status, NOT 'completed' with error_message
   *
   * @param taskId - Task identifier
   * @param errorMessage - Error details or timeout message
   * @param retryCount - Number of retry attempts made (optional)
   * @returns Effect that succeeds when status is updated
   */
  markFailed(
    taskId: string,
    errorMessage: string,
    retryCount?: number
  ): Effect.Effect<void, Error> {
    const update: TaskUpdate =
      retryCount !== undefined
        ? {
            status: "failed",
            error_message: errorMessage,
            retry_count: retryCount,
          }
        : {
            status: "failed",
            error_message: errorMessage,
          };

    return this.deps.apiClient.updateTask(taskId, update).pipe(
      Effect.provide(this.getServiceLayer()),
      Effect.mapError((error): Error => this.enrichError("Failed to mark task failed", error))
    );
  }

  /**
   * Mark task as canceled with error message (status: 'canceled', error_message: <message>)
   * Called when task execution is canceled by user
   *
   * @param taskId - Task identifier
   * @param errorMessage - Cancellation message
   * @returns Effect that succeeds when status is updated
   */
  markCanceled(taskId: string, errorMessage: string): Effect.Effect<void, Error> {
    return this.deps.apiClient
      .updateTask(taskId, {
        status: "canceled",
        error_message: errorMessage,
      })
      .pipe(
        Effect.provide(this.getServiceLayer()),
        Effect.mapError((error): Error => this.enrichError("Failed to mark task canceled", error))
      );
  }

  /**
   * Reset failed tasks to pending status for an issue
   * Called when starting a new job to retry previously failed tasks
   *
   * @param issueId - Issue identifier
   * @returns Effect that succeeds with count of tasks reset
   */
  resetFailedTasks(issueId: string): Effect.Effect<{ count: number }, Error> {
    return this.deps.apiClient.resetFailedTasks(issueId).pipe(
      Effect.provide(this.getServiceLayer()),
      Effect.mapError((error): Error => this.enrichError("Failed to reset failed tasks", error))
    );
  }
}

/**
 * Map SDK state to backend status
 * Ensures consistent state mapping across the SDK
 *
 * SDK States → Backend Status Mapping:
 * - 'completed' → 'completed' (success, no error_message)
 * - 'failed' → 'failed' (explicit failure status with error_message)
 * - 'canceled' → 'canceled' (user-initiated cancellation)
 *
 * @param sdkState - SDK execution state from state machine
 * @returns Backend task status
 */
export function mapSdkStateToBackendStatus(
  sdkState: "completed" | "failed" | "canceled"
): BackendTaskStatus {
  switch (sdkState) {
    case "completed":
      return "completed";
    case "failed":
      return "failed";
    case "canceled":
      return "canceled";
  }
}

/**
 * Build error message for backend based on SDK state
 * Provides clear error messages for different failure scenarios
 *
 * @param sdkState - SDK execution state from state machine
 * @param lastError - Last error from execution context (optional)
 * @param lastExitCode - Last exit code from execution context (optional)
 * @returns Error message string or null for successful completion
 */
export function buildErrorMessage(
  sdkState: "completed" | "failed" | "canceled",
  lastError?: Error,
  lastExitCode?: number
): string | null {
  switch (sdkState) {
    case "completed":
      // Success: no error message
      return null;
    case "canceled":
      // Cancellation: generic message
      return "Execution canceled by user";
    case "failed":
      // Failure: use lastError message if available, otherwise generic with exit code
      return lastError?.message || `Task failed with exit code ${lastExitCode ?? -1}`;
  }
}
