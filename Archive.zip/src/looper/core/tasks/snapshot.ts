import { compact } from "es-toolkit/array";
import type { UIMessage } from "ai";
import type { TaskSuccess } from "./runner";
import type { ExecutionSnapshot, SnapshotMessage } from "./types";

type TextPart = { text?: string; content?: string };

type MessageWithParts = UIMessage & {
  parts?: TextPart[];
  content?: unknown;
  role?: string;
};

function toSnapshotMessage(message: UIMessage): SnapshotMessage {
  const withParts = message as MessageWithParts;
  const content = (() => {
    if (typeof withParts.content === "string") {
      return withParts.content;
    }

    if (Array.isArray(withParts.parts)) {
      const lines = compact(
        withParts.parts.map(part => {
          if (typeof part === "object" && part !== null) {
            const candidate = part as { text?: unknown; content?: unknown };
            if (typeof candidate.text === "string") return candidate.text;
            if (typeof candidate.content === "string") return candidate.content;
          }
          return undefined;
        })
      );

      return lines.join("\n");
    }

    return "";
  })();

  return {
    role: withParts.role ?? "assistant",
    content,
  };
}

export function collectSnapshot(result: TaskSuccess): ExecutionSnapshot {
  const lastMessages = result.chatHistory.slice(-10).map(toSnapshotMessage);

  const snapshot: ExecutionSnapshot = {
    summary: result.summary ?? "",
    lastMessages,
    exitCode: result.exitCode,
    ...(result.artifacts ? { artifacts: result.artifacts } : {}),
    chatHistory: result.chatHistory,
  };

  return snapshot;
}
