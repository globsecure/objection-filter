/**
 * Retry Helpers
 * Utility functions for retry context and prompt modification
 */

import type { RetryContext } from "@compozy/prompts/built-in";

/**
 * Append retry context to user prompt
 * Only modifies user prompt, system prompt remains unchanged
 */
export function appendRetryContext(prompt: string, context: RetryContext): string {
  const status = "failure";
  const errorSection = context.error
    ? `\n  <error><![CDATA[${context.error.message}]]></error>`
    : "";
  const exitCodeSection =
    context.exitCode !== undefined ? `\n  <exit_code>${context.exitCode}</exit_code>` : "";

  const retrySection = `
<previous_attempt_context>
  <attempt>${context.attempt}</attempt>
  <next_attempt>${context.attempt + 1}</next_attempt>
  <status>${status}</status>${errorSection}${exitCodeSection}
  <message>This is a restart (attempt ${context.attempt + 1}). Analyze the previous attempt's failure and resolve the issue before continuing the task.</message>
</previous_attempt_context>`;

  return `${prompt}\n${retrySection}`;
}
