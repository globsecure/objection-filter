/**
 * Electron Integration Module
 * IPC contract, preload bridge, and main process handlers for secure communication
 */

export type {
  IssueContext,
  JobStatus,
  LooperAPI,
  LooperIPCContract,
  RunnerOptions,
} from "./ipc-contract";

export {
  IpcValidatorService,
  IpcValidatorLayer,
  IpcValidatorServiceLive,
  IpcValidatorServiceTest,
  type IpcValidatorServiceType,
} from "./services/ipc-validator";

export { createLooperAPI } from "./preload";

export { JobManager, IPCRegister, SDKLifecycleManager } from "./main";
