/**
 * IPC Contract for Electron Communication
 * Typed contract for secure IPC between main and renderer processes
 */

import { Provider, type OptionsForId } from "../providers/types";

/**
 * Job status information exposed to renderer
 */
export interface JobStatus {
  issueId: string;
  state: "idle" | "running" | "completed" | "failed" | "canceled" | "interrupted";
  currentTask?: {
    id: string;
    attempt: number;
    maxAttempts: number;
  };
  progress: {
    completed: number;
    total: number;
  };
  /** Error message when job has failed */
  error?: string;
}

/**
 * Terminal job states represent an execution that is no longer running.
 * Note: "interrupted" is terminal (the job ended due to restart/crash) but can be restartable.
 */
export const TERMINAL_JOB_STATES = ["completed", "failed", "canceled", "interrupted"] as const;

export type TerminalJobState = (typeof TERMINAL_JOB_STATES)[number];

export function isTerminalJobState(state: JobStatus["state"]): state is TerminalJobState {
  return (
    state === "completed" || state === "failed" || state === "canceled" || state === "interrupted"
  );
}

/**
 * Issue context data for prompt building
 * Contains artifact file paths to provide implementation context
 */
export interface IssueContext {
  /** PRD markdown file path (null when unavailable) */
  prdPath: string | null;
  /** Technical specification markdown file path (null when unavailable) */
  techspecPath: string | null;
  /** Issue context markdown file path (null when unavailable) */
  issueContextPath: string | null;
  /** Tasks directory path (null when unavailable) */
  tasksDirPath: string | null;
}

/**
 * Runner options for starting a looper execution
 */
export interface RunnerOptions<TId extends Provider = Provider> {
  executorId: TId;
  options: OptionsForId<TId>;
  maxRetries?: number;
  customSystemPrompt?: string;
  issueContext?: IssueContext;
}

/**
 * Internal IPC contract interface
 * Maps directly to Electron IPC channel names for type safety
 * @internal Use LooperAPI for public API access
 */
export interface LooperIPCContract {
  /**
   * Start looper execution for an issue
   * @returns Promise with success status and job ID
   */
  "looper:start": (
    issueId: string,
    opts: RunnerOptions
  ) => Promise<{ success: boolean; jobId: string; error?: string }>;

  /**
   * Cancel execution (graceful shutdown)
   */
  "looper:cancel": (issueId: string) => Promise<void>;

  /**
   * Get current job status
   */
  "looper:status": (issueId: string) => Promise<JobStatus>;

  /**
   * Save API key to secure storage (encrypted electron-store)
   * Handled by Electron main process using AES-256 encryption with build-time key
   * @param apiKey - API key to save (must have "compozy_" prefix)
   * @returns Promise with success status and optional error message
   */
  saveApiKey: (params: { apiKey: string }) => Promise<{ success: boolean; error?: string }>;

  /**
   * Get API key status from secure storage
   * @returns Promise with key existence and validity status
   */
  getApiKeyStatus: () => Promise<{ hasKey: boolean; isValid: boolean }>;

  /**
   * Check if API key exists in secure storage
   * @returns Promise with key existence status
   */
  hasApiKey: () => Promise<{ hasKey: boolean }>;

  /**
   * Get the stored API key value from secure storage.
   *
   * IMPORTANT: This is intended for Electron renderer authentication where the
   * renderer must attach `x-api-key` to HTTP requests. Treat this as sensitive data.
   * API key is stored using encrypted electron-store (AES-256 encryption with build-time key).
   *
   * @returns Promise with the API key (or null if missing/unreadable/expired)
   */
  getApiKey: () => Promise<{ apiKey: string | null }>;

  /**
   * Delete API key from secure storage (encrypted electron-store)
   * Removes the encrypted API key data and clears in-memory references
   * Used during sign out to ensure complete cleanup
   * @returns Promise with success status and optional error message
   */
  deleteApiKey: () => Promise<{ success: boolean; error?: string }>;
}

/**
 * Public API interface for Looper SDK
 * Provides clean camelCase method names for better developer experience
 */
export interface LooperAPI {
  /**
   * Start looper execution for an issue
   * @param issueId - Issue identifier
   * @param opts - Runner options
   * @returns Promise with success status and job ID
   */
  start(
    issueId: string,
    opts: RunnerOptions
  ): Promise<{ success: boolean; jobId: string; error?: string }>;

  /**
   * Cancel execution (graceful shutdown)
   * @param issueId - Issue identifier
   */
  cancel(issueId: string): Promise<void>;

  /**
   * Get current job status
   * @param issueId - Issue identifier
   * @returns Promise with job status information
   */
  status(issueId: string): Promise<JobStatus>;

  /**
   * Setup listener for status update events (via IPC events)
   * Status updates are emitted via channel: looper:status:{issueId}
   *
   * IMPORTANT: The returned disposer function MUST be called to prevent
   * memory leaks. Call it when you no longer need status updates, or when
   * the job reaches a terminal state (completed/failed/canceled/interrupted).
   *
   * @param issueId - Issue identifier
   * @returns Disposer function to remove the listener - MUST be called to prevent memory leaks
   *
   * @example
   * ```typescript
   * const dispose = window.looper.statusUpdates("123e4567-e89b-12d3-a456-426614174000");
   * // ... listen for events ...
   * dispose(); // Clean up when done
   * ```
   */
  statusUpdates(issueId: string): () => void;

  /**
   * Save API key to secure storage (encrypted electron-store)
   * Handled by Electron main process using AES-256 encryption with build-time key
   * @param apiKey - API key to save (must have "compozy_" prefix)
   * @returns Promise with success status and optional error message
   */
  saveApiKey(apiKey: string): Promise<{ success: boolean; error?: string }>;

  /**
   * Get API key status from secure storage
   * @returns Promise with key existence and validity status
   */
  getApiKeyStatus(): Promise<{ hasKey: boolean; isValid: boolean }>;

  /**
   * Check if API key exists in secure storage
   * @returns Promise with key existence status
   */
  hasApiKey(): Promise<{ hasKey: boolean }>;

  /**
   * Get the stored API key value from secure storage.
   *
   * Used by Electron renderer to authenticate against the backend via `x-api-key`.
   * API key is stored using encrypted electron-store (AES-256 encryption with build-time key).
   *
   * @returns Promise with the API key (or null if missing/unreadable/expired)
   */
  getApiKey(): Promise<{ apiKey: string | null }>;

  /**
   * Delete API key from secure storage (encrypted electron-store)
   * Removes the encrypted API key data and clears in-memory references
   * Used during sign out to ensure complete cleanup
   * @returns Promise with success status and optional error message
   */
  deleteApiKey(): Promise<{ success: boolean; error?: string }>;
}
