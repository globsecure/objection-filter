/**
 * Preload Bridge for Electron IPC
 * Secure, minimal surface bridge between main and renderer processes
 */

import type { IpcRendererEvent } from "electron";
import type { JobStatus, LooperAPI, RunnerOptions } from "./ipc-contract";
import { getLogger } from "@logtape/logtape";
import { invokeIpc, IpcInvokeError } from "../../shared/ipc-client";

const logger = getLogger(["looper", "preload"]);

// Declare window for preload context (which has access to both Node and DOM APIs)
declare const window: {
  dispatchEvent(event: Event): boolean;
};

type LooperEventType = `looper:status:${string}`;

const createLooperEvent = <TDetail>(type: LooperEventType, detail: TDetail): Event => {
  if (typeof CustomEvent === "function") {
    return new CustomEvent(type, { detail });
  }

  if (typeof Event === "function") {
    const fallback = new Event(type) as CustomEvent<TDetail>;
    Object.defineProperty(fallback, "detail", {
      value: detail,
      enumerable: true,
    });
    return fallback;
  }

  return { type, detail } as unknown as Event;
};

const dispatchLooperEvent = <TDetail>(type: LooperEventType, detail: TDetail): void => {
  if (typeof window === "undefined" || typeof window.dispatchEvent !== "function") {
    return;
  }

  window.dispatchEvent(createLooperEvent(type, detail));
};

type IpcRenderer = {
  invoke(channel: string, ...args: unknown[]): Promise<unknown>;
  on(channel: string, listener: (event: IpcRendererEvent, ...args: unknown[]) => void): void;
  removeListener(
    channel: string,
    listener: (event: IpcRendererEvent, ...args: unknown[]) => void
  ): void;
  removeAllListeners(channel?: string): void;
};

/**
 * Creates the start handler with error handling and logging
 */
const createStartHandler = (ipcRenderer: IpcRenderer): LooperAPI["start"] => {
  return (issueId: string, opts: RunnerOptions) => {
    logger.info("start called with:", { issueId, opts });
    try {
      logger.info("Calling ipcRenderer.invoke('looper:start', ...)");
      const promise = ipcRenderer.invoke("looper:start", issueId, opts) as Promise<{
        success: boolean;
        jobId: string;
        error?: string;
      }>;
      logger.info("IPC invoke promise created, awaiting result...");
      return promise.then(
        result => {
          logger.info("IPC invoke succeeded:", { result });
          return result;
        },
        error => {
          logger.error("IPC invoke failed:", { error });
          throw error;
        }
      );
    } catch (error) {
      logger.error("Error in start function:", { error });
      throw error;
    }
  };
};

/**
 * Creates API key handlers
 */
const createApiKeyHandlers = (ipcRenderer: IpcRenderer) => ({
  saveApiKey: async (apiKey: string) => {
    try {
      await invokeIpc<null>(ipcRenderer, "saveApiKey", { apiKey });
      return { success: true };
    } catch (error) {
      const message = error instanceof IpcInvokeError ? error.message : String(error);
      return { success: false, error: message };
    }
  },
  getApiKey: () => {
    return invokeIpc<{ apiKey: string | null }>(ipcRenderer, "getApiKey");
  },
  getApiKeyStatus: () => {
    return invokeIpc<{ hasKey: boolean; isValid: boolean }>(ipcRenderer, "getApiKeyStatus");
  },
  hasApiKey: async () => {
    try {
      return await invokeIpc<{ hasKey: boolean }>(ipcRenderer, "hasApiKey");
    } catch (error) {
      if (error instanceof IpcInvokeError && error.message.includes("Object has been destroyed")) {
        logger.warn("Skipping hasApiKey IPC call because the renderer was destroyed.");
        return { hasKey: false };
      }
      throw error;
    }
  },
  deleteApiKey: async () => {
    try {
      await invokeIpc<null>(ipcRenderer, "deleteApiKey");
      return { success: true };
    } catch (error) {
      const message = error instanceof IpcInvokeError ? error.message : String(error);
      return { success: false, error: message };
    }
  },
});

/**
 * Creates the Looper API for the renderer process
 * This function is meant to be called in the preload script with contextBridge
 *
 * @example
 * ```ts
 * // In preload script
 * import { contextBridge, ipcRenderer } from 'electron';
 * import { createLooperAPI } from '@looper/electron';
 *
 * contextBridge.exposeInMainWorld('looper', createLooperAPI(ipcRenderer));
 * ```
 */
export function createLooperAPI(ipcRenderer: IpcRenderer): LooperAPI {
  logger.info("createLooperAPI called - building API with new logging");
  // Create functions directly to ensure proper binding through contextBridge
  // contextBridge requires functions to be created in a way that preserves their closure
  const apiKeyHandlers = createApiKeyHandlers(ipcRenderer);
  return {
    start: createStartHandler(ipcRenderer),
    cancel: (issueId: string) => {
      return ipcRenderer.invoke("looper:cancel", issueId) as Promise<void>;
    },
    status: (issueId: string) => {
      return ipcRenderer.invoke("looper:status", issueId) as Promise<JobStatus>;
    },
    /**
     * Setup listener for status update events (via IPC events)
     * Status updates are emitted via channel: looper:status:{issueId}
     *
     * IMPORTANT: The returned disposer function MUST be called to prevent
     * memory leaks. Call it when you no longer need status updates, or when
     * the job reaches a terminal state (completed/failed).
     *
     * @param issueId - Issue identifier
     * @returns Disposer function to remove the listener - MUST be called to prevent memory leaks
     *
     * @example
     * ```typescript
     * const dispose = window.looper.statusUpdates("123e4567-e89b-12d3-a456-426614174000");
     * // ... listen for events ...
     * dispose(); // Clean up when done
     * ```
     */
    statusUpdates: (issueId: string) => {
      const channel = `looper:status:${issueId}`;
      // Remove all existing listeners for this channel to prevent accumulation
      ipcRenderer.removeAllListeners(channel);
      const listener = (_event: IpcRendererEvent, ...args: unknown[]) => {
        const status = args[0] as JobStatus;
        dispatchLooperEvent(`looper:status:${issueId}`, status);
      };
      ipcRenderer.on(channel, listener);
      return () => {
        ipcRenderer.removeListener(channel, listener);
      };
    },
    ...apiKeyHandlers,
  };
}

/**
 * Type augmentation for window object with looper API
 * Add this to your renderer's global types:
 *
 * @example
 * ```ts
 * // In renderer global.d.ts
 * import type { LooperAPI } from '@looper/electron';
 *
 * declare global {
 *   interface Window {
 *     looper: LooperAPI;
 *   }
 * }
 * ```
 */
declare global {
  interface WindowEventMap {
    // Status events are per-issue: looper:status:${issueId}
    [key: `looper:status:${string}`]: CustomEvent<JobStatus>;
  }
}
