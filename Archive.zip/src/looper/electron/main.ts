import { createLoggerConfig } from "@shared";
import type { ApiKeyProviderRef } from "@shared/api-key-provider";
import { configure, getLogger, type Logger } from "@logtape/logtape";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import type * as Runtime from "effect/Runtime";
import fixPath from "fix-path";
import {
  FileSystemLayer,
  IpcService,
  ProcessLayer,
  RetryLayerWithTime,
  SignalLayer,
  SignalService,
  TaskSourceServiceLive,
  TaskTelemetryServiceLive,
  TimeLayer,
  makeApiClientLayer,
} from "../core/layers";
import { serverConfig } from "./config/server-config";
import { HonoServerService } from "./services/hono-server";
import { IPCRegister } from "./services/ipc-register";
import { JobManager } from "./services/job-manager";
import { SDKLifecycleManager } from "./services/sdk-lifecycle-manager";

// Re-export services for backward compatibility
export { IPCRegister } from "./services/ipc-register";
export { JobManager } from "./services/job-manager";
export { SDKLifecycleManager } from "./services/sdk-lifecycle-manager";

/**
 * Configuration options for LooperSDK initialization
 */
export interface LooperSDKOptions {
  /**
   * Optional custom layers to use instead of default layers
   */
  layers?: Layer.Layer<any>;

  /**
   * Backend base URL for API client
   * @default "http://localhost:3002"
   */
  backendBaseUrl?: string;

  /**
   * Skip job recovery on startup.
   *
   * Intended for tests that want to assert "pre-recovery" SQLite state or to
   * simulate recovery failures without mutating persisted rows.
   *
   * @default false
   */
  skipJobRecovery?: boolean;

  /**
   * API key provider ref (in-memory, reactive)
   * Required for API authentication. Must reflect updates immediately.
   */
  apiKeyRef: ApiKeyProviderRef;

  /**
   * Optional error capture function for Sentry integration
   * Called when errors occur during SDK initialization or operation
   */
  captureException?: (error: unknown, context?: Record<string, unknown>) => void;
}

/**
 * Main class for Looper SDK
 * Encapsulates all SDK initialization and lifecycle management
 */
export class LooperSDK {
  private readonly logger: Logger;
  private honoServer: HonoServerService | null = null;
  private captureException?: (error: unknown, context?: Record<string, unknown>) => void;

  constructor() {
    this.logger = getLogger(["looper", "electron"]);
  }

  /**
   * Initialize the Looper SDK with Electron IPC and window
   * This is the main entry point for setting up the SDK
   */
  initialize(
    ipcMain: Electron.IpcMain,
    mainWindow: Electron.BrowserWindow,
    options: LooperSDKOptions
  ): Effect.Effect<void, Error> {
    const ipcLayer = IPCRegister.createIpcLayer(mainWindow);
    if (options.captureException) {
      this.captureException = options.captureException;
    }

    return Effect.sync(() => {
      // API key handlers are now registered in Electron main process, not here
    }).pipe(
      Effect.flatMap(() => this.fixPathForElectron()),
      Effect.flatMap(() => this.configureLogger()),
      Effect.flatMap(() => this.setupApplicationLayers(ipcLayer, options)),
      Effect.flatMap(applicationSetup =>
        this.initializeSDKLifecycleManager(ipcMain, applicationSetup).pipe(
          Effect.flatMap(({ sdkLifecycleManager, jobManager, runtime }) =>
            this.setupIpcRegister(
              ipcMain,
              mainWindow,
              applicationSetup,
              sdkLifecycleManager,
              jobManager
            ).pipe(
              Effect.flatMap(() =>
                this.initializeSignalHandlers(applicationSetup.layers, sdkLifecycleManager)
              ),
              // Hono server is optional (used for streaming/log endpoints). If it fails to start,
              // we still want IPC handlers to be available so the app can function.
              Effect.flatMap(() => this.startHonoServer(runtime, jobManager)),
              Effect.tap(() =>
                Effect.sync(() => {
                  this.logger.info("=== Looper SDK initialized successfully ===");
                })
              )
            )
          )
        )
      ),
      Effect.catchAll(error => {
        // Capture initialization errors in Sentry
        if (this.captureException) {
          this.captureException(error, {
            source: "looper_sdk_initialization",
            component: "LooperSDK",
          });
        }
        return Effect.fail(error);
      })
    );
  }

  /**
   * Start the embedded Hono server (best-effort).
   *
   * IPC handlers must remain available even if the HTTP server cannot bind
   * (e.g. port already in use in dev).
   */
  private startHonoServer(
    runtime: Runtime.Runtime<any>,
    jobManager: JobManager
  ): Effect.Effect<void, never> {
    const logger = this.logger;
    const sdk = this;

    return Effect.gen(function* () {
      const honoServer = new HonoServerService({
        jobManager,
        logger,
      });

      yield* honoServer.start(runtime);

      yield* Effect.sync(() => {
        sdk.honoServer = honoServer;
        logger.info(`Hono server running on port ${honoServer.getPort()}`);
      });
    }).pipe(
      Effect.catchAll(error =>
        Effect.sync(() => {
          logger.warn("Failed to start Hono server; continuing without HTTP streaming", {
            error: error instanceof Error ? error.message : String(error),
          });
          // Capture error in Sentry if available
          if (sdk.captureException) {
            sdk.captureException(error, {
              source: "hono_server_start",
              component: "LooperSDK",
            });
          }
        })
      ),
      Effect.asVoid
    );
  }

  /**
   * Shutdown any long-lived services started during initialize.
   * Currently stops the embedded Hono server.
   */
  shutdown(): Effect.Effect<void, never> {
    const server = this.honoServer;
    if (!server) return Effect.void;
    return server.stop().pipe(
      Effect.tap(() =>
        Effect.sync(() => {
          this.honoServer = null;
        })
      )
    );
  }

  /**
   * Fix PATH environment variable for Electron
   * Electron doesn't inherit the user's shell PATH by default
   */
  private fixPathForElectron(): Effect.Effect<void, never> {
    return Effect.sync(() => {
      try {
        fixPath();
        this.logger.info("PATH fixed for Electron environment");
      } catch (error) {
        this.logger.warn("Failed to fix PATH, Claude SDK may not find CLI executable", {
          error: error instanceof Error ? error.message : String(error),
        });
      }
    });
  }

  /**
   * Configure LogTape logger with categories
   */
  private configureLogger(): Effect.Effect<void, never> {
    return Effect.promise(() =>
      configure(
        createLoggerConfig({
          categories: [
            { category: ["looper", "electron"] },
            { category: ["looper", "orchestrator"] },
            { category: ["looper", "preload"] },
          ],
        })
      )
    );
  }

  /**
   * Setup application layers with optional custom layers
   */
  private setupApplicationLayers(
    ipcLayer: Layer.Layer<IpcService>,
    options: LooperSDKOptions
  ): Effect.Effect<{ layers: Layer.Layer<any> }, Error> {
    return this.buildApplicationLayers(ipcLayer, options.backendBaseUrl, options.apiKeyRef).pipe(
      Effect.map(builtSetup => {
        const layers = options.layers
          ? // Merge default layers with caller overrides (right-biased), so
            // essential infrastructure (like TaskTelemetryServiceLive) always takes precedence.
            Layer.merge(options.layers, builtSetup.layers)
          : builtSetup.layers;
        return { layers };
      })
    );
  }

  /**
   * Initialize SDK lifecycle manager with runtime and IPC
   */
  private initializeSDKLifecycleManager(
    ipcMain: Electron.IpcMain,
    applicationSetup: { layers: Layer.Layer<any> }
  ): Effect.Effect<
    {
      sdkLifecycleManager: SDKLifecycleManager;
      jobManager: JobManager;
      runtime: Runtime.Runtime<any>;
    },
    Error
  > {
    const logger = this.logger;
    return Effect.gen(function* () {
      const runtime = yield* Effect.runtime<any>();

      // Job persistence is scoped per repository (workingDirectory) and initialized lazily
      // when jobs start. Avoid using process.cwd() for a "default" repository at app startup.
      //
      // Tests can still inject a repository directly via JobManagerOptions when needed.
      const jobManager = new JobManager({ logger });
      const sdkLifecycleManager = new SDKLifecycleManager({
        jobManager,
        logger,
      });

      yield* sdkLifecycleManager.setIpcMain(ipcMain);
      yield* sdkLifecycleManager.setRuntime(runtime);
      logger.info("Runtime created and stored");

      return { sdkLifecycleManager, jobManager, runtime };
    }).pipe(Effect.provide(applicationSetup.layers));
  }

  /**
   * Setup IPC register with handlers
   */
  private setupIpcRegister(
    ipcMain: Electron.IpcMain,
    mainWindow: Electron.BrowserWindow,
    applicationSetup: { layers: Layer.Layer<any> },
    sdkLifecycleManager: SDKLifecycleManager,
    jobManager: JobManager
  ): Effect.Effect<void, Error> {
    const ipcRegister = new IPCRegister({
      jobManager,
      sdkLifecycleManager,
      logger: this.logger,
    });

    const logger = this.logger;

    // TaskSourceService is provided via layers, no manual creation needed
    return ipcRegister
      .setup(ipcMain, mainWindow, applicationSetup.layers)
      .pipe(Effect.tap(() => Effect.sync(() => logger.info("IPC handlers registered"))));
  }

  /**
   * Initialize signal handlers for graceful shutdown
   */
  private initializeSignalHandlers(
    layers: Layer.Layer<any>,
    sdkLifecycleManager: SDKLifecycleManager
  ): Effect.Effect<void, Error> {
    return this.registerSignalHandlers(layers, sdkLifecycleManager).pipe(
      Effect.catchAll(error => {
        this.logger.info(`Signal handler registration skipped: ${String(error)}`);
        // Capture error in Sentry if available
        if (this.captureException) {
          this.captureException(error, {
            source: "signal_handler_registration",
            component: "LooperSDK",
          });
        }
        return Effect.sync(() => {
          // Signal handler registration failure is non-fatal
        });
      })
    );
  }

  /**
   * Build all application layers including dependencies and service layers
   * Uses proper Effect-TS service pattern with no Effect.runSync
   */
  public buildApplicationLayers(
    ipcLayer: Layer.Layer<IpcService>,
    backendBaseUrl: string | undefined,
    apiKeyRef: ApiKeyProviderRef
  ): Effect.Effect<{ layers: Layer.Layer<any> }, Error> {
    return Effect.sync(() => {
      const baseUrl = backendBaseUrl ?? serverConfig.backendUrl;

      // Create base layers (without services)
      const baseLayers = Layer.mergeAll(
        FileSystemLayer,
        ProcessLayer,
        TimeLayer,
        RetryLayerWithTime,
        SignalLayer,
        ipcLayer
      );

      // TaskTelemetryService is required by the embedded Hono server (telemetry endpoint) and
      // by the orchestrator/executor pipeline. The default TaskTelemetryLayer is a mock; in
      // Electron we explicitly provide the live implementation.
      const telemetryLive = TaskTelemetryServiceLive.pipe(Layer.provide(baseLayers));

      // Create ApiClient service layer with dynamic key
      // makeApiClientLayer includes RetryService and TimeService internally
      const apiClientLayerWithDeps = makeApiClientLayer({ baseUrl, apiKeyRef });

      // Create TaskSource service layer (depends on ApiClientService)
      // TaskSourceService requires ApiClientService
      const taskSourceLayerWithDeps = TaskSourceServiceLive.pipe(
        Layer.provide(apiClientLayerWithDeps)
      );

      // Combine all layers - all dependencies are satisfied
      const allLayers = Layer.mergeAll(
        baseLayers,
        apiClientLayerWithDeps,
        taskSourceLayerWithDeps,
        telemetryLive
      ) as Layer.Layer<any>;

      return { layers: allLayers };
    });
  }

  /**
   * Register signal handlers for graceful shutdown
   * Uses Effect.scoped to provide Scope for automatic cleanup
   */
  private registerSignalHandlers(
    allLayers: Layer.Layer<any>,
    sdkLifecycleManager: SDKLifecycleManager
  ): Effect.Effect<void, Error> {
    const logger = this.logger;
    return Effect.scoped(
      Effect.gen(function* () {
        const signalService = yield* SignalService;
        yield* signalService.onSigterm(() =>
          wrapShutdownSequence("SIGTERM", allLayers, sdkLifecycleManager)
        );
        yield* signalService.onSigint(() =>
          wrapShutdownSequence("SIGINT", allLayers, sdkLifecycleManager)
        );
        yield* signalService.onSigbreak(() =>
          wrapShutdownSequence("SIGBREAK", allLayers, sdkLifecycleManager)
        );
        logger.info("Signal handlers registered (SIGTERM, SIGINT, SIGBREAK)");
      }).pipe(Effect.provide(allLayers))
    );
  }
}

/**
 * Wrap shutdown sequence for signal handling
 */
const wrapShutdownSequence = (
  label: string,
  allLayers: Layer.Layer<any>,
  sdkLifecycleManager: SDKLifecycleManager
) => {
  const logger = getLogger(["looper", "electron"]);

  return Effect.gen(function* () {
    logger.info(`Received ${label} signal`);
    yield* sdkLifecycleManager.gracefulShutdown();
  }).pipe(
    Effect.provide(allLayers),
    Effect.catchAll(error =>
      Effect.gen(function* () {
        logger.error(`Graceful shutdown error: ${String(error)}`);
        yield* sdkLifecycleManager.forceShutdown();
      })
    )
  );
};
