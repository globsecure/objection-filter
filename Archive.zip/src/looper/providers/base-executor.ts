/**
 * BaseExecutor - Abstract base class for all executor implementations
 * Provides common functionality like session management and chat history persistence
 */

import type { UIMessage } from "ai";
import { Effect, Option, Ref, Stream } from "effect";
import { flatten } from "es-toolkit/array";
import {
  createSqliteMessageRepositoryForWorkingDirectory,
  createSqliteSessionRepositoryForWorkingDirectory,
  type PaginatedMessages,
  type SqliteMessageRepository,
  type SqliteSessionRepository,
} from "../sqlite";
import type { Capabilities, Executor, Provider, ProviderOptsBase, RunInput } from "./types";

/**
 * Abstract base class for executor implementations
 * Provides session management and chat history persistence.
 *
 * @template TOptions - Executor-specific options that extend ExecutorOptionsBase
 * @template TMessage - Executor-specific stream message type (e.g., ClaudeStreamChunk)
 * @template TPersistedMessage - Executor-specific persisted message type (e.g., UIMessage), defaults to TMessage
 */
export abstract class BaseExecutor<
  TOptions extends ProviderOptsBase,
  TMessage = unknown,
  TPersistedMessage = TMessage,
> implements Executor<TOptions, TMessage> {
  protected currentSessionId: string | undefined;
  protected sessionRepository!: SqliteSessionRepository;
  protected messageRepository!: SqliteMessageRepository;
  private readonly persistedMessageCounts = new Map<string, number>();
  protected readonly workingDirectory: string;

  /**
   * Create a new executor
   *
   * @param workingDirectory - The working directory for the task, used for chat history and session persistence.
   */
  constructor(workingDirectory: string) {
    this.workingDirectory = workingDirectory;
  }

  /**
   * Build and initialize the executor
   * This method must be called after construction to complete async initialization
   * @returns Effect that resolves to the initialized executor
   */
  build(): Effect.Effect<this, Error> {
    const self = this;
    return Effect.gen(function* () {
      self.sessionRepository = yield* Effect.tryPromise({
        try: () => createSqliteSessionRepositoryForWorkingDirectory(self.workingDirectory),
        catch: error => (error instanceof Error ? error : new Error(String(error))),
      });
      self.messageRepository = yield* Effect.tryPromise({
        try: () => createSqliteMessageRepositoryForWorkingDirectory(self.workingDirectory),
        catch: error => (error instanceof Error ? error : new Error(String(error))),
      });
      return self;
    });
  }

  /** Executor identifier (e.g., "claude") */
  abstract readonly id: Provider;

  /** Executor capabilities descriptor */
  abstract readonly capabilities: Capabilities;

  /**
   * Execute a prompt and stream messages
   * Delegates to concrete implementation's executeRun method
   *
   * @param input - Run input with prompt components
   * @param options - Executor-specific options
   * @returns Stream of messages
   */
  run(input: RunInput, options: TOptions): Stream.Stream<TMessage, Error, any> {
    return Stream.unwrapScoped(
      this.prepareForRun(options).pipe(Effect.map(() => this.executeRun(input, options)))
    );
  }

  private prepareForRun(options: TOptions): Effect.Effect<void, Error> {
    const taskId = options.taskId;
    const resetSession = Boolean(options.resetSession);

    if (!taskId) {
      return Effect.void;
    }

    const executor = this;
    return Effect.gen(function* () {
      if (resetSession) {
        yield* executor.clearSessionIdOnly(taskId);
        return;
      }

      const sessionId = yield* executor.loadSessionId(taskId);
      if (sessionId) {
        executor.currentSessionId = sessionId;
      }
    });
  }

  /**
   * Abstract method that concrete executors must implement
   * Contains the executor-specific execution logic
   *
   * @param input - Run input with prompt components
   * @param options - Executor-specific options
   * @returns Stream of messages
   */
  protected abstract executeRun(
    input: RunInput,
    options: TOptions
  ): Stream.Stream<TMessage, Error, any>;

  /**
   * Get current session ID if executor supports session management
   *
   * @returns Session ID or undefined if no session exists
   */
  getSessionId(): string | undefined {
    return this.currentSessionId;
  }

  /**
   * Load session ID for a given task from the session store
   *
   * @param taskId - Task identifier for session lookup
   * @returns Effect that resolves to session ID or undefined
   */
  protected loadSessionId(taskId: string): Effect.Effect<string | undefined, never> {
    return this.sessionRepository.getSessionId(taskId).pipe(
      Effect.map(option => Option.getOrUndefined(option)),
      Effect.catchAll(() => Effect.succeed(undefined))
    );
  }

  /**
   * Save session ID if executor supports session management
   *
   * @param taskId - Task identifier for session lookup
   * @param sessionId - Session ID to store
   * @returns Effect that completes after saving session
   */
  setSessionId(taskId: string, sessionId: string): Effect.Effect<void, Error> {
    this.currentSessionId = sessionId;
    return this.sessionRepository
      .setSessionId(taskId, sessionId)
      .pipe(Effect.mapError(error => new Error(error.message)));
  }

  /**
   * Clears only the persisted session ID for a task, preserving chat history.
   * Used when resetSession=true to start a fresh Claude Code conversation while
   * keeping the message log for history/debugging.
   */
  private clearSessionIdOnly(taskId: string): Effect.Effect<void, never> {
    const executor = this;
    return Effect.gen(function* () {
      // Ensure the next persistence attempt re-syncs counts from SQLite.
      executor.persistedMessageCounts.delete(taskId);

      // Best-effort: resetSession should not fail the run if session cleanup cannot be persisted.
      yield* executor.sessionRepository
        .deleteSession(taskId)
        .pipe(
          Effect.catchAll(error =>
            Effect.zipRight(
              Effect.logWarning(`Failed to delete session for task ${taskId}: ${error.message}`),
              Effect.void
            )
          )
        );

      executor.currentSessionId = undefined;
    });
  }

  /**
   * Clear persisted session and chat history for a task.
   * Ensures local session cache is reset when clearing succeeds.
   */
  clearSession(taskId: string): Effect.Effect<void, Error> {
    const executor = this;
    return Effect.gen(function* () {
      const previousSessionId = yield* executor.loadSessionId(taskId);
      const previousHistory = yield* executor
        .loadHistory(taskId)
        .pipe(Effect.catchAll(() => Effect.succeed<TPersistedMessage[]>([])));

      // Ensure the next persistence attempt re-syncs counts from SQLite.
      executor.persistedMessageCounts.delete(taskId);

      const clearHistory = executor.messageRepository
        .deleteTaskMessages(taskId)
        .pipe(Effect.mapError(error => new Error(error.message)));

      const clearPersistedSession = executor.sessionRepository
        .deleteSession(taskId)
        .pipe(Effect.mapError(error => new Error(error.message)));

      yield* clearHistory.pipe(Effect.zipRight(clearPersistedSession)).pipe(
        Effect.tapError(error =>
          Effect.all(
            [
              previousSessionId ? executor.setSessionId(taskId, previousSessionId) : Effect.void,
              previousHistory.length > 0
                ? executor.persistHistory(taskId, previousHistory)
                : Effect.void,
            ],
            { concurrency: "unbounded" }
          ).pipe(
            Effect.catchAll(() => Effect.void),
            Effect.zipRight(Effect.fail(error))
          )
        )
      );

      executor.currentSessionId = undefined;
    });
  }

  /**
   * Persists the chat history after converting it to the UIMessage format.
   * @param taskId The identifier for the task/chat.
   * @param messages The provider-specific messages to persist.
   * @returns Effect that completes after persisting the chat history.
   */
  protected persistHistory(
    taskId: string,
    messages: TPersistedMessage[]
  ): Effect.Effect<void, Error> {
    const executor = this;
    const uiMessages = executor.toUIMessages(messages);

    return Effect.gen(function* () {
      // Initialize persisted count lazily from SQLite.
      let persistedCount = executor.persistedMessageCounts.get(taskId);
      if (typeof persistedCount !== "number") {
        const count = yield* executor.messageRepository
          .getMessageCount(taskId)
          .pipe(Effect.mapError(error => new Error(error.message)));
        persistedCount = count;
        executor.persistedMessageCounts.set(taskId, persistedCount);
      }

      // If in-memory history is behind (e.g. history is limited), fall back to the DB count.
      if (persistedCount > uiMessages.length) {
        const count = yield* executor.messageRepository
          .getMessageCount(taskId)
          .pipe(Effect.mapError(error => new Error(error.message)));
        persistedCount = count;
        executor.persistedMessageCounts.set(taskId, persistedCount);
      }

      const newMessages = uiMessages.slice(persistedCount);
      if (newMessages.length > 0) {
        yield* executor.messageRepository
          .insertMessages(taskId, newMessages)
          .pipe(Effect.mapError(error => new Error(error.message)));
        persistedCount += newMessages.length;
        executor.persistedMessageCounts.set(taskId, persistedCount);
      }

      // Always update the last message (incremental stream updates reuse IDs).
      const last = uiMessages[uiMessages.length - 1];
      if (last) {
        yield* executor.messageRepository
          .updateMessage(taskId, last.id, last)
          .pipe(Effect.mapError(error => new Error(error.message)));
      }
    });
  }

  /**
   * Loads the chat history and converts it from UIMessage format to the provider-specific format.
   * @param taskId The identifier for the task/chat.
   * @returns Effect that resolves to an array of provider-specific messages.
   */
  protected loadHistory(taskId: string): Effect.Effect<TPersistedMessage[], Error> {
    const executor = this;

    return Effect.gen(function* () {
      const pageLimit = 500;
      const cursorRef = yield* Ref.make<number | undefined>(undefined);
      const pagesRef = yield* Ref.make<UIMessage[][]>([]);

      // Load entire history by paging backwards from the most recent messages.
      // This preserves chronological order and keeps memory usage bounded per page.
      while (true) {
        const cursor = yield* Ref.get(cursorRef);
        const options: { cursor?: number; limit: number; direction: "before" } =
          typeof cursor === "number"
            ? { cursor, limit: pageLimit, direction: "before" }
            : { limit: pageLimit, direction: "before" };

        const page: PaginatedMessages = yield* executor.messageRepository
          .getMessages(taskId, options)
          .pipe(Effect.mapError(error => new Error(error.message)));

        if (page.messages.length === 0) {
          break;
        }

        // Collect pages newest-first, then reverse+flatten once at the end to avoid O(n²) prepends.
        yield* Ref.update(pagesRef, pages => [...pages, [...page.messages]]);

        if (!page.hasMore || page.nextCursor == null) {
          break;
        }

        yield* Ref.set(cursorRef, page.nextCursor);
      }

      const pages = yield* Ref.get(pagesRef);
      const all = flatten([...pages].reverse());
      executor.persistedMessageCounts.set(taskId, all.length);
      return executor.fromUIMessages(all);
    });
  }

  /**
   * Converts provider-specific messages to the UIMessage format for persistence.
   * @param messages An array of provider-specific messages.
   * @returns An array of UIMessages.
   */
  protected abstract toUIMessages(messages: TPersistedMessage[]): UIMessage[];

  /**
   * Converts UIMessages from persistence to the provider-specific message format.
   * @param messages An array of UIMessages.
   * @returns An array of provider-specific messages.
   */
  protected abstract fromUIMessages(messages: UIMessage[]): TPersistedMessage[];
}
