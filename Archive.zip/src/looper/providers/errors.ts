/**
 * Unified Error Taxonomy for Looper SDK
 * All errors use Effect Schema.TaggedError pattern for type-safe, serializable error handling
 */

import * as Schema from "effect/Schema";
import { Provider } from "./types";

/**
 * Error thrown when an executor ID is not found in the registry
 */
export class ExecutorNotFoundError extends Schema.TaggedError<ExecutorNotFoundError>()(
  "ExecutorNotFoundError",
  {
    executorId: Schema.String,
    availableExecutors: Schema.Array(Schema.String),
  }
) {
  get message(): string {
    return `Executor '${this.executorId}' not found. Available executors: ${this.availableExecutors.join(", ")}`;
  }
}

/**
 * Executor execution error
 * Wraps errors from provider-specific execution failures
 */
export class ExecutorError extends Schema.TaggedError<ExecutorError>()("ExecutorError", {
  executorId: Schema.Enums(Provider),
  cause: Schema.Defect,
  exitCode: Schema.optional(Schema.Number),
}) {}

/**
 * Timeout error
 * Thrown when execution exceeds inactivity timeout
 */
export class TimeoutError extends Schema.TaggedError<TimeoutError>()("TimeoutError", {
  timeoutMs: Schema.Number,
  lastActivity: Schema.optional(Schema.DateFromSelf),
}) {}

/**
 * Process execution error
 * Wraps errors from child process execution (CLI adapters)
 */
export class ProcessError extends Schema.TaggedError<ProcessError>()("ProcessError", {
  command: Schema.String,
  args: Schema.Array(Schema.String),
  exitCode: Schema.Number,
  stderr: Schema.optional(Schema.String),
}) {}

/**
 * Backend API error
 * Wraps errors from backend communication
 */
export class BackendError extends Schema.TaggedError<BackendError>()("BackendError", {
  endpoint: Schema.String,
  statusCode: Schema.Number,
  response: Schema.optional(Schema.Unknown),
}) {}

/**
 * Input validation error
 * Thrown when input validation fails
 */
export class ValidationError extends Schema.TaggedError<ValidationError>()("ValidationError", {
  field: Schema.String,
  value: Schema.Unknown,
  message: Schema.String,
}) {}

/**
 * Maps unknown errors to ExecutorError
 */
export const mapExecutorError = (
  error: unknown,
  executorId: Provider,
  exitCode?: number
): ExecutorError => {
  const cause = error instanceof Error ? error : new Error(String(error));
  return new ExecutorError(
    exitCode !== undefined ? { executorId, cause, exitCode } : { executorId, cause }
  );
};

/**
 * Creates ProcessError from process execution failure
 */
export const mapProcessError = (
  command: string,
  args: string[],
  exitCode: number,
  stderr?: string
): ProcessError => {
  return new ProcessError(
    stderr !== undefined ? { command, args, exitCode, stderr } : { command, args, exitCode }
  );
};

/**
 * Creates BackendError from API response
 */
export const mapBackendError = (
  endpoint: string,
  statusCode: number,
  response?: unknown
): BackendError => {
  return new BackendError(
    response !== undefined ? { endpoint, statusCode, response } : { endpoint, statusCode }
  );
};

/**
 * Creates ValidationError from validation failure
 */
export const mapValidationError = (
  field: string,
  value: unknown,
  message: string
): ValidationError => {
  return new ValidationError({ field, value, message });
};

/**
 * Creates TimeoutError from timeout event
 */
export const mapTimeoutError = (timeoutMs: number, lastActivity?: Date): TimeoutError => {
  return new TimeoutError(lastActivity !== undefined ? { timeoutMs, lastActivity } : { timeoutMs });
};
