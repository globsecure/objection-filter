/**
 * Executor and Provider Types
 * Core interfaces and types for the provider-agnostic executor system
 */

import type { SubagentRegistry } from "@compozy/prompts/built-in";
import type { Effect, Stream } from "effect";
import type { ClaudeAgentOptions, ClaudeStreamChunk } from "./claude/types";

/**
 * Supported executor providers
 */
export enum Provider {
  Claude = "claude",
}

/**
 * Reasoning effort levels for extended thinking mode.
 *
 * @remarks
 * Controls internal reasoning depth:
 * - **minimal**: Fastest, least reasoning (1K tokens)
 * - **low**: Quick reasoning (2K tokens)
 * - **medium**: Balanced reasoning (4K tokens)
 * - **high**: Deep reasoning (8K tokens)
 *
 * Maps to `maxThinkingTokens` in Claude Agent SDK
 *
 * @see {@link https://docs.claude.com | Claude Documentation}
 */
export type ReasoningEffort = "minimal" | "low" | "medium" | "high";

/**
 * Generic log chunk that can contain any message type
 * @template TMessage - Provider-specific message type
 */
export interface LogChunk<TMessage = unknown> {
  /** Provider-specific message (can be string for backwards compatibility) */
  message: TMessage;
  /** When this log was emitted */
  timestamp: Date;
  /** Whether this is stderr (true) or stdout (false) - optional for backwards compatibility */
  isErr?: boolean;
  /** Legacy field for backwards compatibility - use message instead */
  line?: string;
}

/**
 * Provider capabilities descriptor
 */
export interface Capabilities {
  /** Provider identifier */
  id: Provider;
  /** Feature support matrix */
  supports: {
    /** Can accept prompts via stdin */
    stdinPrompt: boolean;
    /** Can stream JSON output */
    streamJson: boolean;
    /** Supports reasoning effort configuration */
    reasoningEffort: boolean;
    /** Supports model selection */
    modelSelect: boolean;
    /** Supports custom environment variables */
    customEnv: boolean;
  };
}

/**
 * Base executor options common to all providers
 */
export interface ProviderOptsBase {
  /** Model identifier (provider-specific) */
  model?: string;
  /** Reasoning effort level (if supported) */
  reasoningEffort?: ReasoningEffort;
  /** Inactivity timeout in milliseconds */
  timeoutMs?: number;
  /** Custom environment variables */
  env?: Record<string, string>;
  /** Task identifier used for session and history lookups */
  taskId?: string;
  /** Force executor to clear session state before running */
  resetSession?: boolean;
}

/**
 * Separated prompt components for provider-specific handling
 */
export interface PromptComponents {
  /** System prompt (base + custom) */
  systemPrompt: string;
  /** Task-specific user prompt */
  userPrompt: string;
  /** Optional custom subagent registry with artifacts/task injected */
  subagents?: SubagentRegistry;
}

/**
 * Input for a single executor run
 */
export interface RunInput {
  /** Prompt components with system/user separation */
  promptComponents: PromptComponents;
}

/**
 * Exit codes for executor runs
 * Standard exit codes for different execution outcomes
 */
export const ExitCode = {
  /** Execution completed successfully */
  SUCCESS: 0,
  /** Execution failed with an error */
  EXECUTION_ERROR: 1,
  /** Execution was cancelled by user */
  USER_CANCELLED: -1,
  /** Execution timed out */
  TIMEOUT: -2,
} as const;

/**
 * Result of a single executor run
 */
export interface RunResult {
  /** Process exit code (0 = success) */
  exitCode: number;
  /** Whether execution timed out due to inactivity */
  timedOut?: boolean;
  /**
   * Optional token usage reported by the provider (AI SDK v5 compatible).
   * Present on `finish` chunks for streaming providers.
   */
  usage?: {
    inputTokens?: number;
    outputTokens?: number;
    totalTokens?: number;
  };
  /**
   * Optional provider metadata carried on finish chunks (e.g., cost/duration).
   * Shape is provider-specific.
   */
  providerMetadata?: Record<string, unknown>;
}

/**
 * Generic Executor interface for type-safe provider options and messages
 * @template TOptions - Executor-specific options
 * @template TMessage - Executor-specific message type (used for type tracking)
 */
export interface Executor<
  TOptions extends ProviderOptsBase = ProviderOptsBase,
  TMessage = unknown,
> {
  /** Provider identifier */
  readonly id: Provider;
  /** Provider capabilities */
  readonly capabilities: Capabilities;
  /** Execute a prompt and stream messages */
  run(input: RunInput, options: TOptions): Stream.Stream<TMessage, Error, any>;
  /** Get current session ID if executor supports session management */
  getSessionId?(): string | undefined;
  /** Save session ID if executor supports session management */
  setSessionId?(taskId: string, sessionId: string): Effect.Effect<void, Error>;
}

/**
 * Type helper to get message type for an executor
 */
export type MessageForExecutor<T> = T extends Executor<any, infer TMessage> ? TMessage : never;

/**
 * Executor constructor type for factory registry
 * Constructors must accept workingDirectory
 * @template TOptions - Executor-specific options
 * @template TMessage - Executor-specific message type
 */
export type ExecutorConstructor<TOptions extends ProviderOptsBase, TMessage = unknown> = new (
  workingDirectory: string
) => Executor<TOptions, TMessage>;

/**
 * Conditional type mapping from Provider to options type
 * Enables type-safe factory.get() return types
 */
export type OptionsForId<TId extends Provider> = TId extends Provider.Claude
  ? ClaudeAgentOptions
  : never;

/**
 * Conditional type mapping from Provider to message type
 * Enables type-safe message handling per provider
 */
export type MessageForId<TId extends Provider> = TId extends Provider.Claude
  ? ClaudeStreamChunk
  : unknown;

/**
 * Conditional type mapping from Provider to Executor type
 * Enables auto-inferred executor types from registry
 */
export type ExecutorForId<TId extends Provider> = Executor<OptionsForId<TId>, MessageForId<TId>>;
