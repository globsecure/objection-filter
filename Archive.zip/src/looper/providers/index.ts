/**
 * ExecutorFactory and Provider Registration
 * Type-safe factory pattern with dependency injection
 */

import { Effect } from "effect";
import { Provider, type Capabilities, type ExecutorForId } from "./types";
import { ClaudeExecutor } from "./claude";
import { ExecutorNotFoundError } from "./errors";

/**
 * Type-safe factory for creating and managing executor adapters
 */
export interface ExecutorFactory {
  /**
   * Get an executor by ID
   * @param executorId - The executor provider ID
   * @param workingDirectory - Working directory for the task (used for chat history persistence)
   * @returns Effect that resolves to the executor instance
   * @throws ExecutorNotFoundError if executor ID is not registered
   */
  get<TId extends Provider>(
    executorId: TId,
    workingDirectory: string
  ): Effect.Effect<ExecutorForId<TId>, Error>;

  /**
   * Get capabilities for a specific executor
   * @param executorId - The executor provider ID
   * @returns Effect that resolves to capabilities or error
   */
  getCapabilities<TId extends Provider>(executorId: TId): Effect.Effect<Capabilities, Error>;

  /**
   * List all registered executor IDs
   * @returns Array of registered executor IDs
   */
  listExecutors(): Provider[];
}

/**
 * Implementation of ExecutorFactory
 */
class ExecutorFactoryImpl implements ExecutorFactory {
  private supportedProviders: Provider[] = [Provider.Claude];

  constructor() {}

  get<TId extends Provider>(
    executorId: TId,
    workingDirectory: string
  ): Effect.Effect<ExecutorForId<TId>, Error> {
    if (!this.supportedProviders.includes(executorId)) {
      return Effect.fail(
        new ExecutorNotFoundError({
          executorId,
          availableExecutors: this.listExecutors(),
        })
      );
    }

    // Create executor based on ID with required dependencies
    if (executorId === Provider.Claude) {
      return Effect.gen(function* () {
        const executor = new ClaudeExecutor(workingDirectory);
        const initializedExecutor = yield* executor.build();
        return initializedExecutor as ExecutorForId<TId>;
      });
    }

    return Effect.fail(
      new ExecutorNotFoundError({
        executorId,
        availableExecutors: this.listExecutors(),
      })
    );
  }

  getCapabilities<TId extends Provider>(executorId: TId): Effect.Effect<Capabilities, Error> {
    if (!this.supportedProviders.includes(executorId)) {
      return Effect.fail(
        new ExecutorNotFoundError({
          executorId,
          availableExecutors: this.listExecutors(),
        })
      );
    }

    // Return capabilities directly without instantiating executor
    if (executorId === Provider.Claude) {
      return Effect.succeed({
        id: Provider.Claude,
        supports: {
          stdinPrompt: false,
          streamJson: true,
          reasoningEffort: true,
          modelSelect: true,
          customEnv: true,
        },
      });
    }

    return Effect.fail(
      new ExecutorNotFoundError({
        executorId,
        availableExecutors: this.listExecutors(),
      })
    );
  }

  listExecutors(): Provider[] {
    return this.supportedProviders;
  }
}

/**
 * Create a new ExecutorFactory with registered providers
 *
 * @returns Effect that resolves to ExecutorFactory instance
 *
 * @example
 * ```typescript
 * const factory = yield* createExecutorFactory();
 * const claudeExecutor = yield* factory.get('claude', workingDirectory);
 * ```
 */
export const createExecutorFactory = (): Effect.Effect<ExecutorFactory, Error> => {
  return Effect.succeed(new ExecutorFactoryImpl());
};
