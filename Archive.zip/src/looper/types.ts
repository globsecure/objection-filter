/**
 * Browser-Safe Type Exports
 * Types and enums safe for use in Electron renderer process (browser context)
 * This file contains NO runtime code and NO Node.js dependencies
 */

// =============================================================================
// IPC Contract Types (from electron/ipc-contract)
// =============================================================================

export type {
  IssueContext,
  JobStatus,
  LooperAPI,
  LooperIPCContract,
  RunnerOptions,
} from "./electron/ipc-contract";

// =============================================================================
// Provider Types (from providers/types)
// =============================================================================

export { Provider } from "./providers/types";
export type {
  Capabilities,
  LogChunk,
  OptionsForId,
  ProviderOptsBase,
  ReasoningEffort,
  RunInput,
  RunResult,
} from "./providers/types";

// =============================================================================
// Claude Provider Types (from providers/claude)
// =============================================================================

export { ClaudeModel } from "./providers/claude/types";
export type { ClaudeAgentOptions } from "./providers/claude/types";
