import "@shared/test-utils/vitest-jsdom-polyfills";
import { setupLocalStorageMock } from "@shared/test-utils/local-storage-mock";
import { cleanup } from "@testing-library/react";
import { afterAll, afterEach, beforeAll } from "vitest";

// Mock localStorage for tests
const localStorageMock = setupLocalStorageMock();

// Polyfill File.text() method for tests
// File.text() is a standard API but jsdom doesn't implement it
if (typeof File !== "undefined" && !File.prototype.text) {
  File.prototype.text = async function (this: File): Promise<string> {
    return await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = () => reject(reader.error);
      reader.readAsText(this);
    });
  };
}

// Import server after mocks are set up
const { server } = await import("./server");

beforeAll(() => server.listen());
afterEach(() => {
  server.resetHandlers();
  cleanup();
  localStorageMock.clear();
});
afterAll(() => server.close());
