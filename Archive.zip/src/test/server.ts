import { http, HttpResponse } from "msw";
import { setupServer } from "msw/node";

const AGENT_API_URL = "http://localhost:21230";

// Chat messages API handlers
export const messagesSuccessHandler = http.get(
  `${AGENT_API_URL}/api/v1/agents/chat/:chatId/messages`,
  async () => {
    return HttpResponse.json({
      messages: [
        {
          id: "msg-1",
          role: "user",
          parts: [{ type: "text", text: "Hello" }],
          createdAt: new Date("2025-01-01T10:00:00Z").toISOString(),
        },
        {
          id: "msg-2",
          role: "assistant",
          parts: [{ type: "text", text: "Hi there!" }],
          createdAt: new Date("2025-01-01T10:00:01Z").toISOString(),
        },
      ],
    });
  }
);

export const messages404Handler = http.get(
  `${AGENT_API_URL}/api/v1/agents/chat/:chatId/messages`,
  async () => {
    return HttpResponse.json(
      {
        ok: false,
        error: { code: "NOT_FOUND", message: "Chat not found" },
      },
      { status: 404 }
    );
  }
);

export const messagesEmptyHandler = http.get(
  `${AGENT_API_URL}/api/v1/agents/chat/:chatId/messages`,
  async () => {
    return HttpResponse.json({
      messages: [],
    });
  }
);

export const handlers = [messagesSuccessHandler];

export const server = setupServer(...handlers);
