/**
 * Shared validation patterns and utilities
 */

/**
 * Common regex patterns for validation
 */
export const VALIDATION_PATTERNS = {
  /**
   * Alphanumeric with spaces, hyphens, and underscores
   */
  ALPHANUMERIC_WITH_SPECIAL: /^[a-zA-Z0-9\s\-_]+$/,

  /**
   * Lowercase alphanumeric with hyphens (for slugs)
   */
  SLUG: /^[a-z0-9-]+$/,

  /**
   * Path format (alphanumeric with forward slashes, hyphens, underscores, and periods)
   */
  FILE_PATH: /^[a-zA-Z0-9/\-_.]+$/,
} as const;

/**
 * Common validation messages
 */
export const VALIDATION_MESSAGES = {
  REQUIRED: "This field is required",
  MIN_LENGTH: (min: number) => `Must be at least ${min} characters`,
  MAX_LENGTH: (max: number) => `Must be less than ${max} characters`,
  INVALID_FORMAT: (field: string) => `Invalid ${field} format`,
} as const;

/**
 * Validation helper functions
 */
export const validators = {
  /**
   * Check if string doesn't start or end with hyphen
   */
  noLeadingTrailingHyphen: (value: string) => !value.startsWith("-") && !value.endsWith("-"),

  /**
   * Check if string doesn't contain consecutive characters
   */
  noConsecutiveChars: (value: string, char: string) => !value.includes(char.repeat(2)),
} as const;
