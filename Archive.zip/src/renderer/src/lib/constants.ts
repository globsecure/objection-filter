/**
 * Application-wide constants
 */

/**
 * Route paths
 */
export const ROUTES = {
  HOME: "/app",
  AUTH: {
    SIGN_IN: "/auth/signin",
  },
  ONBOARDING: "/app/onboarding",
  ORGANIZATIONS: {
    CREATE: "/app/organizations/create",
  },
  ISSUES: "/app/issues",
  ARTIFACTS: {
    EDITOR: "/app/issues/$issueId/artifacts/$artifactId",
  },
  TASKS: {
    EDITOR: "/app/issues/$issueId/tasks/$taskId",
  },
} as const;

/**
 * Placeholder values
 */
export const PENDING_ORGANIZATION_ID = "pending-organization" as const;

/**
 * Route prefixes for layout matching
 */
export const ROUTE_PREFIXES = {
  AUTH: "/auth",
  APP: "/app",
  ORGANIZATIONS: "/app/organizations",
  ONBOARDING: "/app/onboarding",
} as const;
