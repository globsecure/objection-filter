import type { Actor, AnyActorLogic } from "xstate";
import { createActor } from "xstate";

/**
 * Load persisted state from localStorage.
 * Handles Zustand persist format: { state: T, version?: number }
 *
 * **Note:** For most use cases, prefer `createPersistedStore()` which handles this automatically.
 * This function is available for advanced use cases requiring custom persistence logic.
 *
 * @param storageKey - localStorage key to read from
 * @param selector - Function to extract the desired value from parsed JSON
 * @param defaultValue - Default value if no persisted state exists or parsing fails
 * @returns The persisted state or default value
 *
 * @example
 * ```ts
 * const persistedIds = loadPersistedState(
 *   "my-storage-key",
 *   (parsed) => parsed?.state?.selectedIds,
 *   []
 * );
 * ```
 */
export function loadPersistedState<T>(
  storageKey: string,
  selector: (parsed: any) => T | undefined,
  defaultValue: T
): T {
  try {
    const persisted = localStorage.getItem(storageKey);
    if (!persisted) return defaultValue;

    const parsed = JSON.parse(persisted);
    // Zustand persist format: { state: T, version?: number }
    const value = selector(parsed);
    return value !== undefined ? value : defaultValue;
  } catch {
    return defaultValue;
  }
}

/**
 * Set up automatic persistence for an XState actor.
 * Subscribes to actor changes and saves to localStorage in Zustand persist format.
 *
 * **Note:** For most use cases, prefer `createPersistedStore()` which handles this automatically.
 * This function is available for advanced use cases requiring custom persistence logic.
 *
 * @param actor - The XState actor to persist
 * @param storageKey - localStorage key to save to
 * @param extractor - Function to extract the state to persist from the snapshot context
 * @param version - Optional version number for the persisted state
 * @returns Unsubscribe function to stop persistence
 *
 * @example
 * ```ts
 * const unsubscribe = setupPersistence(
 *   myActor,
 *   "my-storage-key",
 *   (context) => ({ selectedIds: context.selectedIds }),
 *   0
 * );
 * ```
 */
export function setupPersistence<TContext>(
  actor: Actor<AnyActorLogic>,
  storageKey: string,
  extractor: (context: TContext) => any,
  version: number = 0
): () => void {
  const subscription = actor.subscribe(snapshot => {
    try {
      const stateToPersist = extractor(snapshot.context as TContext);
      localStorage.setItem(
        storageKey,
        JSON.stringify({
          state: stateToPersist,
          version,
        })
      );
    } catch (error) {
      console.error(`Failed to persist store "${storageKey}":`, error);
    }
  });

  return () => subscription.unsubscribe();
}

/**
 * Factory function to create a persisted XState store using fromStore and createActor.
 * Handles the complete lifecycle: load persisted state → create actor → set up persistence.
 *
 * **Recommended approach** for creating stores with localStorage persistence.
 * Automatically persists entire context in Zustand-compatible format.
 *
 * @param config - Configuration object
 * @param config.storeLogic - Store logic created with fromStore()
 * @param config.storageKey - localStorage key for persistence
 * @param config.defaultValue - Default context value if no persisted state exists
 * @param config.version - Optional version number for persisted state (default: 0)
 * @returns Configured actor with persistence already set up
 *
 * @example
 * ```ts
 * const storeLogic = fromStore({
 *   context: (initialContext) => initialContext,
 *   on: { /* events *\/ },
 * });
 *
 * const myStore = createPersistedStore({
 *   storeLogic,
 *   storageKey: "my-storage-key",
 *   defaultValue: { selectedIds: [] },
 * });
 * ```
 */
export function createPersistedStore<
  TContext,
  TStoreLogic extends AnyActorLogic = AnyActorLogic,
>(config: {
  storeLogic: TStoreLogic;
  storageKey: string;
  defaultValue: TContext;
  version?: number;
}): Actor<TStoreLogic> {
  const { storeLogic, storageKey, defaultValue, version = 0 } = config;

  // Load persisted state from Zustand format: { state: T, version?: number }
  const persistedInput = loadPersistedState(storageKey, parsed => parsed?.state, defaultValue);

  // Create actor with persisted state as input
  const actor = createActor(storeLogic, {
    input: persistedInput,
  } as any);

  actor.start();

  // Set up persistence subscription - auto-persist entire context
  setupPersistence(actor, storageKey, (context: TContext) => context, version);

  return actor;
}
