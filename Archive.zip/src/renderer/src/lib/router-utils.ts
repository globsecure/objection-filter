import { trim } from "es-toolkit/string";

export type RouterStateLike = {
  isLoading: boolean;
  matches: Array<{ status?: string }>;
};

/**
 * Determines if the router is currently navigating.
 * Returns true if the router is loading or any route match is pending.
 *
 * @param state - The router state containing isLoading and matches
 * @returns Whether navigation is in progress
 */
export function selectIsRouterNavigating(state: RouterStateLike): boolean {
  return state.isLoading || state.matches.some(match => match.status === "pending");
}

/**
 * Normalizes a redirect value coming from `window.location.href` (or similar)
 * into an internal router href (pathname + search + hash) that works in Electron
 * production builds (file://).
 *
 * Why this exists:
 * - In production, Electron loads the renderer via `file://.../index.html` so the
 *   browser `pathname` contains `index.html`, which is not a valid app route.
 * - TanStack Router redirects should use internal paths via `to`, not absolute URLs.
 */
export function normalizeRedirectHref(redirect: unknown, fallbackHref = "/"): string {
  if (typeof redirect !== "string") {
    return fallbackHref;
  }

  const candidate = trim(redirect);
  if (candidate.length === 0) {
    return fallbackHref;
  }

  // Parse absolute URLs (eg: file://, http://) and relative hrefs (eg: /issues?tab=1)
  // into a consistent internal href representation.
  let parsed: URL;
  try {
    parsed = new URL(candidate);
  } catch {
    try {
      parsed = new URL(candidate, "http://app.local");
    } catch {
      return fallbackHref;
    }
  }

  const pathname = parsed.pathname.length > 0 ? parsed.pathname : "/";
  const normalizedPathname =
    pathname === "/index.html" || pathname.endsWith("/index.html") ? "/" : pathname;

  return `${normalizedPathname}${parsed.search}${parsed.hash}`;
}
