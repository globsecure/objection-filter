import { isAppError } from "@/lib/errors";
import { captureRendererException } from "@/lib/sentry";
import { MutationCache, QueryCache, QueryClient } from "@tanstack/react-query";

function isAbortLikeError(error: unknown): boolean {
  if (!error) return false;

  if (error instanceof DOMException && error.name === "AbortError") return true;

  if (error instanceof Error) {
    if (error.name === "AbortError") return true;
    if (error.name === "CanceledError" || error.name === "CancelledError") return true;
    return /aborted|canceled|cancelled/i.test(error.message);
  }

  return false;
}

function shouldSkipSentry(meta: unknown): boolean {
  if (!meta || typeof meta !== "object") return false;

  const maybeMeta = meta as Record<string, unknown>;
  const sentry = maybeMeta.sentry;

  if (sentry === false) return true;
  if (!sentry || typeof sentry !== "object") return false;

  const sentryConfig = sentry as Record<string, unknown>;
  return sentryConfig.disabled === true || sentryConfig.ignore === true;
}

function shouldForceSentry(meta: unknown): boolean {
  if (!meta || typeof meta !== "object") return false;

  const maybeMeta = meta as Record<string, unknown>;
  const sentry = maybeMeta.sentry;

  if (!sentry || typeof sentry !== "object") return false;
  const sentryConfig = sentry as Record<string, unknown>;
  return sentryConfig.force === true;
}

function shouldIncludeQueryKey(meta: unknown): boolean {
  if (!meta || typeof meta !== "object") return false;

  const maybeMeta = meta as Record<string, unknown>;
  const sentry = maybeMeta.sentry;

  if (!sentry || typeof sentry !== "object") return false;
  const sentryConfig = sentry as Record<string, unknown>;
  return sentryConfig.includeQueryKey === true || sentryConfig.includeKeys === true;
}

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      gcTime: 1000 * 60 * 60 * 24,
      staleTime: 1000 * 60 * 5,
    },
  },
  queryCache: new QueryCache({
    onError: (error, query) => {
      const meta = query.meta ?? query.options.meta;
      const forceSentry = shouldForceSentry(meta);
      if (shouldSkipSentry(meta)) return;
      if (isAbortLikeError(error)) return;

      // Client-side "expected" errors often don't need Sentry noise.
      if (!forceSentry && isAppError(error) && error.statusCode && error.statusCode < 500) return;

      captureRendererException(error, {
        source: "tanstack-query",
        kind: "query",
        queryHash: query.queryHash,
        queryKey: shouldIncludeQueryKey(meta) ? query.queryKey : undefined,
        status: query.state.status,
        fetchStatus: query.state.fetchStatus,
        failureCount: query.state.fetchFailureCount,
        href: typeof window !== "undefined" ? window.location.href : undefined,
      });
    },
  }),
  mutationCache: new MutationCache({
    onError: (error, _variables, _context, mutation) => {
      const meta = mutation.meta ?? mutation.options.meta;
      const forceSentry = shouldForceSentry(meta);
      if (shouldSkipSentry(meta)) return;
      if (isAbortLikeError(error)) return;

      if (!forceSentry && isAppError(error) && error.statusCode && error.statusCode < 500) return;

      captureRendererException(error, {
        source: "tanstack-query",
        kind: "mutation",
        mutationKey: mutation.options.mutationKey ?? null,
        status: mutation.state.status,
        failureCount: mutation.state.failureCount,
        href: typeof window !== "undefined" ? window.location.href : undefined,
      });
    },
  }),
});

export default queryClient;
