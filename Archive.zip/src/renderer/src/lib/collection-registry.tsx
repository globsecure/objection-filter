import { invariant } from "es-toolkit/util";
import { createContext, useContext, useEffect, useMemo, useRef, type ReactNode } from "react";

const DEFAULT_COLLECTION_GC_TIME_MS = 1000 * 60 * 30;

type CleanupTimer = ReturnType<typeof setTimeout>;

type CleanupCapable = {
  cleanup?: () => Promise<void> | void;
};

type CollectionRecord<T = unknown> = {
  collection: T;
  refCount: number;
  gcTimeMs: number;
  cleanupTimer?: CleanupTimer;
};

const cleanupCollection = (collection: unknown) => {
  const target = collection as CleanupCapable | null;
  if (typeof target?.cleanup !== "function") {
    return;
  }

  void Promise.resolve(target.cleanup()).catch(error => {
    console.error("Failed to cleanup collection", error);
  });
};

export type CollectionRegistryAcquireOptions = {
  gcTimeMs?: number;
};

export class CollectionRegistry {
  private readonly records = new Map<string, CollectionRecord>();

  constructor(private readonly defaultGcTimeMs: number = DEFAULT_COLLECTION_GC_TIME_MS) {}

  get<T>(key: string): T | undefined {
    return this.records.get(key)?.collection as T | undefined;
  }

  forEach(callback: (collection: unknown, key: string) => void) {
    for (const [key, record] of this.records.entries()) {
      callback(record.collection, key);
    }
  }

  acquire<T>(key: string, factory: () => T, options: CollectionRegistryAcquireOptions = {}): T {
    const existing = this.records.get(key);
    if (existing) {
      existing.refCount += 1;
      if (existing.cleanupTimer) {
        clearTimeout(existing.cleanupTimer);
        existing.cleanupTimer = undefined;
      }
      return existing.collection as T;
    }

    const collection = factory();
    const gcTimeMs = options.gcTimeMs ?? this.defaultGcTimeMs;

    this.records.set(key, {
      collection,
      refCount: 1,
      gcTimeMs,
    });

    return collection;
  }

  release(key: string) {
    const record = this.records.get(key);
    if (!record) {
      return;
    }

    record.refCount = Math.max(0, record.refCount - 1);
    if (record.refCount > 0) {
      return;
    }

    if (record.cleanupTimer) {
      return;
    }

    if (record.gcTimeMs <= 0) {
      this.cleanupRecord(key, record);
      return;
    }

    record.cleanupTimer = setTimeout(() => {
      const current = this.records.get(key);
      if (!current || current !== record) {
        return;
      }
      if (current.refCount > 0) {
        current.cleanupTimer = undefined;
        return;
      }
      this.cleanupRecord(key, current);
    }, record.gcTimeMs);
  }

  clear() {
    for (const [key, record] of this.records.entries()) {
      this.cleanupRecord(key, record);
    }
  }

  private cleanupRecord(key: string, record: CollectionRecord) {
    if (record.cleanupTimer) {
      clearTimeout(record.cleanupTimer);
      record.cleanupTimer = undefined;
    }
    this.records.delete(key);
    cleanupCollection(record.collection);
  }
}

const CollectionRegistryContext = createContext<CollectionRegistry | null>(null);
const sharedRegistry = new CollectionRegistry();

export function getSharedCollectionRegistry() {
  return sharedRegistry;
}

export function forEachCollectionByPrefix<T>(
  prefix: string,
  filterFn: (parsedQueryKey: readonly unknown[]) => boolean,
  callback: (collection: T) => void
) {
  const registry = getSharedCollectionRegistry();
  registry.forEach((collection, key) => {
    if (!key.startsWith(prefix)) {
      return;
    }

    try {
      const keyWithoutPrefix = key.slice(prefix.length);
      const parsedQueryKey = JSON.parse(keyWithoutPrefix) as readonly unknown[];
      if (!filterFn(parsedQueryKey)) {
        return;
      }
    } catch {
      return;
    }

    callback(collection as T);
  });
}

export function CollectionRegistryProvider({ children }: { children: ReactNode }) {
  useEffect(() => {
    return () => sharedRegistry.clear();
  }, []);

  return (
    <CollectionRegistryContext.Provider value={sharedRegistry}>
      {children}
    </CollectionRegistryContext.Provider>
  );
}

export function useCollectionRegistry() {
  const context = useContext(CollectionRegistryContext);
  invariant(context, "useCollectionRegistry must be used within CollectionRegistryProvider");
  return context;
}

/**
 * Acquire a shared collection instance from the registry.
 *
 * Callers can memoize the factory with useCallback, but the latest factory
 * is always used when the key changes.
 */
export function useSharedCollection<T>(
  key: string,
  factory: () => T,
  options?: CollectionRegistryAcquireOptions
): T {
  const registry = useCollectionRegistry();
  const stableOptions = useMemo(() => options, [options?.gcTimeMs]);
  const factoryRef = useRef(factory);
  factoryRef.current = factory;

  const collection = useMemo(() => {
    return registry.acquire(key, () => factoryRef.current(), stableOptions);
  }, [registry, key, stableOptions]);

  useEffect(() => {
    return () => registry.release(key);
  }, [registry, key]);

  return collection;
}
