import { renderHook } from "@testing-library/react";
import { createElement, type PropsWithChildren } from "react";
import { afterEach, describe, expect, it } from "vitest";
import {
  CollectionRegistryProvider,
  getSharedCollectionRegistry,
  useSharedCollection,
} from "./collection-registry";

const wrapper = ({ children }: PropsWithChildren) =>
  createElement(CollectionRegistryProvider, null, children);

describe("useSharedCollection", () => {
  afterEach(() => {
    getSharedCollectionRegistry().clear();
  });

  it("uses the latest factory when the key changes", () => {
    const { result, rerender } = renderHook(
      ({ organizationId }: { organizationId: string }) => {
        const key = `repositories:${organizationId || "none"}`;
        const factory = () => ({ organizationId });
        return useSharedCollection(key, factory);
      },
      { wrapper, initialProps: { organizationId: "" } }
    );

    expect(result.current.organizationId).toBe("");

    rerender({ organizationId: "org-1" });

    expect(result.current.organizationId).toBe("org-1");
  });
});
