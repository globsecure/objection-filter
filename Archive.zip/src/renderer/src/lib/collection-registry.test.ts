import { afterEach, describe, expect, it, vi } from "vitest";
import { CollectionRegistry } from "./collection-registry";

describe("CollectionRegistry", () => {
  afterEach(() => {
    vi.useRealTimers();
  });

  it("reuses the same collection instance for identical keys", () => {
    const registry = new CollectionRegistry(0);
    const first = registry.acquire("tasks:shared", () => ({ id: "first" }));
    const second = registry.acquire("tasks:shared", () => ({ id: "second" }));

    expect(second).toBe(first);

    registry.release("tasks:shared");
    registry.release("tasks:shared");
  });

  it("does not cleanup while there are active references", () => {
    let cleanupCalled = false;
    const registry = new CollectionRegistry(0);
    const collection = { cleanup: () => (cleanupCalled = true) };

    registry.acquire("issues:active", () => collection);
    registry.acquire("issues:active", () => collection);

    registry.release("issues:active");

    expect(cleanupCalled).toBe(false);

    registry.release("issues:active");

    expect(cleanupCalled).toBe(true);
  });

  it("schedules cleanup based on gcTimeMs", () => {
    vi.useFakeTimers();

    let cleanupCalled = false;
    const registry = new CollectionRegistry(50);
    const collection = { cleanup: () => (cleanupCalled = true) };

    registry.acquire("artifacts:slow", () => collection);
    registry.release("artifacts:slow");

    expect(cleanupCalled).toBe(false);

    vi.advanceTimersByTime(49);
    expect(cleanupCalled).toBe(false);

    vi.advanceTimersByTime(1);
    expect(cleanupCalled).toBe(true);
  });

  it("handles concurrent acquire and release operations", async () => {
    const registry = new CollectionRegistry(0);
    const collection = { cleanup: vi.fn() };

    const acquired = await Promise.all([
      Promise.resolve().then(() => registry.acquire("concurrent:test", () => collection)),
      Promise.resolve().then(() => registry.acquire("concurrent:test", () => collection)),
      Promise.resolve().then(() => registry.acquire("concurrent:test", () => collection)),
    ]);

    acquired.forEach(item => {
      expect(item).toBe(collection);
    });

    await Promise.all([
      Promise.resolve().then(() => registry.release("concurrent:test")),
      Promise.resolve().then(() => registry.release("concurrent:test")),
    ]);

    expect(collection.cleanup).not.toHaveBeenCalled();

    await Promise.resolve().then(() => registry.release("concurrent:test"));

    expect(collection.cleanup).toHaveBeenCalledTimes(1);
  });
});
