import { describe, expect, it } from "vitest";
import type { RouterStateLike } from "./router-utils";
import { normalizeRedirectHref, selectIsRouterNavigating } from "./router-utils";

// Constants
const ROOT_PATH = "/";
const FILE_PROTOCOL = "file://";
const STATUS_SUCCESS = "success";
const STATUS_PENDING = "pending";
const TEST_PATH_ISSUES = "/issues";
const TEST_QUERY_HASH = "?tab=open#top";
const TEST_BASE_URL = "http://localhost:3000";
const TEST_FILE_PATH_MACOS = "/Users/me/Compozy.app/index.html";
const TEST_FILE_PATH_SIMPLE = "/index.html";

describe("selectIsRouterNavigating", () => {
  it("returns false when not loading and no matches are pending", () => {
    expect(selectIsRouterNavigating({ isLoading: false, matches: [] })).toBe(false);
  });

  it("returns true when the router is loading", () => {
    expect(selectIsRouterNavigating({ isLoading: true, matches: [] })).toBe(true);
  });

  it("returns true when any match is pending", () => {
    expect(
      selectIsRouterNavigating({
        isLoading: false,
        matches: [{ status: STATUS_SUCCESS }, { status: STATUS_PENDING }],
      })
    ).toBe(true);
  });

  it("ignores properties outside RouterStateLike interface (e.g., isTransitioning)", () => {
    // This test verifies that the function only considers isLoading and matches,
    // ignoring any other properties that might exist on the router state object.
    // Using 'as unknown as RouterStateLike' to explicitly bypass TypeScript checks
    // for testing purposes.
    expect(
      selectIsRouterNavigating({
        isLoading: false,
        matches: [],
        isTransitioning: true,
      } as unknown as RouterStateLike)
    ).toBe(false);
  });
});

describe("normalizeRedirectHref", () => {
  it("falls back to / for non-string values", () => {
    expect(normalizeRedirectHref(undefined)).toBe(ROOT_PATH);
    expect(normalizeRedirectHref(null)).toBe(ROOT_PATH);
    expect(normalizeRedirectHref({})).toBe(ROOT_PATH);
  });

  it("normalizes file:// index.html hrefs to /", () => {
    expect(normalizeRedirectHref(`${FILE_PROTOCOL}${TEST_FILE_PATH_MACOS}`)).toBe(ROOT_PATH);
    expect(normalizeRedirectHref(`${FILE_PROTOCOL}${TEST_FILE_PATH_SIMPLE}`)).toBe(ROOT_PATH);
  });

  it("keeps internal paths intact", () => {
    expect(normalizeRedirectHref(TEST_PATH_ISSUES)).toBe(TEST_PATH_ISSUES);
    expect(normalizeRedirectHref(`${TEST_PATH_ISSUES}${TEST_QUERY_HASH}`)).toBe(
      `${TEST_PATH_ISSUES}${TEST_QUERY_HASH}`
    );
  });

  it("extracts internal href from absolute URLs", () => {
    expect(normalizeRedirectHref(`${TEST_BASE_URL}${TEST_PATH_ISSUES}${TEST_QUERY_HASH}`)).toBe(
      `${TEST_PATH_ISSUES}${TEST_QUERY_HASH}`
    );
  });
});
