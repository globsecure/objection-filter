import { compact } from "es-toolkit/array";

import { DEV_SERVER_PORTS } from "@shared/security/types";
import { stripTrailingSlash } from "@shared/server-config";
import {
  DEFAULT_AGENT_EVENTS_PORT,
  DEFAULT_AGENT_PORT,
  DEFAULT_BACKEND_PROXY_PORT,
  DEFAULT_LOOPER_PORT,
} from "../../../shared/config/defaultPorts";
import type { RuntimeConfig } from "../../../shared/runtime-config";

let cachedRuntimeConfig: RuntimeConfig | undefined;

export function setRuntimeConfig(config: RuntimeConfig | undefined): void {
  cachedRuntimeConfig = config;
}

export function getRuntimeConfig(): RuntimeConfig | undefined {
  if (cachedRuntimeConfig) {
    return cachedRuntimeConfig;
  }

  if (typeof window === "undefined") {
    return undefined;
  }

  const fromApi = window.api?.getRuntimeConfig?.();
  if (fromApi) {
    cachedRuntimeConfig = fromApi;
  } else {
    // Side effect: trigger background fetch to populate the cache for future calls
    void window.api?.getRuntimeConfigAsync?.().then(config => {
      if (config) {
        setRuntimeConfig(config);
      }
    });
  }

  return cachedRuntimeConfig;
}

function getBrowserOriginBase(devPort: string): string | undefined {
  if (typeof window === "undefined") return undefined;

  const current = new URL(window.location.origin);
  const devPorts = compact([DEV_SERVER_PORTS.primary, DEV_SERVER_PORTS.secondary]);

  if (devPorts.includes(current.port)) {
    current.port = devPort;
    return stripTrailingSlash(current.toString());
  }

  return stripTrailingSlash(window.location.origin);
}

export function getBackendApiBase(): string {
  const runtime = getRuntimeConfig();
  if (runtime?.backendProxy?.baseUrl) {
    return runtime.backendProxy.baseUrl;
  }

  return `http://127.0.0.1:${DEFAULT_BACKEND_PROXY_PORT}`;
}

export function getAgentApiBase(): string {
  const runtime = getRuntimeConfig();
  if (runtime?.agents?.baseUrl) {
    return runtime.agents.baseUrl;
  }

  const fromEnv = import.meta.env.VITE_AGENT_API_URL;
  if (fromEnv) {
    return stripTrailingSlash(fromEnv);
  }

  const fromBrowser = getBrowserOriginBase(String(DEFAULT_AGENT_PORT));
  if (fromBrowser) {
    return fromBrowser;
  }

  return `http://localhost:${DEFAULT_AGENT_PORT}`;
}

export function getLooperApiBase(): string {
  const runtime = getRuntimeConfig();
  if (runtime?.looper?.baseUrl) {
    return runtime.looper.baseUrl;
  }

  const fromEnv = import.meta.env.VITE_LOOPER_API_URL;
  if (fromEnv) {
    return stripTrailingSlash(fromEnv);
  }

  const fromBrowser = getBrowserOriginBase(String(DEFAULT_LOOPER_PORT));
  if (fromBrowser) {
    return fromBrowser;
  }

  return `http://localhost:${DEFAULT_LOOPER_PORT}`;
}

export function getAgentEventsBase(): string {
  const runtime = getRuntimeConfig();
  if (runtime?.agentEvents?.baseUrl) {
    return runtime.agentEvents.baseUrl;
  }

  const fromEnv = import.meta.env.VITE_AGENT_EVENTS_URL;
  if (fromEnv) {
    return stripTrailingSlash(fromEnv);
  }

  const fromBrowser = getBrowserOriginBase(String(DEFAULT_AGENT_EVENTS_PORT));
  if (fromBrowser) {
    return fromBrowser;
  }

  return `http://localhost:${DEFAULT_AGENT_EVENTS_PORT}`;
}

export function subscribeRuntimeConfigUpdates(): (() => void) | undefined {
  if (typeof window === "undefined") return undefined;

  const unsubscribe = window.api?.onRuntimeConfig?.(config => {
    setRuntimeConfig(config);
    if (import.meta.env.DEV) {
      console.log("[RuntimeConfig] Updated from IPC event", {
        agentsPort: config?.agents?.port,
        backendProxyPort: config?.backendProxy?.port,
      });
    }
  });

  // Try to get initial config synchronously
  const initial = window.api?.getRuntimeConfig?.();
  if (initial) {
    setRuntimeConfig(initial);
    if (import.meta.env.DEV) {
      console.log("[RuntimeConfig] Loaded initial config synchronously", {
        agentsPort: initial.agents?.port,
        backendProxyPort: initial.backendProxy?.port,
      });
    }
  } else {
    // Retry logic: try fetching async config with retries
    let retryCount = 0;
    const maxRetries = 5;
    const retryDelay = 100; // 100ms between retries

    const scheduleRetry = (reason: string, error?: unknown): void => {
      if (retryCount < maxRetries) {
        retryCount++;
        if (import.meta.env.DEV) {
          const message = `[RuntimeConfig] ${reason}, retrying (${retryCount}/${maxRetries})...`;
          if (error) {
            console.warn(message, error);
          } else {
            console.warn(message);
          }
        }
        // Exponential backoff: 100ms, 200ms, 400ms, 800ms, 1600ms
        setTimeout(fetchWithRetry, retryDelay * Math.pow(2, retryCount - 1));
      } else if (import.meta.env.DEV) {
        if (error) {
          console.error("[RuntimeConfig] Failed to fetch config after retries", error);
        } else {
          console.warn("[RuntimeConfig] Failed to load config after retries, using fallback ports");
        }
      }
    };

    const fetchWithRetry = async (): Promise<void> => {
      try {
        const config = await window.api?.getRuntimeConfigAsync?.();
        if (config) {
          setRuntimeConfig(config);
          if (import.meta.env.DEV) {
            console.log("[RuntimeConfig] Loaded config asynchronously", {
              agentsPort: config.agents?.port,
              backendProxyPort: config.backendProxy?.port,
              retryCount,
            });
          }
        } else {
          scheduleRetry("Config not available");
        }
      } catch (error) {
        scheduleRetry("Error fetching config", error);
      }
    };

    void fetchWithRetry();
  }

  // Fallback to window global if IPC is not available
  if (!unsubscribe && !initial) {
    const fallback = (window as { runtimeConfig?: RuntimeConfig }).runtimeConfig;
    if (fallback) {
      setRuntimeConfig(fallback);
      if (import.meta.env.DEV) {
        console.log("[RuntimeConfig] Using fallback config from window global", {
          agentsPort: fallback.agents?.port,
          backendProxyPort: fallback.backendProxy?.port,
        });
      }
    } else if (import.meta.env.DEV) {
      console.warn("[RuntimeConfig] No runtime config available, API calls will use default ports");
    }
  }

  return unsubscribe;
}
