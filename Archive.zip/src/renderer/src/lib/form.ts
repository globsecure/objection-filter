/**
 * Extracts the error message from a TanStack Form error object.
 * When using Zod validation, errors are objects with a `message` property,
 * not plain strings.
 *
 * @param error - The error from field.state.meta.errors
 * @returns The error message string
 */
export function getErrorMessage(error: unknown): string {
  if (typeof error === "string") return error;
  if (error && typeof error === "object" && "message" in error) {
    return String(error.message);
  }
  return String(error);
}
