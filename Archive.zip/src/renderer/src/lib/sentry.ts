import * as Sentry from "@sentry/electron/renderer";
import { filterSensitiveData } from "./sentry-filter";

const dsn = import.meta.env?.VITE_SENTRY_DSN;
const isDev = import.meta.env?.DEV ?? false;
const environment = isDev ? "development" : "production";

/**
 * Get app version from main process via IPC
 * Falls back to "unknown" if IPC is not available
 */
async function getAppVersion(): Promise<string> {
  try {
    if (typeof window !== "undefined" && window.api?.getAppVersion) {
      return await window.api.getAppVersion();
    }
  } catch (error) {
    console.warn("[Sentry] Failed to get app version via IPC:", error);
  }
  // Fallback to package.json version if available, otherwise "unknown"
  return "unknown";
}

/**
 * Initialize Sentry in the Electron renderer process
 * Sets up error tracking and performance monitoring
 * This function is async but doesn't block - it initializes Sentry in the background
 */
export function initRendererSentry(): void {
  // We gate init behind DSN so dev/test environments without Sentry configured
  // don't pay the initialization cost or emit noisy warnings.
  if (!dsn) return;

  type SentryInitOptions = Parameters<typeof Sentry.init>[0];
  const createInitOptions = (release: string): SentryInitOptions => ({
    dsn,
    debug: isDev,
    environment,
    release,
    tracesSampleRate: isDev ? 1.0 : 0.1, // 100% in dev, 10% in prod
    beforeSend(event) {
      // Only filter error events, other event types pass through unchanged
      // ErrorEvent has type === undefined, transaction events have type === 'transaction'
      if (event.type === undefined) {
        return filterSensitiveData(event);
      }
      return event;
    },
  });

  // Initialize Sentry asynchronously to avoid blocking renderer startup
  // Get app version from main process, then initialize Sentry
  void getAppVersion()
    .then(release => {
      Sentry.init(createInitOptions(release));
    })
    .catch(error => {
      // If getting version fails, initialize with "unknown" release
      console.warn("[Sentry] Failed to get app version, initializing with unknown:", error);
      Sentry.init(createInitOptions("unknown"));
    });
}

/**
 * Capture an exception in the renderer process
 * @param error - The error to capture
 * @param context - Additional context to include with the error
 */
export function captureRendererException(error: unknown, context?: Record<string, unknown>): void {
  if (!dsn) return;
  if (!Sentry.isInitialized()) return;

  Sentry.captureException(error, { extra: context });
}

/**
 * Set user context for Sentry events
 * Call this when user authentication state changes
 */
export function setSentryUser(
  user: { id: string; email?: string; username?: string } | null
): void {
  if (!dsn) return;
  if (!Sentry.isInitialized()) return;

  Sentry.setUser(user);
}

export { Sentry };
