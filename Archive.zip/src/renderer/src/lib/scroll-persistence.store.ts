import { useSelector } from "@xstate/react";
import { createStore, shallowEqual } from "@xstate/store";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  useStickToBottom,
  type StickToBottomInstance,
  type StickToBottomOptions,
} from "use-stick-to-bottom";

export interface ScrollPersistenceContext {
  lastScrollTop: number | null;
  wasAtBottom: boolean;
  hasOpenedOnce: boolean;
  isOpen: boolean;
}

const DEFAULT_CONTEXT: ScrollPersistenceContext = {
  lastScrollTop: null,
  wasAtBottom: true,
  hasOpenedOnce: false,
  isOpen: false,
};

const MAX_RAF_ATTEMPTS = 20;
const MAX_RESTORE_ATTEMPTS = 120;
const NEAR_BOTTOM_OFFSET_PX = 70;

type ScrollRestoreFn = (scrollTop: number | null, wasAtBottom: boolean) => void;
type ScrollCaptureFn = () => { scrollTop: number | null; isAtBottom: boolean };

export function createScrollPersistenceStore(initialContext = DEFAULT_CONTEXT) {
  return createStore({
    context: initialContext,
    on: {
      open: (context, event: { restoreFn: ScrollRestoreFn }, enqueue): ScrollPersistenceContext => {
        if (context.hasOpenedOnce) {
          const { lastScrollTop, wasAtBottom } = context;
          enqueue.effect(() => {
            event.restoreFn(lastScrollTop, wasAtBottom);
          });
        }
        return { ...context, isOpen: true };
      },
      close: (
        context,
        event: { captureFn: ScrollCaptureFn; stopScrollFn: () => void },
        enqueue
      ): ScrollPersistenceContext => {
        const { scrollTop, isAtBottom } = event.captureFn();
        enqueue.effect(() => {
          event.stopScrollFn();
        });
        return {
          ...context,
          lastScrollTop: scrollTop,
          wasAtBottom: isAtBottom,
          hasOpenedOnce: true,
          isOpen: false,
        };
      },
      updateScrollPosition: (
        context,
        event: { scrollTop: number | null; isAtBottom: boolean }
      ): ScrollPersistenceContext => ({
        ...context,
        lastScrollTop: event.scrollTop,
        wasAtBottom: event.isAtBottom,
      }),
      reset: (): ScrollPersistenceContext => DEFAULT_CONTEXT,
    },
  });
}

export type ScrollPersistenceStore = ReturnType<typeof createScrollPersistenceStore>;

const storeCache = new Map<string, ScrollPersistenceStore>();
const refCounts = new Map<string, number>();
const contextCache = new Map<string, ScrollPersistenceContext>();

function getStorageKey(cacheKey: string): string {
  return `scroll-persistence-${cacheKey}`;
}

function loadContextFromStorage(cacheKey: string): ScrollPersistenceContext | null {
  try {
    const storageKey = getStorageKey(cacheKey);
    const persisted = localStorage.getItem(storageKey);
    if (!persisted) return null;

    const parsed = JSON.parse(persisted);
    // Support both direct context format and Zustand persist format
    const context = parsed?.state ?? parsed;
    if (context && typeof context === "object") {
      return {
        lastScrollTop: context.lastScrollTop ?? null,
        wasAtBottom: context.wasAtBottom ?? true,
        hasOpenedOnce: context.hasOpenedOnce ?? false,
        isOpen: false, // Always reset isOpen on load
      };
    }
    return null;
  } catch {
    return null;
  }
}

function saveContextToStorage(cacheKey: string, context: ScrollPersistenceContext): void {
  try {
    const storageKey = getStorageKey(cacheKey);
    const hasSnapshot = context.lastScrollTop !== null || context.hasOpenedOnce || context.isOpen;
    if (hasSnapshot) {
      // Save in Zustand-compatible format for consistency
      localStorage.setItem(
        storageKey,
        JSON.stringify({
          state: {
            ...context,
            isOpen: false, // Never persist isOpen state
          },
          version: 0,
        })
      );
    } else {
      localStorage.removeItem(storageKey);
    }
  } catch (error) {
    console.error(`[ScrollPersistence] Failed to save context for ${cacheKey}:`, error);
  }
}

export function getScrollPersistenceStore(cacheKey: string): ScrollPersistenceStore {
  if (!storeCache.has(cacheKey)) {
    // Try in-memory cache first, then localStorage
    const cachedContext = contextCache.get(cacheKey) ?? loadContextFromStorage(cacheKey);
    storeCache.set(cacheKey, createScrollPersistenceStore(cachedContext ?? DEFAULT_CONTEXT));
    refCounts.set(cacheKey, 0);
  }
  refCounts.set(cacheKey, (refCounts.get(cacheKey) || 0) + 1);
  return storeCache.get(cacheKey)!;
}

export function releaseScrollPersistenceStore(cacheKey: string): void {
  const store = storeCache.get(cacheKey);
  if (store) {
    const snapshot = store.getSnapshot().context;
    const hasSnapshot =
      snapshot.lastScrollTop !== null || snapshot.hasOpenedOnce || snapshot.isOpen;
    if (hasSnapshot) {
      const contextToSave: ScrollPersistenceContext = {
        ...snapshot,
        hasOpenedOnce: snapshot.hasOpenedOnce || snapshot.lastScrollTop !== null || snapshot.isOpen,
        isOpen: false,
      };
      // Save to both in-memory cache and localStorage
      contextCache.set(cacheKey, contextToSave);
      saveContextToStorage(cacheKey, contextToSave);
    } else {
      contextCache.delete(cacheKey);
      localStorage.removeItem(getStorageKey(cacheKey));
    }
  }
  const count = (refCounts.get(cacheKey) || 0) - 1;
  refCounts.set(cacheKey, count);
  if (count <= 0) {
    storeCache.delete(cacheKey);
    refCounts.delete(cacheKey);
  }
}

export interface UseScrollPersistenceOptions {
  id: string;
  keyPrefix: string;
  open: boolean;
  stickToBottomOptions?: StickToBottomOptions;
  waitForReady?: () => boolean; // Function to check if data is ready (e.g., collection.isReady)
}

export interface UseScrollPersistenceReturn {
  instance: StickToBottomInstance;
  isRestoring: boolean;
}

function waitForElement(
  getElement: () => HTMLElement | null,
  callback: (element: HTMLElement) => void
): () => void {
  let frameId: number | undefined;
  let attempts = 0;
  let cancelled = false;

  const check = () => {
    if (cancelled) return;
    const element = getElement();
    if (element) {
      callback(element);
      return;
    }
    if (attempts >= MAX_RAF_ATTEMPTS) return;
    attempts++;
    frameId = requestAnimationFrame(check);
  };

  check();
  return () => {
    cancelled = true;
    if (frameId !== undefined) {
      cancelAnimationFrame(frameId);
    }
  };
}

function getScrollSnapshot(
  scrollElement: HTMLElement | null
): { scrollTop: number; isAtBottom: boolean } | null {
  if (!scrollElement) return null;
  const scrollTop = scrollElement.scrollTop;
  const maxScrollTop = scrollElement.scrollHeight - scrollElement.clientHeight;
  const isAtBottom = maxScrollTop - scrollTop <= NEAR_BOTTOM_OFFSET_PX;
  return { scrollTop, isAtBottom };
}

export function useScrollPersistence({
  id,
  keyPrefix,
  open,
  stickToBottomOptions,
  waitForReady,
}: UseScrollPersistenceOptions): UseScrollPersistenceReturn {
  const cacheKey = `scroll-${keyPrefix}-${id}`;
  const store = useMemo(() => getScrollPersistenceStore(cacheKey), [cacheKey]);
  const instance = useStickToBottom({
    initial: "auto",
    resize: "auto",
    ...stickToBottomOptions,
  });
  const instanceRef = useRef(instance);
  instanceRef.current = instance;
  const restoreCancelRef = useRef<(() => void) | null>(null);
  const [isRestoring, setIsRestoring] = useState(false);

  const { isOpen, hasOpenedOnce } = useSelector(
    store,
    snapshot => ({
      isOpen: snapshot.context.isOpen,
      hasOpenedOnce: snapshot.context.hasOpenedOnce,
    }),
    shallowEqual
  );

  // Persist scroll position changes to localStorage
  useEffect(() => {
    const subscription = store.subscribe(snapshot => {
      const context = snapshot.context;
      const hasSnapshot = context.lastScrollTop !== null || context.hasOpenedOnce || context.isOpen;
      if (hasSnapshot && !context.isOpen) {
        // Only persist when not open (to avoid saving during restoration)
        const contextToSave: ScrollPersistenceContext = {
          ...context,
          isOpen: false,
        };
        saveContextToStorage(cacheKey, contextToSave);
      }
    });
    return () => subscription.unsubscribe();
  }, [cacheKey, store]);

  // Single effect for store lifecycle and open/close transitions
  useEffect(() => {
    return () => {
      restoreCancelRef.current?.();
      releaseScrollPersistenceStore(cacheKey);
    };
  }, [cacheKey]);

  // Handle open/close transitions
  useEffect(() => {
    if (open && !isOpen) {
      // Set isRestoring immediately if we have a saved position to prevent useChatScroll from interfering
      if (hasOpenedOnce) {
        setIsRestoring(true);
      }
      store.send({
        type: "open",
        restoreFn: (scrollTop, wasAtBottom) => {
          restoreCancelRef.current?.();
          setIsRestoring(true);
          let cancelled = false;
          let attempts = 0;
          const targetScrollTop = scrollTop ?? 0;
          const cancelWait = waitForElement(
            () => instanceRef.current.scrollRef.current,
            () => {
              // Wait for content to load before restoring scroll
              const waitForContent = () => {
                if (cancelled) {
                  setIsRestoring(false);
                  return;
                }
                const scrollElement = instanceRef.current.scrollRef.current;
                if (!scrollElement) {
                  if (attempts < MAX_RESTORE_ATTEMPTS) {
                    attempts++;
                    requestAnimationFrame(waitForContent);
                  } else {
                    setIsRestoring(false);
                  }
                  return;
                }
                // Wait for content to be loaded (scrollHeight > clientHeight indicates content)
                const hasContent = scrollElement.scrollHeight > scrollElement.clientHeight;
                // Also wait for data readiness if provided (e.g., collection.isReady)
                const isDataReady = waitForReady ? waitForReady() : true;
                if (!hasContent || !isDataReady) {
                  if (attempts < MAX_RESTORE_ATTEMPTS) {
                    attempts++;
                    requestAnimationFrame(waitForContent);
                  } else {
                    // Content didn't load or data not ready, restore anyway
                    setIsRestoring(false);
                  }
                  return;
                }
                // Wait for scroll height to stabilize (content fully loaded)
                // Check if scroll height has changed in the last few frames
                let stableHeight = scrollElement.scrollHeight;
                let stableAttempts = 0;
                const checkStability = () => {
                  if (cancelled) {
                    setIsRestoring(false);
                    return;
                  }
                  const currentScrollElement = instanceRef.current.scrollRef.current;
                  if (!currentScrollElement) {
                    if (attempts < MAX_RESTORE_ATTEMPTS) {
                      attempts++;
                      requestAnimationFrame(checkStability);
                    } else {
                      setIsRestoring(false);
                    }
                    return;
                  }
                  const currentHeight = currentScrollElement.scrollHeight;
                  if (currentHeight === stableHeight) {
                    stableAttempts++;
                    // Wait for 3 consecutive frames with same height to ensure stability
                    if (stableAttempts >= 3) {
                      // Height is stable, proceed with restoration
                      proceedWithRestoration();
                      return;
                    }
                  } else {
                    // Height changed, reset stability check
                    stableHeight = currentHeight;
                    stableAttempts = 0;
                  }
                  if (attempts < MAX_RESTORE_ATTEMPTS) {
                    attempts++;
                    requestAnimationFrame(checkStability);
                  } else {
                    // Timeout, proceed anyway
                    proceedWithRestoration();
                  }
                };
                const proceedWithRestoration = () => {
                  if (cancelled) {
                    setIsRestoring(false);
                    return;
                  }
                  // Re-check scroll element after stability check
                  const finalScrollElement = instanceRef.current.scrollRef.current;
                  if (!finalScrollElement) {
                    setIsRestoring(false);
                    return;
                  }
                  attempts = 0; // Reset attempts for actual restoration
                  // If we have a specific scroll position, use it (even if wasAtBottom is true)
                  // wasAtBottom is only meaningful when scrollTop is null or 0
                  if (typeof scrollTop === "number" && scrollTop > 0) {
                    // Restore to specific position
                    const applyRestore = () => {
                      if (cancelled) {
                        setIsRestoring(false);
                        return;
                      }
                      const scrollElement = instanceRef.current.scrollRef.current;
                      if (!scrollElement) {
                        if (attempts < MAX_RESTORE_ATTEMPTS) {
                          attempts++;
                          requestAnimationFrame(applyRestore);
                        } else {
                          setIsRestoring(false);
                        }
                        return;
                      }
                      const maxScrollTop = scrollElement.scrollHeight - scrollElement.clientHeight;
                      const canReachTarget = targetScrollTop <= maxScrollTop + 1;
                      const finalScrollTop = canReachTarget ? targetScrollTop : maxScrollTop;
                      scrollElement.scrollTop = finalScrollTop;
                      if (
                        canReachTarget &&
                        Math.abs(scrollElement.scrollTop - targetScrollTop) <= 1
                      ) {
                        setTimeout(() => {
                          setIsRestoring(false);
                        }, 200);
                        return;
                      }
                      if (attempts >= MAX_RESTORE_ATTEMPTS) {
                        setIsRestoring(false);
                        return;
                      }
                      attempts++;
                      requestAnimationFrame(applyRestore);
                    };
                    applyRestore();
                    return;
                  }
                  // If wasAtBottom is true and no specific position, scroll to bottom
                  if (wasAtBottom) {
                    // Call scrollToBottom and verify it actually scrolls to bottom
                    instanceRef.current.scrollToBottom({ animation: "instant", wait: true });
                    // Verify scroll reached bottom after a short delay
                    const verifyScroll = () => {
                      const el = instanceRef.current.scrollRef.current;
                      if (!el) {
                        setIsRestoring(false);
                        return;
                      }
                      const maxScrollTop = el.scrollHeight - el.clientHeight;
                      const currentScrollTop = el.scrollTop;
                      const isAtBottom = Math.abs(maxScrollTop - currentScrollTop) <= 5; // 5px tolerance
                      if (!isAtBottom && maxScrollTop > 0) {
                        // Manually set scroll to bottom if scrollToBottom didn't work
                        el.scrollTop = maxScrollTop;
                      }
                      setIsRestoring(false);
                    };
                    // Wait a bit for scrollToBottom to complete, then verify
                    setTimeout(verifyScroll, 100);
                    return;
                  }
                  // No position to restore
                  setIsRestoring(false);
                  return;
                };
                // Start stability check
                checkStability();
                return;
              };
              waitForContent();
            }
          );
          restoreCancelRef.current = () => {
            cancelled = true;
            setIsRestoring(false);
            cancelWait();
          };
        },
      });
    } else if (!open && isOpen) {
      store.send({
        type: "close",
        captureFn: () => {
          const scrollElement = instanceRef.current.scrollRef.current;
          const snapshot = getScrollSnapshot(scrollElement);
          if (snapshot) return snapshot;
          return { scrollTop: null, isAtBottom: instanceRef.current.isAtBottom };
        },
        stopScrollFn: () => {
          instanceRef.current.stopScroll();
        },
      });
    }
  }, [open, isOpen, store]);

  // Scroll listener effect - only when open
  useEffect(() => {
    if (!open) return;

    let scrollElement: HTMLElement | null = null;
    let ticking = false;

    const sendSnapshot = () => {
      if (!scrollElement) return;
      const snapshot = getScrollSnapshot(scrollElement);
      if (!snapshot) return;
      store.send({
        type: "updateScrollPosition",
        scrollTop: snapshot.scrollTop,
        isAtBottom: snapshot.isAtBottom,
      });
    };

    const handleScroll = () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          sendSnapshot();
          ticking = false;
        });
        ticking = true;
      }
    };

    const cancelWait = waitForElement(
      () => instanceRef.current.scrollRef.current,
      element => {
        scrollElement = element;
        scrollElement.addEventListener("scroll", handleScroll, { passive: true });
        sendSnapshot();
      }
    );

    return () => {
      sendSnapshot();
      cancelWait();
      if (scrollElement) {
        scrollElement.removeEventListener("scroll", handleScroll);
      }
    };
  }, [open, store]);

  // Initial state capture for first open
  useEffect(() => {
    if (!open || hasOpenedOnce) return;
    const scrollElement = instanceRef.current.scrollRef.current;
    const snapshot = getScrollSnapshot(scrollElement);
    if (!snapshot) return;
    store.send({
      type: "updateScrollPosition",
      scrollTop: snapshot.scrollTop,
      isAtBottom: snapshot.isAtBottom,
    });
  }, [open, hasOpenedOnce, store]);

  return { instance, isRestoring };
}

export interface UseTaskLogsStickToBottomOptions {
  open: boolean;
  taskId?: string;
}

export interface UseTaskLogsStickToBottomReturn {
  instance: StickToBottomInstance;
}

export function useTaskLogsStickToBottom({
  open,
  taskId = "default",
}: UseTaskLogsStickToBottomOptions): UseTaskLogsStickToBottomReturn {
  return useScrollPersistence({
    id: taskId,
    keyPrefix: "task-logs",
    open,
  });
}

export interface UseAiChatScrollPersistenceOptions {
  open: boolean;
  issueId: string;
  sessionType: string;
}

export interface UseAiChatScrollPersistenceReturn {
  instance: StickToBottomInstance;
  isRestoring: boolean;
}

export function useAiChatScrollPersistence({
  open,
  issueId,
  sessionType,
  waitForReady,
}: UseAiChatScrollPersistenceOptions & {
  waitForReady?: () => boolean;
}): UseAiChatScrollPersistenceReturn {
  return useScrollPersistence({
    id: `${issueId}-${sessionType}`,
    keyPrefix: "ai-chat",
    open,
    waitForReady,
  });
}
