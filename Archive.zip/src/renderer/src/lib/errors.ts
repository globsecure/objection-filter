/**
 * Custom error classes for type-safe error handling
 */

/**
 * Base application error class
 */
export class AppError extends Error {
  constructor(
    message: string,
    public readonly code: string,
    public readonly statusCode?: number
  ) {
    super(message);
    this.name = "AppError";
  }
}

/**
 * Collection not ready error - thrown when RxDB collection hasn't been initialized
 */
export class CollectionNotReadyError extends AppError {
  constructor(collectionName: string) {
    super(
      `Collection "${collectionName}" is not ready. Please ensure the collection query has run at least once.`,
      "COLLECTION_NOT_READY"
    );
    this.name = "CollectionNotReadyError";
  }
}

/**
 * Organization not found error
 */
export class OrganizationNotFoundError extends AppError {
  constructor() {
    super(
      "No organization found. Please create an organization first.",
      "ORGANIZATION_NOT_FOUND",
      404
    );
    this.name = "OrganizationNotFoundError";
  }
}

export class DuplicateRepositoryError extends AppError {
  constructor(
    message: string,
    public readonly gitRemoteOrigin?: string | null,
    public readonly localDirectoryPath?: string
  ) {
    super(message, "DUPLICATE_REPOSITORY", 409);
    this.name = "DuplicateRepositoryError";
  }
}

/**
 * Result type for functional error handling
 * Following TypeScript best practices from .cursor/rules/typescript.mdc
 */
export type Result<T, E = Error> = { success: true; data: T } | { success: false; error: E };

/**
 * Utility to create success result
 */
export function success<T>(data: T): Result<T, never> {
  return { success: true, data };
}

/**
 * Utility to create error result
 */
export function failure<E = Error>(error: E): Result<never, E> {
  return { success: false, error };
}

/**
 * Safe wrapper for operations that might throw
 */
export async function safe<T>(operation: () => Promise<T>): Promise<Result<T, Error>> {
  try {
    const data = await operation();
    return success(data);
  } catch (error) {
    return failure(error instanceof Error ? error : new Error(String(error)));
  }
}

/**
 * Type guard to check if value is an Error
 */
export function isError(value: unknown): value is Error {
  return value instanceof Error;
}

/**
 * Type guard to check if value is an AppError
 */
export function isAppError(value: unknown): value is AppError {
  return value instanceof AppError;
}
