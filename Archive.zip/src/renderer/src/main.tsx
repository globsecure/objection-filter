import "./assets/main.css";

import { initRendererSentry } from "@/lib/sentry";
import { enableMapSet } from "immer";
import { subscribeRuntimeConfigUpdates } from "./lib/runtime-api";

initRendererSentry();

// Enable Map/Set support for Immer (required for plugin-registry-store)
enableMapSet();
subscribeRuntimeConfigUpdates();

import { AppErrorBoundary } from "@/components/core/app-error-boundary";
import { AppUpdateNotification } from "@/components/core/app-update-notification";
import { ThemeProvider } from "@/components/core/theme-provider";
import { CollectionRegistryProvider } from "@/lib/collection-registry";
import { queryClient } from "@/lib/query-client";
import { Toaster } from "@compozy/ui";
import { QueryClientProvider } from "@tanstack/react-query";
import { RouterProvider, createBrowserHistory, createRouter } from "@tanstack/react-router";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

// Import routes
import { _appRoute } from "@/routes/_app";
import { _authRoute } from "@/routes/_auth";
import { withOnboardingRoute } from "@/routes/_with-onboarding";
import { withOrganizationRoute } from "@/routes/_with-organization";
import { indexRoute } from "@/routes/index-route";
import { rootRoute } from "@/routes/root";
import { authSignInRoute } from "@/systems/auth/auth-route";
import {
  archivedIssuesRoute,
  issueDetailRoute,
  issuesIndexRoute,
  issuesRoute,
} from "@/systems/issues/issues-route";
import { onboardingRoute } from "@/systems/onboarding/onboarding-route";
import { createOrganizationRoute } from "@/systems/organizations/organizations-route";
import { artifactDetailRoute } from "@/systems/artifacts/artifacts-route";
import { taskDetailRoute } from "@/systems/tasks/tasks-route";

// Create the route tree
const routeTree = rootRoute.addChildren([
  // Public routes - no authentication required
  _authRoute.addChildren([authSignInRoute]),
  // Onboarding route - outside _appRoute to avoid AppLayout inheritance
  onboardingRoute, // /app/onboarding
  // Protected routes - API key validation required
  _appRoute.addChildren([
    indexRoute, // /app -> redirects based on onboarding state
    withOnboardingRoute.addChildren([
      createOrganizationRoute, // /app/organizations/create
      withOrganizationRoute.addChildren([
        issuesRoute.addChildren([
          issuesIndexRoute,
          archivedIssuesRoute,
          issueDetailRoute.addChildren([artifactDetailRoute, taskDetailRoute]),
        ]), // /app/issues/*
      ]),
    ]),
  ]),
]);

// Create browser history instance for Electron navigation
const history = createBrowserHistory();

// Create the router
const router = createRouter({
  routeTree,
  history,
  context: {
    queryClient,
  },
});

// Register the router instance for type safety
declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }
}

const AppContent = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <CollectionRegistryProvider>
        <RouterProvider router={router} />
        <Toaster position="bottom-right" />
        <AppUpdateNotification />
      </CollectionRegistryProvider>
    </QueryClientProvider>
  );
};

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <ThemeProvider>
      <AppErrorBoundary variant="app">
        <AppContent />
      </AppErrorBoundary>
    </ThemeProvider>
  </StrictMode>
);
