import { AppLayout } from "./components/core/app-layout";

function App(): React.JSX.Element {
  return <AppLayout />;
}

export default App;
