import { AppErrorBoundary } from "@/components/core/app-error-boundary";
import { AppErrorFallback } from "@/components/core/app-error-fallback";
import { ROUTES } from "@/lib/constants";
import { captureRendererException } from "@/lib/sentry";
import { authClient, useSession } from "@/systems/auth/client";
import { useDeepLinkAuth } from "@/systems/auth/hooks/use-deep-link-auth";
import type { OnboardingAccessState } from "@/systems/onboarding/lib/ensure-onboarding-state";
import {
  Button,
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@compozy/ui";
import type { QueryClient } from "@tanstack/react-query";
import {
  createRootRouteWithContext,
  ErrorComponentProps,
  Outlet,
  redirect,
  useNavigate,
  useRouterState,
} from "@tanstack/react-router";
import { AlertTriangle, RotateCcw } from "lucide-react";
import { useEffect, type ReactNode } from "react";

// Define the context interface for breadcrumbs and layout
export interface RouteContext {
  queryClient: QueryClient;
  onboardingState?: OnboardingAccessState;
  breadcrumb?: {
    title: string | ReactNode | ((params: Record<string, unknown>) => string | ReactNode);
  };
  layout?: {
    hideAppLayout?: boolean;
  };
}

function RootErrorComponent({ error, reset }: ErrorComponentProps) {
  captureRendererException(error, {
    href: window.location.href,
    boundary: "router-root",
  });

  return <AppErrorFallback error={error} resetErrorBoundary={reset} variant="app" />;
}

function RootNotFoundComponent() {
  const navigate = useNavigate();

  return (
    <div className="grid min-h-[60vh] place-items-center px-4 py-10">
      <Card className="w-full max-w-xl">
        <CardHeader className="border-b">
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle aria-hidden="true" className="size-5 text-destructive" />
            <span>Page Not Found</span>
          </CardTitle>
          <CardDescription>
            The page you're looking for doesn't exist or has been moved.
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="rounded-md border bg-muted/40 p-3">
            <div className="font-medium text-sm">404</div>
            <div className="mt-1 wrap-break-word text-muted-foreground text-sm">
              The route{" "}
              <code className="rounded bg-muted px-1 py-0.5 text-xs">
                {window.location.pathname}
              </code>{" "}
              could not be found.
            </div>
          </div>
        </CardContent>

        <CardFooter className="justify-end gap-2 border-t">
          <Button onClick={() => navigate({ to: ROUTES.HOME })} type="button" variant="default">
            <RotateCcw aria-hidden="true" className="size-4" />
            <span>Go Home</span>
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}

function RootComponent() {
  const locationHref = useRouterState({ select: state => state.location.href });
  const { refetch } = useSession();
  useDeepLinkAuth();

  // Listen to session changes for refetching
  useEffect(() => {
    const sessionSignal = authClient.$store.atoms.$sessionSignal;
    if (!sessionSignal) return;

    const unsubscribe = sessionSignal.listen(() => {
      refetch();
    });

    return () => {
      unsubscribe();
    };
  }, [refetch]);

  return (
    <AppErrorBoundary resetKeys={[locationHref]} variant="app">
      <Outlet />
    </AppErrorBoundary>
  );
}

export const rootRoute = createRootRouteWithContext<RouteContext>()({
  beforeLoad: ({ location }) => {
    const isIndexHtmlLocation =
      location.pathname === "/index.html" || location.pathname.endsWith("/index.html");

    if (isIndexHtmlLocation) {
      throw redirect({ to: ROUTES.HOME, replace: true });
    }

    if (location.pathname === "/") {
      throw redirect({ to: ROUTES.HOME, replace: true });
    }

    // No auth validation at root - handled by route groups
    return {};
  },
  component: RootComponent,
  errorComponent: RootErrorComponent,
  notFoundComponent: RootNotFoundComponent,
});
