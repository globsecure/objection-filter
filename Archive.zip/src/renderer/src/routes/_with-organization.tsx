import { AppErrorFallback } from "@/components/core/app-error-fallback";
import { ROUTES } from "@/lib/constants";
import { captureRendererException } from "@/lib/sentry";
import { sessionQueryOptions } from "@/systems/auth/hooks/use-session";
import { BillingGuard } from "@/systems/billing";
import { billingAccessQueryOptions } from "@/systems/billing/hooks/use-access";
import { ensureOnboardingState } from "@/systems/onboarding/lib/ensure-onboarding-state";
import { organizationsQueryOptions } from "@/systems/organizations/adapters/organizations-api";
import { repositoriesQueryOptions } from "@/systems/repositories/db/repositories-collection";
import { createRoute, ErrorComponentProps, Outlet, redirect } from "@tanstack/react-router";
import { withOnboardingRoute } from "./_with-onboarding";

function WithOrganizationLayout() {
  return (
    <BillingGuard>
      <Outlet />
    </BillingGuard>
  );
}

function WithOrganizationError({ error, reset }: ErrorComponentProps) {
  captureRendererException(error, {
    href: window.location.href,
    boundary: "router-with-organization",
  });

  return <AppErrorFallback error={error} resetErrorBoundary={reset} variant="section" />;
}

/**
 * Route guard that ensures user has completed onboarding (organization).
 * Authentication is handled by parent _appRoute.
 */
export const withOrganizationRoute = createRoute({
  getParentRoute: () => withOnboardingRoute,
  id: "_with-organization",
  loader: async ({ context }) => {
    // Session is already prefetched by parent _appRoute
    const session = context.queryClient.getQueryData(sessionQueryOptions.queryKey) as
      | Awaited<ReturnType<NonNullable<typeof sessionQueryOptions.queryFn>>>
      | undefined;
    const organizationId = session?.session?.activeOrganizationId;

    // Prefetch organizations list, billing access, and repositories data before components render
    // to prevent loading glitches in organization-scoped routes
    // Repositories are prefetched here because the sidebar is always visible
    await Promise.all([
      context.queryClient.ensureQueryData(organizationsQueryOptions()),
      context.queryClient.ensureQueryData(billingAccessQueryOptions),
      // Prefetch repositories if we have an organization ID
      organizationId
        ? context.queryClient.ensureQueryData(repositoriesQueryOptions(organizationId))
        : Promise.resolve(),
    ]);
  },
  beforeLoad: async ({ context }) => {
    if (context.onboardingState) {
      if (!context.onboardingState.hasOrganization) {
        throw redirect({
          to: ROUTES.ONBOARDING,
        });
      }
      return {};
    }

    const state = await ensureOnboardingState(context.queryClient);

    if (!state.hasOrganization) {
      throw redirect({
        to: ROUTES.ONBOARDING,
      });
    }

    return {};
  },
  component: WithOrganizationLayout,
  errorComponent: WithOrganizationError,
});
