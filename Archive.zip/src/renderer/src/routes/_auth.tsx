import { AppErrorFallback } from "@/components/core/app-error-fallback";
import { captureRendererException } from "@/lib/sentry";
import { rootRoute } from "@/routes/root";
import { createRoute, ErrorComponentProps, Outlet } from "@tanstack/react-router";

function AuthError({ error, reset }: ErrorComponentProps) {
  captureRendererException(error, {
    href: window.location.href,
    boundary: "router-auth",
  });

  return <AppErrorFallback error={error} resetErrorBoundary={reset} variant="app" />;
}

/**
 * Public route group for authentication pages.
 * No authentication validation - completely public routes.
 */
export const _authRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/auth",
  component: () => <Outlet />,
  errorComponent: AuthError,
});
