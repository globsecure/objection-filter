import { AppErrorFallback } from "@/components/core/app-error-fallback";
import { ROUTES } from "@/lib/constants";
import { captureRendererException } from "@/lib/sentry";
import { ensureOnboardingState } from "@/systems/onboarding/lib/ensure-onboarding-state";
import { createRoute, ErrorComponentProps, Outlet, redirect } from "@tanstack/react-router";
import { _appRoute } from "./_app";

function WithOnboardingError({ error, reset }: ErrorComponentProps) {
  captureRendererException(error, {
    href: window.location.href,
    boundary: "router-with-onboarding",
  });

  return <AppErrorFallback error={error} resetErrorBoundary={reset} variant="section" />;
}

/**
 * Route guard that manages onboarding state.
 * Authentication is handled by parent _appRoute.
 * Redirects to onboarding if user doesn't have organization.
 */
export const withOnboardingRoute = createRoute({
  getParentRoute: () => _appRoute,
  id: "_with-onboarding",
  beforeLoad: async ({ location, context }) => {
    if (location.pathname === ROUTES.ONBOARDING) {
      return {};
    }

    const state = await ensureOnboardingState(context.queryClient);

    if (!state.hasOrganization) {
      throw redirect({
        to: ROUTES.ONBOARDING,
      });
    }

    return { onboardingState: state };
  },
  component: () => <Outlet />,
  errorComponent: WithOnboardingError,
});
