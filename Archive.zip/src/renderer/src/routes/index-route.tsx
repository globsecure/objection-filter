import { ROUTES } from "@/lib/constants";
import { ensureOnboardingState } from "@/systems/onboarding/lib/ensure-onboarding-state";
import { createRoute, redirect } from "@tanstack/react-router";
import { _appRoute } from "./_app";

export const indexRoute = createRoute({
  getParentRoute: () => _appRoute,
  path: "/",
  beforeLoad: async ({ context, location }) => {
    const state = await ensureOnboardingState(context.queryClient);

    if (!state.isAuthenticated) {
      throw redirect({
        to: ROUTES.AUTH.SIGN_IN,
        search: {
          redirect: location.href,
        },
      });
    }

    if (!state.hasOrganization) {
      throw redirect({
        to: ROUTES.ONBOARDING,
      });
    }

    throw redirect({
      to: ROUTES.ISSUES,
    });
  },
});
