import { AppErrorFallback } from "@/components/core/app-error-fallback";
import { AppLayout } from "@/components/core/app-layout";
import { ROUTES } from "@/lib/constants";
import { captureRendererException } from "@/lib/sentry";
import { rootRoute } from "@/routes/root";
import { requireLocalAuth } from "@/systems/auth/guards/route-guards";
import { useBackgroundSessionValidation } from "@/systems/auth/hooks/use-background-session-validation";
import { sessionQueryOptions } from "@/systems/auth/hooks/use-session";
import { ensureOnboardingState } from "@/systems/onboarding/lib/ensure-onboarding-state";
import { createRoute, ErrorComponentProps, Outlet, redirect } from "@tanstack/react-router";

function AppError({ error, reset }: ErrorComponentProps) {
  captureRendererException(error, {
    href: window.location.href,
    boundary: "router-app",
  });

  return <AppErrorFallback error={error} resetErrorBoundary={reset} variant="section" />;
}

function AppComponent() {
  useBackgroundSessionValidation();

  return (
    <AppLayout>
      <Outlet />
    </AppLayout>
  );
}

export const _appRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/app",
  loader: async ({ context }) => {
    // Prefetch session data before components render to prevent loading glitch
    await context.queryClient.ensureQueryData(sessionQueryOptions);
  },
  beforeLoad: async ({ location, context }) => {
    const isIndexHtmlLocation =
      location.pathname === "/index.html" || location.pathname.endsWith("/index.html");

    if (isIndexHtmlLocation) {
      await requireLocalAuth({ queryClient: context.queryClient, location });
      throw redirect({ to: ROUTES.HOME, replace: true });
    }

    await requireLocalAuth({ queryClient: context.queryClient, location });
    const isOnboardingRoute = location.pathname === ROUTES.ONBOARDING;
    const isCreateOrgRoute = location.pathname === ROUTES.ORGANIZATIONS.CREATE;

    if (!isOnboardingRoute && !isCreateOrgRoute) {
      const state = await ensureOnboardingState(context.queryClient);

      if (!state.isAuthenticated) {
        throw redirect({
          to: ROUTES.AUTH.SIGN_IN,
          search: {
            redirect: location.href,
          },
        });
      }

      if (!state.hasOrganization) {
        throw redirect({
          to: ROUTES.ONBOARDING,
        });
      }
    }

    // Handle redirect for exact /app path (indexRoute only matches /app/ with trailing slash)
    if (location.pathname === "/app") {
      throw redirect({ to: ROUTES.ISSUES });
    }

    return {};
  },
  component: AppComponent,
  errorComponent: AppError,
});
