/**
 * Type exports for Looper hooks
 * Re-exports types from @looper/types for convenience
 * Uses browser-safe types export to avoid bundling Node.js code
 */

// Re-export Looper types for convenience
export type {
  LooperAPI,
  JobStatus,
  RunnerOptions,
  LogChunk,
  IssueContext,
  Provider,
  OptionsForId,
} from "@looper/types";
