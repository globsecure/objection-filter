import * as React from "react";

type DragState = {
  isDragging: boolean;
  isManualDrag: boolean;
  windowOffsetX: number;
  windowOffsetY: number;
};

export function useWindowDrag() {
  const [isDragging, setIsDragging] = React.useState(false);
  const dragStateRef = React.useRef<DragState | null>(null);

  const handleMouseMove = React.useCallback((event: MouseEvent) => {
    const state = dragStateRef.current;
    if (!state?.isManualDrag) return;

    const newX = event.screenX - state.windowOffsetX;
    const newY = event.screenY - state.windowOffsetY;

    void window.api?.windowControls?.updatePosition(newX, newY);
  }, []);

  const handleMouseUp = React.useCallback(() => {
    dragStateRef.current = null;
    setIsDragging(false);

    document.removeEventListener("mousemove", handleMouseMove);
    document.removeEventListener("mouseup", handleMouseUp);
  }, [handleMouseMove]);

  const startDrag = React.useCallback(
    async (event: React.MouseEvent) => {
      const api = window.api?.windowControls;
      if (!api) return;

      const state = await api.getState();

      // If not maximized or is fullscreen, let native drag handle it
      if (!state.isMaximized || state.isFullScreen) {
        return;
      }

      // For maximized windows, start manual drag
      event.preventDefault();

      const cursorX = event.screenX;
      const cursorY = event.screenY;
      const dragPointX = event.clientX;

      const result = await api.startDrag({ cursorX, cursorY, dragPointX });

      if (result.wasMaximized) {
        dragStateRef.current = {
          isDragging: true,
          isManualDrag: true,
          windowOffsetX: cursorX - result.newBounds.x,
          windowOffsetY: cursorY - result.newBounds.y,
        };
        setIsDragging(true);

        document.addEventListener("mousemove", handleMouseMove);
        document.addEventListener("mouseup", handleMouseUp);
      }
    },
    [handleMouseMove, handleMouseUp]
  );

  React.useEffect(() => {
    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    };
  }, [handleMouseMove, handleMouseUp]);

  return { isDragging, startDrag };
}
