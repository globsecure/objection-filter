import { useEffect } from "react";
import type { RefObject } from "react";

type WindowControlsOverlayLike = {
  ongeometrychange: ((event: unknown) => void) | null;
};

function getWindowControlsOverlay(): WindowControlsOverlayLike | undefined {
  if (typeof navigator === "undefined") return undefined;
  return (navigator as unknown as { windowControlsOverlay?: WindowControlsOverlayLike })
    .windowControlsOverlay;
}

function getTitleBarOverlayColors(): { color: string; symbolColor: string } {
  const bodyStyle = typeof window !== "undefined" ? window.getComputedStyle(document.body) : null;
  const rootStyle =
    typeof window !== "undefined" ? window.getComputedStyle(document.documentElement) : null;

  const bodyBackground = bodyStyle?.backgroundColor?.trim();
  const rootBackground = rootStyle?.backgroundColor?.trim();

  const color =
    bodyBackground && bodyBackground !== "rgba(0, 0, 0, 0)" ? bodyBackground : rootBackground || "";

  const bodyColor = bodyStyle?.color?.trim();
  const rootColor = rootStyle?.color?.trim();
  const symbolColor = bodyColor || rootColor || "";

  return {
    color: color || "rgba(0, 0, 0, 0)",
    symbolColor: symbolColor || "#ffffff",
  };
}

export function useTitleBarOverlay(containerRef: RefObject<HTMLElement | null>): void {
  useEffect(() => {
    if (typeof window === "undefined") return;
    const overlay = getWindowControlsOverlay();
    const api = window.api?.windowControls;

    if (!overlay || !api?.setTitleBarOverlay) return;

    let rafId: number | null = null;

    const syncOverlay = () => {
      if (rafId != null) return;
      rafId = window.requestAnimationFrame(() => {
        rafId = null;

        const el = containerRef.current;
        if (!el) return;
        const rect = el.getBoundingClientRect();
        const height = Math.round(rect.height);
        if (!Number.isFinite(height) || height <= 0) return;

        const { color, symbolColor } = getTitleBarOverlayColors();
        void api.setTitleBarOverlay({ color, symbolColor, height });
      });
    };

    // Initial sync once we have geometry + DOM.
    syncOverlay();

    overlay.ongeometrychange = () => {
      syncOverlay();
    };

    const classObserver = new MutationObserver(() => {
      syncOverlay();
    });
    classObserver.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class"],
    });

    const resizeObserver =
      typeof ResizeObserver !== "undefined"
        ? new ResizeObserver(() => {
            syncOverlay();
          })
        : null;

    if (resizeObserver && containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }

    const handleWindowResize = () => syncOverlay();
    window.addEventListener("resize", handleWindowResize);

    return () => {
      if (rafId != null) {
        window.cancelAnimationFrame(rafId);
      }
      overlay.ongeometrychange = null;
      classObserver.disconnect();
      resizeObserver?.disconnect();
      window.removeEventListener("resize", handleWindowResize);
    };
  }, [containerRef]);
}
