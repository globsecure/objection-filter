import { useEffect, useRef } from "react";

/**
 * A hook that stores and returns the previous value of a given variable.
 * Useful for comparing current and previous values to detect changes.
 *
 * @param value - The value to track
 * @returns The previous value (undefined on first render)
 */
export function usePrevious<T>(value: T): T | undefined {
  const ref = useRef<T | undefined>(undefined);
  useEffect(() => {
    ref.current = value;
  });
  return ref.current;
}
