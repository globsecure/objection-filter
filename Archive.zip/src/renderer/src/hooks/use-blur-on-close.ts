import { useEffect, type RefObject } from "react";

function blurFocusedInContainer(container: HTMLElement): void {
  const focusedElement = container.querySelector(":focus");
  if (focusedElement instanceof HTMLElement) {
    focusedElement.blur();
  }
  if (document.activeElement && container.contains(document.activeElement)) {
    (document.activeElement as HTMLElement).blur();
  }
}

/**
 * Blurs any focused elements within a container when `isOpen` becomes false.
 * Useful for clearing focus-within state after a dialog or popover closes.
 *
 * @param containerRef - Reference to the container element to check for focused children.
 * @param isOpen - Whether the dialog/popover is open. Blur triggers when this becomes false.
 */
export function useBlurOnClose(containerRef: RefObject<HTMLElement | null>, isOpen: boolean): void {
  useEffect(() => {
    if (!isOpen && containerRef.current) {
      // Use setTimeout to ensure blur happens after dialog closes and focus returns
      setTimeout(() => {
        if (containerRef.current) {
          blurFocusedInContainer(containerRef.current);
        }
      }, 0);
    }
  }, [isOpen]);
}

/**
 * Blurs any focused elements within a container immediately (for event handlers).
 *
 * @param containerRef - Reference to the container element to check for focused children.
 */
export function blurContainedElements(containerRef: RefObject<HTMLElement | null>): void {
  setTimeout(() => {
    if (containerRef.current) {
      blurFocusedInContainer(containerRef.current);
    }
  }, 0);
}
