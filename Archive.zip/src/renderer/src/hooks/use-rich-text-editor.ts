import { htmlToMarkdown, markdownToHtml } from "@/lib/utils/markdown";
import { SearchAndReplace } from "@sereneinserenade/tiptap-search-and-replace";
import Highlight from "@tiptap/extension-highlight";
import Image from "@tiptap/extension-image";
import Link from "@tiptap/extension-link";
import Placeholder from "@tiptap/extension-placeholder";
import TaskItem from "@tiptap/extension-task-item";
import TaskList from "@tiptap/extension-task-list";
import TextAlign from "@tiptap/extension-text-align";
import Underline from "@tiptap/extension-underline";
import { useEditor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import CodeBlockShiki from "tiptap-extension-code-block-shiki";

export interface UseRichTextEditorOptions {
  initialContent: string;
  placeholder?: string;
  onSave?: (markdown: string) => Promise<void> | void;
  isSaving?: boolean;
  isOpen?: boolean;
}

export interface UseRichTextEditorReturn {
  editor: ReturnType<typeof useEditor> | null;
  hasChanges: boolean;
  save: () => Promise<void>;
  resetChanges: () => void;
  getMarkdown: () => string;
}

const EDITOR_CLASSNAME = "tiptap not-prose max-w-none min-h-[500px] focus:outline-none";
const CODE_BLOCK_THEMES = {
  light: "vitesse-light",
  dark: "vitesse-dark",
} as const;

function createExtensions(placeholder: string) {
  return [
    StarterKit.configure({
      bulletList: { keepMarks: true, keepAttributes: false },
      orderedList: { keepMarks: true, keepAttributes: false },
      codeBlock: false,
    }),
    CodeBlockShiki.configure({
      defaultTheme: CODE_BLOCK_THEMES.dark,
      themes: CODE_BLOCK_THEMES,
    }),
    TextAlign.configure({ types: ["heading", "paragraph"] }),
    Highlight.configure({ multicolor: true }),
    Underline,
    Link.configure({ openOnClick: false, HTMLAttributes: { class: "text-primary underline" } }),
    Image.configure({ inline: true, allowBase64: true }),
    TaskList,
    TaskItem.configure({ nested: true }),
    Placeholder.configure({ placeholder }),
    SearchAndReplace.configure({
      searchResultClass: "search-result",
      disableRegex: false,
    }),
  ];
}

function useBeforeUnloadWarning(hasChanges: boolean) {
  useEffect(() => {
    if (!hasChanges) return;
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = "You have unsaved changes. Are you sure you want to leave?";
      return e.returnValue;
    };
    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => window.removeEventListener("beforeunload", handleBeforeUnload);
  }, [hasChanges]);
}

function useSaveShortcut({
  hasChanges,
  isSaving,
  onSave,
  save,
}: {
  hasChanges: boolean;
  isSaving: boolean;
  onSave?: (markdown: string) => Promise<void> | void;
  save: () => Promise<void>;
}) {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "s") {
        e.preventDefault();
        if (hasChanges && !isSaving && onSave) {
          save();
        }
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [hasChanges, isSaving, save, onSave]);
}

export function useRichTextEditor({
  initialContent,
  placeholder = "Start writing...",
  onSave,
  isSaving = false,
  isOpen = true,
}: UseRichTextEditorOptions): UseRichTextEditorReturn {
  const [hasChanges, setHasChanges] = useState(false);
  const isInitializing = useRef(true);
  const initialHtml = useMemo(() => markdownToHtml(initialContent), [initialContent]);
  const extensions = useMemo(() => createExtensions(placeholder), [placeholder]);
  const editor = useEditor({
    extensions,
    content: initialHtml,
    immediatelyRender: false,
    editorProps: {
      attributes: {
        class: EDITOR_CLASSNAME,
      },
    },
    onCreate: () => {
      isInitializing.current = false;
    },
    onUpdate: () => {
      if (!isInitializing.current) {
        setHasChanges(true);
      }
    },
  });
  useEffect(() => {
    if (!editor || !isOpen) return;
    isInitializing.current = true;
    editor.commands.setContent(initialHtml, { emitUpdate: false });
    setHasChanges(false);
    requestAnimationFrame(() => {
      isInitializing.current = false;
    });
  }, [editor, initialHtml, isOpen]);
  useBeforeUnloadWarning(hasChanges);
  const getMarkdown = useCallback(() => {
    if (!editor) return "";
    return htmlToMarkdown(editor.getHTML());
  }, [editor]);
  const save = useCallback(async () => {
    if (!editor || !onSave) return;
    const markdown = getMarkdown();
    await onSave(markdown);
    setHasChanges(false);
  }, [editor, onSave, getMarkdown]);
  const resetChanges = useCallback(() => {
    setHasChanges(false);
  }, []);
  useSaveShortcut({ hasChanges, isSaving, onSave, save });
  return {
    editor,
    hasChanges,
    save,
    resetChanges,
    getMarkdown,
  };
}
