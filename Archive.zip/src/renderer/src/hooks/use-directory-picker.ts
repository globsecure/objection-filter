import { useCallback, useState } from "react";

type UseDirectoryPickerOptions = {
  onPathSelected: (path: string) => void;
  onSelectionError?: (message: string) => void;
};

type UseDirectoryPickerReturn = {
  isSelecting: boolean;
  handleSelectDirectory: () => Promise<void>;
};

export function useDirectoryPicker(options: UseDirectoryPickerOptions): UseDirectoryPickerReturn {
  const [isSelecting, setIsSelecting] = useState(false);
  const { onPathSelected, onSelectionError } = options;

  const handleSelectDirectory = useCallback(async () => {
    try {
      setIsSelecting(true);
      const selectedPath = await window.api.selectDirectory();
      if (!selectedPath) {
        setIsSelecting(false);
        return;
      }
      onPathSelected(selectedPath);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to select directory";
      onSelectionError?.(message);
    } finally {
      setIsSelecting(false);
    }
  }, [onPathSelected, onSelectionError]);

  return {
    isSelecting,
    handleSelectDirectory,
  };
}
