import type {
  JSONValue,
  LanguageModelV2,
  LanguageModelV2CallWarning,
  LanguageModelV2FinishReason,
  LanguageModelV2StreamPart,
  LanguageModelV2Usage,
} from "@ai-sdk/provider";
import { APICallError, LoadAPIKeyError, NoSuchModelError } from "@ai-sdk/provider";
import { generateId } from "@ai-sdk/provider-utils";
import { convertToClaudeCodeMessages } from "./convert-to-claude-code-messages.js";
import {
  createAPICallError,
  createAuthenticationError,
  createTimeoutError,
  type ClaudeCodeErrorMetadata,
} from "./errors.js";
import { createVerboseLogger, getLogger } from "./logger.js";
import { mapClaudeCodeFinishReason } from "./map-claude-code-finish-reason.js";
import type { ClaudeCodeSettings, Logger } from "./types.js";
import { validateModelId, validatePrompt, validateSessionId } from "./validation.js";

import type { SDKPartialAssistantMessage, SDKUserMessage } from "@anthropic-ai/claude-agent-sdk";
import { query, type Options } from "@anthropic-ai/claude-agent-sdk";
import { compact, head } from "es-toolkit/array";
import truncate from "es-toolkit/compat/truncate";
import { trim } from "es-toolkit/string";

const CLAUDE_CODE_TRUNCATION_WARNING =
  "Claude Code SDK output ended unexpectedly; returning truncated response from buffered text. Await upstream fix to avoid data loss.";

const MIN_TRUNCATION_LENGTH = 512;

const MAX_STDERR_BUFFER_LENGTH = 4000;

/**
 * Detects if an error represents a truncated SDK JSON stream.
 *
 * The Claude Code SDK can truncate JSON responses mid-stream, producing a SyntaxError.
 * This function distinguishes genuine truncation from normal JSON syntax errors by:
 * 1. Verifying the error is a SyntaxError with truncation-specific messages
 * 2. Ensuring we received meaningful content (>= MIN_TRUNCATION_LENGTH characters)
 * 3. Avoiding false positives from unrelated parse errors
 *
 * Note: We compare against `bufferedText` (assistant text content) rather than the raw
 * JSON buffer length, since the SDK layer doesn't expose buffer positions. The position
 * reported in SyntaxError messages measures the full JSON payload (metadata + content),
 * which is typically much larger than extracted text. Therefore, we cannot reliably use
 * position proximity checks and instead rely on message patterns and content length.
 *
 * @param error - The caught error (expected to be SyntaxError for truncation)
 * @param bufferedText - Accumulated assistant text content (measured in UTF-16 code units)
 * @returns true if error indicates SDK truncation; false otherwise
 */
function isClaudeCodeTruncationError(error: unknown, bufferedText: string): boolean {
  // Check for SyntaxError by instanceof or by name (for cross-realm errors)
  const isSyntaxError =
    error instanceof SyntaxError ||
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (typeof (error as any)?.name === "string" &&
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (error as any).name.toLowerCase() === "syntaxerror");

  if (!isSyntaxError) {
    return false;
  }

  if (!bufferedText) {
    return false;
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const rawMessage = typeof (error as any)?.message === "string" ? (error as any).message : "";
  const message = rawMessage.toLowerCase();

  // Only match actual truncation patterns, not normal JSON parsing errors.
  // Real truncation: "Unexpected end of JSON input" or "Unterminated string in JSON..."
  // Normal errors: "Unexpected token X in JSON at position N" (should be surfaced as errors)
  const truncationIndicators = [
    "unexpected end of json input",
    "unexpected end of input",
    "unexpected end of string",
    "unexpected eof",
    "end of file",
    "unterminated string",
    "unterminated string constant",
  ];

  if (!truncationIndicators.some(indicator => message.includes(indicator))) {
    return false;
  }

  // Require meaningful content before treating as truncation.
  // Short responses with "end of input" errors are likely genuine syntax errors.
  // Note: bufferedText.length measures UTF-16 code units, not byte length.
  if (bufferedText.length < MIN_TRUNCATION_LENGTH) {
    return false;
  }

  // If we have a truncation indicator AND meaningful content, treat as truncation.
  return true;
}

function isAbortError(err: unknown): boolean {
  if (err && typeof err === "object") {
    const e = err as { name?: unknown; code?: unknown };
    if (typeof e.name === "string" && e.name === "AbortError") return true;
    if (typeof e.code === "string" && e.code.toUpperCase() === "ABORT_ERR") return true;
  }
  return false;
}

const STREAMING_FEATURE_WARNING =
  "Claude Agent SDK features (hooks/MCP/images) require streaming input. Set `streamingInput: 'always'` or provide `canUseTool` (auto streams only when canUseTool is set).";

type ClaudeToolUse = {
  id: string;
  name: string;
  input: unknown;
};

type ClaudeToolResult = {
  id: string;
  name?: string;
  result: unknown;
  isError: boolean;
  structuredContent?: unknown;
};

type StderrBuffer = {
  append: (chunk: string) => void;
  value: () => string;
};

const createStderrBuffer = (): StderrBuffer => {
  let buffer = "";
  return {
    append: (chunk: string) => {
      if (!chunk) return;
      buffer += chunk;
      if (buffer.length > MAX_STDERR_BUFFER_LENGTH) {
        buffer = buffer.slice(buffer.length - MAX_STDERR_BUFFER_LENGTH);
      }
    },
    value: () => buffer,
  };
};

// Provider extension for tool-error stream parts.
type ToolErrorPart = {
  type: "tool-error";
  toolCallId: string;
  toolName: string;
  error: string;
  providerExecuted: true;
  providerMetadata?: Record<string, JSONValue>;
};

type ToolArtifactPart = {
  type: "tool-artifact";
  tool: string;
  id: string;
  data: unknown;
};

// Local extension of the AI SDK stream part union to include tool-error.
type ExtendedStreamPart = LanguageModelV2StreamPart | ToolErrorPart | ToolArtifactPart;

/**
 * Tracks the streaming lifecycle state for a single tool invocation.
 *
 * The tool streaming lifecycle follows this sequence:
 * 1. Tool use detected → state created with all flags false
 * 2. First input seen → `inputStarted` = true, emit `tool-input-start`
 * 3. Input deltas streamed → emit `tool-input-delta` (may be skipped for large/non-prefix updates)
 * 4. Input finalized → `inputClosed` = true, emit `tool-input-end`
 * 5. Tool call formed → `callEmitted` = true, emit `tool-call`
 * 6. Tool results/errors arrive → emit `tool-result` or `tool-error` (may occur multiple times)
 * 7. Stream ends → state cleaned up by `finalizeToolCalls()`
 *
 * @property name - Tool name from SDK (e.g., "Bash", "Read")
 * @property lastSerializedInput - Most recent serialized input, used for delta calculation
 * @property inputStarted - True after `tool-input-start` emitted; prevents duplicate start events
 * @property inputClosed - True after `tool-input-end` emitted; ensures proper event ordering
 * @property callEmitted - True after `tool-call` emitted; prevents duplicate call events when
 *                         multiple result/error chunks arrive for the same tool invocation
 */
type ToolStreamState = {
  name: string;
  lastSerializedInput?: string;
  inputStarted: boolean;
  inputClosed: boolean;
  callEmitted: boolean;
};

function toAsyncIterablePrompt(
  messagesPrompt: string,
  outputStreamEnded: Promise<unknown>,
  sessionId?: string,
  contentParts?: SDKUserMessage["message"]["content"]
): AsyncIterable<SDKUserMessage> {
  const content = (
    contentParts && contentParts.length > 0
      ? contentParts
      : [{ type: "text", text: messagesPrompt }]
  ) as SDKUserMessage["message"]["content"];

  const msg: SDKUserMessage = {
    type: "user",
    message: {
      role: "user",
      content,
    },
    parent_tool_use_id: null,
    session_id: sessionId ?? "",
  };
  return {
    async *[Symbol.asyncIterator]() {
      yield msg;
      await outputStreamEnded;
    },
  };
}

/**
 * Options for creating a Claude Code language model instance.
 *
 * @example
 * ```typescript
 * // Using Opus 4.5 (most capable)
 * const model = new ClaudeCodeLanguageModel({
 *   id: 'opus',
 *   settings: {
 *     maxTurns: 10,
 *     permissionMode: 'auto'
 *   }
 * });
 * ```
 */
export interface ClaudeCodeLanguageModelOptions {
  /**
   * The model identifier to use.
   * Can be 'opus', 'sonnet', 'haiku', or a custom model string.
   */
  id: ClaudeCodeModelId;

  /**
   * Optional settings to configure the model behavior.
   */
  settings?: ClaudeCodeSettings;

  /**
   * Validation warnings from settings validation.
   * Used internally to pass warnings from provider.
   */
  settingsValidationWarnings?: string[];
}

/**
 * Supported Claude model identifiers.
 * - 'opus': Claude Opus (most capable)
 * - 'sonnet': Claude Sonnet (balanced performance)
 * - 'haiku': Claude Haiku (fastest, most cost-effective)
 * - Custom string: Any full model identifier (e.g., 'claude-opus-4-5', 'claude-sonnet-4-5-20250514')
 *
 * @example
 * ```typescript
 * const opusModel = claudeCode('opus');
 * const sonnetModel = claudeCode('sonnet');
 * const haikuModel = claudeCode('haiku');
 * const customModel = claudeCode('claude-opus-4-5');
 * ```
 */
export type ClaudeCodeModelId = "opus" | "sonnet" | "haiku" | (string & {});

const modelMap: Record<string, string> = {
  opus: "opus",
  sonnet: "sonnet",
  haiku: "haiku",
};

/**
 * Language model implementation for Claude Code SDK.
 * This class implements the AI SDK's LanguageModelV2 interface to provide
 * integration with Claude models through the Claude Agent SDK.
 *
 * Features:
 * - Supports streaming and non-streaming generation
 * - Native structured outputs via SDK's outputFormat (guaranteed schema compliance)
 * - Manages CLI sessions for conversation continuity
 * - Provides detailed error handling and retry logic
 *
 * Limitations:
 * - Image inputs require streaming mode
 * - Some parameters like temperature and max tokens are not supported by the CLI
 *
 * @example
 * ```typescript
 * const model = new ClaudeCodeLanguageModel({
 *   id: 'opus',
 *   settings: { maxTurns: 5 }
 * });
 *
 * const result = await model.doGenerate({
 *   prompt: [{ role: 'user', content: [{ type: 'text', text: 'Hello!' }] }],
 * });
 * ```
 */
export class ClaudeCodeLanguageModel implements LanguageModelV2 {
  readonly specificationVersion = "v2" as const;
  readonly defaultObjectGenerationMode = "json" as const;
  readonly supportsImageUrls = false;
  readonly supportedUrls = {};
  readonly supportsStructuredOutputs = true;

  // Fallback/magic string constants
  static readonly UNKNOWN_TOOL_NAME = "unknown-tool";

  // Tool input safety limits
  private static readonly MAX_TOOL_INPUT_SIZE = 1_048_576; // 1MB hard limit
  private static readonly MAX_TOOL_INPUT_WARN = 102_400; // 100KB warning threshold
  private static readonly MAX_DELTA_CALC_SIZE = 10_000; // 10KB delta computation threshold

  readonly modelId: ClaudeCodeModelId;
  readonly settings: ClaudeCodeSettings;

  private sessionId?: string;
  private modelValidationWarning?: string;
  private settingsValidationWarnings: string[];
  private logger: Logger;

  constructor(options: ClaudeCodeLanguageModelOptions) {
    this.modelId = options.id;
    this.settings = options.settings ?? {};
    this.settingsValidationWarnings = options.settingsValidationWarnings ?? [];

    // Create logger that respects verbose setting
    const baseLogger = getLogger(this.settings.logger);
    this.logger = createVerboseLogger(baseLogger, this.settings.verbose ?? false);

    // Validate model ID format
    if (!this.modelId || typeof this.modelId !== "string" || this.modelId.trim() === "") {
      throw new NoSuchModelError({
        modelId: this.modelId,
        modelType: "languageModel",
      });
    }

    // Additional model ID validation
    const warning = validateModelId(this.modelId);
    if (warning !== undefined) {
      this.modelValidationWarning = warning;
      this.logger.warn(`Claude Code Model: ${warning}`);
    }
  }

  get provider(): string {
    return "claude-code";
  }

  private getModel(): string {
    const mapped = modelMap[this.modelId];
    return mapped ?? this.modelId;
  }

  private extractToolUses(content: unknown): ClaudeToolUse[] {
    if (!Array.isArray(content)) {
      return [];
    }

    return content
      .filter(
        (item): item is { type: string; id?: unknown; name?: unknown; input?: unknown } =>
          typeof item === "object" &&
          item !== null &&
          "type" in item &&
          (item as { type: unknown }).type === "tool_use"
      )
      .map(item => {
        const { id, name, input } = item as {
          id?: unknown;
          name?: unknown;
          input?: unknown;
        };
        return {
          id: typeof id === "string" && id.length > 0 ? id : generateId(),
          name:
            typeof name === "string" && name.length > 0
              ? name
              : ClaudeCodeLanguageModel.UNKNOWN_TOOL_NAME,
          input,
        } satisfies ClaudeToolUse;
      });
  }

  private extractToolResults(content: unknown): ClaudeToolResult[] {
    if (!Array.isArray(content)) {
      return [];
    }

    return content
      .filter(
        (
          item
        ): item is {
          type: string;
          tool_use_id?: unknown;
          content?: unknown;
          is_error?: unknown;
          name?: unknown;
          structured_content?: unknown;
          structuredContent?: unknown;
        } =>
          typeof item === "object" &&
          item !== null &&
          "type" in item &&
          (item as { type: unknown }).type === "tool_result"
      )
      .map(item => {
        const { tool_use_id, content, is_error, name, structured_content, structuredContent } =
          item;

        let extractedStructuredContent: unknown = structuredContent ?? structured_content;

        if (!extractedStructuredContent && Array.isArray(content) && content.length > 0) {
          const firstContent = content[0] as { type?: string; text?: string };
          if (firstContent?.type === "text" && typeof firstContent.text === "string") {
            try {
              const parsed = JSON.parse(firstContent.text);
              if (parsed !== null && typeof parsed === "object") {
                extractedStructuredContent = parsed;
              }
            } catch {
              // ignore invalid JSON payloads
            }
          }
        }
        const result: ClaudeToolResult = {
          id:
            typeof tool_use_id === "string" && tool_use_id.length > 0 ? tool_use_id : generateId(),
          result: content,
          isError: Boolean(is_error),
          ...(extractedStructuredContent !== undefined && {
            structuredContent: extractedStructuredContent,
          }),
        };
        if (typeof name === "string" && name.length > 0) {
          result.name = name;
        }
        return result;
      });
  }

  private extractToolErrors(content: unknown): Array<{
    id: string;
    name?: string;
    error: unknown;
  }> {
    if (!Array.isArray(content)) {
      return [];
    }

    return content
      .filter(
        (
          item
        ): item is {
          type: string;
          tool_use_id?: unknown;
          error?: unknown;
          name?: unknown;
        } =>
          typeof item === "object" &&
          item !== null &&
          "type" in item &&
          (item as { type: unknown }).type === "tool_error"
      )
      .map(item => {
        const { tool_use_id, error, name } = item as {
          tool_use_id?: unknown;
          error?: unknown;
          name?: unknown;
        };
        const result: { id: string; name?: string; error: unknown } = {
          id:
            typeof tool_use_id === "string" && tool_use_id.length > 0 ? tool_use_id : generateId(),
          error,
        };
        if (typeof name === "string" && name.length > 0) {
          result.name = name;
        }
        return result;
      });
  }

  private serializeToolInput(input: unknown): string {
    if (typeof input === "string") {
      return this.checkInputSize(input);
    }

    if (input === undefined) {
      return "";
    }

    try {
      const serialized = JSON.stringify(input);
      return this.checkInputSize(serialized);
    } catch {
      const fallback = String(input);
      return this.checkInputSize(fallback);
    }
  }

  private checkInputSize(str: string): string {
    const length = str.length;

    if (length > ClaudeCodeLanguageModel.MAX_TOOL_INPUT_SIZE) {
      throw new Error(
        `Tool input exceeds maximum size of ${ClaudeCodeLanguageModel.MAX_TOOL_INPUT_SIZE} bytes (got ${length} bytes). This may indicate a malformed request or an attempt to process excessively large data.`
      );
    }

    if (length > ClaudeCodeLanguageModel.MAX_TOOL_INPUT_WARN) {
      this.logger.warn(
        `[claude-code] Large tool input detected: ${length} bytes. Performance may be impacted. Consider chunking or reducing input size.`
      );
    }

    return str;
  }

  private normalizeToolResult(result: unknown): unknown {
    if (typeof result === "string") {
      try {
        return JSON.parse(result);
      } catch {
        return result;
      }
    }

    return result;
  }

  private generateAllWarnings(
    options:
      | Parameters<LanguageModelV2["doGenerate"]>[0]
      | Parameters<LanguageModelV2["doStream"]>[0],
    prompt: string
  ): LanguageModelV2CallWarning[] {
    const warnings: LanguageModelV2CallWarning[] = [];
    const unsupportedParams: string[] = [];

    // Check for unsupported parameters
    if (options.temperature !== undefined) unsupportedParams.push("temperature");
    if (options.topP !== undefined) unsupportedParams.push("topP");
    if (options.topK !== undefined) unsupportedParams.push("topK");
    if (options.presencePenalty !== undefined) unsupportedParams.push("presencePenalty");
    if (options.frequencyPenalty !== undefined) unsupportedParams.push("frequencyPenalty");
    if (options.stopSequences !== undefined && options.stopSequences.length > 0)
      unsupportedParams.push("stopSequences");
    if (options.seed !== undefined) unsupportedParams.push("seed");

    if (unsupportedParams.length > 0) {
      // Add a warning for each unsupported parameter
      for (const param of unsupportedParams) {
        warnings.push({
          type: "unsupported-setting",
          setting: param as
            | "temperature"
            | "maxTokens"
            | "topP"
            | "topK"
            | "presencePenalty"
            | "frequencyPenalty"
            | "stopSequences"
            | "seed",
          details: `Claude Code SDK does not support the ${param} parameter. It will be ignored.`,
        });
      }
    }

    // Warn if JSON response format is requested without a schema
    // Claude Code only supports structured outputs with schemas (like Anthropic's API)
    if (options.responseFormat?.type === "json" && !options.responseFormat.schema) {
      warnings.push({
        type: "unsupported-setting",
        setting: "responseFormat",
        details:
          "JSON response format requires a schema for the Claude Code provider. The JSON responseFormat is ignored and the call is treated as plain text.",
      });
    }

    // Add model validation warning if present
    if (this.modelValidationWarning) {
      warnings.push({
        type: "other",
        message: this.modelValidationWarning,
      });
    }

    // Add settings validation warnings
    this.settingsValidationWarnings.forEach(warning => {
      warnings.push({
        type: "other",
        message: warning,
      });
    });

    // Validate prompt
    const promptWarning = validatePrompt(prompt);
    if (promptWarning) {
      warnings.push({
        type: "other",
        message: promptWarning,
      });
    }

    return warnings;
  }

  private createQueryOptions(
    abortController: AbortController,
    responseFormat: Parameters<LanguageModelV2["doGenerate"]>[0]["responseFormat"] | undefined,
    stderrBuffer?: StderrBuffer
  ): Options {
    const opts: Partial<Options> & Record<string, unknown> = {
      model: this.getModel(),
      abortController,
    };
    const resume = this.settings.resume ?? this.sessionId;
    if (resume !== undefined) {
      opts.resume = resume;
    }
    if (this.settings.pathToClaudeCodeExecutable !== undefined) {
      opts.pathToClaudeCodeExecutable = this.settings.pathToClaudeCodeExecutable;
    }
    if (this.settings.maxTurns !== undefined) {
      opts.maxTurns = this.settings.maxTurns;
    }
    if (this.settings.maxThinkingTokens !== undefined) {
      opts.maxThinkingTokens = this.settings.maxThinkingTokens;
    }
    if (this.settings.cwd !== undefined) {
      opts.cwd = this.settings.cwd;
    }
    if (this.settings.executable !== undefined) {
      opts.executable = this.settings.executable;
    }
    if (this.settings.executableArgs !== undefined) {
      opts.executableArgs = this.settings.executableArgs;
    }
    if (this.settings.permissionMode !== undefined) {
      opts.permissionMode = this.settings.permissionMode;
    }
    if (this.settings.permissionPromptToolName !== undefined) {
      opts.permissionPromptToolName = this.settings.permissionPromptToolName;
    }
    if (this.settings.continue !== undefined) {
      opts.continue = this.settings.continue;
    }
    if (this.settings.allowedTools !== undefined) {
      opts.allowedTools = this.settings.allowedTools;
    }
    if (this.settings.disallowedTools !== undefined) {
      opts.disallowedTools = this.settings.disallowedTools;
    }
    if (this.settings.mcpServers !== undefined) {
      opts.mcpServers = this.settings.mcpServers;
    }
    if (this.settings.canUseTool !== undefined) {
      opts.canUseTool = this.settings.canUseTool;
    }
    // NEW: Agent SDK options with legacy mapping
    if (this.settings.systemPrompt !== undefined) {
      opts.systemPrompt = this.settings.systemPrompt;
    } else if (this.settings.customSystemPrompt !== undefined) {
      // Deprecation warning for legacy field
      this.logger.warn(
        "[claude-code] 'customSystemPrompt' is deprecated and will be removed in a future major release. Please use 'systemPrompt' instead (string or { type: 'preset', preset: 'claude_code', append? })."
      );
      opts.systemPrompt = this.settings.customSystemPrompt;
    } else if (this.settings.appendSystemPrompt !== undefined) {
      // Deprecation warning for legacy field
      this.logger.warn(
        "[claude-code] 'appendSystemPrompt' is deprecated and will be removed in a future major release. Please use 'systemPrompt: { type: 'preset', preset: 'claude_code', append: <text> }' instead."
      );
      opts.systemPrompt = {
        type: "preset",
        preset: "claude_code",
        append: this.settings.appendSystemPrompt,
      } as const;
    }
    if (this.settings.settingSources !== undefined) {
      opts.settingSources = this.settings.settingSources;
    }
    if (this.settings.additionalDirectories !== undefined) {
      opts.additionalDirectories = this.settings.additionalDirectories;
    }
    if (this.settings.agents !== undefined) {
      opts.agents = this.settings.agents;
    }
    if (this.settings.includePartialMessages !== undefined) {
      opts.includePartialMessages = this.settings.includePartialMessages;
    }
    if (this.settings.fallbackModel !== undefined) {
      opts.fallbackModel = this.settings.fallbackModel;
    }
    if (this.settings.forkSession !== undefined) {
      opts.forkSession = this.settings.forkSession;
    }
    if (stderrBuffer) {
      const userStderr = this.settings.stderr;
      opts.stderr = (data: string) => {
        stderrBuffer.append(data);
        userStderr?.(data);
      };
    } else if (this.settings.stderr !== undefined) {
      opts.stderr = this.settings.stderr;
    }
    if (this.settings.strictMcpConfig !== undefined) {
      opts.strictMcpConfig = this.settings.strictMcpConfig;
    }
    if (this.settings.extraArgs !== undefined) {
      opts.extraArgs = this.settings.extraArgs;
    }
    // hooks is supported in newer SDKs; include it if provided
    if (this.settings.hooks) {
      opts.hooks = this.settings.hooks;
    }
    if (this.settings.env !== undefined) {
      opts.env = { ...process.env, ...this.settings.env };
    }

    // Native structured outputs (SDK 0.1.45+)
    if (responseFormat?.type === "json" && responseFormat.schema) {
      opts.outputFormat = {
        type: "json_schema",
        schema: responseFormat.schema as Record<string, unknown>,
      };
    }
    return opts as Options;
  }

  private handleClaudeCodeError(
    error: unknown,
    messagesPrompt: string,
    stderrBuffer?: StderrBuffer
  ): APICallError | LoadAPIKeyError {
    // Handle AbortError from the SDK
    if (isAbortError(error)) {
      // Return the abort reason if available, otherwise the error itself
      throw error;
    }

    // Type guard for error with properties
    const isErrorWithMessage = (err: unknown): err is { message?: string } => {
      return typeof err === "object" && err !== null && "message" in err;
    };

    const isErrorWithCode = (
      err: unknown
    ): err is { code?: string; exitCode?: number; stderr?: string } => {
      return typeof err === "object" && err !== null;
    };

    // Check for authentication errors with improved detection
    const authErrorPatterns = [
      "not logged in",
      "authentication",
      "unauthorized",
      "auth failed",
      "please login",
      "claude login",
    ];

    const rawMessage = isErrorWithMessage(error) && error.message ? error.message : undefined;
    const errorMessage = rawMessage ? rawMessage.toLowerCase() : "";

    const exitCode =
      isErrorWithCode(error) && typeof error.exitCode === "number" ? error.exitCode : undefined;

    const isAuthError =
      authErrorPatterns.some(pattern => errorMessage.includes(pattern)) || exitCode === 401;

    if (isAuthError) {
      return createAuthenticationError({
        message:
          isErrorWithMessage(error) && error.message
            ? error.message
            : "Authentication failed. Please ensure Claude Code SDK is properly authenticated.",
      });
    }

    // Check for timeout errors
    const errorCode = isErrorWithCode(error) && typeof error.code === "string" ? error.code : "";

    if (errorCode === "ETIMEDOUT" || errorMessage.includes("timeout")) {
      return createTimeoutError({
        message: isErrorWithMessage(error) && error.message ? error.message : "Request timed out",
        promptExcerpt: messagesPrompt.substring(0, 200),
        // Don't specify timeoutMs since we don't know the actual timeout value
        // It's controlled by the consumer via AbortSignal
      });
    }

    // Create general API call error with appropriate retry flag
    const isRetryable =
      errorCode === "ENOENT" ||
      errorCode === "ECONNREFUSED" ||
      errorCode === "ETIMEDOUT" ||
      errorCode === "ECONNRESET";

    const stderrFromError =
      isErrorWithCode(error) && typeof error.stderr === "string" ? error.stderr : undefined;
    const bufferedStderr = stderrBuffer?.value();
    const stderr =
      stderrFromError ?? (bufferedStderr && bufferedStderr !== "" ? bufferedStderr : undefined);
    const stderrTrimmed = stderr ? trim(stderr) : "";
    const stderrSnippet =
      stderrTrimmed !== "" ? truncate(stderrTrimmed, { length: 500, omission: "..." }) : undefined;

    const detailSegments = compact([
      errorCode ? `code ${errorCode}` : undefined,
      exitCode !== undefined ? `exit code ${exitCode}` : undefined,
      stderrSnippet ? `stderr: ${stderrSnippet}` : undefined,
    ]);

    const messageBase = rawMessage ?? "Claude Code SDK error";
    const message =
      detailSegments.length > 0 ? `${messageBase} (${detailSegments.join("; ")})` : messageBase;

    const errorData: ClaudeCodeErrorMetadata & { message: string; isRetryable: boolean } = {
      message,
      isRetryable,
    };
    if (errorCode) {
      errorData.code = errorCode;
    }
    if (exitCode !== undefined) {
      errorData.exitCode = exitCode;
    }
    if (stderr !== undefined) {
      errorData.stderr = stderr;
    }
    const promptExcerpt = messagesPrompt.substring(0, 200);
    if (promptExcerpt !== undefined) {
      errorData.promptExcerpt = promptExcerpt;
    }
    return createAPICallError(errorData);
  }

  private setSessionId(sessionId: string): void {
    this.sessionId = sessionId;
    const warning = validateSessionId(sessionId);
    if (warning) {
      this.logger.warn(`Claude Code Session: ${warning}`);
    }
  }

  async doGenerate(
    options: Parameters<LanguageModelV2["doGenerate"]>[0]
  ): Promise<Awaited<ReturnType<LanguageModelV2["doGenerate"]>>> {
    this.logger.debug(`[claude-code] Starting doGenerate request with model: ${this.modelId}`);

    const {
      messagesPrompt,
      warnings: messageWarnings,
      streamingContentParts,
      hasImageParts,
    } = convertToClaudeCodeMessages(options.prompt);

    this.logger.debug(
      `[claude-code] Converted ${options.prompt.length} messages, hasImageParts: ${hasImageParts}`
    );

    const abortController = new AbortController();
    let abortListener: (() => void) | undefined;
    if (options.abortSignal?.aborted) {
      // Propagate already-aborted state immediately with original reason
      abortController.abort(options.abortSignal.reason);
    } else if (options.abortSignal) {
      abortListener = () => abortController.abort(options.abortSignal?.reason);
      options.abortSignal.addEventListener("abort", abortListener, { once: true });
    }

    const stderrBuffer = createStderrBuffer();
    const queryOptions = this.createQueryOptions(
      abortController,
      options.responseFormat,
      stderrBuffer
    );

    let text = "";
    let structuredOutput: unknown | undefined;
    let usage: LanguageModelV2Usage = { inputTokens: 0, outputTokens: 0, totalTokens: 0 };
    let finishReason: LanguageModelV2FinishReason = "stop";
    let wasTruncated = false;
    let costUsd: number | undefined;
    let durationMs: number | undefined;
    let rawUsage: unknown | undefined;
    const warnings: LanguageModelV2CallWarning[] = this.generateAllWarnings(
      options,
      messagesPrompt
    );

    // Add warnings from message conversion
    if (messageWarnings) {
      messageWarnings.forEach(warning => {
        warnings.push({
          type: "other",
          message: warning,
        });
      });
    }

    const modeSetting = this.settings.streamingInput ?? "auto";
    const wantsStreamInput =
      modeSetting === "always" || (modeSetting === "auto" && !!this.settings.canUseTool);

    if (!wantsStreamInput && hasImageParts) {
      warnings.push({
        type: "other",
        message: STREAMING_FEATURE_WARNING,
      });
    }

    let done = () => {};
    const outputStreamEnded = new Promise(resolve => {
      done = () => resolve(undefined);
    });
    try {
      if (this.settings.canUseTool && this.settings.permissionPromptToolName) {
        throw new Error(
          "canUseTool requires streamingInput mode ('auto' or 'always') and cannot be used with permissionPromptToolName (SDK constraint). Set streamingInput: 'auto' (or 'always') and remove permissionPromptToolName, or remove canUseTool."
        );
      }
      // hold input stream open until results
      // see: https://github.com/anthropics/claude-code/issues/4775
      const sdkPrompt = wantsStreamInput
        ? toAsyncIterablePrompt(
            messagesPrompt,
            outputStreamEnded,
            this.settings.resume ?? this.sessionId,
            streamingContentParts
          )
        : messagesPrompt;

      this.logger.debug(
        `[claude-code] Executing query with streamingInput: ${wantsStreamInput}, session: ${this.settings.resume ?? this.sessionId ?? "new"}`
      );

      const response = query({
        prompt: sdkPrompt,
        options: queryOptions,
      });

      for await (const message of response) {
        this.logger.debug(`[claude-code] Received message type: ${message.type}`);
        if (message.type === "assistant") {
          text += message.message.content
            .map((c: { type: string; text?: string }) => (c.type === "text" ? c.text : ""))
            .join("");
        } else if (message.type === "result") {
          done();

          // Handle structured output errors (SDK 0.1.45+)
          // Use string comparison to support new SDK subtypes not yet in TypeScript definitions
          if ((message.subtype as string) === "error_max_structured_output_retries") {
            throw new Error(
              "Failed to generate valid structured output after maximum retries. The model could not produce a response matching the required schema."
            );
          }

          // Capture structured output if available (SDK 0.1.45+)
          if ("structured_output" in message && message.structured_output !== undefined) {
            structuredOutput = message.structured_output;
            this.logger.debug("[claude-code] Received structured output from SDK");
          }

          this.setSessionId(message.session_id);
          costUsd = message.total_cost_usd;
          durationMs = message.duration_ms;

          this.logger.info(
            `[claude-code] Request completed - Session: ${message.session_id}, Cost: $${costUsd?.toFixed(4) ?? "N/A"}, Duration: ${durationMs ?? "N/A"}ms`
          );

          if ("usage" in message) {
            rawUsage = message.usage;
            usage = {
              inputTokens:
                (message.usage.cache_creation_input_tokens ?? 0) +
                (message.usage.cache_read_input_tokens ?? 0) +
                (message.usage.input_tokens ?? 0),
              outputTokens: message.usage.output_tokens ?? 0,
              totalTokens:
                (message.usage.cache_creation_input_tokens ?? 0) +
                (message.usage.cache_read_input_tokens ?? 0) +
                (message.usage.input_tokens ?? 0) +
                (message.usage.output_tokens ?? 0),
            };

            this.logger.debug(
              `[claude-code] Token usage - Input: ${usage.inputTokens}, Output: ${usage.outputTokens}, Total: ${usage.totalTokens}`
            );
          }

          finishReason = mapClaudeCodeFinishReason(message.subtype);
          this.logger.debug(`[claude-code] Finish reason: ${finishReason}`);
        } else if (message.type === "system" && message.subtype === "init") {
          this.setSessionId(message.session_id);
          this.logger.info(`[claude-code] Session initialized: ${message.session_id}`);
        }
      }
    } catch (error: unknown) {
      done();
      this.logger.debug(
        `[claude-code] Error during doGenerate: ${error instanceof Error ? error.message : String(error)}`
      );

      // Special handling for AbortError to preserve abort signal reason
      if (isAbortError(error)) {
        this.logger.debug("[claude-code] Request aborted by user");
        throw options.abortSignal?.aborted ? options.abortSignal.reason : error;
      }

      if (error instanceof APICallError || error instanceof LoadAPIKeyError) {
        throw error;
      }

      if (isClaudeCodeTruncationError(error, text)) {
        this.logger.warn(
          `[claude-code] Detected truncated response, returning ${text.length} characters of buffered text`
        );
        wasTruncated = true;
        finishReason = "length";
        warnings.push({
          type: "other",
          message: CLAUDE_CODE_TRUNCATION_WARNING,
        });
      } else {
        // Use unified error handler
        throw this.handleClaudeCodeError(error, messagesPrompt, stderrBuffer);
      }
    } finally {
      if (options.abortSignal && abortListener) {
        options.abortSignal.removeEventListener("abort", abortListener);
      }
    }

    const finalText = structuredOutput !== undefined ? JSON.stringify(structuredOutput) : text;

    return {
      content: [{ type: "text", text: finalText }],
      usage,
      finishReason,
      warnings,
      response: {
        id: generateId(),
        timestamp: new Date(),
        modelId: this.modelId,
      },
      request: {
        body: messagesPrompt,
      },
      providerMetadata: {
        "claude-code": {
          ...(this.sessionId !== undefined && { sessionId: this.sessionId }),
          ...(costUsd !== undefined && { costUsd }),
          ...(durationMs !== undefined && { durationMs }),
          ...(rawUsage !== undefined && { rawUsage: rawUsage as JSONValue }),
          ...(wasTruncated && { truncated: true }),
        },
      },
    };
  }

  async doStream(
    options: Parameters<LanguageModelV2["doStream"]>[0]
  ): Promise<Awaited<ReturnType<LanguageModelV2["doStream"]>>> {
    this.logger.debug(`[claude-code] Starting doStream request with model: ${this.modelId}`);

    const {
      messagesPrompt,
      warnings: messageWarnings,
      streamingContentParts,
      hasImageParts,
    } = convertToClaudeCodeMessages(options.prompt);

    this.logger.debug(
      `[claude-code] Converted ${options.prompt.length} messages for streaming, hasImageParts: ${hasImageParts}`
    );

    const abortController = new AbortController();
    let abortListener: (() => void) | undefined;
    if (options.abortSignal?.aborted) {
      // Propagate already-aborted state immediately with original reason
      abortController.abort(options.abortSignal.reason);
    } else if (options.abortSignal) {
      abortListener = () => abortController.abort(options.abortSignal?.reason);
      options.abortSignal.addEventListener("abort", abortListener, { once: true });
    }

    const stderrBuffer = createStderrBuffer();
    const queryOptions = this.createQueryOptions(
      abortController,
      options.responseFormat,
      stderrBuffer
    );

    // Enable partial messages for true streaming (token-by-token delivery)
    // This can be overridden by user settings, but we default to true for doStream
    if (queryOptions.includePartialMessages === undefined) {
      queryOptions.includePartialMessages = true;
    }

    const warnings: LanguageModelV2CallWarning[] = this.generateAllWarnings(
      options,
      messagesPrompt
    );

    // Add warnings from message conversion
    if (messageWarnings) {
      messageWarnings.forEach(warning => {
        warnings.push({
          type: "other",
          message: warning,
        });
      });
    }

    const modeSetting = this.settings.streamingInput ?? "auto";
    const wantsStreamInput =
      modeSetting === "always" || (modeSetting === "auto" && !!this.settings.canUseTool);

    if (!wantsStreamInput && hasImageParts) {
      warnings.push({
        type: "other",
        message: STREAMING_FEATURE_WARNING,
      });
    }

    const stream = new ReadableStream<ExtendedStreamPart>({
      start: async controller => {
        let done = () => {};
        const outputStreamEnded = new Promise(resolve => {
          done = () => resolve(undefined);
        });
        const toolStates = new Map<string, ToolStreamState>();
        const streamWarnings: LanguageModelV2CallWarning[] = [];

        const closeToolInput = (toolId: string, state: ToolStreamState) => {
          if (!state.inputClosed && state.inputStarted) {
            controller.enqueue({
              type: "tool-input-end",
              id: toolId,
            });
            state.inputClosed = true;
          }
        };

        const emitToolCall = (toolId: string, state: ToolStreamState) => {
          if (state.callEmitted) {
            return;
          }

          closeToolInput(toolId, state);

          controller.enqueue({
            type: "tool-call",
            toolCallId: toolId,
            toolName: state.name,
            input: state.lastSerializedInput ?? "",
            providerExecuted: true,
            dynamic: true, // V3 field: indicates tool is provider-defined (not in user's tools map)
            providerMetadata: {
              "claude-code": {
                // rawInput preserves the original serialized format before AI SDK normalization.
                // Use this if you need the exact string sent to the Claude CLI, which may differ
                // from the `input` field after AI SDK processing.
                rawInput: state.lastSerializedInput ?? "",
              },
            },
          } as any); // eslint-disable-line @typescript-eslint/no-explicit-any
          state.callEmitted = true;
        };

        const finalizeToolCalls = () => {
          for (const [toolId, state] of toolStates) {
            emitToolCall(toolId, state);
          }
          toolStates.clear();
        };

        let usage: LanguageModelV2Usage = {
          inputTokens: 0,
          outputTokens: 0,
          totalTokens: 0,
        };
        let accumulatedText = "";
        let textPartId: string | undefined;
        let streamedTextLength = 0; // Track text already emitted via stream_events to avoid duplication
        let hasReceivedStreamEvents = false; // Track if we've received any stream_events
        let structuredOutput: unknown | undefined;
        let iterator: AsyncIterator<any> | undefined;
        const throwIfAborted = () => {
          if (abortController.signal.aborted) {
            const reason =
              abortController.signal.reason ?? new DOMException("Aborted", "AbortError");
            throw reason;
          }
        };

        try {
          // Emit stream-start with warnings (clone to avoid mutation)
          const streamStartWarnings = [...warnings];
          controller.enqueue({ type: "stream-start", warnings: streamStartWarnings });

          if (this.settings.canUseTool && this.settings.permissionPromptToolName) {
            throw new Error(
              "canUseTool requires streamingInput mode ('auto' or 'always') and cannot be used with permissionPromptToolName (SDK constraint). Set streamingInput: 'auto' (or 'always') and remove permissionPromptToolName, or remove canUseTool."
            );
          }
          // hold input stream open until results
          // see: https://github.com/anthropics/claude-code/issues/4775
          const sdkPrompt = wantsStreamInput
            ? toAsyncIterablePrompt(
                messagesPrompt,
                outputStreamEnded,
                this.settings.resume ?? this.sessionId,
                streamingContentParts
              )
            : messagesPrompt;

          this.logger.debug(
            `[claude-code] Starting stream query with streamingInput: ${wantsStreamInput}, session: ${this.settings.resume ?? this.sessionId ?? "new"}`
          );

          const response = query({
            prompt: sdkPrompt,
            options: queryOptions,
          });

          iterator = response[Symbol.asyncIterator]();

          while (true) {
            throwIfAborted();
            const { value: message, done: iteratorDone } = await iterator.next();
            if (iteratorDone) {
              break;
            }
            this.logger.debug(`[claude-code] Stream received message type: ${message.type}`);

            // Handle streaming events (token-by-token delivery via includePartialMessages)
            if (message.type === "stream_event") {
              const streamEvent = message as SDKPartialAssistantMessage;
              const event = streamEvent.event;

              // Check for text_delta events within content_block_delta
              if (
                event.type === "content_block_delta" &&
                event.delta.type === "text_delta" &&
                "text" in event.delta &&
                event.delta.text
              ) {
                const deltaText = event.delta.text;
                hasReceivedStreamEvents = true;

                // Don't emit text deltas in JSON mode - accumulate instead
                if (options.responseFormat?.type === "json") {
                  accumulatedText += deltaText;
                  streamedTextLength += deltaText.length;
                  continue;
                }

                // Emit text-start if this is the first text
                if (!textPartId) {
                  textPartId = generateId();
                  controller.enqueue({
                    type: "text-start",
                    id: textPartId,
                  });
                }

                controller.enqueue({
                  type: "text-delta",
                  id: textPartId,
                  delta: deltaText,
                });
                accumulatedText += deltaText;
                streamedTextLength += deltaText.length;
              }
              // Handle input_json_delta events for structured output streaming
              // The SDK uses a StructuredOutput tool internally, and JSON is streamed via input_json_delta
              if (
                event.type === "content_block_delta" &&
                event.delta.type === "input_json_delta" &&
                "partial_json" in event.delta &&
                event.delta.partial_json
              ) {
                const jsonDelta = event.delta.partial_json;
                hasReceivedStreamEvents = true;

                // Only emit in JSON mode - this enables streamObject() to receive partial updates
                if (options.responseFormat?.type === "json") {
                  // Emit text-start if this is the first JSON delta
                  if (!textPartId) {
                    textPartId = generateId();
                    controller.enqueue({
                      type: "text-start",
                      id: textPartId,
                    });
                  }

                  controller.enqueue({
                    type: "text-delta",
                    id: textPartId,
                    delta: jsonDelta,
                  });
                  accumulatedText += jsonDelta;
                  streamedTextLength += jsonDelta.length;
                }
                // In non-JSON mode, input_json_delta is ignored (it's internal tool use)
              }

              // Other stream_event types (content_block_start, content_block_stop, etc.)
              // are informational and don't need to be forwarded to the AI SDK stream
              continue;
            }

            if (message.type === "assistant") {
              if (!message.message?.content) {
                this.logger.warn(
                  `[claude-code] Unexpected assistant message structure: missing content field. Message type: ${message.type}. This may indicate an SDK protocol violation.`
                );
                continue;
              }

              const content = message.message.content;

              // Process content items in order to preserve interleaved text and tool calls
              // First, collect all text segments and tool uses in order
              const textSegments: string[] = [];
              const orderedItems: Array<{
                type: "text" | "tool_use";
                text?: string;
                tool?: ClaudeToolUse;
              }> = [];

              for (const item of content) {
                if (!item || typeof item !== "object" || !("type" in item)) {
                  continue;
                }

                const itemType = (item as { type: unknown }).type;

                if (itemType === "text") {
                  const textContent =
                    "text" in item && typeof item.text === "string" ? item.text : "";
                  if (textContent) {
                    textSegments.push(textContent);
                    orderedItems.push({ type: "text", text: textContent });
                  }
                } else if (itemType === "tool_use") {
                  const tools = this.extractToolUses([item]);
                  const tool = head(tools);
                  if (tool) {
                    orderedItems.push({ type: "tool_use", tool });
                  }
                }
              }

              // Process items in order
              for (const orderedItem of orderedItems) {
                if (orderedItem.type === "tool_use" && orderedItem.tool) {
                  // Close current text part before processing tool calls (tool calls interrupt text streaming)
                  if (textPartId !== undefined) {
                    controller.enqueue({
                      type: "text-end",
                      id: textPartId,
                    });
                    textPartId = undefined;
                  }

                  const tool = orderedItem.tool;
                  const toolId = tool.id;
                  let state = toolStates.get(toolId);
                  if (!state) {
                    state = {
                      name: tool.name,
                      inputStarted: false,
                      inputClosed: false,
                      callEmitted: false,
                    };
                    toolStates.set(toolId, state);
                    this.logger.debug(
                      `[claude-code] New tool use detected - Tool: ${tool.name}, ID: ${toolId}`
                    );
                  }

                  state.name = tool.name;

                  if (!state.inputStarted) {
                    this.logger.debug(
                      `[claude-code] Tool input started - Tool: ${tool.name}, ID: ${toolId}`
                    );
                    controller.enqueue({
                      type: "tool-input-start",
                      id: toolId,
                      toolName: tool.name,
                      providerExecuted: true,
                      dynamic: true, // V3 field: indicates tool is provider-defined (not in user's tools map)
                    } as any); // eslint-disable-line @typescript-eslint/no-explicit-any
                    state.inputStarted = true;
                  }

                  const serializedInput = this.serializeToolInput(tool.input);
                  if (serializedInput) {
                    let deltaPayload = "";

                    // First input: emit full delta only if small enough
                    if (state.lastSerializedInput === undefined) {
                      if (serializedInput.length <= ClaudeCodeLanguageModel.MAX_DELTA_CALC_SIZE) {
                        deltaPayload = serializedInput;
                      }
                    } else if (
                      serializedInput.length <= ClaudeCodeLanguageModel.MAX_DELTA_CALC_SIZE &&
                      state.lastSerializedInput.length <=
                        ClaudeCodeLanguageModel.MAX_DELTA_CALC_SIZE &&
                      serializedInput.startsWith(state.lastSerializedInput)
                    ) {
                      deltaPayload = serializedInput.slice(state.lastSerializedInput.length);
                    } else if (serializedInput !== state.lastSerializedInput) {
                      // Non-prefix updates or large inputs - defer to the final tool-call payload
                      deltaPayload = "";
                    }

                    if (deltaPayload) {
                      controller.enqueue({
                        type: "tool-input-delta",
                        id: toolId,
                        delta: deltaPayload,
                      });
                    }
                    state.lastSerializedInput = serializedInput;
                  }
                } else if (orderedItem.type === "text" && orderedItem.text) {
                  // Process text segment
                  const text = orderedItem.text;

                  // When we've received stream_events, assistant messages contain cumulative text
                  // that we've already emitted via stream_event deltas - skip duplicates
                  // When no stream_events received, assistant messages contain incremental text
                  if (hasReceivedStreamEvents) {
                    // Calculate cumulative text up to this point in the message
                    // (all text segments processed so far in order)
                    const currentIndex = orderedItems.indexOf(orderedItem);
                    let cumulativeTextSoFar = "";
                    for (let i = 0; i <= currentIndex; i++) {
                      if (orderedItems[i]?.type === "text") {
                        cumulativeTextSoFar += orderedItems[i]!.text || "";
                      }
                    }

                    const newTextStart = streamedTextLength;
                    const deltaText =
                      cumulativeTextSoFar.length > newTextStart
                        ? cumulativeTextSoFar.slice(newTextStart)
                        : "";

                    // In JSON mode, we accumulate the text and extract JSON at the end
                    // Otherwise, stream any new text
                    if (options.responseFormat?.type !== "json" && deltaText) {
                      // Emit text-start if this is the first text (textPartId is undefined)
                      if (!textPartId) {
                        textPartId = generateId();
                        controller.enqueue({
                          type: "text-start",
                          id: textPartId,
                        });
                      }

                      controller.enqueue({
                        type: "text-delta",
                        id: textPartId,
                        delta: deltaText,
                      });
                    }
                    // Update streamedTextLength to match what we now know is the cumulative text
                    streamedTextLength = cumulativeTextSoFar.length;
                  } else {
                    // No stream_events - assistant messages contain incremental text chunks
                    accumulatedText += text;

                    // In JSON mode, we accumulate the text and extract JSON at the end
                    // Otherwise, stream the text as it comes
                    if (options.responseFormat?.type !== "json") {
                      // Emit text-start if this is the first text (textPartId is undefined)
                      // This handles the case where text comes after a tool call (textPartId was reset)
                      if (!textPartId) {
                        textPartId = generateId();
                        controller.enqueue({
                          type: "text-start",
                          id: textPartId,
                        });
                      }

                      controller.enqueue({
                        type: "text-delta",
                        id: textPartId,
                        delta: text,
                      });
                    }
                  }
                }
              }
            } else if (message.type === "user") {
              if (!message.message?.content) {
                this.logger.warn(
                  `[claude-code] Unexpected user message structure: missing content field. Message type: ${message.type}. This may indicate an SDK protocol violation.`
                );
                continue;
              }
              const content = message.message.content;
              for (const result of this.extractToolResults(content)) {
                let state = toolStates.get(result.id);
                const toolName =
                  result.name ?? state?.name ?? ClaudeCodeLanguageModel.UNKNOWN_TOOL_NAME;

                this.logger.debug(
                  `[claude-code] Tool result received - Tool: ${toolName}, ID: ${result.id}`
                );

                if (!state) {
                  this.logger.warn(
                    `[claude-code] Received tool result for unknown tool ID: ${result.id}`
                  );
                  state = {
                    name: toolName,
                    inputStarted: false,
                    inputClosed: false,
                    callEmitted: false,
                  };
                  toolStates.set(result.id, state);
                  // Synthesize input lifecycle to preserve ordering when no prior tool_use was seen
                  if (!state.inputStarted) {
                    controller.enqueue({
                      type: "tool-input-start",
                      id: result.id,
                      toolName,
                      providerExecuted: true,
                      dynamic: true, // V3 field: indicates tool is provider-defined
                    } as any); // eslint-disable-line @typescript-eslint/no-explicit-any
                    state.inputStarted = true;
                  }
                  if (!state.inputClosed) {
                    controller.enqueue({
                      type: "tool-input-end",
                      id: result.id,
                    });
                    state.inputClosed = true;
                  }
                }
                state.name = toolName;
                const structuredContent = result.structuredContent;

                emitToolCall(result.id, state);

                if (!result.isError && structuredContent !== undefined) {
                  controller.enqueue({
                    type: "tool-artifact",
                    tool: toolName,
                    id: result.id,
                    data: structuredContent,
                  } as any); // eslint-disable-line @typescript-eslint/no-explicit-any
                  continue;
                }

                const normalizedResult = this.normalizeToolResult(result.result);
                const rawResult =
                  typeof result.result === "string"
                    ? result.result
                    : (() => {
                        try {
                          return JSON.stringify(result.result);
                        } catch {
                          return String(result.result);
                        }
                      })();

                controller.enqueue({
                  type: "tool-result",
                  toolCallId: result.id,
                  toolName,
                  result: normalizedResult,
                  isError: result.isError,
                  providerExecuted: true,
                  dynamic: true, // V3 field: indicates tool is provider-defined
                  providerMetadata: {
                    "claude-code": {
                      // rawResult preserves the original CLI output string before JSON parsing.
                      // Use this when you need the exact string returned by the tool, especially
                      // if the `result` field has been parsed/normalized and you need the original format.
                      rawResult,
                    },
                  },
                } as any); // eslint-disable-line @typescript-eslint/no-explicit-any
              }
              // Handle tool errors
              for (const error of this.extractToolErrors(content)) {
                let state = toolStates.get(error.id);
                const toolName =
                  error.name ?? state?.name ?? ClaudeCodeLanguageModel.UNKNOWN_TOOL_NAME;

                this.logger.debug(
                  `[claude-code] Tool error received - Tool: ${toolName}, ID: ${error.id}`
                );

                if (!state) {
                  this.logger.warn(
                    `[claude-code] Received tool error for unknown tool ID: ${error.id}`
                  );
                  state = {
                    name: toolName,
                    inputStarted: true,
                    inputClosed: true,
                    callEmitted: false,
                  };
                  toolStates.set(error.id, state);
                }

                // Ensure tool-call is emitted before tool-error
                emitToolCall(error.id, state);

                const rawError =
                  typeof error.error === "string"
                    ? error.error
                    : typeof error.error === "object" && error.error !== null
                      ? (() => {
                          try {
                            return JSON.stringify(error.error);
                          } catch {
                            return String(error.error);
                          }
                        })()
                      : String(error.error);

                controller.enqueue({
                  type: "tool-error",
                  toolCallId: error.id,
                  toolName,
                  error: rawError,
                  providerExecuted: true,
                  dynamic: true, // V3 field: indicates tool is provider-defined
                  providerMetadata: {
                    "claude-code": {
                      rawError,
                    },
                  },
                } as any); // eslint-disable-line @typescript-eslint/no-explicit-any
              }
            } else if (message.type === "result") {
              done();

              // Handle structured output errors (SDK 0.1.45+)
              // Use string comparison to support new SDK subtypes not yet in TypeScript definitions
              if ((message.subtype as string) === "error_max_structured_output_retries") {
                throw new Error(
                  "Failed to generate valid structured output after maximum retries. The model could not produce a response matching the required schema."
                );
              }

              if ("structured_output" in message && message.structured_output !== undefined) {
                structuredOutput = message.structured_output;
              }

              this.logger.info(
                `[claude-code] Stream completed - Session: ${message.session_id}, Cost: $${message.total_cost_usd?.toFixed(4) ?? "N/A"}, Duration: ${message.duration_ms ?? "N/A"}ms`
              );

              let rawUsage: unknown | undefined;
              if ("usage" in message) {
                rawUsage = message.usage;
                usage = {
                  inputTokens:
                    (message.usage.cache_creation_input_tokens ?? 0) +
                    (message.usage.cache_read_input_tokens ?? 0) +
                    (message.usage.input_tokens ?? 0),
                  outputTokens: message.usage.output_tokens ?? 0,
                  totalTokens:
                    (message.usage.cache_creation_input_tokens ?? 0) +
                    (message.usage.cache_read_input_tokens ?? 0) +
                    (message.usage.input_tokens ?? 0) +
                    (message.usage.output_tokens ?? 0),
                };

                this.logger.debug(
                  `[claude-code] Stream token usage - Input: ${usage.inputTokens}, Output: ${usage.outputTokens}, Total: ${usage.totalTokens}`
                );
              }

              const finishReason: LanguageModelV2FinishReason = mapClaudeCodeFinishReason(
                message.subtype
              );

              this.logger.debug(`[claude-code] Stream finish reason: ${finishReason}`);

              // Store session ID in the model instance
              this.setSessionId(message.session_id);

              // Check if we've already streamed JSON via input_json_delta
              const alreadyStreamedJson =
                textPartId && options.responseFormat?.type === "json" && hasReceivedStreamEvents;

              if (alreadyStreamedJson && textPartId) {
                // We've already streamed JSON deltas, just close the text part
                controller.enqueue({
                  type: "text-end",
                  id: textPartId,
                });
              } else if (structuredOutput !== undefined) {
                // Emit structured output as text (fallback when streaming didn't occur)
                const jsonTextId = generateId();
                const jsonText = JSON.stringify(structuredOutput);
                controller.enqueue({
                  type: "text-start",
                  id: jsonTextId,
                });
                controller.enqueue({
                  type: "text-delta",
                  id: jsonTextId,
                  delta: jsonText,
                });
                controller.enqueue({
                  type: "text-end",
                  id: jsonTextId,
                });
              } else if (textPartId) {
                // Close the text part if it was opened (non-JSON mode)
                controller.enqueue({
                  type: "text-end",
                  id: textPartId,
                });
              } else if (accumulatedText) {
                // Fallback for JSON mode without schema: emit accumulated text
                // This handles the case where responseFormat.type === 'json' but no schema
                // was provided, so the SDK returns plain text instead of structured_output
                const fallbackTextId = generateId();
                controller.enqueue({
                  type: "text-start",
                  id: fallbackTextId,
                });
                controller.enqueue({
                  type: "text-delta",
                  id: fallbackTextId,
                  delta: accumulatedText,
                });
                controller.enqueue({
                  type: "text-end",
                  id: fallbackTextId,
                });
              }

              finalizeToolCalls();

              // Prepare JSON-safe warnings for provider metadata
              const warningsJson = this.serializeWarningsForMetadata(streamWarnings);

              controller.enqueue({
                type: "finish",
                finishReason,
                usage,
                providerMetadata: {
                  "claude-code": {
                    sessionId: message.session_id,
                    ...(message.total_cost_usd !== undefined && {
                      costUsd: message.total_cost_usd,
                    }),
                    ...(message.duration_ms !== undefined && {
                      durationMs: message.duration_ms,
                    }),
                    ...(rawUsage !== undefined && {
                      rawUsage: rawUsage as JSONValue,
                    }),
                    // JSON validation warnings are collected during streaming and included
                    // in providerMetadata since the AI SDK's finish event doesn't support
                    // a top-level warnings field (unlike stream-start which was already emitted)
                    ...(streamWarnings.length > 0 && {
                      warnings: warningsJson as unknown as JSONValue,
                    }),
                  },
                },
              });
            } else if (message.type === "system" && message.subtype === "init") {
              // Store session ID for future use
              this.setSessionId(message.session_id);

              this.logger.info(`[claude-code] Stream session initialized: ${message.session_id}`);

              // Emit response metadata when session is initialized
              controller.enqueue({
                type: "response-metadata",
                id: message.session_id,
                timestamp: new Date(),
                modelId: this.modelId,
              });
            }
          }

          finalizeToolCalls();
          this.logger.debug("[claude-code] Stream finalized, closing stream");
          controller.close();
        } catch (error: unknown) {
          done();

          this.logger.debug(
            `[claude-code] Error during doStream: ${error instanceof Error ? error.message : String(error)}`
          );

          if (abortController.signal.aborted) {
            if (iterator && typeof iterator.return === "function") {
              try {
                await iterator.return();
              } catch {
                // ignore iterator return errors on abort
              }
            }
            finalizeToolCalls();
            const abortReason =
              options.abortSignal?.reason ?? new DOMException("Aborted", "AbortError");
            controller.enqueue({
              type: "error",
              error: abortReason,
            });
            controller.close();
            return;
          }

          if (error instanceof APICallError || error instanceof LoadAPIKeyError) {
            controller.enqueue({
              type: "error",
              error,
            });
            finalizeToolCalls();
            controller.close();
            return;
          }

          if (isClaudeCodeTruncationError(error, accumulatedText)) {
            this.logger.warn(
              `[claude-code] Detected truncated stream response, returning ${accumulatedText.length} characters of buffered text`
            );
            const truncationWarning: LanguageModelV2CallWarning = {
              type: "other",
              message: CLAUDE_CODE_TRUNCATION_WARNING,
            };
            streamWarnings.push(truncationWarning);

            const emitBufferedText = (textValue: string) => {
              const jsonTextId = generateId();
              controller.enqueue({
                type: "text-start",
                id: jsonTextId,
              });
              controller.enqueue({
                type: "text-delta",
                id: jsonTextId,
                delta: textValue,
              });
              controller.enqueue({
                type: "text-end",
                id: jsonTextId,
              });
            };

            if (options.responseFormat?.type === "json" && accumulatedText) {
              emitBufferedText(accumulatedText);
            } else if (textPartId) {
              controller.enqueue({
                type: "text-end",
                id: textPartId,
              });
            } else if (accumulatedText) {
              emitBufferedText(accumulatedText);
            }

            finalizeToolCalls();

            const warningsJson = this.serializeWarningsForMetadata(streamWarnings);

            controller.enqueue({
              type: "finish",
              finishReason: "length",
              usage,
              providerMetadata: {
                "claude-code": {
                  ...(this.sessionId !== undefined && {
                    sessionId: this.sessionId,
                  }),
                  truncated: true,
                  ...(streamWarnings.length > 0 && {
                    warnings: warningsJson as unknown as JSONValue,
                  }),
                },
              },
            });

            controller.close();
            return;
          }

          finalizeToolCalls();
          let errorToEmit: unknown;

          // Special handling for AbortError to preserve abort signal reason
          if (isAbortError(error)) {
            errorToEmit = options.abortSignal?.aborted ? options.abortSignal.reason : error;
          } else {
            // Use unified error handler
            errorToEmit = this.handleClaudeCodeError(error, messagesPrompt, stderrBuffer);
          }

          // Emit error as a stream part
          controller.enqueue({
            type: "error",
            error: errorToEmit,
          });

          controller.close();
        } finally {
          if (options.abortSignal && abortListener) {
            options.abortSignal.removeEventListener("abort", abortListener);
          }
        }
      },
      cancel: () => {
        if (options.abortSignal && abortListener) {
          options.abortSignal.removeEventListener("abort", abortListener);
        }
        abortController.abort(new DOMException("Aborted", "AbortError"));
      },
    });

    return {
      stream: stream as unknown as ReadableStream<LanguageModelV2StreamPart>,
      request: {
        body: messagesPrompt,
      },
    };
  }

  private serializeWarningsForMetadata(warnings: LanguageModelV2CallWarning[]): JSONValue {
    const result = warnings.map(w => {
      const base: Record<string, string> = { type: w.type };
      if ("message" in w) {
        const m = (w as { message?: unknown }).message;
        if (m !== undefined) base.message = String(m);
      }
      if (w.type === "unsupported-setting") {
        const setting = (w as { setting: unknown }).setting;
        if (setting !== undefined) base.setting = String(setting);
        if ("details" in w) {
          const d = (w as { details?: unknown }).details;
          if (d !== undefined) base.details = String(d);
        }
      }
      return base;
    });
    return result as unknown as JSONValue;
  }
}
