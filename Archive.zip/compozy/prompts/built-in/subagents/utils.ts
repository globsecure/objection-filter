/**
 * Shared utilities for subagent prompt builders
 * Provides reusable functions for injecting artifacts and tasks into prompts
 */

import { ARTIFACT_LIST_TOOL_NAME, artifactListInputSchema } from "@compozy/types";
import { invariant } from "es-toolkit/util";
import type { PromptBuilder } from "../../src/builder";
import { withToolDocumentationWithSchema } from "../../src/sections/tools";
import { zodSchemaToPromptText } from "../../src/sections/schema";
import type { ArtifactConfig, IssueConfig, TaskExecutionConfig } from "./types";

/**
 * Type guard to check if config has task property (TaskExecutionConfig)
 */
export function isTaskExecutionConfig(
  config?: ArtifactConfig | TaskExecutionConfig
): config is TaskExecutionConfig {
  return config !== undefined && "task" in config;
}

/**
 * Validates that an artifact has all required fields
 */
function validateArtifact(artifact: {
  id: string;
  title: string;
  filePath: string;
  version?: number;
}): void {
  invariant(
    artifact.id && artifact.title && artifact.filePath,
    `Artifact validation failed: missing required fields (id: ${artifact.id ?? "missing"}, title: ${artifact.title ?? "missing"}, filePath: ${artifact.filePath ? "present" : "missing"})`
  );
}

/**
 * Injects PRD and TechSpec artifacts into a prompt builder
 * Validates artifact content before injection
 */
export function injectArtifactsIntoBuilder(builder: PromptBuilder, config?: ArtifactConfig): void {
  if (config?.techspecArtifact) {
    validateArtifact(config.techspecArtifact);
    const version = config.techspecArtifact.version
      ? `v${config.techspecArtifact.version}`
      : "latest";
    builder.withDocRef(
      "techspec",
      `# ${config.techspecArtifact.title} (TechSpec ${version})\n\nFile path: ${config.techspecArtifact.filePath}\n\nUse artifact search tools to read relevant sections from this file.`
    );
  }

  if (config?.prdArtifact) {
    validateArtifact(config.prdArtifact);
    const prdVersion = config.prdArtifact.version ? `v${config.prdArtifact.version}` : "latest";
    builder.withDocRef(
      "prd",
      `# ${config.prdArtifact.title} (PRD ${prdVersion})\n\nFile path: ${config.prdArtifact.filePath}\n\nUse artifact search tools to read relevant sections from this file.`
    );
  }
}

/**
 * Injects task content into a prompt builder
 * Uses proper type guard to ensure type safety
 */
export function injectTaskIntoBuilder(
  builder: PromptBuilder,
  config?: ArtifactConfig | TaskExecutionConfig
): void {
  if (isTaskExecutionConfig(config)) {
    invariant(
      config.task.id && config.task.title && config.task.filePath,
      `Task validation failed: missing required fields (id: ${config.task.id ?? "missing"}, title: ${config.task.title ?? "missing"}, filePath: ${config.task.filePath ? "present" : "missing"})`
    );
    builder.withDocRef(
      "task",
      `# ${config.task.title} (Task ${config.task.id})\n\nFile path: ${config.task.filePath}\n\nUse artifact search tools to read relevant sections from this task file.`
    );
  }
}

/**
 * Builds the artifact context section text
 * Returns a formatted string indicating which artifact file paths are referenced
 */
export function buildArtifactContextSection(config?: ArtifactConfig | TaskExecutionConfig): string {
  if (!config) return "";

  const parts: string[] = [];
  if (config.techspecArtifact) {
    parts.push("✅ TechSpec file path is provided in the <techspec> reference.\n");
  }
  if (config.prdArtifact) {
    parts.push("✅ PRD file path is provided in the <prd> reference.\n");
  }
  if (isTaskExecutionConfig(config)) {
    parts.push("✅ Current task file path is provided in the <task> reference.\n");
  }

  return parts.join("");
}

/**
 * Checks if any artifacts or task are provided in the config
 */
export function hasArtifactsOrTask(config?: ArtifactConfig | TaskExecutionConfig): boolean {
  if (!config) return false;
  return !!config.techspecArtifact || !!config.prdArtifact || isTaskExecutionConfig(config);
}

/**
 * Builds a TypeScript code example for calling the ArtifactListTool
 * Centralizes the formatting for future updates
 */
function buildArtifactListToolExample(issueId: string): string {
  return `\`\`\`typescript
${ARTIFACT_LIST_TOOL_NAME}({
  issueId: "${issueId}"
})
\`\`\``;
}

/**
 * Injects issue context (issueId and issueTitle) into a prompt builder
 * This enables subagents to call artifactListTool which requires issueId
 */
export function injectIssueContextIntoBuilder(
  builder: PromptBuilder,
  config?: IssueConfig | ArtifactConfig | TaskExecutionConfig
): void {
  if (!config?.issueId) return;

  const issueIdSection = `**Issue ID**: \`${config.issueId}\`${config.issueTitle ? `\n**Issue Title**: ${config.issueTitle}` : ""}

Use this issue ID when calling ${ARTIFACT_LIST_TOOL_NAME} to discover artifacts:
${buildArtifactListToolExample(config.issueId)}`;

  builder.withSection("Issue Context", issueIdSection, "critical");
  builder.withXmlTag("issue_id", config.issueId);
  if (config.issueTitle) {
    builder.withXmlTag("issue_title", config.issueTitle);
  }
}

/**
 * Injects artifact tool documentation into a prompt builder
 * Conditionally adds tool documentation when artifacts are present
 * Uses the withToolDocumentationWithSchema pattern for consistency
 */
export function injectArtifactToolDocumentation(
  builder: PromptBuilder,
  config?: ArtifactConfig | TaskExecutionConfig
): PromptBuilder {
  // Only add documentation when artifacts or task are present
  if (!hasArtifactsOrTask(config)) {
    return builder;
  }

  const schemaDoc = zodSchemaToPromptText(artifactListInputSchema, "artifactListInput");
  const schemaDocFormatted = `\`\`\`typescript
{
  issueId: string;  // Required: Issue ID (UUID) to list artifacts for
}
\`\`\`

**Schema Details**:
${schemaDoc}`;

  return withToolDocumentationWithSchema(
    builder,
    {
      toolName: ARTIFACT_LIST_TOOL_NAME,
      description:
        "List all artifacts (PRD, TechSpec, Tasks, Issue Context) for an issue. Returns file paths for all indexed artifacts.",
      schemaDoc: schemaDocFormatted,
      whenToCall:
        "When you need to discover available artifact files before reading them. Use this to find PRD, TechSpec, or task file paths.",
      behavior:
        "Returns a list of artifact file paths for the specified issue. Use the returned paths to read artifact content directly.",
    },
    "high"
  );
}
