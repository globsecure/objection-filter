/**
 * Shared configuration types for subagent prompt builders
 * Used to inject PRD/TechSpec artifacts and task content into subagents
 */

/**
 * Issue context for subagents - required for artifact discovery tools
 */
export interface IssueConfig {
  /** Issue ID for artifact discovery (required for artifactListTool) */
  issueId: string;
  /** Issue title for path resolution (optional) */
  issueTitle?: string;
}

/**
 * Artifact configuration for subagents used in artifact creation context
 * (e.g., TasksCreator, PRDCreator, TechspecCreator)
 */
export interface ArtifactConfig extends IssueConfig {
  /** PRD artifact file path already resolved for this issue (optional) */
  prdArtifact?: {
    id: string;
    title: string;
    filePath: string;
    version?: number;
  };
  /** TechSpec artifact file path already resolved for this issue (optional) */
  techspecArtifact?: {
    id: string;
    title: string;
    filePath: string;
    version?: number;
  };
}

/**
 * Task execution configuration for subagents used in task execution context
 * (e.g., Looper/TaskExecutor)
 * Extends ArtifactConfig with current task content
 */
export interface TaskExecutionConfig extends ArtifactConfig {
  /** Current task being executed */
  task: {
    id: string;
    title: string;
    filePath: string;
    complexity?: string;
    domain?: string;
    type?: string;
    scope?: string;
    dependencies?: string[];
  };
}
