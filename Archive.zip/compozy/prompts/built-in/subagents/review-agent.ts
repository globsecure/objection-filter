import { z } from "zod";
import { createPromptBuilder, type PromptBuilder } from "../../src/builder";
import type { AgentDefinition } from "../../src/types";
import { buildReviewChecksSection } from "../task-review/helpers";
import type { ArtifactConfig, TaskExecutionConfig } from "./types";
import {
  buildArtifactContextSection,
  hasArtifactsOrTask,
  injectArtifactsIntoBuilder,
  injectArtifactToolDocumentation,
  injectIssueContextIntoBuilder,
  injectTaskIntoBuilder,
  isTaskExecutionConfig,
} from "./utils";

/**
 * Zod schema for the review agent output.
 * Used both for prompt generation (converted to JSON Schema) and response validation.
 * Adapted from task-review/factory.ts reviewOutputSchema for subagent usage.
 */
export const reviewAgentOutputSchema = z.object({
  type: z.literal("task-review-output"),
  response: z.object({
    status: z.enum(["pass", "fail", "warn"]).describe("Review status verdict"),
    summary: z
      .array(z.string())
      .describe("Concise summary of what was reviewed in the implementation")
      .default([]),
    blockingIssues: z.array(z.string()).describe("Critical issues that must be resolved"),
    nonBlockingIssues: z.array(z.string()).describe("Minor issues that can be addressed later"),
    testFindings: z.array(z.string()).describe("Test failures, absent tests, or coverage notes"),
    flakinessSignals: z.array(z.string()).describe("Potential flakiness indicators"),
    riskRating: z.enum(["low", "medium", "high"]).describe("Overall risk level of the changes"),
  }),
});

export type ReviewAgentOutput = z.infer<typeof reviewAgentOutputSchema>;

/**
 * Review Agent agent definition
 */
export const reviewAgentDefinition: AgentDefinition = {
  name: "@reviewAgent",
  purpose: "Code quality and risk assessment specialist for task execution",
  useWhen:
    "Before completing a task, you must review code quality, tests, lint execution, and risk to ensure the implementation meets all quality standards",
  capabilities: [
    "Assess code quality, test execution, lint execution, and risk",
    "Identify flakiness signals and unresolved TODOs",
    "Summarize blocking vs non-blocking issues for reporting",
    "Evaluate test coverage and execution results",
    "Check for security or regression risks",
    "Assess code maintainability and adherence to standards",
  ],
  exampleUsage:
    "@reviewAgent: Review the current implementation for code quality, test execution, lint results, and risk before completing the task",
  bestFor:
    "Ensuring code quality, test coverage, lint compliance, and risk assessment before task completion",
};

export function createReviewAgentPromptBuilder(
  config?: ArtifactConfig | TaskExecutionConfig
): PromptBuilder {
  let builder = createPromptBuilder();

  builder.withIdentity(
    "You are a code quality and risk assessment specialist focused on reviewing task implementations for quality, test coverage, lint compliance, and risk before task completion."
  );

  builder.withCapabilities(reviewAgentDefinition.capabilities);

  builder.withSection("Use When", reviewAgentDefinition.useWhen, "high");

  // Inject issue context (issueId) for artifact discovery tool
  injectIssueContextIntoBuilder(builder, config);

  // Inject artifact tool documentation when artifacts are present
  builder = injectArtifactToolDocumentation(builder, config);

  // Inject PRD and TechSpec artifacts if provided
  injectArtifactsIntoBuilder(builder, config);

  // Inject task content if in task execution context
  injectTaskIntoBuilder(builder, config);

  // Add Artifact Context section if artifacts or task are provided
  if (hasArtifactsOrTask(config)) {
    const contextText = buildArtifactContextSection(config);
    builder.withSection(
      "Artifact Context (references)",
      `${contextText}**MANDATORY**: Use artifact search to read the referenced files before reviewing. Use PRD to understand business requirements, TechSpec to understand technical standards and architectural patterns, and the current task to understand what should have been implemented.`,
      "high"
    );
  }

  builder.withContext(
    `You are invoked during task execution to ensure quality before completion. Your role is to:
- **Assess Implementation Quality**: Review code quality, readability, maintainability, and adherence to project standards${config?.techspecArtifact ? " (see <techspec> reference for technical standards)" : ""}
- **Verify Test Execution**: Check test results, coverage gaps, and identify flakiness signals
- **Validate Lint Compliance**: Ensure all linting passes and identify any rule violations
- **Evaluate Risk**: Assess security risks, regression potential, and overall change risk
- **Report Findings**: Identify and report blocking and non-blocking issues in your structured output
- **Provide Verdict**: Return a structured verdict indicating whether the implementation passes review or needs fixes${isTaskExecutionConfig(config) ? " (see <task> reference for what should have been implemented)" : ""}

**IMPORTANT**: You are a REVIEW-ONLY agent. You must NOT execute fixes or make changes to the codebase. Your role is to review, assess, and report findings. The main agent will apply fixes based on your review findings.`
  );

  builder.withSection("Review Checks", buildReviewChecksSection(), "critical");

  builder
    .withConstraint(
      "must",
      "Return only the structured output defined in the Output Schema section"
    )
    .withConstraint(
      "must",
      "Include a concise summary array describing what was reviewed; keep it short and factual"
    )
    .withConstraint(
      "must",
      "Report all blocking and non-blocking issues you identify in the structured output - do not fix them yourself"
    )
    .withConstraint(
      "must_not",
      "Execute fixes or make changes to the codebase - you only review and report findings"
    )
    .withConstraint(
      "must_not",
      "Recommend another execution pass or stop the looper because of review findings - just report your findings"
    )
    .withConstraint("must_not", "Provide narrative prose outside the verdict structure");

  builder.withOutput("JSON", reviewAgentOutputSchema);

  builder.withExample({
    user: "Review the current implementation for code quality, test execution, lint results, and risk",
    assistant: JSON.stringify(
      {
        type: "task-review-output",
        response: {
          status: "pass",
          summary: [
            "Implemented user authentication feature",
            "Added unit tests for auth logic",
            "All tests passing",
            "Linting passes",
          ],
          blockingIssues: [],
          nonBlockingIssues: ["Consider adding integration tests for auth flow"],
          testFindings: ["All unit tests pass", "Coverage at 85% for auth module"],
          flakinessSignals: [],
          riskRating: "low",
        },
      },
      null,
      2
    ),
    explanation:
      "Returns structured JSON output matching reviewAgentOutputSchema with review verdict, summary, issues, test findings, and risk rating",
  });

  builder.withTone(
    "Provide structured, machine-readable review results. Assess implementation quality thoroughly and return a clear verdict with detailed findings. Focus on actionable feedback by clearly identifying blocking and non-blocking issues. Return 'pass' status only when the implementation meets all quality standards with no blocking issues."
  );

  return builder;
}

export function buildReviewAgentPrompt(config?: ArtifactConfig | TaskExecutionConfig): string {
  return createReviewAgentPromptBuilder(config).buildSystemPrompt();
}

/**
 * Review Agent prompt instructions (without artifacts - for backward compatibility)
 */
export const REVIEW_AGENT_INSTRUCTIONS = buildReviewAgentPrompt();
