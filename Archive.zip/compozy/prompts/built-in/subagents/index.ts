/**
 * Subagents - Default subagent configurations
 *
 * Combines AgentDefinition metadata with actual prompt instructions
 * to create SubagentConfig objects compatible with @compozy/provider-claude-code
 */

import type { AgentDefinition } from "../../src/types";
import {
  buildBusinessAnalystPrompt,
  BUSINESS_ANALYST_INSTRUCTIONS,
  businessAnalystDefinition,
} from "./business-analyst";
import {
  buildFileExplorerPrompt,
  FILE_EXPLORER_INSTRUCTIONS,
  fileExplorerDefinition,
} from "./file-explorer";
import {
  buildReviewAgentPrompt,
  REVIEW_AGENT_INSTRUCTIONS,
  reviewAgentDefinition,
} from "./review-agent";
import {
  buildRulesExplorerPrompt,
  RULES_EXPLORER_INSTRUCTIONS,
  rulesExplorerDefinition,
} from "./rules-explorer";
import {
  buildTaskEnricherPrompt,
  TASK_ENRICHER_INSTRUCTIONS,
  taskEnricherDefinition,
} from "./task-enricher";
import type { ArtifactConfig, TaskExecutionConfig } from "./types";

/**
 * Subagent configuration compatible with @compozy/provider-claude-code
 * The provider accepts the same agent definitions as the Claude Agent SDK
 */
export interface SubagentConfig {
  /** Agent description */
  description: string;
  /** System prompt/instructions for the agent */
  prompt: string;
  /** Model to use for this agent */
  model?: "sonnet" | "opus" | "haiku" | "inherit";
}

/**
 * Collection of subagents keyed by name
 */
export type SubagentRegistry = Record<string, SubagentConfig>;

export type ArtifactSubagentRegistryOptions = {
  includeFileExplorer?: boolean;
  includeRulesExplorer?: boolean;
  includeBusinessAnalyst?: boolean;
  includeTaskEnricher?: boolean;
  includeReviewAgent?: boolean;
};

/**
 * Converts AgentDefinition to SubagentConfig
 * by combining metadata with actual prompt instructions
 */
function createSubagentFromDefinition(definition: AgentDefinition, prompt: string): SubagentConfig {
  return {
    description: definition.purpose,
    prompt,
    model: "sonnet",
  };
}

/**
 * Creates a File Explorer subagent with optional PRD/TechSpec/Task artifacts injected
 */
export function createFileExplorerSubagent(
  config?: ArtifactConfig | TaskExecutionConfig
): SubagentConfig {
  const prompt = buildFileExplorerPrompt(config);
  return createSubagentFromDefinition(fileExplorerDefinition, prompt);
}

/**
 * Creates a Rules Explorer subagent with optional PRD/TechSpec/Task artifacts injected
 */
export function createRulesExplorerSubagent(
  config?: ArtifactConfig | TaskExecutionConfig
): SubagentConfig {
  const prompt = buildRulesExplorerPrompt(config);
  return createSubagentFromDefinition(rulesExplorerDefinition, prompt);
}

/**
 * Creates a Business Analyst subagent with optional PRD/TechSpec artifacts injected
 */
export function createBusinessAnalystSubagent(
  config?: ArtifactConfig | TaskExecutionConfig
): SubagentConfig {
  const prompt = buildBusinessAnalystPrompt(config);
  return createSubagentFromDefinition(businessAnalystDefinition, prompt);
}

/**
 * Creates a Review Agent subagent with optional PRD/TechSpec/Task artifacts injected
 */
export function createReviewAgentSubagent(
  config?: ArtifactConfig | TaskExecutionConfig
): SubagentConfig {
  const prompt = buildReviewAgentPrompt(config);
  return createSubagentFromDefinition(reviewAgentDefinition, prompt);
}

/**
 * Creates a Task Enricher subagent with PRD and TechSpec artifacts injected
 * This factory function allows the Task Enricher to have access to the same
 * artifact context as the Task Creator agent.
 */
export function createTaskEnricherSubagent(
  config?: ArtifactConfig | TaskExecutionConfig
): SubagentConfig {
  const prompt = buildTaskEnricherPrompt(config);
  return createSubagentFromDefinition(taskEnricherDefinition, prompt);
}

const DEFAULT_ARTIFACT_SUBAGENT_OPTIONS: Required<ArtifactSubagentRegistryOptions> = {
  includeFileExplorer: true,
  includeRulesExplorer: true,
  includeBusinessAnalyst: true,
  includeTaskEnricher: true,
  includeReviewAgent: true,
};

export function createArtifactSubagentRegistry(
  config?: ArtifactConfig | TaskExecutionConfig,
  options?: ArtifactSubagentRegistryOptions
): SubagentRegistry {
  const resolvedOptions = {
    ...DEFAULT_ARTIFACT_SUBAGENT_OPTIONS,
    ...options,
  };

  const registry: SubagentRegistry = {};

  if (resolvedOptions.includeFileExplorer) {
    registry.fileExplorer = createFileExplorerSubagent(config);
  }
  if (resolvedOptions.includeRulesExplorer) {
    registry.rulesExplorer = createRulesExplorerSubagent(config);
  }
  if (resolvedOptions.includeBusinessAnalyst) {
    registry.businessAnalyst = createBusinessAnalystSubagent(config);
  }
  if (resolvedOptions.includeTaskEnricher) {
    registry.taskEnricher = createTaskEnricherSubagent(config);
  }
  if (resolvedOptions.includeReviewAgent) {
    registry.reviewAgent = createReviewAgentSubagent(config);
  }

  return registry;
}

/**
 * Creates default subagents registry using AgentDefinition from individual subagent files
 * combined with actual prompt instructions
 */
export const defaultSubagents: SubagentRegistry = {
  fileExplorer: createSubagentFromDefinition(fileExplorerDefinition, FILE_EXPLORER_INSTRUCTIONS),
  rulesExplorer: createSubagentFromDefinition(rulesExplorerDefinition, RULES_EXPLORER_INSTRUCTIONS),
  businessAnalyst: createSubagentFromDefinition(
    businessAnalystDefinition,
    BUSINESS_ANALYST_INSTRUCTIONS
  ),
  taskEnricher: createSubagentFromDefinition(taskEnricherDefinition, TASK_ENRICHER_INSTRUCTIONS),
  reviewAgent: createSubagentFromDefinition(reviewAgentDefinition, REVIEW_AGENT_INSTRUCTIONS),
};

/**
 * Exports all agent definitions for use in prompt builders
 */
export const defaultAgentDefinitions: AgentDefinition[] = [
  fileExplorerDefinition,
  rulesExplorerDefinition,
  businessAnalystDefinition,
  taskEnricherDefinition,
  reviewAgentDefinition,
];

// Re-export individual definitions for direct access
export {
  BUSINESS_ANALYST_INSTRUCTIONS,
  businessAnalystDefinition,
  businessAnalystOutputSchema,
  type BusinessAnalystOutput,
} from "./business-analyst";
export {
  FILE_EXPLORER_INSTRUCTIONS,
  fileExplorerDefinition,
  fileExplorerOutputSchema,
  type FileExplorerOutput,
} from "./file-explorer";
export {
  REVIEW_AGENT_INSTRUCTIONS,
  reviewAgentDefinition,
  reviewAgentOutputSchema,
  type ReviewAgentOutput,
} from "./review-agent";
export {
  RULES_EXPLORER_INSTRUCTIONS,
  rulesExplorerDefinition,
  rulesExplorerOutputSchema,
  type RulesExplorerOutput,
} from "./rules-explorer";
export {
  buildTaskEnricherPrompt,
  TASK_ENRICHER_INSTRUCTIONS,
  taskEnricherDefinition,
  type TaskEnricherPromptBuilderConfig,
} from "./task-enricher";
export type { ArtifactConfig, IssueConfig, TaskExecutionConfig } from "./types";
