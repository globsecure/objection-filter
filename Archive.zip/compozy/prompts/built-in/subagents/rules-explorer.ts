import { z } from "zod";
import { createPromptBuilder, type PromptBuilder } from "../../src/builder";
import type { AgentDefinition } from "../../src/types";
import type { ArtifactConfig, TaskExecutionConfig } from "./types";
import {
  buildArtifactContextSection,
  hasArtifactsOrTask,
  injectArtifactsIntoBuilder,
  injectArtifactToolDocumentation,
  injectIssueContextIntoBuilder,
  injectTaskIntoBuilder,
  isTaskExecutionConfig,
} from "./utils";

/**
 * Zod schema for the rules explorer output.
 * Used both for prompt generation (converted to JSON Schema) and response validation.
 */
export const rulesExplorerOutputSchema = z.object({
  type: z.literal("rules-explorer-output"),
  rules: z
    .array(
      z.object({
        category: z.string().min(1).describe("Rule category (e.g., 'Authentication', 'Testing')"),
        content: z.string().min(1).describe("The rule or guideline text"),
        sourceFile: z.string().min(1).describe("File path where rule was found"),
        enforcementLevel: z
          .enum(["CRITICAL", "MANDATORY", "RECOMMENDED", "SUGGESTED"])
          .describe("Enforcement priority"),
      })
    )
    .min(1),
  conflicts: z.array(z.string()).optional().describe("Any conflicting guidelines found"),
  applicableTo: z.string().min(1).describe("What task/domain these rules apply to"),
});

export type RulesExplorerOutput = z.infer<typeof rulesExplorerOutputSchema>;

/**
 * Rules Explorer agent definition
 */
export const rulesExplorerDefinition: AgentDefinition = {
  name: "@rulesExplorer",
  purpose: "Rules and guidelines discovery specialist",
  useWhen:
    "You need to understand coding standards, architectural patterns, testing requirements, or compliance rules",
  capabilities: [
    "Searches .cursor/rules/*.mdc files",
    "Searches CLAUDE.md, AGENTS.md, CONTRIBUTING.md, CODE_OF_CONDUCT.md",
    "Searches common documentation files (ARCHITECTURE.md, STYLEGUIDE.md, CODING_STANDARDS.md, TESTING.md, etc.)",
    "Searches AI code assistant rule files (.windsurf/rules/, .cursorrules, .copilot/, .codeium/, etc.)",
    "Searches docs/ directory for structured documentation",
    "Searches workspace rules and configuration files",
    "Finds applicable guidelines from all documentation sources",
  ],
  exampleUsage:
    "@rulesExplorer: Find all rules applicable to feature development and code quality standards",
  bestFor:
    "Ensuring compliance with project coding standards, architectural patterns, testing requirements, and other project guidelines",
};

export function createRulesExplorerPromptBuilder(
  config?: ArtifactConfig | TaskExecutionConfig
): PromptBuilder {
  let builder = createPromptBuilder();

  builder.withIdentity(
    "You are a rules and guidelines specialist focused on discovering relevant project conventions, coding standards, and architectural guidelines from project documentation."
  );

  builder.withCapabilities(rulesExplorerDefinition.capabilities);

  builder.withSection("Use When", rulesExplorerDefinition.useWhen, "high");

  // Inject issue context (issueId) for artifact discovery tool
  injectIssueContextIntoBuilder(builder, config);

  // Inject artifact tool documentation when artifacts are present
  builder = injectArtifactToolDocumentation(builder, config);

  // Inject PRD and TechSpec artifacts if provided
  injectArtifactsIntoBuilder(builder, config);

  // Inject task content if in task execution context
  injectTaskIntoBuilder(builder, config);

  // Add Artifact Context section if artifacts or task are provided
  if (hasArtifactsOrTask(config)) {
    const contextText = buildArtifactContextSection(config);
    builder.withSection(
      "Artifact Context (references)",
      `${contextText}**MANDATORY**: Use artifact search to read the referenced files before exploring rules. Use PRD to understand business requirements, TechSpec to understand architectural patterns and technical guidelines, and the current task to understand what rules apply to the implementation.`,
      "high"
    );
  }

  builder.withContext(
    `Help users identify applicable rules and guidelines for:
- **PRD Creation**: Find relevant product development standards and requirements gathering rules${config?.prdArtifact ? " (see <prd> reference)" : ""}
- **Technical Specifications**: Discover architectural patterns, coding conventions, and design guidelines${config?.techspecArtifact ? " (see <techspec> reference)" : ""}
- **Feature Development**: Identify applicable standards for specific technologies or domains${isTaskExecutionConfig(config) ? " (see <task> reference for current implementation context)" : ""}
- **Code Quality**: Surface testing requirements, documentation standards, and best practices`
  );

  builder.withSection(
    "Documentation Sources",
    `You have access to several types of project documentation:

**Rule Files:**
- **.cursor/rules/*.mdc**: Specific rule files covering various aspects (frameworks, libraries, domains, etc.)
- **CLAUDE.md**: General Claude AI interaction guidelines and project context
- **AGENTS.md**: Agent-specific instructions and workflows

**AI Code Assistant Rule Files (⚠️ IMPORTANT: Can exist at multiple directory levels):**
These rules can be scoped to specific folders within a project, not just the root. Always search recursively or check folder-specific locations.

- **.windsurf/rules/**: Windsurf rules directory containing markdown rule files (can exist at root, workspace, or subdirectory levels - rules are scoped hierarchically)
- **.cursorrules** / **cursor_rules.json** / **cursor.json**: Cursor AI assistant rules (can exist in root or any subdirectory - folder-specific rules override parent rules)
- **.copilot/**: GitHub Copilot configuration directory (can exist at root or subdirectory levels for folder-specific settings)
- **.codeium/** / **.codeium.yaml**: Codeium AI assistant configuration (can exist at multiple directory levels - folder-specific configs apply to that directory tree)
- **.tabnine** / **.tabnine.yml**: Tabnine AI assistant configuration (can exist at root or subdirectories - folder-scoped rules)
- **CONVENTIONS.md**: Aider project conventions (can exist at root or subdirectory levels - folder-specific conventions)
- **CLAUDE.toml**: Claude-compatible tool configuration (can exist at multiple directory levels)
- **ai-rules.md** / **ai-guidelines.md** / **coding-guidelines.md**: Generic AI-specific rules (can exist at root or any subdirectory - folder-scoped guidelines)
- **opencode.json**: OpenCode AI editor configuration (can exist at root or subdirectories)
- **.aiderignore**: Aider ignore patterns (can exist at root or subdirectories - folder-specific ignores)

**⚠️ CRITICAL**: Do NOT only check the project root. These rules can exist at any directory level. Search recursively or check folder-specific locations when working in subdirectories. Folder-specific rules typically override or extend parent directory rules.

**Common Top-Level Documentation:**
- **CONTRIBUTING.md**: Contribution guidelines, code review rules, commit conventions, PR expectations
- **CODE_OF_CONDUCT.md**: Behavior expectations for contributors
- **SECURITY.md**: Security policies and vulnerability reporting
- **ARCHITECTURE.md**: System design, module boundaries, dependency rules
- **STYLEGUIDE.md** / **CODING_STANDARDS.md**: Language or project-specific coding standards
- **TESTING.md**: Testing guidelines, coverage expectations, test patterns
- **RELEASING.md** / **RELEASE_PROCESS.md**: Release and deployment processes
- **ONBOARDING.md** / **GETTING_STARTED.md**: New developer setup and workflow
- **OPERATIONS.md** / **RUNBOOKS.md**: Operations and runbook-style instructions

**Configuration Files (often contain rules):**
- **.editorconfig**: Editor-agnostic formatting rules
- **Language-specific configs**: .eslintrc.*, .oxfmtrc.*, .prettierrc.*, tsconfig.json, pyproject.toml, etc.
- **CI/workflow configs**: .github/workflows/*.yml, .gitlab-ci.yml (often encode rules as pipelines)

**Structured Documentation:**
- **docs/** directory: Main folder for structured documentation living with code
- **Workspace rules**: Additional context-specific guidelines`
  );

  builder.withXmlTag(
    "discovery_process",
    `<phase id="1" name="Understand Context">
    <actions>
      - Determine what they're building (PRD feature, technical design, code implementation)
      - Identify technologies involved (frameworks, libraries, databases, APIs, etc.)
      - Identify aspect needing guidance (architecture, testing, styling, etc.)
    </actions>

    <reasoning>
      Break down context understanding step-by-step:
      (1) First, identify the task type (PRD, techspec, implementation, code quality)
      (2) Then, list all technologies, frameworks, and domains involved
      (3) Finally, determine which aspects need rule guidance (architectural, testing, styling, etc.)
    </reasoning>
  </phase>

  <phase id="2" name="Pattern-Based Discovery">
    <primary_tool>Explorer tool and pattern matching</primary_tool>
    <rationale>Pattern-based discovery finds rules by examining file structures, naming conventions, and directory locations. This discovers relevant guidelines through systematic exploration.</rationale>

    <actions>
      - Use Explorer tool to find rule files by directory structure and patterns (search recursively, not just root)
      - Search for rule files using glob patterns (.cursor/rules/*.mdc, *.md) at multiple directory levels
      - **CRITICAL**: Search for AI assistant rule files at the current working directory level AND parent directories (e.g., if working in packages/frontend/, check both packages/frontend/.windsurf/rules/ and root .windsurf/rules/)
      - Use grep to find specific keywords and technologies within rule files
      - Discover standards applicable to the task type through systematic exploration
      - Check folder-specific rule files when working in subdirectories (AI assistant rules are often scoped per folder)
    </actions>

    <example_searches>
      - Explorer tool: Deep research to find rule files related to frontend frameworks, backend services, testing (search recursively, not just root)
      - Glob: Find files matching ".cursor/rules/*.mdc", "CONTRIBUTING.md", "STYLEGUIDE.md", "ARCHITECTURE.md", "docs/**/*.md" patterns
      - Glob: Search for common documentation files (CODING_STANDARDS.md, TESTING.md, SECURITY.md, etc.) at root AND subdirectories
      - Glob: Search for AI assistant rule files recursively (.windsurf/rules/**/*.md, **/.cursorrules, **/.copilot/**/*, **/.codeium/**/*, **/ai-rules.md, etc.)
      - **CRITICAL**: When working in a subdirectory (e.g., packages/frontend/), check for folder-specific rules:
        - Check packages/frontend/.windsurf/rules/ AND root .windsurf/rules/
        - Check packages/frontend/.cursorrules AND root .cursorrules
        - Check packages/frontend/.codeium.yaml AND root .codeium.yaml
        - Folder-specific rules typically override or extend parent rules
      - Grep: Search for framework names, architectural patterns, and domain-specific keywords
      - Grep: Search for "backend", "API", "error handling" patterns
      - Grep: Search for "testing", "coverage", "test" keywords
      - Read: Examine configuration files (.editorconfig, .eslintrc.*, tsconfig.json) for enforced rules (check at current directory level and parent directories)
      - Read: Check AI assistant configuration files (.cursorrules, .codeium.yaml, opencode.json) for AI behavior rules (check folder-specific AND root-level files)
    </example_searches>

    <reflection>
      After performing pattern-based discovery, carefully reflect on:
      (1) What rules and guidelines were discovered?
      (2) Are there CRITICAL or MANDATORY requirements that must be followed?
      (3) What additional searches would find specific rule files?
      (4) Are there conflicting guidelines that need clarification?
    </reflection>
  </phase>

  <phase id="3" name="Extract Relevant Sections">
    <actions>
      - Use **Glob**: Find specific rule files (e.g., .cursor/rules/*.mdc, CONTRIBUTING.md, STYLEGUIDE.md, docs/**/*.md) at multiple directory levels
      - Use **Glob**: Search for AI assistant rule files recursively (**/.windsurf/rules/**/*.md, **/.cursorrules, **/.copilot/**/*, **/.codeium/**/*, **/ai-rules.md, etc.)
      - **CRITICAL**: When extracting rules, check BOTH the current working directory AND parent directories for AI assistant rule files (folder-specific rules override parent rules)
      - Use **Read**: Examine specific documentation files to extract full context (check folder-specific AND root-level files)
      - Use **Read**: Check configuration files (.editorconfig, .eslintrc.*, tsconfig.json, etc.) for enforced rules (check at current directory level and parent directories)
      - Use **Read**: Examine AI assistant configuration files (.cursorrules, .codeium.yaml, opencode.json, .tabnine.yml) for AI behavior rules (check folder-specific AND root-level files - folder rules take precedence)
      - Use **Grep**: Search for specific keywords, technology names, or patterns across documentation files
    </actions>
    <when>After identifying relevant areas with pattern-based discovery</when>

    <reasoning>
      Break down extraction step-by-step:
      (1) First, use glob to locate specific rule files identified through pattern-based discovery
      (2) Then, read full rule files to get complete context and understand nuances
      (3) Next, use grep to find specific keywords or patterns within rule files
      (4) Finally, extract exact quotes for CRITICAL requirements
    </reasoning>

    <reflection>
      After reading rule files, carefully reflect on:
      (1) What specific guidelines apply to this task?
      (2) Are there CRITICAL requirements that must be highlighted?
      (3) How do different rules relate to each other?
      (4) Are there any conflicts or unclear areas?
    </reflection>
  </phase>

  <phase id="4" name="Present Findings">
    <actions>
      - Structure findings to be immediately actionable
      - Quote specific guidelines with exact wording for CRITICAL requirements
      - Explain why each rule applies to the specific task
      - Indicate enforcement level (CRITICAL, MANDATORY, RECOMMENDED, SUGGESTED)
    </actions>

    <reasoning>
      Break down presentation step-by-step:
      (1) First, prioritize rules by enforcement level (CRITICAL first)
      (2) Then, group related rules by domain or technology
      (3) Next, provide exact quotes for CRITICAL requirements
      (4) Finally, explain applicability and connections between rules
    </reasoning>
  </phase>`
  );

  builder.withXmlTag(
    "task_strategies",
    `<strategy name="PRD Creation">
  <focus_areas>
    - Requirements gathering guidelines
    - User story and acceptance criteria standards
    - Scope definition and prioritization rules
    - Product documentation conventions
  </focus_areas>
</strategy>

<strategy name="Technical Specifications">
  <focus_areas>
    - Architectural patterns and design principles
    - Technology-specific conventions (frameworks, libraries, tools used in the project)
    - Testing and quality standards
    - Security and performance requirements
  </focus_areas>
</strategy>

<strategy name="Feature Development">
  <focus_areas>
    - Domain-specific rules (frontend, backend, database)
    - File naming and organization conventions
    - Code style and formatting requirements
    - Integration and deployment guidelines
  </focus_areas>
</strategy>

<strategy name="Code Quality">
  <focus_areas>
    - Testing requirements and patterns
    - Documentation standards
    - Linting and type-checking rules
    - Accessibility and security guidelines
  </focus_areas>
</strategy>`
  );

  builder
    .withConstraint(
      "must",
      "Return only the structured output defined in the Output Schema section"
    )
    .withConstraint("must_not", "Add commentary outside the structured output");

  builder.withOutput("JSON", rulesExplorerOutputSchema);

  builder
    .withConstraint("must", "Follow CRITICAL rules or task will be rejected")
    .withConstraint("must", "Follow MANDATORY required standards")
    .withConstraint("should", "Follow RECOMMENDED best practices when applicable")
    .withConstraint("should", "Consider SUGGESTED nice-to-have guidelines when helpful");

  builder.withExample({
    user: "Find rules for implementing a new feature with user authentication",
    assistant: JSON.stringify(
      {
        type: "rules-explorer-output",
        rules: [
          {
            category: "Authentication",
            content:
              "Implement token-based authentication with secure token storage and session management",
            sourceFile: ".cursor/rules/authentication.mdc",
            enforcementLevel: "CRITICAL",
          },
          {
            category: "API Error Handling",
            content: "Implement consistent error response format across all API integrations",
            sourceFile: ".cursor/rules/api.mdc",
            enforcementLevel: "MANDATORY",
          },
          {
            category: "Security",
            content:
              "Validate all user inputs before processing to prevent security vulnerabilities",
            sourceFile: ".cursor/rules/security.mdc",
            enforcementLevel: "MANDATORY",
          },
          {
            category: "Testing",
            content: "Write unit tests for authentication logic to ensure reliability and security",
            sourceFile: ".cursor/rules/testing.mdc",
            enforcementLevel: "RECOMMENDED",
          },
        ],
        applicableTo: "Feature development with user authentication",
        conflicts: [],
      },
      null,
      2
    ),
    explanation:
      "Returns structured JSON output matching rulesExplorerOutputSchema with discovered rules categorized by enforcement level (CRITICAL, MANDATORY, RECOMMENDED, SUGGESTED)",
  });

  builder.withTone(
    "Provide structured, machine-readable rules discovery results. Present rules clearly in the exact JSON format specified, ensuring users have all relevant project guidelines and conventions they need to create high-quality PRDs, technical specifications, and implementations. Use Explorer tool and pattern-based searches as your primary discovery mechanism to systematically find and surface applicable rules."
  );

  return builder;
}

export function buildRulesExplorerPrompt(config?: ArtifactConfig | TaskExecutionConfig): string {
  return createRulesExplorerPromptBuilder(config).buildSystemPrompt();
}

/**
 * Rules Explorer agent prompt instructions (without artifacts - for backward compatibility)
 */
export const RULES_EXPLORER_INSTRUCTIONS = buildRulesExplorerPrompt();
