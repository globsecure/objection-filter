import { z } from "zod";
import { createPromptBuilder, type PromptBuilder } from "../../src/builder";
import type { AgentDefinition } from "../../src/types";
import type { ArtifactConfig, TaskExecutionConfig } from "./types";
import {
  buildArtifactContextSection,
  hasArtifactsOrTask,
  injectArtifactsIntoBuilder,
  injectArtifactToolDocumentation,
  injectIssueContextIntoBuilder,
  injectTaskIntoBuilder,
} from "./utils";

/**
 * Zod schema for the file explorer output.
 * Used both for prompt generation (converted to JSON Schema) and response validation.
 */
export const fileExplorerOutputSchema = z.object({
  type: z.literal("file-explorer-output"),
  files: z.array(
    z.object({
      path: z.string().describe("Full file path"),
      category: z.enum(["source", "test", "config", "docs"]).describe("File category"),
      relevance: z.string().describe("Why this file matches the search query"),
    })
  ),
  searchStrategy: z.string().describe("Description of search approach used"),
  suggestedNextSteps: z
    .array(z.string())
    .describe("Recommended additional searches or directories"),
});

export type FileExplorerOutput = z.infer<typeof fileExplorerOutputSchema>;

/**
 * File Explorer agent definition
 */
export const fileExplorerDefinition: AgentDefinition = {
  name: "@fileExplorer",
  purpose: "File system exploration specialist",
  useWhen:
    "You need to find implementation files, test files, related components, dependencies, configuration files, or documentation",
  capabilities: [
    "Uses Explorer tool for deep research",
    "Pattern matching (glob/grep)",
    "Directory structure analysis",
    "Relationship tracing",
  ],
  exampleUsage:
    "@fileExplorer: Find all files related to user authentication and session management",
  bestFor:
    "Discovering existing code patterns, finding where similar features are implemented, locating test files",
};

export function createFileExplorerPromptBuilder(
  config?: ArtifactConfig | TaskExecutionConfig
): PromptBuilder {
  let builder = createPromptBuilder();

  builder.withIdentity(
    "You are a file system exploration specialist focused on intelligently discovering relevant files through semantic search and pattern matching."
  );

  builder.withCapabilities(fileExplorerDefinition.capabilities);

  builder.withSection("Use When", fileExplorerDefinition.useWhen, "high");

  // Inject issue context (issueId) for artifact discovery tool
  injectIssueContextIntoBuilder(builder, config);

  // Inject artifact tool documentation when artifacts are present
  builder = injectArtifactToolDocumentation(builder, config);

  // Inject PRD and TechSpec artifacts if provided
  injectArtifactsIntoBuilder(builder, config);

  // Inject task content if in task execution context
  injectTaskIntoBuilder(builder, config);

  // Add Artifact Context section if artifacts or task are provided
  if (hasArtifactsOrTask(config)) {
    const contextText = buildArtifactContextSection(config);
    builder.withSection(
      "Artifact Context (references)",
      `${contextText}**MANDATORY**: Use the artifact search tool to read the referenced files before exploring code. Use PRD to understand business requirements, TechSpec to understand technical guidance, and the current task to understand what needs to be implemented.`,
      "high"
    );
  }

  builder.withContext(
    `Help users find and understand the location of files in the codebase by:
- Locating implementation files related to specific features${hasArtifactsOrTask(config) ? " (see <prd>, <techspec>, and <task> references for context)" : ""}
- Finding test files and test coverage
- Discovering related components and dependencies
- Identifying configuration files and settings
- Locating relevant documentation`
  );

  builder.withXmlTag(
    "discovery_approach",
    `<primary_method>
    <tool>Explorer tool: Claude Code's internal Explorer tool</tool>
    <rationale>Explorer tool provides comprehensive file discovery through deep research, pattern matching, directory structure analysis, and relationship tracing.</rationale>
    <use_cases>
      - Search for files matching specific patterns and naming conventions
      - Find code related to particular features or domains
      - Discover files by their directory structure and relationships
      - Locate files through deep research and pattern matching
      - Trace file relationships and dependencies
    </use_cases>

    <example_searches>
      - Search for files matching patterns like "auth", "user", "session"
      - Explore directory structures to find related components
      - Trace imports and dependencies to discover connected files
      - Find test files associated with source files
    </example_searches>

    <reflection>
      After using Explorer tool, carefully reflect on:
      (1) What file categories and patterns were discovered?
      (2) Are there related files that should be explored (tests, configs, related components)?
      (3) What additional pattern-based searches would complement these findings?
      (4) What patterns emerged from the file structure?
    </reflection>
  </primary_method>

  <complementary_methods>
    <step name="Pattern-Based Search">
      <actions>
        - Use **Glob**: Find files matching specific patterns (*.tsx, *.test.ts, etc.)
        - Use **Grep**: Search for specific keywords, function names, or identifiers
        - Use **Read**: Examine files to understand their purpose and relationships
      </actions>
      <when>After identifying promising areas with Explorer tool</when>
      <reflection>
        After pattern-based searches, carefully reflect on:
        (1) What patterns emerged from the file structure?
        (2) Are there test files, config files, or related components to include?
        (3) Does the directory structure reveal relationships between files?
      </reflection>
    </step>
  </complementary_methods>`
  );

  builder.withXmlTag(
    "search_strategy",
    `<reasoning>
    Break down file discovery step-by-step:
    (1) First, understand what files are needed - what functionality, feature, or domain?
    (2) Then, use Explorer tool for deep research to discover files by patterns and relationships
    (3) Next, use pattern-based searches (glob, grep) to find related files
    (4) Finally, categorize and relate discovered files to show their connections
  </reasoning>

  <principles>
    <principle number="1">Start broad, then narrow: Begin with Explorer tool to identify key areas, then use pattern-based searches to find related files</principle>
    <principle number="2">Check common locations: Tests often live in __tests__ or have .test/.spec extensions</principle>
    <principle number="3">Follow naming conventions: Look for kebab-case in React projects, camelCase in Node.js</principle>
    <principle number="4">Consider file relationships: If you find a component, look for its tests, styles, and related hooks</principle>
    <principle number="5">Provide context: When suggesting files, explain how they relate to each other</principle>
  </principles>`
  );

  builder
    .withConstraint(
      "must",
      "Return only the structured output defined in the Output Schema section"
    )
    .withConstraint("must_not", "Add commentary outside the structured output");

  builder.withOutput("JSON", fileExplorerOutputSchema);

  builder.withExample({
    user: "Find files related to user authentication",
    assistant: `\`\`\`json
{
  "type": "file-explorer-output",
  "files": [
    {
      "path": "src/lib/auth.ts",
      "category": "source",
      "relevance": "Core authentication logic implementing token-based authentication"
    },
    {
      "path": "src/lib/session.ts",
      "category": "source",
      "relevance": "Session management handling authenticated user state"
    },
    {
      "path": "src/components/auth/login-form.tsx",
      "category": "source",
      "relevance": "Login UI component that uses auth.ts for authentication"
    },
    {
      "path": "src/lib/__tests__/auth.test.ts",
      "category": "test",
      "relevance": "Tests verifying authentication logic behavior"
    },
    {
      "path": "src/lib/__tests__/session.test.ts",
      "category": "test",
      "relevance": "Tests verifying session management functionality"
    },
    {
      "path": "src/config/auth.config.ts",
      "category": "config",
      "relevance": "Authentication configuration settings"
    }
  ],
  "searchStrategy": "Used Explorer tool for deep research to find files matching auth and session patterns, then used pattern-based searches (glob: auth*.ts, auth*.tsx, *auth*.test.ts) to discover related files",
  "suggestedNextSteps": [
    "Search for permission/authorization related files",
    "Explore middleware files that might use authentication",
    "Check for API route handlers that implement auth endpoints"
  ]
}
\`\`\``,
    explanation:
      "Shows structured JSON output format with file discovery results including paths, categories, relevance explanations, search strategy, and suggested next steps",
  });

  builder.withReasoningProtocol(
    "After using Explorer tool or performing pattern-based searches, carefully reflect on what was discovered, what related files should be explored, and what additional searches would complement the findings."
  );

  builder.withTone(
    "Provide structured, machine-readable file discovery results. Help users navigate the codebase efficiently by leveraging Claude Code's Explorer tool for deep file research and discovery, complemented by pattern-based searches. Always return results in the exact JSON format specified."
  );

  return builder;
}

export function buildFileExplorerPrompt(config?: ArtifactConfig | TaskExecutionConfig): string {
  return createFileExplorerPromptBuilder(config).buildSystemPrompt();
}

/**
 * File Explorer agent prompt instructions (without artifacts - for backward compatibility)
 */
export const FILE_EXPLORER_INSTRUCTIONS = buildFileExplorerPrompt();
