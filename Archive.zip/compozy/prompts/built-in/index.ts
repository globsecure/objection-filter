/**
 * Built-in Prompts
 *
 * Centralized location for all refactored prompts using @compozy/prompts builder API.
 *
 * This directory is organized by resource/type:
 * - prd/: PRD creation prompts
 * - techspec/: TechSpec creation prompts
 * - tasks/: Task breakdown prompts
 * - task-execution/: Task execution prompts
 * - shared/: Shared helpers and utilities
 *
 * All prompts use dependency injection for tool names, schemas, and other configuration
 * to ensure reusability and testability.
 *
 * Exports are intentionally wide to provide a single import surface during alpha.
 * If a narrower public API is needed later, replace wildcard exports with curated lists.
 */

// PRD prompts
export * from "./prd";

// TechSpec prompts
export * from "./techspec";

// Tasks prompts
export * from "./tasks";

// Task execution prompts
export * from "./task-execution/factory";

// Task confirmation prompts
export * from "./task-confirmation/factory";
export * from "./task-confirmation/types";

// Task review prompts
export * from "./task-review/factory";
export * from "./task-review/types";

// Shared helpers
export * from "./shared/agents";
export * from "./shared/brainstorming";
export * from "./shared/clarification";
export * from "./shared/constraints";
export * from "./shared/templates";

// Subagents
export * from "./subagents";
