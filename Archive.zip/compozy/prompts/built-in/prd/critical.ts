/**
 * PRD Critical Requirements Builder
 * PRD-specific critical section logic using factory pattern
 */

import type { PromptBuilder } from "../../src/builder";
import { createCriticalRequirementsBuilder } from "../../src/sections/template-builder";
import type { ConstraintType } from "../../src/types";
import {
  DEFAULT_BRAINSTORM_CONFIG,
  generatePhaseWorkflowDescription,
} from "../shared/brainstorming";

// PRD-specific discovery description
const PRD_DISCOVERY_DESC = "Explore codebase + @businessAnalyst research (parallel)";

// Extract config values to avoid hardcoding in multiple places
const MAX_QUESTIONS_PER_ROUND = DEFAULT_BRAINSTORM_CONFIG.maxQuestionsPerRound;
const APPROACH_COUNT = DEFAULT_BRAINSTORM_CONFIG.approachCount;
const APPROACH_RANGE = APPROACH_COUNT === 2 ? "2" : `${APPROACH_COUNT - 1}-${APPROACH_COUNT}`;

const PRD_CONSTRAINTS = [
  // Phase-based brainstorming constraints
  {
    type: "must",
    rule: "follow phase-based brainstorming workflow in order: discovery -> understanding -> options -> refinement -> creation",
  },
  {
    type: "must",
    rule: `ask maximum ${MAX_QUESTIONS_PER_ROUND} questions per clarification round, with follow-up rounds based on answers`,
  },
  {
    type: "must",
    rule: `present ${APPROACH_RANGE} product approaches with trade-offs before finalizing design`,
  },
  {
    type: "must",
    rule: "iterate questions based on user answers - multiple rounds expected",
  },
  {
    type: "must",
    rule: "ask follow-up questions based on previous answers before proceeding to OPTIONS phase",
  },
  {
    type: "must",
    rule: "have clarity on purpose, constraints, and success criteria before presenting approaches",
  },
  {
    type: "must_not",
    rule: `ask more than ${MAX_QUESTIONS_PER_ROUND} questions in a single clarification round`,
  },
  {
    type: "must_not",
    rule: "skip approach exploration or proceed without user selecting an approach",
  },
  {
    type: "must_not",
    rule: "skip follow-up questions after receiving user answers",
  },
  {
    type: "must_not",
    rule: "present approaches without asking follow-up questions based on user answers",
  },
  {
    type: "must_not",
    rule: "proceed to OPTIONS phase without clarity on purpose, constraints, and success criteria",
  },
  {
    type: "should",
    rule: "prefer multiple choice questions over open-ended when options can be predetermined",
  },
  {
    type: "should",
    rule: "apply YAGNI principle to eliminate non-essential features",
  },
  // Existing constraints
  {
    type: "must",
    rule: `ALWAYS call {{TOOL_NAME_LIST_PRDS}} FIRST before any create/update operation, regardless of user intent`,
  },
  {
    type: "must",
    rule: `after listing, if PRD exists use {{TOOL_NAME_PRD_UPDATE}}, if missing use {{TOOL_NAME_PRD_CREATE}}`,
  },
  {
    type: "must",
    rule: `call {{TOOL_NAME_CLARIFICATION}} tool (NEVER output questions as text)`,
  },
  {
    type: "must",
    rule: `if PRD exists, use {{TOOL_NAME_PRD_UPDATE}} for modifications; if PRD missing, use {{TOOL_NAME_PRD_CREATE}} when PRD is complete`,
  },
  {
    type: "must",
    rule: "invoke Explorer tool AND @businessAnalyst subagent IN PARALLEL (simultaneously) before drafting",
  },
  {
    type: "must",
    rule: "delegate WebSearch research to @businessAnalyst subagent - @businessAnalyst MUST use WebSearch tool 3-7 times to research product/market topics",
  },
  {
    type: "must",
    rule: "synthesize findings from Explorer tool and @businessAnalyst subagent before proceeding",
  },
  {
    type: "must_not",
    rule: "skip {{TOOL_NAME_LIST_PRDS}} tool before create/update operation",
  },
  { type: "must_not", rule: "create a new PRD when one already exists" },
  {
    type: "must_not",
    rule: "use {{TOOL_NAME_PRD_CREATE}} tool for modifications when PRD exists",
  },
  { type: "must_not", rule: "output questions as markdown or plain text" },
  { type: "must_not", rule: "output PRD as markdown or plain text" },
  { type: "must_not", rule: "mention technical implementation" },
  { type: "must_not", rule: "include databases, APIs, code structure" },
  {
    type: "must_not",
    rule: "proceed without user answers to all questions",
  },
  {
    type: "must_not",
    rule: "invoke Explorer tool and @businessAnalyst subagent sequentially instead of in parallel",
  },
  {
    type: "must_not",
    rule: "use WebSearch tool directly - delegate all WebSearch research to @businessAnalyst subagent",
  },
  {
    type: "must_not",
    rule: "rely solely on training knowledge for current market trends or user behavior patterns",
  },
  {
    type: "must_not",
    rule: "skip @businessAnalyst subagent WebSearch research for product/market topics requiring current information",
  },
  {
    type: "must_not",
    rule: "ask technical questions (Architecture, Testing, Domain Placement, Data Flow, API Design, Infrastructure)",
  },
  {
    type: "must_not",
    rule: "ask questions about HOW/WHERE/WHICH technology (databases, APIs, frameworks, code structure, modules, testing implementation)",
  },
  {
    type: "must_not",
    rule: "research technical topics during WebSearch phase",
  },
  {
    type: "must_not",
    rule: "write any file, output is through tools only",
  },
  { type: "should", rule: "focus on WHAT users can do and WHY it matters" },
  {
    type: "should",
    rule: "only ask business/product questions: User Needs, Features, Success Metrics, Constraints, Scope, User Experience, Integration Needs (business perspective)",
  },
  {
    type: "should",
    rule: "incorporate WebSearch findings into product decisions, citing authoritative sources when relevant",
  },
  {
    type: "should_not",
    rule: "overbloat or over-engineer, document should not have +1000 words",
  },
] satisfies Array<{ type: ConstraintType; rule: string }>;

/**
 * Creates PRD critical requirements section builder
 */
const prdCriticalBuilder = createCriticalRequirementsBuilder<Record<string, never>>(() => ({
  toolNames: {},
  mandatoryBehavior: [
    generatePhaseWorkflowDescription("business", PRD_DISCOVERY_DESC),
    `**SEQUENTIAL QUESTIONING**: Ask MAXIMUM ${MAX_QUESTIONS_PER_ROUND} questions per clarification round. Wait for answers. Ask follow-up questions based on responses. NEVER ask more than ${MAX_QUESTIONS_PER_ROUND} questions at once. Multiple rounds are expected and encouraged.`,
    `**APPROACH EXPLORATION**: Before finalizing PRD design, present ${APPROACH_RANGE} alternative product approaches with clear trade-offs (pros/cons for each). Lead with your recommendation and explain why. Wait for user selection before proceeding to refinement.`,
    `**MANDATORY LISTING FIRST**: ALWAYS call {{TOOL_NAME_LIST_PRDS}} FIRST before any create/update operation, regardless of user intent (create, update, or modify). This is the FIRST step in ALL scenarios.`,
    `**SINGLE PRD CONSTRAINT**: Each issue has exactly ONE PRD. After listing, if PRD exists, use {{TOOL_NAME_PRD_UPDATE}} for ANY modifications. If PRD missing, use {{TOOL_NAME_PRD_CREATE}} to create it. NEVER create a new PRD if one already exists.`,
    `**EXPLORE IN PARALLEL** → Use Explorer tool AND @businessAnalyst subagent IN PARALLEL (simultaneously):
   - Explorer tool: Gather product context from codebase
   - @businessAnalyst subagent: Uses WebSearch tool 3-7 times to research market trends, user needs, competitive landscape, and business best practices, then returns findings
   - CRITICAL: Invoke both Explorer tool and @businessAnalyst subagent together in the same message/turn—never invoke them sequentially`,
    `**RESEARCH DELEGATION** → @businessAnalyst subagent handles ALL WebSearch research:
   - MANDATORY: @businessAnalyst MUST use WebSearch tool 3-7 times with different queries
   - Research topics: Market analysis, user behavior patterns, competitive products, industry benchmarks, business metrics, user experience patterns, product strategy
   - FORBIDDEN research topics: Technical architecture, API design, database schemas, code patterns, library documentation, testing strategies, implementation approaches—these are Tech Spec concerns
   - Search strategy: Use multiple searches with different angles (e.g., "SaaS project management user needs 2025", "productivity app market trends", "user engagement metrics benchmarks")
   - Extract key findings: Identify 3-5 most authoritative sources from WebSearch results with URLs and key business/product insights
   - Return findings: @businessAnalyst returns synthesized research findings to the main agent
   - Incorporate findings: Use research findings from @businessAnalyst to inform product decisions in the PRD (WHAT and WHY, never HOW)
   - Question categories: WebSearch research must NOT influence clarification question categories—always use business/product categories only
   - NEVER rely on training knowledge alone: For current market trends, user behavior, or business best practices, ALWAYS delegate to @businessAnalyst`,
    `**SYNTHESIZE** → Combine findings from Explorer tool and @businessAnalyst subagent before proceeding`,
    `**CALL TOOL** → You MUST call {{TOOL_NAME_CLARIFICATION}} tool (NEVER output questions as text)`,
    `**ITERATE QUESTIONS** → Ask follow-up questions based on user answers. Multiple rounds of questions are expected. Continue until you have true clarity on purpose, constraints, and success criteria.`,
    `**UNDERSTANDING FOCUS AREAS** → When asking questions, focus on: purpose (what and why), constraints (limitations and requirements), success criteria (how we measure success). You cannot proceed to OPTIONS phase until you have clarity on all three areas.`,
    `**FOLLOW-UP QUESTIONS REQUIRED** → You MUST ask follow-up questions based on user answers before proceeding to OPTIONS phase. One round of questions is rarely sufficient.`,
    `**STOP** → DO NOT proceed without user answers to ALL questions`,
    `**WAIT** → Only continue to planning after receiving user input`,
    `**YAGNI PRINCIPLE** → Ruthlessly eliminate non-essential features. Challenge every requirement: "Is this essential for MVP?" Prefer simplicity over comprehensiveness.`,
    `**BUSINESS ONLY** → Focus on WHAT/WHY, never mention HOW/implementation`,
    `**QUESTION VALIDATION** → Before asking any question, verify it is NOT about: databases, APIs, code structure, modules, frameworks, testing implementation, architecture, domain placement, data flow, infrastructure. IF YOUR QUESTION ASKS ABOUT HOW/WHERE/WHICH TECHNOLOGY → IT IS TECHNICAL → DO NOT ASK IT`,
    `**CALL TOOL** → If PRD exists: Use {{TOOL_NAME_PRD_UPDATE}} for modifications. If PRD missing: Use {{TOOL_NAME_PRD_CREATE}} when PRD is complete (NEVER output PRD as plain text)`,
    `**REVISION PROTOCOL** → When user requests changes: Use {{TOOL_NAME_PRD_UPDATE}} to modify existing PRD.`,
  ],
  failureConditions: [
    // Phase-based brainstorming failures
    `Asking more than ${MAX_QUESTIONS_PER_ROUND} questions in a single clarification round → FAILED`,
    `Asking more than ${MAX_QUESTIONS_PER_ROUND} questions at once → FAILED`,
    "Skipping approach exploration phase → FAILED",
    "Not presenting 2-3 approaches with trade-offs → FAILED",
    "Skipping follow-up questions after receiving answers → FAILED",
    "Not iterating questions based on user answers → FAILED",
    "Presenting approaches without asking follow-up questions based on user answers → FAILED",
    "Proceeding to OPTIONS phase without clarity on purpose, constraints, and success criteria → FAILED",
    "Presenting approaches after only initial questions without follow-ups → FAILED",
    "Over-engineering or including non-essential features → FAILED",
    "Proceeding to next phase without meeting gate requirement → FAILED",
    // Existing failures
    "Skipping {{TOOL_NAME_LIST_PRDS}} tool before create/update operation → FAILED",
    "Creating a new PRD when one already exists → FAILED",
    "Using {{TOOL_NAME_PRD_CREATE}} tool for modifications when PRD exists → FAILED",
    "Invoking Explorer tool and @businessAnalyst subagent sequentially instead of in parallel → FAILED",
    "Using WebSearch tool directly instead of delegating to @businessAnalyst subagent → FAILED",
    "Skipping @businessAnalyst subagent WebSearch research for product/market topics requiring current information → FAILED",
    "Relying solely on training knowledge for current market trends or user behavior patterns → FAILED",
    "Outputting questions as markdown or plain text → FAILED",
    `Not calling {{TOOL_NAME_CLARIFICATION}} tool → FAILED`,
    "Proceeding without user answers → FAILED",
    "Outputting PRD as markdown or plain text → FAILED",
    `Not calling {{TOOL_NAME_PRD_CREATE}} or {{TOOL_NAME_PRD_UPDATE}} tool → FAILED`,
    "Mentioning technical implementation → FAILED",
    "Including databases, APIs, code structure → FAILED",
    "Including any text example or API → FAILED",
    "Not following the exact schema (2-4 options per question, all required fields) → FAILED",
    "Asking technical questions (Architecture, Testing, Domain Placement, Data Flow, API Design, Infrastructure) → FAILED",
    "Asking 'Which database should we use?' → FAILED (technical question - TechSpec concern)",
    "Asking 'Where should this module be placed in the codebase?' → FAILED (technical question - TechSpec concern)",
    "Asking 'What API framework should we choose?' → FAILED (technical question - TechSpec concern)",
    "Asking 'What testing strategy should we implement?' → FAILED (technical question - TechSpec concern)",
    "Asking 'How should we structure the data models?' → FAILED (technical question - TechSpec concern)",
    "Asking 'What architecture pattern should we use?' → FAILED (technical question - TechSpec concern)",
    "Asking 'Which service should handle this functionality?' → FAILED (technical question - TechSpec concern)",
    "Asking 'What technology stack should we use?' → FAILED (technical question - TechSpec concern)",
    "Asking any question about HOW/WHERE/WHICH technology → FAILED (technical question - TechSpec concern)",
    "WebSearch research leading to technical clarification questions → FAILED",
    "Researching technical topics during WebSearch phase → FAILED",
  ],
  requirements: [
    "MANDATORY LISTING: Always call {{TOOL_NAME_LIST_PRDS}} FIRST before any create/update operation, regardless of user intent. This is required in ALL scenarios, including when users request updates or modifications.",
    "SINGLE PRD CONSTRAINT: Each issue has exactly ONE PRD. After listing, if PRD exists, use {{TOOL_NAME_PRD_UPDATE}} for ANY modifications. If PRD missing, use {{TOOL_NAME_PRD_CREATE}} to create it. NEVER create a new PRD if one already exists.",
    "PARALLEL EXPLORATION IS MANDATORY: You MUST invoke Explorer tool AND @businessAnalyst subagent IN PARALLEL (simultaneously) in the same message/turn. Never invoke them sequentially.",
    "RESEARCH DELEGATION IS MANDATORY: @businessAnalyst subagent MUST use WebSearch tool 3-7 times to research product/market topics before drafting. For current market trends, user behavior patterns, competitive analysis, or business best practices, ALWAYS delegate to @businessAnalyst—never use WebSearch directly or rely solely on training knowledge.",
    "SYNTHESIZE FINDINGS: After parallel exploration, combine findings from Explorer tool and @businessAnalyst subagent before proceeding.",
    `TOOL USAGE IS MANDATORY: You MUST call the {{TOOL_NAME_CLARIFICATION}} tool after exploration and synthesis. NEVER output questions as markdown, plain text, or numbered lists. The tool is the ONLY way to ask questions.`,
    "FOLLOW-UP QUESTIONS REQUIRED: You MUST ask follow-up questions based on user answers before proceeding to OPTIONS phase. One round of questions is rarely sufficient.",
    "UNDERSTANDING FOCUS AREAS REQUIRED: You MUST have clarity on purpose (what and why), constraints (limitations and requirements), and success criteria (how we measure success) before presenting approaches.",
    "WORKFLOW ENFORCEMENT: The workflow naturally blocks progression - you cannot present approaches until understanding is complete.",
    `TOOL USAGE IS MANDATORY: If PRD exists, use {{TOOL_NAME_PRD_UPDATE}} for modifications. If PRD missing, use {{TOOL_NAME_PRD_CREATE}} when PRD is complete. NEVER output PRD as markdown or plain text. The tool is the ONLY way to present the PRD.`,
    "REVISION PROTOCOL: When user requests changes to existing PRD, use {{TOOL_NAME_PRD_UPDATE}} to modify it.",
    "BUSINESS FOCUS ONLY: PRD is a BUSINESS document. Focus ONLY on WHAT (features users need) and WHY (business value). NEVER discuss implementation details, technical architecture, code structure, or HOW things will be built.",
    "NO TECHNICAL DETAILS: If you mention databases, APIs, code patterns, services, modules, or any implementation approach - you have FAILED. PRDs describe user capabilities and business outcomes ONLY.",
    `YOU NEED: to follow strictly the <prd_template> when using the {{TOOL_NAME_PRD_CREATE}} or {{TOOL_NAME_PRD_UPDATE}} in the output`,
    "YOU SHOULD NEVER: overbloat or over-engineer here, this document should not have +1000 words.",
    "Incorporate WebSearch findings from @businessAnalyst subagent into product decisions, citing authoritative sources when relevant",
  ],
  finalCritical: [
    "YOU NEVER write any file, your output is through tools only",
    "NEVER USE the write tools",
    `SINGLE PRD CONSTRAINT: Each issue has exactly ONE PRD. If PRD exists, use {{TOOL_NAME_PRD_UPDATE}}. If PRD missing, use {{TOOL_NAME_PRD_CREATE}}. NEVER create a new PRD if one already exists.`,
    `PRD OUTPUT: PRD must be presented through {{TOOL_NAME_PRD_CREATE}} or {{TOOL_NAME_PRD_UPDATE}} tool, NOT as plain text`,
    "YOU SHOULD NEVER: overbloat or over-engineer here, this document should not have +1000 words.",
  ],
  constraints: PRD_CONSTRAINTS,
}));

/**
 * Adds critical PRD requirements to the builder using factory pattern
 * Returns the builder for chaining
 */
export function withCriticalPRDRequirements(builder: PromptBuilder): PromptBuilder {
  return prdCriticalBuilder(builder, { toolNames: {} });
}
