/**
 * PRD Clarification Prompt Builder
 * PRD-specific clarification logic with business/product focus
 */

import { buildClarificationPrompt, type ClarificationPromptConfig } from "../shared/clarification";

/**
 * Build PRD clarification prompt
 * PRD-specific clarification logic with business/product focus
 */
export function buildPRDClarificationPrompt(config: ClarificationPromptConfig): string {
  return buildClarificationPrompt(config, {
    title: "PRD (Business/Product Focus)",
    focus: "business",
    restriction:
      "ONLY USE BUSINESS CATEGORIES: Focus exclusively on WHAT (features users need) and WHY (business value).",
    forbiddenCategories:
      "Technical Architecture, Testing Strategy, Domain Placement, Data Flow, API Design, Infrastructure - these belong in Tech Spec and MUST NOT be asked here. Specifically forbidden: database choices, API frameworks, code structure, module placement, testing implementation, architecture patterns, data models, service boundaries, technology stack decisions.",
    categories: [
      "**User Needs & Goals**: Primary problems, user outcomes, target personas",
      "**Core Features & Functionality**: Key capabilities, feature priorities, MVP scope",
      "**Success Metrics**: KPIs, measurement approach, success criteria (business-focused)",
      "**Constraints & Requirements**: Compliance, integrations, performance targets (high-level business requirements)",
      "**Scope & Prioritization**: Must-have vs nice-to-have, phasing strategy",
      "**User Experience**: Interaction patterns, workflows, usability goals",
      "**Integration Needs**: Required systems, data sources, external dependencies (business perspective - what needs to integrate, not how)",
    ],
    neverAskAbout:
      "Technical architecture, code structure, database design, API endpoints, testing implementation, technology choices, module placement, data models, service boundaries, frameworks, libraries - these are Tech Spec concerns",
    questionExamples: `**QUESTION EXAMPLES - DO vs DON'T**:

✅ **DO ASK (Business/Product Questions)**:
- "What user problem does this feature solve?"
- "What business value does this provide?"
- "Who is the target user persona?"
- "What success metrics should we track?"
- "What are the high-level integration requirements?"
- "What user outcomes should this feature deliver?"
- "What compliance or regulatory requirements must be met?"
- "What are the must-have vs nice-to-have features?"

❌ **DON'T ASK (Technical Questions - FORBIDDEN)**:
- "Which database should we use?" → Technical (TechSpec concern)
- "What API framework should we choose?" → Technical (TechSpec concern)
- "Where should this module be placed in the codebase?" → Technical (TechSpec concern)
- "What testing strategy should we implement?" → Technical (TechSpec concern)
- "How should we structure the data models?" → Technical (TechSpec concern)
- "What architecture pattern should we use?" → Technical (TechSpec concern)
- "Which service should handle this functionality?" → Technical (TechSpec concern)
- "What technology stack should we use?" → Technical (TechSpec concern)

**VALIDATION CHECKPOINT**: Before asking any question, verify it is NOT about: databases, APIs, code structure, modules, frameworks, testing implementation, architecture, domain placement, data flow, infrastructure. If your question asks about HOW/WHERE/WHICH technology → IT IS TECHNICAL → DO NOT ASK IT.`,
    webSearchEnforcement: `**CATEGORY RESTRICTION IS ABSOLUTE**:
- WebSearch research findings must NOT influence your question category selection
- Even if WebSearch reveals technical information, you MUST use business/product categories only
- Technical categories are FORBIDDEN regardless of what you discover in research
- If WebSearch results contain technical details, ignore them for clarification questions—focus only on business/product aspects`,
    explorationContext: "exploration and research",
  });
}
