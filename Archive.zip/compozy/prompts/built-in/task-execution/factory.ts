/**
 * Task Execution Prompt Factory
 * Builds task execution prompts using @compozy/prompts builder API
 *
 * This is a centralized, reusable factory for Looper task execution prompts.
 * Separates system prompts from task-specific content to enable provider-specific handling:
 * - Claude SDK: Uses separate systemPrompt and userPrompt
 *
 * NOTE: This file contains types and dependencies from the looper package.
 * Types should be imported from the looper package when using this builder.
 */

import { ARTIFACT_LIST_TOOL_NAME } from "@compozy/types";
import { trim } from "es-toolkit/string";
import { createPromptBuilder } from "../../src/builder";
import { withToolDocumentationWithSchema } from "../../src/sections/tools";
import { withSubagentsSection } from "../shared/agents";
import { createArtifactSubagentRegistry, type SubagentRegistry } from "../subagents";
import type { TaskExecutionConfig } from "../subagents/types";

/**
 * Configuration for prompt construction
 */
export interface PromptConfig {
  /** Path to project rules/standards */
  projectRulesPath: string;
  /** Command to run tests */
  testCommand: string;
  /** Command to run linting */
  lintCommand: string;
}

/**
 * Task metadata for prompt context
 *
 * Note: Tasks now use markdown-based content (single `content` field) instead of
 * structured fields (overview, requirements, deliverables, etc.) per the migration plan.
 * All task details are stored in the `content` field as markdown.
 */
export interface Task {
  /** Task identifier */
  id: string;
  /** Task title/name */
  title: string;
  /** File path for the task markdown artifact */
  filePath: string;
  /** Full task content/specification (markdown format) stored in the task artifact file */
  content: string;
  /** Task domain (e.g., "Authentication", "API") */
  domain?: string;
  /** Task type (e.g., "Feature Implementation", "Bug Fix") */
  type?: string;
  /** Task scope (e.g., "Full", "Partial") */
  scope?: string;
  /** Complexity level */
  complexity: string;
  /** Task dependencies (list of task IDs or names) */
  dependencies?: string[];
}

/**
 * Issue context data (PRD, Techspec) from backend
 * Contains file paths for local artifacts to keep prompts compact
 */
export interface IssueContext {
  /** PRD markdown file path (null when unavailable) */
  prdPath: string | null;
  /** TechSpec markdown file path (null when unavailable) */
  techspecPath: string | null;
  /** Issue context markdown file path (null when unavailable) */
  issueContextPath: string | null;
  /** Tasks directory path (null when unavailable) */
  tasksDirPath: string | null;
}

/**
 * Retry context for failed attempts
 */
export interface RetryContext {
  /** Current attempt number (1-based) */
  attempt: number;
  /** Error from previous attempt */
  error?: Error;
  /** Exit code from previous attempt */
  exitCode?: number;
}

type AppendRetryContext = (prompt: string, retryContext: RetryContext) => string;

/**
 * Options for building prompts
 */
type BasePromptBuilderOptions = {
  /** Task to execute */
  task: Task;
  /** Prompt configuration */
  config: PromptConfig;
  /** Issue ID that this task belongs to */
  issueId: string;
  /** Optional issue title for path resolution */
  issueTitle?: string;
  /** Optional issue context data from backend */
  issueContext?: IssueContext;
  /** Optional custom system prompt to append to base */
  customSystemPrompt?: string;
};

export type PromptBuilderOptions =
  | (BasePromptBuilderOptions & {
      retryContext?: undefined;
      appendRetryContext?: undefined;
    })
  | (BasePromptBuilderOptions & {
      retryContext: RetryContext;
      appendRetryContext: AppendRetryContext;
    });

/**
 * Prompt components (system and user prompts)
 */
export interface PromptComponents {
  /** System prompt (instructions, context, rules) */
  systemPrompt: string;
  /** User prompt (task-specific content) */
  userPrompt: string;
  /** Optional subagent registry for task execution */
  subagents?: SubagentRegistry;
}

/**
 * Build critical execution section
 */
function buildCriticalExecutionSection(
  builder: ReturnType<typeof createPromptBuilder>,
  config: PromptConfig
): void {
  // Add constraints for execution rules
  builder
    .withConstraint("must", "complete task in ONE continuous execution from beginning to end")
    .withConstraint("must", "complete ALL requirements, subtasks, and deliverables")
    .withConstraint("must", "adhere to ALL project rules and coding standards")
    .withConstraint("must", `ensure all tests pass (${config.testCommand})`)
    .withConstraint("must", `ensure all linting passes (${config.lintCommand})`)
    .withConstraint("must", "obtain approval from the @reviewAgent before completing the task")
    .withConstraint("must", "resolve all blocking issues identified by @reviewAgent")
    .withConstraint("must", "mark all subtasks as complete")
    .withConstraint("must", "update task status to 'completed'")
    .withConstraint("must", "commit ALL changes with a descriptive commit message")
    .withConstraint(
      "must",
      "use web_search and code_search tools to find library documentation when encountering unknown libraries, APIs, or patterns"
    )
    .withConstraint(
      "must",
      "use web_search and code_search tools to research solutions when struggling with difficult bugs, complex problems, or any challenge that cannot be quickly resolved"
    )
    .withConstraint(
      "must",
      "MANDATORY: after 2-3 failed attempts at solving ANY problem, immediately use web_search and code_search to research proper solutions before continuing"
    )
    .withConstraint("must_not", "ask for clarification, confirmation, or approval")
    .withConstraint("must_not", "present plans before executing")
    .withConstraint("must_not", "use workarounds, hacks, or shortcuts")
    .withConstraint("must_not", "skip task completion steps (including commits)")
    .withConstraint(
      "must_not",
      "use unknown libraries/APIs without researching documentation first"
    )
    .withConstraint(
      "must_not",
      "continue attempting workarounds or hacks when stuck on a problem without first researching proper solutions"
    )
    .withConstraint(
      "must_not",
      "introduce code smells or suboptimal solutions due to incomplete understanding of the problem"
    );

  // Add critical section with execution mode details
  builder.withCriticalSection(`**EXECUTION MODE: ONE-SHOT DIRECT IMPLEMENTATION**

You MUST complete this task in ONE continuous execution from beginning to end:

- **NO ASKING**: Do not ask for clarification, confirmation, or approval
- **NO PLANNING MODE**: Execute directly without presenting plans
- **NO PARTIAL WORK**: Complete ALL requirements, subtasks, and deliverables
- **FOLLOW ALL STANDARDS**: Adhere to ALL project rules and coding standards
- **BEST PRACTICES ONLY**: No workarounds, hacks, or shortcuts
- **PROPER SOLUTIONS**: Implement production-ready, maintainable code
- **RESEARCH WHEN NEEDED**: Use web_search and code_search tools to find library documentation, API references, and best practices when you encounter unknown libraries, APIs, or patterns
- **RESEARCH WHEN STUCK**: If you encounter a difficult bug, complex problem, or implementation challenge that you cannot quickly resolve, IMMEDIATELY use web_search and code_search to find proper solutions. Do NOT attempt workarounds or hacks.
- **MANDATORY ESCALATION**: After 2-3 failed attempts at solving ANY problem (bugs, implementation issues, test failures, complex logic), you MUST use web_search and code_search to research proper solutions before trying again. This is NON-NEGOTIABLE.
- **NO WORKAROUNDS WHEN STRUGGLING**: If you find yourself considering a workaround, hack, or suboptimal solution because you don't know the right approach, STOP and research first.

**VALIDATION REQUIREMENTS**:
- All tests MUST pass (${config.testCommand})
- All linting MUST pass (${config.lintCommand})
- All subtasks MUST be marked complete
- Task status MUST be updated to 'completed'
- **ALL changes MUST be committed** with a descriptive commit message

⚠️  **WORK WILL BE INVALIDATED** if:
- Any requirement is incomplete
- Tests/linting fails
- Project standards are violated
- Workarounds are used instead of proper solutions
- Task completion steps are skipped (including commits)
- Commit step is skipped or omitted
- Unknown libraries/APIs are used without researching documentation first
- Workarounds, hacks, or code smells are introduced instead of researching proper solutions
- 3+ failed attempts at solving any problem without using web_search/code_search
- Struggling with a problem without escalating to research tools`);
}

/**
 * Build implementation instructions section
 */
function buildImplementationInstructionsSection(
  builder: ReturnType<typeof createPromptBuilder>,
  config: PromptConfig,
  hasContext: boolean
): void {
  const contextNote = hasContext
    ? `- Review the PRD/TechSpec references below using ${ARTIFACT_LIST_TOOL_NAME} before implementing`
    : "";

  const implementationInstructions = `**MANDATORY READ BEFORE STARTING**:
- Review all project rules and coding standards in ${config.projectRulesPath}
${contextNote}
- Use web_search and code_search tools to research any unknown libraries, APIs, or patterns before implementing`;

  builder.withSection("Implementation Instructions", implementationInstructions, "critical");

  // Add tool documentation using builder-integrated helper
  builder = withToolDocumentationWithSchema(
    builder,
    {
      toolName: "mcp__exa__web_search",
      description:
        "Performs real-time web searches and provides up-to-date information for current events and recent data. Use it to verify external facts, library versions, and best practices.",
      schemaDoc: `\`\`\`typescript
{
  query: string;                    // Required: Your search query
  type?: "auto" | "fast" | "deep"; // Optional: Search type - 'auto' (default, balanced), 'fast' (quick), 'deep' (comprehensive)
  numResults?: number;              // Optional: Number of results to return (default: 8)
  livecrawl?: "fallback" | "preferred"; // Optional: Live crawl mode (default: 'fallback')
  contextMaxCharacters?: number;   // Optional: Maximum characters for context (default: 10000)
}
\`\`\``,
      whenToCall:
        "When you need to verify external facts, library versions, recent documentation, or current best practices. Also use when you encounter a difficult bug or problem that you cannot quickly resolve.",
      behavior:
        "Returns real-time web search results from the most relevant websites. Searches are performed automatically within a single API call.",
      followUpMessages:
        "**MANDATORY**: When you encounter unknown libraries, APIs, patterns, OR when you are stuck on a problem after 2-3 attempts, immediately use web_search before continuing.",
    },
    "high"
  );

  builder = withToolDocumentationWithSchema(
    builder,
    {
      toolName: "mcp__exa__code_search",
      description:
        "Finds relevant context for programming tasks, offering high-quality and fresh context for libraries, SDKs, and APIs. Returns comprehensive code examples, documentation, and API references.",
      schemaDoc: `\`\`\`typescript
{
  query: string;        // Required: Search query for APIs, Libraries, and SDKs
                        // Examples: "React useState hook examples", "Python pandas dataframe filtering",
                        //           "Express.js middleware", "Next js partial prerendering configuration"
  tokensNum?: number;   // Optional: Number of tokens to return (1000-50000, default: 5000)
                        // Use lower values for focused queries, higher for comprehensive documentation
}
\`\`\``,
      whenToCall:
        "When you need code examples, API documentation, implementation patterns, SDK usage examples, or when you need to understand how to solve a complex implementation challenge.",
      behavior:
        "Returns comprehensive code examples, documentation, and API references optimized for finding specific programming patterns and solutions.",
      followUpMessages:
        "**MANDATORY**: Use code_search to find working examples when struggling with implementation challenges. Do not attempt workarounds without researching first.",
    },
    "high"
  );
}

/**
 * Build artifacts access section with tool documentation
 * Issue 028: Explicit instructions for using the artifact search tool
 */
function buildArtifactsAccessSection(
  builder: ReturnType<typeof createPromptBuilder>,
  issueContext?: IssueContext
): void {
  const prdPath = issueContext?.prdPath ? trim(issueContext.prdPath) : "";
  const techspecPath = issueContext?.techspecPath ? trim(issueContext.techspecPath) : "";
  const issueContextPath = issueContext?.issueContextPath
    ? trim(issueContext.issueContextPath)
    : "";
  const tasksDirPath = issueContext?.tasksDirPath ? trim(issueContext.tasksDirPath) : "";

  // Only add this section if we have at least one artifact path
  if (!prdPath && !techspecPath && !issueContextPath && !tasksDirPath) {
    return;
  }

  // Build the list of available artifacts
  const artifactsList: string[] = [];
  if (prdPath) artifactsList.push(`- **PRD**: ${prdPath}`);
  if (techspecPath) artifactsList.push(`- **TechSpec**: ${techspecPath}`);
  if (issueContextPath) artifactsList.push(`- **Issue Context**: ${issueContextPath}`);
  if (tasksDirPath) artifactsList.push(`- **Tasks Directory**: ${tasksDirPath}`);

  const artifactsContent = `You have access to the following artifact files:

${artifactsList.join("\n")}

**IMPORTANT**: Use the \`${ARTIFACT_LIST_TOOL_NAME}\` tool to list all artifacts for the issue.
Do NOT ask the user to provide PRD/TechSpec content - list artifacts and read the files directly.

**Tool Usage**:
\`\`\`typescript
// List all artifacts for the issue
${ARTIFACT_LIST_TOOL_NAME}({
  issueId: "<issue_id>",    // Required: Issue ID
  issueTitle: "..."         // Optional: Issue title
})
\`\`\`

**Workflow**:
1. Call \`${ARTIFACT_LIST_TOOL_NAME}\` to get the list of artifact file paths
2. Read the relevant artifact files directly using the file paths returned
3. Use the artifact content to inform your implementation`;

  builder.withSection("Artifacts Access", artifactsContent, "critical");
}

/**
 * Build PRD/TechSpec context sections (doc references for builder)
 */
function buildContextSections(
  builder: ReturnType<typeof createPromptBuilder>,
  issueContext?: IssueContext
): void {
  const prdPath = issueContext?.prdPath ? trim(issueContext.prdPath) : "";
  const techspecPath = issueContext?.techspecPath ? trim(issueContext.techspecPath) : "";
  const issueContextPath = issueContext?.issueContextPath
    ? trim(issueContext.issueContextPath)
    : "";
  const tasksDirPath = issueContext?.tasksDirPath ? trim(issueContext.tasksDirPath) : "";

  // Add explicit artifacts access section with tool documentation (Issue 028)
  buildArtifactsAccessSection(builder, issueContext);

  if (prdPath) {
    builder.withSection(
      "Product Requirements Document (PRD) (reference)",
      `A PRD file reference is available. Use ${ARTIFACT_LIST_TOOL_NAME} to read relevant sections before implementing.`,
      "high"
    );
    builder.withDocRef(
      "prd",
      `# PRD\n\nFile path: ${prdPath}\n\nUse ${ARTIFACT_LIST_TOOL_NAME} to read relevant sections.`
    );
  }

  if (techspecPath) {
    builder.withSection(
      "Technical Specification (Tech Spec) (reference)",
      `A Tech Spec file reference is available. Use ${ARTIFACT_LIST_TOOL_NAME} to read implementation details.`,
      "high"
    );
    builder.withDocRef(
      "techspec",
      `# TechSpec\n\nFile path: ${techspecPath}\n\nUse ${ARTIFACT_LIST_TOOL_NAME} to read relevant sections.`
    );
  }

  if (issueContextPath) {
    builder.withSection(
      "Issue Context (reference)",
      `An issue context file is available. Use ${ARTIFACT_LIST_TOOL_NAME} if you need additional issue details.`,
      "medium"
    );
    builder.withDocRef(
      "issue_context",
      `# Issue Context\n\nFile path: ${issueContextPath}\n\nUse ${ARTIFACT_LIST_TOOL_NAME} to read relevant sections.`
    );
  }

  if (tasksDirPath) {
    builder.withSection(
      "Tasks Directory (reference)",
      `Task artifacts are stored under: ${tasksDirPath}. Use ${ARTIFACT_LIST_TOOL_NAME} to locate other task files when needed.`,
      "low"
    );
  }
}

/**
 * Build system prompt sections
 */
function buildSystemPromptSections(
  builder: ReturnType<typeof createPromptBuilder>,
  options: PromptBuilderOptions
): void {
  // Task and Issue ID XML tags for reuse across prompt
  builder.withXmlTag("task_id", options.task.id);
  builder.withXmlTag("issue_id", options.issueId);

  buildCriticalExecutionSection(builder, options.config);

  const hasContext =
    Boolean(options.issueContext?.prdPath) ||
    Boolean(options.issueContext?.techspecPath) ||
    Boolean(options.issueContext?.issueContextPath);
  buildImplementationInstructionsSection(builder, options.config, hasContext);

  buildContextSections(builder, options.issueContext);

  // Add subagents section (includes @reviewAgent)
  builder = withSubagentsSection(builder);

  if (options.task.filePath) {
    builder.withDocRef(
      "task",
      `# ${options.task.title} (Task ${options.task.id})\n\nFile path: ${options.task.filePath}\n\nUse ${ARTIFACT_LIST_TOOL_NAME} to read relevant sections if needed.`
    );
  }

  builder.withSection(
    "Current Task (reference)",
    `Task details live in the task artifact file. Use ${ARTIFACT_LIST_TOOL_NAME} to locate requirements, deliverables, and tests.`,
    "high"
  );

  // Add self-correction criteria
  builder.withSelfCorrection([
    `All tests pass (${options.config.testCommand})`,
    `All linting passes (${options.config.lintCommand})`,
    "All subtasks completed",
    "Task status updated to 'completed'",
    "All changes committed with descriptive commit message",
  ]);

  // Add capabilities
  builder.withCapabilities([
    "Execute implementation tasks",
    "Run tests and linting",
    "Commit changes",
  ]);

  // Custom system prompt (if provided)
  if (options.customSystemPrompt) {
    builder.withSection("Additional Instructions", options.customSystemPrompt, "medium");
  }
}

/**
 * Build user prompt (task-specific content)
 *
 * NOTE: This function requires appendRetryContext from the looper package.
 * When using this builder, you should provide a function to append retry context.
 */
export function buildUserPrompt(options: PromptBuilderOptions): string {
  const { task, config } = options;

  const header = buildTaskHeader(task);
  const contextSection = buildTaskContextSection(task);
  const specSection = buildTaskSpecificationSection(task);
  const completionSection = buildCompletionCriteriaSection(task, config);

  let userPrompt = `${header}\n${contextSection}\n${specSection}\n${completionSection}`;

  // Append retry context if present
  if (options.retryContext) {
    if (!options.appendRetryContext) {
      throw new Error("appendRetryContext is required when retryContext is provided");
    }
    userPrompt = options.appendRetryContext(userPrompt, options.retryContext);
  }

  return userPrompt;
}

/**
 * Build task header
 */
function buildTaskHeader(task: Task): string {
  return `# Implementation Task: ${task.title}`;
}

/**
 * Build task context section
 */
function buildTaskContextSection(task: Task): string {
  const lines = [
    "## Task Context",
    "",
    `- **ID**: <task_id>`,
    `- **Title**: ${task.title}`,
    `- **File**: ${task.filePath}`,
    `- **Domain**: ${task.domain || "General"}`,
    `- **Type**: ${task.type || "Implementation"}`,
    `- **Scope**: ${task.scope || "Full"}`,
    `- **Complexity**: ${task.complexity}`,
  ];

  if (task.dependencies && task.dependencies.length > 0) {
    lines.push(`- **Dependencies**: ${task.dependencies.join(", ")}`);
  }

  return lines.join("\n");
}

/**
 * Build task specification section
 * Task details are stored in the task artifact file to avoid bloating the prompt.
 */
function buildTaskSpecificationSection(task: Task): string {
  return `## Task Specification

Task details are stored in the task artifact file.
- **File**: ${task.filePath}
- Use ${ARTIFACT_LIST_TOOL_NAME} to search the task file for requirements, deliverables, and tests.`;
}

/**
 * Build completion criteria section
 */
function buildCompletionCriteriaSection(task: Task, config: PromptConfig): string {
  return `## Completion Criteria

After implementation, you MUST complete ALL of the following steps:

1. **Verify Implementation**:
   - All subtasks in this task are completed
   - All deliverables specified are produced
   - All tests pass: ${config.testCommand}
   - Code passes linting: ${config.lintCommand}

2. **Obtain Review Agent Approval**:
   - **MANDATORY**: Invoke @reviewAgent to review your implementation during primary execution
   - @reviewAgent is a subagent that operates within the same execution session (not a separate phase)
   - @reviewAgent must approve with status 'pass' before you can complete the task
   - Resolve all blocking issues identified by @reviewAgent directly using tools
   - Do not mark the task as complete until @reviewAgent approves
   - Note: Review happens during primary execution via subagent invocation, ensuring quality before confirmation phase

3. **Update Task Status**:
   - Update the task status to 'completed' in the backend system via API
   - Ensure all task metadata is properly updated (retry_count, etc.)

4. **MUST COMMIT Changes**:
   - **MANDATORY**: Commit ALL changes with a descriptive message following project conventions
   - Use conventional commit format: \`feat: complete ${task.title}\` or \`fix: implement ${task.title}\`
   - Commit message should clearly describe what was implemented
   - Example: \`git commit -am "feat: complete ${task.title}"\`
   - ⚠️ **DO NOT skip this step** - commits are required for task completion

<critical>
**DO NOT SKIP ANY COMPLETION STEPS**
Your task is NOT complete until ALL steps above are done, including:
- All deliverables produced
- All tests passing
- All linting passing
- @reviewAgent approval with status 'pass'
- All blocking issues resolved
- Task status updated to 'completed' via backend API
- **ALL changes committed** with a descriptive commit message

⚠️ **TASK WILL BE INVALIDATED** if you skip the review agent step, skip the commit step, or fail to commit changes.
</critical>`;
}

/**
 * Configuration for task execution prompt factory
 */
export type TaskExecutionPromptFactoryConfig = PromptBuilderOptions;

/**
 * Builds task execution prompt using the builder API
 * Returns prompt components (system and user prompts) with subagent registry
 */
export function buildTaskExecutionPrompt(
  config: TaskExecutionPromptFactoryConfig
): PromptComponents {
  const builder = createPromptBuilder();

  buildSystemPromptSections(builder, config);

  // Build system prompt
  const systemPrompt = builder.buildSystemPrompt();

  // Build user prompt (task-specific content)
  const userPrompt = buildUserPrompt(config);

  // Build subagent registry with artifacts + task (issueId required for artifactListTool)
  const taskExecutionConfig: TaskExecutionConfig = {
    issueId: config.issueId,
    ...(config.issueTitle !== undefined && { issueTitle: config.issueTitle }),
    ...(config.issueContext?.prdPath && {
      prdArtifact: {
        id: "prd",
        title: "PRD",
        filePath: config.issueContext.prdPath,
      },
    }),
    ...(config.issueContext?.techspecPath && {
      techspecArtifact: {
        id: "techspec",
        title: "TechSpec",
        filePath: config.issueContext.techspecPath,
      },
    }),
    task: {
      id: config.task.id,
      title: config.task.title,
      filePath: config.task.filePath,
      ...(config.task.complexity !== undefined && {
        complexity: config.task.complexity,
      }),
      ...(config.task.domain !== undefined && { domain: config.task.domain }),
      ...(config.task.type !== undefined && { type: config.task.type }),
      ...(config.task.scope !== undefined && { scope: config.task.scope }),
      ...(config.task.dependencies !== undefined && { dependencies: config.task.dependencies }),
    },
  };

  // NOTE: businessAnalyst is intentionally excluded from task execution context
  // as it's primarily used for PRD creation/planning, not task execution
  const subagents = createArtifactSubagentRegistry(taskExecutionConfig, {
    includeBusinessAnalyst: false,
    includeTaskEnricher: false,
  });

  return {
    systemPrompt,
    userPrompt,
    subagents,
  };
}

/**
 * Default prompt configuration
 */
export const defaultPromptConfig: PromptConfig = {
  projectRulesPath: ".cursor/rules/",
  testCommand: "make test",
  lintCommand: "make lint",
};
