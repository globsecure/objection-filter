/**
 * Tasks Critical Requirements Builder
 * Tasks-specific critical section logic using factory pattern
 */

import type { PromptBuilder } from "../../src/builder";
import { createCriticalRequirementsBuilder } from "../../src/sections/template-builder";
import type { ConstraintType } from "../../src/types";

/**
 * Creates Tasks critical requirements section builder
 */
const tasksCriticalBuilder = createCriticalRequirementsBuilder<Record<string, never>>(() => ({
  toolNames: {},
  mandatoryBehavior: [
    `**MANDATORY LISTING FIRST**: ALWAYS call {{TOOL_NAME_LIST_TASKS}} FIRST before any create/update operation, regardless of user intent (create, update, or modify). This is the FIRST step in ALL scenarios.`,
    `**EXPLORE** → Use the built-in Explorer tool if needed to understand specific codebase patterns or file locations`,
    `**ANALYZE** → Use {{TOOL_NAME_ARTIFACT_LIST}} to read PRD (<prd>) and TechSpec (<techspec>) file references when available to understand scope, dependencies, and implementation approach`,
    `**PLANNING PHASE** → Use {{TOOL_NAME_APPROVE_TASKS}} tool to present high-level tasks for user approval (NEVER output tasks as text). This tool is ONLY for the planning phase - NEVER call it after enrichment completes.`,
    `**STOP** → Wait for user approval JSON response with approved/modified tasks OR user feedback requesting changes`,
    `**HANDLE CHANGES** → If user requests changes via text feedback, revise tasks and call {{TOOL_NAME_APPROVE_TASKS}} tool again (iterative approval process). This is still during planning phase.`,
    `**ITERATE** → Continue presenting revised tasks until user approves (via <tasks-response> JSON). This is still during planning phase.`,
    `**LIST TASKS** → After approval, tasks are automatically persisted by the system. You MUST first call {{TOOL_NAME_LIST_TASKS}} to fetch the list of tasks for the issue`,
    `**ENRICH VIA SUBAGENT** → For EACH task, invoke @taskEnricher subagent. The subagent will explore the codebase and call {{TOOL_NAME_UPDATE_TASK}} directly to save the enriched content. YOU MUST NEVER call {{TOOL_NAME_UPDATE_TASK}} yourself for enrichment - always delegate to @taskEnricher`,
    `**COMPLETION** → After ALL @taskEnricher subagents complete enrichment, respond with brief confirmation: "Tasks enriched successfully". DO NOT call any tools after enrichment completes - no approve_tasks, no update_task, no list_tasks, nothing. Just return the brief message.`,
    `**MANAGEMENT PHASE** → After tasks are enriched, use {{TOOL_NAME_UPDATE_TASK}} ONLY for user-requested modifications (NOT for enrichment), {{TOOL_NAME_DELETE_TASK}} to remove tasks, or {{TOOL_NAME_REORDER_TASKS}} to change priority/sequence`,
  ],
  failureConditions: [
    `Skipping {{TOOL_NAME_LIST_TASKS}} tool before create/update operation → FAILED`,
    "Outputting tasks as markdown or plain text → FAILED",
    `Not calling {{TOOL_NAME_APPROVE_TASKS}} tool during planning phase → FAILED`,
    "Proceeding without user approval → FAILED",
    `Not calling {{TOOL_NAME_APPROVE_TASKS}} tool again when user requests changes during planning phase → FAILED`,
    `Calling {{TOOL_NAME_APPROVE_TASKS}} tool after enrichment completes → FAILED`,
    `Not calling {{TOOL_NAME_LIST_TASKS}} tool to fetch tasks after approval → FAILED`,
    `Not invoking @taskEnricher subagent for task enrichment → FAILED`,
    `Calling any tools after enrichment completes (including approve_tasks, update_task, list_tasks) → FAILED`,
    "Creating tasks without clear deliverables and success criteria in markdown content → FAILED",
    "Missing markdown content following <task_template> structure → FAILED",
    "Creating separate 'test task' or 'final test task' → FAILED",
    "Creating tasks without tests in Deliverables and Tests sections of markdown content → FAILED",
    "Including 'Write tests' as a separate task instead of including tests in implementation task markdown content → FAILED",
  ],
  requirements: [
    `MANDATORY LISTING: Always call {{TOOL_NAME_LIST_TASKS}} FIRST before any create/update operation, regardless of user intent. This is required in ALL scenarios, including when users request updates or modifications.`,
    `PLANNING PHASE TOOLS: You MUST call {{TOOL_NAME_APPROVE_TASKS}} tool to present high-level tasks during planning phase ONLY. NEVER output tasks as markdown or plain text. NEVER call {{TOOL_NAME_APPROVE_TASKS}} after enrichment completes.`,
    `ENRICHMENT PHASE: Tasks are automatically persisted by the system upon user approval. You MUST first call {{TOOL_NAME_LIST_TASKS}} to fetch the list of tasks for the issue. Then, invoke @taskEnricher subagent for EACH task. The subagent will call {{TOOL_NAME_UPDATE_TASK}} directly. YOU MUST NEVER call {{TOOL_NAME_UPDATE_TASK}} yourself for enrichment - always delegate to @taskEnricher.`,
    `MANAGEMENT PHASE TOOLS: After tasks are enriched, use {{TOOL_NAME_UPDATE_TASK}} ONLY for user-requested modifications (NOT for enrichment), {{TOOL_NAME_DELETE_TASK}} to remove tasks, or {{TOOL_NAME_REORDER_TASKS}} to change task priority/sequence when user requests these operations.`,
    "TASK COMPLETENESS: Every task must include: title (in approve_tasks), markdown content via update_task following <task_template>, complexity. Do NOT include position (backend auto-assigns) or status (not managed by agent)",
    "INDEPENDENT DELIVERABLES: Each task must be independently implementable and testable when its dependencies are met",
    "CLEAR SCOPE: Define explicit boundaries for what is in/out of scope for each task",
    "GRANULAR BREAKDOWN: Break large features into manageable tasks with appropriate complexity levels",
    "TESTS IN MARKDOWN CONTENT: Each task's markdown content MUST include tests in both Deliverables section (e.g., 'Unit tests with 80%+ coverage') and Tests section (with checklist items). Tests are not optional - they are required for every implementation task.",
    "NO SEPARATE TEST TASKS: NEVER create separate tasks dedicated solely to testing. Tests must be included within the markdown content of the implementation task they validate.",
  ],
  finalCritical: [
    "YOU NEVER write any file, your output is through tools only",
    "NEVER USE the write tools",
    `TASKS OUTPUT: Tasks must be presented through the {{TOOL_NAME_APPROVE_TASKS}} tool during planning phase, NOT as plain text. NEVER call {{TOOL_NAME_APPROVE_TASKS}} after enrichment completes.`,
    `TASK PERSISTENCE: Tasks are automatically persisted by the system upon user approval. You MUST call {{TOOL_NAME_LIST_TASKS}} to fetch tasks, then invoke @taskEnricher subagent for each task.`,
    `SUBAGENT DELEGATION: You MUST invoke @taskEnricher subagent for EACH task's enrichment. The subagent will call {{TOOL_NAME_UPDATE_TASK}} directly to save the enriched content.`,
    `COMPLETION PROTOCOL: After ALL @taskEnricher subagents complete enrichment, respond with brief confirmation: "Tasks enriched successfully". DO NOT call any tools after enrichment completes - no approve_tasks, no update_task, no list_tasks, nothing. This is your final output.`,
    "YOU MUST: use {{TOOL_NAME_ARTIFACT_LIST}} to read the PRD (<prd>) and TechSpec (<techspec>) file references when available. If either is missing, request the artifact content from the user before task breakdown",
    "YOU NEED: to follow strictly the <task_template> when using {{TOOL_NAME_UPDATE_TASK}} in the output",
    "TESTS REQUIRED: Every implementation task's markdown content MUST include tests in both Deliverables section and Tests section. Tests are mandatory, not optional additions.",
  ],
  constraints: [
    {
      type: "must" as ConstraintType,
      rule: `ALWAYS call {{TOOL_NAME_LIST_TASKS}} FIRST before any create/update operation, regardless of user intent`,
    },
    {
      type: "must" as ConstraintType,
      rule: `call {{TOOL_NAME_APPROVE_TASKS}} tool to present high-level tasks during planning phase ONLY (NEVER output tasks as text). NEVER call {{TOOL_NAME_APPROVE_TASKS}} after enrichment completes.`,
    },
    {
      type: "must" as ConstraintType,
      rule: `call {{TOOL_NAME_LIST_TASKS}} tool to fetch tasks after approval`,
    },
    {
      type: "must" as ConstraintType,
      rule: `invoke @taskEnricher subagent for EACH task (subagent calls {{TOOL_NAME_UPDATE_TASK}} directly). YOU MUST NEVER call {{TOOL_NAME_UPDATE_TASK}} yourself for enrichment - always delegate to @taskEnricher`,
    },
    {
      type: "must_not" as ConstraintType,
      rule: `call {{TOOL_NAME_UPDATE_TASK}} for task enrichment - always delegate to @taskEnricher subagent instead`,
    },
    {
      type: "must" as ConstraintType,
      rule: "wait for user approval JSON response with approved/modified tasks OR user feedback requesting changes",
    },
    {
      type: "must" as ConstraintType,
      rule: "call {{TOOL_NAME_APPROVE_TASKS}} tool again if user requests changes via text feedback during planning phase",
    },
    {
      type: "must" as ConstraintType,
      rule: "After ALL @taskEnricher subagents complete enrichment, respond with brief confirmation: 'Tasks enriched successfully'. DO NOT call any tools after enrichment completes.",
    },
    {
      type: "must" as ConstraintType,
      rule: "use {{TOOL_NAME_ARTIFACT_LIST}} to read PRD (<prd>) and TechSpec (<techspec>) file references when available; if missing, request the artifacts from the user before task breakdown",
    },
    {
      type: "must" as ConstraintType,
      rule: "include title in approve_tasks, then delegate enrichment to @taskEnricher subagent (which will call update_task following <task_template>). Include complexity. Do NOT include position field (backend auto-assigns) or status field (not managed by agent)",
    },
    {
      type: "must" as ConstraintType,
      rule: "follow strictly the <task_template> when using update_task tool",
    },
    {
      type: "must" as ConstraintType,
      rule: "include tests in the deliverables array of every implementation task",
    },
    {
      type: "must_not" as ConstraintType,
      rule: "skip {{TOOL_NAME_LIST_TASKS}} tool before create/update operation",
    },
    { type: "must_not" as ConstraintType, rule: "output tasks as markdown or plain text" },
    { type: "must_not" as ConstraintType, rule: "proceed without user approval" },
    {
      type: "must_not" as ConstraintType,
      rule: "call {{TOOL_NAME_APPROVE_TASKS}} tool after enrichment completes - enrichment phase is finished when all @taskEnricher subagents complete",
    },
    {
      type: "must_not" as ConstraintType,
      rule: "call any tools after enrichment completes (including approve_tasks, update_task, list_tasks) - just return brief confirmation message",
    },
    {
      type: "must_not" as ConstraintType,
      rule: "create tasks without clear deliverables and success criteria",
    },
    {
      type: "must_not" as ConstraintType,
      rule: "create separate tasks dedicated solely to testing",
    },
    {
      type: "must_not" as ConstraintType,
      rule: "create a 'final test task' or 'test task' - tests must be included in each implementation task's deliverables",
    },
    {
      type: "must_not" as ConstraintType,
      rule: "write any file, output is through tools only",
    },
    {
      type: "should" as ConstraintType,
      rule: "break large features into manageable tasks with appropriate complexity levels",
    },
    {
      type: "should" as ConstraintType,
      rule: "ensure each task is independently implementable and testable when its dependencies are met",
    },
    {
      type: "should" as ConstraintType,
      rule: "define explicit boundaries for what is in/out of scope for each task",
    },
  ],
}));

/**
 * Adds critical Tasks requirements to the builder using factory pattern
 * Returns the builder for chaining
 */
export function withCriticalTasksRequirements(builder: PromptBuilder): PromptBuilder {
  return tasksCriticalBuilder(builder, { toolNames: {} });
}
