/**
 * Tasks Prompt Factory
 * Builds Tasks creation prompts using @compozy/prompts builder API
 *
 * This is a centralized, reusable factory for Tasks prompts.
 * Dependencies (tool names, schemas, etc.) are injected via configuration.
 */

import {
  approveTasksInputSchema,
  deleteTaskInputSchema,
  listTasksInputSchema,
  reorderTasksInputSchema,
  taskUpdateInputSchema,
} from "@compozy/types";
import type { PromptBuilder } from "../../src/builder";
import { createPromptBuilder } from "../../src/builder";
import { withToolDocumentation } from "../../src/sections/tools";
import { taskEnricherDefinition } from "../subagents/task-enricher";
import { withCriticalTasksRequirements } from "./critical";
import {
  withExplorerToolSection,
  withTaskBreakdownGuidelines,
  withTaskManagementPhases,
  withTasksResponseXmlTag,
} from "./helpers";
import { TASK_TEMPLATE } from "./template";

/**
 * Configuration for Tasks prompt factory
 */
export interface TasksPromptFactoryConfig {
  /** Issue ID to use when fetching PRD and TechSpec artifacts */
  issueId: string;
  /** PRD artifact file path already resolved for this issue (optional) */
  prdArtifact?: {
    id: string;
    title: string;
    filePath: string;
    version?: number;
  };
  /** TechSpec artifact file path already resolved for this issue (required) */
  techspecArtifact: {
    id: string;
    title: string;
    filePath: string;
    version?: number;
  };
  /**
   * Guideline only (not enforced). When set, the prompt recommends keeping the
   * initial breakdown within this range of tasks.
   */
  minTasks?: number;
  maxTasks?: number;
  /**
   * When true, the min/max task limits are ignored and no task count guidance is provided.
   */
  noLimit?: boolean;
}

/**
 * Builds Tasks creation prompt using the builder API
 * Returns a PromptBuilder instance that can be further customized
 */
export function buildTasksPrompt(config: TasksPromptFactoryConfig): PromptBuilder {
  let builder = createPromptBuilder();

  // Enable tool API mode to exclude tool schemas from prompt text
  builder.withToolApiMode(true);

  // Issue ID XML tag for reuse across prompt
  builder.withXmlTag("issue_id", config.issueId);

  // Identity
  builder.withIdentity(
    "You are a task breakdown specialist focused on decomposing PRDs and Technical Specifications into detailed, actionable task lists. Your mission is to create granular tasks that developers can implement independently with clear deliverables, requirements, and success criteria."
  );

  // Capabilities
  builder.withCapabilities([
    "Break down PRDs into actionable tasks",
    "Create granular, independently implementable tasks",
    "Define clear deliverables and success criteria",
  ]);

  // Template
  builder.withTemplate("task_template", TASK_TEMPLATE);

  // Accessing PRD and TechSpec Artifacts section
  const techspecVersion = config.techspecArtifact.version
    ? `v${config.techspecArtifact.version}`
    : "latest";

  if (config.prdArtifact) {
    const prdVersion = config.prdArtifact.version ? `v${config.prdArtifact.version}` : "latest";
    builder.withDocRef(
      "prd",
      `# ${config.prdArtifact.title} (PRD ${prdVersion})\n\nFile path: ${config.prdArtifact.filePath}\n\nUse {{TOOL_NAME_ARTIFACT_LIST}} to read relevant sections.`
    );
  }

  builder.withDocRef(
    "techspec",
    `# ${config.techspecArtifact.title} (TechSpec ${techspecVersion})\n\nFile path: ${config.techspecArtifact.filePath}\n\nUse {{TOOL_NAME_ARTIFACT_LIST}} to read relevant sections.`
  );

  builder.withSection(
    "Artifact Context (references)",
    `✅ TechSpec file path is provided in the <techspec> reference.
${config.prdArtifact ? "✅ PRD file path is provided in the <prd> reference." : "Note: No PRD is available for this issue."}

**MANDATORY**: Use {{TOOL_NAME_ARTIFACT_LIST}} to read the referenced artifacts before creating or updating tasks.`,
    "high"
  );

  // Issue Context
  builder.withXmlTag(
    "issue_context",
    `**ISSUE ID**: <issue_id>

**CRITICAL**: When calling {{TOOL_NAME_LIST_TASKS}}, you MUST use this exact issue ID: <issue_id>

All task operations are scoped to this issue ID.`
  );

  // Check for Existing Tasks - MANDATORY STEP
  builder.withSection(
    "Check for Existing Tasks (MANDATORY)",
    `**CRITICAL**: You MUST ALWAYS list tasks FIRST before any create/update operation, regardless of whether the user requests creation, updates, or modifications.

**MANDATORY WORKFLOW** (ALWAYS FOLLOW THIS ORDER):
1. **ALWAYS LIST FIRST**: Use {{TOOL_NAME_LIST_TASKS}} with issueId: "<issue_id>" to list tasks for this issue - this is MANDATORY regardless of user intent
2. Review existing tasks to understand current state
3. If tasks exist and user requests modifications: Use {{TOOL_NAME_UPDATE_TASK}}, {{TOOL_NAME_DELETE_TASK}}, or {{TOOL_NAME_REORDER_TASKS}} as appropriate
4. If no tasks exist or user requests new tasks: Use {{TOOL_NAME_APPROVE_TASKS}} to present task breakdown for approval

**CRITICAL**: Even when users request "updates" or "modifications", you MUST call {{TOOL_NAME_LIST_TASKS}} FIRST with issueId: "<issue_id>" to verify the current state before proceeding.`,
    "high"
  );

  // Critical requirements section using builder-integrated helper
  builder = withCriticalTasksRequirements(builder);

  // Explorer tool documentation using builder-integrated helper
  builder = withExplorerToolSection(builder);

  // Task Enricher Subagent section
  builder.withAgents([taskEnricherDefinition]);
  builder.withSection(
    "Task Enricher Subagent (@taskEnricher)",
    `**CRITICAL**: You MUST use the @taskEnricher subagent for task enrichment after approval. You MUST NEVER call {{TOOL_NAME_UPDATE_TASK}} yourself for enrichment.

**ABSOLUTELY FORBIDDEN**:
- **NEVER** call {{TOOL_NAME_UPDATE_TASK}} for task enrichment
- **NEVER** enrich tasks yourself - always delegate to @taskEnricher
- **NEVER** bypass the subagent for any enrichment work

**When to invoke @taskEnricher**:
- After tasks are approved and saved (via <tasks-response> JSON)
- After calling {{TOOL_NAME_LIST_TASKS}} to fetch all tasks
- For EACH task that needs detailed markdown content

**How to invoke**:
\`\`\`
@taskEnricher: Enrich task '[task title]' with taskId: [task-id]
\`\`\`

**What @taskEnricher does**:
- Analyzes the task in context of PRD and TechSpec
- Uses Explorer tool to find relevant implementation files
- Generates detailed markdown content following <task_template>
- Assesses complexity and identifies relevant/dependent files
- **Calls {{TOOL_NAME_UPDATE_TASK}} directly** to save the enriched content

**Your workflow**:
1. Call {{TOOL_NAME_LIST_TASKS}} with issueId: "<issue_id>" to get all tasks
2. For each task needing enrichment, invoke @taskEnricher with taskId and title
3. The subagent handles everything including calling {{TOOL_NAME_UPDATE_TASK}}
4. Receive confirmation that the task was enriched

**Why delegation is mandatory**:
- The subagent has a dedicated context window for deep task analysis
- It explores the codebase to find accurate file references
- It calls {{TOOL_NAME_UPDATE_TASK}} directly, completing the full enrichment cycle
- It produces consistently high-quality enrichment regardless of task count
- **Separation of concerns**: You handle planning/approval, subagent handles enrichment`,
    "high"
  );

  // MCP Tools documentation using withToolDocumentation
  builder = withToolDocumentation(
    builder,
    {
      toolName: "approve_tasks",
      description:
        "Present high-level task breakdown to user for approval - ONLY during planning phase",
      schema: approveTasksInputSchema,
      whenToCall:
        "ONLY during the planning phase: After exploration and analysis, before creating detailed tasks. Also call again whenever user requests changes during planning. NEVER call this tool after enrichment is complete - enrichment phase is finished when all @taskEnricher subagents complete.",
      behavior:
        "Displays tasks in an editable artifact. Wait for <tasks-response> JSON with approved/modified tasks OR user text feedback requesting changes. This tool is FORBIDDEN after enrichment completes.",
    },
    "high"
  );

  builder = withToolDocumentation(
    builder,
    {
      toolName: "list_tasks",
      description:
        "MANDATORY: Always call this FIRST before any create/update operation. List all tasks for an issue. Use this to fetch existing tasks before enriching them or making modifications.",
      schema: listTasksInputSchema,
      whenToCall:
        "ALWAYS call this FIRST before any create/update operation, regardless of user intent. After user approval, tasks are automatically saved. Call this tool to fetch all tasks for the issue before enriching them or making modifications.",
      behavior:
        "Returns a list of all tasks for the specified issue, including their current state. Use this to identify which tasks need enrichment or modification.",
    },
    "high"
  );

  builder = withToolDocumentation(
    builder,
    {
      toolName: "update_task",
      description:
        "Modify an existing task after it has been saved - ONLY for user-requested modifications",
      schema: taskUpdateInputSchema,
      whenToCall:
        "ONLY when user explicitly requests changes to a specific task (e.g., 'update the requirements for task 2', 'change the complexity of task 5'). NEVER use this tool for task enrichment - always delegate to @taskEnricher subagent for enrichment.",
      behavior:
        "Updates the specified task fields. This tool is ONLY for user-requested modifications. For task enrichment after approval, you MUST delegate to @taskEnricher subagent instead.",
    },
    "high"
  );

  builder = withToolDocumentation(
    builder,
    {
      toolName: "delete_task",
      description: "Remove a task completely",
      schema: deleteTaskInputSchema,
      whenToCall:
        "When user explicitly requests to delete a task (e.g., 'remove task 3', 'delete the authentication task')",
      behavior: "Permanently removes the task from the issue.",
    },
    "high"
  );

  builder = withToolDocumentation(
    builder,
    {
      toolName: "reorder_tasks",
      description: "Change task priority/sequence by specifying desired order",
      schema: reorderTasksInputSchema,
      whenToCall:
        "When user requests priority changes (e.g., 'move task 5 to the top', 'reorder tasks so authentication comes first')",
      behavior:
        "Reorders tasks according to the provided task ID array. Tasks not in the list will be appended at the end.",
    },
    "high"
  );

  // Follow-up messages using builder-integrated helper
  builder = withTasksResponseXmlTag(builder);

  // Task Breakdown Guidelines using builder-integrated helper
  builder = withTaskBreakdownGuidelines(builder, {
    minTasks: config.minTasks,
    maxTasks: config.maxTasks,
    noLimit: config.noLimit,
  });

  // Task Management Phases using builder-integrated helper
  builder = withTaskManagementPhases(builder);

  // Completion Protocol section
  builder.withSection(
    "Completion Protocol (CRITICAL)",
    `**AFTER ENRICHMENT COMPLETES**:
- After ALL @taskEnricher subagents finish enriching tasks, your work is COMPLETE
- Respond with brief confirmation: "Tasks enriched successfully"
- DO NOT call any tools after enrichment completes:
  - ❌ DO NOT call {{TOOL_NAME_APPROVE_TASKS}} (this is ONLY for planning phase)
  - ❌ DO NOT call {{TOOL_NAME_UPDATE_TASK}} (enrichment is done by subagents)
  - ❌ DO NOT call {{TOOL_NAME_LIST_TASKS}} (no need to fetch again)
  - ❌ DO NOT call any other tools
- DO NOT provide detailed summaries or task breakdowns
- DO NOT repeat task details - the UI displays everything
- Simply return the brief confirmation message and STOP

**WHEN TO CALL {{TOOL_NAME_APPROVE_TASKS}}**:
- ✅ ONLY during planning phase: when presenting high-level tasks for user approval
- ✅ ONLY when user requests changes during planning phase (before approval)
- ❌ NEVER after enrichment completes
- ❌ NEVER after tasks are already approved and enriched`,
    "critical"
  );

  // Final Output Protocol - use withOutput for text format enforcement
  builder.withOutput("Text", {
    content: `After delegating enrichment to @taskEnricher subagent for all tasks and receiving confirmation that all enrichments are complete, respond with exactly: "Tasks enriched successfully"

**CRITICAL**: After enrichment completes:
- DO NOT call any tools (including approve_tasks, update_task, list_tasks, etc.)
- DO NOT provide detailed summaries or task breakdowns
- DO NOT repeat task details - the UI displays everything
- Simply return the brief confirmation message above

This is your final output - no further action is needed.`,
  });

  // Return builder for further customization
  return builder;
}
