/**
 * Tasks Prompt Builder Helpers
 * Optimized helper functions for building Tasks prompts using the builder API
 * Follows the same pattern as PRD/TECHSPEC factories
 */

import type { PromptBuilder } from "../../src/builder";

/**
 * Explorer tool usage guidelines content
 */
const EXPLORER_TOOL_GUIDELINES = `You have access to the Explorer tool for codebase investigation:

- **Purpose**: Search and discover files, patterns, and code structures when needed
- **Use when**: You need to verify file locations, understand specific implementation patterns, or locate related code
- **Note**: PRD and TechSpec file paths are provided in the <prd> and <techspec> references when available. Use {{TOOL_NAME_ARTIFACT_LIST}} to read the referenced artifacts. If either reference is missing, request the artifact content from the user before proceeding with task breakdown.`;

/**
 * Adds Explorer tool section to the builder
 * Returns the builder for chaining
 */
export function withExplorerToolSection(builder: PromptBuilder): PromptBuilder {
  return builder.withSection("Built-in Explorer Tool", EXPLORER_TOOL_GUIDELINES, "high");
}

/**
 * Tasks response XML tag content
 */
const TASKS_RESPONSE_CONTENT = `JSON from UI with approved tasks: { type: "tasks-response", tasksId: "...", tasks: [...] }

**Behavior:**
- On "approved", tasks are automatically saved. Call {{TOOL_NAME_LIST_TASKS}} to fetch all tasks, then invoke @taskEnricher subagent for each task (the subagent will call {{TOOL_NAME_UPDATE_TASK}} directly)
- After delegating enrichment: Respond with brief confirmation only ("Tasks enriched successfully") - DO NOT summarize or repeat task details`;

/**
 * Adds tasks-response XML tag to the builder
 * Returns the builder for chaining
 */
export function withTasksResponseXmlTag(builder: PromptBuilder): PromptBuilder {
  return builder.withXmlTag("tasks-response", TASKS_RESPONSE_CONTENT);
}

interface TaskBreakdownGuidelineConfig {
  minTasks?: number | undefined;
  maxTasks?: number | undefined;
  /**
   * When true, the min/max task limits are ignored and no task count guidance is provided.
   */
  noLimit?: boolean | undefined;
}

/**
 * Task breakdown guidelines XML tag content
 */
const TASK_BREAKDOWN_GUIDELINES_CONTENT = `### Task Structure

Each task must be:
1. **Independently Implementable**: Can be completed when dependencies are met, without waiting for other incomplete tasks
2. **Clearly Scoped**: Explicit boundaries defining what is in/out of scope
3. **Measurable**: Success criteria that are testable and verifiable
4. **Right-Sized**: Appropriately scoped based on complexity level (adjust granularity accordingly)
5. **Standards-Compliant**: Aligned with project conventions discovered via @rulesExplorer

### Complexity Assessment

- **low**: Simple, straightforward changes (configuration, text updates, single-file modifications)
  - Example: Add new field to form, update styling, simple bug fix
- **medium**: Standard development work (new components, API endpoints, moderate integration)
  - Example: New React component with state management, API endpoint with validation
- **high**: Complex implementations (multi-step features, architectural changes, complex data flows)
  - Example: Multi-step feature with integration, complex data flow, performance optimization
- **critical**: Mission-critical or blocking work (security, core architecture, major refactors)
  - Example: Core architecture change, security implementation, major refactor

### Task Fields

**Planning Phase (approve_tasks tool):**
- **title**: Brief, action-oriented summary (e.g., "Implement user authentication API endpoints")
- **slug**: Optional - auto-generated from title if omitted
- **position**: **DO NOT PROVIDE** - Backend auto-assigns positions sequentially

**Enrichment Phase (update_task tool):**
After tasks are approved and saved, enrich each task using {{TOOL_NAME_UPDATE_TASK}} with:
- **content**: Markdown content following <task_template>
- **complexity**: Based on technical difficulty and scope (enum: "low" | "medium" | "high" | "critical")
- **status**: Always "pending" for new tasks (default)

**CRITICAL**: You MUST follow strictly the <task_template> when using {{TOOL_NAME_UPDATE_TASK}} in the output.

### Task Ordering Principles

Order tasks logically:
1. **Foundation First**: Core infrastructure, data models, utilities
2. **Dependencies Before Dependents**: Ensure prerequisites are completed first
3. **Backend Before Frontend**: API endpoints before UI components that consume them
4. **Core Before Extensions**: Essential features before enhancements
5. **Tests Included**: Tests MUST be included as deliverables within each implementation task. NEVER create separate test tasks.

### Test Requirements

**CRITICAL**: Every implementation task MUST include tests in its markdown content:

- Tests are **mandatory deliverables**, not optional additions
- The Deliverables section MUST include test-related items (e.g., "Unit tests with 80%+ coverage", "Integration tests for auth flow")
- The Tests section MUST include test cases with checkboxes
- Tests validate the implementation within the same task - they are not separate deliverables
- NEVER create separate tasks like "Write tests for Task X" or "Final test task"
- If a task implements a feature, its markdown content MUST include tests in both Deliverables and Tests sections

**Examples of correct markdown structure:**
- ✅ Deliverables section includes: "Unit tests with 80%+ coverage **(REQUIRED)**"
- ✅ Tests section includes: checklist items for test cases
- ✅ Both sections are present and comprehensive

**Examples of INCORRECT task structure:**
- ❌ Task without Tests section in markdown content
- ❌ Task with Deliverables missing test requirements
- ❌ Separate task created just for testing`;

/**
 * Adds task_breakdown_guidelines XML tag to the builder
 * Returns the builder for chaining
 */
export function withTaskBreakdownGuidelines(
  builder: PromptBuilder,
  config: TaskBreakdownGuidelineConfig = {}
): PromptBuilder {
  // Skip task count guidance when noLimit is true
  if (config.noLimit === true) {
    return builder.withXmlTag("task_breakdown_guidelines", TASK_BREAKDOWN_GUIDELINES_CONTENT);
  }

  const hasMin = typeof config.minTasks === "number";
  const hasMax = typeof config.maxTasks === "number";

  let taskCountGuidance = "";
  if (hasMin && hasMax) {
    taskCountGuidance = `### Task Count Guidance

Aim for **between ${config.minTasks} and ${config.maxTasks} tasks (inclusive)** in the initial breakdown. This means the breakdown should contain at least ${config.minTasks} tasks and at most ${config.maxTasks} tasks (the maximum value is included). This is a guideline, not a hard limit—prefer clarity over arbitrary splitting, but avoid unnecessary micro-tasks.

`;
  } else if (hasMax) {
    taskCountGuidance = `### Task Count Guidance

Aim for **up to and including ${config.maxTasks} tasks** in the initial breakdown. This means the breakdown should contain at most ${config.maxTasks} tasks (the maximum value is included). This is a guideline, not a hard limit—prefer clarity over arbitrary splitting, but avoid unnecessary micro-tasks.

`;
  } else if (hasMin) {
    taskCountGuidance = `### Task Count Guidance

Aim for **at least ${config.minTasks} tasks** in the initial breakdown. This is a guideline, not a hard limit—prefer clarity over arbitrary splitting, but avoid unnecessary micro-tasks.

`;
  }

  return builder.withXmlTag(
    "task_breakdown_guidelines",
    `${taskCountGuidance}${TASK_BREAKDOWN_GUIDELINES_CONTENT}`
  );
}

/**
 * Task management phases XML tag content
 */
const TASK_MANAGEMENT_PHASES_CONTENT = `### Planning Phase Workflow
1. **Gather Artifacts**: Use {{TOOL_NAME_ARTIFACT_LIST}} to read the PRD (<prd>) and TechSpec (<techspec>) references provided in this prompt. If either reference is missing, request the artifact content from the user before proceeding.
2. **Analyze**: Study PRD and Tech Spec to understand scope and constraints
3. **Draft**: Create high-level task breakdown (titles only - no content yet)
4. **Present**: Call {{TOOL_NAME_APPROVE_TASKS}} tool with tasks containing only titles, STOP immediately
5. **Iterate**: If user requests changes, revise and call {{TOOL_NAME_APPROVE_TASKS}} again until approved
6. **List Tasks**: When <tasks-response> JSON arrives (user has approved), tasks are automatically saved. First call {{TOOL_NAME_LIST_TASKS}} to fetch all tasks for the issue.
7. **Enrich via Subagent**: For EACH task that needs enrichment, invoke the @taskEnricher subagent with:
   - The task ID and title
   - The subagent will use Explorer tool to find relevant files
   - The subagent will call {{TOOL_NAME_UPDATE_TASK}} directly to save the enriched content
   - You will receive confirmation when each task is enriched

**CRITICAL**: Invoke @taskEnricher for each task individually. The subagent has a dedicated context window to deeply analyze each task with PRD/TechSpec references and codebase exploration. The subagent calls {{TOOL_NAME_UPDATE_TASK}} directly - you do NOT need to call it yourself.

### Management Phase Tools
After tasks are enriched, use these tools for modifications:
- **{{TOOL_NAME_UPDATE_TASK}}**: Modify existing task ONLY when user explicitly requests changes (NOT for enrichment - enrichment is handled by @taskEnricher)
- **{{TOOL_NAME_DELETE_TASK}}**: Remove a task
- **{{TOOL_NAME_REORDER_TASKS}}**: Change task priority/sequence`;

/**
 * Adds task_management_phases XML tag to the builder
 * Returns the builder for chaining
 */
export function withTaskManagementPhases(builder: PromptBuilder): PromptBuilder {
  return builder.withXmlTag("task_management_phases", TASK_MANAGEMENT_PHASES_CONTENT);
}
