/**
 * Task Template
 * Template structure for Tasks following markdown-based content format
 */

export const TASK_TEMPLATE = `## Overview

[Brief description of task - 2-3 sentences explaining what the task accomplishes and why it matters]

<critical>
- **ALWAYS READ** the technical docs from this PRD before start
- **REFERENCE TECHSPEC**: Implementation details and code patterns are in TechSpec implementation section - do not duplicate here
- **FOCUS ON "WHAT"**: Describe what needs to be accomplished, not how to implement it
- **MINIMIZE CODE**: Show code only to illustrate current structure or problem areas, not implementation examples
- **TESTS REQUIRED**: Every implementation task MUST include tests in deliverables
</critical>

<requirements>
- [Requirement 1 - specific technical requirement]
- [Requirement 2 - e.g., "MUST authenticate users via JWT tokens"]
- [Requirement 3 - e.g., "MUST validate input using Zod schemas"]
</requirements>

## Subtasks

- [ ] X.1 [Subtask description]
- [ ] X.2 [Subtask description]

## Implementation Details

[Technical guidance - focus on structure and context, not code:]
- Files to create/modify (file paths only)
- Integration points and dependencies
- Reference TechSpec implementation section for code patterns and technical details
- Testing approach (what to test, not how to test)

### Relevant Files

- \`path/to/file.go\`
- \`path/to/file.ts\`

### Dependent Files

- \`path/to/dependency.go\`

## Deliverables

- [Concrete output 1 - e.g., "POST /api/auth/login endpoint"]
- [Concrete output 2 - e.g., "POST /api/auth/logout endpoint"]
- [Concrete output 3 - e.g., "Auth middleware for protected routes"]
- Unit tests with 80%+ coverage **(REQUIRED)**
- Integration tests for [feature] **(REQUIRED)**

## Tests

- Unit tests for this feature:
  - [ ] [Test case 1 - e.g., "Happy path authentication"]
  - [ ] [Test case 2 - e.g., "Invalid credentials handling"]
  - [ ] [Edge cases / error paths - e.g., "Token expiration", "Malformed tokens"]
- Test coverage target: ≥80%
- All tests must pass

## Success Criteria

- All tests passing
- Test coverage ≥80%
- [Measurable outcome 1 - e.g., "Login/logout flow working in development environment"]
- [Measurable outcome 2 - e.g., "Linter shows no errors"]
- [Quality requirement - e.g., "API documentation updated"]
`;
