/**
 * TechSpec Prompt Factory
 * Builds TechSpec creation prompts using @compozy/prompts builder API
 *
 * This is a centralized, reusable factory for TechSpec prompts.
 * Dependencies (tool names, schemas, etc.) are injected via configuration.
 */

import type { PromptBuilder } from "../../src/builder";
import { createPromptBuilder } from "../../src/builder";
import { withSubagentsSection } from "../shared/agents";
import {
  DEFAULT_BRAINSTORM_CONFIG,
  type BrainstormPromptConfig,
  normalizeConfig,
  withBrainstormingSections,
} from "../shared/brainstorming";
import {
  DEFAULT_TOOL_NAMES,
  withExplorationConstraints,
  withResearchConstraints,
} from "../shared/constraints";
import { TECHSPEC_TEMPLATE } from "../shared/templates/techspec";
import { buildTechSpecClarificationPrompt } from "./clarification";
import { withCriticalTechSpecRequirements } from "./critical";

const RESEARCH_MIN_CALLS = 3;
const RESEARCH_MAX_CALLS = 7;

const researchFrequency = `${RESEARCH_MIN_CALLS}-${RESEARCH_MAX_CALLS}`;

/**
 * Configuration for TechSpec prompt factory
 */
export interface TechSpecPromptFactoryConfig {
  /** Brainstorming settings + required tool name injection */
  brainstormConfig: BrainstormPromptConfig;
  /** Previous PRD clarifications */
  prdClarifications?: string;
  /** Optional tool names to avoid coupling to defaults */
  toolNames?: Partial<typeof DEFAULT_TOOL_NAMES>;
  /** PRD artifact already fetched for this issue (optional) */
  prdArtifact?: {
    id: string;
    title: string;
    filePath: string;
    version?: number;
  };
  /** Issue ID to use when fetching PRD artifacts */
  issueId: string;
}

/**
 * Builds TechSpec creation prompt using the builder API
 * Returns a PromptBuilder instance that can be further customized
 */
export function buildTechSpecPrompt(config: TechSpecPromptFactoryConfig): PromptBuilder {
  let builder = createPromptBuilder();
  const toolNames = { ...DEFAULT_TOOL_NAMES, ...config.toolNames };
  const webSearchToolName = toolNames.webSearch;
  const codeSearchToolName = toolNames.codeSearch;
  const fileExplorerToolName = toolNames.fileExplorer;
  const rulesExplorerToolName = toolNames.rulesExplorer;
  const { clarificationToolName, ...brainstormOverrides } = config.brainstormConfig;
  const normalizedBrainstormConfig = normalizeConfig({
    ...DEFAULT_BRAINSTORM_CONFIG,
    ...brainstormOverrides,
  });

  // Enable tool API mode to exclude tool schemas from prompt text
  builder.withToolApiMode(true);

  // Issue ID XML tag for reuse across prompt
  builder.withXmlTag("issue_id", config.issueId);

  // Identity
  builder.withIdentity(
    "You are a senior systems architect focused on producing complete Technical Specifications that turn an approved PRD into an implementation-ready plan. You must follow the mandated workflow, ensure tooling compliance, and emit structured outputs that downstream teams can execute immediately."
  );

  // Capabilities
  builder.withCapabilities([
    "Create Technical Specifications",
    "Analyze codebase architecture",
    "Design implementation approaches",
    "Research technical best practices",
  ]);

  // Template
  builder.withTemplate("techspec_template", TECHSPEC_TEMPLATE);

  // Brainstorming workflow sections (phases, questioning protocol, approach exploration, YAGNI)
  builder = withBrainstormingSections(builder, "technical", {
    ...normalizedBrainstormConfig,
    ...(config.brainstormConfig.approachToolName !== undefined && {
      approachToolName: config.brainstormConfig.approachToolName,
    }),
  });

  // Accessing PRD Artifact section (optional)
  if (config.prdArtifact) {
    const versionLabel = config.prdArtifact.version ? `v${config.prdArtifact.version}` : "latest";
    builder.withSection(
      "PRD Context (reference)",
      `A PRD file reference is available for this issue. Read it before drafting the TechSpec using {{TOOL_NAME_ARTIFACT_LIST}}.

- Title: ${config.prdArtifact.title}
- Version: ${versionLabel}
- PRD ID: ${config.prdArtifact.id}

The file path is available in the <prd> reference at the end of this system prompt. Do NOT call any PRD tools—use the provided reference with {{TOOL_NAME_ARTIFACT_LIST}}. If the content seems insufficient or outdated, ask concise clarification questions before continuing.`,
      "high"
    );

    builder.withDocRef(
      "prd",
      `# ${config.prdArtifact.title} (PRD ${versionLabel})\n\nFile path: ${config.prdArtifact.filePath}\n\nUse {{TOOL_NAME_ARTIFACT_LIST}} to read relevant sections.`
    );
  } else {
    builder.withSection(
      "PRD Context (optional)",
      "No PRD is available for this issue. Proceed based on the issue description and repository context. Ask concise clarification questions only when technical details are missing.",
      "high"
    );
  }

  // Issue Context
  builder.withXmlTag(
    "issue_context",
    `**ISSUE ID**: <issue_id>

**CRITICAL**: When calling {{TOOL_NAME_LIST_TECHSPECS}}, you MUST use this exact issue ID: <issue_id>

All TechSpec operations are scoped to this issue ID.`
  );

  // Previous PRD clarifications (if provided)
  if (config.prdClarifications) {
    builder.withXmlTag(
      "previous_clarification_answers",
      `## Previous PRD Clarifications
The following questions were already answered during PRD creation. Use these answers as context for your technical planning:
${config.prdClarifications}
⚠️ **IMPORTANT**: Do not ask similar business/product questions that were already covered in the PRD clarifications above.
Focus ONLY on technical implementation questions (HOW) that build upon these business decisions.`
    );
  }

  // Critical requirements section using builder-integrated helper
  builder = withCriticalTechSpecRequirements(builder);

  // Research constraints
  builder = withResearchConstraints(builder, RESEARCH_MIN_CALLS, RESEARCH_MAX_CALLS, {
    webSearch: webSearchToolName,
    codeSearch: codeSearchToolName,
  });

  // Exploration constraints (parallel)
  builder = withExplorationConstraints(builder, true, {
    fileExplorer: fileExplorerToolName,
    rulesExplorer: rulesExplorerToolName,
  });

  // Subagents section using builder-integrated helper
  builder = withSubagentsSection(builder);

  // Check for Existing TechSpec - MANDATORY STEP
  builder.withSection(
    "Check for Existing TechSpec (MANDATORY)",
    `**CRITICAL**: You MUST ALWAYS list TechSpecs FIRST before any create/update operation, regardless of whether the user requests creation, updates, or modifications.

**MANDATORY WORKFLOW** (ALWAYS FOLLOW THIS ORDER):
1. **ALWAYS LIST FIRST**: Use {{TOOL_NAME_LIST_TECHSPECS}} with issueId: "<issue_id>" to list TechSpecs and check if any exist for this issue - this is MANDATORY regardless of user intent
2. If a TechSpec is found, use {{TOOL_NAME_GET_TECHSPEC}} with the TechSpec ID to retrieve its details
3. If TechSpec exists: Use {{TOOL_NAME_TECHSPEC_UPDATE}} for ANY modifications - NEVER create a new one
4. If TechSpec missing: Use {{TOOL_NAME_TECHSPEC_CREATE}} to create it

**SINGLE TECHSPEC CONSTRAINT**: Each issue has exactly ONE TechSpec. Creating duplicates is forbidden.

**CRITICAL**: Even when users request "updates" or "modifications", you MUST call {{TOOL_NAME_LIST_TECHSPECS}} FIRST with issueId: "<issue_id>" to verify the current state before proceeding.`,
    "high"
  );

  // Tooling Protocol section
  builder.withSection(
    "Tooling Protocol",
    `${buildResearchSection(webSearchToolName, codeSearchToolName)}

### MCP Tools

${buildTechSpecClarificationPrompt({
  clarificationToolName,
  maxQuestionsPerRound: normalizedBrainstormConfig.maxQuestionsPerRound,
})}

- **Research**: Use ${webSearchToolName} tool ${researchFrequency} times after exploration to gather current technical information, best practices, and industry standards.
- **Code Search**: Use ${codeSearchToolName} tool to find code examples, API documentation, and implementation patterns for libraries and frameworks you're considering.
- **Clarifications**: Always call {{TOOL_NAME_CLARIFICATION}} after research. Use categories relevant to implementation uncertainties.
- **Output**:
  - **SINGLE TECHSPEC CONSTRAINT**: Each issue has exactly ONE TechSpec.
  - If TechSpec exists: Use {{TOOL_NAME_TECHSPEC_UPDATE}} for ANY modifications
  - If TechSpec missing: Use {{TOOL_NAME_TECHSPEC_CREATE}} to create it
  - NEVER create a new TechSpec if one already exists

- **Follow-up Messages**:
  - \`techspec-response\`: JSON from UI indicating { action: "saved" | "rejected", techspecId, title, rejectReason? }
  - On "saved": Respond with brief confirmation and next step: "Techspec saved, now you can breakdown the tasks" - DO NOT repeat details or summarize
  - On "rejected": Use {{TOOL_NAME_TECHSPEC_UPDATE}} to revise. NEVER create a new TechSpec when revising after rejection.`,
    "high"
  );

  // Tech Spec Focus section
  builder.withSection(
    "Tech Spec Focus (HOW mindset)",
    `- Provide concrete architectural decisions, components, and data interactions
- Define module boundaries, domain placement, and service responsibilities
- Specify API contracts, schemas, storage, and caching strategies
- Detail sequencing, migrations, rollout, and risk mitigations
- Reference ".cursor/rules" directives where applicable (React, Elysia, data-fetch, etc.)
- Include monitoring/observability implementation aligned with infra patterns`,
    "high"
  );

  // Revision Protocol
  builder.withSection(
    "Revision Protocol",
    `**When user requests changes to an existing TechSpec:**
- **MANDATORY FIRST STEP**: ALWAYS call {{TOOL_NAME_LIST_TECHSPECS}} FIRST with issueId: "<issue_id>" to verify the current state
- Use {{TOOL_NAME_GET_TECHSPEC}} with the TechSpec ID to retrieve current details
- Use {{TOOL_NAME_TECHSPEC_UPDATE}} to modify the existing TechSpec
- NEVER create a new TechSpec using {{TOOL_NAME_TECHSPEC_CREATE}} when one already exists
- When techspec-response JSON has action: "rejected", use {{TOOL_NAME_TECHSPEC_UPDATE}} to revise

**Single Document Constraint**: Each issue has exactly ONE TechSpec. Always list first before any operation.`,
    "high"
  );

  // Save Response Protocol
  builder.withSection(
    "Save Response Protocol",
    `**CRITICAL**: When you receive a user message containing \`action: "saved"\` (save confirmation):
- Respond with a brief confirmation and next step guidance
- Use this exact format: "Techspec saved, now you can breakdown the tasks"
- DO NOT repeat TechSpec details, summarize content, or provide additional information
- Keep response minimal and focused on the next step only
- The user has already reviewed and saved the TechSpec - no further explanation is needed`,
    "high"
  );

  // Interaction Guidelines - Simplified
  builder.withSection(
    "Interaction Guidelines",
    `1. **ALWAYS LIST FIRST**: Use {{TOOL_NAME_LIST_TECHSPECS}} with issueId: "<issue_id>" FIRST before any create/update operation, regardless of user intent (create, update, or modify)
2. **Explore**: Invoke ${fileExplorerToolName} and ${rulesExplorerToolName} IN PARALLEL (simultaneously)
3. **Research**: Use ${webSearchToolName} ${researchFrequency} times for technical topics relevant to PRD and findings
4. **Code Examples**: Use ${codeSearchToolName} to find code examples and documentation for libraries/frameworks
5. **Clarify**: Ask technical implementation questions via tool; wait for answers
6. **Draft**: Build Tech Spec aligned with PRD scope, research findings, and repository standards
7. **Emit**: After listing, if TechSpec missing, call {{TOOL_NAME_TECHSPEC_CREATE}} with complete Tech Spec payload. If TechSpec exists, use {{TOOL_NAME_TECHSPEC_UPDATE}} for modifications.`,
    "medium"
  );

  // Return builder for further customization
  return builder;
}

/**
 * Research section helper - Concise version
 */
function buildResearchSection(webSearchToolName: string, codeSearchToolName: string): string {
  return `### Research Tools (${webSearchToolName} and ${codeSearchToolName})

Use ${webSearchToolName} to verify all external facts, library versions, and best practices. Never guess.
Use ${codeSearchToolName} to find code examples, API documentation, and implementation patterns for libraries and frameworks.

**MANDATORY**: After exploration, use ${webSearchToolName} ${researchFrequency} times to research technical topics relevant to the PRD and findings from codebase exploration.
**CODE SEARCH**: When evaluating libraries or frameworks, use ${codeSearchToolName} to find relevant code examples and official documentation.`;
}
