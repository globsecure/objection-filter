/**
 * TechSpec Critical Requirements Builder
 * TechSpec-specific critical section logic using factory pattern
 */

import type { PromptBuilder } from "../../src/builder";
import { createCriticalRequirementsBuilder } from "../../src/sections/template-builder";
import type { ConstraintType } from "../../src/types";
import {
  DEFAULT_BRAINSTORM_CONFIG,
  generatePhaseWorkflowDescription,
} from "../shared/brainstorming";

export interface TechSpecCriticalToolNames {
  clarification: string;
  techspecCreate: string;
  techspecUpdate: string;
}

const DEFAULT_TECHSPEC_TOOL_NAMES: TechSpecCriticalToolNames = {
  clarification: "{{TOOL_NAME_CLARIFICATION}}",
  techspecCreate: "{{TOOL_NAME_TECHSPEC_CREATE}}",
  techspecUpdate: "{{TOOL_NAME_TECHSPEC_UPDATE}}",
};

// TechSpec-specific discovery description
const TECHSPEC_DISCOVERY_DESC = "Explore codebase (parallel) + web_search research";

// Extract config values to avoid hardcoding in multiple places
const MAX_QUESTIONS_PER_ROUND = DEFAULT_BRAINSTORM_CONFIG.maxQuestionsPerRound;

/**
 * Creates TechSpec critical requirements section builder
 */
const techSpecCriticalBuilder = createCriticalRequirementsBuilder<TechSpecCriticalToolNames>(
  toolNamesInput => {
    const toolNames: TechSpecCriticalToolNames = {
      ...DEFAULT_TECHSPEC_TOOL_NAMES,
      ...toolNamesInput,
    };
    const { clarification, techspecCreate, techspecUpdate } = toolNames;

    return {
      toolNames,
      mandatoryBehavior: [
        // Phase-based brainstorming workflow - generated from shared source
        generatePhaseWorkflowDescription("technical", TECHSPEC_DISCOVERY_DESC),
        `**SEQUENTIAL QUESTIONING**: Ask MAXIMUM ${MAX_QUESTIONS_PER_ROUND} questions per clarification round. Wait for answers. Ask follow-up questions based on responses. NEVER ask ${MAX_QUESTIONS_PER_ROUND + 2}+ questions at once. Multiple rounds are expected and encouraged.`,
        `**APPROACH EXPLORATION**: Before finalizing TechSpec design, present 2-3 alternative architectural approaches with clear trade-offs (pros/cons for each). Lead with your recommendation and explain why. Wait for user selection before proceeding to refinement.`,
        `**YAGNI PRINCIPLE**: Ruthlessly eliminate non-essential features. Challenge every requirement: "Is this essential for MVP?" Prefer simplicity over comprehensiveness.`,
        // Existing mandatory behaviors
        `**MANDATORY LISTING FIRST**: ALWAYS call {{TOOL_NAME_LIST_TECHSPECS}} FIRST before any create/update operation, regardless of user intent (create, update, or modify). This is the FIRST step in ALL scenarios.`,
        `**SINGLE TECHSPEC CONSTRAINT**: Each issue has exactly ONE TechSpec. After listing, if TechSpec exists, use ${techspecUpdate} for ANY modifications. If TechSpec missing, use ${techspecCreate} to create it. NEVER create a new TechSpec if one already exists.`,
        `**EXPLORE** → Perform deep repo analysis using available subagents FIRST:
   - MANDATORY: Invoke @fileExplorer and @rulesExplorer IN PARALLEL (simultaneously) to maximize efficiency
   - @fileExplorer: Use to discover implementation files, test files, related components, dependencies, and configuration files relevant to the PRD
   - @rulesExplorer: Use to discover applicable coding standards, architectural guidelines, and project conventions from .cursor/rules/*.mdc files
   - Both subagents must be invoked together in the same turn, not sequentially—this reduces exploration time significantly`,
        `**RESEARCH** → Use web search (web_search) and code search (code_search) tools to gather external technical information AFTER exploration:
   - MANDATORY: Use web_search tool 3-7 times with different queries to research technical patterns, best practices, and implementation approaches relevant to the PRD and findings from exploration
   - Research topics: Technology choices, architectural patterns, security best practices, performance optimization, industry standards, library/framework documentation
   - Search strategy: Use multiple searches with different angles (e.g., "React state management patterns 2025", "TanStack Query best practices", "Elysia API design patterns")
   - Code search: Use code_search tool to find code examples, API documentation, and implementation patterns for libraries/frameworks being considered
   - Extract key findings: Identify 3-5 most authoritative sources from web search results with URLs and key technical insights
   - Incorporate findings: Use research findings to inform technical decisions in the Tech Spec
   - NEVER rely on training knowledge alone: For current best practices, library versions, or recent patterns, ALWAYS use web_search and code_search`,
        `**CALL TOOL** → You MUST call ${clarification} tool after research (NEVER output questions as plain text)`,
        `**ITERATE QUESTIONS** → Ask follow-up questions based on user answers. Multiple rounds of questions are expected. Continue until you have true clarity on purpose, constraints, and success criteria.`,
        `**UNDERSTANDING FOCUS AREAS** → When asking questions, focus on: purpose (what and why), constraints (limitations and requirements), success criteria (how we measure success). You cannot proceed to OPTIONS phase until you have clarity on all three areas.`,
        `**FOLLOW-UP QUESTIONS REQUIRED** → You MUST ask follow-up questions based on user answers before proceeding to OPTIONS phase. One round of questions is rarely sufficient.`,
        `**STOP** → Wait for structured user answers before continuing`,
        `**CALL TOOL** → If TechSpec exists: Use ${techspecUpdate} for modifications. If TechSpec missing: Use ${techspecCreate} when Tech Spec is ready (NEVER dump markdown inline)`,
        `**REVISION PROTOCOL** → When user requests changes: Use ${techspecUpdate} to modify existing TechSpec.`,
        `**FOLLOW-UP** → When user sends \`techspec-response\` JSON with action: "rejected", use ${techspecUpdate} to revise. Never create a new TechSpec when revising after rejection.`,
      ],
      failureConditions: [
        // Phase-based brainstorming failures
        `Asking more than ${MAX_QUESTIONS_PER_ROUND} questions in a single clarification round → FAILED`,
        `Asking ${MAX_QUESTIONS_PER_ROUND + 2}+ questions at once → FAILED`,
        "Skipping approach exploration phase → FAILED",
        "Not presenting 2-3 architectural approaches with trade-offs → FAILED",
        "Failing to ask or iterate follow-up questions based on user answers → FAILED",
        "Presenting approaches without adequate follow-ups or iterations based on user answers → FAILED",
        "Proceeding to OPTIONS phase without clarity on purpose, constraints, and success criteria → FAILED",
        "Over-engineering or including non-essential features → FAILED",
        "Proceeding to next phase without meeting gate requirement → FAILED",
        // Existing failures
        `Skipping {{TOOL_NAME_LIST_TECHSPECS}} tool before create/update operation → FAILED`,
        "Creating a new TechSpec when one already exists → FAILED",
        `Using ${techspecCreate} tool for modifications when TechSpec exists → FAILED`,
        `Creating a new TechSpec when revising after rejection (should use ${techspecUpdate}) → FAILED`,
        "Skipping web_search research for technical topics requiring current information → FAILED",
        "Relying solely on training knowledge for current best practices or library versions → FAILED",
        "Not using code_search to find code examples and documentation when evaluating libraries/frameworks → FAILED",
        "Invoking @fileExplorer and @rulesExplorer sequentially instead of in parallel → FAILED",
        `Skipping ${clarification} tool → FAILED`,
        "Emitting clarifications as text instead of tool → FAILED",
        "Proceeding without user answers → FAILED",
        `Producing Tech Spec as plain text instead of ${techspecCreate} or ${techspecUpdate} tool → FAILED`,
        `Not calling ${techspecCreate} or ${techspecUpdate} tool → FAILED`,
        "Ignoring user follow-up JSON messages → FAILED",
        "Mixing PRD-style business writing (WHAT/WHY) instead of deeply technical HOW → FAILED",
        "Not following the exact template structure → FAILED",
        "Asking business questions (User Needs, Business Metrics, User Experience, Feature Prioritization) → FAILED",
        "Asking questions repeated from the <previous_clarification_answers> → FAILED",
      ],
      requirements: [
        `MANDATORY LISTING: Always call {{TOOL_NAME_LIST_TECHSPECS}} FIRST before any create/update operation, regardless of user intent. This is required in ALL scenarios, including when users request updates or modifications.`,
        `SINGLE TECHSPEC CONSTRAINT: Each issue has exactly ONE TechSpec. After listing, if TechSpec exists, use ${techspecUpdate} for ANY modifications. If TechSpec missing, use ${techspecCreate} to create it. NEVER create a new TechSpec if one already exists.`,
        "RESEARCH IS MANDATORY: You MUST use web_search tool 3-7 times to research technical topics before drafting. For current best practices, library versions, security patterns, or recent architectural approaches, ALWAYS use web_search—never rely solely on training knowledge.",
        "CODE SEARCH IS MANDATORY: When selecting or validating external libraries/frameworks, use code_search to find code examples, API documentation, and implementation patterns. This provides the highest quality and freshest context for libraries, SDKs, and APIs.",
        `TOOL USAGE IS MANDATORY: You MUST call the ${clarification} tool after research. NEVER output questions as markdown, plain text, or numbered lists. The tool is the ONLY way to ask questions.`,
        "FOLLOW-UP QUESTIONS REQUIRED: You MUST ask follow-up questions based on user answers before proceeding to OPTIONS phase. One round of questions is rarely sufficient.",
        "UNDERSTANDING FOCUS AREAS REQUIRED: You MUST have clarity on purpose (what and why), constraints (limitations and requirements), and success criteria (how we measure success) before presenting approaches.",
        "WORKFLOW ENFORCEMENT: The workflow naturally blocks progression - you cannot present approaches until understanding is complete.",
        `TOOL USAGE IS MANDATORY: If TechSpec exists, use ${techspecUpdate} for modifications. If TechSpec missing, use ${techspecCreate} when Tech Spec is complete. NEVER output Tech Spec as markdown or plain text. The tool is the ONLY way to present the Tech Spec.`,
        `REVISION PROTOCOL: When user requests changes to existing TechSpec, use ${techspecUpdate} to modify it. When techspec-response JSON has action: rejected, use ${techspecUpdate} to revise.`,
        `YOU NEED: to follow strictly the <techspec_template> when using the ${techspecCreate} or ${techspecUpdate} in the output`,
        "YOU SHOULD NEVER: overbloat or over-engineer here, this document should not have +1500 words.",
        "Treat provided template as non-negotiable structure; populate every section with concise, implementation-ready details",
        "Focus on technical architecture, sequencing, dependencies, risks, observability, and compliance with project standards",
        "Reference code paths, services, data flows, and integration points explicitly",
        "Include monitoring/observability implementation aligned with infra patterns",
        "Keep Tech Spec under ~1500 words but information-dense",
        "Incorporate web_search and code_search findings into technical decisions, citing authoritative sources when relevant",
      ],
      finalCritical: [
        "YOU NEVER write any file, your output is through tools only",
        "NEVER USE the write tools",
        `SINGLE TECHSPEC CONSTRAINT: Each issue has exactly ONE TechSpec. If TechSpec exists, use ${techspecUpdate}. If TechSpec missing, use ${techspecCreate}. NEVER create a new TechSpec if one already exists.`,
        `TECHSPEC OUTPUT: Tech Spec must be presented through ${techspecCreate} or ${techspecUpdate} tool, NOT as plain text`,
        "YOU SHOULD NEVER: overbloat or over-engineer here, this document should not have +1500 words.",
        "YOU MUST: follow the exact template structure",
        "YOU MUST: use the provided PRD reference (<prd>) when available; if missing, request the PRD content from the user before drafting",
        "YOU CANNOT ASK QUESTION: repeated from the <previous_clarification_answers>",
      ],
      constraints: [
        // Phase-based brainstorming constraints
        {
          type: "must" as ConstraintType,
          rule: "follow phase-based brainstorming workflow in order: discovery -> understanding -> options -> refinement -> creation",
        },
        {
          type: "must" as ConstraintType,
          rule: `ask maximum ${MAX_QUESTIONS_PER_ROUND} questions per clarification round, with follow-up rounds based on answers`,
        },
        {
          type: "must" as ConstraintType,
          rule: "present 2-3 architectural approaches with trade-offs before finalizing design",
        },
        {
          type: "must" as ConstraintType,
          rule: "iterate clarification rounds: ask follow-up questions based on user answers before proceeding to OPTIONS phase",
        },
        {
          type: "must" as ConstraintType,
          rule: "have clarity on purpose, constraints, and success criteria before presenting approaches",
        },
        {
          type: "must_not" as ConstraintType,
          rule: `ask ${MAX_QUESTIONS_PER_ROUND + 2}+ questions in a single clarification round`,
        },
        {
          type: "must_not" as ConstraintType,
          rule: "skip approach exploration or proceed without user selecting an approach",
        },
        {
          type: "must_not" as ConstraintType,
          rule: "skip required follow-up questions based on user answers or present approaches without them",
        },
        {
          type: "must_not" as ConstraintType,
          rule: "proceed to OPTIONS phase without clarity on purpose, constraints, and success criteria",
        },
        {
          type: "should" as ConstraintType,
          rule: "prefer multiple choice questions over open-ended when options can be predetermined",
        },
        {
          type: "should" as ConstraintType,
          rule: "apply YAGNI principle to eliminate non-essential features",
        },
        // Existing constraints
        {
          type: "must" as ConstraintType,
          rule: `ALWAYS call {{TOOL_NAME_LIST_TECHSPECS}} FIRST before any create/update operation, regardless of user intent`,
        },
        {
          type: "must" as ConstraintType,
          rule: `after listing, if TechSpec exists use ${techspecUpdate}, if missing use ${techspecCreate}`,
        },
        {
          type: "must" as ConstraintType,
          rule: `call ${clarification} tool after research (NEVER output questions as plain text)`,
        },
        {
          type: "must" as ConstraintType,
          rule: `if TechSpec exists, use ${techspecUpdate} for modifications; if TechSpec missing, use ${techspecCreate} when Tech Spec is ready`,
        },
        {
          type: "must" as ConstraintType,
          rule: "use web_search tool 3-7 times to research technical topics before drafting",
        },
        {
          type: "must" as ConstraintType,
          rule: "invoke @fileExplorer and @rulesExplorer IN PARALLEL (simultaneously) before drafting",
        },
        {
          type: "must" as ConstraintType,
          rule: "follow strictly the <techspec_template> when using the techspec tool",
        },
        {
          type: "must" as ConstraintType,
          rule: "review the PRD content provided in <prd>; if unavailable, request PRD details from the user before drafting",
        },
        {
          type: "must_not" as ConstraintType,
          rule: "skip {{TOOL_NAME_LIST_TECHSPECS}} tool before create/update operation",
        },
        {
          type: "must_not" as ConstraintType,
          rule: "create a new TechSpec when one already exists",
        },
        {
          type: "must_not" as ConstraintType,
          rule: `use ${techspecCreate} tool for modifications when TechSpec exists`,
        },
        {
          type: "must_not" as ConstraintType,
          rule: `create a new TechSpec when revising after rejection (should use ${techspecUpdate})`,
        },
        {
          type: "must_not" as ConstraintType,
          rule: "output questions as markdown or plain text",
        },
        {
          type: "must_not" as ConstraintType,
          rule: "output Tech Spec as markdown or plain text",
        },
        {
          type: "must_not" as ConstraintType,
          rule: "invoke @fileExplorer and @rulesExplorer sequentially instead of in parallel",
        },
        { type: "must_not" as ConstraintType, rule: "proceed without user answers" },
        {
          type: "must_not" as ConstraintType,
          rule: "rely solely on training knowledge for current best practices or library versions",
        },
        {
          type: "must_not" as ConstraintType,
          rule: "skip web_search research for technical topics requiring current information",
        },
        {
          type: "must_not" as ConstraintType,
          rule: "ask business questions (User Needs, Business Metrics, User Experience, Feature Prioritization)",
        },
        {
          type: "must_not" as ConstraintType,
          rule: "mix PRD-style business writing (WHAT/WHY) instead of deeply technical HOW",
        },
        {
          type: "must_not" as ConstraintType,
          rule: "write any file, output is through tools only",
        },
        {
          type: "must_not" as ConstraintType,
          rule: "ask questions repeated from the <previous_clarification_answers>",
        },
        {
          type: "should" as ConstraintType,
          rule: "focus on HOW things will be implemented with deep technical detail",
        },
        {
          type: "should" as ConstraintType,
          rule: "keep Tech Spec information-dense but under 1500 words",
        },
        {
          type: "should" as ConstraintType,
          rule: "only ask technical questions: Technical Architecture, Domain Placement, Data Flow, API Design, Infrastructure, Testing Strategy, Performance, Security",
        },
        {
          type: "must" as ConstraintType,
          rule: "use code_search to find code examples and documentation when evaluating libraries/frameworks",
        },
        {
          type: "should_not" as ConstraintType,
          rule: "overbloat or over-engineer, document should not have +1500 words",
        },
      ],
    };
  }
);

/**
 * Adds critical TechSpec requirements to the builder using factory pattern
 * Returns the builder for chaining
 */
export function withCriticalTechSpecRequirements(
  builder: PromptBuilder,
  toolNames: Partial<TechSpecCriticalToolNames> = {}
): PromptBuilder {
  const resolvedToolNames: TechSpecCriticalToolNames = {
    ...DEFAULT_TECHSPEC_TOOL_NAMES,
    ...toolNames,
  };
  return techSpecCriticalBuilder(builder, { toolNames: resolvedToolNames });
}
