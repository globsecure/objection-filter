/**
 * TechSpec Clarification Prompt Builder
 * TechSpec-specific clarification logic with technical implementation focus
 */

import { buildClarificationPrompt, type ClarificationPromptConfig } from "../shared/clarification";

/**
 * Build TechSpec clarification prompt
 * TechSpec-specific clarification logic with technical implementation focus
 */
export function buildTechSpecClarificationPrompt(config: ClarificationPromptConfig): string {
  return buildClarificationPrompt(config, {
    title: "Tech Spec (Technical Implementation Focus)",
    focus: "technical",
    restriction:
      "ONLY USE TECHNICAL CATEGORIES: Focus exclusively on HOW (implementation approach, architecture, technical decisions).",
    forbiddenCategories:
      "User Needs, Business Metrics, User Experience, Feature Prioritization - these should have been resolved in PRD and MUST NOT be asked here.",
    categories: [
      "**Technical Architecture**: Domain placement, service boundaries, system design patterns",
      "**Domain Placement**: Where features belong in the codebase, module organization",
      "**Data Flow & Storage**: Data models, storage strategies, data access patterns",
      "**API Design**: Endpoint structure, request/response formats, API contracts",
      "**Infrastructure Dependencies**: Required services, deployment requirements, infrastructure needs",
      "**Testing Strategy**: Coverage objectives, test types, validation approach",
      "**Performance Requirements**: Scalability needs, performance targets, optimization requirements",
      "**Security Implementation**: Authentication, authorization, security patterns",
    ],
    neverAskAbout:
      "User needs, business value, feature priorities, user experience - these are PRD concerns",
  });
}
