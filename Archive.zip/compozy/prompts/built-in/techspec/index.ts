/**
 * TechSpec Built-in Prompts
 * Re-exports all TechSpec-related prompt builders
 */

export * from "./factory";
export * from "./critical";
export * from "./clarification";
