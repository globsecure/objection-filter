# Built-in Prompts

This directory contains centralized, refactored prompts using the `@compozy/prompts` builder API. All prompts are organized by domain and use dependency injection for tool names, schemas, and other configuration to ensure reusability and testability.

## Structure

```
built-in/
├── prd/                 # PRD creation prompts
│   ├── clarification.ts  # PRD clarification prompt builder
│   ├── critical.ts       # PRD critical requirements builder
│   └── factory.ts        # PRD prompt factory
├── techspec/            # TechSpec creation prompts
│   ├── clarification.ts  # TechSpec clarification prompt builder
│   ├── critical.ts       # TechSpec critical requirements builder
│   └── factory.ts        # TechSpec prompt factory
├── tasks/               # Task breakdown prompts
│   ├── critical.ts       # Tasks critical requirements builder
│   └── factory.ts        # Tasks prompt factory
├── task-execution/      # Task execution prompts
│   └── factory.ts        # Task execution prompt factory
├── shared/              # Shared helpers and utilities
│   ├── clarification.ts  # Shared clarification utilities
│   ├── agents.ts         # Subagents helpers
│   ├── constraints.ts   # Constraint helpers
│   └── templates/        # Document templates
│       ├── prd.ts        # PRD template
│       ├── techspec.ts   # TechSpec template
│       └── index.ts      # Template exports
└── index.ts             # Public exports
```

## Design Principles

### 1. Dependency Injection

All prompts accept configuration objects that inject:

- Tool names (e.g., `clarification`, `prd`, `techspec`)
- Schema documentation (generated from Zod schemas)
- Context data (PRD content, TechSpec content, etc.)

This makes prompts:

- **Reusable** across different agent implementations
- **Testable** with mock configurations
- **Maintainable** with centralized logic

### 2. Separation of Concerns

- **Factories** (`factory.ts`): Build complete prompts using the builder API
- **Shared Components** (`shared/`): Reusable prompt sections and templates
- **Templates**: PRD/TechSpec templates live under `shared/templates/`; the Tasks template lives alongside the Tasks prompts at `tasks/template.ts`

### 3. Type Safety

All factories use TypeScript interfaces for configuration:

- `PRDPromptFactoryConfig`
- `TechSpecPromptFactoryConfig`
- `TasksPromptFactoryConfig`
- `PromptBuilderOptions` (for Looper)

## Usage Examples

### PRD Prompt

```typescript
import { buildPRDPrompt } from "@compozy/prompts/built-in";

const config = {
  brainstormConfig: {
    clarificationToolName: "ag-ui_clarification",
    maxQuestionsPerRound: 3,
    approachCount: 3,
    requireTradeoffs: true,
  },
  toolNames: {
    webSearch: "web_search",
  },
  issueId: "00000000-0000-0000-0000-000000000000",
};

const result = buildPRDPrompt(config);
// result.system - system prompt
// result.messages - Messages API structure
// Note: Tool schemas are passed via API (tool API mode enabled), not in prompt text
```

### TechSpec Prompt

```typescript
import { buildTechSpecPrompt } from "@compozy/prompts/built-in";

const config = {
  brainstormConfig: {
    clarificationToolName: "ag-ui_clarification",
    maxQuestionsPerRound: 3,
    approachCount: 3,
    requireTradeoffs: true,
  },
  prdClarifications: "...", // Optional previous clarifications (PRD content is fetched via tools)
  issueId: "00000000-0000-0000-0000-000000000000",
};

const result = buildTechSpecPrompt(config);
// Note: Tool schemas are passed via API (tool API mode enabled), not in prompt text
```

### Tasks Prompt

```typescript
import { buildTasksPrompt } from "@compozy/prompts/built-in";

const config = {}; // No configuration needed - agents fetch PRD and TechSpec via tools

const result = buildTasksPrompt(config);
// Note: Tool schemas are passed via API (tool API mode enabled), not in prompt text
// Note: PRD and TechSpec artifacts are fetched dynamically using list_prds/get_prd and list_techspecs/get_techspec tools
```

### Task Execution Prompt

```typescript
import { buildTaskExecutionPrompt } from "@compozy/prompts/built-in/task-execution/factory";
import { appendRetryContext } from "./retry-helpers";

const config = {
  task: {
    /* ... */
  },
  config: {
    projectRulesPath: ".cursor/rules/",
    testCommand: "make test",
    lintCommand: "make lint",
  },
  issueContext: {
    prdPath: "/path/to/prd.md", // Nullable
    techspecPath: "/path/to/techspec.md", // Nullable
    issueContextPath: "/path/to/issue-context.md", // Nullable
    tasksDirPath: "/path/to/tasks", // Nullable
  },
  // Provide both fields together to include retry context in the user prompt
  retryContext: {
    /* ... */
  }, // Optional
  appendRetryContext, // Required when retryContext is provided
};

const result = buildTaskExecutionPrompt(config);
// result.systemPrompt - system prompt
// result.userPrompt - user prompt
```

## Shared Components

### Critical Requirements (Builder-Integrated)

Builder-integrated helpers for critical requirements sections:

- `withCriticalPRDRequirements(builder, toolNames)` - PRD-specific critical requirements (in `prd/critical.ts`)
- `withCriticalTechSpecRequirements(builder, toolNames)` - TechSpec-specific critical requirements (in `techspec/critical.ts`)
- `withCriticalTasksRequirements(builder, toolNames)` - Tasks-specific critical requirements (in `tasks/critical.ts`)

These helpers add constraints and critical sections to the builder, returning the builder for chaining.

**Example:**

```typescript
let builder = createPromptBuilder();
builder = withCriticalPRDRequirements(builder, {
  clarification: "ag-ui_clarification",
  prd: "ag-ui_prd",
});
```

### Constraint Helpers (Builder-Integrated)

Builder-integrated helpers for adding constraint sets:

- `withResearchConstraints(builder, minSearches, maxSearches)` - Research constraints (in `shared/constraints.ts`)
- `withExplorationConstraints(builder, parallel)` - Exploration constraints (in `shared/constraints.ts`)
- `withToolUsageConstraints(builder, toolName, action)` - Tool usage constraints (in `shared/constraints.ts`)

**Example:**

```typescript
let builder = createPromptBuilder();
builder = withResearchConstraints(builder, 3, 7);
builder = withExplorationConstraints(builder, true);
```

### Tool Documentation

Tool documentation is handled directly in factory files using utilities from `src/sections/tools.ts`:

- `buildToolDocumentationContent()` - Builds tool documentation content strings
- `withToolDocumentationWithSchema()` - Adds tool documentation to builders

These utilities are used internally by the factory functions and are not exported as separate helpers.

### Agents Helpers (Builder-Integrated)

Builder-integrated helpers for subagents:

- `withSubagentsSection(builder)` - Adds @fileExplorer and @rulesExplorer subagents (in `shared/agents.ts`)

**Example:**

```typescript
let builder = createPromptBuilder();
builder = withSubagentsSection(builder);
```

### Clarification Prompts

Builders for clarification question prompts:

- `buildPRDClarificationPrompt(config)` - PRD-specific clarification prompt (in `prd/clarification.ts`)
- `buildTechSpecClarificationPrompt(config)` - TechSpec-specific clarification prompt (in `techspec/clarification.ts`)
- `buildClarificationPrompt(baseConfig, variantConfig)` - Generic clarification prompt builder (in `shared/clarification.ts`)
- `ClarificationPromptConfig` - Configuration interface for clarification prompts (in `shared/clarification.ts`)

### Templates

Document structure templates:

- `PRD_TEMPLATE`
- `TECHSPEC_TEMPLATE`

## Builder-Integrated Pattern

All helpers follow a consistent pattern:

1. Accept a `PromptBuilder` instance as the first parameter
2. Return the builder for method chaining
3. Can be composed together

**Example of chaining multiple helpers:**

```typescript
let builder = createPromptBuilder().withIdentity("You are a PRD specialist");

builder = withCriticalPRDRequirements(builder, {
  clarification: "ag-ui_clarification",
  prd: "ag-ui_prd",
});

builder = withResearchConstraints(builder, 3, 7);
builder = withSubagentsSection(builder);

const result = builder.buildMessages();
```

## Organization Principles

The `built-in` directory is organized by **resource/type** rather than by package:

- **`prd/`**: PRD creation prompts
- **`techspec/`**: TechSpec creation prompts
- **`tasks/`**: Task breakdown prompts
- **`task-execution/`**: Task execution prompts
- **`shared/`**: Shared helpers and utilities used across prompts

This organization makes it easier to find prompts by what they do, not where they came from.

## Migration Notes

These prompts were migrated from:

- `packages/agents/src/ag-ui/prompts/factories/` → `built-in/prd/`, `built-in/techspec/`, `built-in/tasks/`
- `packages/looper/src/core/prompt-builder.ts` → `built-in/task-execution/`

The original files still exist and can be updated to use these centralized factories. The built-in prompts are designed to be:

- **Drop-in replacements** with proper configuration
- **More maintainable** with shared components
- **More testable** with dependency injection

## Testing

The built-in prompts include comprehensive tests:

- **Helper Tests** (`built-in/__tests__/helpers.test.ts`): Tests for all builder-integrated helpers
- **Integration Tests** (`built-in/__tests__/integration.test.ts`): Tests for complete prompt factories

Run tests with:

```bash
pnpm test --project packages/prompts
```

## Future Work

- [ ] Migrate existing prompt files to use built-in factories
- [ ] Add snapshot tests for prompt output comparison
- [ ] Create adapter functions for backward compatibility
- [ ] Add validation for configuration objects
