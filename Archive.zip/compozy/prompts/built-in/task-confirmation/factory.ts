import { z } from "zod";
import { invariant } from "es-toolkit/util";
import { ARTIFACT_LIST_TOOL_NAME } from "@compozy/types";
import { createPromptBuilder } from "../../src/builder";
import type { PromptComponents } from "../task-execution/factory";
import {
  buildConfirmationChecksSection,
  formatExecutionSnapshot,
  formatIssueContext,
} from "./helpers";
import type { ConfirmationInput } from "./types";

/**
 * Zod schema for the confirmation output.
 * Used both for prompt generation (converted to JSON Schema) and response validation.
 */
export const confirmationOutputSchema = z.object({
  type: z.literal("task-confirmation-output"),
  response: z.object({
    status: z.enum(["pass", "fail"]).describe("Whether the confirmation passes or fails"),
    reasons: z.array(z.string()).describe("Short reasons for the verdict"),
    limitError: z.boolean().describe("True if provider subscription/plan limit was hit"),
    definitionMismatch: z.boolean().describe("Always false for this version"),
    errorDetected: z.boolean().describe("Always false for this version"),
    actionItems: z.array(z.string()).describe("Specific next steps if limitError is true"),
  }),
});

export type ConfirmationOutput = z.infer<typeof confirmationOutputSchema>;

function buildConfirmationSystemPrompt(input: ConfirmationInput): string {
  const builder = createPromptBuilder();

  // Task and Issue ID XML tags for reuse across prompt
  builder.withXmlTag("task_id", input.taskDefinition.id);
  builder.withXmlTag("issue_id", input.taskDefinition.issueId);
  builder.withXmlTag("task_title", input.taskDefinition.title);
  builder.withXmlTag("task_complexity", input.taskDefinition.complexity);

  builder
    .withIdentity("You are the confirmation pass validator for Looper task executions.")
    .withCapabilities([
      "Detect provider subscription/plan limit exhaustion in the primary execution",
    ])
    .withConstraint(
      "must",
      "Return only the structured verdict defined in the Output Schema section"
    )
    .withConstraint("must_not", "Add commentary outside the structured verdict");

  builder.withSection("Confirmation Checks", buildConfirmationChecksSection(), "critical");
  builder.withOutput("JSON", confirmationOutputSchema);

  return builder.buildSystemPrompt();
}

function buildConfirmationUserPrompt(input: ConfirmationInput): string {
  const { taskDefinition, issueContext, snapshot } = input;

  invariant(
    taskDefinition.filePath,
    "Task definition filePath is required for artifact-based confirmation"
  );

  return `# Task Definition
Title: <task_title>
Complexity: <task_complexity>
Issue ID: <issue_id>

## Task Specification Reference
File path: ${taskDefinition.filePath}
Use ${ARTIFACT_LIST_TOOL_NAME} to read acceptance criteria and task details from the task artifact.

## Issue Context
${formatIssueContext(issueContext)}

## Primary Execution Snapshot
${formatExecutionSnapshot(snapshot)}

Provide the confirmation verdict using ONLY the schema above.`;
}

export function buildConfirmationPrompt(input: ConfirmationInput): PromptComponents {
  const systemPrompt = buildConfirmationSystemPrompt(input);
  const userPrompt = buildConfirmationUserPrompt(input);

  return { systemPrompt, userPrompt };
}
