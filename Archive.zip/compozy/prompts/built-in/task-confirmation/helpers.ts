import { ARTIFACT_LIST_TOOL_NAME } from "@compozy/types";
import { trim } from "es-toolkit/string";
import type { IssueContext } from "../task-execution/factory";
import type {
  ConfirmationVerdict,
  ExecutionArtifacts,
  ExecutionSnapshot,
  SnapshotMessage,
} from "./types";

function toBulletList(values?: string[], emptyLabel = "None provided"): string {
  if (!values || values.length === 0) {
    return `- ${emptyLabel}`;
  }

  const trimmedValues = values.map(value => trim(value)).filter(value => value.length > 0);

  if (trimmedValues.length === 0) {
    return `- ${emptyLabel}`;
  }

  return trimmedValues.map(value => `- ${value}`).join("\n");
}

export function formatMessages(messages?: SnapshotMessage[]): string {
  if (!messages || messages.length === 0) {
    return "- No message history provided.";
  }

  return messages
    .slice(-10)
    .map(
      (message, index) => `- ${index + 1}. ${message.role || "unknown"}: ${trim(message.content)}`
    )
    .join("\n");
}

export function formatArtifacts(artifacts?: ExecutionArtifacts): string {
  if (!artifacts) {
    return "- No artifact metadata provided.";
  }

  const parts: string[] = [];

  if (artifacts.testsStatus) {
    parts.push(`- Tests: ${artifacts.testsStatus}`);
  }
  if (artifacts.lintStatus) {
    parts.push(`- Lint: ${artifacts.lintStatus}`);
  }
  if (artifacts.testsRan && artifacts.testsRan.length > 0) {
    parts.push(`- Test commands: ${artifacts.testsRan.join(", ")}`);
  }
  if (artifacts.changedFiles && artifacts.changedFiles.length > 0) {
    parts.push(
      `- Changed files (${artifacts.changedFiles.length}): ${artifacts.changedFiles.join(", ")}`
    );
  }
  if (artifacts.filesTouched && artifacts.filesTouched.length > 0) {
    parts.push(
      `- Files touched (${artifacts.filesTouched.length}): ${artifacts.filesTouched.join(", ")}`
    );
  }
  if (artifacts.diffSummary) {
    parts.push(`- Diff summary: ${artifacts.diffSummary}`);
  }

  return parts.length > 0 ? parts.join("\n") : "- No artifact metadata provided.";
}

export function buildConfirmationChecksSection(): string {
  return `Analyze ONLY the last messages of the primary execution to determine whether the run was blocked by a provider subscription/plan/usage limit.\n\nYou must:\n- Look at the "Last 10 messages" and infer intent, not exact wording.\n- Mark a limit error ONLY when the messages indicate the provider stopped because the user hit a paid-plan or usage cap (e.g., plan limit exceeded, subscription usage limit reached, max plan quota, upgrade required, tool/step limit due to plan, etc.).\n- Ignore all other failures, transient test failures, non‑zero exit codes, TODOs, or missing artifacts for this version.\n\nIf there is no clear subscription/plan limit exhaustion, treat the confirmation as passing.`;
}

export function formatConfirmationVerdict(verdict: ConfirmationVerdict): string {
  const reasons = toBulletList(verdict.reasons, "No reasons provided");
  const actionItems = toBulletList(verdict.actionItems, "No action items provided");

  return `Status: ${verdict.status}
Limit error: ${verdict.limitError}
Definition mismatch: ${verdict.definitionMismatch}
Error detected: ${verdict.errorDetected}
Reasons:
${reasons}
Action items:
${actionItems}`;
}

export function formatIssueContext(issueContext?: IssueContext): string {
  if (!issueContext) {
    return "(no additional issue context provided)";
  }

  const parts: string[] = [];

  if (issueContext.prdPath && trim(issueContext.prdPath)) {
    parts.push(
      `### PRD Reference\nFile path: ${issueContext.prdPath}\nUse ${ARTIFACT_LIST_TOOL_NAME} to read relevant sections.`
    );
  }

  if (issueContext.techspecPath && trim(issueContext.techspecPath)) {
    parts.push(
      `### Technical Specification Reference\nFile path: ${issueContext.techspecPath}\nUse ${ARTIFACT_LIST_TOOL_NAME} to read relevant sections.`
    );
  }

  if (issueContext.issueContextPath && trim(issueContext.issueContextPath)) {
    parts.push(
      `### Issue Context Reference\nFile path: ${issueContext.issueContextPath}\nUse ${ARTIFACT_LIST_TOOL_NAME} to read relevant sections.`
    );
  }

  if (issueContext.tasksDirPath && trim(issueContext.tasksDirPath)) {
    parts.push(
      `### Tasks Directory\nPath: ${issueContext.tasksDirPath}\nUse ${ARTIFACT_LIST_TOOL_NAME} to locate task artifacts when needed.`
    );
  }

  return parts.length > 0 ? parts.join("\n\n") : "(no additional issue context provided)";
}

export function formatExecutionSnapshot(snapshot: ExecutionSnapshot): string {
  const artifactsBlock = formatArtifacts(snapshot.artifacts);
  const messagesBlock = formatMessages(snapshot.lastMessages);

  return `Summary:
${snapshot.summary || "(no summary provided)"}

Exit code: ${snapshot.exitCode}
Artifacts:
${artifactsBlock}

Last 10 messages:
${messagesBlock}`;
}
