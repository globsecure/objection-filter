import type { IssueContext } from "../task-execution/factory";

/**
 * Minimal BackendTask shape for prompt construction.
 * Kept in sync with looper's BackendTask but duplicated here to avoid runtime coupling.
 */
export interface BackendTask {
  readonly id: string;
  readonly issueId: string;
  readonly title: string;
  readonly filePath: string;
  readonly content: string;
  readonly complexity: "low" | "medium" | "high" | "critical";
}

/**
 * Canonical role variants used by both prompt-side and looper-side snapshots.
 * Additional roles remain allowed while keeping primary literals visible in tooling.
 */
export type SnapshotRole = "user" | "assistant" | "system" | (string & {});

/**
 * Chat message snapshot used in prompts (last N messages of primary execution).
 * This file acts as the single source of truth; looper core reuses these types
 * to avoid drift between prompt rendering and backend verdict parsing.
 */
export interface SnapshotMessage {
  readonly role: SnapshotRole;
  readonly content: string;
}

/**
 * Execution artifact metadata captured after the first pass.
 */
export interface ExecutionArtifacts {
  readonly testsStatus?: string;
  readonly lintStatus?: string;
  readonly changedFiles?: string[];
  readonly filesTouched?: string[];
  readonly testsRan?: string[];
  readonly diffSummary?: string;
}

/**
 * Snapshot collected from the primary execution pass.
 */
export interface ExecutionSnapshot {
  readonly summary: string;
  readonly exitCode: number;
  readonly lastMessages: SnapshotMessage[];
  readonly artifacts?: ExecutionArtifacts;
}

export interface ConfirmationVerdict {
  readonly status: "pass" | "fail";
  readonly reasons: string[];
  readonly limitError: boolean;
  readonly definitionMismatch: boolean;
  readonly errorDetected: boolean;
  readonly actionItems: string[];
}

export interface ConfirmationInput {
  readonly taskDefinition: BackendTask;
  readonly issueContext?: IssueContext;
  readonly snapshot: ExecutionSnapshot;
}
