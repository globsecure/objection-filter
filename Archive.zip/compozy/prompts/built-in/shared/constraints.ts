/**
 * Constraint builders - Helper functions for adding constraint sets programmatically
 * Built-in specific constraint helpers
 */

import type { PromptBuilder } from "../../src/builder";

export type ResearchToolNames = {
  webSearch?: string;
  codeSearch?: string;
};

export type ExplorerToolNames = {
  fileExplorer?: string;
  rulesExplorer?: string;
};

export const DEFAULT_TOOL_NAMES = {
  webSearch: "web_search",
  codeSearch: "code_search",
  fileExplorer: "@fileExplorer",
  rulesExplorer: "@rulesExplorer",
} as const;

/**
 * Adds tool usage constraints to the builder
 * Returns the builder for chaining
 */
export function withToolUsageConstraints(
  builder: PromptBuilder,
  toolName: string,
  action: string
): PromptBuilder {
  return builder
    .withConstraint("must", `call ${toolName} tool ${action}`)
    .withConstraint("must_not", `output ${action} as text`);
}

/**
 * Adds research constraints to the builder
 * Returns the builder for chaining
 */
export function withResearchConstraints(
  builder: PromptBuilder,
  minSearches: number,
  maxSearches: number,
  toolNames: ResearchToolNames = {}
): PromptBuilder {
  const webSearchTool = toolNames.webSearch ?? DEFAULT_TOOL_NAMES.webSearch;
  const hasCodeSearchTool = "codeSearch" in toolNames;
  const codeSearchTool = toolNames.codeSearch ?? DEFAULT_TOOL_NAMES.codeSearch;

  let builderWithConstraints = builder
    .withConstraint(
      "must",
      `use ${webSearchTool} tool ${minSearches}-${maxSearches} times to research relevant topics before drafting`
    )
    .withConstraint("must_not", "rely solely on training knowledge for current information")
    .withConstraint(
      "must_not",
      `skip ${webSearchTool} research for topics requiring current information`
    )
    .withConstraint("should", "extract key findings from 3-5 most authoritative sources")
    .withConstraint(
      "should",
      "incorporate research findings into decisions, citing authoritative sources when relevant"
    );

  // Add code search constraint if codeSearch tool is provided (for techspec)
  if (hasCodeSearchTool && codeSearchTool && codeSearchTool !== webSearchTool) {
    builderWithConstraints = builderWithConstraints.withConstraint(
      "must",
      `use ${codeSearchTool} to find code examples and documentation when evaluating libraries/frameworks`
    );
  }

  return builderWithConstraints;
}

/**
 * Adds exploration constraints to the builder
 * Returns the builder for chaining
 */
export function withExplorationConstraints(
  builder: PromptBuilder,
  parallel: boolean,
  tools: ExplorerToolNames = {}
): PromptBuilder {
  const fileExplorerTool = tools.fileExplorer ?? DEFAULT_TOOL_NAMES.fileExplorer;
  const rulesExplorerTool = tools.rulesExplorer ?? DEFAULT_TOOL_NAMES.rulesExplorer;

  if (parallel) {
    return builder
      .withConstraint(
        "must",
        `invoke ${fileExplorerTool} and ${rulesExplorerTool} IN PARALLEL (simultaneously) before drafting`
      )
      .withConstraint(
        "must_not",
        `invoke ${fileExplorerTool} and ${rulesExplorerTool} sequentially instead of in parallel`
      );
  }
  return builder.withConstraint(
    "should",
    `use ${fileExplorerTool} or ${rulesExplorerTool} if needed to understand specific codebase patterns`
  );
}
