/**
 * Agent builders - Builder-integrated helpers for adding agents
 */

import { createPromptBuilder, type PromptBuilder } from "../../src/builder";
import { defaultAgentDefinitions } from "../subagents";

/**
 * Subagent usage guidelines content
 */
const SUBAGENTS_USAGE_GUIDELINES = `**When to use subagents**:
- **Before drafting**: Always explore with both subagents IN PARALLEL (simultaneously) to understand existing codebase patterns and compliance requirements
- **CRITICAL**: Invoke @fileExplorer and @rulesExplorer together in the same message/turn—never invoke them sequentially
- **During exploration phase**: Use both subagents in parallel—@fileExplorer finds relevant implementation files while @rulesExplorer identifies compliance requirements simultaneously
- **For specific questions**: Invoke subagents in parallel with specific queries about domains, technologies, or patterns you need to understand
- **Efficiency**: Parallel execution reduces total exploration time and allows you to synthesize findings from both sources together

**PRD Creation Specific**:
- **CRITICAL**: For PRD creation, invoke Explorer tool AND @businessAnalyst subagent IN PARALLEL (simultaneously)
- **Explorer tool**: Gathers product context from codebase
- **@businessAnalyst**: Uses web_search tool 3-7 times to research market trends, competitive landscape, and industry benchmarks, then returns synthesized findings
- **Delegation**: @businessAnalyst handles ALL web_search research—main agent should NOT use web_search directly
- **Synthesis**: After parallel exploration, combine findings from Explorer tool and @businessAnalyst subagent before proceeding`;

/**
 * Adds @fileExplorer and @rulesExplorer subagents to the builder
 * Returns the builder for chaining
 */
export function withSubagentsSection(builder: PromptBuilder): PromptBuilder {
  return builder
    .withAgents(defaultAgentDefinitions)
    .withSection("Subagent Usage Guidelines", SUBAGENTS_USAGE_GUIDELINES, "high");
}

/**
 * Builds just the subagents section content (agents + usage guidelines)
 * Returns formatted markdown string suitable for appending to system prompts
 */
export function buildSubagentsSectionContent(): string {
  return withSubagentsSection(createPromptBuilder()).buildSystemPrompt();
}
