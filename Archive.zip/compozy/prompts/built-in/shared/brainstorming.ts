/**
 * Brainstorming Module
 * Core infrastructure for iterative, phase-based brainstorming workflow
 *
 * Replaces one-shot clarification with multi-round, conversational exploration:
 * - Sequential questioning (1-3 per round, not 5-7 at once)
 * - Approach exploration with trade-offs
 * - YAGNI principles throughout
 */

import { clamp } from "es-toolkit/math";
import { invariant } from "es-toolkit/util";
import type { PromptBuilder } from "../../src/builder";

/**
 * Brainstorm phase definition
 */
export interface BrainstormPhase {
  name: "discovery" | "understanding" | "options" | "refinement" | "creation";
  description: string;
  gateRequirement: string;
}

/**
 * Configuration for brainstorming workflow
 */
export interface BrainstormConfig {
  /** Maximum questions per clarification round (default: 3) */
  maxQuestionsPerRound: number;
  /**
   * Number of approaches to present (default: 3).
   * Prompt text presents a human-friendly range: (N-1)-N (e.g., 2-3 when N=3).
   */
  approachCount: number;
  /** Word limit for validation sections (default: 300) */
  sectionWordLimit: number;
  /** Require trade-offs for each approach (default: true) */
  requireTradeoffs: boolean;
}

/**
 * Prompt-factory configuration for brainstorming-related settings and tool names.
 * This keeps prompt factories cohesive while letting runtime inject placeholder values when needed.
 */
export type BrainstormPromptConfig = Partial<BrainstormConfig> & {
  clarificationToolName: string;
  approachToolName?: string;
};

/**
 * Default section word limit for validation sections
 */
export const DEFAULT_SECTION_WORD_LIMIT = 300;

/**
 * Default brainstorming configuration
 */
export const DEFAULT_BRAINSTORM_CONFIG: BrainstormConfig = {
  maxQuestionsPerRound: 3,
  approachCount: 3,
  sectionWordLimit: DEFAULT_SECTION_WORD_LIMIT,
  requireTradeoffs: true,
};

/**
 * Default brainstorming phases
 */
export const BRAINSTORM_PHASES: BrainstormPhase[] = [
  {
    name: "discovery",
    description: "Explore codebase and gather context via parallel exploration and research",
    gateRequirement: "Explorer and research subagents must complete before proceeding",
  },
  {
    name: "understanding",
    description:
      "Sequential questions to understand user intent. Focus on: purpose, constraints, success criteria. Ask follow-up questions based on answers. Continue until you can confidently explain what you're building and why.",
    gateRequirement:
      "Must have clarity on: purpose (what and why), constraints (limitations and requirements), success criteria (how we measure success). Must have asked follow-up questions based on user answers. Cannot proceed to OPTIONS phase until understanding is complete.",
  },
  {
    name: "options",
    description: "Present 2-3 approaches with trade-offs, get user selection",
    gateRequirement: "User must select or confirm an approach before proceeding",
  },
  {
    name: "refinement",
    description: "Deeper questions based on chosen approach (1-3 per round)",
    gateRequirement: "Implementation details must be clear before proceeding",
  },
  {
    name: "creation",
    description: "Create final artifact via tool after refinement complete",
    gateRequirement: "All previous phases must be complete",
  },
];

/**
 * Generates the phase-based workflow description for use in critical requirements
 * This ensures consistency between brainstorming.ts and critical.ts files
 */
export function generatePhaseWorkflowDescription(
  focusType: "business" | "technical",
  customDiscovery?: string
): string {
  const discoveryPhase = BRAINSTORM_PHASES.find(p => p.name === "discovery");
  invariant(discoveryPhase, "Discovery phase must exist in BRAINSTORM_PHASES");
  const discoveryDesc = customDiscovery ?? discoveryPhase.description;

  const approachLabel = focusType === "business" ? "product" : "architectural";

  return `**PHASE-BASED BRAINSTORMING WORKFLOW**: You MUST follow these phases in order:
   1. DISCOVERY - ${discoveryDesc}
   2. UNDERSTANDING - Ask 1-3 ${focusType === "business" ? "" : "technical "}questions per round, wait for answers, ask follow-ups. Focus on: purpose, constraints, success criteria. Continue until you can confidently explain what you're building and why.
   3. OPTIONS - Present 2-3 ${approachLabel} approaches with trade-offs, get user selection
   4. REFINEMENT - Deeper ${focusType === "business" ? "" : "technical "}questions based on chosen approach (1-3 per round)
   5. CREATION - Call ${focusType === "business" ? "PRD" : "TechSpec"} tool after refinement complete`;
}

/**
 * Approach exploration configuration
 */
export interface ApproachExplorationConfig {
  /** Focus type: business for PRD, technical for TechSpec */
  focusType: "business" | "technical";
  /** Full tool name for approaches tool (injects {{TOOL_NAME_APPROACHES}} when provided) */
  approachToolName?: string;
  /** Number of approaches to present (default: 3, range: 2-5) */
  approachCount?: number;
  /** Require trade-offs for each approach (default: true) */
  requireTradeoffs?: boolean;
}

/**
 * Clamps a value to min/max bounds with sensible defaults
 */
function clampConfigValue(value: number, min: number, max: number, defaultValue: number): number {
  if (typeof value !== "number" || Number.isNaN(value)) return defaultValue;
  return clamp(value, min, max);
}

/**
 * Normalizes brainstorm config with bounds checking
 */
export function normalizeConfig(config: Partial<BrainstormConfig> = {}): BrainstormConfig {
  return {
    maxQuestionsPerRound: clampConfigValue(
      config.maxQuestionsPerRound ?? DEFAULT_BRAINSTORM_CONFIG.maxQuestionsPerRound,
      1,
      10,
      DEFAULT_BRAINSTORM_CONFIG.maxQuestionsPerRound
    ),
    approachCount: clampConfigValue(
      config.approachCount ?? DEFAULT_BRAINSTORM_CONFIG.approachCount,
      2,
      5,
      DEFAULT_BRAINSTORM_CONFIG.approachCount
    ),
    sectionWordLimit: clampConfigValue(
      config.sectionWordLimit ?? DEFAULT_BRAINSTORM_CONFIG.sectionWordLimit,
      100,
      500,
      DEFAULT_BRAINSTORM_CONFIG.sectionWordLimit
    ),
    requireTradeoffs: config.requireTradeoffs ?? DEFAULT_BRAINSTORM_CONFIG.requireTradeoffs,
  };
}

/**
 * Adds brainstorming phase workflow to the builder
 * Returns the builder for chaining
 */
export function withBrainstormingPhases(builder: PromptBuilder): PromptBuilder {
  const phaseList = BRAINSTORM_PHASES.map(
    (p, i) => `${i + 1}. **${p.name.toUpperCase()}**: ${p.description}`
  ).join("\n");

  const phaseGates = BRAINSTORM_PHASES.map(
    p => `- **${p.name.toUpperCase()}**: ${p.gateRequirement}`
  ).join("\n");

  return builder.withSection(
    "Brainstorming Workflow Phases",
    `**MANDATORY PHASE-BASED WORKFLOW**

You MUST follow these phases in order. Each phase has a gate requirement that must be met before proceeding.

${phaseList}

**PHASE GATES (DO NOT SKIP)**:
${phaseGates}

**CRITICAL RULES**:
- You CANNOT proceed to the next phase until the current phase's gate requirement is satisfied
- Multiple rounds of questions are EXPECTED and ENCOURAGED in understanding and refinement phases
- There is NO limit on the number of rounds - iterate until you are truly confident
- Violating phase order or skipping gates results in task rejection

**CONVERSATIONAL APPROACH**:
- Frame interactions as collaborative exploration, not interrogation
- Use language like "I'm curious about..." and "Let me understand..."
- Ask follow-up questions based on previous answers
- Present options conversationally, not as formal lists`,
    "critical"
  );
}

/**
 * Adds sequential questioning protocol to the builder
 * Returns the builder for chaining
 */
export function withSequentialQuestioningProtocol(
  builder: PromptBuilder,
  config: BrainstormConfig = DEFAULT_BRAINSTORM_CONFIG
): PromptBuilder {
  const normalizedConfig = normalizeConfig(config);
  const maxQ = normalizedConfig.maxQuestionsPerRound;

  return builder.withSection(
    "Sequential Questioning Protocol",
    `**CRITICAL QUESTIONING RULES**

1. **MAXIMUM ${maxQ} QUESTIONS PER ROUND**
   - NEVER ask ${maxQ + 2}+ questions at once
   - This is the single most important rule for brainstorming quality

2. **MULTIPLE ROUNDS EXPECTED**
   - Ask 1-${maxQ} questions, wait for answers
   - Use answers to inform your next questions
   - **YOU MUST ask follow-up questions based on user answers before proceeding**
   - One round of questions is rarely sufficient - continue until you can confidently explain purpose, constraints, and success criteria
   - Ask follow-up questions that go deeper
   - Continue until you have true clarity

3. **PREFER MULTIPLE CHOICE**
   - When possible, provide 2-4 options for user to choose from
   - Include "Other" option with allowOther: true
   - Only use open-ended when choices cannot be predetermined

4. **ONE TOPIC PER QUESTION**
   - Don't combine multiple concerns into one question
   - Break complex topics into separate focused questions

5. **WAIT FOR ANSWERS**
   - DO NOT proceed without user response
   - DO NOT assume answers or make defaults

6. **USE PREVIOUS ANSWERS**
   - Reference what user said in previous rounds
   - Build on their responses to go deeper
   - Acknowledge their input before asking more

**ANTI-PATTERNS (FORBIDDEN)**:
- Asking ${maxQ + 2}+ questions at once → FAILED
- Skipping to artifact creation after first round → FAILED
- Not asking follow-up questions based on answers → FAILED
- Presenting approaches after only initial questions without follow-ups → FAILED
- Proceeding to OPTIONS phase without asking follow-up questions → FAILED
- Using open-ended when multiple choice would work → FAILED
- Combining multiple topics in one question → FAILED
- Ignoring previous answers when forming new questions → FAILED`,
    "high"
  );
}

/**
 * Adds approach exploration section to the builder
 * Returns the builder for chaining
 */
export function withApproachExplorationSection(
  builder: PromptBuilder,
  config: ApproachExplorationConfig
): PromptBuilder {
  if (config.approachToolName) {
    builder.withPlaceholder("{{TOOL_NAME_APPROACHES}}", config.approachToolName);
  }

  const focusLabel =
    config.focusType === "business" ? "product/business" : "technical/architectural";

  // Use configured approachCount, defaulting to 3 if not provided
  const approachCount = config.approachCount ?? DEFAULT_BRAINSTORM_CONFIG.approachCount;
  // Clamp to valid range (2-5)
  const clampedCount = clamp(approachCount, 2, 5);
  const approachRange = clampedCount === 2 ? "2" : `${clampedCount - 1}-${clampedCount}`;
  const requireTradeoffs = config.requireTradeoffs ?? true;

  const tradeoffSection = requireTradeoffs
    ? `
**TRADE-OFFS REQUIRED**: For EACH approach, you MUST provide:
- 2-3 specific pros (advantages of this approach)
- 2-3 specific cons (disadvantages/risks)
- "Best for" scenario (when to choose this approach)`
    : "";

  return builder.withSection(
    "Approach Exploration Protocol",
    `**MANDATORY**: Before finalizing any design, you MUST call the \`{{TOOL_NAME_APPROACHES}}\` tool to present ${approachRange} distinct ${focusLabel} approaches.

<critical>
**TOOL USAGE REQUIRED**: You MUST use the \`{{TOOL_NAME_APPROACHES}}\` tool to present approaches - DO NOT output approaches as markdown or plain text.
This is the ONLY way to present approaches for user selection. After calling this tool, STOP and wait for user's selection.
</critical>

**FOR EACH APPROACH IN THE TOOL, PROVIDE**:

1. **name**: Short, descriptive name
2. **description**: 2-3 sentences explaining the ${focusLabel} approach
3. **pros**: What makes this approach good (2-3 points as array)
4. **cons**: What are the downsides/risks (2-3 points as array)
5. **bestFor**: When to choose this approach
6. **isRecommended**: Set to true for your recommended approach
${tradeoffSection}

**RECOMMENDATION REQUIRED**:
- Mark your recommended approach with isRecommended: true
- Set recommendationReason in the tool call explaining WHY you recommend it
- Be prepared to change if user prefers another approach

**WAIT FOR USER SELECTION**:
- DO NOT proceed until user confirms approach via the tool response
- If user suggests modifications, incorporate them
- If user picks non-recommended approach, acknowledge and proceed with their choice
- If user is unsure, help them decide with clarifying questions

**CRITICAL**: Skipping approach exploration or proceeding without user selection results in task rejection.`,
    "high"
  );
}

/**
 * Adds incremental validation section to the builder
 * Returns the builder for chaining
 */
export function withIncrementalValidationSection(
  builder: PromptBuilder,
  focusType: "business" | "technical",
  wordLimit: number = 300
): PromptBuilder {
  const sections =
    focusType === "business"
      ? `*Typical PRD Sections to Validate*:
1. Problem Statement & User Impact
2. Core Features (MVP scope only)
3. Success Metrics & Measurement
4. Constraints & Non-Goals
5. User Experience Overview`
      : `*Typical TechSpec Sections to Validate*:
1. Architecture Overview & Domain Placement
2. Data Model & Storage
3. API Design & Contracts
4. Security & Error Handling
5. Testing & Rollout Strategy`;

  return builder.withSection(
    "Incremental Validation Protocol",
    `**MANDATORY**: Present design in digestible sections, validating each before proceeding.

**SECTION RULES**:
1. **Word Limit**: ${wordLimit} words maximum per section
2. **Validation Prompt**: End each section with "Does this look right so far?" or similar
3. **Wait for Confirmation**: DO NOT proceed without user confirmation
4. **Revise if Needed**: If user says no or gives feedback, revise and re-validate

**VALIDATION FLOW**:
1. Present Section 1 (max ${wordLimit} words)
2. Ask: "Does this look right so far?"
3. Wait for user response
4. If "yes", "looks good", "correct", etc.: proceed to Section 2
5. If "no" or feedback given: revise Section 1, then re-validate
6. Repeat until all sections validated
7. ONLY THEN proceed to artifact creation

${sections}

**CONVERSATIONAL VALIDATION**:
- Don't just dump sections, explain your reasoning
- "Based on what you've told me, here's what I'm thinking for [section]..."
- Invite discussion: "Does this capture what you had in mind?"
- Be open to significant changes: "I can adjust this approach if..."

**CRITICAL**: Proceeding to artifact creation without incremental validation results in task rejection.`,
    "high"
  );
}

/**
 * Adds understanding focus areas section to the builder
 * Returns the builder for chaining
 */
export function withUnderstandingFocusAreas(builder: PromptBuilder): PromptBuilder {
  return builder.withSection(
    "Understanding Focus Areas",
    `**MANDATORY**: When asking questions to understand the idea, focus on these three areas:

1. **Purpose**: What are we building and why? What problem does it solve? What value does it provide?

2. **Constraints**: What are the limitations, requirements, and boundaries? What can't we do? What must we do?

3. **Success Criteria**: How do we measure success? What outcomes matter? What does "done" look like?

**CRITICAL**: You cannot proceed to the OPTIONS phase until you have clarity on all three areas. Continue asking follow-up questions until you can confidently explain purpose, constraints, and success criteria.`,
    "high"
  );
}

/**
 * Adds YAGNI principles section to the builder
 * Returns the builder for chaining
 */
export function withYAGNIPrinciples(builder: PromptBuilder): PromptBuilder {
  return builder.withSection(
    "YAGNI Principles",
    `**You Aren't Gonna Need It (YAGNI)**

Apply ruthless simplification throughout the brainstorming process:

**DURING UNDERSTANDING PHASE**:
- Challenge every stated requirement: "Is this essential for MVP?"
- Identify what can be deferred to future iterations
- Push back gently on "nice to have" features
- Ask: "What's the simplest thing that could possibly work?"

**DURING OPTIONS PHASE**:
- Prefer simpler approaches over complex ones
- Each approach should solve the core problem, not edge cases
- Complexity must be justified with clear value
- Default to the minimal viable solution

**RED FLAGS TO CHALLENGE**:
- "We might need..."
- "In case users want..."
- "For future extensibility..."
- "To be comprehensive..."
- Features covering edge cases before core cases work
- "While we're at it, we could also..."

**MANTRA**: Build the smallest thing that could possibly work, validate it, then iterate.

**YOUR ROLE**: Be a collaborative but skeptical partner. Help the user focus on what truly matters by gently questioning complexity and scope creep.`,
    "medium"
  );
}

/**
 * Composes all brainstorming sections into a single section builder
 * This is a convenience function for adding all brainstorming sections at once
 */
export function withBrainstormingSections(
  builder: PromptBuilder,
  focusType: "business" | "technical",
  config: BrainstormConfig & { approachToolName?: string } = DEFAULT_BRAINSTORM_CONFIG
): PromptBuilder {
  const normalizedConfig = normalizeConfig(config);
  let result = builder;

  result = withBrainstormingPhases(result);
  result = withUnderstandingFocusAreas(result);
  result = withSequentialQuestioningProtocol(result, normalizedConfig);
  result = withApproachExplorationSection(result, {
    focusType,
    ...(config.approachToolName !== undefined && { approachToolName: config.approachToolName }),
    approachCount: normalizedConfig.approachCount,
    requireTradeoffs: normalizedConfig.requireTradeoffs,
  });
  result = withYAGNIPrinciples(result);

  return result;
}
