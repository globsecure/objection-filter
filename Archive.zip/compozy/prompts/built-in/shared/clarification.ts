/**
 * Shared Clarification Prompt Utilities
 * Generic template builder for clarification prompts using functional composition
 */

import {
  composeSections,
  conditionalSection,
  createCriticalSectionBuilder,
  createSectionBuilder,
  createTemplateBuilder,
  createXmlTagBuilder,
  type SectionBuilder,
  type TemplateConfig,
} from "../../src/sections/template-builder";

/**
 * Configuration for building clarification prompts
 * Note: Schema documentation removed - using tool API mode (schemas passed via API, not in prompt text)
 */
export interface ClarificationPromptConfig {
  /** Full tool name for clarification tool */
  clarificationToolName: string;
  /** Maximum number of questions per round */
  maxQuestionsPerRound: number;
}

/**
 * Base configuration shared by all clarification prompts
 */
export interface ClarificationBaseConfig extends ClarificationPromptConfig {}

/**
 * Variant-specific configuration
 */
export interface ClarificationVariantConfig {
  title: string;
  focus: "business" | "technical";
  restriction: string;
  forbiddenCategories: string;
  categories: string[];
  neverAskAbout: string;
  webSearchEnforcement?: string;
  explorationContext?: string; // "exploration" vs "exploration and research"
  questionExamples?: string; // Explicit DO/DON'T question examples
}

/**
 * Section builders for clarification prompts
 */

// Tool documentation sections - Schema removed (using tool API mode)
const toolDocumentationSections = composeSections<
  TemplateConfig<ClarificationBaseConfig, ClarificationVariantConfig>
>(
  createSectionBuilder(config => ({
    title: "Using Clarification Questions Tool",
    content: `After ${config.variant.explorationContext || "exploration"}, you MUST call the ${config.base.clarificationToolName} tool. This is the ONLY way to ask questions.
**FORBIDDEN**: Do NOT output questions as markdown text, numbered lists, or plain text. Tool calling is MANDATORY.`,
  }))
);

// WebSearch enforcement (PRD only) - conditional section
const webSearchEnforcementSection = conditionalSection<
  TemplateConfig<ClarificationBaseConfig, ClarificationVariantConfig>
>(
  config => !!config.variant.webSearchEnforcement,
  createXmlTagBuilder<TemplateConfig<ClarificationBaseConfig, ClarificationVariantConfig>>(
    "critical_category_enforcement",
    config => config.variant.webSearchEnforcement!
  )
);

// Question validation checkpoint section (business focus only)
const questionValidationCheckpoint = conditionalSection<
  TemplateConfig<ClarificationBaseConfig, ClarificationVariantConfig>
>(
  config => config.variant.focus === "business",
  createSectionBuilder(() => ({
    title: "Question Validation Checkpoint (CRITICAL)",
    content: `**BEFORE FORMING ANY QUESTION, VERIFY IT IS NOT TECHNICAL**:

🚨 **IF YOUR QUESTION ASKS ABOUT HOW/WHERE/WHICH TECHNOLOGY → IT IS TECHNICAL → DO NOT ASK IT**

**VALIDATION CHECKLIST** - Before asking each question, verify it is NOT about:
- ❌ Databases, data storage, data models
- ❌ APIs, endpoints, request/response formats
- ❌ Code structure, modules, classes, functions
- ❌ Frameworks, libraries, technology stack
- ❌ Testing implementation, test strategies
- ❌ Architecture patterns, service boundaries
- ❌ Domain placement, module organization
- ❌ Data flow, infrastructure, deployment

**IF YOUR QUESTION CONTAINS ANY OF THESE TOPICS → IT IS TECHNICAL → DO NOT ASK IT**

**ONLY ASK ABOUT**:
- ✅ WHAT features users need
- ✅ WHY features provide business value
- ✅ WHO the target users are
- ✅ WHAT success metrics matter
- ✅ WHAT high-level constraints exist (business perspective)

**REMINDER**: PRD questions focus on WHAT/WHY (business), NOT HOW/WHERE/WHICH (technical).`,
  }))
);

// Question examples section (if provided)
const questionExamplesSection = conditionalSection<
  TemplateConfig<ClarificationBaseConfig, ClarificationVariantConfig>
>(
  config => !!config.variant.questionExamples,
  createSectionBuilder(config => ({
    title: "Question Examples - DO vs DON'T",
    content: config.variant.questionExamples!,
  }))
);

// Question formation sections - categories + guidelines grouped together
const questionFormationSections = composeSections<
  TemplateConfig<ClarificationBaseConfig, ClarificationVariantConfig>
>(
  createSectionBuilder(config => {
    const categoriesList = config.variant.categories.map(cat => `- ${cat}`).join("\n");
    return {
      title: `Question Categories Reference - ${config.variant.title}`,
      content: `<critical_category_restriction>
**${config.variant.restriction}**
**FORBIDDEN CATEGORIES**: ${config.variant.forbiddenCategories}
</critical_category_restriction>

When calling ${config.base.clarificationToolName} tool, select the most relevant categories based on your exploration:

${categoriesList}`,
    };
  }),
  createSectionBuilder(config => {
    const researchContext = config.variant.webSearchEnforcement
      ? "exploration findings and WebSearch research, but focused on business/product aspects only"
      : "exploration findings";

    const researchNote = config.variant.webSearchEnforcement
      ? ", but filter to business/product aspects only"
      : "";

    const categoryEnforcement = config.variant.webSearchEnforcement
      ? `\n- **CATEGORY ENFORCEMENT**: Even if WebSearch research reveals technical information, your questions must use business/product categories only. Ignore technical aspects from research when forming clarification questions.`
      : "";

    const focusType = config.variant.focus === "business" ? "business/product" : "technical";

    return {
      title: "Question Guidelines for Tool Call",
      content: `**ITERATIVE QUESTIONING MODE** (CRITICAL):
- **Question Count Per Round**: Ask 1-${config.base.maxQuestionsPerRound} questions per round (NEVER ask 5+ at once)
- **Multiple Rounds Expected**: After receiving answers, ask follow-up questions to go deeper
- **Use Previous Answers**: Reference and build on what the user told you in previous rounds
- **Iterate Until Clear**: Continue asking follow-up questions until you have true clarity
- **No Round Limit**: Take as many rounds as needed - quality over speed

**Question Formation**:
- Create **2-4 options per question** (informed by ${researchContext})
- **Always set allowOther: true** to allow custom user responses
- **Set multiple: true** when questions benefit from multiple selections
- **Set multiple: false** when questions require a single answer
- Keep questions **concise** and focused on ${focusType} decisions
- Base all options on **exploration findings${researchNote}** from codebase/project analysis
- Use appropriate question type: single-select for exclusive choices, multi-select for non-exclusive options
- **NEVER ask about**: ${config.variant.neverAskAbout}${categoryEnforcement}

**ANTI-PATTERNS (FORBIDDEN)**:
- Asking 5+ questions in a single tool call → FAILED
- Not asking follow-up questions based on answers → FAILED
- Skipping directly to artifact creation after first round → FAILED
- Ignoring previous answers when forming new questions → FAILED`,
    };
  })
);

// Critical requirements section
const criticalRequirementsSection: SectionBuilder<
  TemplateConfig<ClarificationBaseConfig, ClarificationVariantConfig>
> = createCriticalSectionBuilder(config => ({
  sections: [
    {
      title: "MANDATORY BEHAVIOR",
      format: "numbered",
      items: [
        `**CALL TOOL** → You MUST call ${config.base.clarificationToolName} tool (NEVER output questions as text)`,
        `**LIMIT QUESTIONS** → Ask 1-${config.base.maxQuestionsPerRound} questions per round (NEVER 5+ at once)`,
        `**STOP** → DO NOT proceed without user answers to ALL questions`,
        `**WAIT** → Only continue after receiving user input`,
        `**ITERATE** → Ask follow-up questions based on user answers - multiple rounds expected`,
      ],
    },
    {
      title: "FAILURE CONDITIONS",
      format: "bulleted",
      items: [
        "Outputting questions as markdown or plain text → FAILED",
        `Not calling ${config.base.clarificationToolName} tool → FAILED`,
        "Asking 5+ questions in a single tool call → FAILED",
        "Proceeding without user answers → FAILED",
        "Not asking follow-up questions based on answers → FAILED",
        "Skipping directly to artifact creation after first question round → FAILED",
        "Not following the exact schema (2-4 options per question, all required fields including multiple) → FAILED",
      ],
    },
  ],
  reminders: [
    `⚠️ If you output questions as text instead of calling tool → You have FAILED`,
    `⚠️ If you skip calling ${config.base.clarificationToolName} tool → You have FAILED`,
    `⚠️ If you ask 5+ questions at once → You have FAILED`,
    `⚠️ If you proceed without user answers → You have FAILED`,
    `⚠️ If you skip follow-up questions and jump to artifact creation → You have FAILED`,
    `⚠️ If you don't follow the exact schema (2-4 options per question, all required fields including multiple) → You have FAILED`,
    `✅ Call ${config.base.clarificationToolName} tool with 1-${config.base.maxQuestionsPerRound} questions per round`,
    `✅ Ask follow-up questions based on user answers - iterate until truly clear`,
    `✅ Set multiple: true for questions that benefit from multiple selections`,
    `✅ Set multiple: false for questions requiring single answers`,
  ],
  enforcementText: "Violating these standards results in immediate task rejection.",
}));

/**
 * Template definition for clarification prompts
 * Organized into logical groups using composeSections
 */
const clarificationTemplate = createTemplateBuilder({
  name: "clarification",
  sections: [
    toolDocumentationSections,
    webSearchEnforcementSection,
    questionValidationCheckpoint,
    questionExamplesSection,
    questionFormationSections,
    criticalRequirementsSection,
  ],
});

/**
 * Factory function to build clarification prompts
 */
export function buildClarificationPrompt(
  baseConfig: ClarificationBaseConfig,
  variantConfig: ClarificationVariantConfig
): string {
  return clarificationTemplate(baseConfig, variantConfig).build().trim();
}
