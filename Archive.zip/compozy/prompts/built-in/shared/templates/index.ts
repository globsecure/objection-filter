/**
 * Templates
 * Document structure templates for PRD, TechSpec, and Tasks
 */

export { PRD_TEMPLATE } from "./prd";
export { TECHSPEC_TEMPLATE } from "./techspec";
