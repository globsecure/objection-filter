/**
 * PRD Template
 * Template structure for Product Requirements Documents
 */

export const PRD_TEMPLATE = `[DON'T NEED TO ADD A H1 STYLE TITLE]
## Overview

[Provide a high-level overview of your product/feature. Explain what problem it solves, who it's for, and why it's valuable.]

## Goals

[List specific, measurable objectives for this feature:

- What success looks like
- Key metrics to track
- Business objectives to achieve]

## User Stories

[Detail the user narratives describing feature usage and benefits:

- As a [type of user], I want to [perform an action] so that [benefit]
- Include primary and secondary user personas
- Cover main user flows and edge cases]

## Core Features

[List and describe the main features of your product. For each feature, include:

- What it does
- Why it's important
- How it works at a high level
- Functional requirements (numbered for clarity)]

## User Experience

[Describe the user journey and experience:

- User personas and their needs
- Key user flows and interactions
- UI/UX considerations and design requirements
- Accessibility requirements]

## Non-Goals (Out of Scope)

[Clearly state what this feature will NOT include to manage scope:

- Features explicitly excluded
- Future considerations that are out of scope
- Boundaries and limitations]
`;
