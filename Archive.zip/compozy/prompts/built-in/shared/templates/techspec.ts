/**
 * TechSpec Template
 * Template structure for Technical Specifications
 */

export const TECHSPEC_TEMPLATE = `[DON'T NEED TO ADD A H1 STYLE TITLE]

## Executive Summary

[Provide a brief technical overview of the solution approach. Summarize the key architectural decisions and implementation strategy in 1-2 paragraphs.]

## System Architecture

### Domain Placement

[Specify where components belong in the project structure:

- Identify the appropriate directory/module for each component
- Group related components by domain or functionality
- Consider separation of concerns and module boundaries
- Document any internal packages or shared utilities used]

### Component Overview

[Brief description of main components and their responsibilities:

- Component names and primary functions
- Key relationships between components
- Data flow overview]

## Implementation Design

### Core Interfaces

[Define key service interfaces (≤20 lines per example):

\`\`\`
// Example interface definition
interface ServiceName {
    methodName(input: InputType): Promise<OutputType>;
}
\`\`\`

]

### Data Models

[Define essential data structures:

- Core domain entities
- Request/response types
- Database schemas (if applicable)]

### API Endpoints

[List API endpoints if applicable:

- Method and path (e.g., \`POST /api/v0/resource\`)
- Brief description
- Request/response format references]

## Integration Points

[Only include if feature requires external integrations:

- External services or APIs
- Authentication requirements
- Error handling approach]

## Impact Analysis

[Detail the potential impact of this feature on existing components, services, and data stores:]

| Affected Component          | Type of Impact            | Description & Risk Level               | Required Action      |
| --------------------------- | ------------------------- | -------------------------------------- | -------------------- |
| Example: \`auth-service\` API | API Change (Non-breaking) | Adds optional \`scope\` field. Low risk. | Notify frontend team |
| Example: \`users\` DB table   | Schema Change             | Adds new column. Medium risk.          | Coordinate migration |

[Categories to consider:

- **Direct Dependencies:** Modules that will call or be called by this feature
- **Shared Resources:** Database tables, caches, queues used by multiple components
- **API Changes:** Any modifications to existing endpoints or contracts
- **Performance Impact:** Components that might experience load changes]

## Testing Approach

### Unit Tests

[Describe unit testing strategy:

- Key components to test
- Mock requirements (external services only)
- Critical test scenarios]

### Integration Tests

[If needed, describe integration testing:

- Components to test together
- Test data requirements
- Test directory structure and organization]

## Development Sequencing

### Build Order

[Define implementation sequence:

1. First component/feature (why first)
2. Second component/feature (dependencies)
3. Subsequent components
4. Integration and testing]

### Technical Dependencies

[List any blocking dependencies:

- Required infrastructure
- External service availability
- Other team deliverables]

## Monitoring & Observability

[Define monitoring approach:

- Metrics to expose (format and standards)
- Key logs and log levels
- Integration with existing monitoring dashboards
- Monitoring infrastructure and tools to use]

## Technical Considerations

### Key Decisions

[Document important technical decisions:

- Choice of approach and rationale
- Trade-offs considered
- Alternatives rejected and why]

### Known Risks

[Identify technical risks:

- Potential challenges
- Mitigation approaches
- Areas needing research]

### Special Requirements

[Only if applicable:

- Performance requirements (specific metrics)
- Security considerations (beyond standard auth)
- Additional monitoring needs]

### Standards Compliance

[Confirm adherence to project standards:

- Follows architectural principles and guidelines
- Applies coding standards and conventions
- Uses required libraries and frameworks
- Implements proper error handling patterns
- Follows testing standards and practices]
`;
