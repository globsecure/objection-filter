/**
 * Tests for builder-integrated helpers
 * Tests critical sections, constraints, agents, and tools helpers
 */

import { describe, expect, it } from "vitest";
import { createPromptBuilder } from "../../src/builder";
import type { AgentDefinition, Constraint } from "../../src/types";
import { withCriticalPRDRequirements } from "../prd";
import { withSubagentsSection } from "../shared/agents";
import { withExplorationConstraints, withResearchConstraints } from "../shared/constraints";
import { withCriticalTasksRequirements } from "../tasks";
import { withCriticalTechSpecRequirements } from "../techspec";
describe("Builder-Integrated Helpers", () => {
  describe("withCriticalPRDRequirements", () => {
    it("should add PRD critical requirements", () => {
      const builder = createPromptBuilder();
      builder.withPlaceholder("{{TOOL_NAME_CLARIFICATION}}", "test_clarification");
      builder.withPlaceholder("{{TOOL_NAME_PRD_CREATE}}", "test_prd_create");
      builder.withPlaceholder("{{TOOL_NAME_PRD_UPDATE}}", "test_prd_update");
      const result = withCriticalPRDRequirements(builder);

      expect(result.hasConstraints()).toBe(true);
      const constraints = result.getConstraints();
      expect(constraints.length).toBeGreaterThan(0);
      const prompt = result.build();
      expect(prompt).toContain("test_clarification");
      expect(prompt).toContain("test_prd_create");
      expect(prompt).toContain("SINGLE PRD CONSTRAINT");
    });

    it("should add critical section", () => {
      const builder = createPromptBuilder();
      builder.withPlaceholder("{{TOOL_NAME_CLARIFICATION}}", "test_clarification");
      builder.withPlaceholder("{{TOOL_NAME_PRD_CREATE}}", "test_prd_create");
      builder.withPlaceholder("{{TOOL_NAME_PRD_UPDATE}}", "test_prd_update");
      const result = withCriticalPRDRequirements(builder);

      const prompt = result.build();
      expect(prompt).toContain("<critical>");
      expect(prompt).toContain("test_clarification");
      expect(prompt).toContain("test_prd_create");
      expect(prompt).toContain("SINGLE PRD CONSTRAINT");
    });
  });

  describe("withCriticalTechSpecRequirements", () => {
    it("should add TechSpec critical requirements", () => {
      const builder = createPromptBuilder();
      builder.withPlaceholder("{{TOOL_NAME_CLARIFICATION}}", "test_clarification");
      builder.withPlaceholder("{{TOOL_NAME_TECHSPEC_CREATE}}", "test_techspec_create");
      builder.withPlaceholder("{{TOOL_NAME_TECHSPEC_UPDATE}}", "test_techspec_update");
      const result = withCriticalTechSpecRequirements(builder);

      expect(result.hasConstraints()).toBe(true);
      const constraints = result.getConstraints();
      expect(constraints.length).toBeGreaterThan(0);
      const prompt = result.build();
      expect(prompt).toContain("test_clarification");
      expect(prompt).toContain("test_techspec_create");
      expect(prompt).toContain("SINGLE TECHSPEC CONSTRAINT");
    });

    it("should add critical section", () => {
      const builder = createPromptBuilder();
      builder.withPlaceholder("{{TOOL_NAME_CLARIFICATION}}", "test_clarification");
      builder.withPlaceholder("{{TOOL_NAME_TECHSPEC_CREATE}}", "test_techspec_create");
      builder.withPlaceholder("{{TOOL_NAME_TECHSPEC_UPDATE}}", "test_techspec_update");
      const result = withCriticalTechSpecRequirements(builder);

      const prompt = result.build();
      expect(prompt).toContain("<critical>");
      expect(prompt).toContain("test_clarification");
      expect(prompt).toContain("test_techspec_create");
      expect(prompt).toContain("SINGLE TECHSPEC CONSTRAINT");
    });
  });

  describe("withCriticalTasksRequirements", () => {
    it("should add Tasks critical requirements", () => {
      const builder = createPromptBuilder();
      builder.withPlaceholder("{{TOOL_NAME_APPROVE_TASKS}}", "test_approve_tasks");
      builder.withPlaceholder("{{TOOL_NAME_LIST_TASKS}}", "test_list_tasks");
      const result = withCriticalTasksRequirements(builder);

      expect(result.hasConstraints()).toBe(true);
      const constraints = result.getConstraints();
      expect(constraints.length).toBeGreaterThan(0);
      const prompt = result.build();
      expect(prompt).toContain("test_approve_tasks");
      expect(prompt).toContain("test_list_tasks");
    });

    it("should add critical section", () => {
      const builder = createPromptBuilder();
      builder.withPlaceholder("{{TOOL_NAME_APPROVE_TASKS}}", "test_approve_tasks");
      builder.withPlaceholder("{{TOOL_NAME_LIST_TASKS}}", "test_list_tasks");
      const result = withCriticalTasksRequirements(builder);

      const prompt = result.build();
      expect(prompt).toContain("<critical>");
      expect(prompt).toContain("test_approve_tasks");
      expect(prompt).toContain("test_list_tasks");
    });
  });

  describe("withResearchConstraints", () => {
    it("should add research constraints", () => {
      const builder = createPromptBuilder();
      const result = withResearchConstraints(builder, 3, 7);

      expect(result.hasConstraints()).toBe(true);
      const constraints = result.getConstraints();
      expect(constraints.some((c: Constraint) => c.rule.includes("3-7"))).toBe(true);
      expect(constraints.some((c: Constraint) => c.type === "must")).toBe(true);
      expect(constraints.some((c: Constraint) => c.type === "must_not")).toBe(true);
      expect(constraints.some((c: Constraint) => c.type === "should")).toBe(true);
    });

    it("should allow overriding research tool name", () => {
      const builder = createPromptBuilder();
      const result = withResearchConstraints(builder, 1, 2, { webSearch: "@customSearch" });
      const constraints = result.getConstraints();

      expect(
        constraints.some((c: Constraint) => c.rule.includes("@customSearch") && c.type === "must")
      ).toBe(true);
      expect(
        constraints.some(
          (c: Constraint) => c.rule.includes("@customSearch") && c.type === "must_not"
        )
      ).toBe(true);
    });
  });

  describe("withExplorationConstraints", () => {
    it("should add parallel exploration constraints", () => {
      const builder = createPromptBuilder();
      const result = withExplorationConstraints(builder, true);

      expect(result.hasConstraints()).toBe(true);
      const constraints = result.getConstraints();
      expect(constraints.some((c: Constraint) => c.rule.includes("PARALLEL"))).toBe(true);
      expect(constraints.some((c: Constraint) => c.rule.includes("@fileExplorer"))).toBe(true);
      expect(constraints.some((c: Constraint) => c.rule.includes("@rulesExplorer"))).toBe(true);
    });

    it("should add non-parallel exploration constraints", () => {
      const builder = createPromptBuilder();
      const result = withExplorationConstraints(builder, false);

      expect(result.hasConstraints()).toBe(true);
      const constraints = result.getConstraints();
      expect(constraints.some((c: Constraint) => c.type === "should")).toBe(true);
    });

    it("should allow overriding explorer tool names", () => {
      const builder = createPromptBuilder();
      const result = withExplorationConstraints(builder, true, {
        fileExplorer: "@customFile",
        rulesExplorer: "@customRules",
      });

      const constraints = result.getConstraints();
      expect(constraints.some((c: Constraint) => c.rule.includes("@customFile"))).toBe(true);
      expect(constraints.some((c: Constraint) => c.rule.includes("@customRules"))).toBe(true);
    });
  });

  describe("withSubagentsSection", () => {
    it("should add subagents", () => {
      const builder = createPromptBuilder();
      const result = withSubagentsSection(builder);

      expect(result.hasAgents()).toBe(true);
      const agents = result.getAgents();
      expect(agents.length).toBe(5);
      expect(agents.some((a: AgentDefinition) => a.name === "@fileExplorer")).toBe(true);
      expect(agents.some((a: AgentDefinition) => a.name === "@rulesExplorer")).toBe(true);
      expect(agents.some((a: AgentDefinition) => a.name === "@businessAnalyst")).toBe(true);
      expect(agents.some((a: AgentDefinition) => a.name === "@taskEnricher")).toBe(true);
      expect(agents.some((a: AgentDefinition) => a.name === "@reviewAgent")).toBe(true);
    });

    it("should add subagents usage guidelines section", () => {
      const builder = createPromptBuilder();
      const result = withSubagentsSection(builder);

      const prompt = result.build();
      expect(prompt).toContain("Subagent Usage Guidelines");
      expect(prompt).toContain("PARALLEL");
    });
  });

  describe("helper chaining", () => {
    it("should allow chaining multiple helpers", () => {
      let builder = createPromptBuilder();
      builder.withPlaceholder("{{TOOL_NAME_CLARIFICATION}}", "test_clarification");
      builder.withPlaceholder("{{TOOL_NAME_PRD_CREATE}}", "test_prd_create");
      builder.withPlaceholder("{{TOOL_NAME_PRD_UPDATE}}", "test_prd_update");
      builder = withCriticalPRDRequirements(builder);
      builder = withResearchConstraints(builder, 3, 7);
      builder = withSubagentsSection(builder);

      expect(builder.hasConstraints()).toBe(true);
      expect(builder.hasAgents()).toBe(true);
      const prompt = builder.build();
      expect(prompt).toContain("<critical>");
      expect(prompt).toContain("Subagents");
    });
  });
});
