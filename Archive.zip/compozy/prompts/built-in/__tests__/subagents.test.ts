import { describe, expect, it } from "vitest";
import {
  buildBusinessAnalystPrompt,
  businessAnalystOutputSchema,
} from "../subagents/business-analyst";
import { buildFileExplorerPrompt, fileExplorerOutputSchema } from "../subagents/file-explorer";
import { buildRulesExplorerPrompt, rulesExplorerOutputSchema } from "../subagents/rules-explorer";

/**
 * Helper function to validate structured output prompt contract.
 * Anchors on structure rather than exact copy to reduce test brittleness.
 */
function expectStructuredOutputPrompt(prompt: string, typeTag: string) {
  expect(prompt).toContain("JSON");
  expect(prompt).toContain(typeTag);
  expect(prompt).toMatch(/return/i);
  expect(prompt).toMatch(/only/i);
}

describe("Subagents", () => {
  describe("File Explorer", () => {
    it("exports schema and type", () => {
      expect(fileExplorerOutputSchema).toBeDefined();
      expect(typeof fileExplorerOutputSchema.parse).toBe("function");
    });

    it("uses structured output schema instructions", () => {
      const systemPrompt = buildFileExplorerPrompt();
      expectStructuredOutputPrompt(systemPrompt, "file-explorer-output");
    });

    it("does not contain conversational language", () => {
      const systemPrompt = buildFileExplorerPrompt();

      expect(systemPrompt).not.toContain("Be conversational");
      expect(systemPrompt).not.toContain("without rigid output formats");
      expect(systemPrompt).not.toContain("Respond naturally");
    });

    it("validates schema structure", () => {
      const validOutput = {
        type: "file-explorer-output" as const,
        files: [
          {
            path: "src/lib/auth.ts",
            category: "source" as const,
            relevance: "Core authentication logic",
          },
        ],
        searchStrategy: "Used Explorer tool for deep research",
        suggestedNextSteps: ["Search for related test files"],
      };

      expect(() => fileExplorerOutputSchema.parse(validOutput)).not.toThrow();
    });
  });

  describe("Rules Explorer", () => {
    it("exports schema and type", () => {
      expect(rulesExplorerOutputSchema).toBeDefined();
      expect(typeof rulesExplorerOutputSchema.parse).toBe("function");
    });

    it("uses structured output schema instructions", () => {
      const systemPrompt = buildRulesExplorerPrompt();
      expectStructuredOutputPrompt(systemPrompt, "rules-explorer-output");
    });

    it("does not contain conversational language", () => {
      const systemPrompt = buildRulesExplorerPrompt();

      expect(systemPrompt).not.toContain("Be conversational");
      expect(systemPrompt).not.toContain("without rigid output formats");
      expect(systemPrompt).not.toContain("Respond naturally");
    });

    it("validates schema structure", () => {
      const validOutput = {
        type: "rules-explorer-output" as const,
        rules: [
          {
            category: "Authentication",
            content: "Use token-based authentication",
            sourceFile: ".cursor/rules/authentication.mdc",
            enforcementLevel: "CRITICAL" as const,
          },
        ],
        applicableTo: "Feature development with authentication",
      };

      expect(() => rulesExplorerOutputSchema.parse(validOutput)).not.toThrow();
    });
  });

  describe("Business Analyst", () => {
    it("exports schema and type", () => {
      expect(businessAnalystOutputSchema).toBeDefined();
      expect(typeof businessAnalystOutputSchema.parse).toBe("function");
    });

    it("uses structured output schema instructions", () => {
      const systemPrompt = buildBusinessAnalystPrompt();
      expectStructuredOutputPrompt(systemPrompt, "business-analyst-output");
    });

    it("does not contain conversational language", () => {
      const systemPrompt = buildBusinessAnalystPrompt();

      expect(systemPrompt).not.toContain("Be conversational");
      expect(systemPrompt).not.toContain("without rigid output formats");
      expect(systemPrompt).not.toContain("Respond naturally");
    });

    it("validates schema structure", () => {
      const validOutput = {
        type: "business-analyst-output" as const,
        problemAnalysis: {
          coreProblem: "Users struggle to find project status",
          rootCauses: ["Information scattered across multiple views"],
          affectedUsers: ["Project managers", "Team leads"],
        },
        userNeeds: [
          {
            persona: "Project Manager",
            goals: ["Quick status overview"],
            frictionPoints: ["Multiple page navigation"],
          },
        ],
        featurePrioritization: {
          mvpFeatures: ["Single-page dashboard"],
          futurePhases: ["Customizable widgets"],
          nonGoals: ["Advanced analytics"],
        },
        successMetrics: [
          {
            metric: "Daily active usage",
            target: "80%",
            baseline: "60%",
          },
        ],
      };

      expect(() => businessAnalystOutputSchema.parse(validOutput)).not.toThrow();
    });
  });
});
