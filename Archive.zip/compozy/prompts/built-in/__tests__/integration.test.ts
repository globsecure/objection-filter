/**
 * Integration tests for built-in prompt factories
 * Tests complete prompt building workflows
 */

import { describe, expect, it } from "vitest";
import { buildPRDPrompt } from "../prd";
import { buildTasksPrompt } from "../tasks";
import { buildTechSpecPrompt } from "../techspec";
import { injectToolNamesIntoBuilder, type MockExecutableTool } from "./test-helpers";

describe("Integration Tests", () => {
  describe("buildPRDPrompt", () => {
    it("should build complete PRD prompt with all sections", () => {
      const builder = buildPRDPrompt({
        brainstormConfig: {
          clarificationToolName: "{{TOOL_NAME_CLARIFICATION}}",
          maxQuestionsPerRound: 5,
        },
        issueId: "00000000-0000-0000-0000-000000000000",
      });
      // Mock tools for injection
      const mockTools: MockExecutableTool[] = [
        {
          name: "mcp__prd__ask_clarification_questions",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
        {
          name: "mcp__prd__present_approaches",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
        {
          name: "mcp__prd__output_prd",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
      ];
      const builderWithTools = injectToolNamesIntoBuilder(builder, mockTools);
      const system = builderWithTools.buildSystemPrompt();

      expect(system).toBeDefined();
      expect(system).toContain("PRD creation specialist");
      expect(system).toContain("<critical>");
      expect(system).toContain("mcp__prd__ask_clarification_questions");
      expect(system).toContain("mcp__prd__present_approaches");
      expect(system).toContain("mcp__prd__output_prd");
      // Verify single document constraint is present
      expect(system).toContain("SINGLE PRD CONSTRAINT");
      // Template should appear at the end of system prompt
      expect(system).toContain("<prd_template>");
      expect(system).toContain("</prd_template>");
      // Verify template is at the end (after other content)
      const templateIndex = system.indexOf("<prd_template>");
      const specialistIndex = system.indexOf("PRD creation specialist");
      expect(templateIndex).toBeGreaterThan(specialistIndex);
    });

    it("should include capabilities", () => {
      const builder = buildPRDPrompt({
        brainstormConfig: {
          clarificationToolName: "{{TOOL_NAME_CLARIFICATION}}",
          maxQuestionsPerRound: 5,
        },
        issueId: "00000000-0000-0000-0000-000000000000",
      });
      const mockTools: MockExecutableTool[] = [
        {
          name: "mcp__techspec__ask_clarification_questions",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
        {
          name: "mcp__prd__output_prd",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
      ];
      const builderWithTools = injectToolNamesIntoBuilder(builder, mockTools);
      const system = builderWithTools.buildSystemPrompt();

      expect(system).toContain("## Capabilities");
      expect(system).toContain("Create Product Requirements Documents");
    });

    it("should apply brainstorm settings for approach exploration", () => {
      const builder = buildPRDPrompt({
        brainstormConfig: {
          clarificationToolName: "{{TOOL_NAME_CLARIFICATION}}",
          maxQuestionsPerRound: 5,
          approachCount: 5,
          requireTradeoffs: false,
        },
        issueId: "00000000-0000-0000-0000-000000000000",
      });

      const mockTools: MockExecutableTool[] = [
        {
          name: "mcp__prd__ask_clarification_questions",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
        {
          name: "mcp__prd__present_approaches",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
        {
          name: "mcp__prd__output_prd",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
      ];

      const builderWithTools = injectToolNamesIntoBuilder(builder, mockTools);
      const system = builderWithTools.buildSystemPrompt();

      expect(system).toContain("mcp__prd__present_approaches");
      expect(system).toContain("present 4-5 distinct product/business approaches");
      expect(system).not.toContain("TRADE-OFFS REQUIRED");
    });
  });

  describe("buildTechSpecPrompt", () => {
    it("should build complete TechSpec prompt with all sections", () => {
      const builder = buildTechSpecPrompt({
        brainstormConfig: {
          clarificationToolName: "{{TOOL_NAME_CLARIFICATION}}",
          maxQuestionsPerRound: 5,
        },
        issueId: "00000000-0000-0000-0000-000000000000",
        prdArtifact: {
          id: "prd-1",
          title: "Sample PRD",
          filePath: "/path/to/prd.md",
          version: 2,
        },
      });
      const mockTools: MockExecutableTool[] = [
        {
          name: "mcp__techspec__ask_clarification_questions",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
        {
          name: "mcp__techspec__present_approaches",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
        {
          name: "mcp__techspec__output_techspec",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
      ];
      const builderWithTools = injectToolNamesIntoBuilder(builder, mockTools);
      const system = builderWithTools.buildSystemPrompt();

      expect(system).toBeDefined();
      expect(system).toContain("systems architect");
      expect(system).toContain("<critical>");
      expect(system).toContain("mcp__techspec__ask_clarification_questions");
      expect(system).toContain("mcp__techspec__present_approaches");
      expect(system).toContain("mcp__techspec__output_techspec");
      // Verify single document constraint is present
      expect(system).toContain("SINGLE TECHSPEC CONSTRAINT");
      expect(system).toContain("Subagents");
      // Template should appear at the end of system prompt
      expect(system).toContain("<techspec_template>");
      expect(system).toContain("</techspec_template>");
      // Verify template is at the end (after other content)
      const templateIndex = system.indexOf("<techspec_template>");
      const architectIndex = system.indexOf("systems architect");
      expect(templateIndex).toBeGreaterThan(architectIndex);
    });

    it("should include PRD access instructions when building prompt", () => {
      const builder = buildTechSpecPrompt({
        brainstormConfig: {
          clarificationToolName: "{{TOOL_NAME_CLARIFICATION}}",
          maxQuestionsPerRound: 5,
        },
        issueId: "00000000-0000-0000-0000-000000000000",
        prdArtifact: {
          id: "prd-1",
          title: "Sample PRD",
          filePath: "/path/to/prd.md",
          version: 2,
        },
      });
      const mockTools: MockExecutableTool[] = [
        {
          name: "mcp__techspec__ask_clarification_questions",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
        {
          name: "mcp__techspec__output_techspec",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
      ];
      const builderWithTools = injectToolNamesIntoBuilder(builder, mockTools);
      const system = builderWithTools.buildSystemPrompt();

      expect(system).toContain("PRD Context (reference)");
      expect(system).toContain("<prd>");
      expect(system).toContain("Sample PRD");
      expect(system).not.toContain("{{TOOL_NAME_LIST_PRDS}}");
      expect(system).not.toContain("{{TOOL_NAME_GET_PRD}}");
    });
  });

  describe("buildTasksPrompt", () => {
    it("should build complete Tasks prompt with all sections", () => {
      const builder = buildTasksPrompt({
        issueId: "00000000-0000-0000-0000-000000000000",
        prdArtifact: {
          id: "prd-1",
          title: "Sample PRD",
          filePath: "/path/to/prd.md",
          version: 1,
        },
        techspecArtifact: {
          id: "tech-1",
          title: "Sample TechSpec",
          filePath: "/path/to/techspec.md",
          version: 3,
        },
      });
      const mockTools: MockExecutableTool[] = [
        {
          name: "mcp__tasks__approve_tasks",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
        {
          name: "mcp__tasks__list_tasks",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
      ];
      const builderWithTools = injectToolNamesIntoBuilder(builder, mockTools);
      const system = builderWithTools.buildSystemPrompt();

      expect(system).toBeDefined();
      expect(system).toContain("task breakdown specialist");
      expect(system).toContain("<critical>");
      expect(system).toContain("mcp__tasks__approve_tasks");
      expect(system).toContain("mcp__tasks__list_tasks");
      // Verify management phase tools are documented (placeholders remain if tools not injected)
      expect(system).toContain("Management Phase");
      expect(system).toContain("update_task");
      expect(system).toContain("delete_task");
      expect(system).toContain("reorder_tasks");
    });

    it("should include PRD and TechSpec access instructions", () => {
      const builder = buildTasksPrompt({
        issueId: "00000000-0000-0000-0000-000000000000",
        prdArtifact: {
          id: "prd-1",
          title: "Sample PRD",
          filePath: "/path/to/prd.md",
          version: 1,
        },
        techspecArtifact: {
          id: "tech-1",
          title: "Sample TechSpec",
          filePath: "/path/to/techspec.md",
          version: 3,
        },
      });
      const mockTools: MockExecutableTool[] = [
        {
          name: "mcp__tasks__approve_tasks",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
        {
          name: "mcp__tasks__list_tasks",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
      ];
      const builderWithTools = injectToolNamesIntoBuilder(builder, mockTools);
      const system = builderWithTools.buildSystemPrompt();

      expect(system).toContain("Artifact Context (references)");
      expect(system).toContain("<prd>");
      expect(system).toContain("<techspec>");
      expect(system).toContain("Sample PRD");
      expect(system).toContain("Sample TechSpec");
      expect(system).not.toContain("{{TOOL_NAME_LIST_PRDS}}");
      expect(system).not.toContain("{{TOOL_NAME_GET_PRD}}");
      expect(system).not.toContain("{{TOOL_NAME_LIST_TECHSPECS}}");
      expect(system).not.toContain("{{TOOL_NAME_GET_TECHSPEC}}");
    });
  });

  describe("prompt structure validation", () => {
    it("should build valid prompt", () => {
      const builder = buildPRDPrompt({
        brainstormConfig: {
          clarificationToolName: "{{TOOL_NAME_CLARIFICATION}}",
          maxQuestionsPerRound: 5,
        },
        issueId: "00000000-0000-0000-0000-000000000000",
      });
      const mockTools: MockExecutableTool[] = [
        {
          name: "mcp__prd__ask_clarification_questions",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
        {
          name: "mcp__prd__present_approaches",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
        {
          name: "mcp__prd__output_prd",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
        {
          name: "mcp__prd__update_prd",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
      ];
      const builderWithTools = injectToolNamesIntoBuilder(builder, mockTools);
      const system = builderWithTools.buildSystemPrompt();
      const messages = builderWithTools.buildMessages();

      expect(typeof system).toBe("string");
      expect(Array.isArray(messages.messages)).toBe(true);
      expect(system.length).toBeGreaterThan(0);
      // Verify all tool placeholders are injected
      expect(system).toContain("mcp__prd__output_prd");
      expect(system).toContain("mcp__prd__update_prd");
      expect(system).toContain("mcp__prd__present_approaches");
    });

    it("should handle tool collision scenarios correctly", () => {
      const builder = buildPRDPrompt({
        brainstormConfig: {
          clarificationToolName: "{{TOOL_NAME_CLARIFICATION}}",
          maxQuestionsPerRound: 5,
        },
        issueId: "00000000-0000-0000-0000-000000000000",
      });
      // Test collision scenario: multiple PRD tools should map to different placeholders
      const mockTools: MockExecutableTool[] = [
        {
          name: "mcp__prd__output_prd",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
        {
          name: "mcp__prd__update_prd",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
      ];
      const builderWithTools = injectToolNamesIntoBuilder(builder, mockTools);
      const system = builderWithTools.buildSystemPrompt();

      // All tools should be injected without collision
      expect(system).toContain("mcp__prd__output_prd");
      expect(system).toContain("mcp__prd__update_prd");
    });

    it("should include constraints in system prompt", () => {
      const builder = buildPRDPrompt({
        brainstormConfig: {
          clarificationToolName: "{{TOOL_NAME_CLARIFICATION}}",
          maxQuestionsPerRound: 5,
        },
        issueId: "00000000-0000-0000-0000-000000000000",
      });
      const mockTools: MockExecutableTool[] = [
        {
          name: "mcp__prd__ask_clarification_questions",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
        {
          name: "mcp__prd__present_approaches",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
        {
          name: "mcp__prd__output_prd",
          description: "",
          parameters: {},
          execute: async () => ({}),
        },
      ];
      const builderWithTools = injectToolNamesIntoBuilder(builder, mockTools);
      const system = builderWithTools.buildSystemPrompt();

      expect(system).toContain("## Constraints");
      expect(system).toContain("**Must:**");
    });
  });
});
