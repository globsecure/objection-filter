import { describe, expect, it } from "vitest";
import { buildConfirmationPrompt } from "../task-confirmation/factory";
import { buildReviewPrompt } from "../task-review/factory";
import type { ConfirmationInput } from "../task-confirmation/types";
import type { ReviewInput } from "../task-review/types";

const baseInput: ConfirmationInput = {
  taskDefinition: {
    id: "task-1",
    issueId: "issue-1",
    title: "Implement confirmation and review prompts",
    filePath: "/path/to/task-1.md",
    content: "Acceptance criteria:\n- add confirmation prompt\n- add review prompt",
    complexity: "medium",
  },
  issueContext: {
    prdPath: "/path/to/prd.md",
    techspecPath: "/path/to/techspec.md",
    issueContextPath: "/path/to/issue-context.md",
    tasksDirPath: "/path/to/tasks",
  },
  snapshot: {
    summary: "Primary execution completed, tests executed, lint clean.",
    exitCode: 0,
    lastMessages: [
      { role: "assistant", content: "Finished execution successfully" },
      { role: "user", content: "Great, thanks" },
    ],
    artifacts: {
      testsStatus: "passed",
      lintStatus: "passed",
      changedFiles: ["packages/prompts/built-in/task-confirmation/factory.ts"],
      testsRan: ["pnpm run test"],
      diffSummary: "Added confirmation and review prompt factories",
    },
  },
};

describe("task-review prompt factories", () => {
  describe("buildConfirmationPrompt", () => {
    it("generates correct confirmation prompts", () => {
      const { systemPrompt, userPrompt } = buildConfirmationPrompt(baseInput);

      expect(systemPrompt).toMatchSnapshot("confirmation-system-prompt");
      expect(userPrompt).toMatchSnapshot("confirmation-user-prompt");
    });

    it("handles missing artifacts and summaries gracefully", () => {
      const minimalInput: ConfirmationInput = {
        ...baseInput,
        snapshot: {
          summary: "",
          exitCode: 1,
          lastMessages: [],
        },
      };

      const { userPrompt } = buildConfirmationPrompt(minimalInput);

      expect(userPrompt).toMatchSnapshot("confirmation-user-prompt-minimal");
    });
  });

  describe("buildReviewPrompt", () => {
    const reviewInput: ReviewInput = {
      ...baseInput,
      confirmationVerdict: {
        status: "fail",
        reasons: ["Exit code non-zero"],
        limitError: false,
        definitionMismatch: true,
        errorDetected: true,
        actionItems: ["Re-run tests"],
      },
    };

    it("generates correct review prompts", () => {
      const { systemPrompt, userPrompt } = buildReviewPrompt(reviewInput);

      expect(systemPrompt).toMatchSnapshot("review-system-prompt");
      expect(userPrompt).toMatchSnapshot("review-user-prompt");
    });
  });
});
