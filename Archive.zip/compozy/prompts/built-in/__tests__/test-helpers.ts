/**
 * Test helpers for built-in prompts
 * Provides test utilities that don't depend on external packages
 */

import type { PromptBuilder } from "../../src/builder";

/**
 * Mock ExecutableTool type for testing
 */
export interface MockExecutableTool {
  name: string;
  description: string;
  parameters: unknown;
  execute: (args: unknown) => Promise<unknown> | unknown;
}

/**
 * Extracts tool names from ExecutableTool[] and maps them to placeholders
 * Uses exact name matching to prevent collisions between operations
 */
function extractToolNames(tools: MockExecutableTool[]): Record<string, string> {
  const mapping: Record<string, string> = {};

  for (const tool of tools) {
    // Clarification tool
    if (tool.name.endsWith("__ask_clarification_questions")) {
      mapping["{{TOOL_NAME_CLARIFICATION}}"] = tool.name;
    }
    // Approaches tool
    else if (tool.name.endsWith("__present_approaches")) {
      mapping["{{TOOL_NAME_APPROACHES}}"] = tool.name;
    }
    // PRD tools - suffix-based matching
    else if (tool.name === "mcp__prd__output_prd") {
      mapping["{{TOOL_NAME_PRD_CREATE}}"] = tool.name;
    } else if (tool.name === "mcp__prd__update_prd") {
      mapping["{{TOOL_NAME_PRD_UPDATE}}"] = tool.name;
    }
    // TechSpec tools - suffix-based matching
    else if (tool.name === "mcp__techspec__output_techspec") {
      mapping["{{TOOL_NAME_TECHSPEC_CREATE}}"] = tool.name;
    } else if (tool.name === "mcp__techspec__update_techspec") {
      mapping["{{TOOL_NAME_TECHSPEC_UPDATE}}"] = tool.name;
    }
    // Tasks tools - suffix-based matching
    else if (tool.name === "mcp__tasks__approve_tasks") {
      mapping["{{TOOL_NAME_APPROVE_TASKS}}"] = tool.name;
    } else if (tool.name === "mcp__tasks__list_tasks") {
      mapping["{{TOOL_NAME_LIST_TASKS}}"] = tool.name;
    } else if (tool.name === "mcp__tasks__update_task") {
      mapping["{{TOOL_NAME_UPDATE_TASK}}"] = tool.name;
    } else if (tool.name === "mcp__tasks__delete_task") {
      mapping["{{TOOL_NAME_DELETE_TASK}}"] = tool.name;
    } else if (tool.name === "mcp__tasks__reorder_tasks") {
      mapping["{{TOOL_NAME_REORDER_TASKS}}"] = tool.name;
    }
  }

  return mapping;
}

/**
 * Injects tool names from MockExecutableTool[] into PromptBuilder placeholders
 * Test-only version that doesn't depend on @compozy/ag-ui
 */
export function injectToolNamesIntoBuilder(
  builder: PromptBuilder,
  tools: MockExecutableTool[]
): PromptBuilder {
  const toolNameMap = extractToolNames(tools);

  let currentBuilder = builder;
  for (const [placeholder, toolName] of Object.entries(toolNameMap)) {
    currentBuilder = currentBuilder.withPlaceholder(placeholder, toolName);
  }

  return currentBuilder;
}
