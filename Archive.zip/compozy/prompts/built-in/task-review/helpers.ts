import { trim } from "es-toolkit/string";
import type { ConfirmationVerdict } from "../task-confirmation/types";
import type { ReviewVerdict } from "./types";
import {
  formatArtifacts,
  formatExecutionSnapshot,
  formatMessages,
} from "../task-confirmation/helpers";

function toBulletList(values?: string[], emptyLabel = "None provided"): string {
  if (!values || values.length === 0) {
    return `- ${emptyLabel}`;
  }

  const trimmedValues = values.map(value => trim(value)).filter(value => value.length > 0);

  if (trimmedValues.length === 0) {
    return `- ${emptyLabel}`;
  }

  return trimmedValues.map(value => `- ${value}`).join("\n");
}

export function buildReviewChecksSection(): string {
  return `Assess the run quality and risks. If you find issues, FIX THEM in this review pass before returning the verdict:
- Test execution results (failures, skipped suites, coverage gaps)
- Lint execution results (errors, warnings, rule suppressions)
- Code quality (readability, maintainability, adherence to standards)
- Security or regression risks (secrets, unsafe patterns, breaking changes)
- Flakiness signals (non-deterministic behavior, race conditions, network-dependent tests)
- Unresolved TODOs or temporary hacks left in code
- Coverage gaps for critical paths and edge cases`;
}

export function formatConfirmationVerdict(verdict: ConfirmationVerdict): string {
  const reasons = toBulletList(verdict.reasons, "No reasons provided");
  const actionItems = toBulletList(verdict.actionItems, "No action items provided");

  return `Status: ${verdict.status}
Limit error: ${verdict.limitError}
Definition mismatch: ${verdict.definitionMismatch}
Error detected: ${verdict.errorDetected}
Reasons:
${reasons}
Action items:
${actionItems}`;
}

export function formatReviewVerdict(verdict?: ReviewVerdict): string {
  if (!verdict) {
    return "No prior review verdict provided.";
  }

  return `Status: ${verdict.status}
Blocking issues:
${toBulletList(verdict.blockingIssues)}
Non-blocking issues:
${toBulletList(verdict.nonBlockingIssues)}
Test findings:
${toBulletList(verdict.testFindings)}
Flakiness signals:
${toBulletList(verdict.flakinessSignals)}
Risk rating: ${verdict.riskRating}`;
}

// Re-export shared helpers for convenience
export { formatArtifacts, formatExecutionSnapshot, formatMessages };
