import { ARTIFACT_LIST_TOOL_NAME } from "@compozy/types";
import { z } from "zod";
import { createPromptBuilder } from "../../src/builder";
import type { PromptComponents } from "../task-execution/factory";
import { formatIssueContext } from "../task-confirmation/helpers";
import {
  buildReviewChecksSection,
  formatArtifacts,
  formatConfirmationVerdict,
  formatMessages,
} from "./helpers";
import type { ReviewInput } from "./types";

/**
 * Zod schema for the review output.
 * Used both for prompt generation (converted to JSON Schema) and response validation.
 */
export const reviewOutputSchema = z.object({
  type: z.literal("task-review-output"),
  response: z.object({
    status: z.enum(["pass", "fail", "warn"]).describe("Review status verdict"),
    blockingIssues: z.array(z.string()).describe("Critical issues that must be resolved"),
    nonBlockingIssues: z.array(z.string()).describe("Minor issues that can be addressed later"),
    testFindings: z.array(z.string()).describe("Test failures, absent tests, or coverage notes"),
    flakinessSignals: z.array(z.string()).describe("Potential flakiness indicators"),
    riskRating: z.enum(["low", "medium", "high"]).describe("Overall risk level of the changes"),
  }),
});

export type ReviewOutput = z.infer<typeof reviewOutputSchema>;

function buildReviewSystemPrompt(input: ReviewInput): string {
  const builder = createPromptBuilder();

  // Task and Issue ID XML tags for reuse across prompt
  builder.withXmlTag("task_id", input.taskDefinition.id);
  builder.withXmlTag("issue_id", input.taskDefinition.issueId);
  builder.withXmlTag("task_title", input.taskDefinition.title);
  builder.withXmlTag("task_complexity", input.taskDefinition.complexity);

  builder
    .withIdentity("You are the review pass evaluator for Looper tasks.")
    .withCapabilities([
      "Assess code quality, test execution, lint execution, and risk",
      "Identify flakiness signals and unresolved TODOs",
      "Fix any issues you find directly using tools before finalizing the verdict",
      "Summarize blocking vs non-blocking issues after fixes for reporting",
    ])
    .withConstraint(
      "must",
      "Return only the structured verdict defined in the Output Schema section"
    )
    .withConstraint("must", "Consider confirmation verdict flags when rating risk")
    .withConstraint(
      "must",
      "When you identify a blocking or non-blocking issue, apply the fix in this pass and re-check locally (tests/lint/typecheck) if relevant before returning the verdict"
    )
    .withConstraint(
      "must_not",
      "Recommend another execution pass or stop the looper because of review findings; the review pass must resolve issues itself"
    )
    .withConstraint("must_not", "Provide narrative prose outside the verdict structure");

  builder.withSection("Review Checks", buildReviewChecksSection(), "critical");
  builder.withOutput("JSON", reviewOutputSchema);

  return builder.buildSystemPrompt();
}

function buildReviewUserPrompt(input: ReviewInput): string {
  const { taskDefinition, issueContext, snapshot, confirmationVerdict } = input;

  const artifactsBlock = formatArtifacts(snapshot.artifacts);
  const messagesBlock = formatMessages(snapshot.lastMessages);
  const confirmationBlock = formatConfirmationVerdict(confirmationVerdict);

  return `# Task Definition
Title: <task_title>
Complexity: <task_complexity>
Issue ID: <issue_id>

## Task Specification Reference
File path: ${taskDefinition.filePath}
Use ${ARTIFACT_LIST_TOOL_NAME} to read acceptance criteria and task details from the task artifact.

## Issue Context
${formatIssueContext(issueContext)}

## First-Pass Summary
${snapshot.summary || "(no summary provided)"}

## Confirmation Verdict
${confirmationBlock}

## Execution Snapshot
Exit code: ${snapshot.exitCode}
Artifacts:
${artifactsBlock}

Last 10 messages:
${messagesBlock}

Provide the review verdict using ONLY the schema above.`;
}

export function buildReviewPrompt(input: ReviewInput): PromptComponents {
  const systemPrompt = buildReviewSystemPrompt(input);
  const userPrompt = buildReviewUserPrompt(input);

  return { systemPrompt, userPrompt };
}
