import type {
  BackendTask,
  ConfirmationInput,
  ConfirmationVerdict,
  ExecutionArtifacts,
  ExecutionSnapshot,
  SnapshotMessage,
  SnapshotRole,
} from "../task-confirmation/types";

// Re-export shared types for convenience
export type {
  BackendTask,
  ConfirmationInput,
  ExecutionArtifacts,
  ExecutionSnapshot,
  SnapshotMessage,
  SnapshotRole,
};

export interface ReviewVerdict {
  readonly status: "pass" | "fail" | "warn";
  readonly blockingIssues: string[];
  readonly nonBlockingIssues: string[];
  readonly testFindings: string[];
  readonly flakinessSignals: string[];
  readonly riskRating: "low" | "medium" | "high";
}

export interface ReviewInput extends ConfirmationInput {
  readonly confirmationVerdict: ConfirmationVerdict;
}
