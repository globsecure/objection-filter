import { defineProject } from "vitest/config";

export default defineProject({
  test: {
    name: "packages/prompts",
    environment: "node",
    include: ["src/**/*.{test,spec}.{ts,tsx}", "built-in/**/*.{test,spec}.{ts,tsx}"],
    exclude: ["**/node_modules/**"],
  },
});
