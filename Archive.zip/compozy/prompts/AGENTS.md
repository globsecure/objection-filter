# @compozy/prompts - Agent Guidelines

<critical>
- **MANDATORY**: This package is **generic** - it provides a builder API, NOT specific prompt templates
- **NEVER** add Compozy-specific prompt templates here - those belong in `packages/looper` or `packages/agents`
- **ALWAYS** maintain separation of concerns: `builder.ts` collects data, `formatter.ts` formats output
- **MUST** run `pnpm run lint`, `pnpm run typecheck`, and `pnpm run test` before completing any changes
- **NEVER** modify formatting logic in `builder.ts` - all formatting belongs in `formatter.ts`
- **ALWAYS** use `es-toolkit` instead of custom implementations or native methods (see `.cursor/rules/es-toolkit.mdc`)
- **ALWAYS** reference `.cursor/rules/typescript.mdc` for TypeScript best practices
</critical>

## Package Overview

`@compozy/prompts` is a **generic, framework-agnostic** prompt building library that provides:

- **Fluent Builder API**: Type-safe, composable prompt construction
- **Multiple Output Formats**: Markdown, Compact, and TOON (Token-Oriented Object Notation)
- **Structured Sections**: Identity, context, capabilities, tools, constraints, examples, tone
- **XML Tag Support**: Native support for custom XML tags (`<critical>`, `<prd>`, etc.)
- **Tool Documentation**: Built-in Zod schema to prompt text conversion
- **Composition**: Extend and merge builders for reusable prompt patterns

**Key Principle**: This package is a **builder library**, not a template library. Actual prompt templates should be created in consuming packages (`looper`, `agents`) using this builder.

## Architecture

### Core Components

```
src/
├── builder.ts      # PromptBuilder class - collects prompt data
├── formatter.ts    # Formatting logic - converts data to strings
├── types.ts        # TypeScript type definitions
├── sections/       # Section builder utilities
│   ├── critical.ts    # Critical section builder
│   ├── tools.ts       # Tool documentation builder
│   ├── schema.ts      # Zod schema to prompt text converter
│   └── index.ts       # Barrel exports
└── __tests__/     # Test files
```

### Separation of Concerns

- **`builder.ts`**: Collects prompt data (sections, capabilities, tools, constraints, examples, tone), provides fluent API methods. **DOES NOT** format output - delegates to `formatter.ts`.

- **`formatter.ts`**: Contains ALL formatting logic (`formatMarkdown()`, `formatCompact()`, `formatTOON()`). **DOES NOT** know about `PromptBuilder` internals.

### Design Patterns

1. **Fluent Interface**: All builder methods return `this` for method chaining
2. **Immutable Composition**: `extend()` creates new instances, never mutates original
3. **Data Separation**: Builder collects data, formatter renders it
4. **Type Safety**: Full TypeScript support with strict types

## Key APIs

### PromptBuilder

See `src/builder.ts` for complete API documentation. Core methods include:

- **Identity & Context**: `withIdentity()`, `withContext()`, `withSection()`, `withXmlTag()`, `withCriticalSection()`
- **Capabilities**: `withCapability()`, `withCapabilities()`
- **Tools**: `withTool()`, `withTools()`, `withToolIf()`
- **Constraints**: `withConstraint()`, `withConstraints()`, `withConstraintIf()`
- **Examples**: `withExample()`, `withExamples()`
- **Tone**: `withTone()`
- **Composition**: `extend()`, `merge()`
- **Output**: `build(format?)`
- **Introspection**: `hasIdentity()`, `hasTools()`, `getTools()`, `getConstraints()`, `getSummary()`

### Formatter

See `src/formatter.ts` for formatting implementation. Main entry point:

- `formatPrompt(data: PromptData, format: PromptFormat): string`

## Testing Guidelines

- **One test file per source file**: `builder.test.ts`, `formatter.test.ts`, `sections.test.ts`
- **Test all public methods**: Every public API method should have tests
- **Test edge cases**: Empty inputs, invalid inputs, boundary conditions
- **Test composition**: `extend()`, `merge()` behavior
- **Test formats**: All three formats (markdown, compact, toon)

See `__tests__/` directory for examples.

## Dependencies

### Core Dependencies

- **`es-toolkit`**: High-performance utility functions (`trim`, `compact`, `invariant`) - **MANDATORY USE**
- **`zod`**: Schema validation and type inference (v4+ with native `z.toJSONSchema()` method)
- **`@toon-format/toon`**: Official TOON library for encoding structured data

### Dependency Guidelines

- **MANDATORY**: **ALWAYS** use `es-toolkit` instead of custom implementations or native methods
- **Prefer `es-toolkit`** over native methods for ALL utility operations
- **Use `invariant`** from `es-toolkit/util` for runtime assertions
- **Use `trim`** from `es-toolkit/string` for string operations
- **Use `compact`** from `es-toolkit/array` for filtering empty values
- **Use `merge`/`mergeWith`** from `es-toolkit/object` for object merging
- **Use `head`**, `last`, `take`, `drop` from `es-toolkit/array` instead of array indexing
- **NEVER** implement custom utility functions that es-toolkit already provides

See `.cursor/rules/es-toolkit.mdc` for complete guidelines.

## Forbidden Practices

<critical>
- **NEVER** add Compozy-specific prompt templates to this package
- **NEVER** put formatting logic in `builder.ts` - it belongs in `formatter.ts`
- **NEVER** mutate builder state directly - use methods or `extend()`
- **NEVER** export private implementation details
- **NEVER** add framework-specific export methods (`toAiSdk()`, `toMastra()`) - those belong in consuming packages
- **NEVER** skip tests - all public APIs must be tested
- **NEVER** use `any` type - use `unknown` with type guards
- **NEVER** modify existing tests to make new code pass - fix the code instead
- **NEVER** use custom utility functions - always use `es-toolkit`
</critical>

## Common Tasks

### Adding a New Section Type

1. Add type to `PromptSection` union in `types.ts`
2. Add method to `PromptBuilder` in `builder.ts`
3. Update `formatMarkdown()` and `formatTOON()` in `formatter.ts`
4. Add tests in `builder.test.ts` and `formatter.test.ts`
5. Update `extend()` and `merge()` to handle new section type

### Adding a New Format

1. Add format type to `PromptFormat` union in `types.ts`
2. Implement formatter function in `formatter.ts` (e.g., `formatNewFormat()`)
3. Add case to `formatPrompt()` switch statement
4. Add tests in `formatter.test.ts`
5. Update documentation

### Adding a New Section Builder Utility

1. Create new file in `sections/` directory
2. Export function from `sections/index.ts`
3. Add tests in `sections.test.ts`
4. Document usage in README.md

## Integration Points

### Consuming Packages

This package is designed to be used by:

- **`packages/looper`**: Task execution prompts
- **`packages/agents`**: Agent system prompts

**Pattern**: Consuming packages should:

1. Import `createPromptBuilder` from `@compozy/prompts`
2. Create their own prompt template functions
3. Use the builder API to construct prompts
4. Export their templates for use in their respective domains

See `packages/looper/src/core/prompt-builder.ts` for integration examples.

## File-Specific Guidelines

### `builder.ts`

- **Purpose**: Collect prompt data, provide fluent API
- **DO**: Add methods for collecting data
- **DON'T**: Add formatting logic
- **DON'T**: Export private methods or fields

### `formatter.ts`

- **Purpose**: Convert `PromptData` to formatted strings
- **DO**: Keep formatters pure (no side effects)
- **DO**: Use `@toon-format/toon` for TOON encoding
- **DON'T**: Depend on `PromptBuilder` class
- **DON'T**: Mutate input data

### `sections/*.ts`

- **Purpose**: Utility functions for building specific section types
- **DO**: Keep functions focused and single-purpose
- **DO**: Export from `sections/index.ts`
- **DON'T**: Add dependencies on builder or formatter

### `types.ts`

- **Purpose**: Centralized type definitions
- **DO**: Export all public types
- **DO**: Use descriptive type names
- **DON'T**: Include implementation details in types

## Validation & Error Handling

### Runtime Validation

- Use `invariant()` from `es-toolkit/util` for assertions
- Validate inputs in builder methods (non-empty strings, valid types)
- Throw descriptive error messages

See `src/builder.ts` for examples.

### Type Safety

- Leverage TypeScript's type system for compile-time safety
- Use discriminated unions for section types
- Use generic types for tool schemas

See `.cursor/rules/typescript.mdc` for TypeScript best practices.

## Performance Considerations

- **`es-toolkit`**: Use for performance-critical operations
- **Immutable Operations**: `extend()` and `merge()` create new instances (acceptable for prompt building)
- **Lazy Evaluation**: Formatting only happens on `build()` call
- **TOON Encoding**: Uses official library for efficient encoding

## Documentation Standards

- **JSDoc Comments**: All public methods must have JSDoc
- **Type Exports**: Export all public types from `index.ts`
- **Examples**: Include usage examples in README.md
- **API Reference**: Keep COMPARISON.md updated when adding features

## Checklist for Changes

Before submitting changes:

- [ ] All tests pass (`pnpm test`)
- [ ] Type checking passes (`pnpm run typecheck`)
- [ ] Linting passes (`pnpm run lint`)
- [ ] No formatting logic in `builder.ts`
- [ ] All new public APIs have tests
- [ ] JSDoc comments added for new methods
- [ ] Types exported from `index.ts` if public
- [ ] README.md updated if API changed
- [ ] COMPARISON.md updated if adding PromptSmith features
- [ ] Using `es-toolkit` instead of custom utilities

## Additional Resources

- **Cursor Rules**:
  - `.cursor/rules/es-toolkit.mdc` (MANDATORY READ)
  - `.cursor/rules/typescript.mdc` (MANDATORY READ)
- **Zod Documentation**: https://zod.dev/
- **TOON Format**: https://github.com/toon-format/toon
