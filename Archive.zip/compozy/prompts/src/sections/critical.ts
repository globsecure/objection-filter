/**
 * Critical section builders
 * Builds structured critical sections with configurable sections
 */

import { trim } from "es-toolkit/string";
import { invariant } from "es-toolkit/util";
import type { CriticalSectionOptions } from "../types";

/**
 * Build a critical section with structured content
 */
export function buildCriticalSection(options: CriticalSectionOptions): string {
  invariant(options.sections.length > 0, "At least one section is required");

  const parts: string[] = [];

  // Process each section
  for (const section of options.sections) {
    if (section.items.length === 0) continue;

    let sectionContent: string;

    switch (section.format) {
      case "numbered":
        sectionContent = section.items
          .map((item, index) => {
            const parts = item.split(" → ");
            if (parts.length > 1) {
              return `${index + 1}. **${parts[0]}** → ${parts[1]}`;
            }
            return `${index + 1}. **${item}**`;
          })
          .join("\n");
        break;
      case "bulleted":
        sectionContent = section.items.map(item => `- ${item}`).join("\n");
        break;
      case "labeled":
        sectionContent = section.items
          .map(item => {
            const parts = item.split(": ");
            if (parts.length > 1) {
              return `- **${parts[0]}**: ${parts.slice(1).join(": ")}`;
            }
            return `- ${item}`;
          })
          .join("\n");
        break;
      default:
        sectionContent = section.items.join("\n");
    }

    parts.push(`**${section.title.toUpperCase()}**:\n${sectionContent}`);
  }

  // Optional Reminders - Consolidated to single concise statement
  if (options.reminders && options.reminders.length > 0) {
    // Consolidate reminders into a single concise statement
    parts.push(`⚠️ **OUTPUT MUST USE TOOLS ONLY. NO TEXT OUTPUT.**`);
  }

  // Optional Final Critical - Content only (no nested critical tags)
  if (options.finalCritical && options.finalCritical.length > 0) {
    const finalCritical = options.finalCritical
      .map(item => {
        const parts = item.split(": ");
        if (parts.length > 1) {
          return `- **${parts[0]}**: ${parts.slice(1).join(": ")}`;
        }
        return `- **${item}**`;
      })
      .join("\n");

    if (options.enforcementText) {
      parts.push(`${finalCritical}\n\n**Enforcement:** ${options.enforcementText}`);
    } else {
      parts.push(finalCritical);
    }
  }

  const content = parts.join("\n\n");
  return trim(`<critical>\n${content}\n</critical>`);
}
