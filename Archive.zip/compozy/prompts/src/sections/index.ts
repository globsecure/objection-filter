/**
 * Section builders - Reusable components for building prompt sections
 */

export { buildCriticalSection } from "./critical";
export {
  buildToolDocumentation,
  buildToolDocumentationContent,
  withToolDocumentation,
  withToolDocumentationWithSchema,
  type ToolDocumentationWithSchemaOptions,
} from "./tools";
export { zodSchemaToPromptText } from "./schema";
export {
  createTemplateBuilder,
  composeSections,
  conditionalSection,
  createSectionBuilder,
  createXmlTagBuilder,
  createCriticalSectionBuilder,
  createConstraintsBuilder,
  createIdentityBuilder,
  createCapabilitiesBuilder,
  createCriticalRequirementsBuilder,
  createResearchSectionBuilder,
  createContextSectionsBuilder,
  createToolDocBuilder,
  type SectionBuilder,
  type TemplateConfig,
  type TemplateBuilderDefinition,
  type CriticalRequirementsConfig,
  type ResearchSectionConfig,
  type ContextSectionConfig,
  type ToolDocConfig,
} from "./template-builder";
