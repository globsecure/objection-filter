/**
 * Schema helpers - Convert Zod schemas to prompt-friendly text
 * Extracted from agents package implementation
 */

import { z } from "zod";

/**
 * Converts a Zod schema to a JSON Schema string formatted for use in prompts.
 * Uses Zod 4's native toJSONSchema() method.
 */
function zodSchemaToJsonSchemaString(schema: z.ZodTypeAny, _schemaName?: string): string {
  const jsonSchema = z.toJSONSchema(schema);
  return JSON.stringify(jsonSchema, null, 2);
}

/**
 * Formats a JSON Schema object into readable prompt text.
 * Extracts key information like properties, types, descriptions, and constraints.
 * @internal Exported for testing purposes
 */
export function formatSchemaForPrompt(jsonSchema: string | object): string {
  const schema = typeof jsonSchema === "string" ? JSON.parse(jsonSchema) : jsonSchema;

  // Handle $ref schemas (definitions) - resolve the reference
  if (
    typeof schema === "object" &&
    schema !== null &&
    "$ref" in schema &&
    typeof schema.$ref === "string"
  ) {
    const refPath = schema.$ref.replace("#/definitions/", "");
    if (
      "definitions" in schema &&
      typeof schema.definitions === "object" &&
      schema.definitions !== null &&
      refPath in schema.definitions
    ) {
      return formatSchemaForPrompt(
        schema.definitions[refPath as keyof typeof schema.definitions] as string | object
      );
    }
  }

  // Handle definitions at root level - check if we have a $ref pointing to definitions
  // If so, resolve it; otherwise check if we have inline object properties
  if (
    typeof schema === "object" &&
    schema !== null &&
    "definitions" in schema &&
    typeof schema.definitions === "object" &&
    schema.definitions !== null
  ) {
    // If root has $ref, resolve it
    if ("$ref" in schema && typeof schema.$ref === "string") {
      const refPath = schema.$ref.replace("#/definitions/", "");
      if (refPath in schema.definitions) {
        return formatSchemaForPrompt(
          schema.definitions[refPath as keyof typeof schema.definitions] as string | object
        );
      }
    }
    // If no $ref but we have definitions, try to find the main schema
    // Only do this if the root schema doesn't have properties itself
    if (!("type" in schema && schema.type === "object" && "properties" in schema)) {
      const mainSchema = Object.values(schema.definitions)[0];
      if (mainSchema) {
        return formatSchemaForPrompt(mainSchema as string | object);
      }
    }
  }

  // Format object schema with properties
  if (
    typeof schema === "object" &&
    schema !== null &&
    "type" in schema &&
    schema.type === "object" &&
    "properties" in schema &&
    typeof schema.properties === "object" &&
    schema.properties !== null
  ) {
    const lines: string[] = [];
    const required = "required" in schema && Array.isArray(schema.required) ? schema.required : [];

    for (const [key, value] of Object.entries(schema.properties)) {
      const prop = value as Record<string, unknown>;
      const isRequired = required.includes(key);
      const requiredMark = isRequired ? " (required)" : " (optional)";

      let propDescription = `- \`${key}\`${requiredMark}: `;

      // Add type information
      if (Array.isArray(prop.type)) {
        propDescription += `Union of ${prop.type.join(" | ")}`;
      } else if (prop.type) {
        propDescription += String(prop.type);
      }

      // Add format if present
      if (prop.format) {
        propDescription += ` (format: ${prop.format})`;
      }

      // Add enum if present
      if (Array.isArray(prop.enum)) {
        propDescription += ` - One of: ${prop.enum.map(e => `"${String(e)}"`).join(", ")}`;
      }

      // Add array item type if array
      if (prop.type === "array" && prop.items) {
        const items = prop.items as Record<string, unknown>;
        if (items.type) {
          propDescription += ` - Array of ${String(items.type)}`;
        } else if (Array.isArray(items.enum)) {
          const enumValues = items.enum.map(e => `"${String(e)}"`).join(", ");
          propDescription += ` - Array of enum values: ${enumValues}`;
        }
      }

      // Add constraints
      if (typeof prop.minLength === "number") {
        propDescription += ` (min length: ${prop.minLength})`;
      }
      if (typeof prop.maxLength === "number") {
        propDescription += ` (max length: ${prop.maxLength})`;
      }
      if (typeof prop.minimum === "number") {
        propDescription += ` (min: ${prop.minimum})`;
      }
      if (typeof prop.maximum === "number") {
        propDescription += ` (max: ${prop.maximum})`;
      }
      if (typeof prop.minItems === "number") {
        propDescription += ` (min items: ${prop.minItems})`;
      }
      if (typeof prop.maxItems === "number") {
        propDescription += ` (max items: ${prop.maxItems})`;
      }

      // Add description
      if (typeof prop.description === "string") {
        propDescription += ` - ${prop.description}`;
      }

      lines.push(propDescription);
    }

    return lines.join("\n");
  }

  // Fallback: return stringified schema
  return JSON.stringify(schema, null, 2);
}

/**
 * Converts a Zod schema to formatted prompt text.
 * This is a convenience function that combines zodSchemaToJsonSchemaString and formatSchemaForPrompt.
 */
export function zodSchemaToPromptText(schema: z.ZodTypeAny, _schemaName?: string): string {
  const jsonSchemaString = zodSchemaToJsonSchemaString(schema, _schemaName);
  return formatSchemaForPrompt(jsonSchemaString);
}
