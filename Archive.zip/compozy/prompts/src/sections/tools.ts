/**
 * Tool documentation builders
 * Builds documentation sections for tools with schemas
 */

import { trim } from "es-toolkit/string";
import { invariant } from "es-toolkit/util";
import type { PromptBuilder } from "../builder";
import type { ToolDocumentationOptions } from "../types";
import { zodSchemaToPromptText } from "./schema";

/**
 * Build tool documentation section
 */
export function buildToolDocumentation(options: ToolDocumentationOptions): string {
  invariant(options.toolName.length > 0, "Tool name cannot be empty");
  invariant(options.description.length > 0, "Tool description cannot be empty");

  const parts: string[] = [];

  parts.push(`#### ${options.toolName} Tool`);

  if (options.description) {
    parts.push(`- **Purpose**: ${options.description}`);
  }

  if (options.whenToCall) {
    parts.push(`- **When to call**: ${options.whenToCall}`);
  }

  if (options.behavior) {
    parts.push(`- **Behavior**: ${options.behavior}`);
  }

  // Schema documentation
  if (options.schema) {
    const schemaDoc = zodSchemaToPromptText(options.schema, `${options.toolName}Input`);
    parts.push(`- **Schema**:\n${schemaDoc}`);
  }

  return trim(parts.join("\n"));
}

/**
 * Builder-integrated helper for adding tool documentation section
 * Returns the builder for chaining
 */
export function withToolDocumentation(
  builder: PromptBuilder,
  options: ToolDocumentationOptions,
  priority?: "critical" | "high" | "medium" | "low"
): PromptBuilder {
  const documentation = buildToolDocumentation(options);
  return builder.withSection(`Using ${options.toolName} Tool`, documentation, priority);
}

/**
 * Extended options for tool documentation with string schema doc
 */
export interface ToolDocumentationWithSchemaOptions extends Omit<
  ToolDocumentationOptions,
  "schema"
> {
  schemaDoc: string;
  followUpMessages?: string;
}

/**
 * Build tool documentation content string (without adding to builder)
 * Useful when you need to combine multiple tool docs or prepend content
 */
export function buildToolDocumentationContent(options: ToolDocumentationWithSchemaOptions): string {
  const { followUpMessages, ...baseOptions } = options;
  const toolDoc = buildToolDocumentation(baseOptions);

  const followUp = followUpMessages ? `\n\n${followUpMessages}` : "";

  return `${toolDoc}

### Schema

The ${options.toolName} tool accepts the following schema:

${options.schemaDoc}${followUp}`;
}

/**
 * Builder-integrated helper for adding tool documentation with string schema doc
 * Returns the builder for chaining
 */
export function withToolDocumentationWithSchema(
  builder: PromptBuilder,
  options: ToolDocumentationWithSchemaOptions,
  priority?: "critical" | "high" | "medium" | "low"
): PromptBuilder {
  const fullDocumentation = buildToolDocumentationContent(options);
  return builder.withSection(`Using ${options.toolName} Tool`, fullDocumentation, priority);
}
