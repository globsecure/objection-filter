/**
 * Template Builder System
 * Functional, generic builder factory pattern for creating composable prompt templates
 *
 * Provides type-safe, composable way to build prompts using functional composition
 * and TypeScript generics. Enables elimination of code duplication across built-in prompts.
 */

import { createPromptBuilder, type PromptBuilder } from "../builder";
import { buildCriticalSection } from "./critical";
import type { SectionPriority, ConstraintType } from "../types";

/**
 * Generic section builder function type
 * Takes a builder and config, returns an updated builder
 */
export type SectionBuilder<TConfig = void, TContext = void> = (
  builder: PromptBuilder,
  config: TConfig,
  context?: TContext
) => PromptBuilder;

/**
 * Template configuration combining base and variant configs
 */
export interface TemplateConfig<TBase, TVariant> {
  base: TBase;
  variant: TVariant;
}

/**
 * Template builder definition
 * Defines how to build sections for a specific prompt template
 */
export interface TemplateBuilderDefinition<TBaseConfig, TVariantConfig, TContext = void> {
  /** Name of the template */
  name: string;
  /** Builders for each section, executed in order */
  sections: Array<SectionBuilder<TemplateConfig<TBaseConfig, TVariantConfig>, TContext>>;
  /** Optional priority for sections */
  defaultPriority?: SectionPriority;
}

/**
 * Creates a template builder factory
 * Returns a function that builds prompts using the template definition
 */
export function createTemplateBuilder<TBaseConfig, TVariantConfig, TContext = void>(
  definition: TemplateBuilderDefinition<TBaseConfig, TVariantConfig, TContext>
) {
  return (
    baseConfig: TBaseConfig,
    variantConfig: TVariantConfig,
    context?: TContext
  ): PromptBuilder => {
    const builder = createPromptBuilder();
    const config: TemplateConfig<TBaseConfig, TVariantConfig> = {
      base: baseConfig,
      variant: variantConfig,
    };

    // Apply all section builders in sequence
    const finalBuilder = definition.sections.reduce(
      (acc, sectionBuilder) => sectionBuilder(acc, config, context),
      builder
    );

    return finalBuilder;
  };
}

/**
 * Helper to compose multiple section builders
 */
export function composeSections<TConfig, TContext = void>(
  ...builders: Array<SectionBuilder<TConfig, TContext>>
): SectionBuilder<TConfig, TContext> {
  return (builder, config, context) => {
    return builders.reduce((acc, sectionBuilder) => sectionBuilder(acc, config, context), builder);
  };
}

/**
 * Helper to conditionally apply a section builder
 */
export function conditionalSection<TConfig, TContext = void>(
  predicate: (config: TConfig, context?: TContext) => boolean,
  sectionBuilder: SectionBuilder<TConfig, TContext>
): SectionBuilder<TConfig, TContext> {
  return (builder, config, context) => {
    return predicate(config, context) ? sectionBuilder(builder, config, context) : builder;
  };
}

/**
 * Helper to create a simple section builder
 */
export function createSectionBuilder<TConfig, TContext = void>(
  fn: (
    config: TConfig,
    context?: TContext
  ) => {
    title: string;
    content: string;
    priority?: SectionPriority;
  }
): SectionBuilder<TConfig, TContext> {
  return (builder, config, context) => {
    const section = fn(config, context);
    return builder.withSection(section.title, section.content, section.priority);
  };
}

/**
 * Helper to create an XML tag section builder
 */
export function createXmlTagBuilder<TConfig, TContext = void>(
  tag: string,
  fn: (config: TConfig, context?: TContext) => string
): SectionBuilder<TConfig, TContext> {
  return (builder, config, context) => {
    return builder.withXmlTag(tag, fn(config, context));
  };
}

/**
 * Helper to create a critical section builder
 */
export function createCriticalSectionBuilder<TConfig, TContext = void>(
  fn: (config: TConfig, context?: TContext) => Parameters<typeof buildCriticalSection>[0]
): SectionBuilder<TConfig, TContext> {
  return (builder, config, context) => {
    const criticalOptions = fn(config, context);
    const content = buildCriticalSection(criticalOptions);
    return builder.withSection("Critical Requirements", content, "critical");
  };
}

/**
 * Helper to create a constraints builder
 */
export function createConstraintsBuilder<TConfig, TContext = void>(
  fn: (config: TConfig, context?: TContext) => Array<{ type: ConstraintType; rule: string }>
): SectionBuilder<TConfig, TContext> {
  return (builder, config, context) => {
    const constraints = fn(config, context);
    return builder.withConstraints(constraints);
  };
}

/**
 * Helper to create an identity builder
 */
export function createIdentityBuilder<TConfig, TContext = void>(
  fn: (config: TConfig, context?: TContext) => string
): SectionBuilder<TConfig, TContext> {
  return (builder, config, context) => builder.withIdentity(fn(config, context));
}

/**
 * Helper to create a capabilities builder
 */
export function createCapabilitiesBuilder<TConfig, TContext = void>(
  fn: (config: TConfig, context?: TContext) => string[]
): SectionBuilder<TConfig, TContext> {
  return (builder, config, context) => builder.withCapabilities(fn(config, context));
}

/**
 * Pattern: Critical Requirements Builder Factory
 * Handles the pattern used in prd/critical.ts, techspec/critical.ts, tasks/critical.ts
 */
export interface CriticalRequirementsConfig<
  TToolNames extends { [K in keyof TToolNames]: string } = Record<string, string>,
> {
  toolNames: TToolNames;
  mandatoryBehavior: string[];
  failureConditions: string[];
  requirements: string[];
  finalCritical?: string[];
  constraints: Array<{ type: ConstraintType; rule: string }>;
}

/**
 * Creates a critical requirements builder factory
 * Accepts a config with toolNames and a function that builds the full config
 */
export function createCriticalRequirementsBuilder<
  TToolNames extends { [K in keyof TToolNames]: string },
>(
  configFn: (toolNames: TToolNames) => CriticalRequirementsConfig<TToolNames>
): SectionBuilder<{ toolNames: TToolNames }> {
  return composeSections(
    createConstraintsBuilder(config => configFn(config.toolNames).constraints),
    createCriticalSectionBuilder(config => {
      const cfg = configFn(config.toolNames);
      const result: Parameters<typeof buildCriticalSection>[0] = {
        sections: [
          {
            title: "MANDATORY BEHAVIOR",
            format: "numbered",
            items: cfg.mandatoryBehavior,
          },
          {
            title: "FAILURE CONDITIONS",
            format: "bulleted",
            items: cfg.failureConditions,
          },
          {
            title: "REQUIREMENTS",
            format: "bulleted",
            items: cfg.requirements,
          },
        ],
        enforcementText: "Violating these standards results in immediate task rejection.",
      };
      if (cfg.finalCritical) {
        result.finalCritical = cfg.finalCritical;
      }
      return result;
    })
  );
}

/**
 * Pattern: Research Section Builder Factory
 * Handles WebSearch research sections (duplicated across factories)
 */
export interface ResearchSectionConfig {
  minSearches: number;
  maxSearches: number;
  researchTopics: string[];
  searchExamples: string[];
  forbiddenTopics?: string[];
  focusType: "business" | "technical" | "general";
}

/**
 * Creates a research section builder factory
 */
export function createResearchSectionBuilder<TConfig extends ResearchSectionConfig>(
  configFn: (config: TConfig) => ResearchSectionConfig
): SectionBuilder<TConfig> {
  return createSectionBuilder(config => {
    const cfg = configFn(config);
    const forbiddenSection = cfg.forbiddenTopics
      ? `\n- ⚠️ **FORBIDDEN RESEARCH TOPICS**: ${cfg.forbiddenTopics.join(", ")}`
      : "";

    const focusNote =
      cfg.focusType === "business"
        ? "\n- ⚠️ **BUSINESS FOCUS ONLY**: Research should focus EXCLUSIVELY on product, market, and business topics—NOT technical implementation"
        : cfg.focusType === "technical"
          ? "\n- ⚠️ **TECHNICAL FOCUS**: Research should focus on implementation patterns, best practices, and technical solutions"
          : "";

    const focusLabel =
      cfg.focusType === "business"
        ? "product, market, and business"
        : cfg.focusType === "technical"
          ? "technical"
          : "";

    const researchContext =
      cfg.focusType === "business"
        ? "product/market topics relevant to the task and findings from codebase exploration"
        : "technical topics relevant to the PRD and findings from codebase exploration";

    const researchNote =
      cfg.focusType === "business"
        ? "current market trends, user behavior patterns, or business best practices"
        : "current best practices, library versions, or recent patterns";

    const incorporateNote =
      cfg.focusType === "business" ? "PRD product decisions" : "Tech Spec technical decisions";

    return {
      title: "WebSearch Research Tool",
      content: `You have access to the WebSearch tool for gathering current ${focusLabel} information.

**When to use WebSearch**:
- **MANDATORY**: After exploration, use WebSearch ${cfg.minSearches}-${cfg.maxSearches} times to research ${researchContext}
${cfg.researchTopics.map(topic => `- **${topic}**`).join("\n")}

**Research Strategy**:
1. **Multiple searches**: Use ${cfg.minSearches}-${cfg.maxSearches} different queries with varying angles to get comprehensive coverage
   - Example: ${cfg.searchExamples.join("\n     * ")}
2. **Extract key findings**: Identify 3-5 most authoritative sources from WebSearch results
3. **Cite sources**: Include URLs and key ${cfg.focusType === "business" ? "business/product" : "technical"} insights
4. **Incorporate findings**: Use research to inform ${incorporateNote}

**CRITICAL RULES**:
- ⚠️ **NEVER rely solely on training knowledge** for ${researchNote}
- ⚠️ **ALWAYS use WebSearch** when ${cfg.focusType === "business" ? "product/market" : "technical"} information needs to be current or authoritative
- ⚠️ **Use multiple searches** (${cfg.minSearches}-${cfg.maxSearches}) with different queries${forbiddenSection}${focusNote}
- ✅ **Extract only critical information**—focus on actionable ${cfg.focusType === "business" ? "product" : "technical"} insights
- ✅ **Incorporate findings** directly into ${incorporateNote}
- ✅ **Cite authoritative sources** when referencing external research`,
      priority: "high",
    };
  });
}

/**
 * Pattern: Context Section Builder Factory
 * Handles PRD/TechSpec context sections (duplicated)
 */
export interface ContextSectionConfig {
  prdPath?: string;
  techspecPath?: string;
}

/**
 * Creates context sections builder
 */
export function createContextSectionsBuilder<
  TConfig extends ContextSectionConfig,
>(): SectionBuilder<TConfig> {
  return composeSections(
    conditionalSection(
      config => !!config.prdPath,
      createXmlTagBuilder(
        "prd",
        config =>
          `## Product Requirements Document (PRD)
File path: ${config.prdPath}
Use the artifact search tool to read relevant sections from this file when needed.`
      )
    ),
    conditionalSection(
      config => !!config.techspecPath,
      createXmlTagBuilder(
        "techspec",
        config =>
          `## Technical Specification (Tech Spec)
File path: ${config.techspecPath}
Use the artifact search tool to read relevant sections from this file when needed.`
      )
    )
  );
}

/**
 * Pattern: Tool Documentation Builder Factory
 * Generic tool documentation builder
 */
export interface ToolDocConfig {
  toolName: string;
  description: string;
  whenToCall: string;
  behavior: string;
  schemaDoc: string;
  followUpMessages?: string;
}

/**
 * Creates a tool documentation builder factory
 */
export function createToolDocBuilder<TConfig extends ToolDocConfig>(
  configFn: (config: TConfig) => ToolDocConfig
): SectionBuilder<TConfig> {
  return createSectionBuilder(config => {
    const cfg = configFn(config);
    const followUp = cfg.followUpMessages ? `\n\n${cfg.followUpMessages}` : "";
    return {
      title: `Using ${cfg.toolName} Tool`,
      content: `After completing the ${cfg.toolName.toLowerCase()}, you MUST call the ${cfg.toolName} tool. This is the ONLY way to present the output.
**FORBIDDEN**: Do NOT output as markdown text or plain text. Tool calling is MANDATORY.

### ${cfg.toolName} Tool Schema

The ${cfg.toolName} tool accepts the following schema:

${cfg.schemaDoc}${followUp}`,
      priority: "high",
    };
  });
}
