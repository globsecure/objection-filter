/**
 * PromptFormatter - Handles formatting prompts in different output formats
 *
 * Separated from PromptBuilder to keep concerns separated and improve maintainability.
 */

import { encode } from "@toon-format/toon";
import { compact } from "es-toolkit/array";
import { z } from "zod";
import { zodSchemaToPromptText } from "./sections/schema";
import { buildToolDocumentation } from "./sections/tools";
import type {
  AgentDefinition,
  Constraint,
  ConstraintType,
  Example,
  PromptFormat,
  PromptSection,
  ToolDefinition,
} from "./types";
import { indentXmlContent } from "./utils/xml-indent";

/**
 * Regex patterns for TOON format parsing (for converting markdown parameter docs)
 */
const TOON_PARAM_REGEX = /^-\s+`([^`]+)`\s+\(([^)]+)\):\s+(.+)$/;
const TOON_DASH_PREFIX_REGEX = /^-\s+/;
const TOON_BACKTICK_REGEX = /`/g;

/**
 * Data structure passed to formatters
 */
export interface PromptData {
  sections: readonly PromptSection[];
  capabilities: readonly string[];
  tools: readonly ToolDefinition[];
  agents: readonly AgentDefinition[];
  constraints: readonly Constraint[];
  examples: readonly Example[];
  tone: string;
}

/**
 * Formats prompt data in the specified format
 */
export function formatPrompt(data: PromptData, format: PromptFormat): string {
  switch (format) {
    case "toon":
      return formatTOON(data);
    case "compact":
      return formatCompact(data);
    case "markdown":
    default:
      return formatMarkdown(data);
  }
}

/**
 * Formats system prompt (identity, tools, constraints, tone, capabilities).
 * Excludes user-facing context and examples.
 */
export function formatSystemPrompt(data: PromptData, format: PromptFormat = "markdown"): string {
  const systemData: PromptData = {
    sections: data.sections.filter(
      s =>
        s.type === "identity" ||
        s.type === "section" ||
        s.type === "xml-tag" ||
        s.type === "thinking"
    ),
    capabilities: data.capabilities,
    tools: data.tools,
    agents: data.agents,
    constraints: data.constraints,
    examples: [], // Examples typically go in user context
    tone: data.tone,
  };

  return formatPrompt(systemData, format);
}

/**
 * Formats user context (context sections, examples).
 * Excludes system-level instructions.
 */
export function formatUserContext(data: PromptData, format: PromptFormat = "markdown"): string {
  const userData: PromptData = {
    sections: data.sections.filter(s => s.type === "context"),
    capabilities: [],
    tools: [],
    agents: [],
    constraints: [],
    examples: data.examples,
    tone: "",
  };

  return formatPrompt(userData, format);
}

/**
 * Formats prompt in standard markdown format (default).
 */
function formatMarkdown(data: PromptData): string {
  const parts: string[] = [];

  // Add sections in order
  for (const section of data.sections) {
    switch (section.type) {
      case "identity":
        parts.push(section.content);
        break;

      case "context":
        parts.push(section.content);
        break;

      case "section":
        parts.push(section.title ? `## ${section.title}\n\n${section.content}` : section.content);
        break;

      case "xml-tag":
        parts.push(`<${section.tag}>\n${indentXmlContent(section.content, 2)}\n</${section.tag}>`);
        break;

      case "thinking":
        parts.push(`<thinking>\n${section.content}\n</thinking>`);
        break;

      default:
        if (section.content) {
          parts.push(section.content);
        }
    }
  }

  // Add capabilities if present
  if (data.capabilities.length > 0) {
    const capabilitiesList = data.capabilities
      .map((cap, index) => `${index + 1}. ${cap}`)
      .join("\n");
    parts.push(`## Capabilities\n\n${capabilitiesList}`);
  }

  // Add tools if present
  if (data.tools.length > 0) {
    const toolDocs = data.tools.map(tool =>
      buildToolDocumentation({
        toolName: tool.name,
        description: tool.description,
        schema: tool.schema,
      })
    );
    parts.push(`## Available Tools\n\n${toolDocs.join("\n\n")}`);
  }

  // Add agents if present
  if (data.agents.length > 0) {
    const agentDocs = data.agents.map(agent => {
      const parts: string[] = [];
      parts.push(`- **${agent.name}**: ${agent.purpose}`);
      parts.push(`  - **Use when**: ${agent.useWhen}`);
      if (agent.capabilities.length > 0) {
        parts.push(`  - **Capabilities**: ${agent.capabilities.join(", ")}`);
      }
      if (agent.exampleUsage) {
        parts.push(`  - **Example usage**: ${agent.exampleUsage}`);
      }
      if (agent.bestFor) {
        parts.push(`  - **Best for**: ${agent.bestFor}`);
      }
      return parts.join("\n");
    });
    parts.push(`### Subagents (Available via @subagent_name syntax)\n\n${agentDocs.join("\n\n")}`);
  }

  // Add constraints if present
  if (data.constraints.length > 0) {
    const constraintsByType: Record<ConstraintType, string[]> = {
      must: [],
      must_not: [],
      should: [],
      should_not: [],
    };

    for (const constraint of data.constraints) {
      constraintsByType[constraint.type].push(constraint.rule);
    }

    const constraintParts: string[] = [];
    if (constraintsByType.must.length > 0) {
      constraintParts.push(`**Must:**\n${constraintsByType.must.map(r => `- ${r}`).join("\n")}`);
    }
    if (constraintsByType.must_not.length > 0) {
      constraintParts.push(
        `**Must Not:**\n${constraintsByType.must_not.map(r => `- ${r}`).join("\n")}`
      );
    }
    if (constraintsByType.should.length > 0) {
      constraintParts.push(
        `**Should:**\n${constraintsByType.should.map(r => `- ${r}`).join("\n")}`
      );
    }
    if (constraintsByType.should_not.length > 0) {
      constraintParts.push(
        `**Should Not:**\n${constraintsByType.should_not.map(r => `- ${r}`).join("\n")}`
      );
    }

    if (constraintParts.length > 0) {
      parts.push(`## Constraints\n\n${constraintParts.join("\n\n")}`);
    }
  }

  // Add examples if present
  if (data.examples.length > 0) {
    const exampleParts = data.examples.map((example, index) => {
      const parts: string[] = [];
      if (example.user && example.assistant) {
        parts.push(`**User:** ${example.user}`);
        parts.push(`**Assistant:** ${example.assistant}`);
      } else if (example.input && example.output) {
        parts.push(`**Input:** ${example.input}`);
        parts.push(`**Output:** ${example.output}`);
      }
      if (example.explanation) {
        parts.push(`*${example.explanation}*`);
      }
      return `### Example ${index + 1}\n\n${parts.join("\n")}`;
    });
    parts.push(`## Examples\n\n${exampleParts.join("\n\n")}`);
  }

  // Add tone if present
  if (data.tone) {
    parts.push(`## Tone\n\n${data.tone}`);
  }

  // Filter out empty parts and join with double newlines
  const nonEmptyParts = parts.filter((part: string) => part.length > 0);
  return compact(nonEmptyParts).join("\n\n");
}

/**
 * Formats prompt in compact markdown format.
 * Removes excessive whitespace while maintaining markdown structure.
 */
function formatCompact(data: PromptData): string {
  const markdown = formatMarkdown(data);
  // Remove triple+ newlines, reduce to double
  return markdown.replace(/\n{3,}/g, "\n\n").trim();
}

/**
 * Formats prompt in TOON (Token-Oriented Object Notation) format.
 * Uses the official @toon-format/toon library for structured data encoding.
 */
function formatTOON(data: PromptData): string {
  const lines: string[] = [];

  // Identity section
  const identitySection = data.sections.find(s => s.type === "identity");
  if (identitySection) {
    lines.push("Identity:");
    lines.push(`  ${identitySection.content}`);
    lines.push("");
  }

  // Context section
  const contextSection = data.sections.find(s => s.type === "context");
  if (contextSection) {
    lines.push("Context:");
    const contextLines = contextSection.content.split("\n");
    for (const line of contextLines) {
      lines.push(`  ${line}`);
    }
    lines.push("");
  }

  // Capabilities section - use TOON library for array encoding
  if (data.capabilities.length > 0) {
    const capabilitiesData = { capabilities: data.capabilities };
    const toonCapabilities = encode(capabilitiesData, { indent: 2 });
    lines.push(toonCapabilities);
    lines.push("");
  }

  // Tools section
  if (data.tools.length > 0) {
    lines.push(`Tools[${data.tools.length}]:`);
    for (const tool of data.tools) {
      lines.push(`  ${tool.name}:`);
      lines.push(`    ${tool.description}`);
      const params = parseZodSchemaToTOON(tool.schema);
      if (params) {
        lines.push("    Parameters:");
        const paramLines = params.split("\n");
        for (const line of paramLines) {
          lines.push(`      ${line}`);
        }
      }
    }
    lines.push("");
  }

  // Agents section - use TOON library for structured agents
  if (data.agents.length > 0) {
    const agentsData = {
      agents: data.agents.map(agent => ({
        name: agent.name,
        purpose: agent.purpose,
        useWhen: agent.useWhen,
        capabilities: agent.capabilities,
        ...(agent.exampleUsage ? { exampleUsage: agent.exampleUsage } : {}),
        ...(agent.bestFor ? { bestFor: agent.bestFor } : {}),
      })),
    };
    const toonAgents = encode(agentsData, { indent: 2 });
    lines.push(toonAgents);
    lines.push("");
  }

  // Examples section - use TOON library for structured examples
  if (data.examples.length > 0) {
    // Check if all examples have the same structure for tabular format
    const allHaveSameStructure =
      data.examples.length > 1 &&
      data.examples.every(
        ex =>
          (ex.user !== undefined) === (data.examples[0]?.user !== undefined) &&
          (ex.assistant !== undefined) === (data.examples[0]?.assistant !== undefined) &&
          (ex.explanation !== undefined) === (data.examples[0]?.explanation !== undefined) &&
          (ex.input !== undefined) === (data.examples[0]?.input !== undefined) &&
          (ex.output !== undefined) === (data.examples[0]?.output !== undefined)
      );

    if (allHaveSameStructure && data.examples.length > 1) {
      const first = data.examples[0];
      if (first) {
        // Use TOON library for tabular encoding
        const examplesData = {
          examples: data.examples.map(ex => ({
            ...(ex.user !== undefined ? { user: ex.user } : {}),
            ...(ex.assistant !== undefined ? { assistant: ex.assistant } : {}),
            ...(ex.input !== undefined ? { input: ex.input } : {}),
            ...(ex.output !== undefined ? { output: ex.output } : {}),
            ...(ex.explanation !== undefined ? { explanation: ex.explanation } : {}),
          })),
        };
        const toonExamples = encode(examplesData, { indent: 2 });
        lines.push(toonExamples);
      }
    } else {
      // Standard format for single example or varying structures
      lines.push(`Examples[${data.examples.length}]:`);
      for (const [index, example] of data.examples.entries()) {
        lines.push(`  Example ${index + 1}:`);

        const inputLabel = example.user ? "User" : "Input";
        const outputLabel = example.assistant ? "Assistant" : "Output";
        const inputText = example.user || example.input;
        const outputText = example.assistant || example.output;

        if (inputText) {
          lines.push(`    ${inputLabel}: ${inputText}`);
        }
        if (outputText) {
          lines.push(`    ${outputLabel}: ${outputText}`);
        }
        if (example.explanation) {
          lines.push(`    Explanation: ${example.explanation}`);
        }
      }
    }
    lines.push("");
  }

  // Constraints section - use TOON library for structured constraints
  if (data.constraints.length > 0) {
    const constraintsByType = {
      must: data.constraints.filter(c => c.type === "must").map(c => c.rule),
      must_not: data.constraints.filter(c => c.type === "must_not").map(c => c.rule),
      should: data.constraints.filter(c => c.type === "should").map(c => c.rule),
      should_not: data.constraints.filter(c => c.type === "should_not").map(c => c.rule),
    };

    const constraintsData: Record<string, string[]> = {};
    if (constraintsByType.must.length > 0) constraintsData.must = constraintsByType.must;
    if (constraintsByType.must_not.length > 0)
      constraintsData.must_not = constraintsByType.must_not;
    if (constraintsByType.should.length > 0) constraintsData.should = constraintsByType.should;
    if (constraintsByType.should_not.length > 0)
      constraintsData.should_not = constraintsByType.should_not;

    const toonConstraints = encode({ constraints: constraintsData }, { indent: 2 });
    lines.push(toonConstraints);
    lines.push("");
  }

  // Tone section
  if (data.tone) {
    lines.push("Tone:");
    const toneLines = data.tone.split("\n");
    for (const line of toneLines) {
      lines.push(`  ${line}`);
    }
    lines.push("");
  }

  // XML tag sections and thinking blocks
  for (const section of data.sections) {
    if (section.type === "xml-tag") {
      lines.push(`<${section.tag}>`);
      const indentedContent = indentXmlContent(section.content, 2);
      const contentLines = indentedContent.split("\n");
      for (const line of contentLines) {
        lines.push(line);
      }
      lines.push(`</${section.tag}>`);
      lines.push("");
    } else if (section.type === "thinking") {
      lines.push("<thinking>");
      const contentLines = section.content.split("\n");
      for (const line of contentLines) {
        lines.push(`  ${line}`);
      }
      lines.push("</thinking>");
      lines.push("");
    } else if (section.type === "section") {
      lines.push(`${section.title || "Section"}:`);
      const contentLines = section.content.split("\n");
      for (const line of contentLines) {
        lines.push(`  ${line}`);
      }
      lines.push("");
    }
  }

  return lines.join("\n").trim();
}

/**
 * Parses a Zod schema and converts it to TOON format parameter documentation.
 * Converts from markdown format: `- \`name\` (type, required): description`
 * To TOON format: `name(type,req): description`
 */
function parseZodSchemaToTOON(schema: z.ZodTypeAny): string {
  const markdown = zodSchemaToPromptText(schema);

  // Convert markdown format to TOON format
  const lines = markdown.split("\n");
  const toonLines: string[] = [];

  for (const line of lines) {
    // Match markdown parameter format
    const match = line.match(TOON_PARAM_REGEX);
    if (match && match[1] && match[2] && match[3]) {
      const name = match[1];
      const typeInfo = match[2];
      const description = match[3];
      const compactType = typeInfo.replace(/,\s+/g, ",");
      toonLines.push(`${name}(${compactType}): ${description}`);
    } else if (line.trim()) {
      toonLines.push(line.replace(TOON_DASH_PREFIX_REGEX, "").replace(TOON_BACKTICK_REGEX, ""));
    }
  }

  return toonLines.join("\n");
}
