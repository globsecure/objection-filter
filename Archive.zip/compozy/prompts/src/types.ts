/**
 * Type definitions for the prompts package
 */

import type { z } from "zod";

export interface PromptSection {
  type:
    | "identity"
    | "context"
    | "section"
    | "xml-tag"
    | "capabilities"
    | "tools"
    | "constraints"
    | "examples"
    | "tone"
    | "thinking";
  title?: string;
  content: string;
  tag?: string;
  priority?: SectionPriority;
}

export interface PromptConfig {
  sections: PromptSection[];
}

export interface CriticalSection {
  title: string;
  items: string[];
  format?: "numbered" | "bulleted" | "labeled" | "plain";
}

export interface CriticalSectionOptions {
  sections: CriticalSection[];
  reminders?: string[];
  finalCritical?: string[];
  enforcementText?: string;
}

export interface ToolDocumentationOptions {
  toolName: string;
  description: string;
  schema?: z.ZodTypeAny; // ZodSchema type
  whenToCall?: string;
  behavior?: string;
}

/**
 * Severity levels for behavioral constraints.
 */
export type ConstraintType = "must" | "must_not" | "should" | "should_not";

/**
 * A behavioral constraint or guideline for the AI agent.
 */
export interface Constraint {
  /**
   * The severity level of this constraint.
   */
  type: ConstraintType;

  /**
   * The actual constraint rule text.
   */
  rule: string;
}

/**
 * Represents a single example for few-shot learning in the system prompt.
 */
export interface Example {
  /**
   * User's input message (conversational style).
   * Use this OR `input`, not both.
   */
  user?: string;

  /**
   * Agent's response (conversational style).
   * Use this OR `output`, not both.
   */
  assistant?: string;

  /**
   * Input to the agent (function-call style).
   * Use this OR `user`, not both.
   */
  input?: string;

  /**
   * Agent's output (function-call style).
   * Use this OR `assistant`, not both.
   */
  output?: string;

  /**
   * Optional explanation of what this example demonstrates.
   */
  explanation?: string;
}

/**
 * Defines a tool available to an AI agent.
 */
export interface ToolDefinition<T extends z.ZodType = z.ZodType> {
  /**
   * Unique identifier for the tool.
   */
  name: string;

  /**
   * Human-readable description of what the tool does and when to use it.
   */
  description: string;

  /**
   * Zod schema defining the tool's input parameters.
   */
  schema: T;

  /**
   * Optional execution function for the tool.
   */
  execute?: (args: z.infer<T>) => Promise<unknown> | unknown;
}

/**
 * Defines a subagent available to an AI agent.
 */
export interface AgentDefinition {
  /**
   * Agent identifier (e.g., "@fileExplorer").
   */
  name: string;

  /**
   * What the agent does.
   */
  purpose: string;

  /**
   * When to use this agent.
   */
  useWhen: string;

  /**
   * What the agent can do.
   */
  capabilities: string[];

  /**
   * Example of how to invoke the agent.
   */
  exampleUsage?: string;

  /**
   * Best use cases for this agent.
   */
  bestFor?: string;
}

/**
 * Output format for generated prompts.
 */
export type PromptFormat = "markdown" | "toon" | "compact";

/**
 * Message role for Anthropic Messages API compatibility.
 */
export type MessageRole = "user" | "assistant";

/**
 * Message structure matching Anthropic Messages API format.
 */
export interface Message {
  role: MessageRole;
  content: string;
}

/**
 * Result structure for building prompts with Messages API separation.
 */
export interface PromptBuildResult {
  system: string;
  messages: Message[];
}

/**
 * Section priority for context window management.
 */
export type SectionPriority = "critical" | "high" | "medium" | "low";

/**
 * Reasoning protocol configuration for Chain-of-Thought patterns.
 */
export interface ReasoningProtocol {
  enabled: boolean;
  instructions?: string;
  thinkingBlocks?: string[];
}

/**
 * Self-correction configuration for output validation.
 */
export interface SelfCorrectionConfig {
  criteria: string[];
  validationRules?: string[];
}

// Re-export validation types
export type {
  ValidationSeverity,
  ValidationIssue,
  ValidationResult,
  ValidatorConfig,
} from "./validation";
