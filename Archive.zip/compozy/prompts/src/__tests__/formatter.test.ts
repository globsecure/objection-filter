/**
 * Tests for PromptFormatter
 */

import { describe, expect, it } from "vitest";
import { z } from "zod";
import { formatPrompt, type PromptData } from "../formatter";

describe("PromptFormatter", () => {
  const createTestData = (overrides?: Partial<PromptData>): PromptData => ({
    sections: [],
    capabilities: [],
    tools: [],
    agents: [],
    constraints: [],
    examples: [],
    tone: "",
    ...overrides,
  });

  describe("formatMarkdown", () => {
    it("should format identity section", () => {
      const data = createTestData({
        sections: [{ type: "identity", content: "You are a helpful assistant" }],
      });
      const result = formatPrompt(data, "markdown");
      expect(result).toContain("You are a helpful assistant");
    });

    it("should format capabilities", () => {
      const data = createTestData({
        capabilities: ["Cap1", "Cap2"],
      });
      const result = formatPrompt(data, "markdown");
      expect(result).toContain("## Capabilities");
      expect(result).toContain("1. Cap1");
      expect(result).toContain("2. Cap2");
    });

    it("should format tools", () => {
      const data = createTestData({
        tools: [
          {
            name: "search",
            description: "Search tool",
            schema: z.object({ query: z.string() }),
          },
        ],
      });
      const result = formatPrompt(data, "markdown");
      expect(result).toContain("## Available Tools");
      expect(result).toContain("search");
    });

    it("should format constraints", () => {
      const data = createTestData({
        constraints: [
          { type: "must", rule: "Rule 1" },
          { type: "should", rule: "Rule 2" },
        ],
      });
      const result = formatPrompt(data, "markdown");
      expect(result).toContain("## Constraints");
      expect(result).toContain("**Must:**");
      expect(result).toContain("**Should:**");
    });

    it("should format must_not constraints", () => {
      const data = createTestData({
        constraints: [{ type: "must_not", rule: "Don't do this" }],
      });
      const result = formatPrompt(data, "markdown");
      expect(result).toContain("## Constraints");
      expect(result).toContain("**Must Not:**");
      expect(result).toContain("Don't do this");
    });

    it("should format should_not constraints", () => {
      const data = createTestData({
        constraints: [{ type: "should_not", rule: "Avoid this" }],
      });
      const result = formatPrompt(data, "markdown");
      expect(result).toContain("## Constraints");
      expect(result).toContain("**Should Not:**");
      expect(result).toContain("Avoid this");
    });

    it("should handle unknown section types", () => {
      const data = createTestData({
        sections: [{ type: "unknown" as any, content: "Test content" }],
      });
      const result = formatPrompt(data, "markdown");
      expect(result).toContain("Test content");
    });

    it("should handle sections with empty content", () => {
      const data = createTestData({
        sections: [{ type: "section", title: "Title", content: "" }],
      });
      const result = formatPrompt(data, "markdown");
      // Should not crash, may or may not include empty content
      expect(typeof result).toBe("string");
    });

    it("should format examples", () => {
      const data = createTestData({
        examples: [{ user: "Hello", assistant: "Hi" }],
      });
      const result = formatPrompt(data, "markdown");
      expect(result).toContain("## Examples");
      expect(result).toContain("Hello");
      expect(result).toContain("Hi");
    });

    it("should format tone", () => {
      const data = createTestData({
        tone: "Be friendly",
      });
      const result = formatPrompt(data, "markdown");
      expect(result).toContain("## Tone");
      expect(result).toContain("Be friendly");
    });

    it("should format XML tags with proper indentation", () => {
      const data = createTestData({
        sections: [
          {
            type: "xml-tag",
            tag: "critical",
            content: "Important content",
          },
        ],
      });
      const result = formatPrompt(data, "markdown");
      expect(result).toContain("<critical>");
      expect(result).toContain("Important content");
      expect(result).toContain("</critical>");
    });

    it("should properly indent nested XML tags in markdown", () => {
      const data = createTestData({
        sections: [
          {
            type: "xml-tag",
            tag: "discovery_approach",
            content: `<primary_method>
<tool>Explorer tool</tool>
<rationale>Provides comprehensive discovery</rationale>
</primary_method>
<complementary_methods>
<step name="Pattern-Based Search">
<actions>Use glob and grep</actions>
</step>
</complementary_methods>`,
          },
        ],
      });
      const result = formatPrompt(data, "markdown");

      // Check that nested tags are properly indented
      expect(result).toContain("<discovery_approach>");
      expect(result).toContain("  <primary_method>");
      // Tags with text content stay on same line but are indented
      expect(result).toContain("    <tool>Explorer tool</tool>");
      expect(result).toContain("    <rationale>Provides comprehensive discovery</rationale>");
      expect(result).toContain("  </primary_method>");
      expect(result).toContain("  <complementary_methods>");
      expect(result).toContain('    <step name="Pattern-Based Search">');
      expect(result).toContain("      <actions>Use glob and grep</actions>");
      expect(result).toContain("    </step>");
      expect(result).toContain("  </complementary_methods>");
      expect(result).toContain("</discovery_approach>");
    });
  });

  describe("formatCompact", () => {
    it("should remove excessive whitespace", () => {
      const data = createTestData({
        sections: [
          { type: "identity", content: "Test" },
          { type: "context", content: "Context" },
        ],
      });
      const compact = formatPrompt(data, "compact");
      expect(compact).not.toMatch(/\n{3,}/);
    });

    it("should maintain markdown structure", () => {
      const data = createTestData({
        capabilities: ["Cap1", "Cap2"],
      });
      const compact = formatPrompt(data, "compact");
      expect(compact).toContain("## Capabilities");
    });
  });

  describe("formatTOON", () => {
    it("should format identity in TOON format", () => {
      const data = createTestData({
        sections: [{ type: "identity", content: "You are a helpful assistant" }],
      });
      const toon = formatPrompt(data, "toon");
      expect(toon).toContain("Identity:");
      expect(toon).toContain("You are a helpful assistant");
    });

    it("should format capabilities using TOON library", () => {
      const data = createTestData({
        capabilities: ["Cap1", "Cap2"],
      });
      const toon = formatPrompt(data, "toon");
      expect(toon).toContain("capabilities");
      expect(toon).toContain("Cap1");
      expect(toon).toContain("Cap2");
    });

    it("should format constraints using TOON library", () => {
      const data = createTestData({
        constraints: [
          { type: "must", rule: "Rule 1" },
          { type: "should", rule: "Rule 2" },
        ],
      });
      const toon = formatPrompt(data, "toon");
      expect(toon).toContain("constraints");
      expect(toon).toContain("must");
      expect(toon).toContain("should");
    });

    it("should format examples using TOON library when uniform", () => {
      const data = createTestData({
        examples: [
          { user: "Hello", assistant: "Hi" },
          { user: "How are you?", assistant: "I'm good" },
        ],
      });
      const toon = formatPrompt(data, "toon");
      expect(toon).toContain("examples");
    });

    it("should format tools with TOON parameter notation", () => {
      const data = createTestData({
        tools: [
          {
            name: "search",
            description: "Search tool",
            schema: z.object({
              query: z.string().describe("Search query"),
            }),
          },
        ],
      });
      const toon = formatPrompt(data, "toon");
      expect(toon).toContain("Tools[1]:");
      expect(toon).toContain("search:");
      expect(toon).toContain("Search tool");
    });

    it("should format XML tags in TOON", () => {
      const data = createTestData({
        sections: [
          {
            type: "xml-tag",
            tag: "critical",
            content: "Important content",
          },
        ],
      });
      const toon = formatPrompt(data, "toon");
      expect(toon).toContain("<critical>");
      expect(toon).toContain("Important content");
      expect(toon).toContain("</critical>");
    });

    it("should properly indent nested XML tags in TOON", () => {
      const data = createTestData({
        sections: [
          {
            type: "xml-tag",
            tag: "discovery_approach",
            content: `<primary_method>
<tool>Explorer tool</tool>
<rationale>Provides comprehensive discovery</rationale>
</primary_method>
<complementary_methods>
<step name="Pattern-Based Search">
<actions>Use glob and grep</actions>
</step>
</complementary_methods>`,
          },
        ],
      });
      const toon = formatPrompt(data, "toon");

      // Check that nested tags are properly indented (2 spaces base + 2 per level)
      expect(toon).toContain("<discovery_approach>");
      expect(toon).toContain("  <primary_method>");
      // Tags with text content stay on same line but are indented
      expect(toon).toContain("    <tool>Explorer tool</tool>");
      expect(toon).toContain("    <rationale>Provides comprehensive discovery</rationale>");
      expect(toon).toContain("  </primary_method>");
      expect(toon).toContain("  <complementary_methods>");
      expect(toon).toContain('    <step name="Pattern-Based Search">');
      expect(toon).toContain("      <actions>Use glob and grep</actions>");
      expect(toon).toContain("    </step>");
      expect(toon).toContain("  </complementary_methods>");
      expect(toon).toContain("</discovery_approach>");
    });

    it("should handle self-closing XML tags", () => {
      const data = createTestData({
        sections: [
          {
            type: "xml-tag",
            tag: "config",
            content: `<setting name="debug" value="true" />
<setting name="timeout" value="30" />`,
          },
        ],
      });
      const toon = formatPrompt(data, "toon");
      expect(toon).toContain("<config>");
      expect(toon).toContain('  <setting name="debug" value="true" />');
      expect(toon).toContain('  <setting name="timeout" value="30" />');
      expect(toon).toContain("</config>");
    });

    it("should format context section in TOON", () => {
      const data = createTestData({
        sections: [
          {
            type: "context",
            content: "Context line 1\nContext line 2",
          },
        ],
      });
      const toon = formatPrompt(data, "toon");
      expect(toon).toContain("Context:");
      expect(toon).toContain("  Context line 1");
      expect(toon).toContain("  Context line 2");
    });

    it("should format non-uniform examples in TOON", () => {
      const data = createTestData({
        examples: [
          { user: "Hello", assistant: "Hi" },
          { input: "Question", output: "Answer", explanation: "Explanation" },
        ],
      });
      const toon = formatPrompt(data, "toon");
      expect(toon).toContain("Examples[2]:");
      expect(toon).toContain("User:");
      expect(toon).toContain("Input:");
      expect(toon).toContain("Output:");
      expect(toon).toContain("Explanation:");
    });

    it("should format examples with mixed user/assistant and input/output in TOON", () => {
      const data = createTestData({
        examples: [
          { user: "Hello", assistant: "Hi" },
          { input: "Question", output: "Answer" },
        ],
      });
      const toon = formatPrompt(data, "toon");
      expect(toon).toContain("Example 1:");
      expect(toon).toContain("Example 2:");
    });

    it("should format tone section in TOON", () => {
      const data = createTestData({
        tone: "Be friendly\nBe concise",
      });
      const toon = formatPrompt(data, "toon");
      expect(toon).toContain("Tone:");
      expect(toon).toContain("  Be friendly");
      expect(toon).toContain("  Be concise");
    });

    it("should format regular sections in TOON", () => {
      const data = createTestData({
        sections: [
          {
            type: "section",
            title: "Instructions",
            content: "Step 1\nStep 2",
          },
        ],
      });
      const toon = formatPrompt(data, "toon");
      expect(toon).toContain("Instructions:");
      expect(toon).toContain("  Step 1");
      expect(toon).toContain("  Step 2");
    });

    it("should format sections without title in TOON", () => {
      const data = createTestData({
        sections: [
          {
            type: "section",
            title: "",
            content: "Content without title",
          },
        ],
      });
      const toon = formatPrompt(data, "toon");
      expect(toon).toContain("Section:");
      expect(toon).toContain("  Content without title");
    });

    it("should handle TOON parameter regex matching", () => {
      const data = createTestData({
        tools: [
          {
            name: "test_tool",
            description: "Test tool description",
            schema: z.object({
              param1: z.string().describe("Parameter 1"),
              param2: z.number().optional().describe("Parameter 2"),
            }),
          },
        ],
      });
      const toon = formatPrompt(data, "toon");
      // Should convert markdown parameter format to TOON format
      expect(toon).toContain("test_tool:");
      expect(toon).toContain("Test tool description");
    });

    it("should handle TOON parameter regex with complex type info", () => {
      // Create a schema that will produce markdown format matching TOON_PARAM_REGEX
      const data = createTestData({
        tools: [
          {
            name: "complex_tool",
            description: "Complex tool",
            schema: z.object({
              param: z.string().min(1).max(100).describe("A parameter with constraints"),
            }),
          },
        ],
      });
      const toon = formatPrompt(data, "toon");
      // The parseZodSchemaToTOON function should process the markdown and convert it
      expect(toon).toContain("complex_tool:");
      expect(toon).toContain("Complex tool");
    });

    it("should handle lines that don't match TOON parameter regex", () => {
      // Test the else branch when line doesn't match regex but has content
      const data = createTestData({
        tools: [
          {
            name: "simple_tool",
            description: "Simple tool",
            schema: z.object({
              // This should produce markdown that may not match the exact regex
              param: z.string(),
            }),
          },
        ],
      });
      const toon = formatPrompt(data, "toon");
      // Should still process the tool even if regex doesn't match
      expect(toon).toContain("simple_tool:");
      expect(toon).toContain("Simple tool");
    });
  });

  describe("format switching", () => {
    it("should produce different output for different formats", () => {
      const data = createTestData({
        sections: [{ type: "identity", content: "Test" }],
        capabilities: ["Cap1"],
      });

      const markdown = formatPrompt(data, "markdown");
      const compact = formatPrompt(data, "compact");
      const toon = formatPrompt(data, "toon");

      expect(markdown).toContain("## Capabilities");
      expect(compact).toContain("## Capabilities");
      expect(toon).toContain("capabilities");

      // Formats should be different
      expect(markdown).not.toBe(toon);
      expect(compact).not.toBe(toon);
    });

    it("should fallback to markdown for unmapped formats", () => {
      const data = createTestData({
        sections: [{ type: "identity", content: "Test" }],
      });

      const fallback = formatPrompt(data, "invalid_format" as any);
      const markdown = formatPrompt(data, "markdown");

      expect(fallback).toBe(markdown);
    });
  });

  describe("formatAgents", () => {
    it("should format agents in markdown", () => {
      const data = createTestData({
        agents: [
          {
            name: "@fileExplorer",
            purpose: "File exploration",
            useWhen: "When exploring files",
            capabilities: ["Search files", "Read files"],
          },
        ],
      });
      const result = formatPrompt(data, "markdown");
      expect(result).toContain("### Subagents");
      expect(result).toContain("@fileExplorer");
      expect(result).toContain("File exploration");
      expect(result).toContain("When exploring files");
      expect(result).toContain("Search files");
      expect(result).toContain("Read files");
    });

    it("should format agents with optional fields", () => {
      const data = createTestData({
        agents: [
          {
            name: "@agent",
            purpose: "Purpose",
            useWhen: "When",
            capabilities: ["Cap1"],
            exampleUsage: "Example usage",
            bestFor: "Best for",
          },
        ],
      });
      const result = formatPrompt(data, "markdown");
      expect(result).toContain("Example usage");
      expect(result).toContain("Best for");
    });

    it("should format multiple agents", () => {
      const data = createTestData({
        agents: [
          {
            name: "@agent1",
            purpose: "Purpose 1",
            useWhen: "When 1",
            capabilities: [],
          },
          {
            name: "@agent2",
            purpose: "Purpose 2",
            useWhen: "When 2",
            capabilities: [],
          },
        ],
      });
      const result = formatPrompt(data, "markdown");
      expect(result).toContain("@agent1");
      expect(result).toContain("@agent2");
      expect(result).toContain("Purpose 1");
      expect(result).toContain("Purpose 2");
    });

    it("should format agents in TOON format", () => {
      const data = createTestData({
        agents: [
          {
            name: "@fileExplorer",
            purpose: "File exploration",
            useWhen: "When exploring files",
            capabilities: ["Search files"],
          },
        ],
      });
      const toon = formatPrompt(data, "toon");
      expect(toon).toContain("agents");
      expect(toon).toContain("@fileExplorer");
      expect(toon).toContain("File exploration");
    });

    it("should format agents in compact format", () => {
      const data = createTestData({
        agents: [
          {
            name: "@agent",
            purpose: "Purpose",
            useWhen: "When",
            capabilities: [],
          },
        ],
      });
      const compact = formatPrompt(data, "compact");
      expect(compact).toContain("### Subagents");
      expect(compact).toContain("@agent");
    });

    it("should not include agents section when empty", () => {
      const data = createTestData({
        agents: [],
      });
      const result = formatPrompt(data, "markdown");
      expect(result).not.toContain("### Subagents");
    });
  });

  describe("edge cases", () => {
    it("should preserve unicode, emoji, and long content", () => {
      const longCapability = "🚀".repeat(50);
      const htmlEntitySection = "&lt;secured&gt; café ☕";
      const data = createTestData({
        sections: [
          { type: "identity", content: `Lead engineer ${htmlEntitySection}` },
          { type: "tone", content: htmlEntitySection.repeat(3) },
        ],
        capabilities: [longCapability, "Handle emoji 😊"],
        tools: [
          {
            name: "unicode_tool",
            description: "Handles emoji and entities like ❤ &amp;",
            schema: z.object({ note: z.string().min(1) }),
          },
        ],
        examples: [
          {
            input: "Input 😀",
            output: "Output 👍",
            explanation: "Emoji example",
          },
        ],
      });

      const result = formatPrompt(data, "markdown");
      expect(result).toContain("🚀🚀");
      expect(result).toContain("café ☕");
      expect(result).toContain("❤");
      expect(result.length).toBeGreaterThan(100);
    });

    it("should handle complex zod schemas without throwing", () => {
      const recursiveSchema: z.ZodTypeAny = z.lazy(() =>
        z.object({
          id: z.string(),
          child: z.union([z.string(), recursiveSchema]).optional(),
          metadata: z.record(z.string(), z.union([z.string(), z.number()])).optional(),
        })
      );

      const data = createTestData({
        tools: [
          {
            name: "complex_tool",
            description: "Tests unions and optional recursion",
            schema: z.object({
              payload: z.union([z.string(), z.array(z.number())]),
              nested: recursiveSchema.optional(),
            }),
          },
        ],
      });

      expect(() => formatPrompt(data, "toon")).not.toThrow();
      const toon = formatPrompt(data, "toon");
      expect(toon).toContain("complex_tool");
    });
  });
});
