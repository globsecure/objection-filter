/**
 * Tests for section builders
 * Validates critical sections, tool documentation, context sections, and schema helpers
 */

import { describe, expect, it } from "vitest";
import { buildCriticalSection } from "../sections/critical";
import { buildToolDocumentation } from "../sections/tools";
import { zodSchemaToPromptText, formatSchemaForPrompt } from "../sections/schema";
import { z } from "zod";

describe("buildCriticalSection", () => {
  it("should build critical section with sections", () => {
    const result = buildCriticalSection({
      sections: [
        {
          title: "Mandatory Behavior",
          items: ["Do this", "Do that"],
          format: "numbered",
        },
        {
          title: "Failure Conditions",
          items: ["Don't do this", "Don't do that"],
          format: "bulleted",
        },
        {
          title: "Requirements",
          items: ["Requirement 1", "Requirement 2"],
          format: "labeled",
        },
      ],
    });

    expect(result).toContain("<critical>");
    expect(result).toContain("</critical>");
    expect(result).toContain("MANDATORY BEHAVIOR");
    expect(result).toContain("FAILURE CONDITIONS");
    expect(result).toContain("REQUIREMENTS");
    expect(result).toContain("Do this");
    expect(result).toContain("Don't do this");
    expect(result).toContain("Requirement 1");
  });

  it("should format numbered sections with arrows", () => {
    const result = buildCriticalSection({
      sections: [
        {
          title: "Actions",
          items: ["EXPLORE → Use explorer tool", "CALL → Use tool"],
          format: "numbered",
        },
      ],
    });

    expect(result).toContain("1. **EXPLORE** → Use explorer tool");
    expect(result).toContain("2. **CALL** → Use tool");
  });

  it("should format labeled sections with colons", () => {
    const result = buildCriticalSection({
      sections: [
        {
          title: "Rules",
          items: ["TOOL USAGE: Must call tool", "VALIDATION: Must validate"],
          format: "labeled",
        },
      ],
    });

    expect(result).toContain("- **TOOL USAGE**: Must call tool");
    expect(result).toContain("- **VALIDATION**: Must validate");
  });

  it("should include optional reminders", () => {
    const result = buildCriticalSection({
      sections: [
        {
          title: "Behavior",
          items: ["Item 1"],
          format: "bulleted",
        },
      ],
      reminders: ["Reminder 1", "Reminder 2"],
    });

    // Reminders are now consolidated into a single concise statement
    expect(result).toContain("⚠️ **OUTPUT MUST USE TOOLS ONLY. NO TEXT OUTPUT.**");
  });

  it("should include optional final critical", () => {
    const result = buildCriticalSection({
      sections: [
        {
          title: "Behavior",
          items: ["Item 1"],
          format: "bulleted",
        },
      ],
      finalCritical: ["Final rule 1", "Final rule 2"],
    });

    expect(result).toContain("Final rule 1");
    expect(result).toContain("Final rule 2");
    expect(result).toContain("<critical>");
  });

  it("should use custom enforcement text", () => {
    const result = buildCriticalSection({
      sections: [
        {
          title: "Behavior",
          items: ["Item 1"],
          format: "bulleted",
        },
      ],
      finalCritical: ["Final rule"],
      enforcementText: "Custom enforcement message.",
    });

    expect(result).toContain("Custom enforcement message.");
  });

  it("should throw error for empty sections", () => {
    expect(() => {
      buildCriticalSection({
        sections: [],
      });
    }).toThrow();
  });

  it("should skip empty section items", () => {
    const result = buildCriticalSection({
      sections: [
        {
          title: "Empty Section",
          items: [],
          format: "bulleted",
        },
        {
          title: "Valid Section",
          items: ["Item 1"],
          format: "bulleted",
        },
      ],
    });

    expect(result).not.toContain("EMPTY SECTION");
    expect(result).toContain("VALID SECTION");
    expect(result).toContain("Item 1");
  });
});

describe("buildToolDocumentation", () => {
  it("should build tool documentation", () => {
    const schema = z.object({
      query: z.string().describe("Search query"),
    });

    const result = buildToolDocumentation({
      toolName: "search_tool",
      description: "Search for items",
      schema,
    });

    expect(result).toContain("search_tool Tool");
    expect(result).toContain("Purpose");
    expect(result).toContain("Search for items");
  });

  it("should include whenToCall if provided", () => {
    const result = buildToolDocumentation({
      toolName: "search_tool",
      description: "Search for items",
      schema: z.object({}),
      whenToCall: "When you need to search",
    });

    expect(result).toContain("When to call");
    expect(result).toContain("When you need to search");
  });

  it("should include behavior if provided", () => {
    const result = buildToolDocumentation({
      toolName: "search_tool",
      description: "Search for items",
      schema: z.object({}),
      behavior: "Returns search results",
    });

    expect(result).toContain("Behavior");
    expect(result).toContain("Returns search results");
  });
});

describe("zodSchemaToPromptText", () => {
  // Uses Zod 4's native toJSONSchema() method

  it("should handle Zod schema conversion", () => {
    const schema = z.object({
      name: z.string().describe("User name"),
      age: z.number().optional(),
    });

    const result = zodSchemaToPromptText(schema, "UserInput");
    // Returns formatted prompt text from JSON Schema
    expect(typeof result).toBe("string");
    expect(result.length).toBeGreaterThan(0);
  });

  it("should return a string for any Zod schema", () => {
    const schema = z.object({
      required: z.string(),
      optional: z.string().optional(),
    });

    const result = zodSchemaToPromptText(schema, "TestInput");
    expect(typeof result).toBe("string");
    expect(result.length).toBeGreaterThan(0);
  });

  it("should handle enum types gracefully", () => {
    const schema = z.object({
      status: z.enum(["active", "inactive"]),
    });

    const result = zodSchemaToPromptText(schema, "StatusInput");
    expect(typeof result).toBe("string");
    expect(result.length).toBeGreaterThan(0);
  });

  it("should handle array types gracefully", () => {
    const schema = z.object({
      items: z.array(z.string()),
    });

    const result = zodSchemaToPromptText(schema, "ArrayInput");
    expect(typeof result).toBe("string");
    expect(result.length).toBeGreaterThan(0);
  });

  it("should handle $ref resolution", () => {
    const schemaWithRef = {
      $ref: "#/definitions/User",
      definitions: {
        User: {
          type: "object",
          properties: {
            name: { type: "string", description: "User name" },
          },
          required: ["name"],
        },
      },
    };

    const result = formatSchemaForPrompt(schemaWithRef);
    expect(result).toContain("name");
    expect(result).toContain("User name");
  });

  it("should format object schemas with properties", () => {
    const jsonSchema = {
      type: "object",
      properties: {
        name: { type: "string", description: "User name" },
        age: { type: "number" },
      },
      required: ["name"],
    };

    const result = formatSchemaForPrompt(jsonSchema);
    expect(result).toContain("`name` (required)");
    expect(result).toContain("`age` (optional)");
    expect(result).toContain("User name");
  });

  it("should handle schemas with constraints", () => {
    const jsonSchema = {
      type: "object",
      properties: {
        name: { type: "string", minLength: 3, maxLength: 50 },
        age: { type: "number", minimum: 0, maximum: 120 },
        tags: { type: "array", items: { type: "string" }, minItems: 1, maxItems: 10 },
      },
      required: ["name"],
    };

    const result = formatSchemaForPrompt(jsonSchema);
    expect(result).toContain("min length: 3");
    expect(result).toContain("max length: 50");
    expect(result).toContain("min: 0");
    expect(result).toContain("max: 120");
    expect(result).toContain("min items: 1");
    expect(result).toContain("max items: 10");
  });

  it("should handle schemas with enum values", () => {
    const jsonSchema = {
      type: "object",
      properties: {
        status: { type: "string", enum: ["active", "inactive", "pending"] },
      },
    };

    const result = formatSchemaForPrompt(jsonSchema);
    expect(result).toContain('One of: "active", "inactive", "pending"');
  });

  it("should handle array items with types", () => {
    const jsonSchema = {
      type: "object",
      properties: {
        numbers: { type: "array", items: { type: "number" } },
        strings: { type: "array", items: { type: "string" } },
      },
    };

    const result = formatSchemaForPrompt(jsonSchema);
    expect(result).toContain("Array of number");
    expect(result).toContain("Array of string");
  });

  it("should handle array items with enum values", () => {
    const jsonSchema = {
      type: "object",
      properties: {
        tags: {
          type: "array",
          items: { enum: ["tag1", "tag2", "tag3"] },
        },
      },
    };

    const result = formatSchemaForPrompt(jsonSchema);
    expect(result).toContain("Array of enum values");
  });

  it("should handle schemas with format information", () => {
    const jsonSchema = {
      type: "object",
      properties: {
        email: { type: "string", format: "email" },
        date: { type: "string", format: "date-time" },
      },
    };

    const result = formatSchemaForPrompt(jsonSchema);
    expect(result).toContain("(format: email)");
    expect(result).toContain("(format: date-time)");
  });

  it("should handle definitions at root level", () => {
    const schemaWithDefinitions = {
      definitions: {
        User: {
          type: "object",
          properties: {
            name: { type: "string" },
          },
        },
      },
    };

    const result = formatSchemaForPrompt(schemaWithDefinitions);
    expect(result).toContain("name");
  });

  it("should handle definitions with $ref at root", () => {
    const schemaWithRef = {
      $ref: "#/definitions/User",
      definitions: {
        User: {
          type: "object",
          properties: {
            name: { type: "string", description: "User name" },
          },
        },
      },
    };

    const result = formatSchemaForPrompt(schemaWithRef);
    expect(result).toContain("name");
    expect(result).toContain("User name");
  });

  it("should handle union types", () => {
    const jsonSchema = {
      type: "object",
      properties: {
        value: { type: ["string", "number"] },
      },
    };

    const result = formatSchemaForPrompt(jsonSchema);
    expect(result).toContain("Union of string | number");
  });

  it("should handle fallback for non-object schemas", () => {
    const simpleSchema = { type: "string" };
    const result = formatSchemaForPrompt(simpleSchema);
    expect(result).toBe(JSON.stringify(simpleSchema, null, 2));
  });

  it("should handle string schema input", () => {
    const jsonSchemaString = JSON.stringify({
      type: "object",
      properties: {
        name: { type: "string" },
      },
    });

    const result = formatSchemaForPrompt(jsonSchemaString);
    expect(result).toContain("name");
  });

  it("should handle $ref that cannot be resolved", () => {
    const schemaWithUnresolvableRef = {
      $ref: "#/definitions/NonExistent",
      definitions: {
        User: {
          type: "object",
          properties: {
            name: { type: "string" },
          },
        },
      },
    };

    // Should fallback to stringified schema when ref can't be resolved
    const result = formatSchemaForPrompt(schemaWithUnresolvableRef);
    expect(typeof result).toBe("string");
    expect(result.length).toBeGreaterThan(0);
  });

  it("should handle definitions with $ref at root level", () => {
    const schemaWithRootRef = {
      $ref: "#/definitions/User",
      definitions: {
        User: {
          type: "object",
          properties: {
            name: { type: "string", description: "User name" },
          },
          required: ["name"],
        },
      },
    };

    const result = formatSchemaForPrompt(schemaWithRootRef);
    expect(result).toContain("name");
    expect(result).toContain("User name");
  });

  it("should handle definitions without properties at root", () => {
    const schemaWithDefinitionsOnly = {
      definitions: {
        User: {
          type: "object",
          properties: {
            name: { type: "string" },
          },
        },
      },
    };

    const result = formatSchemaForPrompt(schemaWithDefinitionsOnly);
    expect(result).toContain("name");
  });

  it("should not use definitions when root has properties", () => {
    const schemaWithBoth = {
      type: "object",
      properties: {
        name: { type: "string" },
      },
      definitions: {
        User: {
          type: "object",
          properties: {
            email: { type: "string" },
          },
        },
      },
    };

    const result = formatSchemaForPrompt(schemaWithBoth);
    expect(result).toContain("name");
    // Should use root properties, not definitions
    expect(result).not.toContain("email");
  });
});
