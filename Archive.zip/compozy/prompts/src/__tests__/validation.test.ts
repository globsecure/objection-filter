/**
 * Tests for PromptValidator
 * Validates validation logic, error detection, warnings, and recommendations
 */

import { describe, expect, it } from "vitest";
import { z } from "zod";
import { PromptValidator, formatValidationResult } from "../validation";
import type { ToolDefinition, Constraint, Example } from "../types";

describe("PromptValidator", () => {
  describe("checkDuplicateTools", () => {
    it("should detect duplicate tool names", () => {
      const tools: ToolDefinition[] = [
        {
          name: "search",
          description: "Search tool",
          schema: z.object({ query: z.string() }),
        },
        {
          name: "search",
          description: "Another search tool",
          schema: z.object({ query: z.string() }),
        },
      ];

      const validator = new PromptValidator();
      const result = validator.validate({
        identity: true,
        capabilities: [],
        tools,
        constraints: [],
        examples: [],
        tone: false,
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toHaveLength(1);
      expect(result.errors[0]?.code).toBe("DUPLICATE_TOOL");
      expect(result.errors[0]?.message).toContain("Duplicate tool name");
    });

    it("should not error when tools have unique names", () => {
      const tools: ToolDefinition[] = [
        {
          name: "search",
          description: "Search tool",
          schema: z.object({ query: z.string() }),
        },
        {
          name: "fetch",
          description: "Fetch tool",
          schema: z.object({ url: z.string() }),
        },
      ];

      const validator = new PromptValidator();
      const result = validator.validate({
        identity: true,
        capabilities: [],
        tools,
        constraints: [],
        examples: [],
        tone: false,
      });

      expect(result.errors.filter(e => e.code === "DUPLICATE_TOOL")).toHaveLength(0);
    });
  });

  describe("checkIdentity", () => {
    it("should warn when identity is missing", () => {
      const validator = new PromptValidator();
      const result = validator.validate({
        identity: false,
        capabilities: [],
        tools: [],
        constraints: [],
        examples: [],
        tone: false,
      });

      expect(result.warnings.some(w => w.code === "MISSING_IDENTITY")).toBe(true);
      const identityWarning = result.warnings.find(w => w.code === "MISSING_IDENTITY");
      expect(identityWarning?.message).toContain("No identity set");
    });

    it("should not warn when identity is present", () => {
      const validator = new PromptValidator();
      const result = validator.validate({
        identity: true,
        capabilities: [],
        tools: [],
        constraints: [],
        examples: [],
        tone: false,
      });

      expect(result.warnings.filter(w => w.code === "MISSING_IDENTITY")).toHaveLength(0);
    });
  });

  describe("checkEmptySections", () => {
    it("should warn when capabilities are empty", () => {
      const validator = new PromptValidator();
      const result = validator.validate({
        identity: true,
        capabilities: [],
        tools: [],
        constraints: [],
        examples: [],
        tone: false,
      });

      expect(result.warnings.some(w => w.code === "EMPTY_CAPABILITIES")).toBe(true);
    });

    it("should warn when constraints are empty", () => {
      const validator = new PromptValidator();
      const result = validator.validate({
        identity: true,
        capabilities: ["Answer questions"],
        tools: [],
        constraints: [],
        examples: [],
        tone: false,
      });

      expect(result.warnings.some(w => w.code === "EMPTY_CONSTRAINTS")).toBe(true);
    });

    it("should not warn when sections are populated", () => {
      const validator = new PromptValidator();
      const result = validator.validate({
        identity: true,
        capabilities: ["Answer questions"],
        tools: [],
        constraints: [{ type: "must", rule: "Be helpful" }],
        examples: [],
        tone: false,
      });

      expect(
        result.warnings.filter(
          w => w.code === "EMPTY_CAPABILITIES" || w.code === "EMPTY_CONSTRAINTS"
        )
      ).toHaveLength(0);
    });
  });

  describe("checkRecommendations", () => {
    it("should recommend examples when tools exist but no examples", () => {
      const tools: ToolDefinition[] = [
        {
          name: "search",
          description: "Search tool",
          schema: z.object({ query: z.string() }),
        },
      ];

      const validator = new PromptValidator();
      const result = validator.validate({
        identity: true,
        capabilities: [],
        tools,
        constraints: [],
        examples: [],
        tone: false,
      });

      expect(result.info.some(i => i.code === "TOOLS_WITHOUT_EXAMPLES")).toBe(true);
    });

    it("should recommend must constraints when constraints exist but no must", () => {
      const validator = new PromptValidator();
      const result = validator.validate({
        identity: true,
        capabilities: [],
        tools: [],
        constraints: [{ type: "should", rule: "Be helpful" }],
        examples: [],
        tone: false,
      });

      expect(result.info.some(i => i.code === "NO_MUST_CONSTRAINTS")).toBe(true);
    });

    it("should not recommend when examples exist with tools", () => {
      const tools: ToolDefinition[] = [
        {
          name: "search",
          description: "Search tool",
          schema: z.object({ query: z.string() }),
        },
      ];

      const examples: Example[] = [
        {
          user: "Search for cats",
          assistant: "I'll search for cats",
        },
      ];

      const validator = new PromptValidator();
      const result = validator.validate({
        identity: true,
        capabilities: [],
        tools,
        constraints: [],
        examples,
        tone: false,
      });

      expect(result.info.filter(i => i.code === "TOOLS_WITHOUT_EXAMPLES")).toHaveLength(0);
    });
  });

  describe("checkConstraintConflicts", () => {
    it("should warn about potentially conflicting constraints", () => {
      const constraints: Constraint[] = [
        { type: "must", rule: "Never log user data" },
        { type: "must_not", rule: "log user data" },
      ];

      const validator = new PromptValidator();
      const result = validator.validate({
        identity: true,
        capabilities: [],
        tools: [],
        constraints,
        examples: [],
        tone: false,
      });

      expect(result.warnings.some(w => w.code === "CONFLICTING_CONSTRAINTS")).toBe(true);
    });

    it("should not warn when constraints don't conflict", () => {
      const constraints: Constraint[] = [
        { type: "must", rule: "Always verify user identity" },
        { type: "must_not", rule: "Never share passwords" },
      ];

      const validator = new PromptValidator();
      const result = validator.validate({
        identity: true,
        capabilities: [],
        tools: [],
        constraints,
        examples: [],
        tone: false,
      });

      expect(result.warnings.filter(w => w.code === "CONFLICTING_CONSTRAINTS")).toHaveLength(0);
    });
  });

  describe("ValidatorConfig", () => {
    it("should respect checkDuplicateTools config", () => {
      const tools: ToolDefinition[] = [
        {
          name: "search",
          description: "Search tool",
          schema: z.object({ query: z.string() }),
        },
        {
          name: "search",
          description: "Another search tool",
          schema: z.object({ query: z.string() }),
        },
      ];

      const validator = new PromptValidator({
        checkDuplicateTools: false,
      });

      const result = validator.validate({
        identity: true,
        capabilities: [],
        tools,
        constraints: [],
        examples: [],
        tone: false,
      });

      expect(result.errors.filter(e => e.code === "DUPLICATE_TOOL")).toHaveLength(0);
    });

    it("should respect checkIdentity config", () => {
      const validator = new PromptValidator({
        checkIdentity: false,
      });

      const result = validator.validate({
        identity: false,
        capabilities: [],
        tools: [],
        constraints: [],
        examples: [],
        tone: false,
      });

      expect(result.warnings.filter(w => w.code === "MISSING_IDENTITY")).toHaveLength(0);
    });

    it("should respect checkEmptySections config", () => {
      const validator = new PromptValidator({
        checkEmptySections: false,
      });

      const result = validator.validate({
        identity: true,
        capabilities: [],
        tools: [],
        constraints: [],
        examples: [],
        tone: false,
      });

      expect(
        result.warnings.filter(
          w => w.code === "EMPTY_CAPABILITIES" || w.code === "EMPTY_CONSTRAINTS"
        )
      ).toHaveLength(0);
    });

    it("should respect checkRecommendations config", () => {
      const tools: ToolDefinition[] = [
        {
          name: "search",
          description: "Search tool",
          schema: z.object({ query: z.string() }),
        },
      ];

      const validator = new PromptValidator({
        checkRecommendations: false,
      });

      const result = validator.validate({
        identity: true,
        capabilities: [],
        tools,
        constraints: [],
        examples: [],
        tone: false,
      });

      expect(result.info.filter(i => i.code === "TOOLS_WITHOUT_EXAMPLES")).toHaveLength(0);
    });

    it("should respect checkConstraintConflicts config", () => {
      const constraints: Constraint[] = [
        { type: "must", rule: "Never log user data" },
        { type: "must_not", rule: "log user data" },
      ];

      const validator = new PromptValidator({
        checkConstraintConflicts: false,
      });

      const result = validator.validate({
        identity: true,
        capabilities: [],
        tools: [],
        constraints,
        examples: [],
        tone: false,
      });

      expect(result.warnings.filter(w => w.code === "CONFLICTING_CONSTRAINTS")).toHaveLength(0);
    });
  });

  describe("formatValidationResult", () => {
    it("should format valid result", () => {
      const result = {
        valid: true,
        errors: [],
        warnings: [],
        info: [],
      };

      const formatted = formatValidationResult(result);
      expect(formatted).toContain("✓ Validation passed");
    });

    it("should format invalid result with errors", () => {
      const result = {
        valid: false,
        errors: [
          {
            severity: "error" as const,
            code: "DUPLICATE_TOOL",
            message: "Duplicate tool name: search",
            suggestion: "Rename one of the tools",
          },
        ],
        warnings: [],
        info: [],
      };

      const formatted = formatValidationResult(result);
      expect(formatted).toContain("✗ Validation failed");
      expect(formatted).toContain("DUPLICATE_TOOL");
      expect(formatted).toContain("Rename one of the tools");
    });

    it("should format warnings and info", () => {
      const result = {
        valid: true,
        errors: [],
        warnings: [
          {
            severity: "warning" as const,
            code: "MISSING_IDENTITY",
            message: "No identity set",
            suggestion: "Add an identity",
          },
        ],
        info: [
          {
            severity: "info" as const,
            code: "TOOLS_WITHOUT_EXAMPLES",
            message: "Tools defined without examples",
            suggestion: "Add examples",
          },
        ],
      };

      const formatted = formatValidationResult(result);
      expect(formatted).toContain("MISSING_IDENTITY");
      expect(formatted).toContain("TOOLS_WITHOUT_EXAMPLES");
    });
  });
});
