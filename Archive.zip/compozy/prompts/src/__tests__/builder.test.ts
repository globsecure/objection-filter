/**
 * Tests for PromptBuilder
 * Validates fluent API, section building, XML tags, and composition
 */

import { describe, expect, it, vi } from "vitest";
import { z } from "zod";
import { createPromptBuilder, PromptBuilder } from "../builder";

/**
 * Test helper to access the private _output field of PromptBuilder.
 * Centralizes the cast to reduce noise and coupling to internals.
 */
const getOutput = (
  builder: PromptBuilder
): { format: string; content: string; language?: string } | undefined =>
  (builder as unknown as { _output?: { format: string; content: string; language?: string } })
    ._output;

describe("PromptBuilder", () => {
  describe("createPromptBuilder", () => {
    it("should create a new PromptBuilder instance", () => {
      const builder = createPromptBuilder();
      expect(builder).toBeInstanceOf(PromptBuilder);
    });
  });

  describe("withIdentity", () => {
    it("should add identity section", () => {
      const builder = createPromptBuilder().withIdentity("You are a helpful assistant");
      const sections = builder.getSections();
      expect(sections).toHaveLength(1);
      expect(sections[0]).toMatchObject({
        type: "identity",
        content: "You are a helpful assistant",
      });
    });

    it("should trim whitespace from identity", () => {
      const builder = createPromptBuilder().withIdentity("  You are a helpful assistant  ");
      const sections = builder.getSections();
      expect(sections[0]?.content).toBe("You are a helpful assistant");
    });

    it("should throw error for empty identity", () => {
      expect(() => {
        createPromptBuilder().withIdentity("");
      }).toThrow();
    });
  });

  describe("withContext", () => {
    it("should add context section", () => {
      const builder = createPromptBuilder().withContext("Company: TechCorp");
      const sections = builder.getSections();
      expect(sections).toHaveLength(1);
      expect(sections[0]).toMatchObject({
        type: "context",
        content: "Company: TechCorp",
      });
    });

    it("should trim whitespace from context", () => {
      const builder = createPromptBuilder().withContext("  Company: TechCorp  ");
      const sections = builder.getSections();
      expect(sections[0]?.content).toBe("Company: TechCorp");
    });
  });

  describe("withSection", () => {
    it("should add titled section", () => {
      const builder = createPromptBuilder().withSection("Capabilities", "Answer questions");
      const sections = builder.getSections();
      expect(sections).toHaveLength(1);
      expect(sections[0]).toMatchObject({
        type: "section",
        title: "Capabilities",
        content: "Answer questions",
      });
    });

    it("should trim whitespace from title and content", () => {
      const builder = createPromptBuilder().withSection("  Capabilities  ", "  Answer questions  ");
      const sections = builder.getSections();
      expect(sections[0]?.title).toBe("Capabilities");
      expect(sections[0]?.content).toBe("Answer questions");
    });
  });

  describe("withXmlTag", () => {
    it("should add XML tag section", () => {
      const builder = createPromptBuilder().withXmlTag("critical", "This is critical");
      const sections = builder.getSections();
      expect(sections).toHaveLength(1);
      expect(sections[0]).toMatchObject({
        type: "xml-tag",
        tag: "critical",
        content: "This is critical",
      });
    });

    it("should trim whitespace from tag and content", () => {
      const builder = createPromptBuilder().withXmlTag("  critical  ", "  This is critical  ");
      const sections = builder.getSections();
      expect(sections[0]?.tag).toBe("critical");
      expect(sections[0]?.content).toBe("This is critical");
    });
  });

  describe("withTemplate", () => {
    it("should store template separately from sections", () => {
      const builder = createPromptBuilder().withTemplate("prd_template", "Template content");
      const sections = builder.getSections();
      expect(sections).toHaveLength(0); // Templates are not in sections
    });

    it("should append template at end of system prompt with separator", () => {
      const builder = createPromptBuilder()
        .withIdentity("You are a PRD specialist")
        .withTemplate("prd_template", "Template content here");
      const systemPrompt = builder.buildSystemPrompt();
      expect(systemPrompt).toContain("You are a PRD specialist");
      expect(systemPrompt).toContain("=== TEMPLATES ===");
      expect(systemPrompt).toContain("<prd_template>");
      expect(systemPrompt).toContain("Template content here");
      expect(systemPrompt).toContain("</prd_template>");
      // Template should be at the end
      const templateIndex = systemPrompt.indexOf("<prd_template>");
      const identityIndex = systemPrompt.indexOf("You are a PRD specialist");
      expect(templateIndex).toBeGreaterThan(identityIndex);
      // Separator should appear before templates
      const separatorIndex = systemPrompt.indexOf("=== TEMPLATES ===");
      expect(separatorIndex).toBeLessThan(templateIndex);
    });

    it("should append template at end of full prompt with separator", () => {
      const builder = createPromptBuilder()
        .withIdentity("You are a PRD specialist")
        .withTemplate("prd_template", "Template content here");
      const prompt = builder.build();
      expect(prompt).toContain("=== TEMPLATES ===");
      expect(prompt).toContain("<prd_template>");
      expect(prompt).toContain("Template content here");
      expect(prompt).toContain("</prd_template>");
    });

    it("should trim whitespace from tag name and content", () => {
      const builder = createPromptBuilder().withTemplate(
        "  prd_template  ",
        "  Template content  "
      );
      const systemPrompt = builder.buildSystemPrompt();
      expect(systemPrompt).toContain("<prd_template>");
      expect(systemPrompt).toContain("Template content");
    });

    it("should throw error for empty tag name", () => {
      expect(() => {
        createPromptBuilder().withTemplate("", "Content");
      }).toThrow();
    });

    it("should throw error for empty content", () => {
      expect(() => {
        createPromptBuilder().withTemplate("prd_template", "");
      }).toThrow();
    });

    it("should throw error for invalid tag name characters", () => {
      expect(() => {
        createPromptBuilder().withTemplate("prd template", "Content");
      }).toThrow();
    });

    it("should support multiple templates with separator", () => {
      const builder = createPromptBuilder()
        .withTemplate("prd_template", "PRD template")
        .withTemplate("techspec_template", "TechSpec template");
      const systemPrompt = builder.buildSystemPrompt();
      expect(systemPrompt).toContain("=== TEMPLATES ===");
      expect(systemPrompt).toContain("<prd_template>");
      expect(systemPrompt).toContain("PRD template");
      expect(systemPrompt).toContain("<techspec_template>");
      expect(systemPrompt).toContain("TechSpec template");
    });

    it("should preserve templates when extending builder", () => {
      const builder = createPromptBuilder().withTemplate("prd_template", "Template content");
      const extended = builder.extend();
      const systemPrompt = extended.buildSystemPrompt();
      expect(systemPrompt).toContain("<prd_template>");
      expect(systemPrompt).toContain("Template content");
    });

    it("should merge templates when merging builders", () => {
      const builder1 = createPromptBuilder().withTemplate("prd_template", "PRD template");
      const builder2 = createPromptBuilder().withTemplate("techspec_template", "TechSpec template");
      const merged = builder1.merge(builder2);
      const systemPrompt = merged.buildSystemPrompt();
      expect(systemPrompt).toContain("<prd_template>");
      expect(systemPrompt).toContain("PRD template");
      expect(systemPrompt).toContain("<techspec_template>");
      expect(systemPrompt).toContain("TechSpec template");
    });

    it("should allow template references in prompt text", () => {
      const builder = createPromptBuilder()
        .withSection("Instructions", "Follow the <prd_template> when building")
        .withTemplate("prd_template", "Template content");
      const systemPrompt = builder.buildSystemPrompt();
      // Reference should remain as-is
      expect(systemPrompt).toContain("Follow the <prd_template> when building");
      // Template should appear at end
      expect(systemPrompt).toContain("<prd_template>");
      expect(systemPrompt).toContain("Template content");
    });
  });

  describe("withDocRef", () => {
    it("should store reference separately from sections", () => {
      const builder = createPromptBuilder()
        .withSection("Section", "Section content")
        .withDocRef("prd_ref", "Reference content");
      const sections = builder.getSections();
      expect(sections).toHaveLength(1);
      expect(sections[0]?.content).toBe("Section content");
    });

    it("should append reference at end of system prompt with separator", () => {
      const builder = createPromptBuilder()
        .withIdentity("You are a TechSpec specialist")
        .withDocRef("prd_ref", "PRD content here");
      const systemPrompt = builder.buildSystemPrompt();
      expect(systemPrompt).toContain("You are a TechSpec specialist");
      expect(systemPrompt).toContain("=== REFERENCES ===");
      expect(systemPrompt).toContain("<prd_ref>");
      expect(systemPrompt).toContain("PRD content here");
      expect(systemPrompt).toContain("</prd_ref>");
      // Reference should be at the end
      const refIndex = systemPrompt.indexOf("<prd_ref>");
      const identityIndex = systemPrompt.indexOf("You are a TechSpec specialist");
      expect(refIndex).toBeGreaterThan(identityIndex);
      // Separator should appear before references
      const separatorIndex = systemPrompt.indexOf("=== REFERENCES ===");
      expect(separatorIndex).toBeLessThan(refIndex);
    });

    it("should append reference at end of full prompt with separator", () => {
      const builder = createPromptBuilder()
        .withIdentity("You are a TechSpec specialist")
        .withDocRef("prd_ref", "PRD content here");
      const prompt = builder.build();
      expect(prompt).toContain("=== REFERENCES ===");
      expect(prompt).toContain("<prd_ref>");
      expect(prompt).toContain("PRD content here");
      expect(prompt).toContain("</prd_ref>");
    });

    it("should trim whitespace from tag name and content", () => {
      const builder = createPromptBuilder().withDocRef("  prd_ref  ", "  Reference content  ");
      const systemPrompt = builder.buildSystemPrompt();
      expect(systemPrompt).toContain("<prd_ref>");
      expect(systemPrompt).toContain("Reference content");
    });

    it("should throw error for empty tag name", () => {
      expect(() => {
        createPromptBuilder().withDocRef("", "Content");
      }).toThrow();
    });

    it("should throw error for empty content", () => {
      expect(() => {
        createPromptBuilder().withDocRef("prd_ref", "");
      }).toThrow();
    });

    it("should throw error for invalid tag name characters", () => {
      expect(() => {
        createPromptBuilder().withDocRef("prd ref", "Content");
      }).toThrow();
    });

    it("should support multiple references with separator", () => {
      const builder = createPromptBuilder()
        .withDocRef("prd_ref", "PRD content")
        .withDocRef("techspec_ref", "TechSpec content");
      const systemPrompt = builder.buildSystemPrompt();
      expect(systemPrompt).toContain("=== REFERENCES ===");
      expect(systemPrompt).toContain("<prd_ref>");
      expect(systemPrompt).toContain("PRD content");
      expect(systemPrompt).toContain("<techspec_ref>");
      expect(systemPrompt).toContain("TechSpec content");
    });

    it("should append references after templates", () => {
      const builder = createPromptBuilder()
        .withTemplate("prd_template", "Template content")
        .withDocRef("prd_ref", "Reference content");
      const systemPrompt = builder.buildSystemPrompt();
      const templateIndex = systemPrompt.indexOf("=== TEMPLATES ===");
      const refIndex = systemPrompt.indexOf("=== REFERENCES ===");
      expect(refIndex).toBeGreaterThan(templateIndex);
    });

    it("should preserve references when extending builder", () => {
      const builder = createPromptBuilder().withDocRef("prd_ref", "Reference content");
      const extended = builder.extend();
      const systemPrompt = extended.buildSystemPrompt();
      expect(systemPrompt).toContain("<prd_ref>");
      expect(systemPrompt).toContain("Reference content");
    });

    it("should merge references when merging builders", () => {
      const builder1 = createPromptBuilder().withDocRef("prd_ref", "PRD content");
      const builder2 = createPromptBuilder().withDocRef("techspec_ref", "TechSpec content");
      const merged = builder1.merge(builder2);
      const systemPrompt = merged.buildSystemPrompt();
      expect(systemPrompt).toContain("<prd_ref>");
      expect(systemPrompt).toContain("PRD content");
      expect(systemPrompt).toContain("<techspec_ref>");
      expect(systemPrompt).toContain("TechSpec content");
    });

    it("should allow reference references in prompt text", () => {
      const builder = createPromptBuilder()
        .withSection("Instructions", "Check the <prd_ref> when building")
        .withDocRef("prd_ref", "Reference content");
      const systemPrompt = builder.buildSystemPrompt();
      expect(systemPrompt).toContain("Check the <prd_ref> when building");
      expect(systemPrompt).toContain("<prd_ref>");
      expect(systemPrompt).toContain("Reference content");
    });
  });

  describe("withCriticalSection", () => {
    it("should add critical section wrapped in <critical> tag", () => {
      const builder = createPromptBuilder().withCriticalSection("Always be helpful");
      const sections = builder.getSections();
      expect(sections).toHaveLength(1);
      expect(sections[0]).toMatchObject({
        type: "xml-tag",
        tag: "critical",
        content: "Always be helpful",
      });
    });
  });

  describe("extend", () => {
    it("should create immutable copy", () => {
      const original = createPromptBuilder().withIdentity("Original");
      const extended = original.extend().withContext("Extended");

      expect(original.getSections()).toHaveLength(1);
      expect(extended.getSections()).toHaveLength(2);
    });

    it("should not modify original when extending", () => {
      const original = createPromptBuilder().withIdentity("Original");
      const extended = original.extend();
      extended.withContext("Extended");

      expect(original.getSections()).toHaveLength(1);
      expect(extended.getSections()).toHaveLength(2);
    });
  });

  describe("merge", () => {
    it("should merge sections from another builder", () => {
      const builder1 = createPromptBuilder().withIdentity("Identity 1");
      const builder2 = createPromptBuilder().withContext("Context 2");
      const merged = builder1.merge(builder2);

      expect(merged.getSections()).toHaveLength(2);
      expect(merged.getSections()[0]?.content).toBe("Identity 1");
      expect(merged.getSections()[1]?.content).toBe("Context 2");
    });

    it("should not modify original builders", () => {
      const builder1 = createPromptBuilder().withIdentity("Identity 1");
      const builder2 = createPromptBuilder().withContext("Context 2");
      builder1.merge(builder2);

      expect(builder1.getSections()).toHaveLength(1);
      expect(builder2.getSections()).toHaveLength(1);
    });
  });

  describe("build", () => {
    it("should build simple identity prompt", () => {
      const prompt = createPromptBuilder().withIdentity("You are a helpful assistant").build();

      expect(prompt).toBe("You are a helpful assistant");
    });

    it("should build prompt with multiple sections", () => {
      const prompt = createPromptBuilder()
        .withIdentity("You are a helpful assistant")
        .withContext("Company: TechCorp")
        .withSection("Capabilities", "Answer questions")
        .build();

      expect(prompt).toContain("You are a helpful assistant");
      expect(prompt).toContain("Company: TechCorp");
      expect(prompt).toContain("## Capabilities");
      expect(prompt).toContain("Answer questions");
    });

    it("should build prompt with XML tags", () => {
      const prompt = createPromptBuilder().withXmlTag("critical", "This is critical").build();

      expect(prompt).toContain("<critical>");
      expect(prompt).toContain("This is critical");
      expect(prompt).toContain("</critical>");
    });

    it("should build prompt with critical section", () => {
      const prompt = createPromptBuilder().withCriticalSection("Always be helpful").build();

      expect(prompt).toContain("<critical>");
      expect(prompt).toContain("Always be helpful");
      expect(prompt).toContain("</critical>");
    });

    it("should join sections with double newlines", () => {
      const prompt = createPromptBuilder().withIdentity("Identity").withContext("Context").build();

      // Should have double newline between sections
      expect(prompt).toMatch(/Identity\n\nContext/);
    });

    it("should handle empty sections gracefully", () => {
      const builder = createPromptBuilder();
      // Add section then clear it (edge case)
      const prompt = builder.build();
      expect(prompt).toBe("");
    });
  });

  describe("chaining", () => {
    it("should support method chaining", () => {
      const prompt = createPromptBuilder()
        .withIdentity("Identity")
        .withContext("Context")
        .withSection("Section", "Content")
        .withCriticalSection("Critical")
        .build();

      expect(prompt).toContain("Identity");
      expect(prompt).toContain("Context");
      expect(prompt).toContain("Section");
      expect(prompt).toContain("Critical");
    });
  });

  describe("withCapability", () => {
    it("should add a single capability", () => {
      const builder = createPromptBuilder().withCapability("Answer questions");
      const prompt = builder.build();
      expect(prompt).toContain("## Capabilities");
      expect(prompt).toContain("1. Answer questions");
    });

    it("should ignore empty capabilities", () => {
      const builder = createPromptBuilder().withCapability("");
      const prompt = builder.build();
      expect(prompt).not.toContain("## Capabilities");
    });
  });

  describe("withCapabilities", () => {
    it("should add multiple capabilities", () => {
      const builder = createPromptBuilder().withCapabilities([
        "Answer questions",
        "Provide solutions",
        "Debug issues",
      ]);
      const prompt = builder.build();
      expect(prompt).toContain("## Capabilities");
      expect(prompt).toContain("1. Answer questions");
      expect(prompt).toContain("2. Provide solutions");
      expect(prompt).toContain("3. Debug issues");
    });

    it("should filter out empty capabilities", () => {
      const builder = createPromptBuilder().withCapabilities([
        "Answer questions",
        "",
        "Provide solutions",
      ]);
      const prompt = builder.build();
      expect(prompt).toContain("1. Answer questions");
      expect(prompt).toContain("2. Provide solutions");
      // Should not have a third item since empty was filtered
      expect(prompt.split("\n").filter(line => line.match(/^\d+\./))).toHaveLength(2);
    });
  });

  describe("withTool", () => {
    it("should add a tool", () => {
      const builder = createPromptBuilder().withTool({
        name: "search",
        description: "Search the web",
        schema: z.object({
          query: z.string().describe("Search query"),
        }),
      });
      expect(builder.hasTools()).toBe(true);
      expect(builder.getTools()).toHaveLength(1);
    });

    it("should throw error for empty tool name", () => {
      expect(() => {
        createPromptBuilder().withTool({
          name: "",
          description: "Description",
          schema: z.object({}),
        });
      }).toThrow();
    });

    it("should throw error for empty tool description", () => {
      expect(() => {
        createPromptBuilder().withTool({
          name: "tool",
          description: "",
          schema: z.object({}),
        });
      }).toThrow();
    });
  });

  describe("withTools", () => {
    it("should add multiple tools", () => {
      const builder = createPromptBuilder().withTools([
        {
          name: "search",
          description: "Search",
          schema: z.object({ query: z.string() }),
        },
        {
          name: "fetch",
          description: "Fetch",
          schema: z.object({ url: z.string() }),
        },
      ]);
      expect(builder.getTools()).toHaveLength(2);
    });
  });

  describe("withToolIf", () => {
    it("should add tool when condition is true", () => {
      const builder = createPromptBuilder().withToolIf(true, {
        name: "search",
        description: "Search",
        schema: z.object({ query: z.string() }),
      });
      expect(builder.hasTools()).toBe(true);
    });

    it("should not add tool when condition is false", () => {
      const builder = createPromptBuilder().withToolIf(false, {
        name: "search",
        description: "Search",
        schema: z.object({ query: z.string() }),
      });
      expect(builder.hasTools()).toBe(false);
    });
  });

  describe("withConstraint", () => {
    it("should add a constraint", () => {
      const builder = createPromptBuilder().withConstraint("must", "Always be helpful");
      expect(builder.hasConstraints()).toBe(true);
      expect(builder.getConstraints()).toHaveLength(1);
    });

    it("should throw error for empty constraint rule", () => {
      expect(() => {
        createPromptBuilder().withConstraint("must", "");
      }).toThrow();
    });
  });

  describe("withConstraints", () => {
    it("should add multiple constraints", () => {
      const builder = createPromptBuilder().withConstraints([
        { type: "must", rule: "Rule 1" },
        { type: "should", rule: "Rule 2" },
      ]);
      expect(builder.getConstraints()).toHaveLength(2);
    });
  });

  describe("withConstraintIf", () => {
    it("should add constraint when condition is true", () => {
      const builder = createPromptBuilder().withConstraintIf(true, "must", "Rule");
      expect(builder.hasConstraints()).toBe(true);
    });

    it("should not add constraint when condition is false", () => {
      const builder = createPromptBuilder().withConstraintIf(false, "must", "Rule");
      expect(builder.hasConstraints()).toBe(false);
    });

    it("should add multiple constraints when array provided", () => {
      const builder = createPromptBuilder().withConstraintIf(true, "must", ["Rule 1", "Rule 2"]);
      expect(builder.getConstraints()).toHaveLength(2);
    });
  });

  describe("withExample", () => {
    it("should add example with user/assistant", () => {
      const builder = createPromptBuilder().withExample({
        user: "Hello",
        assistant: "Hi there!",
      });
      const prompt = builder.build();
      expect(prompt).toContain("## Examples");
      expect(prompt).toContain("Hello");
      expect(prompt).toContain("Hi there!");
    });

    it("should add example with input/output", () => {
      const builder = createPromptBuilder().withExample({
        input: "Query",
        output: "Result",
      });
      const prompt = builder.build();
      expect(prompt).toContain("Query");
      expect(prompt).toContain("Result");
    });

    it("should include explanation if provided", () => {
      const builder = createPromptBuilder().withExample({
        user: "Hello",
        assistant: "Hi",
        explanation: "Shows greeting",
      });
      const prompt = builder.build();
      expect(prompt).toContain("Shows greeting");
    });

    it("should throw error for invalid example", () => {
      expect(() => {
        createPromptBuilder().withExample({
          user: "Hello",
        } as never);
      }).toThrow();
    });
  });

  describe("withExamples", () => {
    it("should add multiple examples", () => {
      const builder = createPromptBuilder().withExamples([
        { user: "Hello", assistant: "Hi" },
        { input: "Query", output: "Result" },
      ]);
      const prompt = builder.build();
      expect(prompt).toContain("Example 1");
      expect(prompt).toContain("Example 2");
    });
  });

  describe("withTone", () => {
    it("should set tone", () => {
      const builder = createPromptBuilder().withTone("Friendly and helpful");
      const prompt = builder.build();
      expect(prompt).toContain("## Tone");
      expect(prompt).toContain("Friendly and helpful");
    });

    it("should throw error for empty tone", () => {
      expect(() => {
        createPromptBuilder().withTone("");
      }).toThrow();
    });
  });

  describe("hasIdentity", () => {
    it("should return false when no identity", () => {
      const builder = createPromptBuilder();
      expect(builder.hasIdentity()).toBe(false);
    });

    it("should return true when identity is set", () => {
      const builder = createPromptBuilder().withIdentity("Identity");
      expect(builder.hasIdentity()).toBe(true);
    });
  });

  describe("hasTools", () => {
    it("should return false when no tools", () => {
      const builder = createPromptBuilder();
      expect(builder.hasTools()).toBe(false);
    });

    it("should return true when tools are added", () => {
      const builder = createPromptBuilder().withTool({
        name: "search",
        description: "Search",
        schema: z.object({}),
      });
      expect(builder.hasTools()).toBe(true);
    });
  });

  describe("hasConstraints", () => {
    it("should return false when no constraints", () => {
      const builder = createPromptBuilder();
      expect(builder.hasConstraints()).toBe(false);
    });

    it("should return true when constraints are added", () => {
      const builder = createPromptBuilder().withConstraint("must", "Rule");
      expect(builder.hasConstraints()).toBe(true);
    });
  });

  describe("getSummary", () => {
    it("should return summary of builder state", () => {
      const builder = createPromptBuilder()
        .withIdentity("Identity")
        .withCapabilities(["Cap1", "Cap2"])
        .withTool({
          name: "tool",
          description: "Tool",
          schema: z.object({}),
        })
        .withConstraint("must", "Rule")
        .withExample({ user: "Hello", assistant: "Hi" })
        .withTone("Friendly");

      const summary = builder.getSummary();
      expect(summary.hasIdentity).toBe(true);
      expect(summary.capabilitiesCount).toBe(2);
      expect(summary.toolsCount).toBe(1);
      expect(summary.constraintsCount).toBe(1);
      expect(summary.examplesCount).toBe(1);
      expect(summary.hasTone).toBe(true);
    });
  });

  describe("getConstraintsByType", () => {
    it("should filter constraints by type", () => {
      const builder = createPromptBuilder()
        .withConstraint("must", "Must rule")
        .withConstraint("should", "Should rule")
        .withConstraint("must", "Another must");

      const mustConstraints = builder.getConstraintsByType("must");
      expect(mustConstraints).toHaveLength(2);
      expect(mustConstraints[0]?.rule).toBe("Must rule");
      expect(mustConstraints[1]?.rule).toBe("Another must");
    });
  });

  describe("extend with new features", () => {
    it("should copy capabilities, tools, constraints, examples, and tone", () => {
      const original = createPromptBuilder()
        .withCapability("Cap1")
        .withTool({
          name: "tool",
          description: "Tool",
          schema: z.object({}),
        })
        .withConstraint("must", "Rule")
        .withExample({ user: "Hello", assistant: "Hi" })
        .withTone("Friendly");

      const extended = original.extend().withCapability("Cap2");

      expect(extended.getSummary().capabilitiesCount).toBe(2);
      expect(extended.getSummary().toolsCount).toBe(1);
      expect(extended.getSummary().constraintsCount).toBe(1);
      expect(extended.getSummary().examplesCount).toBe(1);
      expect(extended.getSummary().hasTone).toBe(true);
    });
  });

  describe("merge with new features", () => {
    it("should merge capabilities, tools, constraints, examples, and tone", () => {
      const builder1 = createPromptBuilder()
        .withCapability("Cap1")
        .withTool({
          name: "tool1",
          description: "Tool1",
          schema: z.object({}),
        })
        .withConstraint("must", "Rule1")
        .withTone("Friendly");

      const builder2 = createPromptBuilder()
        .withCapability("Cap2")
        .withTool({
          name: "tool2",
          description: "Tool2",
          schema: z.object({}),
        })
        .withConstraint("should", "Rule2")
        .withExample({ user: "Hello", assistant: "Hi" });

      const merged = builder1.merge(builder2);

      expect(merged.getSummary().capabilitiesCount).toBe(2);
      expect(merged.getSummary().toolsCount).toBe(2);
      expect(merged.getSummary().constraintsCount).toBe(2);
      expect(merged.getSummary().examplesCount).toBe(1);
      expect(merged.getSummary().hasTone).toBe(true);
    });
  });

  describe("build with new features", () => {
    it("should include capabilities, tools, constraints, examples, and tone in output", () => {
      const prompt = createPromptBuilder()
        .withIdentity("You are a helpful assistant")
        .withCapabilities(["Answer questions", "Provide solutions"])
        .withTool({
          name: "search",
          description: "Search the web",
          schema: z.object({
            query: z.string().describe("Search query"),
          }),
        })
        .withConstraint("must", "Always be helpful")
        .withConstraint("should", "Be concise")
        .withExample({
          user: "Hello",
          assistant: "Hi! How can I help?",
          explanation: "Shows greeting",
        })
        .withTone("Friendly and professional")
        .build();

      expect(prompt).toContain("You are a helpful assistant");
      expect(prompt).toContain("## Capabilities");
      expect(prompt).toContain("1. Answer questions");
      expect(prompt).toContain("## Available Tools");
      expect(prompt).toContain("search");
      expect(prompt).toContain("## Constraints");
      expect(prompt).toContain("**Must:**");
      expect(prompt).toContain("Always be helpful");
      expect(prompt).toContain("**Should:**");
      expect(prompt).toContain("Be concise");
      expect(prompt).toContain("## Examples");
      expect(prompt).toContain("Hello");
      expect(prompt).toContain("Hi! How can I help?");
      expect(prompt).toContain("Shows greeting");
      expect(prompt).toContain("## Tone");
      expect(prompt).toContain("Friendly and professional");
    });
  });

  describe("withFormat", () => {
    it("should set format to markdown by default", () => {
      const builder = createPromptBuilder().withIdentity("Test");
      const prompt = builder.build();
      expect(prompt).toContain("Test");
    });

    it("should set format to compact", () => {
      const builder = createPromptBuilder().withIdentity("Test").withFormat("compact");
      const prompt = builder.build();
      expect(prompt).toContain("Test");
    });

    it("should set format to toon", () => {
      const builder = createPromptBuilder().withIdentity("Test").withFormat("toon");
      const prompt = builder.build();
      expect(prompt).toContain("Identity:");
      expect(prompt).toContain("Test");
    });
  });

  describe("build with format parameter", () => {
    it("should use configured format when no parameter provided", () => {
      const builder = createPromptBuilder().withIdentity("Test").withFormat("toon");
      const prompt = builder.build();
      expect(prompt).toContain("Identity:");
    });

    it("should override format with parameter", () => {
      const builder = createPromptBuilder().withIdentity("Test").withFormat("toon");
      const markdownPrompt = builder.build("markdown");
      expect(markdownPrompt).toContain("Test");
      expect(markdownPrompt).not.toContain("Identity:");
    });
  });

  describe("extend with format", () => {
    it("should copy format in extend", () => {
      const original = createPromptBuilder().withIdentity("Test").withFormat("toon");
      const extended = original.extend();
      const prompt = extended.build();
      expect(prompt).toContain("Identity:");
    });
  });

  describe("validate", () => {
    it("should return ValidationResult with correct structure", () => {
      const builder = createPromptBuilder().withIdentity("Test");
      const result = builder.validate();

      expect(result).toHaveProperty("valid");
      expect(result).toHaveProperty("errors");
      expect(result).toHaveProperty("warnings");
      expect(result).toHaveProperty("info");
      expect(Array.isArray(result.errors)).toBe(true);
      expect(Array.isArray(result.warnings)).toBe(true);
      expect(Array.isArray(result.info)).toBe(true);
    });

    it("should detect duplicate tools", () => {
      const builder = createPromptBuilder()
        .withIdentity("Test")
        .withTool({
          name: "search",
          description: "Search tool",
          schema: z.object({ query: z.string() }),
        })
        .withTool({
          name: "search",
          description: "Another search tool",
          schema: z.object({ query: z.string() }),
        });

      const result = builder.validate();
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.code === "DUPLICATE_TOOL")).toBe(true);
    });

    it("should warn on missing identity", () => {
      const builder = createPromptBuilder();
      const result = builder.validate();

      expect(result.warnings.some(w => w.code === "MISSING_IDENTITY")).toBe(true);
    });

    it("should warn on empty capabilities", () => {
      const builder = createPromptBuilder().withIdentity("Test");
      const result = builder.validate();

      expect(result.warnings.some(w => w.code === "EMPTY_CAPABILITIES")).toBe(true);
    });

    it("should provide recommendations for tools without examples", () => {
      const builder = createPromptBuilder()
        .withIdentity("Test")
        .withTool({
          name: "search",
          description: "Search tool",
          schema: z.object({ query: z.string() }),
        });

      const result = builder.validate();
      expect(result.info.some(i => i.code === "TOOLS_WITHOUT_EXAMPLES")).toBe(true);
    });

    it("should respect validator config", () => {
      const builder = createPromptBuilder();
      const result = builder.validate({
        checkIdentity: false,
      });

      expect(result.warnings.filter(w => w.code === "MISSING_IDENTITY")).toHaveLength(0);
    });

    it("should use withValidatorConfig", () => {
      const builder = createPromptBuilder().withValidatorConfig({
        checkIdentity: false,
      });

      const result = builder.validate();
      expect(result.warnings.filter(w => w.code === "MISSING_IDENTITY")).toHaveLength(0);
    });

    it("should merge validator config with per-call config", () => {
      const builder = createPromptBuilder().withValidatorConfig({
        checkIdentity: false,
      });

      // Per-call config should override
      const result = builder.validate({
        checkIdentity: true,
      });

      expect(result.warnings.some(w => w.code === "MISSING_IDENTITY")).toBe(true);
    });
  });

  describe("debug", () => {
    it("should return builder for chaining", () => {
      const builder = createPromptBuilder().withIdentity("Test");
      const result = builder.debug();
      expect(result).toBe(builder);
    });

    it("should log debug information", () => {
      const consoleSpy = vi.spyOn(console, "log").mockImplementation(() => {});
      try {
        createPromptBuilder()
          .withIdentity("Test Assistant")
          .withCapabilities(["Answer questions"])
          .withTool({
            name: "search",
            description: "Search tool",
            schema: z.object({ query: z.string() }),
          })
          .debug();

        expect(consoleSpy).toHaveBeenCalled();
        const output = consoleSpy.mock.calls.map(args => args.join(" ")).join("\n");
        expect(output).toContain("PromptBuilder Debug");
        expect(output).toContain("Test Assistant");
        expect(output).toContain("Capabilities");
        expect(output).toContain("Tools");
        expect(output).toContain("Token Estimates");
      } finally {
        consoleSpy.mockRestore();
      }
    });

    it("should include validation results in debug output", () => {
      const consoleSpy = vi.spyOn(console, "log").mockImplementation(() => {});
      try {
        createPromptBuilder().withCapabilities(["Answer questions"]).debug();

        const output = consoleSpy.mock.calls.map(args => args.join(" ")).join("\n");
        expect(output).toContain("Validation");
      } finally {
        consoleSpy.mockRestore();
      }
    });

    it("should show prompt preview in debug output", () => {
      const consoleSpy = vi.spyOn(console, "log").mockImplementation(() => {});
      try {
        createPromptBuilder().withIdentity("Test Assistant").debug();

        const output = consoleSpy.mock.calls.map(args => args.join(" ")).join("\n");
        expect(output).toContain("Prompt Preview");
        expect(output).toContain("Test Assistant");
      } finally {
        consoleSpy.mockRestore();
      }
    });

    it("should show token estimates for all formats", () => {
      const consoleSpy = vi.spyOn(console, "log").mockImplementation(() => {});
      try {
        createPromptBuilder().withIdentity("Test").debug();

        const output = consoleSpy.mock.calls.map(args => args.join(" ")).join("\n");
        expect(output).toContain("Token Estimates");
        expect(output).toContain("Markdown format");
        expect(output).toContain("Compact format");
        expect(output).toContain("TOON format");
      } finally {
        consoleSpy.mockRestore();
      }
    });
  });

  describe("withAgent", () => {
    it("should add an agent", () => {
      const builder = createPromptBuilder().withAgent({
        name: "@testAgent",
        purpose: "Test agent",
        useWhen: "When testing",
        capabilities: ["Test capability"],
      });
      expect(builder.hasAgents()).toBe(true);
      expect(builder.getAgents()).toHaveLength(1);
      expect(builder.getAgents()[0]?.name).toBe("@testAgent");
    });

    it("should throw error for empty agent name", () => {
      expect(() => {
        createPromptBuilder().withAgent({
          name: "",
          purpose: "Purpose",
          useWhen: "When",
          capabilities: [],
        });
      }).toThrow();
    });

    it("should throw error for empty agent purpose", () => {
      expect(() => {
        createPromptBuilder().withAgent({
          name: "@agent",
          purpose: "",
          useWhen: "When",
          capabilities: [],
        });
      }).toThrow();
    });
  });

  describe("withAgents", () => {
    it("should add multiple agents", () => {
      const builder = createPromptBuilder().withAgents([
        {
          name: "@agent1",
          purpose: "Purpose 1",
          useWhen: "When 1",
          capabilities: [],
        },
        {
          name: "@agent2",
          purpose: "Purpose 2",
          useWhen: "When 2",
          capabilities: [],
        },
      ]);
      expect(builder.getAgents()).toHaveLength(2);
    });
  });

  describe("withAgentIf", () => {
    it("should add agent when condition is true", () => {
      const builder = createPromptBuilder().withAgentIf(true, {
        name: "@agent",
        purpose: "Purpose",
        useWhen: "When",
        capabilities: [],
      });
      expect(builder.hasAgents()).toBe(true);
    });

    it("should not add agent when condition is false", () => {
      const builder = createPromptBuilder().withAgentIf(false, {
        name: "@agent",
        purpose: "Purpose",
        useWhen: "When",
        capabilities: [],
      });
      expect(builder.hasAgents()).toBe(false);
    });
  });

  describe("hasAgents", () => {
    it("should return false when no agents", () => {
      const builder = createPromptBuilder();
      expect(builder.hasAgents()).toBe(false);
    });

    it("should return true when agents are added", () => {
      const builder = createPromptBuilder().withAgent({
        name: "@agent",
        purpose: "Purpose",
        useWhen: "When",
        capabilities: [],
      });
      expect(builder.hasAgents()).toBe(true);
    });
  });

  describe("getAgents", () => {
    it("should return all registered agents", () => {
      const builder = createPromptBuilder().withAgents([
        {
          name: "@agent1",
          purpose: "Purpose 1",
          useWhen: "When 1",
          capabilities: ["Cap1"],
        },
        {
          name: "@agent2",
          purpose: "Purpose 2",
          useWhen: "When 2",
          capabilities: ["Cap2"],
          exampleUsage: "Example",
          bestFor: "Best for",
        },
      ]);
      const agents = builder.getAgents();
      expect(agents).toHaveLength(2);
      expect(agents[0]?.name).toBe("@agent1");
      expect(agents[1]?.name).toBe("@agent2");
      expect(agents[1]?.exampleUsage).toBe("Example");
      expect(agents[1]?.bestFor).toBe("Best for");
    });
  });

  describe("extend with agents", () => {
    it("should copy agents in extend", () => {
      const original = createPromptBuilder().withAgent({
        name: "@agent1",
        purpose: "Purpose 1",
        useWhen: "When 1",
        capabilities: [],
      });
      const extended = original.extend().withAgent({
        name: "@agent2",
        purpose: "Purpose 2",
        useWhen: "When 2",
        capabilities: [],
      });

      expect(original.getAgents()).toHaveLength(1);
      expect(extended.getAgents()).toHaveLength(2);
    });
  });

  describe("merge with agents", () => {
    it("should merge agents from another builder", () => {
      const builder1 = createPromptBuilder().withAgent({
        name: "@agent1",
        purpose: "Purpose 1",
        useWhen: "When 1",
        capabilities: [],
      });
      const builder2 = createPromptBuilder().withAgent({
        name: "@agent2",
        purpose: "Purpose 2",
        useWhen: "When 2",
        capabilities: [],
      });

      const merged = builder1.merge(builder2);
      expect(merged.getAgents()).toHaveLength(2);
      expect(merged.getAgents()[0]?.name).toBe("@agent1");
      expect(merged.getAgents()[1]?.name).toBe("@agent2");
    });
  });

  describe("getSummary with agents", () => {
    it("should include agents count in summary", () => {
      const builder = createPromptBuilder()
        .withAgent({
          name: "@agent1",
          purpose: "Purpose 1",
          useWhen: "When 1",
          capabilities: [],
        })
        .withAgent({
          name: "@agent2",
          purpose: "Purpose 2",
          useWhen: "When 2",
          capabilities: [],
        });

      const summary = builder.getSummary();
      expect(summary.agentsCount).toBe(2);
    });
  });

  describe("build with agents", () => {
    it("should include agents in output", () => {
      const prompt = createPromptBuilder()
        .withIdentity("You are a helpful assistant")
        .withAgent({
          name: "@fileExplorer",
          purpose: "File exploration",
          useWhen: "When exploring files",
          capabilities: ["Search files", "Read files"],
          exampleUsage: "@fileExplorer: Find auth files",
          bestFor: "Finding implementation files",
        })
        .build();

      expect(prompt).toContain("### Subagents");
      expect(prompt).toContain("@fileExplorer");
      expect(prompt).toContain("File exploration");
      expect(prompt).toContain("When exploring files");
      expect(prompt).toContain("Search files");
      expect(prompt).toContain("Find auth files");
      expect(prompt).toContain("Finding implementation files");
    });
  });

  describe("withOutput - Text-based formats", () => {
    it("should accept { content: string } for Markdown format", () => {
      const builder = createPromptBuilder().withOutput("Markdown", {
        content: "Return **bold** text",
      });
      const output = getOutput(builder);
      expect(output).toEqual({
        format: "Markdown",
        content: "Return **bold** text",
      });
    });

    it("should accept { content: string } for Text format", () => {
      const builder = createPromptBuilder().withOutput("Text", { content: "Plain text" });
      const output = getOutput(builder);
      expect(output?.format).toBe("Text");
      expect(output?.content).toBe("Plain text");
    });

    it("should accept { content: string } for YAML format", () => {
      const builder = createPromptBuilder().withOutput("YAML", { content: "key: value" });
      const output = getOutput(builder);
      expect(output?.format).toBe("YAML");
    });

    it("should accept { content: string } for XML format", () => {
      const builder = createPromptBuilder().withOutput("XML", {
        content: "<root>content</root>",
      });
      const output = getOutput(builder);
      expect(output?.format).toBe("XML");
    });

    it("should trim whitespace from content", () => {
      const builder = createPromptBuilder().withOutput("Text", { content: "  Plain text  " });
      const output = getOutput(builder);
      expect(output?.content).toBe("Plain text");
    });

    it("should throw error for empty content", () => {
      expect(() => {
        createPromptBuilder().withOutput("Markdown", { content: "" });
      }).toThrow("Output content must be a non-empty string");
    });
  });

  describe("withOutput - Schema-based formats (Zod)", () => {
    it("should accept ZodTypeAny for JSON format and convert to JSON Schema", () => {
      const schema = z.object({
        type: z.literal("test"),
        value: z.string().describe("A test value"),
      });

      const builder = createPromptBuilder().withOutput("JSON", schema);
      const output = getOutput(builder);

      expect(output?.format).toBe("JSON");
      // Parse and validate JSON structure instead of substring checks
      const jsonSchema = JSON.parse(output!.content);
      expect(jsonSchema.type).toBe("object");
      expect(jsonSchema.properties).toBeTruthy();
    });

    it("should accept ZodTypeAny for Structured format", () => {
      const schema = z.object({
        items: z.array(z.string()),
      });

      const builder = createPromptBuilder().withOutput("Structured", schema);
      const output = getOutput(builder);

      expect(output?.format).toBe("Structured");
      // Parse and validate JSON structure instead of substring checks
      const jsonSchema = JSON.parse(output!.content);
      expect(jsonSchema.type).toBe("object");
    });

    it("should preserve Zod descriptions in JSON Schema output", () => {
      const schema = z.object({
        name: z.string().describe("The user's full name"),
      });

      const builder = createPromptBuilder().withOutput("JSON", schema);
      const output = getOutput(builder);

      // Parse and validate JSON structure
      const jsonSchema = JSON.parse(output!.content);
      expect(jsonSchema.properties.name.description).toBe("The user's full name");
    });

    it("should throw error for null/undefined schema", () => {
      expect(() => {
        createPromptBuilder().withOutput("JSON", null as unknown as z.ZodTypeAny);
      }).toThrow("Schema cannot be null or undefined");
    });
  });

  describe("withOutput - Code format", () => {
    it("should accept { content: string } for Code format", () => {
      const builder = createPromptBuilder().withOutput("Code", {
        content: "Return code only",
      });
      const output = getOutput(builder);

      expect(output?.format).toBe("Code");
      expect(output?.content).toBe("Return code only");
      expect(output?.language).toBeUndefined();
    });

    it("should accept { content: string; language?: string } with language", () => {
      const builder = createPromptBuilder().withOutput("Code", {
        content: "Return TypeScript code",
        language: "typescript",
      });
      const output = getOutput(builder);

      expect(output?.format).toBe("Code");
      expect(output?.content).toBe("Return TypeScript code");
      expect(output?.language).toBe("typescript");
    });

    it("should include language attribute in output XML", () => {
      const builder = createPromptBuilder()
        .withIdentity("Test")
        .withOutput("Code", { content: "Return Python code", language: "python" });

      const systemPrompt = builder.buildSystemPrompt();
      // Use regex to tolerate attribute ordering (format/language can be in any order)
      // Match <output> tag with both attributes present in any order
      expect(systemPrompt).toMatch(/<output\s+[^>]*format="Code"[^>]*>/);
      expect(systemPrompt).toMatch(/<output\s+[^>]*language="python"[^>]*>/);
    });

    it("should throw error for empty code content", () => {
      expect(() => {
        createPromptBuilder().withOutput("Code", { content: "" });
      }).toThrow("Output content must be a non-empty string");
    });

    it("should throw error for invalid language pattern", () => {
      expect(() => {
        createPromptBuilder().withOutput("Code", {
          content: "code",
          language: "type script",
        });
      }).toThrow(/Invalid language identifier/);
    });

    it("should throw error for language with special characters", () => {
      expect(() => {
        createPromptBuilder().withOutput("Code", {
          content: "code",
          language: '<script>alert("xss")</script>',
        });
      }).toThrow(/Invalid language identifier/);
    });

    it("should accept valid language patterns", () => {
      // Valid patterns: alphanumeric, underscores, plus signs, dots, hyphens
      const validLanguages = [
        "typescript",
        "c++",
        "c#",
        "objective-c",
        "f#",
        "node.js",
        "type_script",
      ];
      for (const lang of validLanguages) {
        const builder = createPromptBuilder().withOutput("Code", {
          content: "code",
          language: lang,
        });
        const output = getOutput(builder);
        expect(output?.language).toBe(lang);
      }
    });

    it("should throw error when Code config is not an object", () => {
      expect(() => {
        createPromptBuilder().withOutput("Code", "not an object" as unknown as { content: string });
      }).toThrow("Code format config must be an object");
    });

    it("should throw error when Text config is not an object", () => {
      expect(() => {
        createPromptBuilder().withOutput("Text", "not an object" as unknown as { content: string });
      }).toThrow("Text format config must be an object");
    });
  });

  describe("withOutput - XML safety", () => {
    it("should escape XML special characters in language attribute", () => {
      // Note: Invalid language patterns are already rejected by validation,
      // but we test that even if they somehow got through, escaping would occur
      const builder = createPromptBuilder()
        .withIdentity("Test")
        .withOutput("Code", { content: "Return code", language: "typescript" });

      const systemPrompt = builder.buildSystemPrompt();
      expect(systemPrompt).toMatch(/language="typescript"/);
    });

    it("should wrap output content in CDATA", () => {
      const builder = createPromptBuilder()
        .withIdentity("Test")
        .withOutput("Text", { content: "Content with </output> injection" });

      const systemPrompt = builder.buildSystemPrompt();
      expect(systemPrompt).toContain("<![CDATA[Content with </output> injection]]>");
    });

    it("should handle CDATA end markers in content", () => {
      const builder = createPromptBuilder()
        .withIdentity("Test")
        .withOutput("Text", { content: "Content with ]]> marker" });

      const systemPrompt = builder.buildSystemPrompt();
      // CDATA end markers should be escaped to prevent breaking out
      expect(systemPrompt).toContain("]]]]><![CDATA[>");
    });
  });

  describe("withOutput - buildSystemPrompt integration", () => {
    it("should include output section before templates", () => {
      const schema = z.object({ result: z.string() });
      const builder = createPromptBuilder()
        .withIdentity("Test")
        .withOutput("JSON", schema)
        .withTemplate("test_template", "Template content");

      const systemPrompt = builder.buildSystemPrompt();
      const outputIndex = systemPrompt.indexOf('<output format="JSON">');
      const templateIndex = systemPrompt.indexOf("=== TEMPLATES ===");

      expect(outputIndex).toBeGreaterThan(-1);
      expect(templateIndex).toBeGreaterThan(-1);
      expect(outputIndex).toBeLessThan(templateIndex);
    });

    it("should include format-specific enforcement message for JSON", () => {
      const schema = z.object({ data: z.string() });
      const builder = createPromptBuilder().withIdentity("Test").withOutput("JSON", schema);

      const systemPrompt = builder.buildSystemPrompt();
      // Check for key phrases instead of exact wording (reduces churn from copy edits)
      expect(systemPrompt).toMatch(/MANDATORY.*valid JSON/i);
      expect(systemPrompt).toMatch(/REQUIRED.*output instruction/i);
      expect(systemPrompt).toMatch(/CANNOT.*output.*message.*before/i);
    });

    it("should include format-specific enforcement message for Markdown", () => {
      const builder = createPromptBuilder()
        .withIdentity("Test")
        .withOutput("Markdown", { content: "Return markdown" });

      const systemPrompt = builder.buildSystemPrompt();
      // Check for key phrases instead of exact wording (reduces churn from copy edits)
      expect(systemPrompt).toMatch(/MANDATORY.*markdown/i);
      expect(systemPrompt).toMatch(/REQUIRED.*output instruction/i);
      expect(systemPrompt).toMatch(/CANNOT.*output.*message.*before/i);
    });

    it("should include output section before references", () => {
      const builder = createPromptBuilder()
        .withIdentity("Test")
        .withOutput("Text", { content: "Plain text output" })
        .withDocRef("test_ref", "Reference content");

      const systemPrompt = builder.buildSystemPrompt();
      const outputIndex = systemPrompt.indexOf('<output format="Text">');
      const refIndex = systemPrompt.indexOf("=== REFERENCES ===");

      expect(outputIndex).toBeGreaterThan(-1);
      expect(refIndex).toBeGreaterThan(-1);
      expect(outputIndex).toBeLessThan(refIndex);
    });

    it("should apply placeholder replacement to output content", () => {
      const builder = createPromptBuilder()
        .withPlaceholder("{{PLACEHOLDER}}", "replaced")
        .withOutput("Markdown", { content: "Content with {{PLACEHOLDER}}" });

      const systemPrompt = builder.buildSystemPrompt();
      // Content is now wrapped in CDATA for XML safety
      expect(systemPrompt).toContain("<![CDATA[Content with replaced]]>");
      expect(systemPrompt).not.toContain("{{PLACEHOLDER}}");
    });

    it("should not include output section if not set", () => {
      const builder = createPromptBuilder().withIdentity("Test");
      const systemPrompt = builder.buildSystemPrompt();
      expect(systemPrompt).not.toContain("<output");
    });
  });

  describe("extend with output", () => {
    it("should copy output configuration when extending", () => {
      const schema = z.object({ value: z.number() });
      const original = createPromptBuilder().withOutput("JSON", schema);
      const extended = original.extend().withIdentity("Extended");

      const originalOutput = getOutput(original);
      const extendedOutput = getOutput(extended);

      expect(extendedOutput?.format).toBe(originalOutput?.format);
      expect(extendedOutput?.content).toBe(originalOutput?.content);
      expect(extendedOutput).not.toBe(originalOutput);
    });

    it("should not copy output if not set", () => {
      const original = createPromptBuilder().withIdentity("Test");
      const extended = original.extend();

      const extendedOutput = getOutput(extended);
      expect(extendedOutput).toBeUndefined();
    });
  });

  describe("merge with output", () => {
    it("should use other builder's output when merging", () => {
      const schema = z.object({ a: z.string() });
      const builder1 = createPromptBuilder().withOutput("JSON", schema);
      const builder2 = createPromptBuilder().withOutput("Text", { content: "Output 2" });

      const merged = builder1.merge(builder2);
      const mergedOutput = getOutput(merged);

      expect(mergedOutput?.format).toBe("Text");
      expect(mergedOutput?.content).toBe("Output 2");
    });

    it("should keep first builder's output if second doesn't have one", () => {
      const schema = z.object({ b: z.number() });
      const builder1 = createPromptBuilder().withOutput("JSON", schema);
      const builder2 = createPromptBuilder().withIdentity("Test");

      const merged = builder1.merge(builder2);
      const mergedOutput = getOutput(merged);

      expect(mergedOutput?.format).toBe("JSON");
    });
  });
});
