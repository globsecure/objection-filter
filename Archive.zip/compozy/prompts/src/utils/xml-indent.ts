import { trim } from "es-toolkit/string";

/**
 * XML indentation utility for properly formatting nested XML tags
 */

/**
 * Regex pattern to match XML tags (opening, closing, self-closing)
 * Captures:
 * - Group 1: Forward slash if closing tag
 * - Group 2: Tag name
 * - Group 3: Attributes (if any)
 * - Group 4: Forward slash if self-closing
 */
const XML_TAG_REGEX = /<(\/?)([a-zA-Z0-9_.-]+)(\s[^/>]*(?:\s\/)?)?(\/?)>/g;

/**
 * Indents XML content based on nesting depth.
 * Tracks opening/closing tags and applies proper indentation to each line.
 *
 * @param content - XML content string (may contain nested tags)
 * @param baseIndent - Base indentation level in spaces (default: 0)
 * @returns Properly indented XML content
 */
export function indentXmlContent(content: string, baseIndent: number = 0): string {
  if (!content.trim()) {
    return content;
  }

  const lines = content.split("\n");
  const result: string[] = [];
  let depth = 0;
  const indentSize = 2; // 2 spaces per nesting level

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line === undefined) {
      continue;
    }
    const trimmedLine = trim(line);

    // Skip empty lines (preserve them as-is)
    if (!trimmedLine) {
      result.push(line);
      continue;
    }

    // Find all XML tags in this line
    const tags: Array<{ type: "open" | "close" | "self-closing"; index: number }> = [];
    let match: RegExpExecArray | null;

    // Reset regex lastIndex to ensure we match from the start of the line
    XML_TAG_REGEX.lastIndex = 0;

    while ((match = XML_TAG_REGEX.exec(trimmedLine)) !== null) {
      const isClosing = match[1] === "/";
      const isSelfClosing = match[4] === "/" || trimmedLine.endsWith("/>");

      if (isSelfClosing) {
        tags.push({ type: "self-closing", index: match.index });
      } else if (isClosing) {
        tags.push({ type: "close", index: match.index });
      } else {
        tags.push({ type: "open", index: match.index });
      }
    }

    // Calculate indentation for this line
    // If line starts with a closing tag, decrease depth first
    const firstTag = tags[0];
    let lineDepth = depth;

    if (firstTag && firstTag.type === "close") {
      lineDepth = Math.max(0, depth - 1);
    }

    // Apply indentation
    const indent = " ".repeat(baseIndent + lineDepth * indentSize);
    const indentedLine = indent + trimmedLine;
    result.push(indentedLine);

    // Update depth for next line based on tags in current line
    for (const tag of tags) {
      if (tag.type === "open") {
        depth++;
      } else if (tag.type === "close") {
        depth = Math.max(0, depth - 1);
      }
      // Self-closing tags don't change depth
    }
  }

  return result.join("\n");
}
