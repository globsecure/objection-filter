/**
 * @compozy/prompts - Structured, type-safe prompt building system
 *
 * Provides a fluent API for building prompts with support for:
 * - Basic sections (identity, context, sections)
 * - XML tags (<critical>, <prd>, <techspec>, etc.)
 * - Tool documentation
 * - Composition and extension
 *
 * This is a generic package - actual prompt templates should be created
 * in their respective packages (looper, agents) using this builder.
 */

export {
  PromptBuilder,
  createPromptBuilder,
  type OutputFormat,
  type TextBasedFormat,
  type SchemaBasedFormat,
  type CodeFormat,
  type OutputConfigMap,
  type OutputConfigFor,
  type OutputConfigInternal,
} from "./builder";
export type {
  PromptSection,
  PromptConfig,
  CriticalSection,
  CriticalSectionOptions,
  ToolDocumentationOptions,
  ConstraintType,
  Constraint,
  Example,
  ToolDefinition,
  AgentDefinition,
  PromptFormat,
  MessageRole,
  Message,
  PromptBuildResult,
  SectionPriority,
  ReasoningProtocol,
  SelfCorrectionConfig,
  ValidationSeverity,
  ValidationIssue,
  ValidationResult,
  ValidatorConfig,
} from "./types";

// Export validation utilities
export { PromptValidator, createValidator, formatValidationResult } from "./validation";

// Export section builders
export * from "./sections";

// Export formatter utilities
export { formatSystemPrompt, formatUserContext } from "./formatter";
