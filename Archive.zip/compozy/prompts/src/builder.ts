/**
 * PromptBuilder - Fluent API for building structured prompts
 *
 * Provides a type-safe, composable way to build prompts with support for:
 * - Basic sections (identity, context, sections)
 * - XML tags (<critical>, <prd>, <techspec>, etc.)
 * - Tool documentation
 * - Capabilities, constraints, examples, tone
 * - Composition and extension
 */

import { trim } from "es-toolkit/string";
import { invariant } from "es-toolkit/util";
import { z, type ZodTypeAny } from "zod";
import { formatPrompt, formatSystemPrompt, formatUserContext, type PromptData } from "./formatter";
import type {
  AgentDefinition,
  Constraint,
  ConstraintType,
  Example,
  Message,
  PromptBuildResult,
  PromptFormat,
  PromptSection,
  ReasoningProtocol,
  SectionPriority,
  SelfCorrectionConfig,
  ToolDefinition,
  ValidationResult,
  ValidatorConfig,
} from "./types";
import { PromptValidator } from "./validation";

/**
 * Supported output formats for the withOutput() method
 */
export type OutputFormat = "JSON" | "Text" | "Markdown" | "YAML" | "XML" | "Code" | "Structured";

/**
 * Formats that accept a simple content string
 */
export type TextBasedFormat = "Text" | "Markdown" | "YAML" | "XML";

/**
 * Formats that accept a Zod schema (converted to JSON Schema internally)
 */
export type SchemaBasedFormat = "JSON" | "Structured";

/**
 * Code format with optional language specification
 */
export type CodeFormat = "Code";

/**
 * Type map that maps each format to its required config type.
 * Uses conditional types to enforce different parameter shapes per format.
 */
export type OutputConfigMap = {
  Text: { content: string };
  Markdown: { content: string };
  YAML: { content: string };
  XML: { content: string };
  JSON: ZodTypeAny;
  Structured: ZodTypeAny;
  Code: { content: string; language?: string };
};

/**
 * Extracts the config type for a given format using indexed access
 */
export type OutputConfigFor<F extends OutputFormat> = OutputConfigMap[F];

/**
 * Internal normalized storage format (always string content after processing)
 */
export interface OutputConfigInternal {
  readonly format: OutputFormat;
  readonly content: string;
  readonly language?: string;
}

/**
 * Valid pattern for Code format language identifier.
 * Allows alphanumeric characters, underscores, plus signs, dots, hyphens, and hash (#) for C#/F#.
 */
const LANGUAGE_PATTERN = /^[a-zA-Z0-9_+.#-]+$/;

/**
 * Escape special characters in XML attribute values.
 * @private
 */
function escapeXmlAttribute(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

/**
 * Wrap content in CDATA section to prevent XML injection.
 * Handles nested CDATA markers by splitting into safe segments.
 * @private
 */
function wrapInCdata(content: string): string {
  // Handle edge case where content contains CDATA end marker
  // Split ]]> into ]]]]><![CDATA[> to safely escape it
  const safeContent = content.replace(/]]>/g, "]]]]><![CDATA[>");
  return `<![CDATA[${safeContent}]]>`;
}

export class PromptBuilder {
  private static readonly CHARS_PER_TOKEN = 4;

  private readonly sections: PromptSection[] = [];
  private readonly _capabilities: string[] = [];
  private readonly _tools: ToolDefinition[] = [];
  private readonly _agents: AgentDefinition[] = [];
  private readonly _constraints: Constraint[] = [];
  private readonly _examples: Example[] = [];
  private _templates: Map<string, string> = new Map();
  private _docReferences: Map<string, string> = new Map();
  private _placeholders: Map<string, string> = new Map();
  private _tone = "";
  private _format: PromptFormat = "markdown";
  private _validatorConfig?: ValidatorConfig;
  private _maxTokens?: number;
  private _reasoningProtocol?: ReasoningProtocol;
  private _selfCorrection?: SelfCorrectionConfig;
  private _toolApiMode = false;
  private _output?: OutputConfigInternal;

  /**
   * Set the agent's core identity or purpose
   */
  withIdentity(text: string): this {
    invariant(text.length > 0, "Identity cannot be empty");
    this.sections.push({
      type: "identity",
      content: trim(text),
    });
    return this;
  }

  /**
   * Provide domain-specific context and background knowledge
   */
  withContext(text: string): this {
    invariant(text.length > 0, "Context cannot be empty");
    this.sections.push({
      type: "context",
      content: trim(text),
    });
    return this;
  }

  /**
   * Add a titled section with content
   *
   * @param title - Section title
   * @param content - Section content
   * @param priority - Optional priority level for context window management
   */
  withSection(title: string, content: string, priority?: SectionPriority): this {
    invariant(title.length > 0, "Section title cannot be empty");
    invariant(content.length > 0, "Section content cannot be empty");
    const section: PromptSection = {
      type: "section",
      title: trim(title),
      content: trim(content),
    };
    if (priority !== undefined) {
      section.priority = priority;
    }
    this.sections.push(section);
    return this;
  }

  /**
   * Add content wrapped in an XML tag
   */
  withXmlTag(tag: string, content: string): this {
    invariant(tag.length > 0, "XML tag name cannot be empty");
    const trimmedTag = trim(tag);
    invariant(trimmedTag.length > 0, "XML tag name cannot be empty after trimming whitespace");
    invariant(
      /^[a-zA-Z0-9_.-]+$/.test(trimmedTag),
      "XML tag name contains invalid characters. Only alphanumeric characters, underscores, dots, and hyphens are allowed."
    );
    invariant(content.length > 0, "XML tag content cannot be empty");
    this.sections.push({
      type: "xml-tag",
      tag: trimmedTag,
      content: trim(content),
    });
    return this;
  }

  /**
   * Add a template that will be injected at the end of the system prompt.
   * Templates are stored separately and can be referenced in prompt text (e.g., `<prd_template>`)
   * while the full content appears at the end of the system prompt.
   *
   * @param tagName - Template tag name (e.g., "prd_template")
   * @param content - Template content
   */
  withTemplate(tagName: string, content: string): this {
    invariant(tagName.length > 0, "Template tag name cannot be empty");
    const trimmedTag = trim(tagName);
    invariant(trimmedTag.length > 0, "Template tag name cannot be empty after trimming whitespace");
    invariant(
      /^[a-zA-Z0-9_.-]+$/.test(trimmedTag),
      "Template tag name contains invalid characters. Only alphanumeric characters, underscores, dots, and hyphens are allowed."
    );
    invariant(content.length > 0, "Template content cannot be empty");
    this._templates.set(trimmedTag, trim(content));
    return this;
  }

  /**
   * Add a document reference that will be injected at the end of the system prompt.
   * Document references are stored separately and can be referenced in prompt text (e.g., `<prd_ref>`)
   * while the full content appears at the end of the system prompt after templates.
   *
   * @param tagName - Reference tag name (e.g., "prd_ref")
   * @param content - Reference content
   */
  withDocRef(tagName: string, content: string): this {
    invariant(tagName.length > 0, "Reference tag name cannot be empty");
    const trimmedTag = trim(tagName);
    invariant(
      trimmedTag.length > 0,
      "Reference tag name cannot be empty after trimming whitespace"
    );
    invariant(
      /^[a-zA-Z0-9_.-]+$/.test(trimmedTag),
      "Reference tag name contains invalid characters. Only alphanumeric characters, underscores, dots, and hyphens are allowed."
    );
    invariant(content.length > 0, "Reference content cannot be empty");
    this._docReferences.set(trimmedTag, trim(content));
    return this;
  }

  /**
   * Get format-specific mandatory enforcement message
   * @private
   */
  private getOutputEnforcementMessage(format: OutputFormat): string {
    switch (format) {
      case "JSON":
        return "MANDATORY: You MUST return ONLY valid JSON. Do not return YAML, markdown, or any other format. The response must be parseable JSON.";
      case "Text":
        return "MANDATORY: You MUST return plain text only. Do not use markdown formatting or code blocks.";
      case "Markdown":
        return "MANDATORY: You MUST return valid markdown formatted text.";
      case "YAML":
        return "MANDATORY: You MUST return valid YAML. Do not return JSON or other formats.";
      case "XML":
        return "MANDATORY: You MUST return valid XML.";
      case "Code":
        return "MANDATORY: You MUST return code in the specified language. Do not include explanations outside code blocks.";
      case "Structured":
        return "MANDATORY: You MUST return structured output in the exact format specified below.";
      default: {
        // Exhaustiveness check - ensures all OutputFormat cases are handled
        const exhaustive: never = format;
        invariant(false, `Unhandled output format: ${exhaustive}`);
      }
    }
  }

  /**
   * Set the required output format and schema for the agent's response.
   * The output section will be wrapped in XML with format-specific enforcement
   * and positioned at the end of the system prompt before templates/references.
   *
   * Uses TypeScript function overloads to enforce format-specific config types:
   * - Text/Markdown/YAML/XML: { content: string }
   * - JSON/Structured: ZodTypeAny (Zod schema, converted via z.toJSONSchema())
   * - Code: { content: string; language?: string }
   *
   * @example Text-based formats
   * ```typescript
   * builder.withOutput("Markdown", { content: "Return a **bold** summary" });
   * builder.withOutput("Text", { content: "Return plain text only" });
   * ```
   *
   * @example Schema-based formats (Zod schema)
   * ```typescript
   * const outputSchema = z.object({
   *   type: z.literal("task-output"),
   *   response: z.object({ summary: z.string() })
   * });
   * builder.withOutput("JSON", outputSchema);
   * builder.withOutput("Structured", outputSchema);
   * ```
   *
   * @example Code format with language
   * ```typescript
   * builder.withOutput("Code", { content: "Return TypeScript code", language: "typescript" });
   * ```
   */
  withOutput(format: TextBasedFormat, config: { content: string }): this;
  withOutput(format: SchemaBasedFormat, schema: ZodTypeAny): this;
  withOutput(format: CodeFormat, config: { content: string; language?: string }): this;
  withOutput<F extends OutputFormat>(format: F, config: OutputConfigFor<F>): this;
  withOutput(format: OutputFormat, config: unknown): this {
    let content: string;
    let language: string | undefined;

    if (format === "JSON" || format === "Structured") {
      invariant(config !== undefined && config !== null, "Schema cannot be null or undefined");
      const schema = config as ZodTypeAny;
      try {
        const jsonSchema = z.toJSONSchema(schema);
        content = JSON.stringify(jsonSchema, null, 2);
      } catch (error) {
        throw new Error(
          `Failed to convert Zod schema to JSON Schema for output format "${format}": ${error instanceof Error ? error.message : String(error)}`
        );
      }
    } else if (format === "Code") {
      // Validate config is an object before accessing properties
      invariant(
        config !== null && typeof config === "object",
        "Code format config must be an object with content property"
      );
      const codeConfig = config as { content?: unknown; language?: unknown };
      invariant(
        typeof codeConfig.content === "string" && codeConfig.content.length > 0,
        "Output content must be a non-empty string"
      );
      content = trim(codeConfig.content);
      // Validate language if provided
      if (codeConfig.language !== undefined) {
        invariant(typeof codeConfig.language === "string", "Code format language must be a string");
        invariant(
          LANGUAGE_PATTERN.test(codeConfig.language),
          `Invalid language identifier "${codeConfig.language}". Language must contain only alphanumeric characters, underscores, plus signs, dots, and hyphens.`
        );
        language = codeConfig.language;
      }
    } else {
      // Text-based formats (Text, Markdown, YAML, XML)
      // Validate config is an object before accessing properties
      invariant(
        config !== null && typeof config === "object",
        `${format} format config must be an object with content property`
      );
      const textConfig = config as { content?: unknown };
      invariant(
        typeof textConfig.content === "string" && textConfig.content.length > 0,
        "Output content must be a non-empty string"
      );
      content = trim(textConfig.content);
    }

    this._output = {
      format,
      content,
      ...(language && { language }),
    };
    return this;
  }

  /**
   * Add a critical section (wraps content in <critical> tag)
   */
  withCriticalSection(content: string): this {
    return this.withXmlTag("critical", trim(content));
  }

  /**
   * Adds a single capability to the agent's skillset.
   */
  withCapability(cap: string): this {
    if (cap && trim(cap).length > 0) {
      this._capabilities.push(trim(cap));
    }
    return this;
  }

  /**
   * Adds multiple capabilities at once.
   */
  withCapabilities(caps: string[]): this {
    const filtered = caps.filter(c => c && trim(c).length > 0).map(c => trim(c));
    this._capabilities.push(...filtered);
    return this;
  }

  /**
   * Registers a tool that the agent can use.
   */
  withTool<T extends import("zod").ZodType>(def: ToolDefinition<T>): this {
    invariant(def.name.length > 0, "Tool name cannot be empty");
    invariant(def.description.length > 0, "Tool description cannot be empty");
    this._tools.push(def);
    return this;
  }

  /**
   * Registers multiple tools at once.
   */
  withTools(defs: ToolDefinition[]): this {
    for (const def of defs) {
      this.withTool(def);
    }
    return this;
  }

  /**
   * Conditionally adds a tool based on a boolean condition.
   */
  withToolIf<T extends import("zod").ZodType>(condition: boolean, def: ToolDefinition<T>): this {
    if (condition) {
      this.withTool(def);
    }
    return this;
  }

  /**
   * Adds a subagent definition.
   */
  withAgent(agentDef: AgentDefinition): this {
    invariant(agentDef.name.length > 0, "Agent name cannot be empty");
    invariant(agentDef.purpose.length > 0, "Agent purpose cannot be empty");
    this._agents.push(agentDef);
    return this;
  }

  /**
   * Adds multiple agents at once.
   */
  withAgents(agentDefs: AgentDefinition[]): this {
    for (const agentDef of agentDefs) {
      this.withAgent(agentDef);
    }
    return this;
  }

  /**
   * Conditionally adds an agent based on a boolean condition.
   */
  withAgentIf(condition: boolean, agentDef: AgentDefinition): this {
    if (condition) {
      this.withAgent(agentDef);
    }
    return this;
  }

  /**
   * Adds a behavioral constraint.
   */
  withConstraint(type: ConstraintType, rule: string): this {
    invariant(rule.length > 0, "Constraint rule cannot be empty");
    this._constraints.push({ type, rule: trim(rule) });
    return this;
  }

  /**
   * Adds multiple constraints at once.
   */
  withConstraints(constraints: Constraint[]): this {
    for (const constraint of constraints) {
      this.withConstraint(constraint.type, constraint.rule);
    }
    return this;
  }

  /**
   * Conditionally adds a constraint or array of constraints.
   */
  withConstraintIf(condition: boolean, type: ConstraintType, rule: string | string[]): this {
    if (condition) {
      if (Array.isArray(rule)) {
        this.withConstraints(rule.map(r => ({ type, rule: r })));
      } else {
        this.withConstraint(type, rule);
      }
    }
    return this;
  }

  /**
   * Adds a single example for few-shot learning.
   */
  withExample(example: Example): this {
    invariant(
      (example.user && example.assistant) || (example.input && example.output),
      "Example must have either (user, assistant) or (input, output)"
    );
    this._examples.push(example);
    return this;
  }

  /**
   * Adds multiple examples at once.
   */
  withExamples(examples: Example[]): this {
    for (const example of examples) {
      this.withExample(example);
    }
    return this;
  }

  /**
   * Sets the communication tone and style.
   */
  withTone(text: string): this {
    invariant(text.length > 0, "Tone cannot be empty");
    this._tone = trim(text);
    return this;
  }

  /**
   * Enables Chain-of-Thought reasoning protocol with optional instructions.
   *
   * @param instructions - Optional custom instructions for reasoning protocol
   */
  withReasoningProtocol(instructions?: string): this {
    this._reasoningProtocol = {
      enabled: true,
      instructions:
        instructions ||
        "Think step-by-step before responding. Use <thinking> tags to show your reasoning process.",
      thinkingBlocks: [],
    };

    // Add thinking instructions as a regular section (not thinking type)
    // The "thinking" type is reserved for model output, not instructions
    const thinkingContent =
      instructions ||
      "Think step-by-step before responding. Use <thinking> tags to show your reasoning process.";
    this.sections.push({
      type: "section",
      title: "Reasoning Instructions",
      content: thinkingContent,
      priority: "high",
    });

    return this;
  }

  /**
   * Adds a thinking block for explicit reasoning steps.
   *
   * @param content - The thinking/reasoning content
   */
  withThinkingBlock(content: string): this {
    invariant(content.length > 0, "Thinking block content cannot be empty");
    this.sections.push({
      type: "thinking",
      content: trim(content),
      priority: "high",
    });

    if (this._reasoningProtocol) {
      this._reasoningProtocol.thinkingBlocks = this._reasoningProtocol.thinkingBlocks || [];
      this._reasoningProtocol.thinkingBlocks.push(trim(content));
    }

    return this;
  }

  /**
   * Convenience method for step-by-step reasoning.
   * Adds instructions to think through problems systematically.
   */
  withStepByStepReasoning(): this {
    return this.withReasoningProtocol(
      "Break down complex problems into smaller steps. Think through each step carefully before proceeding. Use <thinking> tags to show your reasoning process."
    );
  }

  /**
   * Adds a thinking tag helper (convenience wrapper).
   * Wraps content in <thinking> tags.
   *
   * @param content - Content to wrap in thinking tags
   */
  withThinking(content: string): this {
    invariant(content.length > 0, "Thinking content cannot be empty");
    return this.withXmlTag("thinking", trim(content));
  }

  /**
   * Sets the output format for the generated prompt.
   *
   * Available formats:
   * - `markdown`: Standard markdown format (default)
   * - `compact`: Minimal whitespace variant of markdown
   * - `toon`: TOON format (Token-Oriented Object Notation) - optimized for token efficiency
   */
  withFormat(format: PromptFormat): this {
    this._format = format;
    return this;
  }

  /**
   * Sets the maximum token limit for context window management.
   * When building, low-priority sections may be truncated if approaching this limit.
   *
   * @param maxTokens - Maximum token budget
   */
  withMaxTokens(maxTokens: number): this {
    invariant(maxTokens > 0, "Max tokens must be greater than 0");
    this._maxTokens = maxTokens;
    return this;
  }

  /**
   * Gets the current token usage estimate (approximate, based on character count).
   * Uses ~4 characters per token as a rough estimate.
   *
   * @param format - Optional format to estimate for
   */
  getTokenUsage(format?: PromptFormat): number {
    const targetFormat = format || this._format;
    const prompt = this.build(targetFormat);
    return Math.ceil(prompt.length / PromptBuilder.CHARS_PER_TOKEN);
  }

  /**
   * Adds self-correction criteria for output validation.
   *
   * @param criteria - Array of criteria to check after generating output
   */
  withSelfCorrection(criteria: string[]): this {
    invariant(criteria.length > 0, "Self-correction criteria cannot be empty");
    this._selfCorrection = {
      criteria: criteria.map(c => trim(c)),
      validationRules: [],
    };

    // Add verification instructions as a section
    const verificationContent = `<verify>\n${criteria.map(c => `- ${c}`).join("\n")}\n</verify>`;
    this.sections.push({
      type: "section",
      title: "Output Verification",
      content: verificationContent,
      priority: "high",
    });

    return this;
  }

  /**
   * Adds output validation rules for introspection patterns.
   *
   * @param validationRules - Array of validation rules to apply
   */
  withOutputValidation(validationRules: string[]): this {
    invariant(validationRules.length > 0, "Validation rules cannot be empty");

    if (!this._selfCorrection) {
      this._selfCorrection = {
        criteria: [],
        validationRules: validationRules.map(r => trim(r)),
      };
    } else {
      this._selfCorrection.validationRules = validationRules.map(r => trim(r));
    }

    // Add validation instructions
    const validationContent = `<check>\n${validationRules.map(r => `- ${r}`).join("\n")}\n</check>`;
    this.sections.push({
      type: "section",
      title: "Output Validation",
      content: validationContent,
      priority: "high",
    });

    return this;
  }

  /**
   * Enables tool API mode, which excludes tools from prompt text
   * when using native Anthropic SDK tool definitions.
   *
   * @param enabled - Whether to enable tool API mode (default: true)
   */
  withToolApiMode(enabled = true): this {
    this._toolApiMode = enabled;
    return this;
  }

  /**
   * Add a placeholder that will be replaced when building the final prompt.
   * Placeholders are replaced in all section content, XML tags, templates, and doc references.
   *
   * @param placeholder - Placeholder string (e.g., "{{TOOL_NAME_CLARIFICATION}}")
   * @param value - Value to replace the placeholder with
   */
  withPlaceholder(placeholder: string, value: string): this {
    invariant(placeholder.length > 0, "Placeholder cannot be empty");
    this._placeholders.set(placeholder, value);
    return this;
  }

  /**
   * Replace all placeholders in the given text.
   * @private
   */
  private replacePlaceholders(text: string): string {
    let result = text;
    for (const [placeholder, value] of this._placeholders) {
      result = result.replaceAll(placeholder, value);
    }
    return result;
  }

  /**
   * Process sections with placeholder replacement.
   * @private
   */
  private processSectionsWithPlaceholders(sections: PromptSection[]): PromptSection[] {
    return sections.map(section => {
      if (section.type === "section") {
        return {
          ...section,
          title: this.replacePlaceholders(section.title || ""),
          content: this.replacePlaceholders(section.content),
        };
      } else if (section.type === "xml-tag") {
        return {
          ...section,
          content: this.replacePlaceholders(section.content),
        };
      } else {
        return {
          ...section,
          content: this.replacePlaceholders(section.content),
        };
      }
    });
  }

  /**
   * Gets tools formatted for Anthropic SDK API.
   * Returns tools in the format expected by Anthropic's Messages API.
   * Automatically converts Zod schemas to JSON Schema format.
   *
   * @throws {Error} If Zod schema conversion fails
   */
  getToolsForApi(): Array<{
    name: string;
    description: string;
    input_schema: unknown;
  }> {
    return this._tools.map(tool => {
      try {
        return {
          name: tool.name,
          description: tool.description,
          input_schema: z.toJSONSchema(tool.schema),
        };
      } catch (error) {
        throw new Error(
          `Failed to convert Zod schema to JSON Schema for tool "${tool.name}": ${error instanceof Error ? error.message : String(error)}`
        );
      }
    });
  }

  /**
   * Gets tool definitions in API format (alias for getToolsForApi).
   */
  getToolDefinitions(): Array<{
    name: string;
    description: string;
    input_schema: unknown;
  }> {
    return this.getToolsForApi();
  }

  /**
   * Truncates context sections if token limit is exceeded.
   * Non-critical sections are truncated first, with low-priority sections truncated before medium/high.
   *
   * @param maxLength - Maximum character length (approximate). If not provided, uses _maxTokens * 4
   */
  truncateContext(maxLength?: number): this {
    // Calculate effective limit: use provided maxLength, fall back to _maxTokens * 4, or return early
    const effectiveMax =
      maxLength ??
      (this._maxTokens !== undefined ? this._maxTokens * PromptBuilder.CHARS_PER_TOKEN : undefined);

    if (!effectiveMax) {
      return this;
    }

    const currentLength = this.build().length;
    if (currentLength <= effectiveMax) {
      return this;
    }

    // Sort sections by priority (low priority first for truncation)
    const priorityOrder: Record<SectionPriority, number> = {
      critical: 4,
      high: 3,
      medium: 2,
      low: 1,
    };

    const sectionsToTruncate = [...this.sections].sort((a, b) => {
      const aPriority = a.priority ? priorityOrder[a.priority] : 2; // Default to medium
      const bPriority = b.priority ? priorityOrder[b.priority] : 2;
      return aPriority - bPriority; // Lower priority first
    });

    // Truncate non-critical sections (low priority first, then medium, then high)
    let truncatedLength = currentLength;
    for (const section of sectionsToTruncate) {
      if (truncatedLength <= effectiveMax) {
        break;
      }
      const sectionIndex = this.sections.indexOf(section);
      // Truncate anything that isn't critical
      if (sectionIndex >= 0 && section.priority !== "critical") {
        const sectionLength = section.content.length;
        const neededReduction = truncatedLength - effectiveMax;

        // For low-priority sections, try partial truncation if possible
        if (section.priority === "low" && sectionLength > neededReduction + 50) {
          this.sections[sectionIndex] = {
            ...section,
            content:
              section.content.slice(0, section.content.length - neededReduction - 50) + "...",
          };
          truncatedLength -= neededReduction;
        } else {
          // Remove entire section for medium/high priority or if low-priority section is too small
          this.sections.splice(sectionIndex, 1);
          truncatedLength -= sectionLength;
        }
      }
    }

    return this;
  }

  /**
   * Returns true if an identity has been set.
   */
  hasIdentity(): boolean {
    return this.sections.some(s => s.type === "identity");
  }

  /**
   * Returns true if at least one tool is registered.
   */
  hasTools(): boolean {
    return this._tools.length > 0;
  }

  /**
   * Returns true if at least one agent is registered.
   */
  hasAgents(): boolean {
    return this._agents.length > 0;
  }

  /**
   * Returns true if at least one constraint exists.
   */
  hasConstraints(): boolean {
    return this._constraints.length > 0;
  }

  /**
   * Returns all registered tools.
   */
  getTools(): readonly ToolDefinition[] {
    return this._tools;
  }

  /**
   * Returns all registered agents.
   */
  getAgents(): readonly AgentDefinition[] {
    return this._agents;
  }

  /**
   * Returns all constraints.
   */
  getConstraints(): readonly Constraint[] {
    return this._constraints;
  }

  /**
   * Returns constraints filtered by type.
   */
  getConstraintsByType(type: ConstraintType): readonly Constraint[] {
    return this._constraints.filter(c => c.type === type);
  }

  /**
   * Returns a summary of the builder state.
   */
  getSummary(): {
    hasIdentity: boolean;
    capabilitiesCount: number;
    toolsCount: number;
    agentsCount: number;
    constraintsCount: number;
    examplesCount: number;
    hasTone: boolean;
    format: PromptFormat;
  } {
    return {
      hasIdentity: this.hasIdentity(),
      capabilitiesCount: this._capabilities.length,
      toolsCount: this._tools.length,
      agentsCount: this._agents.length,
      constraintsCount: this._constraints.length,
      examplesCount: this._examples.length,
      hasTone: this._tone.length > 0,
      format: this._format,
    };
  }

  /**
   * Sets the default validator configuration for this builder.
   *
   * This configuration will be used when calling `validate()` without arguments.
   *
   * @param config - Validator configuration
   * @returns The builder instance for method chaining
   *
   * @example
   * ```typescript
   * builder
   *   .withValidatorConfig({
   *     checkDuplicateTools: true,
   *     checkIdentity: false
   *   })
   *   .validate(); // Uses the configured validator
   * ```
   */
  withValidatorConfig(config: ValidatorConfig): this {
    this._validatorConfig = config;
    return this;
  }

  /**
   * Validates the current builder configuration.
   *
   * Runs a comprehensive validation check on the builder state and returns
   * detailed information about errors, warnings, and suggestions. This is
   * useful for catching configuration issues before building the prompt.
   *
   * @param config - Optional validator configuration to customize validation rules
   * @returns A ValidationResult object containing validation status and issues
   *
   * @example
   * ```typescript
   * const builder = createPromptBuilder()
   *   .withIdentity("Customer service agent")
   *   .withCapability("Answer questions");
   *
   * const result = builder.validate();
   *
   * if (!result.valid) {
   *   console.error("Validation errors:", result.errors);
   * }
   *
   * if (result.warnings.length > 0) {
   *   console.warn("Validation warnings:", result.warnings);
   * }
   * ```
   */
  validate(config?: ValidatorConfig): ValidationResult {
    // Merge provided config with builder's default config
    const mergedConfig: ValidatorConfig = {
      ...this._validatorConfig,
      ...config,
    };

    const validator = new PromptValidator(mergedConfig);
    return validator.validate({
      identity: this.hasIdentity(),
      capabilities: this._capabilities,
      tools: this._tools,
      constraints: this._constraints,
      examples: this._examples,
      tone: this._tone.length > 0,
    });
  }

  /**
   * Outputs detailed debug information about the builder's current state.
   *
   * This method provides comprehensive logging of the builder's configuration,
   * including all sections, counts, warnings, and suggestions for improvement.
   * Useful for debugging, development, and understanding how the prompt will
   * be structured.
   *
   * The debug output includes:
   * - Configuration summary with counts
   * - Detailed section breakdowns
   * - Validation warnings (missing sections, potential issues)
   * - Suggestions for completeness
   * - Preview of the first 200 characters of the built prompt
   * - Token usage estimates for different formats
   *
   * @returns The builder instance for method chaining
   *
   * @example
   * ```typescript
   * const builder = createPromptBuilder()
   *   .withIdentity("Assistant")
   *   .withCapabilities(["Answer questions", "Provide help"])
   *   .withTool({ name: "search", description: "Search", schema: z.object({}) })
   *   .debug(); // Logs detailed information to console
   *
   * // Continue chaining after debug
   * const prompt = builder
   *   .debug()
   *   .withConstraint("must", "Be helpful")
   *   .build();
   * ```
   */
  debug(): this {
    const summary = this.getSummary();
    const lines: string[] = [];
    const PREVIEW_LENGTH = 200;

    // Configuration Summary
    lines.push("PromptBuilder Debug");
    lines.push("");
    lines.push(
      `Format: ${summary.format} | Identity: ${summary.hasIdentity ? "✓" : "✗"} | Capabilities: ${summary.capabilitiesCount} | Tools: ${summary.toolsCount}`
    );
    lines.push(
      `Constraints: ${summary.constraintsCount} | Examples: ${summary.examplesCount} | Tone: ${summary.hasTone ? "✓" : "✗"}`
    );
    lines.push("");

    // Detailed Breakdown
    if (summary.hasIdentity) {
      const identitySection = this.sections.find(s => s.type === "identity");
      const identityPreview = identitySection?.content.slice(0, 60) || "N/A";
      lines.push(`Identity: ${identityPreview}${identityPreview.length >= 60 ? "..." : ""}`);
    }

    if (summary.capabilitiesCount > 0) {
      lines.push(`Capabilities (${summary.capabilitiesCount}):`);
      this._capabilities.slice(0, 3).forEach(cap => {
        lines.push(`  - ${cap}`);
      });
      if (summary.capabilitiesCount > 3) {
        lines.push(`  ... and ${summary.capabilitiesCount - 3} more`);
      }
    }

    if (summary.toolsCount > 0) {
      lines.push(`Tools (${summary.toolsCount}):`);
      this._tools.slice(0, 3).forEach(tool => {
        lines.push(
          `  - ${tool.name}: ${tool.description.slice(0, 50)}${tool.description.length > 50 ? "..." : ""}`
        );
      });
      if (summary.toolsCount > 3) {
        lines.push(`  ... and ${summary.toolsCount - 3} more`);
      }
    }

    if (summary.constraintsCount > 0) {
      const mustCount = this._constraints.filter(c => c.type === "must").length;
      const mustNotCount = this._constraints.filter(c => c.type === "must_not").length;
      const shouldCount = this._constraints.filter(c => c.type === "should").length;
      const shouldNotCount = this._constraints.filter(c => c.type === "should_not").length;
      lines.push(
        `Constraints (${summary.constraintsCount}): must: ${mustCount}, must_not: ${mustNotCount}, should: ${shouldCount}, should_not: ${shouldNotCount}`
      );
    }

    lines.push("");

    // Validation Results
    const validationResult = this.validate();
    if (
      !validationResult.valid ||
      validationResult.warnings.length > 0 ||
      validationResult.info.length > 0
    ) {
      lines.push("Validation:");
      if (validationResult.errors.length > 0) {
        lines.push(`  Errors: ${validationResult.errors.length}`);
        validationResult.errors.slice(0, 2).forEach(error => {
          lines.push(`    ✗ [${error.code}] ${error.message}`);
        });
      }
      if (validationResult.warnings.length > 0) {
        lines.push(`  Warnings: ${validationResult.warnings.length}`);
        validationResult.warnings.slice(0, 2).forEach(warning => {
          lines.push(`    ⚠ [${warning.code}] ${warning.message}`);
        });
      }
      if (validationResult.info.length > 0) {
        lines.push(`  Info: ${validationResult.info.length}`);
        validationResult.info.slice(0, 2).forEach(item => {
          lines.push(`    ℹ [${item.code}] ${item.message}`);
        });
      }
      lines.push("");
    }

    // Prompt Preview
    const promptPreview = this.build();
    lines.push(`Prompt Preview (first ${PREVIEW_LENGTH} chars):`);
    lines.push(promptPreview.slice(0, PREVIEW_LENGTH));
    if (promptPreview.length > PREVIEW_LENGTH) {
      lines.push("...");
    }
    lines.push("");

    // Token Estimates
    const markdownLength = this.build("markdown").length;
    const compactLength = this.build("compact").length;
    const toonLength = this.build("toon").length;
    const markdownTokens = Math.ceil(markdownLength / PromptBuilder.CHARS_PER_TOKEN);
    const compactTokens = Math.ceil(compactLength / PromptBuilder.CHARS_PER_TOKEN);
    const toonTokens = Math.ceil(toonLength / PromptBuilder.CHARS_PER_TOKEN);

    lines.push("Token Estimates:");
    lines.push(`Markdown format: ${markdownLength} chars (~${markdownTokens} tokens)`);
    lines.push(`Compact format: ${compactLength} chars (~${compactTokens} tokens)`);
    lines.push(`TOON format: ${toonLength} chars (~${toonTokens} tokens)`);

    if (summary.format === "toon" || summary.format === "compact") {
      const savingsPercent = Math.round(((markdownLength - toonLength) / markdownLength) * 100);
      if (savingsPercent > 0) {
        lines.push(`TOON format saves ${savingsPercent}% compared to markdown`);
      }
    }

    // Token breakdown by section
    if (this.sections.length > 0) {
      lines.push("");
      lines.push("Token Breakdown by Section:");
      const sectionBreakdown: Array<{
        name: string;
        tokens: number;
        priority?: SectionPriority;
      }> = [];

      for (const section of this.sections) {
        const sectionText =
          section.type === "section"
            ? `${section.title || "Section"}`
            : section.type === "identity"
              ? "Identity"
              : section.type === "context"
                ? "Context"
                : section.type === "thinking"
                  ? "Thinking"
                  : section.type === "xml-tag"
                    ? `<${section.tag}>`
                    : section.type;
        const sectionTokens = Math.ceil(section.content.length / PromptBuilder.CHARS_PER_TOKEN);
        const breakdownItem: { name: string; tokens: number; priority?: SectionPriority } = {
          name: sectionText,
          tokens: sectionTokens,
        };
        if (section.priority !== undefined) {
          breakdownItem.priority = section.priority;
        }
        sectionBreakdown.push(breakdownItem);
      }

      // Add capabilities, tools, constraints, examples
      if (this._capabilities.length > 0) {
        const capsText = this._capabilities.join("\n");
        sectionBreakdown.push({
          name: "Capabilities",
          tokens: Math.ceil(capsText.length / PromptBuilder.CHARS_PER_TOKEN),
        });
      }
      if (this._tools.length > 0 && !this._toolApiMode) {
        const toolsText = this._tools.map(t => `${t.name}: ${t.description}`).join("\n");
        sectionBreakdown.push({
          name: "Tools",
          tokens: Math.ceil(toolsText.length / PromptBuilder.CHARS_PER_TOKEN),
        });
      }
      if (this._constraints.length > 0) {
        const constraintsText = this._constraints.map(c => c.rule).join("\n");
        sectionBreakdown.push({
          name: "Constraints",
          tokens: Math.ceil(constraintsText.length / PromptBuilder.CHARS_PER_TOKEN),
        });
      }
      if (this._examples.length > 0) {
        const examplesText = this._examples
          .map(e => `${e.user || e.input || ""} ${e.assistant || e.output || ""}`)
          .join("\n");
        sectionBreakdown.push({
          name: "Examples",
          tokens: Math.ceil(examplesText.length / PromptBuilder.CHARS_PER_TOKEN),
        });
      }
      if (this._tone) {
        sectionBreakdown.push({
          name: "Tone",
          tokens: Math.ceil(this._tone.length / PromptBuilder.CHARS_PER_TOKEN),
        });
      }

      sectionBreakdown.forEach(({ name, tokens, priority }) => {
        const priorityLabel = priority !== undefined ? ` [${priority}]` : "";
        lines.push(`  ${name}${priorityLabel}: ~${tokens} tokens`);
      });
    }

    // Priority visualization
    const priorityCounts: Record<SectionPriority | "none", number> = {
      critical: 0,
      high: 0,
      medium: 0,
      low: 0,
      none: 0,
    };

    for (const section of this.sections) {
      if (section.priority) {
        priorityCounts[section.priority]++;
      } else {
        priorityCounts.none++;
      }
    }

    if (Object.values(priorityCounts).some(count => count > 0)) {
      lines.push("");
      lines.push("Section Priorities:");
      if (priorityCounts.critical > 0) lines.push(`  Critical: ${priorityCounts.critical}`);
      if (priorityCounts.high > 0) lines.push(`  High: ${priorityCounts.high}`);
      if (priorityCounts.medium > 0) lines.push(`  Medium: ${priorityCounts.medium}`);
      if (priorityCounts.low > 0) lines.push(`  Low: ${priorityCounts.low}`);
      if (priorityCounts.none > 0) lines.push(`  Unspecified: ${priorityCounts.none}`);
    }

    // Max tokens warning
    if (this._maxTokens !== undefined) {
      const currentTokens = this.getTokenUsage();
      const usagePercent = Math.round((currentTokens / this._maxTokens) * 100);
      lines.push("");
      lines.push(`Max Tokens: ${this._maxTokens} (${usagePercent}% used)`);
      if (usagePercent > 90) {
        lines.push(`  ⚠ Warning: Approaching token limit!`);
      }
    }

    // biome-ignore lint/suspicious/noConsole: Debug method intentionally uses console
    console.log(lines.join("\n"));

    return this;
  }

  /**
   * Create an immutable copy of this builder for composition
   */
  extend(): PromptBuilder {
    const newBuilder = new PromptBuilder();
    newBuilder.sections.push(...this.sections);
    newBuilder._capabilities.push(...this._capabilities);
    newBuilder._tools.push(...this._tools);
    newBuilder._agents.push(...this._agents);
    newBuilder._constraints.push(...this._constraints);
    newBuilder._examples.push(...this._examples);
    newBuilder._templates = new Map(this._templates);
    newBuilder._docReferences = new Map(this._docReferences);
    newBuilder._placeholders = new Map(this._placeholders);
    newBuilder._tone = this._tone;
    newBuilder._format = this._format;
    if (this._maxTokens !== undefined) {
      newBuilder._maxTokens = this._maxTokens;
    }
    newBuilder._toolApiMode = this._toolApiMode;
    if (this._validatorConfig !== undefined) {
      newBuilder._validatorConfig = this._validatorConfig;
    }
    if (this._reasoningProtocol !== undefined) {
      newBuilder._reasoningProtocol = { ...this._reasoningProtocol };
    }
    if (this._selfCorrection !== undefined) {
      newBuilder._selfCorrection = { ...this._selfCorrection };
    }
    if (this._output !== undefined) {
      newBuilder._output = { ...this._output };
    }
    return newBuilder;
  }

  /**
   * Merge another builder's sections into this one
   */
  merge(other: PromptBuilder): PromptBuilder {
    const merged = this.extend();
    merged.sections.push(...other.sections);
    merged._capabilities.push(...other._capabilities);
    merged._tools.push(...other._tools);
    merged._agents.push(...other._agents);
    merged._constraints.push(...other._constraints);
    merged._examples.push(...other._examples);
    // Merge templates (other's templates override if same tag name)
    for (const [tagName, content] of other._templates) {
      merged._templates.set(tagName, content);
    }
    // Merge references (other's references override if same tag name)
    for (const [tagName, content] of other._docReferences) {
      merged._docReferences.set(tagName, content);
    }
    // Merge placeholders (other's placeholders override if same placeholder)
    for (const [placeholder, value] of other._placeholders) {
      merged._placeholders.set(placeholder, value);
    }
    if (other._tone && !merged._tone) {
      merged._tone = other._tone;
    }
    if (other._maxTokens && !merged._maxTokens) {
      merged._maxTokens = other._maxTokens;
    }
    if (other._reasoningProtocol && !merged._reasoningProtocol) {
      merged._reasoningProtocol = { ...other._reasoningProtocol };
    }
    if (other._selfCorrection && !merged._selfCorrection) {
      merged._selfCorrection = { ...other._selfCorrection };
    }
    // Merge output (other's output overrides if set)
    if (other._output !== undefined) {
      merged._output = { ...other._output };
    }
    // Format and toolApiMode are not merged - keep original
    return merged;
  }

  /**
   * Build the system prompt (identity, tools, constraints, tone, capabilities).
   * Excludes user-facing context and examples.
   * Templates are appended at the end of the system prompt.
   *
   * @param format - Optional format override
   */
  buildSystemPrompt(format?: PromptFormat): string {
    const targetFormat = format || this._format;

    const promptData: PromptData = {
      sections: this.processSectionsWithPlaceholders(this.sections),
      capabilities: this._capabilities.map(cap => this.replacePlaceholders(cap)),
      tools: this._toolApiMode ? [] : this._tools, // Exclude tools if using API mode
      agents: this._agents.map(agent => {
        const mapped: AgentDefinition = {
          name: agent.name,
          purpose: this.replacePlaceholders(agent.purpose),
          useWhen: this.replacePlaceholders(agent.useWhen),
          capabilities: agent.capabilities.map(cap => this.replacePlaceholders(cap)),
        };
        if (agent.exampleUsage) {
          mapped.exampleUsage = this.replacePlaceholders(agent.exampleUsage);
        }
        if (agent.bestFor) {
          mapped.bestFor = this.replacePlaceholders(agent.bestFor);
        }
        return mapped;
      }),
      constraints: this._constraints.map(constraint => ({
        ...constraint,
        rule: this.replacePlaceholders(constraint.rule),
      })),
      examples: [],
      tone: this.replacePlaceholders(this._tone),
    };

    const systemPrompt = formatSystemPrompt(promptData, targetFormat);

    // Build parts array starting with formatted system prompt
    const parts: string[] = [systemPrompt];

    // Inject output section before templates/references if set
    if (this._output) {
      const enforcementMessage = this.getOutputEnforcementMessage(this._output.format);
      const outputContent = this.replacePlaceholders(this._output.content);

      // Escape attribute values to prevent XML injection
      const escapedFormat = escapeXmlAttribute(this._output.format);
      const escapedLanguage = this._output.language
        ? escapeXmlAttribute(this._output.language)
        : undefined;

      // Build format attribute, including language for Code format
      const formatAttr = escapedLanguage
        ? `format="${escapedFormat}" language="${escapedLanguage}"`
        : `format="${escapedFormat}"`;

      // Wrap dynamic content in CDATA to prevent XML injection from content
      const safeOutputContent = wrapInCdata(outputContent);

      const outputSection = `<output ${formatAttr}>
${enforcementMessage}

${safeOutputContent}

- **IT'S REQUIRED FOR YOU** to follow this output instruction, IF YOU DON'T DO that your task will be invalidated
- **YOU CANNOT AT ANY CIRCUMSTANCE** output any other message on this iteration before this output. This output must be your last and only response.
</output>`;
      parts.push(outputSection);
    }

    // Append templates and references at the end of system prompt with clear separators
    if (this._templates.size > 0) {
      const templateParts: string[] = [];
      for (const [tagName, content] of this._templates) {
        templateParts.push(`<${tagName}>\n${this.replacePlaceholders(content)}\n</${tagName}>`);
      }
      parts.push(`=== TEMPLATES ===\n\n${templateParts.join("\n\n")}`);
    }

    if (this._docReferences.size > 0) {
      const referenceParts: string[] = [];
      for (const [tagName, content] of this._docReferences) {
        referenceParts.push(`<${tagName}>\n${this.replacePlaceholders(content)}\n</${tagName}>`);
      }
      parts.push(`=== REFERENCES ===\n\n${referenceParts.join("\n\n")}`);
    }

    return parts.join("\n\n");
  }

  /**
   * Build user context (context sections, examples).
   * Excludes system-level instructions.
   *
   * @param format - Optional format override
   */
  buildUserContext(format?: PromptFormat): string {
    const targetFormat = format || this._format;

    const promptData: PromptData = {
      sections: this.processSectionsWithPlaceholders(this.sections),
      capabilities: [],
      tools: [],
      agents: [],
      constraints: [],
      examples: this._examples.map(example => {
        const mapped: Example = {};
        if (example.user) {
          mapped.user = this.replacePlaceholders(example.user);
        }
        if (example.assistant) {
          mapped.assistant = this.replacePlaceholders(example.assistant);
        }
        if (example.input) {
          mapped.input = this.replacePlaceholders(example.input);
        }
        if (example.output) {
          mapped.output = this.replacePlaceholders(example.output);
        }
        if (example.explanation) {
          mapped.explanation = this.replacePlaceholders(example.explanation);
        }
        return mapped;
      }),
      tone: "",
    };

    return formatUserContext(promptData, targetFormat);
  }

  /**
   * Build Messages API structure separating system prompt from user messages.
   *
   * @param userMessage - Optional initial user message content
   * @param format - Optional format override
   */
  buildMessages(userMessage?: string, format?: PromptFormat): PromptBuildResult {
    const targetFormat = format || this._format;
    const system = this.buildSystemPrompt(targetFormat);
    const userContext = this.buildUserContext(targetFormat);

    const messages: Message[] = [];

    // Add user context if present
    if (userContext.trim()) {
      messages.push({ role: "user", content: userContext });
    }

    // Add user message if provided
    if (userMessage) {
      messages.push({ role: "user", content: userMessage });
    }

    return {
      system,
      messages,
    };
  }

  /**
   * Build the final prompt string from all sections.
   * Templates are appended at the end.
   *
   * @param format - Optional format override. If not provided, uses the format set via `withFormat()` (defaults to 'markdown')
   */
  build(format?: PromptFormat): string {
    const targetFormat = format || this._format;

    const promptData: PromptData = {
      sections: this.processSectionsWithPlaceholders(this.sections),
      capabilities: this._capabilities.map(cap => this.replacePlaceholders(cap)),
      tools: this._toolApiMode ? [] : this._tools, // Exclude tools if using API mode
      agents: this._agents.map(agent => {
        const mapped: AgentDefinition = {
          name: agent.name,
          purpose: this.replacePlaceholders(agent.purpose),
          useWhen: this.replacePlaceholders(agent.useWhen),
          capabilities: agent.capabilities.map(cap => this.replacePlaceholders(cap)),
        };
        if (agent.exampleUsage) {
          mapped.exampleUsage = this.replacePlaceholders(agent.exampleUsage);
        }
        if (agent.bestFor) {
          mapped.bestFor = this.replacePlaceholders(agent.bestFor);
        }
        return mapped;
      }),
      constraints: this._constraints.map(constraint => ({
        ...constraint,
        rule: this.replacePlaceholders(constraint.rule),
      })),
      examples: this._examples.map(example => {
        const mapped: Example = {};
        if (example.user) {
          mapped.user = this.replacePlaceholders(example.user);
        }
        if (example.assistant) {
          mapped.assistant = this.replacePlaceholders(example.assistant);
        }
        if (example.input) {
          mapped.input = this.replacePlaceholders(example.input);
        }
        if (example.output) {
          mapped.output = this.replacePlaceholders(example.output);
        }
        if (example.explanation) {
          mapped.explanation = this.replacePlaceholders(example.explanation);
        }
        return mapped;
      }),
      tone: this.replacePlaceholders(this._tone),
    };

    const prompt = formatPrompt(promptData, targetFormat);

    // Append templates and references at the end with clear separators
    const parts: string[] = [prompt];

    if (this._templates.size > 0) {
      const templateParts: string[] = [];
      for (const [tagName, content] of this._templates) {
        templateParts.push(`<${tagName}>\n${this.replacePlaceholders(content)}\n</${tagName}>`);
      }
      parts.push(`=== TEMPLATES ===\n\n${templateParts.join("\n\n")}`);
    }

    if (this._docReferences.size > 0) {
      const referenceParts: string[] = [];
      for (const [tagName, content] of this._docReferences) {
        referenceParts.push(`<${tagName}>\n${this.replacePlaceholders(content)}\n</${tagName}>`);
      }
      parts.push(`=== REFERENCES ===\n\n${referenceParts.join("\n\n")}`);
    }

    return parts.join("\n\n");
  }

  /**
   * Get all sections (for testing/debugging)
   */
  getSections(): readonly PromptSection[] {
    return this.sections;
  }
}

/**
 * Factory function to create a new PromptBuilder instance
 */
export function createPromptBuilder(): PromptBuilder {
  return new PromptBuilder();
}
