/**
 * Generate Built-in Prompts Script
 *
 * Generates all built-in prompts as .txt files for review and inspection.
 * This helps visualize the final prompt output without needing to run the full application.
 */

import {
  approachesTool,
  approveTasksTool,
  artifactListTool,
  clarificationTool,
  createPrdTool,
  createTechspecTool,
  deleteTaskTool,
  listTasksTool,
  reorderTasksTool,
  updatePrdTool,
  updateTaskTool,
  updateTechspecTool,
} from "@compozy/types";
import { mkdir, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { join } from "path";
import { buildPRDPrompt } from "../built-in/prd";
import { buildBusinessAnalystPrompt } from "../built-in/subagents/business-analyst";
import { buildFileExplorerPrompt } from "../built-in/subagents/file-explorer";
import { buildReviewAgentPrompt } from "../built-in/subagents/review-agent";
import { buildRulesExplorerPrompt } from "../built-in/subagents/rules-explorer";
import { buildTaskEnricherPrompt } from "../built-in/subagents/task-enricher";
import { buildConfirmationPrompt } from "../built-in/task-confirmation/factory";
import type { ConfirmationInput } from "../built-in/task-confirmation/types";
import {
  buildTaskExecutionPrompt,
  type PromptBuilderOptions,
} from "../built-in/task-execution/factory";
import { buildReviewPrompt } from "../built-in/task-review/factory";
import type { ReviewInput } from "../built-in/task-review/types";
import { buildTasksPrompt } from "../built-in/tasks";
import { buildTechSpecPrompt } from "../built-in/techspec";

type ToolNameMappings = Record<string, string>;

const TOOL_NAME_MAP: ToolNameMappings = {
  "{{TOOL_NAME_CLARIFICATION}}": clarificationTool.fullName,
  "{{TOOL_NAME_APPROACHES}}": approachesTool.fullName,
  "{{TOOL_NAME_PRD_CREATE}}": createPrdTool.fullName,
  "{{TOOL_NAME_PRD_UPDATE}}": updatePrdTool.fullName,
  "{{TOOL_NAME_PRD}}": createPrdTool.fullName,
  "{{TOOL_NAME_TECHSPEC_CREATE}}": createTechspecTool.fullName,
  "{{TOOL_NAME_TECHSPEC_UPDATE}}": updateTechspecTool.fullName,
  "{{TOOL_NAME_TECHSPEC}}": createTechspecTool.fullName,
  "{{TOOL_NAME_APPROVE_TASKS}}": approveTasksTool.fullName,
  "{{TOOL_NAME_LIST_TASKS}}": listTasksTool.fullName,
  "{{TOOL_NAME_UPDATE_TASK}}": updateTaskTool.fullName,
  "{{TOOL_NAME_DELETE_TASK}}": deleteTaskTool.fullName,
  "{{TOOL_NAME_REORDER_TASKS}}": reorderTasksTool.fullName,
  "{{TOOL_NAME_ARTIFACT_LIST}}": artifactListTool.fullName,
};

function injectAllToolNames<T extends { withPlaceholder: (key: string, value: string) => T }>(
  builder: T
): T {
  let current = builder;
  for (const [placeholder, toolName] of Object.entries(TOOL_NAME_MAP)) {
    current = current.withPlaceholder(placeholder, toolName);
  }
  return current;
}

/**
 * Sample task for task execution prompt
 */
const SAMPLE_TASK = {
  id: "task-1",
  title: "Implement user login API endpoint",
  filePath: "/path/to/tasks/task-1.md",
  content: "Create POST /api/auth/login endpoint with email/password validation",
  domain: "Authentication",
  type: "Feature Implementation",
  scope: "Full",
  complexity: "medium",
  dependencies: [],
  overview: "Implement secure login endpoint",
  requirements: [
    "Validate email format",
    "Hash password comparison",
    "Return JWT token on success",
  ],
  deliverables: ["POST /api/auth/login endpoint", "Input validation schema", "Unit tests"],
  successCriteria: [
    "All tests passing",
    "Linter shows no errors",
    "Endpoint returns 200 on valid credentials",
  ],
};

/**
 * Sample artifact configs for subagents
 */
const SAMPLE_PRD_ARTIFACT = {
  id: "sample-prd-id",
  title: "Sample PRD",
  filePath: "/path/to/prd.md",
  version: 1,
};

const SAMPLE_TECHSPEC_ARTIFACT = {
  id: "sample-techspec-id",
  title: "Sample TechSpec",
  filePath: "/path/to/techspec.md",
  version: 1,
};

const SAMPLE_TASK_ARTIFACT = {
  id: "task-1",
  title: "Implement user login API endpoint",
  filePath: "/path/to/tasks/task-1.md",
  complexity: "medium",
  domain: "backend",
  type: "api",
  scope: "single-service",
  dependencies: ["auth-service"],
};

/**
 * Generate PRD prompt
 */
function generatePRDPrompt(): string {
  const builder = buildPRDPrompt({
    brainstormConfig: {
      clarificationToolName: "{{TOOL_NAME_CLARIFICATION}}",
      maxQuestionsPerRound: 5,
    },
    issueId: "sample-issue-id",
  });
  const builderWithTools = injectAllToolNames(builder);
  const system = builderWithTools.buildSystemPrompt();
  const messages = builderWithTools.buildMessages();
  return `=== SYSTEM PROMPT ===\n\n${system}\n\n=== USER MESSAGES ===\n\n${messages.messages.map((msg, i) => `Message ${i + 1} (${msg.role}):\n${msg.content}`).join("\n\n---\n\n")}`;
}

/**
 * Generate TechSpec prompt
 */
function generateTechSpecPrompt(): string {
  const builder = buildTechSpecPrompt({
    brainstormConfig: {
      clarificationToolName: "{{TOOL_NAME_CLARIFICATION}}",
      maxQuestionsPerRound: 5,
    },
    prdClarifications:
      "User needs: Secure authentication\nFeatures: Email verification, password reset\nSuccess Metrics: 90% registration rate",
    issueId: "sample-issue-id",
    prdArtifact: SAMPLE_PRD_ARTIFACT,
  });

  const builderWithTools = injectAllToolNames(builder);
  const system = builderWithTools.buildSystemPrompt();
  const messages = builderWithTools.buildMessages();
  return `=== SYSTEM PROMPT ===\n\n${system}\n\n=== USER MESSAGES ===\n\n${messages.messages.map((msg, i) => `Message ${i + 1} (${msg.role}):\n${msg.content}`).join("\n\n---\n\n")}`;
}

/**
 * Generate Tasks prompt
 */
function generateTasksPrompt(): string {
  const builder = buildTasksPrompt({
    issueId: "sample-issue-id",
    prdArtifact: SAMPLE_PRD_ARTIFACT,
    techspecArtifact: SAMPLE_TECHSPEC_ARTIFACT,
  });

  const builderWithTools = injectAllToolNames(builder);
  const system = builderWithTools.buildSystemPrompt();
  const messages = builderWithTools.buildMessages();
  return `=== SYSTEM PROMPT ===\n\n${system}\n\n=== USER MESSAGES ===\n\n${messages.messages.map((msg, i) => `Message ${i + 1} (${msg.role}):\n${msg.content}`).join("\n\n---\n\n")}`;
}

/**
 * Sample execution snapshot for confirmation/review prompts
 */
const SAMPLE_EXECUTION_SNAPSHOT = {
  summary:
    "Successfully implemented POST /api/auth/login endpoint with email/password validation. All tests passing.",
  exitCode: 0,
  lastMessages: [
    {
      role: "user" as const,
      content: "Implement user login API endpoint",
    },
    {
      role: "assistant" as const,
      content: "I'll implement the login endpoint with proper validation and error handling.",
    },
    {
      role: "assistant" as const,
      content: "Created POST /api/auth/login endpoint. All tests passing. Ready for review.",
    },
  ],
  artifacts: {
    testsStatus: "passed",
    lintStatus: "passed",
    changedFiles: ["src/api/auth/login.ts", "src/api/auth/login.test.ts"],
    filesTouched: ["src/api/auth/login.ts", "src/api/auth/login.test.ts"],
    testsRan: ["login.test.ts"],
    diffSummary: "Added login endpoint with validation and tests",
  },
};

/**
 * Sample confirmation verdict for review prompt
 */
const SAMPLE_CONFIRMATION_VERDICT = {
  status: "pass" as const,
  reasons: ["All tests passing", "No limit errors detected"],
  limitError: false,
  definitionMismatch: false,
  errorDetected: false,
  actionItems: [],
};

/**
 * Generate Task Execution prompt
 */
function generateTaskExecutionPrompt(): string {
  const config: PromptBuilderOptions = {
    task: SAMPLE_TASK,
    issueId: "sample-issue-id",
    config: {
      projectRulesPath: ".cursor/rules/",
      testCommand: "pnpm run test",
      lintCommand: "pnpm run lint",
    },
    issueContext: {
      prdPath: "/path/to/prd.md",
      techspecPath: "/path/to/techspec.md",
      issueContextPath: "/path/to/issue-context.md",
      tasksDirPath: "/path/to/tasks",
    },
  };

  const result = buildTaskExecutionPrompt(config);
  return `=== SYSTEM PROMPT ===\n\n${result.systemPrompt}\n\n=== USER PROMPT ===\n\n${result.userPrompt}`;
}

/**
 * Generate Task Enricher prompt (with artifacts)
 */
function generateTaskEnricherPrompt(): string {
  return buildTaskEnricherPrompt({
    issueId: "sample-issue-id",
    prdArtifact: SAMPLE_PRD_ARTIFACT,
    techspecArtifact: SAMPLE_TECHSPEC_ARTIFACT,
  });
}

/**
 * Generate Business Analyst prompt (with PRD artifact)
 */
function generateBusinessAnalystPrompt(): string {
  return buildBusinessAnalystPrompt({
    issueId: "sample-issue-id",
    prdArtifact: SAMPLE_PRD_ARTIFACT,
  });
}

/**
 * Generate File Explorer prompt (with artifacts)
 */
function generateFileExplorerPrompt(): string {
  return buildFileExplorerPrompt({
    issueId: "sample-issue-id",
    prdArtifact: SAMPLE_PRD_ARTIFACT,
    techspecArtifact: SAMPLE_TECHSPEC_ARTIFACT,
    task: SAMPLE_TASK_ARTIFACT,
  });
}

/**
 * Generate Rules Explorer prompt (with artifacts)
 */
function generateRulesExplorerPrompt(): string {
  return buildRulesExplorerPrompt({
    issueId: "sample-issue-id",
    prdArtifact: SAMPLE_PRD_ARTIFACT,
    techspecArtifact: SAMPLE_TECHSPEC_ARTIFACT,
    task: SAMPLE_TASK_ARTIFACT,
  });
}

/**
 * Generate Review Agent prompt (with artifacts)
 */
function generateReviewAgentPrompt(): string {
  return buildReviewAgentPrompt({
    issueId: "sample-issue-id",
    prdArtifact: SAMPLE_PRD_ARTIFACT,
    techspecArtifact: SAMPLE_TECHSPEC_ARTIFACT,
    task: SAMPLE_TASK_ARTIFACT,
  });
}

/**
 * Generate Task Confirmation prompt
 */
function generateTaskConfirmationPrompt(): string {
  const input: ConfirmationInput = {
    taskDefinition: {
      id: SAMPLE_TASK.id,
      issueId: "sample-issue-id",
      title: SAMPLE_TASK.title,
      filePath: SAMPLE_TASK.filePath ?? "/path/to/task.md",
      content: SAMPLE_TASK.content,
      complexity: SAMPLE_TASK.complexity as "low" | "medium" | "high" | "critical",
    },
    issueContext: {
      prdPath: "/path/to/prd.md",
      techspecPath: "/path/to/techspec.md",
      issueContextPath: "/path/to/issue-context.md",
      tasksDirPath: "/path/to/tasks",
    },
    snapshot: SAMPLE_EXECUTION_SNAPSHOT,
  };

  const result = buildConfirmationPrompt(input);
  return `=== SYSTEM PROMPT ===\n\n${result.systemPrompt}\n\n=== USER PROMPT ===\n\n${result.userPrompt}`;
}

/**
 * Generate Task Review prompt
 */
function generateTaskReviewPrompt(): string {
  const input: ReviewInput = {
    taskDefinition: {
      id: SAMPLE_TASK.id,
      issueId: "sample-issue-id",
      title: SAMPLE_TASK.title,
      filePath: SAMPLE_TASK.filePath ?? "/path/to/task.md",
      content: SAMPLE_TASK.content,
      complexity: SAMPLE_TASK.complexity as "low" | "medium" | "high" | "critical",
    },
    issueContext: {
      prdPath: "/path/to/prd.md",
      techspecPath: "/path/to/techspec.md",
      issueContextPath: "/path/to/issue-context.md",
      tasksDirPath: "/path/to/tasks",
    },
    snapshot: SAMPLE_EXECUTION_SNAPSHOT,
    confirmationVerdict: SAMPLE_CONFIRMATION_VERDICT,
  };

  const result = buildReviewPrompt(input);
  return `=== SYSTEM PROMPT ===\n\n${result.systemPrompt}\n\n=== USER PROMPT ===\n\n${result.userPrompt}`;
}

/**
 * Main execution
 */
async function main() {
  const outputDir = join(process.cwd(), "prompts-output");

  // Create output directory
  try {
    await mkdir(outputDir, { recursive: true });
  } catch {
    // Directory might already exist, that's fine
  }

  console.log("Generating built-in prompts...\n");

  // Generate PRD prompt
  console.log("Generating PRD prompt...");
  const prdPrompt = generatePRDPrompt();
  await writeFile(join(outputDir, "prd-prompt.txt"), prdPrompt, "utf-8");
  console.log("✓ Generated prd-prompt.txt");

  // Generate TechSpec prompt
  console.log("Generating TechSpec prompt...");
  const techSpecPrompt = generateTechSpecPrompt();
  await writeFile(join(outputDir, "techspec-prompt.txt"), techSpecPrompt, "utf-8");
  console.log("✓ Generated techspec-prompt.txt");

  // Generate Tasks prompt
  console.log("Generating Tasks prompt...");
  const tasksPrompt = generateTasksPrompt();
  await writeFile(join(outputDir, "tasks-prompt.txt"), tasksPrompt, "utf-8");
  console.log("✓ Generated tasks-prompt.txt");

  // Generate Task Execution prompt
  console.log("Generating Task Execution prompt...");
  const taskExecutionPrompt = generateTaskExecutionPrompt();
  await writeFile(join(outputDir, "task-execution-prompt.txt"), taskExecutionPrompt, "utf-8");
  console.log("✓ Generated task-execution-prompt.txt");

  // Generate Rules Explorer prompt
  console.log("Generating Rules Explorer prompt...");
  const rulesExplorerPrompt = generateRulesExplorerPrompt();
  await writeFile(join(outputDir, "rules-explorer-prompt.txt"), rulesExplorerPrompt, "utf-8");
  console.log("✓ Generated rules-explorer-prompt.txt");

  // Generate File Explorer prompt
  console.log("Generating File Explorer prompt...");
  const fileExplorerPrompt = generateFileExplorerPrompt();
  await writeFile(join(outputDir, "file-explorer-prompt.txt"), fileExplorerPrompt, "utf-8");
  console.log("✓ Generated file-explorer-prompt.txt");

  // Generate Business Analyst prompt
  console.log("Generating Business Analyst prompt...");
  const businessAnalystPrompt = generateBusinessAnalystPrompt();
  await writeFile(join(outputDir, "business-analyst-prompt.txt"), businessAnalystPrompt, "utf-8");
  console.log("✓ Generated business-analyst-prompt.txt");

  // Generate Review Agent prompt
  console.log("Generating Review Agent prompt...");
  const reviewAgentPrompt = generateReviewAgentPrompt();
  await writeFile(join(outputDir, "review-agent-prompt.txt"), reviewAgentPrompt, "utf-8");
  console.log("✓ Generated review-agent-prompt.txt");

  // Generate Task Enricher prompt
  console.log("Generating Task Enricher prompt...");
  const taskEnricherPrompt = generateTaskEnricherPrompt();
  await writeFile(join(outputDir, "task-enricher-prompt.txt"), taskEnricherPrompt, "utf-8");
  console.log("✓ Generated task-enricher-prompt.txt");

  // Generate Task Confirmation prompt
  console.log("Generating Task Confirmation prompt...");
  const taskConfirmationPrompt = generateTaskConfirmationPrompt();
  await writeFile(join(outputDir, "task-confirmation-prompt.txt"), taskConfirmationPrompt, "utf-8");
  console.log("✓ Generated task-confirmation-prompt.txt");

  // Generate Task Review prompt
  console.log("Generating Task Review prompt...");
  const taskReviewPrompt = generateTaskReviewPrompt();
  await writeFile(join(outputDir, "task-review-prompt.txt"), taskReviewPrompt, "utf-8");
  console.log("✓ Generated task-review-prompt.txt");

  console.log(`\n✅ All prompts generated successfully in: ${outputDir}`);
}

// Run if executed directly
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  void main();
}
