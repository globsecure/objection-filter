import { z } from "zod";
import { AgentTool, defineTool, interactionMetadataSchema } from "./definition";

const CLARIFICATION_TOOL_NAME = "ask_clarification_questions" as const;

export const clarificationOptionSchema = z.object({
  label: z.string().describe("Display text for the option"),
  value: z.string().describe("Value to submit when selected"),
});

export const clarificationQuestionSchema = z.object({
  id: z.string().describe("Unique identifier for the question"),
  category: z.string().describe('Question category (e.g., "User Needs", "Technical Constraints")'),
  question: z.string().describe("The actual question to ask"),
  multiple: z
    .boolean()
    .describe("Whether question allows multiple selections (true) or single selection (false)"),
  options: z.array(clarificationOptionSchema).min(2).max(4).describe("2-4 answer options"),
  allowOther: z.boolean().describe('Whether to allow "Other" text input'),
});

export const clarificationInputSchema = z.object({
  questions: z
    .array(clarificationQuestionSchema)
    .min(1)
    .max(10)
    .describe("List of clarification questions (1-10 questions required)"),
  context: z.string().describe("Context about why these questions are being asked"),
});

const clarificationInteractionMetadataSchema = interactionMetadataSchema
  .extend({
    type: z.literal("form"),
    uiComponent: z.literal("clarification-form"),
    tool: z.string().optional(),
  })
  .default({
    type: "form",
    uiComponent: "clarification-form",
    requiresInput: true,
  });

export const clarificationArtifactSchema = z.object({
  questionId: z
    .string()
    .min(1)
    .describe("Stable identifier for this clarification round (not required to be a UUID)"),
  context: z.string(),
  questions: z.array(clarificationQuestionSchema),
  status: z.literal("presented").optional(),
  type: z.literal("clarification-presented").optional(),
  questionCount: z.number().int().nonnegative().optional(),
  message: z.string().optional(),
  _interaction: clarificationInteractionMetadataSchema,
});

const clarificationDefinition = defineTool({
  name: CLARIFICATION_TOOL_NAME,
  description:
    "MANDATORY TOOL: Present clarification questions and wait for a structured user response before proceeding.",
  schemas: {
    input: clarificationInputSchema,
    artifact: clarificationArtifactSchema,
  },
  behavior: {
    stopOnUse: true,
  },
  interaction: {
    type: "form",
    uiComponent: "clarification-form",
    autoSync: true,
  },
});

const createClarificationToolWithNamespace = (namespace: string) =>
  new AgentTool(clarificationDefinition, namespace);

export const clarificationTool = createClarificationToolWithNamespace("mcp__clarification__");
export const prdClarificationTool = createClarificationToolWithNamespace("mcp__prd__");
export const techspecClarificationTool = createClarificationToolWithNamespace("mcp__techspec__");
export { CLARIFICATION_TOOL_NAME };
