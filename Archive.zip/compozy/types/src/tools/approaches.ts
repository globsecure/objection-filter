import { z } from "zod";
import { AgentTool, defineTool, interactionMetadataSchema } from "./definition";

const APPROACHES_TOOL_NAME = "present_approaches" as const;

export const approachOptionSchema = z.object({
  name: z.string().describe("Short, descriptive name for the approach"),
  description: z.string().describe("2-3 sentences explaining the approach"),
  pros: z.array(z.string()).min(1).max(5).describe("Advantages of this approach (1-5 points)"),
  cons: z
    .array(z.string())
    .min(1)
    .max(5)
    .describe("Disadvantages/risks of this approach (1-5 points)"),
  bestFor: z.string().describe("When to choose this approach"),
  isRecommended: z.boolean().default(false).describe("Whether this is the recommended approach"),
});

export const approachesInputSchema = z.object({
  approaches: z
    .array(approachOptionSchema)
    .min(2)
    .max(5)
    .describe("List of approaches to present (2-5 approaches required)"),
  context: z.string().describe("Context about why these approaches are being presented"),
  focusType: z
    .enum(["business", "technical"])
    .describe("Whether this is for business/product (PRD) or technical (TechSpec) decisions"),
  recommendationReason: z.string().optional().describe("Why the recommended approach is suggested"),
});

const approachesInteractionMetadataSchema = interactionMetadataSchema
  .extend({
    type: z.literal("form"),
    uiComponent: z.literal("approaches-form"),
    tool: z.string().optional(),
  })
  .default({
    type: "form",
    uiComponent: "approaches-form",
    requiresInput: true,
  });

export const approachesArtifactSchema = z.object({
  approachId: z
    .string()
    .min(1)
    .describe("Stable identifier for this approaches presentation (not required to be a UUID)"),
  context: z.string(),
  approaches: z.array(approachOptionSchema),
  focusType: z.enum(["business", "technical"]),
  recommendationReason: z.string().optional(),
  status: z.literal("presented").optional(),
  type: z.literal("approaches-presented").optional(),
  approachCount: z.number().int().nonnegative().optional(),
  message: z.string().optional(),
  _interaction: approachesInteractionMetadataSchema,
});

export const approachesResponseSchema = z.object({
  approachId: z.string().describe("The ID of this approaches presentation"),
  selectedApproach: z.string().describe("Name of the selected approach"),
  selectedIndex: z.number().int().min(0).describe("Zero-based index of selected approach"),
  additionalFeedback: z.string().optional().describe("Optional additional feedback from the user"),
});

const approachesDefinition = defineTool({
  name: APPROACHES_TOOL_NAME,
  description:
    "MANDATORY TOOL: Present 2-5 approaches with trade-offs and wait for user selection before proceeding.",
  schemas: {
    input: approachesInputSchema,
    artifact: approachesArtifactSchema,
  },
  behavior: {
    stopOnUse: true,
  },
  interaction: {
    type: "form",
    uiComponent: "approaches-form",
    autoSync: true,
  },
});

const createApproachesToolWithNamespace = (namespace: string) =>
  new AgentTool(approachesDefinition, namespace);

export const approachesTool = createApproachesToolWithNamespace("mcp__approaches__");
export const prdApproachesTool = createApproachesToolWithNamespace("mcp__prd__");
export const techspecApproachesTool = createApproachesToolWithNamespace("mcp__techspec__");
export { APPROACHES_TOOL_NAME };

export type ApproachOption = z.infer<typeof approachOptionSchema>;
export type ApproachesInput = z.infer<typeof approachesInputSchema>;
export type ApproachesArtifact = z.infer<typeof approachesArtifactSchema>;
export type ApproachesResponse = z.infer<typeof approachesResponseSchema>;
