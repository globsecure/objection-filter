import { trim } from "es-toolkit/string";
import { z } from "zod";
import { AgentTool, defineTool } from "./definition";

const ARTIFACT_TOOL_NAMESPACE = "mcp__artifact__" as const;

export const artifactTypeSchema = z.enum(["prd", "techspec", "task", "issue_context"]);

const hasRequiredArtifactContent = (data: {
  type: z.infer<typeof artifactTypeSchema>;
  content?: string | undefined;
}) => data.type === "task" || (typeof data.content === "string" && trim(data.content).length > 0);

export const artifactIndexInputSchema = z
  .object({
    issueId: z.string().uuid().describe("Issue ID that this artifact belongs to"),
    type: artifactTypeSchema.describe("Artifact type to index"),
    title: z.string().optional().describe("Artifact title or task title"),
    taskId: z.string().uuid().optional().describe("Task ID (required when type is task)"),
    taskSlug: z.string().optional().describe("Task slug (optional when type is task)"),
    content: z
      .string()
      .optional()
      .describe("Markdown content to store locally and index for search"),
    updatedAt: z.number().int().optional().describe("Updated timestamp in milliseconds"),
    syncedAt: z.number().int().nullable().optional().describe("Synced timestamp in milliseconds"),
  })
  .refine(data => data.type !== "task" || typeof data.taskId === "string", {
    message: "taskId is required when type is task",
    path: ["taskId"],
  })
  .refine(hasRequiredArtifactContent, {
    message: "content is required when type is not task",
    path: ["content"],
  });

export const artifactListInputSchema = z.object({
  issueId: z.string().uuid().describe("Issue ID to list artifacts for"),
});

const artifactIndexDefinition = defineTool({
  name: "index_artifact",
  description:
    "Index a local artifact so it can be searched later. Provide the artifact markdown content and metadata (issueId, type, taskId for tasks). Use this when you need to sync an artifact file into the local artifacts database.",
  schemas: {
    input: artifactIndexInputSchema,
  },
});

const artifactListDefinition = defineTool({
  name: "list_artifacts",
  description:
    "List all local artifacts (PRD, TechSpec, Tasks, Issue Context) for an issue. Returns file paths for all indexed artifacts.",
  schemas: {
    input: artifactListInputSchema,
  },
});

export const artifactIndexTool = new AgentTool(artifactIndexDefinition, ARTIFACT_TOOL_NAMESPACE);
export const artifactListTool = new AgentTool(artifactListDefinition, ARTIFACT_TOOL_NAMESPACE);
