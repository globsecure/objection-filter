/**
 * Centralized tool name constants.
 * All tool names should be imported from here instead of hardcoding strings.
 */

import { createPrdTool, updatePrdTool } from "./prd";
import { createTechspecTool, updateTechspecTool } from "./techspec";
import { prdClarificationTool, techspecClarificationTool } from "./clarification";
import { artifactIndexTool, artifactListTool } from "./artifact";

// PRD Tool Names
export const PRD_CREATE_TOOL_NAME = createPrdTool.fullName;
export const PRD_UPDATE_TOOL_NAME = updatePrdTool.fullName;

// TechSpec Tool Names
export const TECHSPEC_CREATE_TOOL_NAME = createTechspecTool.fullName;
export const TECHSPEC_UPDATE_TOOL_NAME = updateTechspecTool.fullName;

// Clarification Tool Names
export const PRD_CLARIFICATION_TOOL_NAME = prdClarificationTool.fullName;
export const TECHSPEC_CLARIFICATION_TOOL_NAME = techspecClarificationTool.fullName;

// Artifact Tool Names
export const ARTIFACT_INDEX_TOOL_NAME = artifactIndexTool.fullName;
export const ARTIFACT_LIST_TOOL_NAME = artifactListTool.fullName;
