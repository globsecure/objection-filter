import { z } from "zod";
import { AgentTool, defineTool, interactionMetadataSchema } from "./definition";

const TECHSPEC_TOOL_NAMESPACE = "mcp__techspec__" as const;

export const techspecInputSchema = z.object({
  title: z
    .string()
    .min(1)
    .describe("Tech Spec title or feature name that will appear in the artifact"),
  summary: z.string().min(1).describe("Concise summary of the technical approach and decisions"),
  content: z
    .string()
    .min(1)
    .describe(
      "Full Tech Spec content in markdown. Follow sections such as Summary, Motivation, Architecture, Implementation Plan, Risks, Testing, Rollout, and Appendix."
    ),
  prdId: z.uuid().optional().describe("Related PRD ID when the tech spec is scoped"),
  issueId: z.uuid().optional().describe("Parent issue ID that this TechSpec belongs to"),
});

const techspecInteractionMetadataSchema = interactionMetadataSchema
  .extend({
    type: z.literal("approval"),
    uiComponent: z.literal("techspec-review"),
    tool: z.literal("mcp__techspec__create_techspec").optional(),
  })
  .default({
    type: "approval",
    uiComponent: "techspec-review",
    requiresInput: true,
    tool: "mcp__techspec__create_techspec",
  });

export const techspecArtifactSchema = z.object({
  techspecId: z.uuid(),
  title: z.string(),
  summary: z.string(),
  content: z.string(),
  prdId: z.uuid().optional(),
  issueId: z.uuid().optional(),
  _interaction: techspecInteractionMetadataSchema,
});

export const techspecUpdateInputSchema = techspecInputSchema.partial().extend({
  id: z.uuid().describe("Techspec ID to update"),
  expectedVersion: z
    .number()
    .int()
    .min(1)
    .describe("Expected version number for optimistic locking (required by backend API)"),
  prdId: z.uuid().optional().describe("PRD ID to associate with this techspec"),
  issueId: z.uuid().optional().describe("Parent issue ID for cache invalidation"),
});

const techspecUpdateInteractionMetadataSchema = interactionMetadataSchema
  .extend({
    type: z.literal("approval"),
    uiComponent: z.literal("techspec-review"),
    tool: z.literal("mcp__techspec__update_techspec").optional(),
  })
  .default({
    type: "approval",
    uiComponent: "techspec-review",
    requiresInput: true,
    tool: "mcp__techspec__update_techspec",
  });

export const techspecUpdateArtifactSchema = z.object({
  techspecId: z.uuid(),
  title: z.string().optional(),
  summary: z.string().optional(),
  content: z.string().optional(),
  prdId: z.uuid().optional(),
  expectedVersion: z.number().int().min(1),
  _interaction: techspecUpdateInteractionMetadataSchema,
});

export const techspecCreatedEventSchema = z.object({
  type: z.literal("TECHSPEC_CREATED"),
  techspecId: z.uuid(),
  issueId: z.uuid().optional(),
  prdId: z.uuid().optional(),
  techspec: techspecArtifactSchema,
});

export const techspecUpdatedEventSchema = z.object({
  type: z.literal("TECHSPEC_UPDATED"),
  techspecId: z.uuid(),
  issueId: z.uuid().optional(),
  prdId: z.uuid().optional(),
  changes: z
    .object({
      title: z.string().optional(),
      summary: z.string().optional(),
      content: z.string().optional(),
      prdId: z.uuid().optional(),
    })
    .refine(
      (value: Record<string, unknown>) => Object.keys(value).length > 0,
      "At least one field must be provided"
    ),
});

export const techspecDeletedEventSchema = z.object({
  type: z.literal("TECHSPEC_DELETED"),
  techspecId: z.uuid(),
  issueId: z.uuid().optional(),
  prdId: z.uuid().optional(),
});

export const techspecEventSchema = z.discriminatedUnion("type", [
  techspecCreatedEventSchema,
  techspecUpdatedEventSchema,
  techspecDeletedEventSchema,
]);

const updateTechspecDefinition = defineTool({
  name: "update_techspec",
  description:
    "MANDATORY TOOL: Call this tool when you have completed Tech Spec updates and are ready to present them for review. The Tech Spec updates will be presented for user approval before applying. Requires the Tech Spec ID and expectedVersion for optimistic locking.",
  schemas: {
    input: techspecUpdateInputSchema,
    artifact: techspecUpdateArtifactSchema,
    event: techspecUpdatedEventSchema,
  },
  behavior: {
    stopOnUse: true,
  },
  interaction: {
    type: "approval",
    uiComponent: "techspec-review",
    autoSync: true,
  },
});

const createTechspecDefinition = defineTool({
  name: "create_techspec",
  description:
    "MANDATORY TOOL: Call this tool to present the completed Tech Spec. The Tech Spec will be presented for user approval before creation.",
  schemas: {
    input: techspecInputSchema,
    artifact: techspecArtifactSchema,
    event: techspecCreatedEventSchema,
  },
  behavior: {
    stopOnUse: true,
  },
  interaction: {
    type: "approval",
    uiComponent: "techspec-review",
    autoSync: true,
  },
});

const listTechspecsDefinition = defineTool({
  name: "list_techspecs",
  description:
    "MANDATORY: Always call this FIRST before any create/update operation. List TechSpecs. Use this tool to check if a TechSpec already exists for an issue before creating a new one or making modifications. You can filter by issueId or prdId if needed.",
  schemas: {
    input: z.object({
      issueId: z.string().uuid().optional().describe("Filter TechSpecs by parent issue ID"),
      prdId: z.string().uuid().optional().describe("Filter TechSpecs by associated PRD ID"),
      limit: z
        .number()
        .int()
        .min(1)
        .max(100)
        .default(25)
        .optional()
        .describe("Maximum number of TechSpecs to return"),
      offset: z.number().int().min(0).default(0).optional().describe("Number of TechSpecs to skip"),
    }),
  },
});

const getTechspecDefinition = defineTool({
  name: "get_techspec",
  description:
    "Get a TechSpec by ID. Use this tool to retrieve an existing TechSpec's details, including its content and metadata.",
  schemas: {
    input: z.object({
      techspecId: z.string().uuid().describe("The TechSpec ID to retrieve"),
    }),
  },
});

export const updateTechspecTool = new AgentTool(updateTechspecDefinition, TECHSPEC_TOOL_NAMESPACE);
export const createTechspecTool = new AgentTool(createTechspecDefinition, TECHSPEC_TOOL_NAMESPACE);
export const listTechspecsTool = new AgentTool(listTechspecsDefinition, TECHSPEC_TOOL_NAMESPACE);
export const getTechspecTool = new AgentTool(getTechspecDefinition, TECHSPEC_TOOL_NAMESPACE);
