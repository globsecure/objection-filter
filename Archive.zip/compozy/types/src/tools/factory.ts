import type { ToolDefinition } from "./definition";
import { z } from "zod";
import type { ZodObject, ZodRawShape, ZodTypeAny } from "zod";
import { z as z3 } from "zod3";
import type {
  ZodObject as ZodV3Object,
  ZodRawShape as ZodV3RawShape,
  ZodTypeAny as ZodV3TypeAny,
} from "zod3";
import type { ToolStreamContext } from "./stream-context";
import { ErrorClassifier, type RetryConfig } from "./error-classifier";

const unknownTypeWarnings = new Set<string>();

function normalizeTypeName(typeName: string | undefined) {
  if (!typeName) return undefined;
  return typeName.replace(/^Zod/, "").toLowerCase();
}

/**
 * Handles tool execution errors with retry logic and error enhancement.
 * Checks if error is retryable and enhances error messages with context for agent self-correction.
 */
function handleToolError(error: unknown, toolName: string, classifier: ErrorClassifier): never {
  // Check if error is retryable (blacklist approach - defaults to retryable)
  const retryable = classifier.isRetryable(error);

  if (!retryable) {
    // Non-retryable errors: throw immediately without enhancement
    throw error;
  }

  // Retryable errors: enhance error message with context for agent self-correction
  const errorContext = classifier.extractContext(error);
  const enhancedMessage = classifier.formatForAgent(error, 1);

  // Create enhanced error with context
  const enhancedError = new Error(enhancedMessage);
  if (error instanceof Error) {
    enhancedError.name = error.name;
    if (error.stack !== undefined) {
      enhancedError.stack = error.stack;
    }
  }

  // Attach context to error for stream-level interception
  (enhancedError as any).__toolErrorContext = {
    originalError: error,
    context: errorContext,
    retryable: true,
    toolName,
  };

  throw enhancedError;
}

export type CreateAgentToolOptions = {
  /**
   * Allows interactive tools to declare a response schema that differs from
   * the artifact schema defined in ToolDefinition.
   */
  outputSchema?: z.ZodTypeAny;
  /**
   * Optional stream context for writing custom data parts. If provided and tool has
   * interaction config, the handler will write a custom data part for HITL UI rendering.
   * This abstracts the streaming implementation to enable provider portability.
   */
  streamContext?: ToolStreamContext;
  /**
   * Retry configuration for tool error handling
   */
  retryConfig?: RetryConfig;
};

/**
 * Tool definition structure for MCP server tools.
 * Matches the reference implementation pattern from claude-code-acp.
 */
export type AgentToolDefinition = {
  name: string;
  description: string;
  inputSchema: z.ZodType<object>;
  handler: (input: object) => Promise<any>;
  /**
   * Zod v3 schema shape for MCP tool registration compatibility.
   * This is used internally when registering tools with createSdkMcpServer.
   */
  mcpInputShape: Record<string, ZodV3TypeAny>;
  /**
   * Whether the agent should stop generation after using this tool.
   * Preserved from the original ToolDefinition.
   */
  stopOnUse?: boolean;
};

/**
 * Extracts the Zod definition from a schema, handling both Zod v3 and v4.
 */
function getZodDef(schema: ZodTypeAny | undefined) {
  if (!schema) return undefined;
  const maybeDef = (schema as unknown as { _def?: unknown; _zod?: { def?: unknown } })._def;
  const z4Def = (schema as unknown as { _def?: unknown; _zod?: { def?: unknown } })._zod?.def;
  return (maybeDef ?? z4Def) as
    | {
        type?: string;
        typeName?: string;
        description?: string;
        shape?: ZodRawShape | (() => ZodRawShape);
        element?: ZodTypeAny;
        options?: ZodTypeAny[];
        optionsMap?: Map<string, ZodTypeAny>;
        discriminator?: string;
        entries?: Record<string, string>;
        values?: unknown[];
        value?: unknown;
        innerType?: ZodTypeAny;
        defaultValue?: unknown;
        keyType?: ZodTypeAny;
        valueType?: ZodTypeAny;
        items?: ZodTypeAny[];
        left?: ZodTypeAny;
        right?: ZodTypeAny;
      }
    | undefined;
}

function isOptionalField(schema: ZodTypeAny): boolean {
  return schema.safeParse(undefined).success;
}

export function enrichStructuredContentForArtifact(
  input: Record<string, unknown>,
  artifactSchema: ZodTypeAny | undefined
): Record<string, unknown> {
  if (!artifactSchema || !(artifactSchema instanceof z.ZodObject)) {
    return input;
  }

  const initialParse = artifactSchema.safeParse(input);
  if (initialParse.success) {
    return initialParse.data;
  }

  const enriched: Record<string, unknown> = { ...input };
  const shape = artifactSchema.shape;

  for (const [key, schema] of Object.entries(shape)) {
    if (enriched[key] !== undefined) continue;
    if (isOptionalField(schema)) continue;

    const needsGeneratedId =
      key === "id" ||
      key === "artifactId" ||
      key === "toolCallId" ||
      key === "tasksId" ||
      key === "taskId" ||
      key === "questionId" ||
      key.toLowerCase().endsWith("id");

    if (needsGeneratedId) {
      enriched[key] = crypto.randomUUID();
    }
  }

  const enrichedParse = artifactSchema.safeParse(enriched);
  return enrichedParse.success ? enrichedParse.data : input;
}

/**
 * Converts a Zod v4 (or v3) schema to Zod v3 format for MCP tool registration.
 * This is necessary because @anthropic-ai/claude-agent-sdk requires Zod v3 schemas.
 */
function convertToZodV3(schema: ZodTypeAny | undefined): ZodV3TypeAny {
  if (!schema) return z3.any();

  const def = getZodDef(schema);
  const typeName = def?.type ?? def?.typeName;
  const normalizedTypeName = normalizeTypeName(typeName);

  let converted: ZodV3TypeAny;

  switch (normalizedTypeName) {
    case "string":
      converted = z3.string();
      break;
    case "number":
      converted = z3.number();
      break;
    case "boolean":
      converted = z3.boolean();
      break;
    case "date":
      converted = z3.date();
      break;
    case "literal": {
      const literalValue = def?.value ?? def?.values?.[0];
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      converted = z3.literal(literalValue as any);
      break;
    }
    case "null":
      converted = z3.null();
      break;
    case "undefined":
    case "void":
      converted = z3.undefined();
      break;
    case "any":
      converted = z3.any();
      break;
    case "unknown":
      converted = z3.unknown();
      break;
    case "enum": {
      const entries = def?.entries ?? {};
      const values = Object.values(entries);
      converted =
        values.length > 0 ? z3.enum(values as [string, ...string[]]) : z3.enum([""] as [string]);
      break;
    }
    case "object": {
      const shape = typeof def?.shape === "function" ? def.shape() : (def?.shape ?? {});
      const convertedShape = Object.fromEntries(
        Object.entries(shape)
          .filter(([, value]) => value)
          .map(([key, value]) => [key, convertToZodV3(value as ZodTypeAny)])
      ) as ZodV3RawShape;
      converted = z3.object(convertedShape);
      break;
    }
    case "array":
      converted = z3.array(convertToZodV3(def?.element as ZodTypeAny));
      break;
    case "union": {
      const options = def?.options ?? [];
      const convertedOptions = options.map(option => convertToZodV3(option));
      if (convertedOptions.length >= 2) {
        converted = z3.union(convertedOptions as [ZodV3TypeAny, ZodV3TypeAny, ...ZodV3TypeAny[]]);
      } else if (convertedOptions.length === 1) {
        converted = convertedOptions[0] as ZodV3TypeAny;
      } else {
        converted = z3.any();
      }
      break;
    }
    case "record":
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      converted = z3.record(
        convertToZodV3(def?.keyType as ZodTypeAny) as any,
        convertToZodV3(def?.valueType as ZodTypeAny)
      );
      break;
    case "optional":
      converted = convertToZodV3(def?.innerType as ZodTypeAny).optional();
      break;
    case "nullable":
      converted = convertToZodV3(def?.innerType as ZodTypeAny).nullable();
      break;
    case "nullish":
      converted = convertToZodV3(def?.innerType as ZodTypeAny).nullish();
      break;
    case "default":
      converted = convertToZodV3(def?.innerType as ZodTypeAny).default(def?.defaultValue);
      break;
    case "effects": {
      const innerSchema =
        (def as { schema?: ZodTypeAny; innerType?: ZodTypeAny }).schema ??
        (def as { innerType?: ZodTypeAny }).innerType;
      converted = convertToZodV3(innerSchema as ZodTypeAny);
      break;
    }
    case "tuple": {
      const items = def?.items ?? [];
      const convertedItems = items.map(item => convertToZodV3(item));
      converted = convertedItems.length
        ? z3.tuple(convertedItems as [ZodV3TypeAny, ...ZodV3TypeAny[]])
        : z3.tuple([]);
      break;
    }
    case "intersection":
      converted = z3.intersection(
        convertToZodV3(def?.left as ZodTypeAny),
        convertToZodV3(def?.right as ZodTypeAny)
      );
      break;
    default:
      if (process.env.NODE_ENV !== "production") {
        const warningKey = normalizedTypeName ?? "unknown";
        if (!unknownTypeWarnings.has(warningKey)) {
          unknownTypeWarnings.add(warningKey);
          console.warn(
            `[tool-factory] Unsupported Zod type "${typeName ?? "unknown"}" encountered; falling back to z3.any()`
          );
        }
      }
      converted = z3.any();
      break;
  }

  const description = def?.description ?? (schema as { description?: string }).description;
  return description ? converted.describe(description) : converted;
}

/**
 * Converts a ZodObject schema to Zod v3 format for MCP tool registration.
 */
function convertObjectToZodV3(schema: ZodObject<ZodRawShape>): ZodV3Object<ZodV3RawShape> {
  const converted = convertToZodV3(schema);
  if (converted instanceof z3.ZodObject) {
    return converted as ZodV3Object<ZodV3RawShape>;
  }
  throw new Error("Failed to convert schema to Zod v3 object for MCP tool registration");
}

/**
 * Helper function to enrich data with artifact schema defaults and write custom data part
 * if stream context and interaction config are available.
 * Extracted to avoid duplication between withExecution and createAgentTool.
 *
 * @param data - The raw data to enrich and optionally write
 * @param definition - Tool definition to check for interaction config and artifact schema
 * @param streamContext - Optional stream context for writing custom data parts
 * @returns The enriched structured content data
 */
function enrichAndWriteDataPart<TResult = Record<string, unknown>>(
  data: Record<string, unknown>,
  definition: ToolDefinition<z.ZodTypeAny, any, any>,
  streamContext?: ToolStreamContext
): TResult {
  const structuredContentData = enrichStructuredContentForArtifact(
    data,
    definition.schemas.artifact
  ) as TResult;
  if (streamContext && definition.interaction?.uiComponent) {
    streamContext.writeDataPart(
      `data-${definition.interaction.uiComponent}`,
      structuredContentData as Record<string, unknown>
    );
  }
  return structuredContentData;
}

/**
 * Helper function to abstract stream context logic for tool implementations.
 * Executes the provided function, enriches the result with artifact schema defaults,
 * and writes the result as a custom data part if stream context and interaction config are available.
 * This matches the behavior of createAgentTool's non-implementation path.
 *
 * @param execution - Function that returns the artifact data
 * @param definition - Tool definition to check for interaction config and artifact schema
 * @param streamContext - Optional stream context for writing custom data parts
 * @returns The result of the execution function (enriched if artifact schema is available)
 */
export function withExecution<TInput extends z.ZodTypeAny, TResult>(
  execution: (input: z.infer<TInput>) => Promise<TResult>,
  definition: ToolDefinition<TInput, any, any>,
  streamContext?: ToolStreamContext
): (input: z.infer<TInput>) => Promise<TResult> {
  return async (input: z.infer<TInput>): Promise<TResult> => {
    const result = await execution(input);
    return enrichAndWriteDataPart<TResult>(
      result as Record<string, unknown>,
      definition,
      streamContext
    );
  };
}

/**
 * Minimal wrapper that turns a shared ToolDefinition into a tool definition
 * for MCP server registration.
 *
 * - If no implementation is provided (interactive tools), returns input as content.
 * - Tool handlers return { content: [{ type: 'text', text: string }] } format.
 * - Callers may override the output schema for interactive tools while still
 *   reusing the shared input schema/metadata.
 * - Converts Zod v4 schemas to Zod v3 for MCP tool registration compatibility.
 */
export function createAgentTool<
  TInput extends z.ZodTypeAny,
  TArtifact extends z.ZodTypeAny | undefined = undefined,
  TEvent extends z.ZodTypeAny | undefined = undefined,
>(
  definition: ToolDefinition<TInput, TArtifact, TEvent>,
  implementation?: (input: z.infer<TInput>) => Promise<unknown>,
  options: CreateAgentToolOptions = {}
): AgentToolDefinition {
  const { streamContext } = options;

  const classifier = new ErrorClassifier(options.retryConfig);

  const handler = implementation
    ? async (input: object): Promise<any> => {
        try {
          // Validate and parse input against Zod v4 schema before passing to implementation
          // The MCP SDK validates against Zod v3 schema, but we need to ensure
          // the input matches our Zod v4 schema for type safety
          const parsedInput = definition.schemas.input.parse(input);
          const result = await implementation(parsedInput);
          return {
            content: [{ type: "text", text: JSON.stringify(result) }],
            structuredContent: result as Record<string, unknown>,
          };
        } catch (error) {
          handleToolError(error, definition.name, classifier);
        }
      }
    : async (input: object): Promise<any> => {
        try {
          // Validate and parse input against Zod v4 schema
          const parsedInput = definition.schemas.input.parse(input);
          const structuredContentData = enrichAndWriteDataPart(
            parsedInput as Record<string, unknown>,
            definition,
            streamContext
          );
          return {
            content: [{ type: "text", text: JSON.stringify(parsedInput) }],
            structuredContent: structuredContentData,
          };
        } catch (error) {
          handleToolError(error, definition.name, classifier);
        }
      };

  if (!(definition.schemas.input instanceof z.ZodObject)) {
    throw new Error(
      `Tool ${definition.name} input schema must be a ZodObject, got ${definition.schemas.input.constructor.name}`
    );
  }

  const inputSchema = definition.schemas.input as unknown as ZodObject<ZodRawShape>;
  const mcpInputSchema = convertObjectToZodV3(inputSchema);
  // Extract shape from Zod v3 object - in Zod v3, shape is directly accessible
  // Type assertion needed due to Zod v3/v4 type differences
  const mcpInputShape = mcpInputSchema.shape as Record<string, ZodV3TypeAny>;
  const result: AgentToolDefinition = {
    name: definition.name,
    description: definition.description,
    inputSchema: definition.schemas.input as z.ZodType<object>,
    handler: handler as (input: object) => Promise<any>,
    mcpInputShape,
    ...(definition.behavior?.stopOnUse !== undefined && {
      stopOnUse: definition.behavior.stopOnUse,
    }),
  };

  return result;
}
