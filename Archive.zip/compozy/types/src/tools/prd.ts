import { z } from "zod";
import { AgentTool, defineTool, interactionMetadataSchema } from "./definition";

const PRD_TOOL_NAMESPACE = "mcp__prd__" as const;

export const prdInputSchema = z.object({
  title: z
    .string()
    .min(1)
    .describe("PRD title – the feature or product name as it should appear in the document"),
  overview: z
    .string()
    .min(1)
    .describe(
      "High-level overview describing the user problem, target audience, and business value"
    ),
  content: z
    .string()
    .min(1)
    .describe(
      "Complete PRD content in markdown format. Follow the standard sections: Overview, Goals, Success Metrics, User Stories, Core Features, User Experience, Non-Goals, and Risks."
    ),
  issueId: z.uuid().optional().describe("Parent issue ID that this PRD belongs to"),
});

const prdInteractionMetadataSchema = interactionMetadataSchema
  .extend({
    type: z.literal("approval"),
    uiComponent: z.literal("prd-review"),
    tool: z.literal("mcp__prd__create_prd").optional(),
  })
  .default({
    type: "approval",
    uiComponent: "prd-review",
    requiresInput: true,
    tool: "mcp__prd__create_prd",
  });

export const prdArtifactSchema = z.object({
  prdId: z.uuid(),
  title: z.string(),
  overview: z.string(),
  content: z.string(),
  issueId: z.uuid().optional(),
  _interaction: prdInteractionMetadataSchema,
});

export const prdUpdateInputSchema = prdInputSchema.partial().extend({
  id: z.uuid().describe("PRD ID to update"),
  expectedVersion: z
    .number()
    .int()
    .min(1)
    .describe("Expected version number for optimistic locking (required by backend API)"),
  issueId: z.uuid().optional().describe("Parent issue ID for cache invalidation"),
});

const prdUpdateInteractionMetadataSchema = interactionMetadataSchema
  .extend({
    type: z.literal("approval"),
    uiComponent: z.literal("prd-review"),
    tool: z.literal("mcp__prd__update_prd").optional(),
  })
  .default({
    type: "approval",
    uiComponent: "prd-review",
    requiresInput: true,
    tool: "mcp__prd__update_prd",
  });

export const prdUpdateArtifactSchema = z.object({
  prdId: z.uuid(),
  title: z.string().optional(),
  overview: z.string().optional(),
  content: z.string().optional(),
  expectedVersion: z.number().int().min(1),
  _interaction: prdUpdateInteractionMetadataSchema,
});

export const prdCreatedEventSchema = z.object({
  type: z.literal("PRD_CREATED"),
  prdId: z.uuid(),
  issueId: z.uuid().optional(),
  prd: prdArtifactSchema,
});

export const prdUpdatedEventSchema = z.object({
  type: z.literal("PRD_UPDATED"),
  prdId: z.uuid(),
  issueId: z.uuid().optional(),
  changes: z
    .object({
      title: z.string().optional(),
      overview: z.string().optional(),
      content: z.string().optional(),
    })
    .refine(
      (value: Record<string, unknown>) => Object.keys(value).length > 0,
      "At least one field must be provided"
    ),
});

export const prdDeletedEventSchema = z.object({
  type: z.literal("PRD_DELETED"),
  prdId: z.uuid(),
  issueId: z.uuid().optional(),
});

export const prdEventSchema = z.discriminatedUnion("type", [
  prdCreatedEventSchema,
  prdUpdatedEventSchema,
  prdDeletedEventSchema,
]);

const updatePrdDefinition = defineTool({
  name: "update_prd",
  description:
    "MANDATORY TOOL: Call this tool when you have completed PRD updates and are ready to present them for review. The PRD updates will be presented for user approval before applying. Requires the PRD ID and expectedVersion for optimistic locking.",
  schemas: {
    input: prdUpdateInputSchema,
    artifact: prdUpdateArtifactSchema,
    event: prdUpdatedEventSchema,
  },
  behavior: {
    stopOnUse: true,
  },
  interaction: {
    type: "approval",
    uiComponent: "prd-review",
    autoSync: true,
  },
});

const createPrdDefinition = defineTool({
  name: "create_prd",
  description:
    "MANDATORY TOOL: Call this tool when you have completed the PRD draft and are ready to present it for review. Always return fully formatted markdown content. The PRD will be presented for user approval before creation.",
  schemas: {
    input: prdInputSchema,
    artifact: prdArtifactSchema,
    event: prdCreatedEventSchema,
  },
  behavior: {
    stopOnUse: true,
  },
  interaction: {
    type: "approval",
    uiComponent: "prd-review",
    autoSync: true,
  },
});

const listPrdsDefinition = defineTool({
  name: "list_prds",
  description:
    "MANDATORY: Always call this FIRST before any create/update operation. List PRDs. Use this tool to check if a PRD already exists for an issue before creating a new one or making modifications. You can filter by issueId.",
  schemas: {
    input: z.object({
      issueId: z.string().uuid().optional().describe("Filter PRDs by parent issue ID"),
      limit: z
        .number()
        .int()
        .min(1)
        .max(100)
        .default(25)
        .optional()
        .describe("Maximum number of PRDs to return"),
      offset: z.number().int().min(0).default(0).optional().describe("Number of PRDs to skip"),
    }),
  },
});

const getPrdDefinition = defineTool({
  name: "get_prd",
  description:
    "Get a PRD by ID. Use this tool to retrieve an existing PRD's details, including its content and metadata.",
  schemas: {
    input: z.object({
      prdId: z.string().uuid().describe("The PRD ID to retrieve"),
    }),
  },
});

export const updatePrdTool = new AgentTool(updatePrdDefinition, PRD_TOOL_NAMESPACE);
export const createPrdTool = new AgentTool(createPrdDefinition, PRD_TOOL_NAMESPACE);
export const listPrdsTool = new AgentTool(listPrdsDefinition, PRD_TOOL_NAMESPACE);
export const getPrdTool = new AgentTool(getPrdDefinition, PRD_TOOL_NAMESPACE);
