import { z } from "zod";

export type ToolSchemas<
  TInput extends z.ZodTypeAny,
  TArtifact extends z.ZodTypeAny | undefined,
  TEvent extends z.ZodTypeAny | undefined,
> = {
  input: TInput;
  artifact?: TArtifact;
  event?: TEvent;
};

export type ToolDefinition<
  TInput extends z.ZodTypeAny,
  TArtifact extends z.ZodTypeAny | undefined = undefined,
  TEvent extends z.ZodTypeAny | undefined = undefined,
> = {
  name: string;
  description: string;
  schemas: ToolSchemas<TInput, TArtifact, TEvent>;
  behavior?: {
    stopOnUse?: boolean; // If true, the agent stops generation after this tool is used
  };
  /**
   * Optional human-in-the-loop interaction configuration.
   * When present, the tool execution should pause until the interaction is resolved.
   */
  interaction?: ToolInteractionConfig;
};

export function defineTool<
  TInput extends z.ZodTypeAny,
  TArtifact extends z.ZodTypeAny | undefined = undefined,
  TEvent extends z.ZodTypeAny | undefined = undefined,
>(definition: ToolDefinition<TInput, TArtifact, TEvent>) {
  return definition;
}

/**
 * AgentTool wraps a ToolDefinition with namespace handling for MCP tool naming.
 * This class encapsulates the logic for generating full tool names and provides
 * convenient access to tool properties.
 */
export class AgentTool<
  TInput extends z.ZodTypeAny,
  TArtifact extends z.ZodTypeAny | undefined = undefined,
  TEvent extends z.ZodTypeAny | undefined = undefined,
> {
  constructor(
    public readonly definition: ToolDefinition<TInput, TArtifact, TEvent>,
    public readonly namespace: string = ""
  ) {}

  /**
   * The tool name from the definition
   */
  get name(): string {
    return this.definition.name;
  }

  /**
   * The full tool name including namespace (e.g., "mcp__prd__create_prd")
   */
  get fullName(): string {
    return `${this.namespace}${this.definition.name}`;
  }

  /**
   * The tool description
   */
  get description(): string {
    return this.definition.description;
  }

  /**
   * The tool schemas (input, artifact, event)
   */
  get schemas(): ToolSchemas<TInput, TArtifact, TEvent> {
    return this.definition.schemas;
  }

  /**
   * The tool behavior configuration
   */
  get behavior(): ToolDefinition<TInput, TArtifact, TEvent>["behavior"] {
    return this.definition.behavior;
  }

  /**
   * The tool interaction configuration (if any)
   */
  get interaction(): ToolDefinition<TInput, TArtifact, TEvent>["interaction"] {
    return this.definition.interaction;
  }

  /**
   * Check if this tool should stop generation on use
   */
  get stopOnUse(): boolean {
    return this.definition.behavior?.stopOnUse ?? false;
  }
}

export type InferToolInput<TDef extends ToolDefinition<z.ZodTypeAny, any, any>> = z.infer<
  TDef["schemas"]["input"]
>;

export type InferToolArtifact<
  TDef extends ToolDefinition<z.ZodTypeAny, z.ZodTypeAny | undefined, any>,
> = TDef["schemas"]["artifact"] extends z.ZodTypeAny
  ? z.infer<NonNullable<TDef["schemas"]["artifact"]>>
  : never;

export type InferToolEvent<
  TDef extends ToolDefinition<z.ZodTypeAny, any, z.ZodTypeAny | undefined>,
> = TDef["schemas"]["event"] extends z.ZodTypeAny
  ? z.infer<NonNullable<TDef["schemas"]["event"]>>
  : never;

export type ToolArtifactPart<
  TDef extends ToolDefinition<z.ZodTypeAny, z.ZodTypeAny | undefined, any>,
> = TDef["schemas"]["artifact"] extends z.ZodTypeAny
  ? {
      type: "tool-artifact";
      tool: TDef["name"];
      id?: string;
      data: InferToolArtifact<TDef>;
    }
  : never;

export type ToolEventPart<
  TDef extends ToolDefinition<z.ZodTypeAny, any, z.ZodTypeAny | undefined>,
> = TDef["schemas"]["event"] extends z.ZodTypeAny
  ? {
      type: "tool-event";
      tool: TDef["name"];
      id?: string;
      data: InferToolEvent<TDef>;
    }
  : never;

export type AnyToolArtifactPart = {
  type: "tool-artifact";
  tool: string;
  id?: string;
  data: unknown;
};

export type AnyToolEventPart = {
  type: "tool-event";
  tool: string;
  id?: string;
  data: unknown;
};

export type ToolInteractionType = "approval" | "form" | "custom";

export interface ToolInteractionConfig {
  /**
   * Interaction category used by the frontend renderer.
   */
  type: ToolInteractionType;
  /**
   * Component key used by the registry to render the right UI.
   */
  uiComponent: string;
  /**
   * Whether draft updates should be auto-synced (default true).
   */
  autoSync?: boolean;
}

/**
 * Shared metadata embedded into interactive tool artifacts so the frontend
 * can render HITL components without relying on external pending-interaction
 * records. Defaults are filled by the schemas of interactive tools, ensuring
 * the metadata survives persistence/reloads even when the model does not
 * explicitly include it.
 */
export const interactionMetadataSchema = z.object({
  type: z.literal("approval").or(z.literal("form")).or(z.literal("custom")),
  uiComponent: z.string(),
  requiresInput: z.boolean().default(true),
  tool: z.string().optional(),
});

export type InteractionMetadata = z.infer<typeof interactionMetadataSchema>;
