import { describe, it, expect } from "vitest";
import { z } from "zod";
import { z as z3 } from "zod3";
import { defineTool } from "./definition.js";
import { createAgentTool } from "./factory.js";

describe("createAgentTool with Retry Logic", () => {
  describe("Error Handling", () => {
    it("should enhance retryable errors with context", async () => {
      const definition = defineTool({
        name: "test_tool",
        description: "Test tool",
        schemas: {
          input: z.object({
            value: z.string().min(5),
          }),
        },
      });

      const implementation = async (_input: { value: string }) => {
        throw new Error("Validation failed");
      };

      const tool = createAgentTool(definition, implementation);

      try {
        await tool.handler({ value: "abc" });
        throw new Error("Should have thrown");
      } catch (error) {
        expect(error).toBeInstanceOf(Error);
        const errorMessage = (error as Error).message;
        expect(errorMessage).toContain("Tool execution failed");
        expect(errorMessage).toContain("Validation failed");
      }
    });

    it("should not enhance non-retryable errors", async () => {
      const definition = defineTool({
        name: "test_tool",
        description: "Test tool",
        schemas: {
          input: z.object({
            value: z.string(),
          }),
        },
      });

      const implementation = async (_input: { value: string }) => {
        const error = new Error("Resource not found");
        throw error;
      };

      const tool = createAgentTool(definition, implementation);

      try {
        await tool.handler({ value: "test" });
        throw new Error("Should have thrown");
      } catch (error) {
        expect(error).toBeInstanceOf(Error);
        const errorMessage = (error as Error).message;
        // Non-retryable errors should not be enhanced
        expect(errorMessage).toBe("Resource not found");
      }
    });

    it("should enhance Zod validation errors with field-level details", async () => {
      const definition = defineTool({
        name: "test_tool",
        description: "Test tool",
        schemas: {
          input: z.object({
            name: z.string().min(1),
            age: z.number().int().min(0),
          }),
        },
      });

      const implementation = async (_input: { name: string; age: number }) => {
        return { success: true };
      };

      const tool = createAgentTool(definition, implementation);

      try {
        await tool.handler({ name: "", age: -1 });
        throw new Error("Should have thrown");
      } catch (error) {
        expect(error).toBeInstanceOf(Error);
        const errorMessage = (error as Error).message;
        expect(errorMessage).toContain("Tool execution failed");
        expect(errorMessage).toContain("attempt 1");
        expect(errorMessage).toContain("name");
        expect(errorMessage).toContain("age");
        expect(errorMessage).toContain("Suggestions to fix");
      }
    });

    it("should attach error context to enhanced errors", async () => {
      const definition = defineTool({
        name: "test_tool",
        description: "Test tool",
        schemas: {
          input: z.object({
            value: z.string(),
          }),
        },
      });

      const implementation = async (_input: { value: string }) => {
        throw new Error("Test error");
      };

      const tool = createAgentTool(definition, implementation);

      try {
        await tool.handler({ value: "test" });
        throw new Error("Should have thrown");
      } catch (error) {
        expect(error).toBeInstanceOf(Error);
        const context = (error as any).__toolErrorContext;
        expect(context).toBeDefined();
        expect(context.retryable).toBe(true);
        expect(context.toolName).toBe("test_tool");
        expect(context.context).toBeDefined();
      }
    });

    it("should respect custom retry configuration", async () => {
      const definition = defineTool({
        name: "test_tool",
        description: "Test tool",
        schemas: {
          input: z.object({
            value: z.string(),
          }),
        },
      });

      const implementation = async (_input: { value: string }) => {
        throw new Error("Custom error pattern");
      };

      const tool = createAgentTool(definition, implementation, {
        retryConfig: {
          nonRetryableErrorPatterns: [/custom.*error/i],
        },
      });

      try {
        await tool.handler({ value: "test" });
        throw new Error("Should have thrown");
      } catch (error) {
        expect(error).toBeInstanceOf(Error);
        const errorMessage = (error as Error).message;
        // Should not be enhanced because it matches non-retryable pattern
        expect(errorMessage).toBe("Custom error pattern");
      }
    });
  });

  describe("Successful Execution", () => {
    it("should return result for successful tool execution", async () => {
      const definition = defineTool({
        name: "test_tool",
        description: "Test tool",
        schemas: {
          input: z.object({
            value: z.string(),
          }),
        },
      });

      const implementation = async (input: { value: string }) => {
        return { result: `Processed: ${input.value}` };
      };

      const tool = createAgentTool(definition, implementation);
      const result = await tool.handler({ value: "test" });

      expect(result).toBeDefined();
      expect(result.content).toBeDefined();
      expect(result.structuredContent).toBeDefined();
      expect(result.structuredContent.result).toBe("Processed: test");
    });

    it("should validate input against schema before execution", async () => {
      const definition = defineTool({
        name: "test_tool",
        description: "Test tool",
        schemas: {
          input: z.object({
            value: z.string().min(5),
          }),
        },
      });

      const implementation = async (_input: { value: string }) => {
        return { success: true };
      };

      const tool = createAgentTool(definition, implementation);

      try {
        await tool.handler({ value: "abc" });
        throw new Error("Should have thrown validation error");
      } catch (error) {
        expect(error).toBeInstanceOf(Error);
        // Should be enhanced because validation errors are retryable
        const errorMessage = (error as Error).message;
        expect(errorMessage).toContain("Tool execution failed");
      }
    });
  });
});

describe("createAgentTool schema conversion", () => {
  it("converts refined schemas (effects) to their inner types", () => {
    const definition = defineTool({
      name: "refined",
      description: "Refined string schema",
      schemas: {
        input: z.object({
          title: z.string().refine(value => value.trim().length > 0),
        }),
      },
    });

    const tool = createAgentTool(definition);

    expect(tool.mcpInputShape.title).toBeInstanceOf(z3.ZodString);
  });

  it("maps date schemas to zod3 date", () => {
    const definition = defineTool({
      name: "dates",
      description: "Date schema conversion",
      schemas: {
        input: z.object({ due: z.coerce.date() }),
      },
    });

    const tool = createAgentTool(definition);

    expect(tool.mcpInputShape.due).toBeInstanceOf(z3.ZodDate);
  });

  it("warns once and falls back to any for unsupported schemas", () => {
    const originalWarn = console.warn;
    const warnings: string[] = [];
    console.warn = (...args: unknown[]) => {
      warnings.push(args.map(String).join(" "));
    };

    try {
      const definition = defineTool({
        name: "fn_tool",
        description: "Function schema",
        schemas: {
          input: z.object({
            handler: z.lazy(() => z.string()),
          }),
        },
      });

      const tool = createAgentTool(definition);

      expect(tool.mcpInputShape.handler).toBeInstanceOf(z3.ZodAny);
      expect(warnings.length).toBe(1);
      expect(warnings[0]).toContain("Unsupported Zod type");
      expect(warnings[0]).toContain("lazy");
    } finally {
      console.warn = originalWarn;
    }
  });
});
