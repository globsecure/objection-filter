import { describe, it, expect } from "vitest";
import { z } from "zod";
import { ErrorClassifier, DEFAULT_RETRY_CONFIG, type RetryConfig } from "./error-classifier.js";

describe("ErrorClassifier", () => {
  describe("isRetryable", () => {
    it("should default to retryable for unknown errors (blacklist approach)", () => {
      const classifier = new ErrorClassifier();
      const error = new Error("Unknown error");
      expect(classifier.isRetryable(error)).toBe(true);
    });

    it("should return false for errors with explicit isRetryable: false", () => {
      const classifier = new ErrorClassifier();
      const error = {
        isRetryable: false,
        message: "Non-retryable error",
      };
      expect(classifier.isRetryable(error)).toBe(false);
    });

    it("should return false for authentication errors (LoadAPIKeyError)", () => {
      const classifier = new ErrorClassifier();
      const error = {
        name: "LoadAPIKeyError",
        constructor: { name: "LoadAPIKeyError" },
        message: "Authentication failed",
      };
      expect(classifier.isRetryable(error)).toBe(false);
    });

    it("should return false for APICallError with exit code 401", () => {
      const classifier = new ErrorClassifier();
      const error = {
        name: "APICallError",
        constructor: { name: "APICallError" },
        message: "Unauthorized",
        data: { exitCode: 401 },
      };
      expect(classifier.isRetryable(error)).toBe(false);
    });

    it("should return false for errors matching non-retryable patterns", () => {
      const classifier = new ErrorClassifier();
      const nonRetryableErrors = [
        "Resource not found",
        "User does not exist",
        "Invalid user id",
        "Permission denied",
        "Access forbidden",
        "Unauthorized access",
      ];

      nonRetryableErrors.forEach(errorMessage => {
        const error = new Error(errorMessage);
        expect(classifier.isRetryable(error)).toBe(false);
      });
    });

    it("should return true for Zod validation errors (retryable)", () => {
      const classifier = new ErrorClassifier();
      const schema = z.object({ name: z.string(), age: z.number() });
      try {
        schema.parse({ name: 123 });
      } catch (error) {
        expect(classifier.isRetryable(error)).toBe(true);
      }
    });

    it("should return true for Zod errors with 'Invalid UUID' message (bypasses pattern matching)", () => {
      const classifier = new ErrorClassifier();
      const schema = z.object({ id: z.string().uuid() });
      try {
        schema.parse({ id: "not-a-uuid" });
      } catch (error) {
        // "Invalid UUID" would match /invalid.*id/i pattern, but Zod errors should bypass it
        expect(classifier.isRetryable(error)).toBe(true);
      }
    });

    it("should always return true for Zod errors regardless of error message content", () => {
      const classifier = new ErrorClassifier();
      const schema = z.object({
        id: z.string().uuid(),
        resourceId: z.string().min(1),
      });
      try {
        schema.parse({ id: "invalid-uuid", resourceId: "" });
      } catch (error) {
        // Even though messages contain "Invalid UUID" and "resourceId", Zod errors are always retryable
        expect(classifier.isRetryable(error)).toBe(true);
      }
    });

    it("should return true for network errors (retryable)", () => {
      const classifier = new ErrorClassifier();
      const error = new Error("Network timeout");
      expect(classifier.isRetryable(error)).toBe(true);
    });

    it("should respect custom non-retryable patterns", () => {
      const config: RetryConfig = {
        nonRetryableErrorPatterns: [/custom.*error/i],
      };
      const classifier = new ErrorClassifier(config);
      const error = new Error("This is a custom error");
      expect(classifier.isRetryable(error)).toBe(false);
    });

    it("should respect enableAutoRetry flag", () => {
      const config: RetryConfig = {
        enableAutoRetry: false,
      };
      const classifier = new ErrorClassifier(config);
      const error = new Error("Any error");
      expect(classifier.isRetryable(error)).toBe(false);
    });
  });

  describe("extractContext", () => {
    it("should extract context from Zod validation errors", () => {
      const classifier = new ErrorClassifier();
      const schema = z.object({
        name: z.string().min(1),
        age: z.number().int().min(0),
        email: z.string().email(),
      });

      try {
        schema.parse({ name: "", age: -1, email: "invalid" });
      } catch (error) {
        const context = classifier.extractContext(error);
        expect(context.message).toContain("Validation failed");
        expect(context.details).toBeDefined();
        expect(context.details?.fieldErrors).toBeDefined();
        expect(Array.isArray(context.details?.fieldErrors)).toBe(true);
        expect(context.suggestions).toBeDefined();
        expect(context.suggestions!.length).toBeGreaterThan(0);
      }
    });

    it("should extract field-level errors from Zod errors", () => {
      const classifier = new ErrorClassifier();
      const schema = z.object({
        id: z.string().uuid(),
        status: z.enum(["pending", "completed"]),
      });

      try {
        schema.parse({ id: "not-a-uuid", status: "invalid" });
      } catch (error) {
        const context = classifier.extractContext(error);
        expect(context.details).toBeDefined();
        expect(context.details?.fieldErrors).toBeDefined();
        const fieldErrors = context.details?.fieldErrors as Array<{ path: string }>;
        expect(Array.isArray(fieldErrors)).toBe(true);
        expect(fieldErrors.some(err => err.path.includes("id"))).toBe(true);
        expect(fieldErrors.some(err => err.path.includes("status"))).toBe(true);
      }
    });

    it("should extract context from standard Error objects", () => {
      const classifier = new ErrorClassifier();
      const error = new Error("Test error message");
      const context = classifier.extractContext(error);
      expect(context.message).toBe("Test error message");
      expect(context.details).toBeDefined();
      expect(context.details!.name).toBe("Error");
    });

    it("should handle unknown error types", () => {
      const classifier = new ErrorClassifier();
      const error = "String error";
      const context = classifier.extractContext(error);
      expect(context.message).toBe("String error");
      expect(context.details).toBeDefined();
    });

    it("should extract suggestions for missing required fields", () => {
      const classifier = new ErrorClassifier();
      const schema = z.object({
        required: z.string(),
        optional: z.string().optional(),
      });

      try {
        schema.parse({});
      } catch (error) {
        const context = classifier.extractContext(error);
        expect(context.suggestions).toBeDefined();
        expect(context.suggestions!.length).toBeGreaterThan(0);
        // Should have suggestions that reference the missing field or field errors
        const hasRequiredFieldSuggestion = context.suggestions!.some(
          s => s.includes("required") || s.includes("Required") || s.includes("Fix")
        );
        const fieldErrors = context.details?.fieldErrors as Array<unknown> | undefined;
        expect(hasRequiredFieldSuggestion || (fieldErrors?.length ?? 0) > 0).toBe(true);
      }
    });

    it("should extract suggestions for type mismatches", () => {
      const classifier = new ErrorClassifier();
      const schema = z.object({
        count: z.number(),
        name: z.string(),
      });

      try {
        schema.parse({ count: "not-a-number", name: 123 });
      } catch (error) {
        const context = classifier.extractContext(error);
        expect(context.suggestions).toBeDefined();
        expect(context.suggestions!.some(s => s.includes("expects") || s.includes("Fix"))).toBe(
          true
        );
      }
    });
  });

  describe("formatForAgent", () => {
    it("should format Zod validation errors with field details", () => {
      const classifier = new ErrorClassifier();
      const schema = z.object({
        name: z.string().min(1),
        age: z.number(),
      });

      try {
        schema.parse({ name: "", age: "not-a-number" });
      } catch (error) {
        const formatted = classifier.formatForAgent(error, 1);
        expect(formatted).toContain("Tool execution failed");
        expect(formatted).toContain("attempt 1");
        expect(formatted).toContain("name");
        expect(formatted).toContain("age");
      }
    });

    it("should include attempt number in formatted message", () => {
      const classifier = new ErrorClassifier();
      const error = new Error("Test error");
      const formatted = classifier.formatForAgent(error, 2);
      expect(formatted).toContain("attempt 2");
    });

    it("should include suggestions in formatted message", () => {
      const classifier = new ErrorClassifier();
      const schema = z.object({
        id: z.string().uuid(),
      });

      try {
        schema.parse({ id: "invalid" });
      } catch (error) {
        const formatted = classifier.formatForAgent(error, 1);
        expect(formatted).toContain("Suggestions to fix");
      }
    });

    it("should indicate non-retryable errors", () => {
      const classifier = new ErrorClassifier();
      const error = new Error("Resource not found");
      const formatted = classifier.formatForAgent(error, 1);
      // Note: formatForAgent checks isRetryable internally
      // Since "not found" matches a non-retryable pattern, it should indicate this
      expect(formatted).toBeDefined();
    });
  });

  describe("createEnhancedMessage", () => {
    it("should create enhanced error message with attempt 1", () => {
      const classifier = new ErrorClassifier();
      const error = new Error("Test error");
      const message = classifier.createEnhancedMessage(error);
      expect(message).toContain("attempt 1");
      expect(message).toContain("Test error");
    });
  });

  describe("withDefaults", () => {
    it("should create classifier with default configuration", () => {
      const classifier = ErrorClassifier.withDefaults();
      expect(classifier).toBeInstanceOf(ErrorClassifier);
      const error = new Error("Test error");
      expect(classifier.isRetryable(error)).toBe(true);
    });
  });

  describe("DEFAULT_RETRY_CONFIG", () => {
    it("should have sensible defaults", () => {
      expect(DEFAULT_RETRY_CONFIG.maxRetries).toBe(2);
      expect(DEFAULT_RETRY_CONFIG.enableAutoRetry).toBe(true);
      expect(Array.isArray(DEFAULT_RETRY_CONFIG.nonRetryableErrorPatterns)).toBe(true);
    });

    it("should detect non-retryable patterns in error classification", () => {
      const classifier = new ErrorClassifier();
      const testMessages = [
        "Resource not found",
        "User does not exist",
        "Invalid user id",
        "Permission denied",
        "Access forbidden",
        "Unauthorized access",
      ];

      testMessages.forEach(message => {
        const error = new Error(message);
        // These should be detected as non-retryable by the classifier's built-in patterns
        expect(classifier.isRetryable(error)).toBe(false);
      });
    });
  });
});
