import { invariant } from "es-toolkit/util";
import type { AgentToolDefinition } from "./factory";

/**
 * Tools class that manages tool definitions and provides a builder pattern
 * for creating tools. This abstracts interactive tools logic and eliminates
 * the need to pass toolDefinitions around.
 *
 * @template TServerConfig - The type of server configuration returned by createTools
 */
export class Tools<TServerConfig = any> {
  private tools: Map<string, AgentToolDefinition> = new Map();
  private createToolsFn?: (
    tools: AgentToolDefinition[],
    config: { name: string; version?: string }
  ) => TServerConfig;

  /**
   * Register a tool in the registry.
   */
  register(tool: AgentToolDefinition): void {
    this.tools.set(tool.name, tool);
  }

  /**
   * Register multiple tools at once.
   */
  registerMany(tools: AgentToolDefinition[]): void {
    for (const tool of tools) {
      this.register(tool);
    }
  }

  /**
   * Get a tool by name.
   */
  get(name: string): AgentToolDefinition | undefined {
    return this.tools.get(name);
  }

  /**
   * Get all registered tools as a record.
   */
  getAll(): Record<string, AgentToolDefinition> {
    return Object.fromEntries(this.tools);
  }

  /**
   * Set the function responsible for creating the MCP server.
   * This implements the curry pattern where the creator is injected.
   */
  setCreateTools(
    fn: (tools: AgentToolDefinition[], config: { name: string; version?: string }) => TServerConfig
  ): void {
    this.createToolsFn = fn;
  }

  /**
   * Create an MCP server using the provided tool definitions and configuration.
   * This registers the tools internally and delegates creation to the injected function.
   *
   * Tools are registered with their full namespaced name (mcp__${serverName}__${toolName})
   * to match how the MCP SDK namespaces tools in tool parts.
   */
  createTools(
    toolDefinitions: AgentToolDefinition[],
    config: { name: string; version?: string }
  ): TServerConfig {
    invariant(this.createToolsFn, "Create tools function not set. Call setCreateTools first.");
    for (const toolDef of toolDefinitions) {
      const fullName = `mcp__${config.name}__${toolDef.name}`;
      this.tools.set(fullName, toolDef);
    }
    return this.createToolsFn!(toolDefinitions, config);
  }

  /**
   * Get all registered tool names that have stopOnUse: true.
   * Returns namespaced tool names (mcp__${server}__${tool}) as they appear in stream chunks.
   */
  getStopOnUseToolNames(): Set<string> {
    const stopOnUseNames = new Set<string>();
    for (const [fullName, tool] of this.tools) {
      if (tool.stopOnUse === true) {
        stopOnUseNames.add(fullName);
      }
    }
    return stopOnUseNames;
  }
}
