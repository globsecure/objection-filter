import { z } from "zod";

/**
 * Retry configuration options for tool error handling
 */
export interface RetryConfig {
  /**
   * Maximum number of retry attempts (default: 2)
   */
  maxRetries?: number;
  /**
   * Additional patterns to identify non-retryable errors (blacklist)
   */
  nonRetryableErrorPatterns?: RegExp[];
  /**
   * Feature flag to enable/disable retry mechanism (default: true)
   */
  enableAutoRetry?: boolean;
}

/**
 * Default retry configuration
 */
export const DEFAULT_RETRY_CONFIG: Required<RetryConfig> = {
  maxRetries: 2,
  nonRetryableErrorPatterns: [],
  enableAutoRetry: true,
};

/**
 * Error context extracted from errors for agent self-correction
 */
export interface ErrorContext {
  message: string;
  details?: Record<string, unknown>;
  suggestions?: string[];
}

/**
 * ErrorClassifier provides error classification and context extraction for tool errors.
 * Encapsulates retry configuration and provides methods for determining retryability
 * and formatting error messages for agent self-correction.
 */
export class ErrorClassifier {
  private readonly config: Required<RetryConfig>;

  /**
   * Creates a new ErrorClassifier instance with the provided configuration.
   * @param config - Retry configuration (defaults to DEFAULT_RETRY_CONFIG)
   */
  constructor(config: RetryConfig = DEFAULT_RETRY_CONFIG) {
    this.config = { ...DEFAULT_RETRY_CONFIG, ...config };
  }

  /**
   * Creates an ErrorClassifier instance with default configuration.
   * Convenience factory method for common use cases.
   */
  static withDefaults(): ErrorClassifier {
    return new ErrorClassifier();
  }

  /**
   * Determines if a tool error is retryable using a blacklist approach.
   * Default behavior: All errors are retryable unless explicitly marked as non-retryable.
   *
   * Non-retryable errors:
   * - Authentication errors (401, 403)
   * - Permanent resource errors (404, invalid IDs)
   * - Errors explicitly marked as isRetryable: false
   * - Permission/forbidden errors
   *
   * Everything else defaults to retryable (validation errors, timeouts, network errors, etc.)
   */
  isRetryable(error: unknown): boolean {
    // If auto-retry is disabled, nothing is retryable
    if (this.config.enableAutoRetry === false) {
      return false;
    }

    // Zod validation errors are ALWAYS retryable (blacklist approach)
    // Check this BEFORE pattern matching to avoid false positives (e.g., "Invalid UUID" matching /invalid.*id/i)
    if (error instanceof z.ZodError) {
      return true;
    }

    // Default to retryable - only exclude specific non-retryable cases

    // Check for explicit non-retryable flag (check error properties without importing classes)
    if (
      error &&
      typeof error === "object" &&
      "isRetryable" in error &&
      error.isRetryable === false
    ) {
      return false;
    }

    // Authentication errors are NOT retryable
    // Check for LoadAPIKeyError or APICallError with exit code 401
    if (error && typeof error === "object") {
      const errorObj = error as Record<string, unknown>;
      // Check for LoadAPIKeyError (name or constructor name)
      if (
        errorObj.name === "LoadAPIKeyError" ||
        (errorObj.constructor &&
          (errorObj.constructor as { name?: string }).name === "LoadAPIKeyError")
      ) {
        return false;
      }
      // Check for APICallError with exit code 401
      if (
        errorObj.name === "APICallError" &&
        errorObj.data &&
        typeof errorObj.data === "object" &&
        "exitCode" in errorObj.data &&
        errorObj.data.exitCode === 401
      ) {
        return false;
      }
    }

    // Permanent resource errors are NOT retryable
    const errorMessage = error instanceof Error ? error.message : String(error);
    const nonRetryablePatterns = [
      /not found/i,
      /does not exist/i,
      /invalid.*id/i,
      /permission denied/i,
      /forbidden/i,
      /unauthorized/i,
      ...(this.config.nonRetryableErrorPatterns ?? []),
    ];

    if (nonRetryablePatterns.some(pattern => pattern.test(errorMessage))) {
      return false;
    }

    // Everything else is retryable (validation errors, timeouts, network errors, etc.)
    return true;
  }

  /**
   * Extracts structured error context for agent self-correction.
   * Provides actionable information about what went wrong and how to fix it.
   */
  extractContext(error: unknown): ErrorContext {
    // Extract structured error information for agent context
    // Check if error is a ZodError - try instanceof first, then check properties
    let zodError: z.ZodError | null = null;
    if (error instanceof z.ZodError) {
      zodError = error;
    } else if (
      error &&
      typeof error === "object" &&
      "errors" in error &&
      Array.isArray((error as { errors: unknown[] }).errors) &&
      ((error as { name?: string }).name === "ZodError" ||
        (error as { constructor?: { name?: string } }).constructor?.name === "ZodError")
    ) {
      zodError = error as unknown as z.ZodError;
    }

    if (zodError) {
      // Zod v4 uses 'issues' instead of 'errors'
      const issues =
        "issues" in zodError && Array.isArray((zodError as { issues: unknown[] }).issues)
          ? (
              zodError as {
                issues: Array<{
                  path: (string | number)[];
                  message: string;
                  code: string;
                  expected?: string;
                  received?: string;
                }>;
              }
            ).issues
          : "errors" in zodError && Array.isArray((zodError as { errors: unknown[] }).errors)
            ? (
                zodError as {
                  errors: Array<{
                    path: (string | number)[];
                    message: string;
                    code: string;
                    expected?: string;
                    received?: string;
                  }>;
                }
              ).errors
            : [];

      const fieldErrors = issues.map(err => ({
        path: err.path.join("."),
        message: err.message,
        code: err.code,
        expected: err.code === "invalid_type" ? err.expected : undefined,
        received: err.code === "invalid_type" ? err.received : undefined,
      }));

      return {
        message: "Validation failed: Please fix the following errors",
        details: {
          fieldErrors,
          errorCount: fieldErrors.length,
        },
        suggestions: fieldErrors.map(err => {
          if (err.code === "invalid_type" && err.expected && err.received) {
            return `Field '${err.path}' expects ${err.expected}, but received ${err.received}. Please provide the correct type.`;
          }
          return `Fix field '${err.path}': ${err.message}`;
        }),
      };
    }

    const errorMessage = error instanceof Error ? error.message : String(error);
    return {
      message: errorMessage,
      details:
        error instanceof Error
          ? {
              name: error.name,
              ...(error.stack && { stack: error.stack }),
            }
          : error && typeof error === "object"
            ? { type: typeof error }
            : { type: typeof error },
    };
  }

  /**
   * Formats an error message for the agent with context and attempt number.
   * Used when retrying tool calls to provide actionable feedback.
   */
  formatForAgent(error: unknown, attemptNumber: number): string {
    const context = this.extractContext(error);
    const isRetryable = this.isRetryable(error);

    let message = `Tool execution failed (attempt ${attemptNumber}): ${context.message}`;

    if (context.suggestions && context.suggestions.length > 0) {
      message +=
        "\n\nSuggestions to fix:\n" +
        context.suggestions.map((s, i) => `${i + 1}. ${s}`).join("\n");
    }

    if (context.details && Object.keys(context.details).length > 0) {
      const detailsStr = JSON.stringify(context.details, null, 2);
      message += `\n\nError details:\n${detailsStr}`;
    }

    if (!isRetryable) {
      message += "\n\nNote: This error is not retryable. Please check your input and try again.";
    } else {
      message += "\n\nPlease fix the errors above and retry the tool call.";
    }

    return message;
  }

  /**
   * Creates an enhanced error message with context for agent self-correction.
   * Combines error classification and context extraction into a single formatted message.
   */
  createEnhancedMessage(error: unknown): string {
    return this.formatForAgent(error, 1);
  }
}
