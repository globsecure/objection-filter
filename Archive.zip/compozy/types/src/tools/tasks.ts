import { kebabCase } from "es-toolkit/string";
import { z } from "zod";
import { AgentTool, defineTool, interactionMetadataSchema } from "./definition";

const TASK_TOOL_NAMESPACE = "mcp__tasks__";

/**
 * Generates a standardized task slug using the first 8 characters of issueId + kebabCase(title).
 * This ensures uniqueness across issues while maintaining readability.
 *
 * @param issueId - The issue UUID (hífens serão removidos antes de pegar os 8 primeiros caracteres)
 * @param title - The task title to slugify
 * @param existingSlug - Optional existing slug to preserve if provided
 * @returns A standardized task slug in format: {issueIdPrefix}-{kebabCaseTitle}
 *
 * @example
 * generateTaskSlug("123e4567-e89b-12d3-a456-426614174000", "Implement Authentication")
 * // Returns: "123e4567-implement-authentication"
 */
export function generateTaskSlug(issueId: string, title: string, existingSlug?: string): string {
  const MAX_SLUG_LENGTH = 64;

  // If existing slug is provided and valid, use it
  if (existingSlug && existingSlug.trim().length > 0) {
    return existingSlug.slice(0, MAX_SLUG_LENGTH);
  }

  // Extract first 8 characters from issueId (remove hyphens first)
  const issueIdPrefix = issueId.replace(/-/g, "").slice(0, 8);

  // Generate slug from title
  const titleSlug = kebabCase(title.trim());

  // If title is empty, use a fallback
  if (!titleSlug || titleSlug.length === 0) {
    return `${issueIdPrefix}-task`;
  }

  const slug = `${issueIdPrefix}-${titleSlug}`;

  // Enforce a maximum length to keep slugs filesystem/URL friendly
  return slug.slice(0, MAX_SLUG_LENGTH).replace(/-+$/, "");
}

export const TASK_STATUSES = [
  "saved",
  "pending",
  "in_progress",
  "completed",
  "failed",
  "canceled",
] as const;

export const TASK_CREATION_STATUSES = ["pending", "in_progress", "completed"] as const;
export const TASK_COMPLEXITIES = ["low", "medium", "high", "critical"] as const;

// Default values for task creation
export const DEFAULT_TASK_OVERVIEW = "TBD";
export const DEFAULT_TASK_COMPLEXITY = "medium";
export const DEFAULT_TASK_STATUS = "pending";

export const taskStatusSchema = z.enum(TASK_STATUSES);
export const taskCreationStatusSchema = z.enum(TASK_CREATION_STATUSES);
export const taskComplexitySchema = z.enum(TASK_COMPLEXITIES);

// Lenient approval task schema - for approval flow only
// Allows optional IDs (backend generates), empty titles (for drafts), optional position
// Status is not part of approval - backend assigns default status when tasks are saved
export const approvalTaskSchema = z.object({
  slug: z.string().optional().describe("Task slug (auto-generated from title if omitted)"),
  title: z.string().describe("High-level task title"), // No min(1) - allow empty for drafts
  position: z.number().int().min(0).optional().describe("Ordered position within the backlog"),
});

export const approveTasksInputSchema = z.object({
  tasks: z.array(approvalTaskSchema).min(1).describe("List of tasks for approval"),
});

// Minimal task schema - used for approval artifacts and basic task representation
export const taskSchema = z.object({
  id: z.uuid().optional(),
  slug: z.string().optional(),
  title: z.string().trim().min(1, "Task title cannot be empty"),
  content: z.string().default("").describe("Markdown content for the task body"),
  position: z.number().int().min(0),
  status: taskStatusSchema.default("pending"),
});

// Full task schema - complete task with all fields (for backend API responses and detailed views)
// Intended for: Backend API Task Detail endpoint responses (TaskDetailResponse.task)
// Note: Dates are coerced from strings (JSON) to Date objects for consistent type handling
export const fullTaskSchema = z.object({
  id: z.uuid(),
  issueId: z.uuid(),
  slug: z.string(),
  title: z.string().trim().min(1, "Task title cannot be empty"),
  content: z.string(),
  complexity: taskComplexitySchema,
  status: taskStatusSchema,
  position: z.number().int().min(0),
  createdAt: z.coerce.date(),
  updatedAt: z.coerce.date(),
});

const tasksInteractionMetadataSchema = interactionMetadataSchema
  .extend({
    type: z.literal("approval"),
    uiComponent: z.literal("tasks-approval"),
    tool: z.literal("mcp__tasks__approve_tasks").optional(),
  })
  .default({
    type: "approval",
    uiComponent: "tasks-approval",
    requiresInput: true,
    tool: "mcp__tasks__approve_tasks",
  });

export const tasksArtifactSchema = z.object({
  tasksId: z.uuid(),
  tasks: z.array(taskSchema),
  _interaction: tasksInteractionMetadataSchema,
});

export const listTasksInputSchema = z.object({
  issueId: z.string().describe("Issue identifier to list tasks for"),
});

export const taskUpdateInputSchema = z.object({
  id: z.string().describe("Task ID (UUID) or Slug to update"),
  title: z.string().min(1).optional().describe("Task title"),
  complexity: taskComplexitySchema.optional().describe("Relative complexity"),
  slug: z.string().optional().describe("URL-friendly identifier"),
  content: z.string().optional().describe("Markdown content for the task body"),
});

export const reorderTasksInputSchema = z.object({
  taskIds: z
    .array(z.uuid())
    .min(1)
    .describe(
      "Array of task IDs in the desired order. Tasks not in this array will be appended at the end."
    ),
});

export const deleteTaskInputSchema = z.object({
  id: z.uuid().describe("Task ID to delete"),
});

// Event schemas for task creation events
// Used by frontend plugins to handle task lifecycle events
export const taskCreatedEventSchema = z.object({
  type: z.literal("TASK_CREATED"),
  issueId: z.uuid(),
  taskId: z.uuid(),
  task: z.record(z.string(), z.unknown()),
});

export const tasksCreatedEventSchema = z.object({
  type: z.literal("TASKS_CREATED"),
  issueId: z.uuid(),
  tasks: z.array(z.record(z.string(), z.unknown())),
});

export const taskUpdatedEventSchema = z.object({
  type: z.literal("TASK_UPDATED"),
  taskId: z.uuid(),
  changes: z
    .object({
      slug: z.string().optional(),
      title: z.string().optional(),
      content: z.string().optional(),
      complexity: taskComplexitySchema.optional(),
      status: taskStatusSchema.optional(),
      position: z.number().int().min(0).optional(),
    })
    .refine(
      (value: Record<string, unknown>) => Object.keys(value).length > 0,
      "At least one field must be provided"
    ),
  updatedTask: z.record(z.string(), z.unknown()).optional(),
});

export const taskDeletedEventSchema = z.object({
  type: z.literal("TASK_DELETED"),
  taskId: z.uuid(),
  issueId: z.uuid().optional(),
});

export const taskReorderedEventSchema = z.object({
  type: z.literal("TASK_REORDERED"),
  issueId: z.uuid(),
  taskIds: z.array(z.uuid()).min(1),
});

export const tasksEventSchema = z.discriminatedUnion("type", [
  taskCreatedEventSchema,
  taskUpdatedEventSchema,
  taskDeletedEventSchema,
  taskReorderedEventSchema,
  tasksCreatedEventSchema,
]);

// Tasks data part schema (what backend sends to frontend)
export const tasksDataPartSchema = z.object({
  tasksId: z.uuid(),
  tasks: z.array(taskSchema),
});

// XState machine context schema (for frontend state management)
export const tasksMachineContextSchema = z.object({
  tasksId: z.uuid(),
  issueId: z.uuid(),
  tasks: z.array(taskSchema),
  editingTaskId: z.uuid().nullable(),
  error: z.string().nullable(),
  validationErrors: z.record(z.string(), z.array(z.string())).nullable(),
  isSubmitted: z.boolean(),
  createdAt: z.number(),
});

// Persisted session schema (for localStorage)
export const tasksSessionSchema = z.object({
  version: z.literal(1), // Schema version for migrations
  tasksId: z.uuid(),
  tasks: z.array(taskSchema),
  createdAt: z.number(),
  isSubmitted: z.boolean(),
});

// Approval payload schema (what gets sent on approve)
export const approvalPayloadSchema = z.object({
  type: z.literal("tasks-response"),
  tasksId: z.uuid(),
  tasks: z.array(approvalTaskSchema), // Lenient schema allows optional IDs and relaxed validation
});

// Type exports
export type ApprovalTask = z.infer<typeof approvalTaskSchema>;
export type Task = z.infer<typeof taskSchema>;
export type FullTask = z.infer<typeof fullTaskSchema>;
export type TasksDataPart = z.infer<typeof tasksDataPartSchema>;
export type TasksMachineContext = z.infer<typeof tasksMachineContextSchema>;
export type TasksSession = z.infer<typeof tasksSessionSchema>;
export type ApprovalPayload = z.infer<typeof approvalPayloadSchema>;

const approveTasksDefinition = defineTool({
  name: "approve_tasks",
  description:
    "Present a set of high-level tasks to the user for approval. The system will assign IDs automatically when they are omitted.",
  schemas: {
    input: approveTasksInputSchema,
    artifact: tasksArtifactSchema,
  },
  behavior: {
    stopOnUse: true,
  },
  interaction: {
    type: "approval",
    uiComponent: "tasks-approval",
    autoSync: true,
  },
});

const listTasksDefinition = defineTool({
  name: "list_tasks",
  description:
    "List all tasks for an issue. Use this to fetch existing tasks before enriching them.",
  schemas: {
    input: listTasksInputSchema,
  },
});

const updateTaskDefinition = defineTool({
  name: "update_task",
  description:
    "Update an existing task. Provide only the fields that should change. Emits a TASK_UPDATED event with the changed fields.",
  schemas: {
    input: taskUpdateInputSchema,
    event: taskUpdatedEventSchema,
  },
});

const deleteTaskDefinition = defineTool({
  name: "delete_task",
  description: "Delete an existing task by ID. Emits a TASK_DELETED event.",
  schemas: {
    input: deleteTaskInputSchema,
    event: taskDeletedEventSchema,
  },
});

const reorderTasksDefinition = defineTool({
  name: "reorder_tasks",
  description:
    "Reorder tasks by specifying the desired order of task IDs. Tasks not in the list will be appended at the end. Emits a TASK_REORDERED event.",
  schemas: {
    input: reorderTasksInputSchema,
    event: taskReorderedEventSchema,
  },
});

export const approveTasksTool = new AgentTool(approveTasksDefinition, TASK_TOOL_NAMESPACE);
export const listTasksTool = new AgentTool(listTasksDefinition, TASK_TOOL_NAMESPACE);
export const updateTaskTool = new AgentTool(updateTaskDefinition, TASK_TOOL_NAMESPACE);
export const deleteTaskTool = new AgentTool(deleteTaskDefinition, TASK_TOOL_NAMESPACE);
export const reorderTasksTool = new AgentTool(reorderTasksDefinition, TASK_TOOL_NAMESPACE);
