/**
 * Provider-agnostic interface for writing data parts to a stream.
 *
 * This abstraction decouples MCP tools from specific streaming implementations
 * (like Vercel AI SDK's UIMessageStreamWriter), enabling:
 * - Provider portability (Claude Code, Codex, OpenCode, etc.)
 * - Easier testing with simple mocks
 * - Clear separation between transport and domain layers
 */
export interface ToolStreamContext {
  /**
   * Write a custom data part to the stream for HITL UI rendering.
   * @param type - The data part type (e.g., 'data-clarification', 'data-prd-editor')
   * @param data - The structured data payload
   */
  writeDataPart(type: string, data: Record<string, unknown>): void;

  /**
   * Optional callback invoked after an artifact is created.
   * Useful for indexing newly created artifacts without relying on LLM tool calls.
   */
  onArtifactCreated?: (payload: ArtifactIndexPayload) => void | Promise<void>;

  /**
   * Optional callback invoked after an artifact is updated.
   */
  onArtifactUpdated?: (payload: ArtifactIndexPayload) => void | Promise<void>;
}

export type ArtifactIndexPayload = {
  issueId: string;
  issueTitle?: string;
  type: "prd" | "techspec" | "task" | "issue_context";
  title?: string;
  content?: string;
  taskId?: string;
  taskSlug?: string;
  updatedAt?: number;
  syncedAt?: number | null;
};
