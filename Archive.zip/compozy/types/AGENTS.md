# @compozy/types - Agent Guidelines

<critical>
- **MANDATORY**: This package provides **SHARED TYPE DEFINITIONS** only - pure TypeScript types and Zod schemas
- **NEVER** add runtime implementations or business logic - those belong in consuming packages
- **ALWAYS** maintain strict type safety with discriminated unions and branded types
- **MUST** run `pnpm run lint`, `pnpm run typecheck`, and `pnpm run test` before completing any changes
- **ALWAYS** reference `.cursor/rules/typescript.mdc` for TypeScript best practices
- **NEVER** use `any` type - use `unknown` with type guards or proper generics
- **ALWAYS** use `es-toolkit` utilities instead of custom implementations
</critical>

## Package Overview

`@compozy/types` is a **pure type definitions package** that provides:

- **Zod Schemas**: Runtime validation schemas for all domain entities (tasks, PRD, techspec, etc.)
- **Type Exports**: TypeScript types inferred from Zod schemas for compile-time safety
- **Tool Definitions**: Shared tool schemas and type-safe tool definition utilities
- **Discriminated Unions**: Type-safe state representations using discriminated union patterns
- **Branded Types**: Type-safe ID and identifier types preventing mixups
- **Factory Functions**: Generic utilities for creating tool definitions with full type inference

**Key Principle**: This package is a **shared type library**, not an implementation library. All runtime behavior belongs in consuming packages (`looper`, `agents`, `frontend`).

## Architecture

### Core Components

```
src/
├── auth-session.ts          # Authentication session types
├── tools/                   # Tool-related types and schemas
│   ├── definition.ts        # Core tool definition types and utilities
│   ├── factory.ts           # Tool creation utilities with Zod v3/v4 conversion
│   ├── tasks.ts             # Task tool schemas and definitions
│   ├── prd.ts               # PRD tool schemas and definitions
│   ├── techspec.ts          # Tech spec tool schemas and definitions
│   ├── clarification.ts     # Clarification tool schemas and definitions
│   └── error-classifier.ts  # Error classification and retry logic
└── index.ts                 # Barrel exports
```

### Design Principles

1. **Type-First Design**: All schemas are Zod schemas, types are inferred via `z.infer<>`
2. **Single Source of Truth**: Schemas define both runtime validation and compile-time types
3. **Generic Utilities**: Use TypeScript generics for reusable type-safe patterns
4. **Discriminated Unions**: Use `type` field for state machine patterns and error handling
5. **Branded Types**: Use unique symbols for type-safe IDs (prevent UUID mixups)
6. **Immutable by Default**: All types represent immutable data structures

**Reference**: See `src/tools/definition.ts` for tool definition patterns, `src/tools/tasks.ts` for schema examples.

## Build, Test, and Development Commands

From package root:

```bash
pnpm install              # Install dependencies
pnpm run typecheck        # Type check
pnpm run lint             # Lint
pnpm test                 # Run tests
pnpm run lint && pnpm run typecheck && pnpm test  # Run all checks
```

## Coding Style & Conventions

### TypeScript Standards

**MANDATORY**: Follow `.cursor/rules/typescript.mdc` for all TypeScript code

- **Strict Mode**: Always enabled (`strict: true` in `tsconfig.json`)
- **Type Inference**: Prefer inference for return types, explicit for parameters
- **No `any`**: Use `unknown` and type guards instead
- **Branded Types**: Use for IDs and critical identifiers
- **Discriminated Unions**: Use for state management and error handling
- **Utility Types**: Use built-in types (`Partial`, `Omit`, `Pick`, etc.) before creating custom ones

**Reference**: `.cursor/rules/typescript.mdc` for complete TypeScript guidelines.

### File Organization

- **Schema Files**: One file per domain concept (`tasks.ts`, `prd.ts`, `techspec.ts`)
- **Definition Files**: Core utilities in `definition.ts` and `factory.ts`
- **Type Exports**: Export types and schemas together from the same file
- **Barrel Exports**: All public exports through `index.ts`
- **Tests**: `*.test.ts` files alongside source files

### Naming Conventions

- **Schemas**: `camelCaseSchema` (e.g., `taskSchema`, `approveTasksInputSchema`)
- **Types**: PascalCase inferred from schemas (e.g., `Task`, `ApprovalTask`)
- **Functions**: camelCase (e.g., `defineTool`, `generateTaskSlug`)
- **Classes**: PascalCase (e.g., `AgentTool`, `ErrorClassifier`)
- **Constants**: UPPER_SNAKE_CASE (e.g., `TASK_STATUSES`, `DEFAULT_TASK_STATUS`)

## Key APIs

### Tool Definition

**Reference**: See `src/tools/definition.ts` for tool definition types and utilities.

- `defineTool<TInput, TArtifact, TEvent>()` - Core tool definition function
- `AgentTool` class - Tool wrapper with namespace support
- Type inference helpers - `InferToolInput`, `InferToolArtifact`, `InferToolEvent`

### Tool Factory

**Reference**: See `src/tools/factory.ts` for tool creation utilities.

- `createAgentTool()` - Create agent tool for MCP registration
- `withExecution()` - Helper for execution with artifact enrichment
- `enrichStructuredContentForArtifact()` - Enrich artifact data with schema defaults

### Error Classification

**Reference**: See `src/tools/error-classifier.ts` for error classification.

- `ErrorClassifier` class - Error classification and retry logic

## Schema Patterns

### Input Schemas

Define what the agent provides to a tool. See `src/tools/tasks.ts` for input schema examples.

### Artifact Schemas

Define what the tool returns (for interactive tools). See `src/tools/tasks.ts` for artifact schema examples.

### Event Schemas

Define events emitted by tools. See `src/tools/tasks.ts` for event schema examples.

### Session Schemas

Define persisted state. See `src/tools/tasks.ts` for session schema examples.

## Testing Guidelines

### Test Structure

- **Schema Validation**: Test that schemas accept valid data and reject invalid data
- **Type Inference**: Test that inferred types match expected shapes
- **Edge Cases**: Test boundary conditions, empty inputs, invalid inputs
- **Tool Creation**: Test tool definition and factory functions
- **Error Classification**: Test error handling and retry logic

**Reference**: See `src/tools/*.test.ts` for test examples.

## Dependencies

### Core Dependencies

- **`zod`** (v4+): Schema validation and type inference
- **`zod3`**: Zod v3 for MCP compatibility (separate import)
- **`es-toolkit`**: High-performance utility functions
- **`ai`**: Vercel AI SDK types (for tool integration)
- **`immer`**: Immutable state updates (for complex state management)

### Dependency Guidelines

- **MANDATORY**: **ALWAYS** use `es-toolkit` instead of custom implementations or native methods
- **Use `kebabCase`** from `es-toolkit/string` for slug generation
- **Use `invariant`** from `es-toolkit/util` for runtime assertions
- **NEVER** implement custom utility functions that es-toolkit provides
- **Use Zod v4** (`zod`) for schema definitions
- **Use Zod v3** (`zod3`) only for MCP tool registration conversion

**Reference**: `.cursor/rules/es-toolkit.mdc` for complete es-toolkit guidelines.

## Tool Definition Patterns

### Basic Tool (No Artifact)

**Reference**: See `src/tools/tasks.ts` for basic tool example.

### Interactive Tool (With Artifact)

**Reference**: See `src/tools/tasks.ts` for interactive tool example.

### Tool With Events

**Reference**: See `src/tools/tasks.ts` for tool with events example.

## Forbidden Practices

<critical>
- **NEVER** add runtime implementations or business logic to this package
- **NEVER** use `any` type - use `unknown` with type guards
- **NEVER** create mutable types - all types should represent immutable data
- **NEVER** skip schema validation - always use Zod schemas
- **NEVER** export implementation details - only types and schemas
- **NEVER** add framework-specific code - keep types generic
- **NEVER** modify schemas without updating dependent packages
- **NEVER** use native methods when es-toolkit provides alternatives
- **NEVER** create custom utility functions without checking es-toolkit first
</critical>

## Common Tasks

### Adding a New Tool Definition

1. Create schema file in `src/tools/` (e.g., `new-feature.ts`)
2. Define input schema using Zod
3. Define artifact schema (if interactive tool)
4. Define event schema (if tool emits events)
5. Create tool definition using `defineTool()`
6. Export `AgentTool` instance with proper namespace
7. Export from `src/index.ts`
8. Add tests for schemas and tool definition
9. Update consuming packages to use new tool

**Reference**: See `src/tools/tasks.ts` for complete example.

### Adding a New Schema

1. Create Zod schema with proper validation
2. Infer TypeScript type using `z.infer<>`
3. Export both schema and type
4. Add JSDoc comments for documentation
5. Add tests for valid and invalid cases
6. Export from barrel file (`index.ts`)

### Adding Branded Types

**Reference**: See `.cursor/rules/typescript.mdc` for branded type patterns.

## Integration Points

### Consuming Packages

This package is designed to be used by:

- **`packages/looper`**: Task execution and agent runtime
- **`packages/agents`**: Agent orchestration and tool implementation
- **`packages/frontend`**: UI components and state management

**Pattern**: Consuming packages should import types and schemas from `@compozy/types`, implement tool handlers using the schemas for validation, and use inferred types for type-safe implementation.

**Reference**: See `packages/agents/src/tools/` for tool handler examples.

## File-Specific Guidelines

### `definition.ts`

- **Purpose**: Core tool definition types and utilities
- **DO**: Define generic tool definition types, export type inference helpers
- **DON'T**: Add implementation logic or domain-specific tool definitions

### `factory.ts`

- **Purpose**: Tool creation utilities and Zod v3/v4 conversion
- **DO**: Provide generic factory functions, handle Zod version compatibility
- **DON'T**: Add domain-specific logic or export MCP-specific implementation details

### `tasks.ts` / `prd.ts` / `techspec.ts`

- **Purpose**: Domain-specific tool schemas and definitions
- **DO**: Define schemas for specific domain, export tool instances with proper namespace
- **DON'T**: Add implementation logic or cross-reference other domain schemas

### `error-classifier.ts`

- **Purpose**: Error classification and retry logic
- **DO**: Define error patterns and retry configs, provide type-safe error handling utilities
- **DON'T**: Add domain-specific error handling or implement actual retry logic (that belongs in runtime packages)

## Validation & Error Handling

- Use Zod schemas for all runtime validation
- Use `invariant()` from `es-toolkit/util` for assertions
- Provide descriptive error messages
- Use `.safeParse()` when validation failure is expected

**Reference**: See `src/tools/*.ts` for validation examples.

## Type Safety

- Leverage TypeScript's type system for compile-time safety
- Use discriminated unions for state machine types
- Use branded types for critical identifiers
- Use generic constraints for reusable utilities

**Reference**: `.cursor/rules/typescript.mdc` for type safety patterns.

## Performance Considerations

- **Schema Parsing**: Cache schema instances, don't recreate them
- **Type Inference**: Infer types once, reuse across codebase
- **Branded Types**: Zero runtime overhead, compile-time only
- **es-toolkit**: Use for performance-critical operations
- **Zod Transformations**: Use `.transform()` sparingly, prefer `.refine()`

## Documentation Standards

- **JSDoc Comments**: All exported types and functions must have JSDoc
- **Type Exports**: Export all public types from `index.ts`
- **Schema Descriptions**: Use `.describe()` for all schema fields
- **Examples**: Include usage examples in JSDoc comments

**Reference**: See `src/tools/tasks.ts` for JSDoc examples.

## Checklist for Changes

Before submitting changes:

- [ ] All tests pass (`pnpm test`)
- [ ] Type checking passes (`pnpm run typecheck`)
- [ ] Linting passes (`pnpm run lint`)
- [ ] No runtime implementations added
- [ ] All new schemas have tests
- [ ] JSDoc comments added for public APIs
- [ ] Types exported from `index.ts`
- [ ] Schema field descriptions added
- [ ] Consuming packages updated if needed
- [ ] No `any` types used
- [ ] Used `es-toolkit` for utilities

## Three-Tier Boundaries

### Tier 1: Pure Type Definitions (This Package)

- **ALLOWED**: Zod schemas, TypeScript types, type inference helpers, constants
- **FORBIDDEN**: Runtime implementations, business logic, framework-specific code

### Tier 2: Tool Implementations (Consuming Packages)

- **ALLOWED**: Tool handlers, validation logic, business rules
- **FORBIDDEN**: Type definitions (should be in this package), UI components

### Tier 3: UI and Presentation (Frontend Package)

- **ALLOWED**: React components, state management, UI interactions
- **FORBIDDEN**: Business logic (should be in Tier 2), type definitions (should be in Tier 1)

**Enforcement**: Violating these boundaries results in immediate task rejection.

## Related Documentation

- **Main Repository Guidelines**: `/Users/pedronauck/Dev/compozy/compozy-code/AGENTS.md`
- **TypeScript Guidelines**: `.cursor/rules/typescript.mdc`
- **es-toolkit Guidelines**: `.cursor/rules/es-toolkit.mdc`
