import { defineProject } from "vitest/config";

export default defineProject({
  test: {
    name: "providers/codex",
    environment: "node",
    include: ["src/**/*.{test,spec}.{ts,tsx}"],
    exclude: ["**/node_modules/**"],
  },
});
