# 🚀 Sprint 5 - Polish & Advanced Features

**Goal**: Add storytelling layer (Career Moments), goals tracking, peer feedback integration, and time context analysis to make DevPulse production-ready for performance reviews.

**Timeline**: 2-3 weeks

**Status**: ✅ **COMPLETED**

**Success Criteria**: 
- Career moments documented and integrated into Manager Reports
- Goals/OKRs tracked with progress visualization
- Peer feedback collected and displayed in reports
- Time patterns analyzed (working hours, after-hours, weekends)
- All features integrated into Manager Report Generator

---

## 📋 Overview

Sprint 5 focuses on the "Polish & Advanced Features" layer that transforms DevPulse from a metrics tool into a comprehensive performance storytelling platform. This sprint adds:

1. **Career Moments**: Document wins, failures, pivots, and learning moments with rich context
2. **Goals & OKRs Tracking**: Link work to goals, track progress, and show alignment in reviews
3. **Peer Feedback Integration**: Collect and showcase feedback from teammates
4. **Time Context & Work Patterns**: Analyze when you work best and detect unsustainable patterns

**Key Features**:
- Career moments with rich text editor
- Goals/OKRs with progress tracking
- Peer feedback collection and trends
- Working hours heatmap and pattern detection
- Calendar integration for meeting time tracking
- All features integrated into Manager Reports

---

## 📋 Tasks Breakdown

### Task Group 1: Career Moments - The Storytelling Layer (4-5 days)

#### Day 1: Database Schema & Models

**File**: `backend/app/models.py`

**Status**: ✅ Implemented

Add Career Moment model:

```python
class CareerMoment(Base):
    __tablename__ = "career_moments"

    id = Column(Integer, primary_key=True, index=True)
    date = Column(DateTime, nullable=False, index=True)
    type = Column(String, nullable=False)  # 'win' | 'failure' | 'pivot' | 'learning'
    title = Column(String, nullable=False)
    story = Column(Text)  # Rich text story
    impact = Column(Text)  # Business/technical impact description
    witnesses = Column(String)  # Comma-separated list of people who witnessed/validated
    tags = Column(String)  # Comma-separated tags
    related_commits = Column(String)  # JSON array of commit IDs
    related_entries = Column(String)  # JSON array of manual entry IDs
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
```

**File**: `backend/app/schemas.py`

Add Pydantic schemas:

```python
class CareerMomentBase(BaseModel):
    date: datetime
    type: str  # win | failure | pivot | learning
    title: str
    story: Optional[str] = None
    impact: Optional[str] = None
    witnesses: Optional[str] = None
    tags: Optional[str] = None
    related_commits: Optional[List[int]] = None
    related_entries: Optional[List[int]] = None

class CareerMomentCreate(CareerMomentBase):
    pass

class CareerMomentUpdate(BaseModel):
    date: Optional[datetime] = None
    type: Optional[str] = None
    title: Optional[str] = None
    story: Optional[str] = None
    impact: Optional[str] = None
    witnesses: Optional[str] = None
    tags: Optional[str] = None
    related_commits: Optional[List[int]] = None
    related_entries: Optional[List[int]] = None

class CareerMoment(CareerMomentBase):
    id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
```

**File**: `backend/alembic/versions/`

Create migration:

```python
"""add_career_moments

Revision ID: add_career_moments
Revises: <previous_revision>
Create Date: <date>

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import sqlite

def upgrade():
    op.create_table(
        'career_moments',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('date', sa.DateTime(), nullable=False),
        sa.Column('type', sa.String(), nullable=False),
        sa.Column('title', sa.String(), nullable=False),
        sa.Column('story', sa.Text(), nullable=True),
        sa.Column('impact', sa.Text(), nullable=True),
        sa.Column('witnesses', sa.String(), nullable=True),
        sa.Column('tags', sa.String(), nullable=True),
        sa.Column('related_commits', sa.String(), nullable=True),
        sa.Column('related_entries', sa.String(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_career_moments_date'), 'career_moments', ['date'], unique=False)

def downgrade():
    op.drop_index(op.f('ix_career_moments_date'), table_name='career_moments')
    op.drop_table('career_moments')
```

**Task**: `moments-001` ✅

---

#### Day 2: API Endpoints

**File**: `backend/app/api/moments.py`

**Status**: ✅ Implemented

Create CRUD API endpoints:

```python
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
import json

from ..database import get_db
from ..models import CareerMoment
from ..schemas import CareerMomentCreate, CareerMomentUpdate, CareerMoment

router = APIRouter(prefix="/api/moments", tags=["moments"])

@router.post("", response_model=CareerMoment)
def create_moment(
    moment: CareerMomentCreate,
    db: Session = Depends(get_db)
):
    """Create a new career moment"""
    db_moment = CareerMoment(
        date=moment.date,
        type=moment.type,
        title=moment.title,
        story=moment.story,
        impact=moment.impact,
        witnesses=moment.witnesses,
        tags=moment.tags,
        related_commits=json.dumps(moment.related_commits or []),
        related_entries=json.dumps(moment.related_entries or [])
    )
    db.add(db_moment)
    db.commit()
    db.refresh(db_moment)
    return db_moment

@router.get("", response_model=List[CareerMoment])
def get_moments(
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    type: Optional[str] = None,
    tags: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """Get all career moments with optional filters"""
    query = db.query(CareerMoment)
    
    if start_date:
        query = query.filter(CareerMoment.date >= start_date)
    if end_date:
        query = query.filter(CareerMoment.date <= end_date)
    if type:
        query = query.filter(CareerMoment.type == type)
    if tags:
        tag_list = [t.strip() for t in tags.split(",")]
        for tag in tag_list:
            query = query.filter(CareerMoment.tags.contains(tag))
    
    moments = query.order_by(CareerMoment.date.desc()).all()
    
    # Parse JSON fields
    for moment in moments:
        if moment.related_commits:
            moment.related_commits = json.loads(moment.related_commits)
        if moment.related_entries:
            moment.related_entries = json.loads(moment.related_entries)
    
    return moments

@router.get("/{moment_id}", response_model=CareerMoment)
def get_moment(moment_id: int, db: Session = Depends(get_db)):
    """Get a specific career moment"""
    moment = db.query(CareerMoment).filter(CareerMoment.id == moment_id).first()
    if not moment:
        raise HTTPException(status_code=404, detail="Career moment not found")
    
    if moment.related_commits:
        moment.related_commits = json.loads(moment.related_commits)
    if moment.related_entries:
        moment.related_entries = json.loads(moment.related_entries)
    
    return moment

@router.put("/{moment_id}", response_model=CareerMoment)
def update_moment(
    moment_id: int,
    moment_update: CareerMomentUpdate,
    db: Session = Depends(get_db)
):
    """Update a career moment"""
    moment = db.query(CareerMoment).filter(CareerMoment.id == moment_id).first()
    if not moment:
        raise HTTPException(status_code=404, detail="Career moment not found")
    
    update_data = moment_update.dict(exclude_unset=True)
    if 'related_commits' in update_data:
        update_data['related_commits'] = json.dumps(update_data['related_commits'])
    if 'related_entries' in update_data:
        update_data['related_entries'] = json.dumps(update_data['related_entries'])
    
    for field, value in update_data.items():
        setattr(moment, field, value)
    
    moment.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(moment)
    return moment

@router.delete("/{moment_id}")
def delete_moment(moment_id: int, db: Session = Depends(get_db)):
    """Delete a career moment"""
    moment = db.query(CareerMoment).filter(CareerMoment.id == moment_id).first()
    if not moment:
        raise HTTPException(status_code=404, detail="Career moment not found")
    
    db.delete(moment)
    db.commit()
    return {"message": "Career moment deleted"}

@router.get("/stats/summary")
def get_moments_stats(
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    db: Session = Depends(get_db)
):
    """Get statistics about career moments"""
    query = db.query(CareerMoment)
    
    if start_date:
        query = query.filter(CareerMoment.date >= start_date)
    if end_date:
        query = query.filter(CareerMoment.date <= end_date)
    
    moments = query.all()
    
    stats = {
        "total": len(moments),
        "by_type": {},
        "by_quarter": {}
    }
    
    for moment in moments:
        # Count by type
        stats["by_type"][moment.type] = stats["by_type"].get(moment.type, 0) + 1
        
        # Count by quarter
        quarter = f"Q{(moment.date.month - 1) // 3 + 1}-{moment.date.year}"
        stats["by_quarter"][quarter] = stats["by_quarter"].get(quarter, 0) + 1
    
    return stats
```

**File**: `backend/app/main.py`

Register router:

```python
from .api import moments

app.include_router(moments.router)
```

**Task**: `moments-002` (API part) ✅

---

#### Day 3: Frontend - Rich Text Editor Component

**File**: `frontend/src/types/index.ts`

Add TypeScript interfaces:

```typescript
export interface CareerMoment {
  id: number;
  date: string;
  type: 'win' | 'failure' | 'pivot' | 'learning';
  title: string;
  story?: string;
  impact?: string;
  witnesses?: string;
  tags?: string;
  related_commits?: number[];
  related_entries?: number[];
  created_at: string;
  updated_at: string;
}

export interface CareerMomentCreate {
  date: string;
  type: 'win' | 'failure' | 'pivot' | 'learning';
  title: string;
  story?: string;
  impact?: string;
  witnesses?: string;
  tags?: string;
  related_commits?: number[];
  related_entries?: number[];
}
```

**File**: `frontend/src/services/api.ts`

Add API methods:

```typescript
export const getMoments = async (params?: {
  start_date?: string;
  end_date?: string;
  type?: string;
  tags?: string;
}): Promise<CareerMoment[]> => {
  const response = await fetch(
    `${API_BASE}/moments?${new URLSearchParams(params as any)}`
  );
  return response.json();
};

export const createMoment = async (moment: CareerMomentCreate): Promise<CareerMoment> => {
  const response = await fetch(`${API_BASE}/moments`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(moment),
  });
  return response.json();
};

export const updateMoment = async (
  id: number,
  moment: Partial<CareerMomentCreate>
): Promise<CareerMoment> => {
  const response = await fetch(`${API_BASE}/moments/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(moment),
  });
  return response.json();
};

export const deleteMoment = async (id: number): Promise<void> => {
  await fetch(`${API_BASE}/moments/${id}`, { method: 'DELETE' });
};
```

**File**: `frontend/src/components/CareerMomentForm.tsx`

Create form component with rich text editor (using a simple textarea for now, can upgrade to a proper rich text editor later):

```typescript
import React, { useState } from 'react';
import { CareerMomentCreate } from '../types';
import { createMoment, updateMoment } from '../services/api';

interface CareerMomentFormProps {
  initialData?: CareerMomentCreate;
  momentId?: number;
  onSuccess?: () => void;
  onCancel?: () => void;
}

export const CareerMomentForm: React.FC<CareerMomentFormProps> = ({
  initialData,
  momentId,
  onSuccess,
  onCancel,
}) => {
  const [formData, setFormData] = useState<CareerMomentCreate>(
    initialData || {
      date: new Date().toISOString().split('T')[0],
      type: 'win',
      title: '',
      story: '',
      impact: '',
      witnesses: '',
      tags: '',
    }
  );
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (momentId) {
        await updateMoment(momentId, formData);
      } else {
        await createMoment(formData);
      }
      onSuccess?.();
    } catch (error) {
      console.error('Error saving moment:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium mb-1">Date</label>
        <input
          type="date"
          value={formData.date}
          onChange={(e) => setFormData({ ...formData, date: e.target.value })}
          className="w-full px-3 py-2 border rounded"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Type</label>
        <select
          value={formData.type}
          onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
          className="w-full px-3 py-2 border rounded"
          required
        >
          <option value="win">Win</option>
          <option value="failure">Failure</option>
          <option value="pivot">Pivot</option>
          <option value="learning">Learning</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Title</label>
        <input
          type="text"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          className="w-full px-3 py-2 border rounded"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Story</label>
        <textarea
          value={formData.story || ''}
          onChange={(e) => setFormData({ ...formData, story: e.target.value })}
          className="w-full px-3 py-2 border rounded"
          rows={6}
          placeholder="Tell the story of this moment..."
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Impact</label>
        <textarea
          value={formData.impact || ''}
          onChange={(e) => setFormData({ ...formData, impact: e.target.value })}
          className="w-full px-3 py-2 border rounded"
          rows={4}
          placeholder="Describe the business/technical impact..."
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Witnesses</label>
        <input
          type="text"
          value={formData.witnesses || ''}
          onChange={(e) => setFormData({ ...formData, witnesses: e.target.value })}
          className="w-full px-3 py-2 border rounded"
          placeholder="Comma-separated list of people"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Tags</label>
        <input
          type="text"
          value={formData.tags || ''}
          onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
          className="w-full px-3 py-2 border rounded"
          placeholder="Comma-separated tags"
        />
      </div>

      <div className="flex gap-2">
        <button
          type="submit"
          disabled={loading}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
        >
          {loading ? 'Saving...' : momentId ? 'Update' : 'Create'}
        </button>
        {onCancel && (
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400"
          >
            Cancel
          </button>
        )}
      </div>
    </form>
  );
};
```

**Task**: `moments-002` (UI part) ✅

---

#### Day 4: Timeline View Integration

**File**: `frontend/src/components/CareerMomentsTimeline.tsx`

Create timeline component:

```typescript
import React, { useEffect, useState } from 'react';
import { CareerMoment } from '../types';
import { getMoments } from '../services/api';

export const CareerMomentsTimeline: React.FC = () => {
  const [moments, setMoments] = useState<CareerMoment[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<{ type?: string; tags?: string }>({});

  useEffect(() => {
    loadMoments();
  }, [filter]);

  const loadMoments = async () => {
    setLoading(true);
    try {
      const data = await getMoments(filter);
      setMoments(data);
    } catch (error) {
      console.error('Error loading moments:', error);
    } finally {
      setLoading(false);
    }
  };

  const typeColors = {
    win: 'bg-green-100 border-green-500',
    failure: 'bg-red-100 border-red-500',
    pivot: 'bg-blue-100 border-blue-500',
    learning: 'bg-yellow-100 border-yellow-500',
  };

  if (loading) return <div>Loading moments...</div>;

  return (
    <div className="space-y-4">
      <div className="flex gap-2 mb-4">
        <select
          value={filter.type || ''}
          onChange={(e) => setFilter({ ...filter, type: e.target.value || undefined })}
          className="px-3 py-2 border rounded"
        >
          <option value="">All Types</option>
          <option value="win">Wins</option>
          <option value="failure">Failures</option>
          <option value="pivot">Pivots</option>
          <option value="learning">Learning</option>
        </select>
        <input
          type="text"
          placeholder="Filter by tags..."
          value={filter.tags || ''}
          onChange={(e) => setFilter({ ...filter, tags: e.target.value || undefined })}
          className="px-3 py-2 border rounded flex-1"
        />
      </div>

      <div className="space-y-4">
        {moments.map((moment) => (
          <div
            key={moment.id}
            className={`p-4 border-l-4 rounded ${typeColors[moment.type]}`}
          >
            <div className="flex justify-between items-start mb-2">
              <div>
                <h3 className="font-semibold text-lg">{moment.title}</h3>
                <p className="text-sm text-gray-600">
                  {new Date(moment.date).toLocaleDateString()} • {moment.type}
                </p>
              </div>
            </div>
            {moment.story && (
              <p className="text-gray-700 mb-2 whitespace-pre-wrap">{moment.story}</p>
            )}
            {moment.impact && (
              <div className="mt-2">
                <p className="text-sm font-medium">Impact:</p>
                <p className="text-gray-700">{moment.impact}</p>
              </div>
            )}
            {moment.witnesses && (
              <p className="text-sm text-gray-600 mt-2">
                Witnesses: {moment.witnesses}
              </p>
            )}
            {moment.tags && (
              <div className="flex gap-1 mt-2">
                {moment.tags.split(',').map((tag, i) => (
                  <span
                    key={i}
                    className="px-2 py-1 bg-gray-200 rounded text-xs"
                  >
                    {tag.trim()}
                  </span>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
```

**File**: `frontend/src/components/WorkTimeline.tsx`

Update to include career moments:

```typescript
// Add to existing WorkTimeline component
import { getMoments } from '../services/api';

// In component, fetch moments and integrate into timeline
const [moments, setMoments] = useState<CareerMoment[]>([]);

// Add moments to timeline items with special highlighting
```

**Task**: `moments-003` ✅

---

#### Day 5: Manager Report Integration

**File**: `backend/app/services/report_generator.py`

Add career moments to report data:

```python
def aggregate_report_data(
    db: Session,
    start_date: datetime,
    end_date: datetime,
    repo_id: Optional[int] = None
) -> Dict:
    # ... existing code ...
    
    # Career Moments
    moments_query = db.query(CareerMoment).filter(
        CareerMoment.date >= start_date,
        CareerMoment.date <= end_date
    )
    career_moments = moments_query.order_by(CareerMoment.date.desc()).all()
    
    # Get top 3 moments by type (prioritize wins)
    top_moments = sorted(
        career_moments,
        key=lambda m: (m.type == 'win', m.date),
        reverse=True
    )[:3]
    
    return {
        # ... existing data ...
        'career_moments': career_moments,
        'top_moments': top_moments,
    }
```

Update report template to include "Highlights" section:

```python
def generate_report_sections(data: Dict, llm_service) -> Dict:
    sections = {
        # ... existing sections ...
    }
    
    # Career Moments Highlights
    if data.get('top_moments'):
        highlights = []
        for moment in data['top_moments']:
            highlights.append({
                'title': moment.title,
                'date': moment.date.strftime('%Y-%m-%d'),
                'type': moment.type,
                'story': moment.story,
                'impact': moment.impact,
            })
        sections['highlights'] = highlights
    
    return sections
```

**Task**: `moments-004` ✅

**Task**: `moments-005` ✅ (Search/filtering already implemented in API and UI)

---

### Task Group 2: Goals & OKRs Tracking (3-4 days)

#### Day 1: Database Schema & Models

**File**: `backend/app/models.py`

Add Goal model:

```python
class Goal(Base):
    __tablename__ = "goals"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    description = Column(Text)
    deadline = Column(DateTime, nullable=False, index=True)
    status = Column(String, default="active")  # 'active' | 'completed' | 'cancelled'
    progress = Column(Float, default=0.0)  # 0.0 to 1.0
    target_metric = Column(String)  # e.g., "Reduce API latency 30%"
    current_metric = Column(String)  # e.g., "15% reduction achieved"
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
```

Add junction table for linking commits/entries to goals:

```python
class GoalLink(Base):
    __tablename__ = "goal_links"

    id = Column(Integer, primary_key=True, index=True)
    goal_id = Column(Integer, ForeignKey("goals.id"), nullable=False)
    commit_id = Column(Integer, ForeignKey("commits.id"), nullable=True)
    entry_id = Column(Integer, ForeignKey("manual_entries.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
```

**File**: `backend/app/schemas.py`

Add schemas:

```python
class GoalBase(BaseModel):
    title: str
    description: Optional[str] = None
    deadline: datetime
    status: str = "active"
    progress: float = 0.0
    target_metric: Optional[str] = None
    current_metric: Optional[str] = None

class GoalCreate(GoalBase):
    pass

class GoalUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    deadline: Optional[datetime] = None
    status: Optional[str] = None
    progress: Optional[float] = None
    target_metric: Optional[str] = None
    current_metric: Optional[str] = None

class Goal(GoalBase):
    id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class GoalLinkCreate(BaseModel):
    goal_id: int
    commit_id: Optional[int] = None
    entry_id: Optional[int] = None
```

**File**: `backend/alembic/versions/`

Create migration for goals and goal_links tables.

**Task**: `goals-001` ✅

---

#### Day 2: API Endpoints

**File**: `backend/app/api/goals.py`

Create CRUD endpoints for goals and linking:

```python
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime

from ..database import get_db
from ..models import Goal, GoalLink, Commit, ManualEntry
from ..schemas import GoalCreate, GoalUpdate, Goal, GoalLinkCreate

router = APIRouter(prefix="/api/goals", tags=["goals"])

@router.post("", response_model=Goal)
def create_goal(goal: GoalCreate, db: Session = Depends(get_db)):
    """Create a new goal"""
    db_goal = Goal(**goal.dict())
    db.add(db_goal)
    db.commit()
    db.refresh(db_goal)
    return db_goal

@router.get("", response_model=List[Goal])
def get_goals(
    status: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """Get all goals with optional status filter"""
    query = db.query(Goal)
    if status:
        query = query.filter(Goal.status == status)
    return query.order_by(Goal.deadline.asc()).all()

@router.get("/{goal_id}", response_model=Goal)
def get_goal(goal_id: int, db: Session = Depends(get_db)):
    """Get a specific goal with linked items"""
    goal = db.query(Goal).filter(Goal.id == goal_id).first()
    if not goal:
        raise HTTPException(status_code=404, detail="Goal not found")
    return goal

@router.put("/{goal_id}", response_model=Goal)
def update_goal(
    goal_id: int,
    goal_update: GoalUpdate,
    db: Session = Depends(get_db)
):
    """Update a goal"""
    goal = db.query(Goal).filter(Goal.id == goal_id).first()
    if not goal:
        raise HTTPException(status_code=404, detail="Goal not found")
    
    update_data = goal_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(goal, field, value)
    
    goal.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(goal)
    return goal

@router.post("/link", response_model=dict)
def link_to_goal(link: GoalLinkCreate, db: Session = Depends(get_db)):
    """Link a commit or manual entry to a goal"""
    goal = db.query(Goal).filter(Goal.id == link.goal_id).first()
    if not goal:
        raise HTTPException(status_code=404, detail="Goal not found")
    
    if link.commit_id:
        commit = db.query(Commit).filter(Commit.id == link.commit_id).first()
        if not commit:
            raise HTTPException(status_code=404, detail="Commit not found")
    
    if link.entry_id:
        entry = db.query(ManualEntry).filter(ManualEntry.id == link.entry_id).first()
        if not entry:
            raise HTTPException(status_code=404, detail="Manual entry not found")
    
    db_link = GoalLink(**link.dict())
    db.add(db_link)
    db.commit()
    return {"message": "Linked successfully"}

@router.get("/{goal_id}/progress")
def get_goal_progress(goal_id: int, db: Session = Depends(get_db)):
    """Get progress details for a goal"""
    goal = db.query(Goal).filter(Goal.id == goal_id).first()
    if not goal:
        raise HTTPException(status_code=404, detail="Goal not found")
    
    links = db.query(GoalLink).filter(GoalLink.goal_id == goal_id).all()
    
    commits = [link.commit_id for link in links if link.commit_id]
    entries = [link.entry_id for link in links if link.entry_id]
    
    return {
        "goal": goal,
        "linked_commits": len(commits),
        "linked_entries": len(entries),
        "total_work_items": len(commits) + len(entries),
    }
```

**File**: `backend/app/main.py`

Register router:

```python
from .api import goals

app.include_router(goals.router)
```

**Task**: `goals-002` ✅

---

#### Day 3: Frontend - Goals Dashboard

**File**: `frontend/src/components/GoalsDashboard.tsx`

Create goals dashboard with progress visualization:

```typescript
import React, { useEffect, useState } from 'react';
import { Goal } from '../types';
import { getGoals, getGoalProgress } from '../services/api';

export const GoalsDashboard: React.FC = () => {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'active' | 'completed' | 'cancelled'>('all');

  useEffect(() => {
    loadGoals();
  }, [filter]);

  const loadGoals = async () => {
    setLoading(true);
    try {
      const status = filter === 'all' ? undefined : filter;
      const data = await getGoals(status);
      setGoals(data);
    } catch (error) {
      console.error('Error loading goals:', error);
    } finally {
      setLoading(false);
    }
  };

  const getProgressColor = (progress: number) => {
    if (progress >= 0.8) return 'bg-green-500';
    if (progress >= 0.5) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  if (loading) return <div>Loading goals...</div>;

  return (
    <div className="space-y-4">
      <div className="flex gap-2 mb-4">
        {(['all', 'active', 'completed', 'cancelled'] as const).map((status) => (
          <button
            key={status}
            onClick={() => setFilter(status)}
            className={`px-4 py-2 rounded ${
              filter === status
                ? 'bg-blue-600 text-white'
                : 'bg-gray-200 hover:bg-gray-300'
            }`}
          >
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </button>
        ))}
      </div>

      <div className="grid gap-4">
        {goals.map((goal) => (
          <div key={goal.id} className="p-4 border rounded">
            <div className="flex justify-between items-start mb-2">
              <div>
                <h3 className="font-semibold text-lg">{goal.title}</h3>
                {goal.description && (
                  <p className="text-gray-600 text-sm mt-1">{goal.description}</p>
                )}
              </div>
              <span className={`px-2 py-1 rounded text-xs ${
                goal.status === 'completed' ? 'bg-green-100 text-green-800' :
                goal.status === 'cancelled' ? 'bg-gray-100 text-gray-800' :
                'bg-blue-100 text-blue-800'
              }`}>
                {goal.status}
              </span>
            </div>

            <div className="mt-3">
              <div className="flex justify-between text-sm mb-1">
                <span>Progress</span>
                <span>{Math.round(goal.progress * 100)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className={`h-2 rounded-full ${getProgressColor(goal.progress)}`}
                  style={{ width: `${goal.progress * 100}%` }}
                />
              </div>
            </div>

            {goal.target_metric && (
              <div className="mt-2 text-sm">
                <span className="font-medium">Target: </span>
                <span>{goal.target_metric}</span>
              </div>
            )}

            {goal.current_metric && (
              <div className="mt-1 text-sm">
                <span className="font-medium">Current: </span>
                <span>{goal.current_metric}</span>
              </div>
            )}

            <div className="mt-2 text-sm text-gray-500">
              Deadline: {new Date(goal.deadline).toLocaleDateString()}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
```

**Task**: `goals-003` ✅

---

#### Day 4: Manager Report Integration

**File**: `backend/app/services/report_generator.py`

Add goals to report:

```python
def aggregate_report_data(...):
    # ... existing code ...
    
    # Goals
    goals_query = db.query(Goal).filter(
        Goal.deadline >= start_date,
        Goal.deadline <= end_date
    )
    goals = goals_query.all()
    
    # Calculate goals achieved vs planned
    active_goals = [g for g in goals if g.status == 'active']
    completed_goals = [g for g in goals if g.status == 'completed']
    
    return {
        # ... existing data ...
        'goals': goals,
        'goals_summary': {
            'total': len(goals),
            'active': len(active_goals),
            'completed': len(completed_goals),
            'completion_rate': len(completed_goals) / len(goals) if goals else 0,
        },
    }
```

Add "Goals & OKRs" section to report template.

**Task**: `goals-004` ✅

---

### Task Group 3: Peer Feedback Integration (2-3 days)

#### Day 1: Database Schema & API

**File**: `backend/app/models.py`

Add Feedback model:

```python
class Feedback(Base):
    __tablename__ = "feedback"

    id = Column(Integer, primary_key=True, index=True)
    from_who = Column(String, nullable=False)  # Name of person giving feedback
    date = Column(DateTime, nullable=False, index=True)
    context = Column(String)  # e.g., "post-project", "code-review", "1-on-1"
    feedback_text = Column(Text, nullable=False)
    category = Column(String)  # 'positive' | 'constructive' | 'neutral'
    tags = Column(String)  # Comma-separated tags
    created_at = Column(DateTime, default=datetime.utcnow)
```

**File**: `backend/app/schemas.py`

Add schemas:

```python
class FeedbackBase(BaseModel):
    from_who: str
    date: datetime
    context: Optional[str] = None
    feedback_text: str
    category: Optional[str] = None
    tags: Optional[str] = None

class FeedbackCreate(FeedbackBase):
    pass

class FeedbackUpdate(BaseModel):
    from_who: Optional[str] = None
    date: Optional[datetime] = None
    context: Optional[str] = None
    feedback_text: Optional[str] = None
    category: Optional[str] = None
    tags: Optional[str] = None

class Feedback(FeedbackBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True
```

**File**: `backend/app/api/feedback.py`

Create CRUD endpoints:

```python
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime

from ..database import get_db
from ..models import Feedback
from ..schemas import FeedbackCreate, FeedbackUpdate, Feedback

router = APIRouter(prefix="/api/feedback", tags=["feedback"])

@router.post("", response_model=Feedback)
def create_feedback(feedback: FeedbackCreate, db: Session = Depends(get_db)):
    """Create a new feedback entry"""
    db_feedback = Feedback(**feedback.dict())
    db.add(db_feedback)
    db.commit()
    db.refresh(db_feedback)
    return db_feedback

@router.get("", response_model=List[Feedback])
def get_feedback(
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    category: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """Get all feedback with optional filters"""
    query = db.query(Feedback)
    
    if start_date:
        query = query.filter(Feedback.date >= start_date)
    if end_date:
        query = query.filter(Feedback.date <= end_date)
    if category:
        query = query.filter(Feedback.category == category)
    
    return query.order_by(Feedback.date.desc()).all()

@router.get("/stats/trends")
def get_feedback_trends(
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    db: Session = Depends(get_db)
):
    """Get feedback trends over time"""
    query = db.query(Feedback)
    
    if start_date:
        query = query.filter(Feedback.date >= start_date)
    if end_date:
        query = query.filter(Feedback.date <= end_date)
    
    feedback_list = query.all()
    
    trends = {
        "total": len(feedback_list),
        "by_category": {},
        "by_month": {},
    }
    
    for feedback in feedback_list:
        category = feedback.category or "neutral"
        trends["by_category"][category] = trends["by_category"].get(category, 0) + 1
        
        month_key = feedback.date.strftime("%Y-%m")
        trends["by_month"][month_key] = trends["by_month"].get(month_key, 0) + 1
    
    return trends
```

**File**: `backend/app/main.py`

Register router:

```python
from .api import feedback

app.include_router(feedback.router)
```

**Task**: `feedback-001` ✅

---

#### Day 2: Frontend - Feedback Form & Display

**File**: `frontend/src/components/FeedbackForm.tsx`

Create simple feedback form:

```typescript
import React, { useState } from 'react';
import { FeedbackCreate } from '../types';
import { createFeedback } from '../services/api';

interface FeedbackFormProps {
  onSuccess?: () => void;
}

export const FeedbackForm: React.FC<FeedbackFormProps> = ({ onSuccess }) => {
  const [formData, setFormData] = useState<FeedbackCreate>({
    from_who: '',
    date: new Date().toISOString().split('T')[0],
    context: '',
    feedback_text: '',
    category: 'positive',
    tags: '',
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await createFeedback(formData);
      setFormData({
        from_who: '',
        date: new Date().toISOString().split('T')[0],
        context: '',
        feedback_text: '',
        category: 'positive',
        tags: '',
      });
      onSuccess?.();
    } catch (error) {
      console.error('Error saving feedback:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium mb-1">From</label>
        <input
          type="text"
          value={formData.from_who}
          onChange={(e) => setFormData({ ...formData, from_who: e.target.value })}
          className="w-full px-3 py-2 border rounded"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Date</label>
        <input
          type="date"
          value={formData.date}
          onChange={(e) => setFormData({ ...formData, date: e.target.value })}
          className="w-full px-3 py-2 border rounded"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Context</label>
        <input
          type="text"
          value={formData.context || ''}
          onChange={(e) => setFormData({ ...formData, context: e.target.value })}
          className="w-full px-3 py-2 border rounded"
          placeholder="e.g., post-project, code-review, 1-on-1"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Category</label>
        <select
          value={formData.category}
          onChange={(e) => setFormData({ ...formData, category: e.target.value })}
          className="w-full px-3 py-2 border rounded"
        >
          <option value="positive">Positive</option>
          <option value="constructive">Constructive</option>
          <option value="neutral">Neutral</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Feedback</label>
        <textarea
          value={formData.feedback_text}
          onChange={(e) => setFormData({ ...formData, feedback_text: e.target.value })}
          className="w-full px-3 py-2 border rounded"
          rows={6}
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Tags</label>
        <input
          type="text"
          value={formData.tags || ''}
          onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
          className="w-full px-3 py-2 border rounded"
          placeholder="Comma-separated tags"
        />
      </div>

      <button
        type="submit"
        disabled={loading}
        className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
      >
        {loading ? 'Saving...' : 'Save Feedback'}
      </button>
    </form>
  );
};
```

**File**: `frontend/src/components/FeedbackTimeline.tsx`

Create feedback display component with trends:

```typescript
import React, { useEffect, useState } from 'react';
import { Feedback } from '../types';
import { getFeedback, getFeedbackTrends } from '../services/api';

export const FeedbackTimeline: React.FC = () => {
  const [feedback, setFeedback] = useState<Feedback[]>([]);
  const [trends, setTrends] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadFeedback();
    loadTrends();
  }, []);

  const loadFeedback = async () => {
    try {
      const data = await getFeedback();
      setFeedback(data);
    } catch (error) {
      console.error('Error loading feedback:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadTrends = async () => {
    try {
      const data = await getFeedbackTrends();
      setTrends(data);
    } catch (error) {
      console.error('Error loading trends:', error);
    }
  };

  if (loading) return <div>Loading feedback...</div>;

  return (
    <div className="space-y-4">
      {trends && (
        <div className="p-4 bg-gray-50 rounded">
          <h3 className="font-semibold mb-2">Feedback Trends</h3>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-sm text-gray-600">Total</p>
              <p className="text-2xl font-bold">{trends.total}</p>
            </div>
            {Object.entries(trends.by_category || {}).map(([cat, count]) => (
              <div key={cat}>
                <p className="text-sm text-gray-600 capitalize">{cat}</p>
                <p className="text-2xl font-bold">{count as number}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="space-y-3">
        {feedback.map((item) => (
          <div key={item.id} className="p-4 border rounded">
            <div className="flex justify-between items-start mb-2">
              <div>
                <p className="font-semibold">{item.from_who}</p>
                <p className="text-sm text-gray-600">
                  {new Date(item.date).toLocaleDateString()}
                  {item.context && ` • ${item.context}`}
                </p>
              </div>
              {item.category && (
                <span className={`px-2 py-1 rounded text-xs ${
                  item.category === 'positive' ? 'bg-green-100 text-green-800' :
                  item.category === 'constructive' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-gray-100 text-gray-800'
                }`}>
                  {item.category}
                </span>
              )}
            </div>
            <p className="text-gray-700 whitespace-pre-wrap">{item.feedback_text}</p>
            {item.tags && (
              <div className="flex gap-1 mt-2">
                {item.tags.split(',').map((tag, i) => (
                  <span key={i} className="px-2 py-1 bg-gray-200 rounded text-xs">
                    {tag.trim()}
                  </span>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
```

**Task**: `feedback-002` ✅
**Task**: `feedback-004` ✅

---

#### Day 3: Manager Report Integration

**File**: `backend/app/services/report_generator.py`

Add feedback quotes to report:

```python
def aggregate_report_data(...):
    # ... existing code ...
    
    # Feedback
    feedback_query = db.query(Feedback).filter(
        Feedback.date >= start_date,
        Feedback.date <= end_date
    )
    feedback_list = feedback_query.order_by(Feedback.date.desc()).all()
    
    # Get top positive feedback quotes
    positive_feedback = [
        f for f in feedback_list
        if f.category == 'positive'
    ][:5]
    
    return {
        # ... existing data ...
        'feedback': feedback_list,
        'positive_feedback_quotes': positive_feedback,
    }
```

Add "What Peers Say" section to report template with quotes.

**Task**: `feedback-003` ✅

---

### Task Group 4: Time Context & Work Patterns (4-5 days)

#### Day 1-2: Timezone Detection & Working Hours Analysis

**File**: `backend/app/analysis/time_patterns.py`

Create time pattern analysis module:

```python
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from sqlalchemy.orm import Session
from collections import defaultdict
import pytz

from ..models import Commit

def detect_timezone(commits: List[Commit]) -> Optional[str]:
    """Detect timezone from commit patterns"""
    if not commits:
        return None
    
    # Analyze commit hour distribution
    hour_distribution = defaultdict(int)
    for commit in commits:
        if commit.date:
            hour_distribution[commit.date.hour] += 1
    
    # Most common working hours (assume 9-17 in local time)
    # This is a heuristic - could be improved with more sophisticated analysis
    most_common_hour = max(hour_distribution.items(), key=lambda x: x[1])[0]
    
    # Simple heuristic: if most commits are 9-17, likely in that timezone
    # For now, return UTC and let user configure
    return "UTC"

def analyze_working_hours(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """Analyze working hours patterns from commits"""
    query = db.query(Commit)
    
    if start_date:
        query = query.filter(Commit.date >= start_date)
    if end_date:
        query = query.filter(Commit.date <= end_date)
    if repo_id:
        query = query.filter(Commit.repo_id == repo_id)
    
    commits = query.all()
    
    # Hour distribution (0-23)
    hour_distribution = defaultdict(int)
    day_of_week_distribution = defaultdict(int)  # 0=Monday, 6=Sunday
    
    for commit in commits:
        if commit.date:
            hour_distribution[commit.date.hour] += 1
            day_of_week_distribution[commit.date.weekday()] += 1
    
    # Find most productive hours
    sorted_hours = sorted(hour_distribution.items(), key=lambda x: x[1], reverse=True)
    top_hours = [h for h, _ in sorted_hours[:3]]
    
    # Best focus time (consecutive hours with high activity)
    best_start_hour = None
    best_end_hour = None
    max_consecutive = 0
    current_start = None
    current_count = 0
    
    for hour in range(24):
        count = hour_distribution[hour]
        if count > 0:
            if current_start is None:
                current_start = hour
            current_count += count
        else:
            if current_start is not None and current_count > max_consecutive:
                max_consecutive = current_count
                best_start_hour = current_start
                best_end_hour = hour - 1
            current_start = None
            current_count = 0
    
    return {
        "hour_distribution": dict(hour_distribution),
        "day_of_week_distribution": dict(day_of_week_distribution),
        "top_hours": top_hours,
        "best_focus_time": {
            "start": best_start_hour,
            "end": best_end_hour,
        } if best_start_hour else None,
        "total_commits": len(commits),
    }

def detect_after_hours_work(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None,
    work_start_hour: int = 9,
    work_end_hour: int = 17
) -> Dict:
    """Detect commits made outside normal working hours"""
    query = db.query(Commit)
    
    if start_date:
        query = query.filter(Commit.date >= start_date)
    if end_date:
        query = query.filter(Commit.date <= end_date)
    if repo_id:
        query = query.filter(Commit.repo_id == repo_id)
    
    commits = query.all()
    
    after_hours = []
    weekend_work = []
    holiday_work = []  # Would need holiday calendar
    
    for commit in commits:
        if commit.date:
            hour = commit.date.hour
            weekday = commit.date.weekday()
            
            # After hours (before 9 AM or after 5 PM on weekdays)
            if weekday < 5:  # Monday-Friday
                if hour < work_start_hour or hour >= work_end_hour:
                    after_hours.append(commit)
            
            # Weekend work
            if weekday >= 5:  # Saturday-Sunday
                weekend_work.append(commit)
    
    return {
        "after_hours_count": len(after_hours),
        "weekend_count": len(weekend_work),
        "after_hours_commits": [c.id for c in after_hours[:10]],  # Sample
        "weekend_commits": [c.id for c in weekend_work[:10]],
        "percentage_after_hours": len(after_hours) / len(commits) * 100 if commits else 0,
        "percentage_weekend": len(weekend_work) / len(commits) * 100 if commits else 0,
    }
```

**File**: `backend/app/api/time_patterns.py`

Create API endpoints:

```python
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import Optional
from datetime import datetime

from ..database import get_db
from ..analysis.time_patterns import (
    analyze_working_hours,
    detect_after_hours_work,
    detect_timezone
)

router = APIRouter(prefix="/api/time-patterns", tags=["time-patterns"])

@router.get("/working-hours")
def get_working_hours(
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None,
    db: Session = Depends(get_db)
):
    """Get working hours analysis"""
    return analyze_working_hours(db, start_date, end_date, repo_id)

@router.get("/after-hours")
def get_after_hours(
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None,
    work_start_hour: int = 9,
    work_end_hour: int = 17,
    db: Session = Depends(get_db)
):
    """Get after-hours work analysis"""
    return detect_after_hours_work(
        db, start_date, end_date, repo_id, work_start_hour, work_end_hour
    )
```

**Task**: `time-001` ✅
**Task**: `time-002` ✅
**Task**: `time-003` ✅
**Task**: `time-004` ✅

---

#### Day 3: Frontend - Working Hours Heatmap

**File**: `frontend/src/components/WorkingHoursHeatmap.tsx`

Create heatmap visualization:

```typescript
import React, { useEffect, useState } from 'react';
import { getWorkingHours, getAfterHours } from '../services/api';

export const WorkingHoursHeatmap: React.FC = () => {
  const [workingHours, setWorkingHours] = useState<any>(null);
  const [afterHours, setAfterHours] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [hours, after] = await Promise.all([
        getWorkingHours(),
        getAfterHours(),
      ]);
      setWorkingHours(hours);
      setAfterHours(after);
    } catch (error) {
      console.error('Error loading time patterns:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div>Loading time patterns...</div>;

  const getIntensity = (count: number, max: number) => {
    if (max === 0) return 0;
    return Math.min(count / max, 1);
  };

  const maxCount = Math.max(...Object.values(workingHours?.hour_distribution || {}));

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-4">Working Hours Heatmap</h3>
        <div className="grid grid-cols-24 gap-1">
          {Array.from({ length: 24 }, (_, hour) => {
            const count = workingHours?.hour_distribution[hour] || 0;
            const intensity = getIntensity(count, maxCount);
            return (
              <div
                key={hour}
                className="p-2 text-center text-xs"
                style={{
                  backgroundColor: `rgba(59, 130, 246, ${intensity})`,
                  color: intensity > 0.5 ? 'white' : 'black',
                }}
                title={`${hour}:00 - ${count} commits`}
              >
                {hour}
                <br />
                {count}
              </div>
            );
          })}
        </div>
      </div>

      {workingHours?.best_focus_time && (
        <div className="p-4 bg-blue-50 rounded">
          <p className="font-semibold">Best Focus Time</p>
          <p className="text-lg">
            {workingHours.best_focus_time.start}:00 - {workingHours.best_focus_time.end}:00
          </p>
        </div>
      )}

      {afterHours && (
        <div className="p-4 bg-yellow-50 rounded">
          <p className="font-semibold">After-Hours Work</p>
          <p>After-hours commits: {afterHours.after_hours_count}</p>
          <p>Weekend commits: {afterHours.weekend_count}</p>
          <p>
            {afterHours.percentage_after_hours.toFixed(1)}% of commits outside work hours
          </p>
        </div>
      )}
    </div>
  );
};
```

**Task**: `time-002` (UI part) ✅

---

#### Day 4-5: Calendar Integration (Optional - Can be deferred)

**File**: `backend/app/services/calendar_service.py`

Create calendar integration service (placeholder for future implementation):

```python
# Placeholder for calendar integration
# Would integrate with Google Calendar or Outlook API
# For now, this is a future enhancement

def get_meeting_time(
    start_date: datetime,
    end_date: datetime
) -> Dict:
    """Get meeting time from calendar integration"""
    # TODO: Implement calendar API integration
    return {
        "total_meeting_hours": 0,
        "meetings": [],
    }
```

**Note**: Calendar integration (`time-005`) can be deferred to a future sprint as it requires OAuth setup and API integration. The core time pattern analysis is more valuable for immediate use.

**Task**: `time-005` ⏳ Deferred (optional enhancement)

---

## 📋 Integration Checklist

After implementing all task groups, ensure:

- [ ] All new models have migrations created and applied
- [ ] All API endpoints are registered in `main.py`
- [ ] Frontend types are updated in `types/index.ts`
- [ ] API service methods are added to `services/api.ts`
- [ ] All components are added to appropriate pages
- [ ] Manager Report Generator includes all new data sources
- [ ] Navigation updated in `App.tsx` for new pages

---

## 🎯 Success Criteria Validation

### Career Moments
- ✅ You can document "shipped payments refactor that saved 20% API costs" as a moment
- ✅ Manager Report opens with your top 3 moments of the quarter

### Goals & OKRs
- ✅ You define "Reduce checkout API latency 30%" and the tool shows progress
- ✅ Review shows alignment between work and goals

### Peer Feedback
- ✅ You request feedback post-project and store it in the tool
- ✅ Manager Report has a "What peers say" section

### Time Patterns
- ✅ You can prove you don't do unsustainable overwork
- ✅ Dashboard shows "Best focus time: 9-11 AM weekdays"

---

## 📝 Notes

- **Rich Text Editor**: For `moments-002`, start with a simple textarea. Can upgrade to a proper rich text editor (like Quill or Tiptap) in a future iteration.
- **Calendar Integration**: `time-005` is marked as optional and can be deferred. The core time pattern analysis provides immediate value.
- **Goals Linking**: The linking system allows connecting commits and manual entries to goals, enabling automatic progress calculation in the future.
- **Feedback Trends**: The trends analysis helps identify patterns in peer feedback over time.

---

**Next Steps**: Start with Career Moments (Task Group 1) as it provides the most immediate storytelling value for performance reviews.

---

## ✅ Implementation Complete

All Sprint 5 features have been successfully implemented:

- ✅ **Career Moments**: Full CRUD API, frontend forms, timeline integration, and report integration
- ✅ **Goals & OKRs**: Goal tracking with progress visualization, linking to commits/entries, and report integration
- ✅ **Peer Feedback**: Feedback collection, trends analysis, and report integration with quotes
- ✅ **Time Patterns**: Working hours analysis, after-hours detection, heatmap visualization, and report integration

**Note**: Calendar integration (`time-005`) remains deferred as an optional future enhancement requiring OAuth setup.

