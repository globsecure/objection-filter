# 🚀 Sprint 3 - DORA & SPACE Metrics Enhancement

**Goal**: Complete and enhance DORA and SPACE metrics calculations, integrate with friction logs and manual entries, and create comprehensive dashboards.

**Timeline**: 2-3 weeks

**Status**: ✅ **COMPLETE**

**Success Criteria**: 
- All DORA metrics calculated accurately with benchmarks
- All SPACE metrics calculated with friction logs and manual entries integration
- Interactive dashboards showing trends and comparisons
- Metrics integrated into Manager Reports

---

## 📋 Overview

Sprint 3 enhances the existing DORA and SPACE metrics implementations to be production-ready. While basic calculations exist, we need to:

1. **Complete DORA Metrics**: Add Change Failure Rate and MTTR calculations
2. **Enhance SPACE Metrics**: Integrate friction logs and manual entries into all 5 dimensions
3. **Create Dashboards**: Visual representations with trends and benchmarks
4. **Integration**: Ensure metrics flow into Manager Reports seamlessly

**Key Features**:
- Complete DORA metrics (4/4): Deployment Frequency, Lead Time, Change Failure Rate, MTTR
- Complete SPACE metrics (5/5): Satisfaction, Performance, Activity, Collaboration, Efficiency
- Interactive dashboards with trends
- Benchmark comparisons (Elite/High/Medium/Low)
- Integration with friction logs and manual entries

---

## 📋 Tasks Breakdown

### Task Group 1: Complete DORA Metrics (3-4 days)

#### Day 1: Change Failure Rate Calculation

**File**: `backend/app/analysis/dora_metrics.py`

**Status**: ⏳ To be implemented

Add Change Failure Rate calculation:

```python
def calculate_change_failure_rate(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """
    Calculate Change Failure Rate: % of deployments that result in incidents.
    
    Sources:
    1. Friction logs with type='incident' linked to commits
    2. Commits with keywords: revert, hotfix, rollback
    3. Revert commits (detected from commit messages)
    """
    # Get all deployments (merges to main)
    deployments = get_deployments(db, start_date, end_date, repo_id)
    
    # Get incidents from friction logs
    incident_query = db.query(FrictionLog).filter(
        FrictionLog.type == 'incident',
        FrictionLog.date >= start_date if start_date else True,
        FrictionLog.date <= end_date if end_date else True
    )
    incidents = incident_query.all()
    
    # Get revert/hotfix commits
    revert_keywords = ['revert', 'hotfix', 'rollback', 'fix critical', 'emergency']
    revert_commits = db.query(Commit).filter(
        Commit.date >= start_date if start_date else True,
        Commit.date <= end_date if end_date else True,
        or_(*[Commit.message.ilike(f'%{kw}%') for kw in revert_keywords])
    )
    if repo_id:
        revert_commits = revert_commits.filter(Commit.repo_id == repo_id)
    revert_commits = revert_commits.all()
    
    # Match incidents to deployments (within 24 hours)
    failed_deployments = set()
    for incident in incidents:
        # Find deployments within 24h before incident
        incident_time = incident.date
        for deploy in deployments:
            if abs((deploy.date - incident_time).total_seconds()) < 86400:  # 24 hours
                failed_deployments.add(deploy.id)
    
    # Add revert commits as failures
    for revert in revert_commits:
        # Find associated deployment
        for deploy in deployments:
            if abs((deploy.date - revert.date).total_seconds()) < 86400:
                failed_deployments.add(deploy.id)
    
    total_deployments = len(deployments)
    failed_count = len(failed_deployments)
    
    failure_rate = (failed_count / total_deployments * 100) if total_deployments > 0 else 0.0
    
    # Determine benchmark category
    if failure_rate <= 5:
        category = "Elite"
    elif failure_rate <= 10:
        category = "High"
    elif failure_rate <= 15:
        category = "Medium"
    else:
        category = "Low"
    
    return {
        'failure_rate': round(failure_rate, 2),
        'total_deployments': total_deployments,
        'failed_deployments': failed_count,
        'category': category,
        'incidents_count': len(incidents),
        'revert_commits_count': len(revert_commits)
    }
```

---

#### Day 2: Mean Time to Recovery (MTTR)

**File**: `backend/app/analysis/dora_metrics.py`

**Status**: ⏳ To be implemented

Add MTTR calculation using friction logs:

```python
def calculate_mttr(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """
    Calculate Mean Time to Recovery from incidents.
    
    Uses friction logs with type='incident' and resolution timestamps.
    Falls back to time between incident and first fix commit.
    """
    # Get incidents from friction logs
    incident_query = db.query(FrictionLog).filter(
        FrictionLog.type == 'incident',
        FrictionLog.date >= start_date if start_date else True,
        FrictionLog.date <= end_date if end_date else True
    )
    incidents = incident_query.all()
    
    recovery_times = []
    
    for incident in incidents:
        recovery_time = None
        
        # Method 1: Use resolution field if it has timestamp
        if incident.resolution:
            # Try to extract timestamp or find resolution commit
            # Look for fix commits after incident
            fix_commits = db.query(Commit).filter(
                Commit.date > incident.date,
                Commit.date <= incident.date + timedelta(days=7),  # Within 7 days
                or_(
                    Commit.message.ilike('%fix%'),
                    Commit.message.ilike('%resolve%'),
                    Commit.message.ilike('%patch%')
                )
            )
            if repo_id:
                fix_commits = fix_commits.filter(Commit.repo_id == repo_id)
            
            first_fix = fix_commits.order_by(Commit.date.asc()).first()
            if first_fix:
                recovery_time = (first_fix.date - incident.date).total_seconds() / 3600  # hours
        
        if recovery_time:
            recovery_times.append(recovery_time)
    
    if not recovery_times:
        return {
            'mean_hours': 0.0,
            'median_hours': 0.0,
            'min_hours': 0.0,
            'max_hours': 0.0,
            'total_incidents': len(incidents),
            'resolved_incidents': 0,
            'category': 'N/A'
        }
    
    mean_hours = statistics.mean(recovery_times)
    median_hours = statistics.median(recovery_times)
    
    # Determine benchmark category
    if mean_hours < 1:
        category = "Elite"
    elif mean_hours < 24:
        category = "High"
    elif mean_hours < 168:  # 1 week
        category = "Medium"
    else:
        category = "Low"
    
    return {
        'mean_hours': round(mean_hours, 2),
        'median_hours': round(median_hours, 2),
        'min_hours': round(min(recovery_times), 2),
        'max_hours': round(max(recovery_times), 2),
        'total_incidents': len(incidents),
        'resolved_incidents': len(recovery_times),
        'category': category
    }
```

---

#### Day 3: Enhanced DORA Summary Function

**File**: `backend/app/analysis/dora_metrics.py`

**Status**: ⏳ To be enhanced

Update `get_dora_metrics()` to include all 4 metrics:

```python
def get_dora_metrics(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """
    Get complete DORA metrics summary (all 4 metrics).
    """
    return {
        'deployment_frequency': calculate_deployment_frequency(db, start_date, end_date, repo_id),
        'lead_time': calculate_cycle_time(db, start_date, end_date, repo_id),
        'change_failure_rate': calculate_change_failure_rate(db, start_date, end_date, repo_id),
        'mttr': calculate_mttr(db, start_date, end_date, repo_id),
        'overall_score': calculate_dora_score(...),  # Optional: composite score
        'benchmark_category': determine_overall_category(...)  # Optional
    }
```

---

### Task Group 2: Complete SPACE Metrics (4-5 days)

#### Day 4: Satisfaction & Wellbeing Integration

**File**: `backend/app/analysis/space_metrics.py`

**Status**: ⏳ To be implemented

Integrate friction logs (DailyLog) into satisfaction calculation:

```python
def calculate_satisfaction_metrics(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None
) -> Dict:
    """
    Calculate Satisfaction & Wellbeing from DailyLog entries.
    """
    query = db.query(DailyLog).filter(
        DailyLog.date >= start_date if start_date else True,
        DailyLog.date <= end_date if end_date else True
    )
    logs = query.order_by(DailyLog.date.asc()).all()
    
    if not logs:
        return {
            'average_satisfaction': 0.0,
            'average_wellbeing': 0.0,
            'trend': 'stable',
            'low_weeks_count': 0,
            'total_entries': 0
        }
    
    satisfaction_scores = [log.satisfaction_score for log in logs if log.satisfaction_score]
    wellbeing_scores = [log.wellbeing_score for log in logs if log.wellbeing_score]
    
    # Calculate trend (comparing first half vs second half)
    if len(satisfaction_scores) >= 4:
        first_half = statistics.mean(satisfaction_scores[:len(satisfaction_scores)//2])
        second_half = statistics.mean(satisfaction_scores[len(satisfaction_scores)//2:])
        if second_half > first_half + 0.5:
            trend = 'improving'
        elif second_half < first_half - 0.5:
            trend = 'declining'
        else:
            trend = 'stable'
    else:
        trend = 'stable'
    
    # Count low weeks (score < 5)
    low_weeks = len([s for s in satisfaction_scores if s and s < 5])
    
    return {
        'average_satisfaction': round(statistics.mean(satisfaction_scores), 2) if satisfaction_scores else 0.0,
        'average_wellbeing': round(statistics.mean(wellbeing_scores), 2) if wellbeing_scores else 0.0,
        'trend': trend,
        'low_weeks_count': low_weeks,
        'total_entries': len(logs),
        'scores_over_time': [
            {'date': log.date.isoformat(), 'satisfaction': log.satisfaction_score, 'wellbeing': log.wellbeing_score}
            for log in logs if log.satisfaction_score
        ]
    }
```

---

#### Day 5: Performance Metrics Enhancement

**File**: `backend/app/analysis/space_metrics.py`

**Status**: ⏳ To be enhanced

Enhance performance calculation with manual entries:

```python
def calculate_performance_metrics(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """
    Calculate Performance (Output) metrics combining commits and manual entries.
    """
    # Get commits
    commit_query = db.query(Commit).filter(
        Commit.date >= start_date if start_date else True,
        Commit.date <= end_date if end_date else True
    )
    if repo_id:
        commit_query = commit_query.filter(Commit.repo_id == repo_id)
    commits = commit_query.all()
    
    # Get manual entries
    manual_query = db.query(ManualEntry).filter(
        ManualEntry.date >= start_date if start_date else True,
        ManualEntry.date <= end_date if end_date else True
    )
    manual_entries = manual_query.all()
    
    # Calculate volume metrics
    total_commits = len(commits)
    total_insertions = sum(c.insertions for c in commits)
    total_deletions = sum(c.deletions for c in commits)
    merge_commits = len([c for c in commits if c.is_merge_commit])
    
    # Manual entry metrics
    code_reviews = len([e for e in manual_entries if e.type == 'code_review'])
    design_docs = len([e for e in manual_entries if e.type == 'design_doc'])
    mentoring = len([e for e in manual_entries if e.type == 'mentoring'])
    
    # Quality metrics
    revert_commits = len([c for c in commits if 'revert' in c.message.lower()])
    revert_rate = (revert_commits / total_commits * 100) if total_commits > 0 else 0.0
    
    # Calculate quality score (0-100)
    # Penalize revert rate, reward code reviews and design docs
    quality_score = 100.0
    quality_score -= min(revert_rate * 2, 20)  # Max 20 point penalty
    quality_score += min(code_reviews * 0.5, 10)  # Max 10 point bonus
    quality_score += min(design_docs * 1, 10)  # Max 10 point bonus
    quality_score = max(0, min(100, quality_score))  # Clamp to 0-100
    
    return {
        'commits': total_commits,
        'lines_changed': total_insertions + total_deletions,
        'net_change': total_insertions - total_deletions,
        'merge_commits': merge_commits,
        'code_reviews': code_reviews,
        'design_docs': design_docs,
        'mentoring_sessions': mentoring,
        'revert_rate': round(revert_rate, 2),
        'quality_score': round(quality_score, 2)
    }
```

---

#### Day 6: Activity Metrics Enhancement

**File**: `backend/app/analysis/space_metrics.py`

**Status**: ⏳ To be enhanced

Enhance activity calculation with fragmentation analysis:

```python
def calculate_activity_metrics(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """
    Calculate Activity (Volume) metrics with consistency and fragmentation analysis.
    """
    commit_query = db.query(Commit).filter(
        Commit.date >= start_date if start_date else True,
        Commit.date <= end_date if end_date else True
    )
    if repo_id:
        commit_query = commit_query.filter(Commit.repo_id == repo_id)
    commits = commit_query.order_by(Commit.date.asc()).all()
    
    if not commits:
        return {
            'active_days': 0,
            'active_days_pct': 0.0,
            'avg_commits_per_day': 0.0,
            'consistency_score': 0.0,
            'longest_streak': 0,
            'fragmentation_score': 0.0
        }
    
    # Get unique dates
    commit_dates = sorted(set(c.date.date() for c in commits))
    total_days = (end_date.date() - start_date.date()).days if start_date and end_date else len(commit_dates)
    active_days = len(commit_dates)
    
    # Commits per day
    commits_per_day = defaultdict(int)
    for commit in commits:
        commits_per_day[commit.date.date()] += 1
    
    # Consistency score (lower std dev = more consistent)
    daily_counts = list(commits_per_day.values())
    if len(daily_counts) > 1:
        mean_count = statistics.mean(daily_counts)
        std_dev = statistics.stdev(daily_counts)
        consistency_score = max(0, 1 - (std_dev / mean_count)) if mean_count > 0 else 0.0
    else:
        consistency_score = 1.0
    
    # Longest streak
    longest_streak = calculate_longest_streak(commit_dates)
    
    # Fragmentation: gaps between commits
    gaps = []
    for i in range(1, len(commit_dates)):
        gap = (commit_dates[i] - commit_dates[i-1]).days
        gaps.append(gap)
    
    # Fragmentation score: higher = more fragmented (more gaps > 1 day)
    if gaps:
        fragmentation_score = len([g for g in gaps if g > 1]) / len(gaps)
    else:
        fragmentation_score = 0.0
    
    return {
        'active_days': active_days,
        'active_days_pct': round((active_days / total_days * 100) if total_days > 0 else 0, 2),
        'avg_commits_per_day': round(total_commits / active_days if active_days > 0 else 0, 2),
        'consistency_score': round(consistency_score, 2),
        'longest_streak': longest_streak,
        'fragmentation_score': round(fragmentation_score, 2),
        'total_commits': total_commits
    }
```

---

#### Day 7: Collaboration Metrics

**File**: `backend/app/analysis/space_metrics.py`

**Status**: ⏳ To be implemented

Calculate collaboration from manual entries:

```python
def calculate_collaboration_metrics(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None
) -> Dict:
    """
    Calculate Communication & Collaboration metrics from manual entries.
    """
    query = db.query(ManualEntry).filter(
        ManualEntry.date >= start_date if start_date else True,
        ManualEntry.date <= end_date if end_date else True
    )
    entries = query.all()
    
    # Count by type
    code_reviews = [e for e in entries if e.type == 'code_review']
    design_docs = [e for e in entries if e.type == 'design_doc']
    mentoring = [e for e in entries if e.type == 'mentoring']
    meetings = [e for e in entries if e.type == 'meeting']
    
    # Count unique collaborators
    all_collaborators = set()
    for entry in entries:
        if entry.collaborators:
            collaborators = [c.strip() for c in entry.collaborators.split(',')]
            all_collaborators.update(collaborators)
    
    # Calculate collaboration score (0-100)
    # Based on variety and frequency of collaboration activities
    collaboration_score = 0.0
    collaboration_score += min(len(code_reviews) * 2, 30)  # Max 30 points
    collaboration_score += min(len(design_docs) * 3, 25)  # Max 25 points
    collaboration_score += min(len(mentoring) * 5, 25)  # Max 25 points
    collaboration_score += min(len(all_collaborators) * 2, 20)  # Max 20 points
    collaboration_score = min(100, collaboration_score)
    
    return {
        'code_reviews': len(code_reviews),
        'design_docs': len(design_docs),
        'mentoring_sessions': len(mentoring),
        'meetings': len(meetings),
        'unique_collaborators': len(all_collaborators),
        'collaboration_score': round(collaboration_score, 2),
        'total_collaboration_activities': len(entries)
    }
```

---

#### Day 8: Enhanced SPACE Summary Function

**File**: `backend/app/analysis/space_metrics.py`

**Status**: ⏳ To be enhanced

Update `get_space_metrics()` to include all 5 dimensions:

```python
def get_space_metrics(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """
    Get complete SPACE metrics summary (all 5 dimensions).
    """
    return {
        'satisfaction': calculate_satisfaction_metrics(db, start_date, end_date),
        'performance': calculate_performance_metrics(db, start_date, end_date, repo_id),
        'activity': calculate_activity_metrics(db, start_date, end_date, repo_id),
        'collaboration': calculate_collaboration_metrics(db, start_date, end_date),
        'efficiency': analyze_focus_time(db, start_date, end_date, repo_id),  # Existing flow score
        'overall_score': calculate_space_score(...),  # Optional: composite score
    }
```

---

### Task Group 3: Dashboards & Visualization (3-4 days)

#### Day 9-10: DORA Dashboard Component

**File**: `frontend/src/components/DoraDashboard.tsx`

**Status**: ⏳ To be created

Create comprehensive DORA dashboard:

```typescript
interface DoraDashboardProps {
  startDate: string
  endDate: string
  repoId?: number
}

export function DoraDashboard({ startDate, endDate, repoId }: DoraDashboardProps) {
  const [metrics, setMetrics] = useState<DoraMetrics | null>(null)
  const [loading, setLoading] = useState(false)
  const [trends, setTrends] = useState<any>(null)

  // Features:
  // 1. Four metric cards with current values and benchmark categories
  // 2. Trend charts (line/bar) showing metrics over time
  // 3. Comparison view (current vs previous period)
  // 4. Benchmark indicators (Elite/High/Medium/Low badges)
  // 5. Detailed breakdown tables
  
  return (
    <div className="space-y-6">
      {/* Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <MetricCard
          title="Deployment Frequency"
          value={metrics?.deployment_frequency?.frequency_per_week}
          category={metrics?.deployment_frequency?.category}
          trend={trends?.deployment_frequency}
        />
        {/* ... other metrics */}
      </div>
      
      {/* Trend Charts */}
      <TrendChart data={trends} />
      
      {/* Detailed Tables */}
      <DetailedBreakdown metrics={metrics} />
    </div>
  )
}
```

---

#### Day 11-12: SPACE Dashboard Component

**File**: `frontend/src/components/SpaceDashboard.tsx`

**Status**: ⏳ To be created

Create comprehensive SPACE dashboard:

```typescript
export function SpaceDashboard({ startDate, endDate, repoId }: DashboardProps) {
  // Features:
  // 1. Five dimension cards (S-P-A-C-E)
  // 2. Radar/spider chart showing all 5 dimensions
  // 3. Satisfaction trend over time
  // 4. Activity heatmap (commits by day/hour)
  // 5. Collaboration network visualization
  // 6. Efficiency flow score visualization
  
  return (
    <div className="space-y-6">
      {/* SPACE Radar Chart */}
      <SpaceRadarChart metrics={metrics} />
      
      {/* Individual Dimension Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        {/* Satisfaction, Performance, Activity, Collaboration, Efficiency */}
      </div>
      
      {/* Detailed Visualizations */}
      <SatisfactionTrend data={metrics?.satisfaction} />
      <ActivityHeatmap commits={commits} />
      <CollaborationNetwork entries={manualEntries} />
    </div>
  )
}
```

---

### Task Group 4: API Enhancements (1-2 days)

#### Day 13: Enhanced API Endpoints

**File**: `backend/app/api/dora.py` and `backend/app/api/space.py`

**Status**: ⏳ To be enhanced

Add new endpoints for trends and comparisons:

```python
@router.get("/trends")
def get_dora_trends(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_id: Optional[int] = Query(None),
    group_by: str = Query("week"),  # day, week, month
    db: Session = Depends(get_db)
):
    """Get DORA metrics trends over time."""
    # Return time-series data for all 4 metrics
    pass

@router.get("/compare")
def compare_dora_periods(
    period1_start: datetime = Query(...),
    period1_end: datetime = Query(...),
    period2_start: datetime = Query(...),
    period2_end: datetime = Query(...),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """Compare DORA metrics between two periods."""
    # Return comparison data showing improvements/declines
    pass
```

---

### Task Group 5: Integration & Testing (1-2 days)

#### Day 14: Manager Report Integration

**File**: `backend/app/services/report_generator.py`

**Status**: ⏳ To be enhanced

Ensure metrics are properly formatted in reports:

- DORA metrics already integrated (verify formatting)
- SPACE metrics already integrated (verify all 5 dimensions)
- Add benchmark context to report narratives
- Add trend indicators (improving/declining)

---

#### Day 15: Testing & Validation

**Status**: ⏳ To be done

- Test all calculations with real data
- Verify benchmark categories are accurate
- Test edge cases (no data, single data point, etc.)
- Validate dashboard visualizations
- Test API endpoints with various date ranges

---

## 🎯 Testing Your Implementation

### Manual Test Plan

1. **DORA Metrics Test**:

```bash
# Test Change Failure Rate
curl -X GET "http://localhost:8000/api/dora/change-failure-rate?start_date=2024-10-01&end_date=2024-12-31"

# Test MTTR
curl -X GET "http://localhost:8000/api/dora/mttr?start_date=2024-10-01&end_date=2024-12-31"

# Test complete DORA summary
curl -X GET "http://localhost:8000/api/dora/summary?start_date=2024-10-01&end_date=2024-12-31"
```

2. **SPACE Metrics Test**:

```bash
# Test Satisfaction
curl -X GET "http://localhost:8000/api/space/satisfaction?start_date=2024-10-01&end_date=2024-12-31"

# Test Performance
curl -X GET "http://localhost:8000/api/space/performance?start_date=2024-10-01&end_date=2024-12-31"

# Test complete SPACE summary
curl -X GET "http://localhost:8000/api/space/summary?start_date=2024-10-01&end_date=2024-12-31"
```

3. **Frontend Test**:
- Open DORA dashboard and verify all 4 metrics display
- Open SPACE dashboard and verify all 5 dimensions display
- Check trend charts update correctly
- Verify benchmark categories show correct badges
- Test date range filtering

---

## 📊 Success Metrics for Sprint 3

After completing Sprint 3, you should be able to:

✅ **Complete DORA Metrics**:
- All 4 metrics calculated accurately
- Benchmark categories correctly assigned
- Trends visible over time
- Integration with friction logs for MTTR and Change Failure Rate

✅ **Complete SPACE Metrics**:
- All 5 dimensions calculated
- Integration with friction logs (Satisfaction) and manual entries (Collaboration)
- Flow score and activity metrics enhanced
- Performance metrics include quality indicators

✅ **Dashboards**:
- Interactive visualizations for both DORA and SPACE
- Trend analysis and comparisons
- Benchmark indicators clearly visible
- Responsive and intuitive UI

✅ **Integration**:
- Metrics flow seamlessly into Manager Reports
- All calculations handle edge cases gracefully
- API endpoints return consistent data structures

---

## 🚀 After Sprint 3: What's Next?

With DORA and SPACE metrics complete, you unlock:

1. **Sprint 4**: Multi-Repo Aggregation
   - Aggregate metrics across multiple repositories
   - Cross-repo impact detection
   - Team-level comparisons

2. **Sprint 5**: Data Quality & Validation
   - Commit message quality scoring
   - Data completeness dashboards
   - Automated data validation

3. **Advanced Features**:
   - Career Moments integration
   - Goals & OKRs tracking
   - Peer feedback integration

---

## 💡 Pro Tips

1. **Start with DORA**: It's more straightforward and has clear benchmarks
2. **Use existing data**: Leverage friction logs and manual entries from Sprint 1
3. **Test incrementally**: Test each metric calculation independently
4. **Visualize early**: Create simple charts first, enhance later
5. **Benchmark context**: Always show where you stand (Elite/High/Medium/Low)

---

## 🆘 Common Issues

### Issue: "No incidents found for MTTR"

**Solution**: Ensure friction logs with type='incident' exist. Check date ranges match.

### Issue: "Change Failure Rate is 0% but I know there were issues"

**Solution**: Verify incident friction logs are linked to deployments (within 24h window). Check revert commit detection.

### Issue: "SPACE metrics missing collaboration data"

**Solution**: Ensure manual entries with collaboration types (code_review, design_doc, mentoring) are created.

### Issue: "Dashboard charts not updating"

**Solution**: Check API responses match expected format. Verify date range parameters are correct.

---

## 🎉 Sprint 3 Complete!

**Status**: ⏳ Ready to implement

### Next Steps

1. **Start with Day 1**: Change Failure Rate calculation
2. **Then Day 2**: MTTR calculation
3. **Continue**: Through all task groups
4. **Test**: Each metric independently before integration

**Ready to start? Begin with `dora-003` - Change Failure Rate. It builds on existing deployment frequency logic!**

