This is an ambitious and extremely strategic project. In companies like **PayPal**, a "Data-Driven Performance" culture is very strong. Having a tool that transforms your commit logs and tasks into **impact narratives** will put you light-years ahead in performance cycle meetings.

Below is the complete plan for **DevPulse**, your personal career intelligence tool, translated into English.

---

# 🚀 Project DevPulse: Personal Performance Intelligence

This document serves as the **Master Plan** to be fed into a coding AI (such as Cursor, Claude, or GPT-4) to generate the code for your tool.

## 📌 1. Overview & Objectives

**DevPulse** is a local dashboard for developers who want to automate the collection of productivity evidence. It doesn't just focus on "how many commits," but on **"what was the impact."**

- **Target Audience:** You (Local use).
- **Main Objective:** Generate ready-to-use reports for 1:1s and bi-annual Performance Reviews.
- **Key Differentiator:** Use of AI to summarize technical commits into business achievements.

---

## 🛠 2. Tech Stack

To ensure speed, aesthetics, and ease of running locally:

- **Backend:** Python (FastAPI) – Fast and easy to integrate with analysis scripts.
- **Database:** SQLite – Simple, local, and requires no server installation.
- **Frontend:** React (Vite) + Tailwind CSS + Shadcn/UI – For a modern, "Enterprise-level" look.
- **Visualization:** Recharts – For career evolution charts.
- **Integrations:** GitPython (local analysis), Jira/GitHub APIs (optional).

---

## 🏗 3. System Architecture

1. **Crawler Engine (Python):** Scans local folders for `.git` repositories.
2. **Analysis Layer:** Categorizes commits using keywords or LLM.
3. **Local API:** Serves the processed data to the frontend.
4. **Dashboard (React):** Visualizes metrics and generates the "Performance Report."

---

## 📋 4. Development Backlog (Roadmap)

### Phase 1: Foundation & Git Crawler (MVP)

- **Task 1.1:** Setup FastAPI and SQLite environment.
- **Task 1.2:** Create a Python script that reads a local directory of projects and extracts: Commit message, changed files, date, and line volume.
- **Task 1.3:** Create an endpoint to list this data on the Frontend.

### Phase 2: Intelligence & Categorization

- **Task 2.1:** Implement logic to identify task types (Bugfix, Feature, Refactor, Documentation).
- **Task 2.2:** LLM Integration (OpenAI/Gemini) to transform a list of 50 technical commits into a "Weekly Key Achievements" paragraph.

### Phase 3: React Dashboard

- **Task 3.1:** Create a productivity "Heatmap."
- **Task 3.2:** Develop "Review Mode": A screen where you select a period (e.g., January to June) and it generates a PDF with technical highlights.

---

## 🤖 5. Master Prompt for the AI (Copy & Paste)

> "Act as a Senior Software Engineer. I want to build a local tool called 'DevPulse' to monitor my performance.
> **Technical Requirements:**
>
> 1. Backend in FastAPI with Python. Use the `GitPython` library to analyze local repositories.
> 2. The backend must persist data in SQLite.
> 3. The Frontend must be in React with Tailwind CSS.
> 4. Create a functionality that crawls a project folder on my PC, reads commits from the last 3 months, and groups them by 'Type' (Feature, Fix, Chore).
>
> **Special Feature:**
> I need a 'Generate Manager Report' button that takes the most relevant commits and organizes them into impact-driven bullet points.
> Start by creating the folder structure, the `requirements.txt` for the backend, and the initial Vite configuration for the frontend."

---

## 📈 6. What to measure to impress at PayPal?

For your bi-annual review, the tool should collect these metrics:

| Metric                | What it tells your Manager                                          |
| --------------------- | ------------------------------------------------------------------- |
| **Code Churn**        | If you are refactoring too much or delivering right the first time. |
| **Lead Time**         | How quickly a task goes from "In Progress" to "Done."               |
| **Cross-Team Impact** | Commits that affected shared libraries or documentation.            |
| **Consistency**       | Your delivery pace over the months (avoids the pre-review "rush").  |

---

## 💡 Suggested Next Steps

1. **Install basic dependencies:** `pip install fastapi uvicorn gitpython` and `npm create vite@latest`.
2. **Start with the 'Git Crawler':** This is the most valuable part. Automatically reading your own commits already solves 50% of your "memory" problem during meetings.
3. **Create a "Logbook":** Add a field in the tool for you to write one sentence a day about what you learned. At the end of 6 months, this is pure gold.

**Would you like me to write the initial Python script code that performs this local commit reading so we can get started?**

---

## ✅ Sprint 5 Completion Summary

**Status**: Completed (January 2025)

Sprint 5 successfully implemented all "Polish & Advanced Features" to transform DevPulse into a comprehensive performance storytelling platform:

### Features Delivered

1. **Career Moments** ✅
   - Full CRUD API for documenting wins, failures, pivots, and learning moments
   - Rich text form with timeline visualization
   - Integrated into Work Timeline and Manager Reports
   - Highlights section in reports showcasing top 3 moments

2. **Goals & OKRs Tracking** ✅
   - Goal creation and progress tracking
   - Linking commits and manual entries to goals
   - Progress dashboard with visual indicators
   - Goals summary integrated into Manager Reports

3. **Peer Feedback Integration** ✅
   - Feedback collection form
   - Trends analysis (by category, by month)
   - "What Peers Say" section in Manager Reports with positive quotes

4. **Time Context & Work Patterns** ✅
   - Working hours heatmap visualization
   - Best focus time detection
   - After-hours and weekend work analysis
   - Work patterns section in Manager Reports

### Technical Implementation

- **New Models**: CareerMoment, Goal, GoalLink, Feedback
- **New API Endpoints**: `/api/moments`, `/api/goals`, `/api/feedback`, `/api/time-patterns`
- **New Frontend Pages**: Career Moments, Goals, Feedback
- **New Components**: CareerMomentForm, CareerMomentsTimeline, GoalsDashboard, GoalForm, FeedbackForm, FeedbackTimeline, WorkingHoursHeatmap
- **Report Integration**: All features integrated into Manager Report Generator (Markdown and PDF)

### Database Migrations

- `add_career_moments`: Creates career_moments table
- `add_goals`: Creates goals and goal_links tables
- `add_feedback`: Creates feedback table

### Next Steps

- Calendar integration (deferred - requires OAuth setup)
- Rich text editor upgrade (currently using textarea)
- Enhanced timezone detection with user configuration
