# 📊 DevPulse - Metrics Specification

**Purpose**: Define exactly what to measure, how to calculate, and what it tells your manager.

**Status**: Sprint 3 completo - Todas as métricas DORA e SPACE implementadas e integradas.

---

## 🎯 Framework Overview

We implement **DORA** (velocity/stability) + **SPACE** (holistic developer experience).

### Why These Frameworks?

- **DORA**: Industry standard. Google/DORA research backed. Execs understand it.
- **SPACE**: GitHub/Microsoft research. Captures "invisible work" that DORA misses.

### 📦 Data Sources Available (Sprint 1)

✅ **Commits** - Git history analysis (já implementado)
✅ **Friction Logs** - Blockers, learnings, wins, incidents (Sprint 1)
✅ **Manual Entries** - Code reviews, design docs, mentoring, incidents, meetings (Sprint 1)

**Status**: ✅ Todas as métricas DORA e SPACE implementadas com integração completa de friction logs e manual entries.

---

## 📈 DORA Metrics (Deployment & Delivery)

### 1. Deployment Frequency

**What**: How often you ship code to production (or main branch).

**Calculation**:

```python
def calculate_deployment_frequency(commits, date_range):
    """
    Count merges to main/master branch
    """
    deploys = commits.filter(
        branch__in=['main', 'master'],
        is_merge=True,
        date__range=date_range
    )
    days = (date_range.end - date_range.start).days
    return len(deploys) / (days / 7)  # per week
```

**Benchmark** (DORA Research):

- **Elite**: Multiple deploys per day
- **High**: Once per day to once per week
- **Medium**: Once per week to once per month
- **Low**: Less than once per month

**What to say in review**:

> "I maintained a deployment frequency of 3x/week, placing our team in the High performer category per DORA standards."

---

### 2. Lead Time for Changes

**What**: Time from first commit to deployment (merge to main).

**Calculation**:

```python
def calculate_lead_time(branch_commits):
    """
    For each feature branch:
    - first_commit: earliest commit timestamp
    - merge_commit: merge to main timestamp
    - lead_time: merge_commit - first_commit
    """
    lead_times = []
    for branch in branches:
        first = branch.commits.order_by('date').first()
        merge = branch.merge_commit
        if first and merge:
            hours = (merge.date - first.date).total_seconds() / 3600
            lead_times.append(hours)

    return {
        'mean': statistics.mean(lead_times),
        'median': statistics.median(lead_times),
        'p90': numpy.percentile(lead_times, 90)
    }
```

**Benchmark**:

- **Elite**: Less than 1 day
- **High**: 1 day to 1 week
- **Medium**: 1 week to 1 month
- **Low**: More than 1 month

**What to say in review**:

> "I optimized my development workflow, reducing median lead time from 4 days to 1.5 days - a 62% improvement."

**Implementation Notes**:

- Detect feature branches: branches not named main/master/develop
- Merge detection: commits with >1 parent
- Edge case: direct commits to main (lead time = 0)

---

### 3. Change Failure Rate

**What**: % of deployments that cause incidents/rollbacks.

**Calculation**:

```python
def calculate_change_failure_rate(commits, date_range):
    """
    Detect failure indicators:
    - Commits with keywords: revert, rollback, hotfix
    - Follow-up fix commits < 24h after deploy
    - Manual friction logs tagged as 'incident'
    """
    total_deploys = count_deploys(commits, date_range)

    failures = commits.filter(
        Q(message__icontains='revert') |
        Q(message__icontains='rollback') |
        Q(message__icontains='hotfix') |
        Q(type='revert')
    )

    # Also check friction logs
    incidents = FrictionLog.filter(
        type='incident',
        date__range=date_range
    )

    total_failures = len(failures) + len(incidents)
    return (total_failures / total_deploys) * 100 if total_deploys > 0 else 0
```

**Benchmark**:

- **Elite**: 0-15%
- **High**: 16-30%
- **Medium**: 31-45%
- **Low**: More than 45%

**What to say in review**:

> "My change failure rate was 8%, indicating high code quality and thorough testing before deployment."

---

### 4. Mean Time to Recovery (MTTR)

**What**: How fast you fix production issues.

**Status**: ✅ Dados disponíveis via FrictionLog (tipo 'incident') - Implementação pendente

**Calculation**:

```python
def calculate_mttr(friction_logs, commits):
    """
    For each incident friction log:
    - incident_time: log timestamp
    - resolution_commit: next commit with 'fix', 'resolve', 'hotfix'
    - recovery_time: resolution_commit.date - incident_time
    """
    recovery_times = []

    for incident in friction_logs.filter(type='incident'):
        # Use resolution field from FrictionLog if available
        if incident.resolution:
            # Can also match with commits
            resolution = commits.filter(
                date__gte=incident.date,
                message__iregex=r'(fix|resolve|hotfix).*' + incident.tags
            ).first()

            if resolution:
                minutes = (resolution.date - incident.date).total_seconds() / 60
                recovery_times.append(minutes)

    return statistics.mean(recovery_times) / 60  # in hours
```

**Nota**: FrictionLog agora tem campo `resolution` que pode ser usado para calcular MTTR mais precisamente.

**Benchmark**:

- **Elite**: Less than 1 hour
- **High**: Less than 1 day
- **Medium**: 1 day to 1 week
- **Low**: More than 1 week

**What to say in review**:

> "When production issues occurred, my average recovery time was 2.3 hours, demonstrating strong debugging skills and system knowledge."

**Implementation Notes**:

- Requires friction logs for incidents
- Fallback: detect revert commits
- Consider severity levels (P0/P1/P2)

---

## 🌟 SPACE Metrics (Holistic Performance)

### 1. Satisfaction & Wellbeing (S)

**What**: How you feel about your work and environment.

**Calculation**:

```python
def calculate_satisfaction(health_checks):
    """
    Weekly self-assessment (1-10 scale)
    Track trends, correlations with workload
    """
    scores = [check.score for check in health_checks]

    return {
        'average': statistics.mean(scores),
        'trend': calculate_trend(scores),  # improving/declining
        'low_weeks': len([s for s in scores if s < 5]),
        'correlation_with_commits': pearson(scores, commit_volume)
    }
```

**Red Flags**:

- Score < 5 for 2+ consecutive weeks
- Declining trend over 4+ weeks
- High negative correlation with commit volume (burnout indicator)

**What to say in review**:

> "I maintained consistent satisfaction scores of 7-8/10, indicating healthy work-life balance despite high delivery volume."

**Implementation**:

- Weekly popup: "How satisfied were you with work this week?"
- Optional: Free text for context
- Private metric (not shared unless you choose)

---

### 2. Performance (P)

**What**: Output and quality of your work.

**Calculation**:

```python
def calculate_performance(commits, manual_entries):
    """
    Combine quantitative output with quality indicators
    """
    # Volume metrics
    total_commits = len(commits)
    lines_changed = sum(c.additions + c.deletions for c in commits)
    prs_merged = len(commits.filter(is_merge=True))

    # Quality metrics
    churn_rate = calculate_churn_rate(commits)
    revert_rate = len(commits.filter(type='revert')) / total_commits

    # Manual entries
    code_reviews = len(manual_entries.filter(type='code_review'))
    design_docs = len(manual_entries.filter(type='design_doc'))

    # Quality score (0-100)
    quality = 100 - (churn_rate * 0.5) - (revert_rate * 100)

    return {
        'commits': total_commits,
        'lines_changed': lines_changed,
        'prs_merged': prs_merged,
        'code_reviews': code_reviews,
        'design_docs': design_docs,
        'quality_score': quality
    }
```

**What to say in review**:

> "I delivered 87 commits across 12 features with a 92% quality score, while also completing 23 code reviews for teammates."

---

### 3. Activity (A)

**What**: Volume and consistency of work.

**Calculation**:

```python
def calculate_activity(commits, date_range):
    """
    Frequency and distribution of work
    """
    # Active days
    commit_dates = set(c.date.date() for c in commits)
    total_days = (date_range.end - date_range.start).days
    active_days = len(commit_dates)

    # Commit distribution
    commits_per_day = defaultdict(int)
    for c in commits:
        commits_per_day[c.date.date()] += 1

    # Consistency score (std deviation)
    consistency = 1 - (statistics.stdev(commits_per_day.values()) /
                      statistics.mean(commits_per_day.values()))

    return {
        'active_days': active_days,
        'active_days_pct': (active_days / total_days) * 100,
        'avg_commits_per_day': len(commits) / active_days,
        'consistency_score': consistency,
        'streak_longest': calculate_longest_streak(commit_dates)
    }
```

**What to say in review**:

> "I maintained 87% active days with consistent daily contributions, demonstrating reliable delivery cadence."

**Red Flags**:

- Large gaps (7+ days no activity)
- Extreme spikes (20 commits one day, 0 for a week)
- Weekend/evening heavy work (burnout risk)

---

### 4. Communication & Collaboration (C)

**What**: Teamwork, knowledge sharing, helping others.

**Status**: ✅ Dados disponíveis via ManualEntry - Implementação pendente (Sprint 4)

**Calculation**:

```python
def calculate_collaboration(commits, manual_entries):
    """
    Interaction with team and cross-functional work
    """
    # Code reviews performed
    code_reviews = manual_entries.filter(type='code_review')

    # Cross-repo work (shared libs, docs)
    cross_repo_commits = commits.filter(
        Q(repository__name__icontains='shared') |
        Q(repository__name__icontains='common') |
        Q(files_changed__icontains='README')
    )

    # Design docs written
    design_docs = manual_entries.filter(type='design_doc')

    # Mentoring sessions
    mentoring = manual_entries.filter(type='mentoring')

    # Pair programming
    pair_programming = commits.filter(
        message__iregex=r'(co-authored-by|paired with)'
    )

    return {
        'code_reviews': len(code_reviews),
        'cross_repo_contributions': len(cross_repo_commits),
        'design_docs': len(design_docs),
        'mentoring_sessions': len(mentoring),
        'pair_programming': len(pair_programming),
        'collaboration_score': calculate_weighted_score(...)
    }
```

**Nota**: ManualEntry agora disponível com tipos: `code_review`, `design_doc`, `mentoring`, `incident`, `meeting`. Campos `collaborators` e `duration_minutes` podem ser usados para cálculos mais precisos.

**What to say in review**:

> "I conducted 31 code reviews, wrote 2 design docs, and contributed to 3 shared libraries, demonstrating strong cross-team collaboration."

**Implementation Notes**:

- Requires manual entries (code reviews don't appear in your commits)
- Parse co-author tags from commit messages
- Track meeting time (if calendar integration available)

---

### 5. Efficiency & Flow (E)

**What**: Ability to focus and work without interruptions.

**Calculation**:

```python
def calculate_efficiency(commits, friction_logs):
    """
    Focus time, context switching, blockers
    """
    # Deep work sessions: 2+ consecutive hours of commits
    commit_sessions = group_commits_by_proximity(commits, threshold_hours=2)
    deep_work_sessions = [s for s in commit_sessions if s.duration_hours >= 2]

    # Fragmentation: commits scattered throughout day
    daily_patterns = analyze_commit_patterns(commits)
    fragmentation_score = calculate_fragmentation(daily_patterns)

    # Blockers from friction logs
    blockers = friction_logs.filter(type='blocker')
    avg_blockers_per_week = len(blockers) / weeks_in_range

    # Context switching (commits to different repos in same day)
    context_switches = calculate_repo_switches_per_day(commits)

    # Flow score (0-100, higher is better)
    flow_score = (
        (len(deep_work_sessions) * 10) -
        (fragmentation_score * 20) -
        (avg_blockers_per_week * 5) -
        (context_switches * 2)
    )

    return {
        'deep_work_sessions': len(deep_work_sessions),
        'avg_deep_work_hours_per_week': sum(s.duration for s in deep_work_sessions) / weeks,
        'fragmentation_score': fragmentation_score,
        'blockers_per_week': avg_blockers_per_week,
        'context_switches_per_day': context_switches,
        'flow_score': max(0, min(100, flow_score))
    }
```

**What to say in review**:

> "I optimized my schedule to achieve 15+ hours of deep work per week, resulting in a flow score of 82/100."

**Red Flags**:

- Flow score < 40 (too many interruptions)
- Zero deep work sessions
- High fragmentation (commits spread thin across day)

---

## 🎨 Custom Metrics for PayPal Context

### 6. Business Impact Score

**What**: Connect technical work to business outcomes.

**Calculation**:

```python
def calculate_business_impact(commits, manual_entries, career_moments):
    """
    Weight work by business value
    """
    impact_weights = {
        'feature': 5,      # New capability
        'bugfix': 3,       # Reliability
        'refactor': 2,     # Tech debt
        'documentation': 1 # Enablement
    }

    # Weighted commit score
    commit_score = sum(impact_weights.get(c.type, 0) for c in commits)

    # High-impact moments
    career_moments_score = len(career_moments) * 10

    # Manual entries bonus
    manual_score = sum({
        'incident': 8,     # Crisis management
        'design_doc': 6,   # Strategic thinking
        'mentoring': 4     # Leadership
    }.get(e.type, 0) for e in manual_entries)

    total = commit_score + career_moments_score + manual_score

    return {
        'total_score': total,
        'commits_contribution': commit_score / total,
        'moments_contribution': career_moments_score / total,
        'manual_contribution': manual_score / total
    }
```

**What to say in review**:

> "My work contributed 234 impact points this quarter, with 45% from feature development and 25% from incident response leadership."

---

### 7. Growth Trajectory

**What**: Learning and skill development.

**Calculation**:

```python
def calculate_growth(friction_logs, manual_entries, repos):
    """
    Track skill expansion over time
    """
    # Technologies touched
    languages = set()
    for commit in commits:
        languages.update(detect_languages(commit.files_changed))

    # New repositories (areas of codebase)
    new_repos = repos.filter(first_commit_date__gte=start_of_quarter)

    # Learning moments from friction logs
    learnings = friction_logs.filter(type='learning')

    # Complexity increase (LOC, file count)
    complexity_trend = analyze_complexity_trend(commits)

    return {
        'languages_used': list(languages),
        'new_areas_explored': len(new_repos),
        'documented_learnings': len(learnings),
        'complexity_trend': complexity_trend,  # 'increasing' | 'stable' | 'decreasing'
        'growth_score': calculate_normalized_growth(...)
    }
```

**What to say in review**:

> "I expanded my skillset by contributing to 3 new microservices and learning Kotlin, while documenting 12 key learnings."

---

## 📊 Dashboard Views

### Weekly View (Tactical)

- Commits this week vs last week
- Friction logs to review
- Flow score daily
- Action items: "Log your Friday achievements"

### Monthly View (Operational)

- DORA metrics trends
- SPACE scores radar chart
- Top repositories worked on
- Collaboration highlights

### Quarterly View (Strategic)

- Manager report preview
- Career moments timeline
- Growth trajectory
- Goal progress

---

## 🎯 Data Collection Requirements

### Automatic (Git)

- ✅ Commit hash, message, date, author
- ✅ Files changed, lines added/deleted
- ✅ Branch name, merge status
- ✅ Repository name

### Manual Entry Required

- ✅ Code reviews performed (Sprint 1 - ManualEntry type='code_review')
- ✅ Design documents written (Sprint 1 - ManualEntry type='design_doc')
- ✅ Incidents handled (Sprint 1 - ManualEntry type='incident' + FrictionLog type='incident')
- ✅ Mentoring sessions (Sprint 1 - ManualEntry type='mentoring')
- ⏱️ Meetings attended (Sprint 1 - ManualEntry type='meeting' disponível, calendar integration pendente)

### Weekly Check-in

- ✅ Satisfaction score (1-10) - DailyLog já implementado
- ✅ Friction logs (Sprint 1 - FrictionLog disponível)
- ⏱️ Career moments (pendente)

---

## 🚨 Alert System

Implement alerts for potential issues:

| Alert               | Condition                       | Action                            |
| ------------------- | ------------------------------- | --------------------------------- |
| 🔥 Burnout Risk     | Satisfaction < 5 for 2 weeks    | Suggest time off, review workload |
| 📉 Declining Output | 50% drop in commits for 2 weeks | Check for blockers                |
| 🐛 Quality Issue    | Change failure rate > 30%       | Review testing practices          |
| 🚫 Flow Disruption  | Flow score < 40 for 2 weeks     | Analyze friction logs             |
| 📅 No Activity      | 7+ days no commits              | Reminder to log manual work       |

---

## 🎯 Manager Report Integration

Each metric should feed the report:

**Executive Summary** (AI-generated from all data)

> "William delivered 67 commits across 8 features this quarter, maintaining elite-level deployment frequency (4x/week) and low change failure rate (6%). His collaboration score increased 40% through increased code reviews and mentoring, while his flow score of 78/100 indicates strong focus and minimal blockers."

**Metrics Snapshot**

```
DORA Metrics:
✅ Deployment Frequency: 4x/week (Elite)
✅ Lead Time: 1.2 days median (Elite)
✅ Change Failure Rate: 6% (Elite)
✅ MTTR: 1.8 hours (Elite)

SPACE Metrics:
😊 Satisfaction: 7.8/10
📈 Performance: 92/100 quality score
📅 Activity: 87% active days
🤝 Collaboration: 31 code reviews, 2 design docs
⚡ Efficiency: 78/100 flow score

Business Impact: 234 points (High)
Growth: +3 new technology areas
```

---

## 🔄 Next Steps for Implementation

1. ✅ **Sprint 1**: Friction Tracker & Manual Entries - **COMPLETO**
   - Friction logs disponíveis para MTTR e análise de blockers
   - Manual entries disponíveis para métricas de Collaboration
2. ✅ **Sprint 2**: Manager Report Generator - **COMPLETO**
   - Integrar friction logs e manual entries nos relatórios
3. ✅ **Sprint 3**: DORA & SPACE Metrics - **COMPLETO**
   - Todas as 4 métricas DORA implementadas (Deployment Frequency, Lead Time, Change Failure Rate, MTTR)
   - Todas as 5 dimensões SPACE implementadas (Satisfaction, Performance, Activity, Collaboration, Efficiency)
   - Dashboards criados para visualização
   - Métricas integradas nos Manager Reports
4. ✅ **Sprint 4**: Multi-Repo Aggregation & Data Quality - **COMPLETO**
   - ✅ Agregar métricas entre múltiplos repositórios
   - ✅ Cross-repo impact detection
   - ✅ Validação de qualidade de dados
   - ✅ Dashboards de completude
   - ✅ Sistema de tags e filtros por team
   - ✅ Backup automático e export/import

**Status Atual**: ✅ Todas as métricas DORA e SPACE implementadas e funcionais
✅ Multi-repo aggregation e data quality implementados

**Próximo**: Advanced analytics e career moments tracking.
