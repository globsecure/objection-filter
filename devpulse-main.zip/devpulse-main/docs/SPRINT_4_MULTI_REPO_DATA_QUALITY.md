# 🚀 Sprint 4 - Multi-Repo Aggregation & Data Quality

**Goal**: Enable multi-repository support with tags/labels, cross-repo metrics aggregation, and comprehensive data quality validation.

**Timeline**: 2-3 weeks

**Status**: ✅ **COMPLETE**

**Success Criteria**: 
- Support for scanning and managing multiple repositories
- Repository tagging system (frontend, backend, infra, etc.)
- Cross-repo metrics aggregation and filtering
- Data quality validation and completeness dashboards
- Automated backup and data export/import capabilities

---

## 📋 Overview

Sprint 4 focuses on two main areas:

1. **Multi-Repo Aggregation**: Enable working with multiple repositories simultaneously, tag them by type/team, aggregate metrics across repos, and detect cross-repo impacts.

2. **Data Quality & Validation**: Ensure data integrity, validate git history, score commit message quality, track data completeness, and provide backup/export capabilities.

**Key Features**:
- Multi-repo scanning and management
- Repository tags/labels system
- Cross-repo metrics aggregation
- Repository filtering in dashboards
- Git history validation
- Commit message quality scoring
- Data completeness tracking
- Automated backups
- Data export/import

---

## 📋 Tasks Breakdown

### Task Group 1: Multi-Repo Aggregation (5-6 days)

#### Day 1-2: Repository Tags/Labels System

**File**: `backend/app/models.py`, `backend/app/schemas.py`

**Status**: ⏳ To be implemented

Add tags/labels support to Repository model:

```python
# Migration: Add tags column to repositories table
class Repository(Base):
    __tablename__ = "repositories"
    
    id = Column(Integer, primary_key=True, index=True)
    path = Column(String, unique=True, index=True)
    name = Column(String, index=True)
    tags = Column(String)  # Comma-separated tags: "frontend,paypal,team-a"
    team = Column(String, index=True)  # Optional: team/squad name
    last_scanned = Column(DateTime(timezone=True), server_default=func.now())
    
    commits = relationship("Commit", back_populates="repository")
    branch_metrics = relationship("BranchMetric", back_populates="repository")
```

**API Endpoints** (`backend/app/api/repositories.py`):

```python
@router.patch("/repositories/{repo_id}/tags")
def update_repository_tags(
    repo_id: int,
    tags: List[str],
    db: Session = Depends(get_db)
):
    """Update repository tags."""
    repo = db.query(Repository).filter(Repository.id == repo_id).first()
    if not repo:
        raise HTTPException(status_code=404, detail="Repository not found")
    repo.tags = ','.join(tags)
    db.commit()
    return {"id": repo.id, "tags": tags}

@router.get("/repositories")
def list_repositories(
    tags: Optional[str] = Query(None),  # Comma-separated tags filter
    team: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """List repositories with optional filtering."""
    query = db.query(Repository)
    if tags:
        tag_list = [t.strip() for t in tags.split(',')]
        # Filter repositories that have any of the specified tags
        for tag in tag_list:
            query = query.filter(Repository.tags.contains(tag))
    if team:
        query = query.filter(Repository.team == team)
    return query.all()
```

---

#### Day 3: Enhanced Multi-Repo Scanning

**File**: `backend/app/api/commits.py`, `backend/app/crawler/git_crawler.py`

**Status**: ⏳ To be enhanced

Enhance scanning to support:
- Batch scanning of multiple directories
- Tagging during scan (auto-detect from path/name)
- Progress tracking for large scans
- Error handling per repository

```python
@router.post("/crawl")
def crawl_repositories(
    request: CrawlRequest,
    db: Session = Depends(get_db)
):
    """
    Scan directory for git repositories and extract commits.
    Enhanced to support multiple repos with tags.
    """
    directory = request.directory or settings.projects_dir
    auto_tags = request.auto_tags or True  # Auto-detect tags from path
    
    repositories = scan_directory(directory)
    results = []
    
    for repo_info in repositories:
        try:
            # Auto-detect tags from path/name
            detected_tags = _detect_repository_tags(repo_info['path'], repo_info['name']) if auto_tags else []
            
            db_repo = db.query(Repository).filter(Repository.path == repo_info['path']).first()
            
            if not db_repo:
                db_repo = Repository(
                    path=repo_info['path'],
                    name=repo_info['name'],
                    tags=','.join(detected_tags) if detected_tags else None
                )
                db.add(db_repo)
                db.commit()
                db.refresh(db_repo)
            else:
                # Update tags if not set
                if not db_repo.tags and detected_tags:
                    db_repo.tags = ','.join(detected_tags)
                    db.commit()
            
            # Extract commits and branch metrics (existing logic)
            # ...
            
            results.append({
                'repo_id': db_repo.id,
                'name': db_repo.name,
                'tags': db_repo.tags.split(',') if db_repo.tags else [],
                'commits_added': commits_count,
                'status': 'success'
            })
        except Exception as e:
            results.append({
                'repo_id': None,
                'name': repo_info['name'],
                'status': 'error',
                'error': str(e)
            })
    
    return {
        "repositories_found": len(repositories),
        "results": results
    }

def _detect_repository_tags(path: str, name: str) -> List[str]:
    """Auto-detect repository tags from path and name."""
    tags = []
    path_lower = path.lower()
    name_lower = name.lower()
    
    # Technology tags
    if any(x in path_lower or x in name_lower for x in ['frontend', 'ui', 'web', 'react', 'vue', 'angular']):
        tags.append('frontend')
    if any(x in path_lower or x in name_lower for x in ['backend', 'api', 'server', 'service']):
        tags.append('backend')
    if any(x in path_lower or x in name_lower for x in ['infra', 'infrastructure', 'terraform', 'k8s', 'kubernetes']):
        tags.append('infra')
    if any(x in path_lower or x in name_lower for x in ['mobile', 'ios', 'android', 'react-native']):
        tags.append('mobile')
    
    # Organization tags (customize for your org)
    if 'paypal' in path_lower or 'paypal' in name_lower:
        tags.append('paypal')
    
    return tags
```

---

#### Day 4: Cross-Repo Metrics Aggregation

**File**: `backend/app/analysis/aggregation.py` (new file)

**Status**: ⏳ To be implemented

Create aggregation service for cross-repo metrics:

```python
from sqlalchemy.orm import Session
from typing import List, Dict, Optional
from datetime import datetime
from ..models import Commit, Repository
from .dora_metrics import get_dora_metrics
from .space_metrics import get_space_metrics

def aggregate_dora_metrics(
    db: Session,
    repo_ids: Optional[List[int]] = None,
    tags: Optional[List[str]] = None,
    team: Optional[str] = None,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None
) -> Dict:
    """
    Aggregate DORA metrics across multiple repositories.
    """
    # Get repositories based on filters
    repos = _get_filtered_repositories(db, repo_ids, tags, team)
    
    if not repos:
        return {
            'repositories': [],
            'aggregated': None,
            'per_repo': []
        }
    
    per_repo_metrics = []
    total_deployments = 0
    total_lead_times = []
    total_failures = 0
    total_mttr_times = []
    
    for repo in repos:
        metrics = get_dora_metrics(db, start_date, end_date, repo.id)
        per_repo_metrics.append({
            'repo_id': repo.id,
            'repo_name': repo.name,
            'metrics': metrics
        })
        
        # Aggregate values
        df = metrics.get('deployment_frequency', {})
        lt = metrics.get('lead_time', {})
        cfr = metrics.get('change_failure_rate', {})
        mttr = metrics.get('mttr', {})
        
        total_deployments += df.get('total_deployments', 0)
        if lt.get('average_days'):
            total_lead_times.append(lt['average_days'])
        total_failures += cfr.get('failed_deployments', 0)
        if mttr.get('mean_hours'):
            total_mttr_times.append(mttr['mean_hours'])
    
    # Calculate aggregated metrics
    aggregated = {
        'deployment_frequency': {
            'total_deployments': total_deployments,
            'frequency_per_week': sum(m['metrics']['deployment_frequency'].get('frequency_per_week', 0) for m in per_repo_metrics) / len(per_repo_metrics) if per_repo_metrics else 0
        },
        'lead_time': {
            'average_days': sum(total_lead_times) / len(total_lead_times) if total_lead_times else 0,
            'median_days': statistics.median(total_lead_times) if total_lead_times else 0
        },
        'change_failure_rate': {
            'failure_rate': (total_failures / total_deployments * 100) if total_deployments > 0 else 0,
            'total_deployments': total_deployments,
            'failed_deployments': total_failures
        },
        'mttr': {
            'mean_hours': sum(total_mttr_times) / len(total_mttr_times) if total_mttr_times else 0,
            'median_hours': statistics.median(total_mttr_times) if total_mttr_times else 0
        }
    }
    
    return {
        'repositories': [{'id': r.id, 'name': r.name} for r in repos],
        'aggregated': aggregated,
        'per_repo': per_repo_metrics
    }

def aggregate_space_metrics(
    db: Session,
    repo_ids: Optional[List[int]] = None,
    tags: Optional[List[str]] = None,
    team: Optional[str] = None,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None
) -> Dict:
    """
    Aggregate SPACE metrics across multiple repositories.
    """
    repos = _get_filtered_repositories(db, repo_ids, tags, team)
    
    if not repos:
        return {
            'repositories': [],
            'aggregated': None,
            'per_repo': []
        }
    
    per_repo_metrics = []
    satisfaction_scores = []
    performance_scores = []
    activity_scores = []
    collaboration_scores = []
    efficiency_scores = []
    
    for repo in repos:
        metrics = get_space_metrics(db, start_date, end_date, repo.id)
        per_repo_metrics.append({
            'repo_id': repo.id,
            'repo_name': repo.name,
            'metrics': metrics
        })
        
        sat = metrics.get('satisfaction', {})
        perf = metrics.get('performance', {})
        act = metrics.get('activity', {})
        collab = metrics.get('collaboration', {})
        eff = metrics.get('efficiency', {})
        
        if sat.get('average_satisfaction'):
            satisfaction_scores.append(sat['average_satisfaction'] * 10)
        if perf.get('quality_score'):
            performance_scores.append(perf['quality_score'])
        if act.get('consistency_score'):
            activity_scores.append(act['consistency_score'] * 100)
        if collab.get('collaboration_score'):
            collaboration_scores.append(collab['collaboration_score'])
        if eff.get('score'):
            efficiency_scores.append(eff['score'])
    
    aggregated = {
        'satisfaction': statistics.mean(satisfaction_scores) if satisfaction_scores else 0,
        'performance': statistics.mean(performance_scores) if performance_scores else 0,
        'activity': statistics.mean(activity_scores) if activity_scores else 0,
        'collaboration': statistics.mean(collaboration_scores) if collaboration_scores else 0,
        'efficiency': statistics.mean(efficiency_scores) if efficiency_scores else 0
    }
    
    return {
        'repositories': [{'id': r.id, 'name': r.name} for r in repos],
        'aggregated': aggregated,
        'per_repo': per_repo_metrics
    }

def _get_filtered_repositories(
    db: Session,
    repo_ids: Optional[List[int]] = None,
    tags: Optional[List[str]] = None,
    team: Optional[str] = None
) -> List[Repository]:
    """Get repositories based on filters."""
    query = db.query(Repository)
    
    if repo_ids:
        query = query.filter(Repository.id.in_(repo_ids))
    if tags:
        for tag in tags:
            query = query.filter(Repository.tags.contains(tag))
    if team:
        query = query.filter(Repository.team == team)
    
    return query.all()
```

---

#### Day 5: Cross-Repo Impact Detection

**File**: `backend/app/analysis/cross_repo_analyzer.py` (new file)

**Status**: ⏳ To be implemented

Detect cross-repo impacts (shared libraries, dependencies):

```python
from sqlalchemy.orm import Session
from typing import List, Dict
from ..models import Commit, Repository
import re

def detect_cross_repo_impacts(
    db: Session,
    repo_id: int,
    other_repos: Optional[List[int]] = None
) -> Dict:
    """
    Detect commits that might impact other repositories.
    Looks for:
    - Shared library references
    - Dependency updates
    - API changes
    - Common file patterns
    """
    repo = db.query(Repository).filter(Repository.id == repo_id).first()
    if not repo:
        return {'impacts': []}
    
    commits = db.query(Commit).filter(Commit.repo_id == repo_id).all()
    
    # Patterns that suggest cross-repo impact
    impact_patterns = [
        r'shared[_-]?lib',
        r'common[_-]?lib',
        r'@paypal/',
        r'package\.json',
        r'requirements\.txt',
        r'pom\.xml',
        r'api[_-]?v\d+',
        r'breaking[_-]?change',
        r'deprecat'
    ]
    
    impact_commits = []
    for commit in commits:
        message_lower = commit.message.lower()
        files_changed = commit.files_changed
        
        # Check commit message
        matches = []
        for pattern in impact_patterns:
            if re.search(pattern, message_lower):
                matches.append(pattern)
        
        # High file count might indicate library changes
        is_library_change = files_changed > 20 and any(x in message_lower for x in ['lib', 'package', 'dependency'])
        
        if matches or is_library_change:
            impact_commits.append({
                'commit_id': commit.id,
                'hash': commit.hash,
                'message': commit.message[:100],
                'date': commit.date.isoformat(),
                'impact_indicators': matches,
                'files_changed': files_changed,
                'potential_impact': 'high' if len(matches) > 2 or is_library_change else 'medium'
            })
    
    return {
        'repo_id': repo_id,
        'repo_name': repo.name,
        'total_commits_analyzed': len(commits),
        'impact_commits': impact_commits,
        'impact_count': len(impact_commits)
    }
```

---

#### Day 6: Dashboard Filtering & UI Updates

**File**: `frontend/src/components/DoraDashboard.tsx`, `frontend/src/components/SpaceDashboard.tsx`

**Status**: ⏳ To be enhanced

Add repository filtering to dashboards:

```typescript
interface DashboardProps {
  startDate?: string
  endDate?: string
  repoId?: number
  repoIds?: number[]  // Multiple repos
  tags?: string[]     // Filter by tags
  team?: string       // Filter by team
}

// Update DoraDashboard and SpaceDashboard to support:
// - Multi-select repository dropdown
// - Tag-based filtering
// - Team-based filtering
// - Aggregated vs per-repo view toggle
```

---

### Task Group 2: Data Quality & Validation (4-5 days)

#### Day 7: Git History Validation

**File**: `backend/app/validation/git_validator.py` (new file)

**Status**: ⏳ To be implemented

Validate git repositories for corruption and issues:

```python
from git import Repo, InvalidGitRepositoryError, GitCommandError
from typing import Dict, List
from pathlib import Path

def validate_repository(repo_path: str) -> Dict:
    """
    Validate git repository for corruption and issues.
    """
    issues = []
    warnings = []
    
    try:
        repo = Repo(repo_path)
        
        # Check if repository is bare
        if repo.bare:
            warnings.append("Repository is bare (no working directory)")
        
        # Check for corruption
        try:
            repo.git.fsck('--full', '--strict')
        except GitCommandError as e:
            if 'corrupt' in str(e).lower() or 'error' in str(e).lower():
                issues.append(f"Repository corruption detected: {str(e)}")
        
        # Check for missing objects
        try:
            missing = repo.git.fsck('--unreachable', '--no-full')
            if missing:
                warnings.append("Unreachable objects found (may indicate issues)")
        except:
            pass
        
        # Check repository size
        repo_size = sum(f.stat().st_size for f in Path(repo_path).rglob('*') if f.is_file())
        if repo_size > 1_000_000_000:  # > 1GB
            warnings.append(f"Large repository size: {repo_size / 1_000_000_000:.2f} GB")
        
        # Check for empty repository
        try:
            commits = list(repo.iter_commits(max_count=1))
            if not commits:
                warnings.append("Repository has no commits")
        except:
            warnings.append("Could not read commits")
        
        return {
            'repo_path': repo_path,
            'valid': len(issues) == 0,
            'issues': issues,
            'warnings': warnings,
            'status': 'corrupt' if issues else 'warning' if warnings else 'healthy'
        }
    
    except InvalidGitRepositoryError:
        return {
            'repo_path': repo_path,
            'valid': False,
            'issues': ['Not a valid git repository'],
            'warnings': [],
            'status': 'invalid'
        }
    except Exception as e:
        return {
            'repo_path': repo_path,
            'valid': False,
            'issues': [f"Error validating repository: {str(e)}"],
            'warnings': [],
            'status': 'error'
        }
```

---

#### Day 8: Commit Message Quality Scoring

**File**: `backend/app/analysis/commit_quality.py` (new file)

**Status**: ⏳ To be implemented

Score commit message quality:

```python
from typing import Dict
import re

def score_commit_message(message: str) -> Dict:
    """
    Score commit message quality (0-100).
    
    Penalties:
    - Generic words without context: "wip", "fix", "update" (-10 each)
    - Very short messages (< 10 chars): -20
    - No capital letter at start: -5
    - All caps: -10
    
    Bonuses:
    - Conventional commits format: +20
    - Includes issue/ticket reference: +10
    - Descriptive (> 50 chars): +10
    - Multiple sentences: +5
    """
    score = 100.0
    message_lower = message.lower().strip()
    issues = []
    positives = []
    
    # Penalties
    generic_words = ['wip', 'fix', 'update', 'change', 'stuff', 'things']
    generic_count = sum(1 for word in generic_words if word in message_lower)
    if generic_count > 0 and len(message.split()) < 5:
        penalty = min(generic_count * 10, 30)
        score -= penalty
        issues.append(f"Generic words without context: -{penalty}")
    
    if len(message) < 10:
        score -= 20
        issues.append("Very short message: -20")
    
    if message and not message[0].isupper():
        score -= 5
        issues.append("No capital letter at start: -5")
    
    if message.isupper() and len(message) > 5:
        score -= 10
        issues.append("All caps: -10")
    
    # Bonuses
    # Conventional commits: type(scope): description
    conventional_pattern = r'^(feat|fix|docs|style|refactor|test|chore)(\(.+\))?:'
    if re.match(conventional_pattern, message):
        score += 20
        positives.append("Conventional commits format: +20")
    
    # Issue reference
    if re.search(r'#[0-9]+|\[[A-Z]+-[0-9]+\]', message):
        score += 10
        positives.append("Includes issue reference: +10")
    
    if len(message) > 50:
        score += 10
        positives.append("Descriptive message: +10")
    
    if message.count('.') > 1 or message.count('!') > 1:
        score += 5
        positives.append("Multiple sentences: +5")
    
    score = max(0, min(100, score))
    
    return {
        'score': round(score, 1),
        'grade': _get_grade(score),
        'issues': issues,
        'positives': positives,
        'message_length': len(message)
    }

def _get_grade(score: float) -> str:
    """Convert score to letter grade."""
    if score >= 90:
        return 'A'
    elif score >= 80:
        return 'B'
    elif score >= 70:
        return 'C'
    elif score >= 60:
        return 'D'
    else:
        return 'F'
```

---

#### Day 9: Data Completeness Dashboard

**File**: `backend/app/analysis/data_quality.py` (new file), `frontend/src/components/DataQualityDashboard.tsx` (new file)

**Status**: ⏳ To be implemented

Track and display data completeness:

```python
from sqlalchemy.orm import Session
from typing import Dict, List
from ..models import Commit, FrictionLog, ManualEntry, Repository
from sqlalchemy import func

def calculate_data_completeness(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """
    Calculate data completeness metrics.
    """
    commit_query = db.query(Commit)
    if repo_id:
        commit_query = commit_query.filter(Commit.repo_id == repo_id)
    if start_date:
        commit_query = commit_query.filter(Commit.date >= start_date)
    if end_date:
        commit_query = commit_query.filter(Commit.date <= end_date)
    
    commits = commit_query.all()
    
    total_commits = len(commits)
    commits_without_type = len([c for c in commits if not c.type or c.type == 'Unknown'])
    commits_without_category = len([c for c in commits if not c.impact_category or c.impact_category == 'Unknown'])
    commits_without_branch = len([c for c in commits if not c.branch_name])
    
    # Friction logs without resolution
    friction_query = db.query(FrictionLog).filter(FrictionLog.type == 'incident')
    if start_date:
        friction_query = friction_query.filter(FrictionLog.date >= start_date)
    if end_date:
        friction_query = friction_query.filter(FrictionLog.date <= end_date)
    incidents = friction_query.all()
    incidents_without_resolution = len([i for i in incidents if not i.resolution])
    
    # Manual entries without impact
    manual_query = db.query(ManualEntry)
    if start_date:
        manual_query = manual_query.filter(ManualEntry.date >= start_date)
    if end_date:
        manual_query = manual_query.filter(ManualEntry.date <= end_date)
    manual_entries = manual_query.all()
    entries_without_impact = len([e for e in manual_entries if not e.impact])
    
    completeness_score = 100.0
    completeness_score -= (commits_without_type / total_commits * 30) if total_commits > 0 else 0
    completeness_score -= (commits_without_category / total_commits * 20) if total_commits > 0 else 0
    completeness_score -= (incidents_without_resolution / len(incidents) * 25) if incidents else 0
    completeness_score -= (entries_without_impact / len(manual_entries) * 25) if manual_entries else 0
    completeness_score = max(0, completeness_score)
    
    return {
        'completeness_score': round(completeness_score, 1),
        'commits': {
            'total': total_commits,
            'without_type': commits_without_type,
            'without_category': commits_without_category,
            'without_branch': commits_without_branch,
            'completeness': round((1 - commits_without_type / total_commits) * 100, 1) if total_commits > 0 else 0
        },
        'incidents': {
            'total': len(incidents),
            'without_resolution': incidents_without_resolution,
            'completeness': round((1 - incidents_without_resolution / len(incidents)) * 100, 1) if incidents else 100
        },
        'manual_entries': {
            'total': len(manual_entries),
            'without_impact': entries_without_impact,
            'completeness': round((1 - entries_without_impact / len(manual_entries)) * 100, 1) if manual_entries else 100
        },
        'recommendations': _generate_recommendations(
            commits_without_type,
            commits_without_category,
            incidents_without_resolution,
            entries_without_impact
        )
    }

def _generate_recommendations(*args) -> List[str]:
    """Generate recommendations based on data completeness issues."""
    recommendations = []
    commits_without_type, commits_without_category, incidents_without_resolution, entries_without_impact = args
    
    if commits_without_type > 0:
        recommendations.append(f"Review {commits_without_type} commits without type classification")
    if commits_without_category > 0:
        recommendations.append(f"Review {commits_without_category} commits without impact category")
    if incidents_without_resolution > 0:
        recommendations.append(f"Add resolution to {incidents_without_resolution} unresolved incidents")
    if entries_without_impact > 0:
        recommendations.append(f"Add impact description to {entries_without_impact} manual entries")
    
    return recommendations
```

---

#### Day 10: Automated Backup System

**File**: `backend/app/services/backup_service.py` (new file)

**Status**: ⏳ To be implemented

Implement automated SQLite backup:

```python
import shutil
from pathlib import Path
from datetime import datetime
from typing import Optional
import sqlite3

def backup_database(
    db_path: str,
    backup_dir: Optional[str] = None,
    keep_backups: int = 7
) -> Dict:
    """
    Create a backup of the SQLite database.
    """
    db_path_obj = Path(db_path)
    if not db_path_obj.exists():
        return {'success': False, 'error': 'Database file not found'}
    
    if backup_dir is None:
        backup_dir = db_path_obj.parent / 'backups'
    else:
        backup_dir = Path(backup_dir)
    
    backup_dir.mkdir(parents=True, exist_ok=True)
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_filename = f"devpulse_backup_{timestamp}.db"
    backup_path = backup_dir / backup_filename
    
    try:
        # Use SQLite backup API for safe backup
        source = sqlite3.connect(db_path)
        backup = sqlite3.connect(backup_path)
        source.backup(backup)
        backup.close()
        source.close()
        
        # Clean up old backups
        backups = sorted(backup_dir.glob('devpulse_backup_*.db'), key=lambda p: p.stat().st_mtime, reverse=True)
        for old_backup in backups[keep_backups:]:
            old_backup.unlink()
        
        return {
            'success': True,
            'backup_path': str(backup_path),
            'backup_size': backup_path.stat().st_size,
            'timestamp': timestamp
        }
    except Exception as e:
        return {
            'success': False,
            'error': str(e)
        }
```

---

#### Day 11: Data Export/Import

**File**: `backend/app/api/data_export.py` (new file)

**Status**: ⏳ To be implemented

Implement data export/import functionality:

```python
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
import json
from datetime import datetime

router = APIRouter()

@router.get("/export")
def export_data(
    format: str = "json",  # json, csv
    include_commits: bool = True,
    include_friction_logs: bool = True,
    include_manual_entries: bool = True,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    db: Session = Depends(get_db)
):
    """
    Export data for migration or backup.
    """
    data = {}
    
    if include_commits:
        commits = db.query(Commit).all()
        data['commits'] = [
            {
                'hash': c.hash,
                'message': c.message,
                'author': c.author,
                'date': c.date.isoformat(),
                'repo_id': c.repo_id,
                # ... other fields
            }
            for c in commits
        ]
    
    if include_friction_logs:
        logs = db.query(FrictionLog).all()
        data['friction_logs'] = [
            {
                'date': log.date.isoformat(),
                'type': log.type,
                'description': log.description,
                # ... other fields
            }
            for log in logs
        ]
    
    if include_manual_entries:
        entries = db.query(ManualEntry).all()
        data['manual_entries'] = [
            {
                'date': entry.date.isoformat(),
                'type': entry.type,
                'title': entry.title,
                # ... other fields
            }
            for entry in entries
        ]
    
    if format == "json":
        return {
            'format': 'json',
            'exported_at': datetime.now().isoformat(),
            'data': data
        }
    elif format == "csv":
        # Convert to CSV format
        # ...
        pass

@router.post("/import")
def import_data(
    data: Dict,
    db: Session = Depends(get_db)
):
    """
    Import data from export.
    """
    # Validate and import data
    # ...
    pass
```

---

## 🎯 Testing Your Implementation

### Manual Test Plan

1. **Multi-Repo Test**:
```bash
# Scan multiple repositories
curl -X POST "http://localhost:8000/api/commits/crawl" \
  -H "Content-Type: application/json" \
  -d '{"directory": "/path/to/projects", "months_back": 3}'

# Get repositories with tags
curl -X GET "http://localhost:8000/api/repositories?tags=frontend,backend"

# Aggregate metrics across repos
curl -X GET "http://localhost:8000/api/aggregate/dora?tags=frontend&start_date=2024-10-01&end_date=2024-12-31"
```

2. **Data Quality Test**:
```bash
# Validate repository
curl -X GET "http://localhost:8000/api/validation/repository?repo_path=/path/to/repo"

# Get data completeness
curl -X GET "http://localhost:8000/api/quality/completeness?start_date=2024-10-01&end_date=2024-12-31"

# Score commit message
curl -X POST "http://localhost:8000/api/quality/commit-score" \
  -H "Content-Type: application/json" \
  -d '{"message": "feat(api): add user authentication"}'
```

3. **Backup Test**:
```bash
# Create backup
curl -X POST "http://localhost:8000/api/backup/create"

# Export data
curl -X GET "http://localhost:8000/api/export?format=json"
```

---

## 📊 Success Metrics for Sprint 4

After completing Sprint 4, you should be able to:

✅ **Multi-Repo Support**:
- Scan and manage multiple repositories
- Tag repositories by type/team
- Filter metrics by tags/team
- View aggregated metrics across repos
- Detect cross-repo impacts

✅ **Data Quality**:
- Validate git repositories for corruption
- Score commit message quality
- Track data completeness
- Automated backups
- Export/import data for migration

✅ **User Experience**:
- Easy repository management UI
- Tag-based filtering in dashboards
- Data quality dashboard showing gaps
- Confidence in data accuracy

---

## 🚀 After Sprint 4: What's Next?

With multi-repo and data quality complete, you unlock:

1. **Sprint 5**: Advanced Analytics
   - Predictive metrics
   - Anomaly detection
   - Trend forecasting

2. **Career Moments Integration**:
   - Link moments to metrics
   - Storytelling with data

3. **Goals & OKRs**:
   - Track progress against goals
   - Metrics-driven OKRs

---

## 💡 Pro Tips

1. **Start with tags**: Implement tagging system first - it enables everything else
2. **Incremental aggregation**: Start with simple aggregation, enhance later
3. **Validation early**: Add validation during scan to catch issues early
4. **Backup regularly**: Set up automated backups from day one
5. **Quality dashboard**: Make data quality visible - users will improve it

---

## 🆘 Common Issues

### Issue: "Tags not saving"

**Solution**: Check database migration ran correctly. Verify tags column exists.

### Issue: "Aggregation too slow"

**Solution**: Add caching for aggregated metrics. Consider background jobs for large datasets.

### Issue: "Backup fails"

**Solution**: Check disk space and permissions. Verify SQLite backup API works.

### Issue: "Cross-repo detection too noisy"

**Solution**: Tune impact patterns. Add confidence scores. Allow user filtering.

---

## 🎉 Sprint 4 Complete!

**Status**: ⏳ Ready to implement

### Next Steps

1. **Start with Day 1**: Repository tags system
2. **Then Day 2**: Enhanced scanning
3. **Continue**: Through all task groups
4. **Test**: Each feature independently before integration

**Ready to start? Begin with `multi-001` - Repository Tags System. It's the foundation for everything else!**

