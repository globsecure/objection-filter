# 🚀 Sprint 2 - Manager Report Generator

**Goal**: Generate professional performance reports that tell your story with data + context.

**Timeline**: 1-2 weeks

**Status**: ✅ **COMPLETE**

**Success Criteria**: Generate a complete manager-ready report in < 2 minutes that requires zero manual editing.

---

## 📋 Overview

Sprint 2 builds on Sprint 1's data collection (commits + friction logs + manual entries) to generate comprehensive performance reports. The report generator uses AI to create narrative summaries while maintaining factual accuracy from your data.

**Key Features**:
- Executive Summary (AI-generated from all data sources)
- Key Achievements (categorized by impact)
- Challenges & Growth (from friction logs)
- Collaboration Highlights (from manual entries)
- Metrics Snapshot (DORA + SPACE)
- Export to Markdown, PDF, JSON

**Sprint 9 Enhancements**:
- Context enrichment: Reports now include user role, team, business domain, and quarter goals in AI prompts
- Template customization: Support for different report templates (1:1 meetings vs performance reviews)
- Human-in-the-loop editing: Edit AI-generated sections before export
- Multi-language support: Generate reports in English or Portuguese

---

## 📋 Tasks Breakdown

### Task Group 1: Enhanced Report Structure (2-3 days)

#### Day 1: Report Data Aggregation ✅

**File**: `backend/app/services/report_generator.py`

**Status**: ✅ **COMPLETE** - Implemented `aggregate_report_data()` function

Create function to aggregate all data sources:

```python
from datetime import datetime
from typing import Dict, List, Optional
from sqlalchemy.orm import Session
from ..models import Commit, FrictionLog, ManualEntry

def aggregate_report_data(
    db: Session,
    start_date: datetime,
    end_date: datetime,
    repo_id: Optional[int] = None
) -> Dict:
    """
    Aggregate commits, friction logs, and manual entries for report generation.
    """
    # Commits
    commit_query = db.query(Commit).filter(
        Commit.date >= start_date,
        Commit.date <= end_date
    )
    if repo_id:
        commit_query = commit_query.filter(Commit.repo_id == repo_id)
    commits = commit_query.order_by(Commit.date.desc()).all()
    
    # Friction Logs
    friction_query = db.query(FrictionLog).filter(
        FrictionLog.date >= start_date,
        FrictionLog.date <= end_date
    )
    friction_logs = friction_query.order_by(FrictionLog.date.desc()).all()
    
    # Manual Entries
    manual_query = db.query(ManualEntry).filter(
        ManualEntry.date >= start_date,
        ManualEntry.date <= end_date
    )
    manual_entries = manual_query.order_by(ManualEntry.date.desc()).all()
    
    # Calculate basic stats
    commits_by_type = {}
    for commit in commits:
        commit_type = commit.type or 'Unknown'
        commits_by_type[commit_type] = commits_by_type.get(commit_type, 0) + 1
    
    friction_by_type = {}
    for friction in friction_logs:
        friction_type = friction.type
        friction_by_type[friction_type] = friction_by_type.get(friction_type, 0) + 1
    
    manual_by_type = {}
    for entry in manual_entries:
        entry_type = entry.type
        manual_by_type[entry_type] = manual_by_type.get(entry_type, 0) + 1
    
    return {
        'commits': commits,
        'friction_logs': friction_logs,
        'manual_entries': manual_entries,
        'stats': {
            'total_commits': len(commits),
            'commits_by_type': commits_by_type,
            'total_friction_logs': len(friction_logs),
            'friction_by_type': friction_by_type,
            'total_manual_entries': len(manual_entries),
            'manual_by_type': manual_by_type,
            'date_range': {
                'start': start_date.isoformat(),
                'end': end_date.isoformat()
            }
        }
    }
```

---

#### Day 2: Enhanced LLM Prompts ✅

**File**: `backend/app/analysis/llm_service.py`

**Status**: ✅ **COMPLETE** - Added `generate_executive_summary()`, `generate_challenges_section()`, and `generate_collaboration_section()` methods

Add new methods for report generation:

```python
def generate_executive_summary(
    self,
    commits: List[Commit],
    friction_logs: List[FrictionLog],
    manual_entries: List[ManualEntry],
    start_date: datetime,
    end_date: datetime
) -> str:
    """
    Generate executive summary combining all data sources.
    """
    # Format commits
    commit_texts = []
    for commit in commits[:50]:
        commit_texts.append(f"- {commit.type or 'Unknown'}: {commit.message[:100]}")
    
    # Format friction logs
    friction_texts = []
    for friction in friction_logs[:20]:
        friction_texts.append(
            f"- [{friction.type}] {friction.description[:80]} "
            f"(Impact: {friction.impact_level}/5)"
        )
    
    # Format manual entries
    manual_texts = []
    for entry in manual_entries[:20]:
        manual_texts.append(
            f"- [{entry.type}] {entry.title}: {entry.description[:80] if entry.description else 'N/A'}"
        )
    
    prompt = f"""Generate an executive summary for a performance review covering the period {start_date.strftime('%B %d, %Y')} to {end_date.strftime('%B %d, %Y')}.

Technical Work (Commits):
{chr(10).join(commit_texts[:30])}

Challenges & Growth (Friction Logs):
{chr(10).join(friction_texts[:15])}

Collaboration & Invisible Work (Manual Entries):
{chr(10).join(manual_texts[:15])}

Generate a 3-4 sentence executive summary that:
1. Highlights overall impact and achievements
2. Mentions key challenges overcome
3. Notes collaboration contributions
4. Uses professional, manager-friendly language

Focus on business value and outcomes, not technical details."""

    # Implementation continues with LLM call...
```

```python
def generate_challenges_section(
    self,
    friction_logs: List[FrictionLog]
) -> str:
    """
    Generate "Challenges & Growth" section from friction logs.
    """
    blockers = [f for f in friction_logs if f.type == 'blocker']
    incidents = [f for f in friction_logs if f.type == 'incident']
    learnings = [f for f in friction_logs if f.type == 'learning']
    
    friction_texts = []
    for friction in blockers + incidents + learnings[:15]:
        resolution_text = f" → Resolved: {friction.resolution}" if friction.resolution else ""
        friction_texts.append(
            f"- [{friction.type.upper()}] {friction.description[:100]} "
            f"(Impact: {friction.impact_level}/5){resolution_text}"
        )
    
    prompt = f"""Transform the following friction logs into a "Challenges & Growth" section for a performance review.

Friction Logs:
{chr(10).join(friction_texts)}

Generate 3-5 bullet points that:
1. Frame challenges as growth opportunities
2. Highlight problem-solving skills
3. Show how challenges were overcome
4. Emphasize learning and adaptation

Format: Professional, positive tone, focus on outcomes."""

    # Implementation continues...
```

```python
def generate_collaboration_section(
    self,
    manual_entries: List[ManualEntry]
) -> str:
    """
    Generate "Collaboration Highlights" section from manual entries.
    """
    code_reviews = [e for e in manual_entries if e.type == 'code_review']
    design_docs = [e for e in manual_entries if e.type == 'design_doc']
    mentoring = [e for e in manual_entries if e.type == 'mentoring']
    
    entry_texts = []
    for entry in code_reviews + design_docs + mentoring[:20]:
        collaborators_text = f" with {entry.collaborators}" if entry.collaborators else ""
        entry_texts.append(
            f"- [{entry.type}] {entry.title}{collaborators_text}: "
            f"{entry.description[:80] if entry.description else 'N/A'}"
        )
    
    prompt = f"""Transform the following collaboration activities into a "Collaboration Highlights" section.

Activities:
{chr(10).join(entry_texts)}

Generate 3-5 bullet points that:
1. Highlight teamwork and knowledge sharing
2. Show cross-functional contributions
3. Emphasize impact on team/org
4. Use specific examples with context

Format: Professional, emphasize collective impact."""

    # Implementation continues...
```

---

#### Day 3: Report Template Structure ✅

**File**: `backend/app/services/report_generator.py`

**Status**: ✅ **COMPLETE** - Created `ReportTemplate` class with `to_dict()` and `to_markdown()` methods

Create structured report template:

```python
from typing import Dict, List
from datetime import datetime

class ReportTemplate:
    """
    Structured report template with all sections.
    """
    
    def __init__(
        self,
        start_date: datetime,
        end_date: datetime,
        executive_summary: str,
        key_achievements: List[str],
        challenges_section: str,
        collaboration_section: str,
        metrics_snapshot: Dict,
        commits: List[Commit],
        friction_logs: List[FrictionLog],
        manual_entries: List[ManualEntry]
    ):
        self.start_date = start_date
        self.end_date = end_date
        self.executive_summary = executive_summary
        self.key_achievements = key_achievements
        self.challenges_section = challenges_section
        self.collaboration_section = collaboration_section
        self.metrics_snapshot = metrics_snapshot
        self.commits = commits
        self.friction_logs = friction_logs
        self.manual_entries = manual_entries
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON export."""
        return {
            'period': {
                'start': self.start_date.isoformat(),
                'end': self.end_date.isoformat()
            },
            'executive_summary': self.executive_summary,
            'key_achievements': self.key_achievements,
            'challenges_and_growth': self.challenges_section,
            'collaboration_highlights': self.collaboration_section,
            'metrics_snapshot': self.metrics_snapshot,
            'data_summary': {
                'total_commits': len(self.commits),
                'total_friction_logs': len(self.friction_logs),
                'total_manual_entries': len(self.manual_entries)
            }
        }
    
    def to_markdown(self) -> str:
        """Convert to Markdown format."""
        md = f"""# Performance Review Report

**Period**: {self.start_date.strftime('%B %d, %Y')} to {self.end_date.strftime('%B %d, %Y')}

---

## Executive Summary

{self.executive_summary}

---

## Key Achievements

{chr(10).join(f"- {achievement}" for achievement in self.key_achievements)}

---

## Challenges & Growth

{self.challenges_section}

---

## Collaboration Highlights

{self.collaboration_section}

---

## Metrics Snapshot

### DORA Metrics
- **Deployment Frequency**: {self.metrics_snapshot.get('dora', {}).get('deployment_frequency', 'N/A')}
- **Lead Time**: {self.metrics_snapshot.get('dora', {}).get('lead_time', 'N/A')}
- **Change Failure Rate**: {self.metrics_snapshot.get('dora', {}).get('change_failure_rate', 'N/A')}
- **MTTR**: {self.metrics_snapshot.get('dora', {}).get('mttr', 'N/A')}

### SPACE Metrics
- **Satisfaction**: {self.metrics_snapshot.get('space', {}).get('satisfaction', 'N/A')}
- **Performance**: {self.metrics_snapshot.get('space', {}).get('performance', 'N/A')}
- **Activity**: {self.metrics_snapshot.get('space', {}).get('activity', 'N/A')}
- **Collaboration**: {self.metrics_snapshot.get('space', {}).get('collaboration', 'N/A')}
- **Efficiency**: {self.metrics_snapshot.get('space', {}).get('efficiency', 'N/A')}

---

## Data Summary

- **Total Commits**: {len(self.commits)}
- **Friction Logs**: {len(self.friction_logs)}
- **Manual Entries**: {len(self.manual_entries)}

---
*Generated by DevPulse on {datetime.now().strftime('%B %d, %Y at %H:%M')}*
"""
        return md
```

---

### Task Group 2: Report Generation Service (2-3 days)

#### Day 4: Main Report Generator Function ✅

**File**: `backend/app/services/report_generator.py`

**Status**: ✅ **COMPLETE** - Implemented `generate_manager_report()` with LLM integration and fallback functions

Create main function that orchestrates report generation:

```python
from typing import Dict, Optional
from datetime import datetime
from sqlalchemy.orm import Session
from ..models import Commit, FrictionLog, ManualEntry
from ..analysis.llm_service import get_llm_provider
from ..analysis.dora_metrics import get_dora_metrics
from ..analysis.space_metrics import get_space_metrics

def generate_manager_report(
    db: Session,
    start_date: datetime,
    end_date: datetime,
    repo_id: Optional[int] = None,
    use_llm: bool = True
) -> ReportTemplate:
    """
    Generate complete manager report with all sections.
    """
    # Aggregate data
    data = aggregate_report_data(db, start_date, end_date, repo_id)
    
    commits = data['commits']
    friction_logs = data['friction_logs']
    manual_entries = data['manual_entries']
    
    # Get metrics
    try:
        dora_metrics = get_dora_metrics(db, start_date, end_date, repo_id)
    except Exception:
        dora_metrics = None
    
    try:
        space_metrics = get_space_metrics(db, start_date, end_date, repo_id)
    except Exception:
        space_metrics = None
    
    metrics_snapshot = {
        'dora': dora_metrics,
        'space': space_metrics
    }
    
    # Generate sections with LLM or fallback
    if use_llm:
        try:
            llm_provider = get_llm_provider()
            
            executive_summary = llm_provider.generate_executive_summary(
                commits, friction_logs, manual_entries, start_date, end_date
            )
            
            challenges_section = llm_provider.generate_challenges_section(friction_logs)
            
            collaboration_section = llm_provider.generate_collaboration_section(manual_entries)
            
            # Key achievements from commits (existing method)
            key_achievements_text = llm_provider.summarize_commits(commits, start_date, end_date)
            # Parse into bullet points
            key_achievements = [
                line.strip('- ').strip()
                for line in key_achievements_text.split('\n')
                if line.strip().startswith('-')
            ]
        except Exception as e:
            # Fallback to template-based generation
            executive_summary = generate_fallback_summary(data)
            challenges_section = generate_fallback_challenges(friction_logs)
            collaboration_section = generate_fallback_collaboration(manual_entries)
            key_achievements = generate_fallback_achievements(commits)
    else:
        # Use template-based generation
        executive_summary = generate_fallback_summary(data)
        challenges_section = generate_fallback_challenges(friction_logs)
        collaboration_section = generate_fallback_collaboration(manual_entries)
        key_achievements = generate_fallback_achievements(commits)
    
    return ReportTemplate(
        start_date=start_date,
        end_date=end_date,
        executive_summary=executive_summary,
        key_achievements=key_achievements,
        challenges_section=challenges_section,
        collaboration_section=collaboration_section,
        metrics_snapshot=metrics_snapshot,
        commits=commits,
        friction_logs=friction_logs,
        manual_entries=manual_entries
    )


def generate_fallback_summary(data: Dict) -> str:
    """Fallback summary without LLM."""
    stats = data['stats']
    return f"""During this period, I delivered {stats['total_commits']} commits across multiple features and improvements. I documented {stats['total_friction_logs']} friction points and completed {stats['total_manual_entries']} collaboration activities including code reviews and design work."""


def generate_fallback_challenges(friction_logs: List[FrictionLog]) -> str:
    """Fallback challenges section without LLM."""
    blockers = [f for f in friction_logs if f.type == 'blocker']
    incidents = [f for f in friction_logs if f.type == 'incident']
    
    challenges = []
    for friction in blockers + incidents[:5]:
        resolution = f" Resolved by: {friction.resolution}" if friction.resolution else ""
        challenges.append(f"- {friction.description[:100]}{resolution}")
    
    return "\n".join(challenges) if challenges else "No major challenges documented during this period."


def generate_fallback_collaboration(manual_entries: List[ManualEntry]) -> str:
    """Fallback collaboration section without LLM."""
    code_reviews = [e for e in manual_entries if e.type == 'code_review']
    design_docs = [e for e in manual_entries if e.type == 'design_doc']
    
    activities = []
    for entry in code_reviews + design_docs[:5]:
        collaborators = f" with {entry.collaborators}" if entry.collaborators else ""
        activities.append(f"- {entry.title}{collaborators}")
    
    return "\n".join(activities) if activities else "No collaboration activities documented during this period."


def generate_fallback_achievements(commits: List[Commit]) -> List[str]:
    """Fallback achievements from commits without LLM."""
    achievements = []
    commits_by_type = {}
    
    for commit in commits:
        commit_type = commit.type or 'Unknown'
        commits_by_type[commit_type] = commits_by_type.get(commit_type, 0) + 1
    
    for commit_type, count in sorted(commits_by_type.items(), key=lambda x: x[1], reverse=True)[:5]:
        achievements.append(f"Delivered {count} {commit_type} commits")
    
    return achievements
```

---

#### Day 5: Enhanced PDF Generation ✅

**File**: `backend/app/services/report_generator.py`

**Status**: ✅ **COMPLETE** - Enhanced PDF generation with all new sections

Update PDF generation to include all new sections:

```python
def generate_pdf_report(
    db: Session,
    start_date: datetime,
    end_date: datetime,
    repo_id: Optional[int] = None,
    use_llm: bool = True
) -> bytes:
    """
    Generate enhanced PDF report with all sections.
    """
    from io import BytesIO
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak
    from reportlab.lib import colors
    
    # Generate report template
    report = generate_manager_report(db, start_date, end_date, repo_id, use_llm)
    
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    story = []
    styles = getSampleStyleSheet()
    
    # Custom styles
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=colors.HexColor('#1a1a1a'),
        spaceAfter=30,
    )
    
    heading_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=16,
        textColor=colors.HexColor('#2c3e50'),
        spaceAfter=12,
    )
    
    # Title
    story.append(Paragraph("DevPulse Performance Report", title_style))
    story.append(Spacer(1, 0.2 * inch))
    
    # Period
    period_text = f"Period: {start_date.strftime('%B %d, %Y')} to {end_date.strftime('%B %d, %Y')}"
    story.append(Paragraph(period_text, styles['Normal']))
    story.append(Spacer(1, 0.3 * inch))
    
    # Executive Summary
    story.append(Paragraph("Executive Summary", heading_style))
    story.append(Paragraph(report.executive_summary, styles['Normal']))
    story.append(Spacer(1, 0.3 * inch))
    
    # Key Achievements
    story.append(Paragraph("Key Achievements", heading_style))
    for achievement in report.key_achievements:
        story.append(Paragraph(f"• {achievement}", styles['Normal']))
    story.append(Spacer(1, 0.3 * inch))
    
    # Challenges & Growth
    story.append(Paragraph("Challenges & Growth", heading_style))
    story.append(Paragraph(report.challenges_section, styles['Normal']))
    story.append(Spacer(1, 0.3 * inch))
    
    # Collaboration Highlights
    story.append(Paragraph("Collaboration Highlights", heading_style))
    story.append(Paragraph(report.collaboration_section, styles['Normal']))
    story.append(Spacer(1, 0.3 * inch))
    
    # Metrics Snapshot
    story.append(Paragraph("Metrics Snapshot", heading_style))
    
    if report.metrics_snapshot.get('dora'):
        dora = report.metrics_snapshot['dora']
        story.append(Paragraph("DORA Metrics:", styles['Heading3']))
        story.append(Paragraph(f"Deployment Frequency: {dora.get('deployment_frequency', 'N/A')}", styles['Normal']))
        story.append(Paragraph(f"Lead Time: {dora.get('lead_time', 'N/A')}", styles['Normal']))
        story.append(Paragraph(f"Change Failure Rate: {dora.get('change_failure_rate', 'N/A')}", styles['Normal']))
        story.append(Paragraph(f"MTTR: {dora.get('mttr', 'N/A')}", styles['Normal']))
        story.append(Spacer(1, 0.2 * inch))
    
    if report.metrics_snapshot.get('space'):
        space = report.metrics_snapshot['space']
        story.append(Paragraph("SPACE Metrics:", styles['Heading3']))
        story.append(Paragraph(f"Satisfaction: {space.get('satisfaction', 'N/A')}", styles['Normal']))
        story.append(Paragraph(f"Performance: {space.get('performance', 'N/A')}", styles['Normal']))
        story.append(Paragraph(f"Activity: {space.get('activity', 'N/A')}", styles['Normal']))
        story.append(Paragraph(f"Collaboration: {space.get('collaboration', 'N/A')}", styles['Normal']))
        story.append(Paragraph(f"Efficiency: {space.get('efficiency', 'N/A')}", styles['Normal']))
    
    story.append(Spacer(1, 0.3 * inch))
    
    # Data Summary
    story.append(Paragraph("Data Summary", heading_style))
    story.append(Paragraph(f"Total Commits: {len(report.commits)}", styles['Normal']))
    story.append(Paragraph(f"Friction Logs: {len(report.friction_logs)}", styles['Normal']))
    story.append(Paragraph(f"Manual Entries: {len(report.manual_entries)}", styles['Normal']))
    
    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()
```

---

### Task Group 3: API Endpoints (1-2 days)

#### Day 6: Enhanced Report API ✅

**File**: `backend/app/api/reports.py`

**Status**: ✅ **COMPLETE** - Updated `/generate` endpoint and added `/preview` endpoint with format and use_llm parameters

Update API endpoints to support new report structure:

```python
from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy.orm import Session
from typing import Optional
from datetime import datetime
from pydantic import BaseModel

from ..database import get_db
from ..services.report_generator import (
    generate_manager_report,
    generate_pdf_report,
    ReportTemplate
)

router = APIRouter(prefix="/api/reports", tags=["reports"])


class ReportRequest(BaseModel):
    start_date: datetime
    end_date: datetime
    repo_id: Optional[int] = None
    use_llm: Optional[bool] = True
    format: Optional[str] = "json"  # json, markdown, pdf


@router.post("/generate")
def generate_report(
    request: ReportRequest,
    db: Session = Depends(get_db)
):
    """
    Generate manager report in requested format.
    """
    try:
        report = generate_manager_report(
            db,
            request.start_date,
            request.end_date,
            request.repo_id,
            request.use_llm
        )
        
        if request.format == "markdown":
            return {
                "format": "markdown",
                "content": report.to_markdown(),
                "metadata": report.to_dict()['data_summary']
            }
        elif request.format == "pdf":
            pdf_bytes = generate_pdf_report(
                db,
                request.start_date,
                request.end_date,
                request.repo_id,
                request.use_llm
            )
            return Response(
                content=pdf_bytes,
                media_type="application/pdf",
                headers={
                    "Content-Disposition": f"attachment; filename=devpulse_report_{request.start_date.date()}_to_{request.end_date.date()}.pdf"
                }
            )
        else:  # json
            return {
                "format": "json",
                "report": report.to_dict()
            }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating report: {str(e)}")


@router.post("/preview")
def preview_report(
    request: ReportRequest,
    db: Session = Depends(get_db)
):
    """
    Preview report data without generating full report (faster).
    """
    try:
        from ..services.report_generator import aggregate_report_data
        
        data = aggregate_report_data(
            db,
            request.start_date,
            request.end_date,
            request.repo_id
        )
        
        return {
            "data_summary": data['stats'],
            "sample_commits": len(data['commits'][:5]),
            "sample_friction": len(data['friction_logs'][:5]),
            "sample_manual": len(data['manual_entries'][:5]),
            "will_include_llm": request.use_llm
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error previewing report: {str(e)}")
```

---

### Task Group 4: Frontend Integration (2-3 days)

#### Day 7-8: Report Generation UI ✅

**File**: `frontend/src/pages/Review.tsx` (enhance existing)

**Status**: ✅ **COMPLETE** - Enhanced UI with format selector, LLM toggle, preview functionality, and improved report display

Create report generation interface:

```typescript
import React, { useState } from 'react';
import { api } from '../services/api';

interface ReportRequest {
  start_date: string;
  end_date: string;
  repo_id?: number;
  use_llm: boolean;
  format: 'json' | 'markdown' | 'pdf';
}

export function Review() {
  const [request, setRequest] = useState<ReportRequest>({
    start_date: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    end_date: new Date().toISOString().split('T')[0],
    use_llm: true,
    format: 'json'
  });
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState<any>(null);
  const [report, setReport] = useState<any>(null);

  const handlePreview = async () => {
    setLoading(true);
    try {
      const previewData = await api.previewReport(request);
      setPreview(previewData);
    } catch (error) {
      alert('Failed to preview report');
    } finally {
      setLoading(false);
    }
  };

  const handleGenerate = async () => {
    setLoading(true);
    try {
      if (request.format === 'pdf') {
        // Download PDF
        const blob = await api.generateReportPDF(request);
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `devpulse_report_${request.start_date}_to_${request.end_date}.pdf`;
        a.click();
      } else {
        const reportData = await api.generateReport(request);
        setReport(reportData);
      }
    } catch (error) {
      alert('Failed to generate report');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <h1 className="text-3xl font-bold">Manager Report Generator</h1>

      {/* Configuration */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-bold mb-4">Report Configuration</h2>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Start Date</label>
            <input
              type="date"
              value={request.start_date}
              onChange={(e) => setRequest({ ...request, start_date: e.target.value })}
              className="w-full border rounded px-3 py-2"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">End Date</label>
            <input
              type="date"
              value={request.end_date}
              onChange={(e) => setRequest({ ...request, end_date: e.target.value })}
              className="w-full border rounded px-3 py-2"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Format</label>
            <select
              value={request.format}
              onChange={(e) => setRequest({ ...request, format: e.target.value as any })}
              className="w-full border rounded px-3 py-2"
            >
              <option value="json">JSON</option>
              <option value="markdown">Markdown</option>
              <option value="pdf">PDF</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="use_llm"
              checked={request.use_llm}
              onChange={(e) => setRequest({ ...request, use_llm: e.target.checked })}
            />
            <label htmlFor="use_llm">Use AI for narrative generation</label>
          </div>

          <div className="flex gap-4">
            <button
              onClick={handlePreview}
              disabled={loading}
              className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600"
            >
              Preview
            </button>
            <button
              onClick={handleGenerate}
              disabled={loading}
              className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
            >
              {loading ? 'Generating...' : 'Generate Report'}
            </button>
          </div>
        </div>
      </div>

      {/* Preview */}
      {preview && (
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-bold mb-4">Preview</h2>
          <pre className="bg-gray-100 p-4 rounded text-sm overflow-auto">
            {JSON.stringify(preview, null, 2)}
          </pre>
        </div>
      )}

      {/* Report Display */}
      {report && request.format !== 'pdf' && (
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-bold mb-4">Generated Report</h2>
          {request.format === 'markdown' ? (
            <pre className="bg-gray-100 p-4 rounded text-sm whitespace-pre-wrap">
              {report.content}
            </pre>
          ) : (
            <div className="space-y-4">
              <div>
                <h3 className="font-bold">Executive Summary</h3>
                <p>{report.report.executive_summary}</p>
              </div>
              <div>
                <h3 className="font-bold">Key Achievements</h3>
                <ul className="list-disc list-inside">
                  {report.report.key_achievements.map((a: string, i: number) => (
                    <li key={i}>{a}</li>
                  ))}
                </ul>
              </div>
              {/* More sections... */}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
```

Add to `frontend/src/services/api.ts`:

```typescript
export const api = {
  // ... existing methods ...

  previewReport: async (request: ReportRequest): Promise<any> => {
    const response = await fetch(`${API_BASE}/reports/preview`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(request),
    });
    return response.json();
  },

  generateReport: async (request: ReportRequest): Promise<any> => {
    const response = await fetch(`${API_BASE}/reports/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(request),
    });
    return response.json();
  },

  generateReportPDF: async (request: ReportRequest): Promise<Blob> => {
    const response = await fetch(`${API_BASE}/reports/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...request, format: 'pdf' }),
    });
    return response.blob();
  },
};
```

---

#### Day 9: Saved Reports History (Optional) ✅

**File**: `backend/app/models.py` + `backend/app/api/reports.py`

**Status**: ⏸️ **DEFERRED** - Optional enhancement for future sprint

Add model for saved reports:

```python
class SavedReport(Base):
    __tablename__ = "saved_reports"
    
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    start_date = Column(DateTime(timezone=True), nullable=False)
    end_date = Column(DateTime(timezone=True), nullable=False)
    report_data = Column(Text)  # JSON string
    format = Column(String)  # json, markdown, pdf
    created_at = Column(DateTime(timezone=True), server_default=func.now())
```

Add endpoints:

```python
@router.get("/saved")
def list_saved_reports(db: Session = Depends(get_db)):
    """List all saved reports."""
    reports = db.query(SavedReport).order_by(SavedReport.created_at.desc()).all()
    return [{"id": r.id, "title": r.title, "created_at": r.created_at} for r in reports]

@router.post("/save")
def save_report(
    title: str,
    report_data: dict,
    db: Session = Depends(get_db)
):
    """Save a generated report."""
    saved = SavedReport(
        title=title,
        start_date=report_data['period']['start'],
        end_date=report_data['period']['end'],
        report_data=json.dumps(report_data),
        format='json'
    )
    db.add(saved)
    db.commit()
    return {"id": saved.id, "message": "Report saved"}
```

---

## 🎯 Testing Your Implementation

### Manual Test Plan

1. **Data Aggregation Test**:

```bash
# Test API endpoint
curl -X POST http://localhost:8000/api/reports/preview \
  -H "Content-Type: application/json" \
  -d '{
    "start_date": "2024-10-01T00:00:00",
    "end_date": "2024-12-31T23:59:59",
    "use_llm": true
  }'
```

2. **Report Generation Test**:

```bash
# Generate JSON report
curl -X POST http://localhost:8000/api/reports/generate \
  -H "Content-Type: application/json" \
  -d '{
    "start_date": "2024-10-01T00:00:00",
    "end_date": "2024-12-31T23:59:59",
    "format": "json",
    "use_llm": true
  }'

# Generate Markdown report
curl -X POST http://localhost:8000/api/reports/generate \
  -H "Content-Type: application/json" \
  -d '{
    "start_date": "2024-10-01T00:00:00",
    "end_date": "2024-12-31T23:59:59",
    "format": "markdown",
    "use_llm": true
  }'
```

3. **Frontend Test**:

- Open `http://localhost:5173/review`
- Select date range
- Click "Preview" to see data summary
- Generate report in different formats
- Verify all sections are included
- Test fallback mode (disable LLM)

---

## 📊 Success Metrics for Sprint 2

After completing Sprint 2, you should be able to:

✅ **Report Generation** (< 2 minutes): **ACHIEVED**
- ✅ Generate complete report from date range selection
- ✅ Export to Markdown, PDF, or JSON
- ✅ Preview data before generating

✅ **Report Quality**: **ACHIEVED**
- ✅ Executive summary includes all data sources
- ✅ Challenges section from friction logs
- ✅ Collaboration section from manual entries
- ✅ Metrics snapshot (DORA + SPACE when available)

✅ **Reliability**: **ACHIEVED**
- ✅ Fallback works when LLM fails
- ✅ Report generation never crashes
- ✅ All sections populated even with minimal data

---

## 🚀 After Sprint 2: What's Next?

With Manager Report Generator working, you unlock:

1. **Sprint 3**: DORA Metrics (calculation-heavy but data exists)
   - Can now include DORA metrics in reports
   - MTTR calculation from friction incidents

2. **Sprint 4**: SPACE Metrics
   - Can now include SPACE metrics in reports
   - Collaboration score from manual entries

3. **Sprint 5**: Dashboard Visualizations
   - Visualize all metrics integrated
   - Interactive charts and trends

---

## 💡 Pro Tips

1. **Test with real data**: Generate a report for your last quarter to see gaps
2. **Iterate on prompts**: Adjust LLM prompts based on output quality
3. **Use preview**: Always preview before generating full report
4. **Save reports**: Keep history to compare quarters
5. **Fallback mode**: Test without LLM to ensure it works

---

## 🆘 Common Issues

### Issue: "LLM API fails"

**Solution**: Fallback mode uses template-based generation. Test with `use_llm: false`.

### Issue: "Report is too generic"

**Solution**: Improve LLM prompts with more context. Add role/team info to prompts.

### Issue: "Missing friction logs in report"

**Solution**: Verify friction logs are in date range. Check aggregation function.

---

## 🎉 Sprint 2 Complete!

**Status**: ✅ **COMPLETE**

### Implementation Summary

All core features have been successfully implemented:

1. ✅ **Data Aggregation**: `aggregate_report_data()` function combines commits, friction logs, and manual entries
2. ✅ **Enhanced LLM Methods**: Three new methods for executive summary, challenges, and collaboration sections
3. ✅ **Report Template**: Structured `ReportTemplate` class with JSON and Markdown export
4. ✅ **Main Generator**: `generate_manager_report()` with LLM integration and fallback support
5. ✅ **PDF Generation**: Enhanced PDF with all new sections
6. ✅ **API Endpoints**: Updated `/generate` and new `/preview` endpoints with format support
7. ✅ **Frontend UI**: Complete UI with format selector, LLM toggle, preview, and report display

### Next Steps

1. **Sprint 3**: DORA Metrics (calculation-heavy but data exists)
   - Can now include DORA metrics in reports
   - MTTR calculation from friction incidents

2. **Sprint 4**: SPACE Metrics
   - Can now include SPACE metrics in reports
   - Collaboration score from manual entries

3. **Sprint 5**: Dashboard Visualizations
   - Visualize all metrics integrated
   - Interactive charts and trends

**The Manager Report Generator is production-ready and can generate comprehensive reports in < 2 minutes!**

