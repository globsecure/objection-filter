# 🚀 Sprint 7 - Final Improvements (Pre-Architecture)

**Goal**: Complete all remaining business features before architecture refactoring.

**Timeline**: 1-2 weeks

**Status**: ✅ **COMPLETE**

**Success Criteria**:

- Rate limiting and cost tracking for LLM APIs implemented
- Saved reports history with comparison capabilities
- All business features production-ready
- Ready for architecture migration (P3)

---

## 📋 Overview

Sprint 7 focuses on completing the final business-critical improvements before moving to architecture refactoring. This sprint ensures the tool is fully production-ready from a feature perspective.

**Key Features**:

- LLM API rate limiting and cost tracking
- Saved reports history for quarter-over-quarter comparisons
- Enhanced report management

**Exclusions** (deferred to P3):

- Complete DDD migration
- Advanced integrations (Jira, GitHub API, Slack)
- Calendar integration (OAuth complexity)

---

## 📋 Tasks Breakdown

### Task Group 1: LLM Rate Limiting & Cost Tracking (2-3 days)

#### Day 1: Database Schema & Models

**File**: `backend/app/models.py`

**Status**: ✅ Implemented

Add models for tracking LLM usage:

```python
class LLMUsageLog(Base):
    __tablename__ = "llm_usage_logs"

    id = Column(Integer, primary_key=True, index=True)
    provider = Column(String, nullable=False, index=True)  # 'openai' | 'gemini'
    model = Column(String, nullable=False)  # 'gpt-3.5-turbo', 'gemini-pro', etc.
    operation = Column(String, nullable=False, index=True)  # 'executive_summary' | 'challenges' | 'collaboration'
    input_tokens = Column(Integer, default=0)
    output_tokens = Column(Integer, default=0)
    cost_usd = Column(Float, default=0.0)
    request_duration_ms = Column(Integer)
    success = Column(Boolean, default=True)
    error_message = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)


class LLMRateLimit(Base):
    __tablename__ = "llm_rate_limits"

    id = Column(Integer, primary_key=True, index=True)
    provider = Column(String, nullable=False, unique=True)
    requests_per_minute = Column(Integer, default=60)
    tokens_per_minute = Column(Integer, default=90000)
    requests_per_day = Column(Integer, default=1000)
    current_minute_requests = Column(Integer, default=0)
    current_minute_tokens = Column(Integer, default=0)
    current_day_requests = Column(Integer, default=0)
    last_reset_minute = Column(DateTime(timezone=True))
    last_reset_day = Column(DateTime(timezone=True))
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
```

**Migration**: Create Alembic migration `add_llm_tracking.py`

---

#### Day 2: Rate Limiting Service

**File**: `backend/app/services/llm_rate_limiter.py`

**Status**: ✅ Implemented

Create rate limiting service:

```python
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from typing import Optional, Dict
from ..models import LLMRateLimit, LLMUsageLog
from ..database import get_db


class RateLimitExceeded(Exception):
    """Raised when rate limit is exceeded"""
    pass


class LLMRateLimiter:
    def __init__(self, db: Session):
        self.db = db

    def check_rate_limit(
        self,
        provider: str,
        estimated_tokens: int = 0
    ) -> bool:
        """
        Check if request is within rate limits.
        Returns True if allowed, raises RateLimitExceeded if not.
        """
        limit = self.db.query(LLMRateLimit).filter(
            LLMRateLimit.provider == provider
        ).first()

        if not limit:
            # Create default limits
            limit = LLMRateLimit(
                provider=provider,
                requests_per_minute=60,
                tokens_per_minute=90000,
                requests_per_day=1000
            )
            self.db.add(limit)
            self.db.commit()

        now = datetime.utcnow()

        # Reset minute counter if needed
        if not limit.last_reset_minute or (now - limit.last_reset_minute).seconds >= 60:
            limit.current_minute_requests = 0
            limit.current_minute_tokens = 0
            limit.last_reset_minute = now

        # Reset day counter if needed
        if not limit.last_reset_day or (now - limit.last_reset_day).days >= 1:
            limit.current_day_requests = 0
            limit.last_reset_day = now

        # Check limits
        if limit.current_minute_requests >= limit.requests_per_minute:
            raise RateLimitExceeded(
                f"Rate limit exceeded: {limit.current_minute_requests}/{limit.requests_per_minute} requests per minute"
            )

        if limit.current_minute_tokens + estimated_tokens > limit.tokens_per_minute:
            raise RateLimitExceeded(
                f"Token limit exceeded: {limit.current_minute_tokens + estimated_tokens}/{limit.tokens_per_minute} tokens per minute"
            )

        if limit.current_day_requests >= limit.requests_per_day:
            raise RateLimitExceeded(
                f"Daily limit exceeded: {limit.current_day_requests}/{limit.requests_per_day} requests per day"
            )

        # Update counters
        limit.current_minute_requests += 1
        limit.current_minute_tokens += estimated_tokens
        limit.current_day_requests += 1
        limit.updated_at = now
        self.db.commit()

        return True

    def log_usage(
        self,
        provider: str,
        model: str,
        operation: str,
        input_tokens: int,
        output_tokens: int,
        cost_usd: float,
        duration_ms: int,
        success: bool = True,
        error_message: Optional[str] = None
    ):
        """Log LLM API usage"""
        log = LLMUsageLog(
            provider=provider,
            model=model,
            operation=operation,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=cost_usd,
            request_duration_ms=duration_ms,
            success=success,
            error_message=error_message
        )
        self.db.add(log)
        self.db.commit()

    def get_usage_stats(
        self,
        provider: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> Dict:
        """Get usage statistics"""
        query = self.db.query(LLMUsageLog)

        if provider:
            query = query.filter(LLMUsageLog.provider == provider)
        if start_date:
            query = query.filter(LLMUsageLog.created_at >= start_date)
        if end_date:
            query = query.filter(LLMUsageLog.created_at <= end_date)

        logs = query.all()

        total_requests = len(logs)
        successful_requests = len([l for l in logs if l.success])
        total_input_tokens = sum(l.input_tokens for l in logs)
        total_output_tokens = sum(l.output_tokens for l in logs)
        total_cost = sum(l.cost_usd for l in logs)
        avg_duration = sum(l.request_duration_ms for l in logs) / total_requests if total_requests > 0 else 0

        # Group by operation
        by_operation = {}
        for log in logs:
            if log.operation not in by_operation:
                by_operation[log.operation] = {
                    'count': 0,
                    'cost': 0.0,
                    'tokens': 0
                }
            by_operation[log.operation]['count'] += 1
            by_operation[log.operation]['cost'] += log.cost_usd
            by_operation[log.operation]['tokens'] += (log.input_tokens + log.output_tokens)

        return {
            'total_requests': total_requests,
            'successful_requests': successful_requests,
            'failed_requests': total_requests - successful_requests,
            'total_input_tokens': total_input_tokens,
            'total_output_tokens': total_output_tokens,
            'total_tokens': total_input_tokens + total_output_tokens,
            'total_cost_usd': round(total_cost, 4),
            'avg_duration_ms': round(avg_duration, 2),
            'by_operation': by_operation,
            'by_provider': self._group_by_provider(logs)
        }

    def _group_by_provider(self, logs: list) -> Dict:
        """Group usage stats by provider"""
        by_provider = {}
        for log in logs:
            if log.provider not in by_provider:
                by_provider[log.provider] = {
                    'count': 0,
                    'cost': 0.0,
                    'tokens': 0
                }
            by_provider[log.provider]['count'] += 1
            by_provider[log.provider]['cost'] += log.cost_usd
            by_provider[log.provider]['tokens'] += (log.input_tokens + log.output_tokens)
        return by_provider
```

---

#### Day 3: Cost Calculator & LLM Service Integration

**File**: `backend/app/services/llm_cost_calculator.py`

**Status**: ✅ Implemented

Create cost calculator:

```python
# Pricing per 1K tokens (as of 2024)
PRICING = {
    'openai': {
        'gpt-3.5-turbo': {
            'input': 0.0005,  # $0.50 per 1M tokens
            'output': 0.0015  # $1.50 per 1M tokens
        },
        'gpt-4': {
            'input': 0.03,    # $30 per 1M tokens
            'output': 0.06    # $60 per 1M tokens
        },
        'gpt-4-turbo': {
            'input': 0.01,    # $10 per 1M tokens
            'output': 0.03   # $30 per 1M tokens
        }
    },
    'gemini': {
        'gemini-pro': {
            'input': 0.00025,  # $0.25 per 1M tokens
            'output': 0.0005   # $0.50 per 1M tokens
        }
    }
}


def calculate_cost(
    provider: str,
    model: str,
    input_tokens: int,
    output_tokens: int
) -> float:
    """Calculate cost in USD"""
    if provider not in PRICING:
        return 0.0

    if model not in PRICING[provider]:
        # Use default pricing
        return 0.0

    pricing = PRICING[provider][model]
    input_cost = (input_tokens / 1000) * pricing['input']
    output_cost = (output_tokens / 1000) * pricing['output']

    return round(input_cost + output_cost, 6)
```

**File**: `backend/app/analysis/llm_service.py`

**Status**: ⏳ To be enhanced

Update LLM service to use rate limiter and cost tracking:

```python
from ..services.llm_rate_limiter import LLMRateLimiter, RateLimitExceeded
from ..services.llm_cost_calculator import calculate_cost
import time

# In each method, wrap API calls:

def generate_executive_summary(...):
    rate_limiter = LLMRateLimiter(db)
    start_time = time.time()

    try:
        # Estimate tokens (rough: 1 token ≈ 4 chars)
        estimated_tokens = len(prompt) // 4
        rate_limiter.check_rate_limit('openai', estimated_tokens)

        # Make API call
        response = client.chat.completions.create(...)

        # Calculate actual usage
        input_tokens = response.usage.prompt_tokens
        output_tokens = response.usage.completion_tokens
        cost = calculate_cost('openai', 'gpt-3.5-turbo', input_tokens, output_tokens)
        duration_ms = int((time.time() - start_time) * 1000)

        # Log usage
        rate_limiter.log_usage(
            provider='openai',
            model='gpt-3.5-turbo',
            operation='executive_summary',
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=cost,
            duration_ms=duration_ms,
            success=True
        )

        return response.choices[0].message.content.strip()
    except RateLimitExceeded as e:
        rate_limiter.log_usage(
            provider='openai',
            model='gpt-3.5-turbo',
            operation='executive_summary',
            input_tokens=0,
            output_tokens=0,
            cost_usd=0.0,
            duration_ms=int((time.time() - start_time) * 1000),
            success=False,
            error_message=str(e)
        )
        raise
    except Exception as e:
        # Log error
        rate_limiter.log_usage(...)
        return f"Error generating executive summary: {str(e)}"
```

---

### Task Group 2: Saved Reports History (3-4 days)

#### Day 4: Database Schema & Models

**File**: `backend/app/models.py`

**Status**: ✅ Implemented

Add SavedReport model:

```python
class SavedReport(Base):
    __tablename__ = "saved_reports"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)  # e.g., "Q1 2025 Performance Review"
    period_start = Column(DateTime(timezone=True), nullable=False, index=True)
    period_end = Column(DateTime(timezone=True), nullable=False, index=True)
    quarter = Column(String, index=True)  # e.g., "Q1-2025"
    report_data = Column(Text)  # JSON string of full report
    markdown_content = Column(Text)  # Cached markdown
    pdf_path = Column(String)  # Optional: path to saved PDF
    repo_id = Column(Integer, ForeignKey("repositories.id"), nullable=True)
    tags = Column(String)  # Comma-separated tags
    notes = Column(Text)  # User notes about this report
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
```

**Migration**: Create Alembic migration `add_saved_reports.py`

---

#### Day 5: API Endpoints

**File**: `backend/app/api/reports.py`

**Status**: ⏳ To be enhanced

Add endpoints for saved reports:

```python
from ..models import SavedReport
from ..schemas import SavedReportCreate, SavedReportUpdate
from datetime import datetime
import json

@router.post("/save")
def save_report(
    request: ReportRequest,
    name: str = Query(..., description="Report name"),
    quarter: Optional[str] = Query(None, description="Quarter identifier (e.g., Q1-2025)"),
    tags: Optional[str] = Query(None, description="Comma-separated tags"),
    notes: Optional[str] = Query(None, description="User notes"),
    db: Session = Depends(get_db)
):
    """Save a generated report for future reference"""
    try:
        # Generate report
        report = generate_manager_report(
            db,
            request.start_date,
            request.end_date,
            request.repo_id,
            request.use_llm
        )

        # Save to database
        saved_report = SavedReport(
            name=name,
            period_start=request.start_date,
            period_end=request.end_date,
            quarter=quarter or _generate_quarter(request.start_date, request.end_date),
            report_data=json.dumps(report.to_dict()),
            markdown_content=report.to_markdown(),
            repo_id=request.repo_id,
            tags=tags,
            notes=notes
        )
        db.add(saved_report)
        db.commit()
        db.refresh(saved_report)

        return {
            "id": saved_report.id,
            "name": saved_report.name,
            "quarter": saved_report.quarter,
            "created_at": saved_report.created_at.isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error saving report: {str(e)}")


@router.get("/saved")
def list_saved_reports(
    quarter: Optional[str] = Query(None),
    repo_id: Optional[int] = Query(None),
    limit: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """List all saved reports"""
    query = db.query(SavedReport)

    if quarter:
        query = query.filter(SavedReport.quarter == quarter)
    if repo_id:
        query = query.filter(SavedReport.repo_id == repo_id)

    reports = query.order_by(SavedReport.created_at.desc()).limit(limit).all()

    return [
        {
            "id": r.id,
            "name": r.name,
            "quarter": r.quarter,
            "period_start": r.period_start.isoformat(),
            "period_end": r.period_end.isoformat(),
            "tags": r.tags.split(",") if r.tags else [],
            "created_at": r.created_at.isoformat()
        }
        for r in reports
    ]


@router.get("/saved/{report_id}")
def get_saved_report(
    report_id: int,
    format: str = Query("json", regex="^(json|markdown)$"),
    db: Session = Depends(get_db)
):
    """Retrieve a saved report"""
    report = db.query(SavedReport).filter(SavedReport.id == report_id).first()

    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    if format == "markdown":
        return {
            "format": "markdown",
            "content": report.markdown_content,
            "metadata": {
                "id": report.id,
                "name": report.name,
                "quarter": report.quarter,
                "created_at": report.created_at.isoformat()
            }
        }
    else:
        return {
            "format": "json",
            "report": json.loads(report.report_data),
            "metadata": {
                "id": report.id,
                "name": report.name,
                "quarter": report.quarter,
                "created_at": report.created_at.isoformat()
            }
        }


@router.delete("/saved/{report_id}")
def delete_saved_report(
    report_id: int,
    db: Session = Depends(get_db)
):
    """Delete a saved report"""
    report = db.query(SavedReport).filter(SavedReport.id == report_id).first()

    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    db.delete(report)
    db.commit()

    return {"message": "Report deleted successfully"}


@router.get("/saved/compare")
def compare_reports(
    report_ids: str = Query(..., description="Comma-separated report IDs"),
    db: Session = Depends(get_db)
):
    """Compare multiple saved reports"""
    ids = [int(id.strip()) for id in report_ids.split(",")]
    reports = db.query(SavedReport).filter(SavedReport.id.in_(ids)).all()

    if len(reports) != len(ids):
        raise HTTPException(status_code=404, detail="One or more reports not found")

    # Extract metrics for comparison
    comparisons = []
    for report in reports:
        data = json.loads(report.report_data)
        metrics = data.get('metrics_snapshot', {})

        comparisons.append({
            "id": report.id,
            "name": report.name,
            "quarter": report.quarter,
            "period": {
                "start": report.period_start.isoformat(),
                "end": report.period_end.isoformat()
            },
            "metrics": {
                "dora": metrics.get('dora', {}),
                "space": metrics.get('space', {}),
                "summary": data.get('data_summary', {})
            }
        })

    return {
        "reports": comparisons,
        "comparison_summary": _generate_comparison_summary(comparisons)
    }


def _generate_quarter(start_date: datetime, end_date: datetime) -> str:
    """Generate quarter identifier from date range"""
    # Simple implementation - can be enhanced
    year = start_date.year
    if start_date.month <= 3:
        quarter = "Q1"
    elif start_date.month <= 6:
        quarter = "Q2"
    elif start_date.month <= 9:
        quarter = "Q3"
    else:
        quarter = "Q4"

    return f"{quarter}-{year}"


def _generate_comparison_summary(comparisons: list) -> dict:
    """Generate summary comparing multiple reports"""
    if len(comparisons) < 2:
        return {}

    # Extract key metrics for comparison
    dora_metrics = []
    space_scores = []

    for comp in comparisons:
        dora = comp['metrics'].get('dora', {})
        space = comp['metrics'].get('space', {})

        if dora:
            dora_metrics.append({
                'quarter': comp['quarter'],
                'deployment_frequency': dora.get('deployment_frequency', {}).get('per_week', 0),
                'lead_time_days': dora.get('lead_time', {}).get('avg_days', 0)
            })

        if space:
            # Calculate overall SPACE score
            scores = space.get('satisfaction', {}).get('average_satisfaction', 0)
            # Add other dimensions...
            space_scores.append({
                'quarter': comp['quarter'],
                'satisfaction': scores
            })

    return {
        'dora_trends': dora_metrics,
        'space_trends': space_scores,
        'improvements': _identify_improvements(dora_metrics, space_scores)
    }


def _identify_improvements(dora_metrics: list, space_scores: list) -> list:
    """Identify improvements across quarters"""
    improvements = []

    if len(dora_metrics) >= 2:
        # Compare deployment frequency
        latest = dora_metrics[-1]
        previous = dora_metrics[-2]

        if latest['deployment_frequency'] > previous['deployment_frequency']:
            improvements.append({
                'metric': 'deployment_frequency',
                'change': f"+{latest['deployment_frequency'] - previous['deployment_frequency']:.1f} per week",
                'trend': 'improving'
            })

    return improvements
```

---

#### Day 6: Frontend Components

**File**: `frontend/src/components/SavedReportsList.tsx`

**Status**: ✅ Implemented

Create component to list and manage saved reports:

```typescript
import React, { useState, useEffect } from 'react';
import {
  getSavedReports,
  deleteSavedReport,
  compareReports,
} from '../services/api';

interface SavedReport {
  id: number;
  name: string;
  quarter: string;
  period_start: string;
  period_end: string;
  tags: string[];
  created_at: string;
}

export const SavedReportsList: React.FC = () => {
  const [reports, setReports] = useState<SavedReport[]>([]);
  const [selectedReports, setSelectedReports] = useState<number[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadReports();
  }, []);

  const loadReports = async () => {
    try {
      const data = await getSavedReports();
      setReports(data);
    } catch (error) {
      console.error('Error loading reports:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to delete this report?')) return;

    try {
      await deleteSavedReport(id);
      setReports(reports.filter((r) => r.id !== id));
    } catch (error) {
      console.error('Error deleting report:', error);
    }
  };

  const handleCompare = async () => {
    if (selectedReports.length < 2) {
      alert('Please select at least 2 reports to compare');
      return;
    }

    try {
      const comparison = await compareReports(selectedReports.join(','));
      // Navigate to comparison view or show modal
      console.log('Comparison:', comparison);
    } catch (error) {
      console.error('Error comparing reports:', error);
    }
  };

  if (loading) {
    return <div>Loading saved reports...</div>;
  }

  return (
    <div className='space-y-4'>
      <div className='flex justify-between items-center'>
        <h2 className='text-2xl font-bold'>Saved Reports</h2>
        {selectedReports.length >= 2 && (
          <button
            onClick={handleCompare}
            className='px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700'
          >
            Compare Selected ({selectedReports.length})
          </button>
        )}
      </div>

      <div className='grid gap-4'>
        {reports.map((report) => (
          <div
            key={report.id}
            className='border rounded-lg p-4 hover:shadow-md transition-shadow'
          >
            <div className='flex items-start justify-between'>
              <div className='flex-1'>
                <div className='flex items-center gap-2'>
                  <input
                    type='checkbox'
                    checked={selectedReports.includes(report.id)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedReports([...selectedReports, report.id]);
                      } else {
                        setSelectedReports(
                          selectedReports.filter((id) => id !== report.id)
                        );
                      }
                    }}
                  />
                  <h3 className='text-lg font-semibold'>{report.name}</h3>
                  {report.quarter && (
                    <span className='px-2 py-1 bg-blue-100 text-blue-800 rounded text-sm'>
                      {report.quarter}
                    </span>
                  )}
                </div>
                <p className='text-sm text-gray-600 mt-1'>
                  {new Date(report.period_start).toLocaleDateString()} -{' '}
                  {new Date(report.period_end).toLocaleDateString()}
                </p>
                {report.tags && report.tags.length > 0 && (
                  <div className='flex gap-1 mt-2'>
                    {report.tags.map((tag, idx) => (
                      <span
                        key={idx}
                        className='px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs'
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>
              <div className='flex gap-2'>
                <button
                  onClick={() =>
                    window.open(
                      `/api/reports/saved/${report.id}?format=markdown`,
                      '_blank'
                    )
                  }
                  className='px-3 py-1 text-sm bg-gray-100 hover:bg-gray-200 rounded'
                >
                  View
                </button>
                <button
                  onClick={() => handleDelete(report.id)}
                  className='px-3 py-1 text-sm bg-red-100 hover:bg-red-200 rounded text-red-700'
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {reports.length === 0 && (
        <div className='text-center py-8 text-gray-500'>
          No saved reports yet. Generate and save a report to see it here.
        </div>
      )}
    </div>
  );
};
```

**File**: `frontend/src/components/ReportComparison.tsx`

**Status**: ✅ Implemented

Create comparison component:

```typescript
import React, { useState, useEffect } from 'react';
import { compareReports } from '../services/api';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

interface ComparisonProps {
  reportIds: number[];
}

export const ReportComparison: React.FC<ComparisonProps> = ({ reportIds }) => {
  const [comparison, setComparison] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadComparison();
  }, [reportIds]);

  const loadComparison = async () => {
    try {
      const data = await compareReports(reportIds.join(','));
      setComparison(data);
    } catch (error) {
      console.error('Error loading comparison:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div>Loading comparison...</div>;
  }

  if (!comparison) {
    return <div>No comparison data available</div>;
  }

  // Prepare chart data
  const doraData =
    comparison.comparison_summary?.dora_trends?.map((trend: any) => ({
      quarter: trend.quarter,
      deployment_frequency: trend.deployment_frequency,
      lead_time: trend.lead_time_days,
    })) || [];

  return (
    <div className='space-y-6'>
      <h2 className='text-2xl font-bold'>Report Comparison</h2>

      {/* DORA Metrics Trend */}
      {doraData.length > 0 && (
        <div className='bg-white p-4 rounded-lg shadow'>
          <h3 className='text-lg font-semibold mb-4'>DORA Metrics Trend</h3>
          <ResponsiveContainer width='100%' height={300}>
            <LineChart data={doraData}>
              <CartesianGrid strokeDasharray='3 3' />
              <XAxis dataKey='quarter' />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line
                type='monotone'
                dataKey='deployment_frequency'
                stroke='#8884d8'
                name='Deployments/Week'
              />
              <Line
                type='monotone'
                dataKey='lead_time'
                stroke='#82ca9d'
                name='Lead Time (days)'
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Improvements Summary */}
      {comparison.comparison_summary?.improvements && (
        <div className='bg-green-50 p-4 rounded-lg'>
          <h3 className='text-lg font-semibold mb-2'>Key Improvements</h3>
          <ul className='list-disc list-inside space-y-1'>
            {comparison.comparison_summary.improvements.map(
              (imp: any, idx: number) => (
                <li key={idx}>
                  <strong>{imp.metric}:</strong> {imp.change} ({imp.trend})
                </li>
              )
            )}
          </ul>
        </div>
      )}

      {/* Individual Report Metrics */}
      <div className='grid grid-cols-1 md:grid-cols-2 gap-4'>
        {comparison.reports.map((report: any) => (
          <div key={report.id} className='bg-white p-4 rounded-lg shadow'>
            <h3 className='font-semibold'>{report.name}</h3>
            <p className='text-sm text-gray-600'>{report.quarter}</p>
            {/* Display key metrics */}
          </div>
        ))}
      </div>
    </div>
  );
};
```

---

#### Day 7: Integration & Testing

**Tasks**:

- Update `frontend/src/services/api.ts` with new endpoints
- Add "Save Report" button to report generation page
- Create SavedReportsPage component
- Add navigation link
- Test end-to-end flow

---

### Task Group 3: Verification & Polish (1 day)

#### Day 8: Verify Manual Entries Integration

**Status**: ✅ Already implemented (verified in code review)

Manual entries are already integrated into SPACE metrics:

- `calculate_performance_metrics()` uses manual entries (code_reviews, design_docs, mentoring)
- `calculate_collaboration_metrics()` fully uses manual entries
- Integration is complete

**Action**: Update roadmap to mark `manual-006` as complete.

---

#### Day 8: Final Testing & Documentation

**Tasks**:

- Test rate limiting with multiple rapid requests
- Verify cost tracking accuracy
- Test saved reports CRUD operations
- Test report comparison feature
- Update API documentation
- Update user documentation

---

## 📋 API Endpoints Summary

### New Endpoints

**LLM Usage & Rate Limiting**:

- `GET /api/llm/usage` - Get usage statistics
- `GET /api/llm/usage/stats` - Detailed usage stats with filters
- `GET /api/llm/rate-limits` - Get current rate limit status
- `PUT /api/llm/rate-limits` - Update rate limits (admin)

**Saved Reports**:

- `POST /api/reports/save` - Save a generated report
- `GET /api/reports/saved` - List all saved reports
- `GET /api/reports/saved/{id}` - Get a specific saved report
- `DELETE /api/reports/saved/{id}` - Delete a saved report
- `GET /api/reports/saved/compare` - Compare multiple reports

---

## 🎯 Success Criteria

### Rate Limiting & Cost Tracking

- ✅ Rate limits prevent API abuse
- ✅ Cost tracking shows accurate spending
- ✅ Usage dashboard displays trends
- ✅ Alerts when approaching limits

### Saved Reports

- ✅ Reports can be saved with metadata
- ✅ Reports can be retrieved by quarter
- ✅ Multiple reports can be compared
- ✅ Comparison shows trends and improvements

---

## 📝 Implementation Checklist

- [x] Create database migrations for LLM tracking
- [x] Create database migrations for saved reports
- [x] Implement rate limiting service
- [x] Implement cost calculator
- [x] Integrate rate limiting into LLM service
- [x] Add usage logging to all LLM calls
- [x] Create API endpoints for LLM usage stats
- [x] Create API endpoints for saved reports
- [x] Create frontend components for saved reports
- [x] Create comparison visualization
- [x] Update report generation to include save option
- [x] Add navigation links
- [ ] Write tests
- [x] Update documentation

---

## 🚀 Next Steps After Sprint 7

Once Sprint 7 is complete, the tool will be **feature-complete** from a business perspective. The next phase will be:

**P3 - Architecture Refactoring**:

- Complete DDD migration
- Use cases layer
- Domain events
- Advanced integrations (optional)

---

## 📊 Estimated Timeline

- **Task Group 1** (Rate Limiting & Cost Tracking): 2-3 days
- **Task Group 2** (Saved Reports): 3-4 days
- **Task Group 3** (Verification & Polish): 1 day

**Total**: 6-8 days of focused work

---

## 🎉 Sprint 7 Complete!

After this sprint, DevPulse will have:

- ✅ Complete business feature set
- ✅ Production-ready LLM usage management
- ✅ Historical report tracking and comparison
- ✅ Ready for architecture refactoring

**Status**: Ready to move to P3 architecture work with confidence that all business features are complete.
