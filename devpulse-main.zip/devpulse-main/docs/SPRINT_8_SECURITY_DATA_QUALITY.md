# 🔒 Sprint 8 - Security & Data Quality Enhancements

**Goal**: Make DevPulse production-ready with security protections and comprehensive data quality validation.

**Timeline**: 2-3 weeks

**Status**: ✅ **COMPLETED** (January 2025)

**Note**: All security and data quality features have been fully implemented, including:
- Secret detection integrated with LLM service
- PII Scrubber with UI connected to backend (endpoints `/api/settings/security`)
- Encryption at rest with SQLCipher support (optional, configured via env vars)
- Local LLM Support (Ollama) - already implemented
- Enhanced validation warnings with actionable links

**Success Criteria**:

- Secret detection prevents sensitive data from being sent to LLM APIs
- Data redaction option available for privacy-conscious users
- Database encryption option available
- Local LLM support (Ollama) for maximum privacy
- Data completeness dashboard shows gaps and recommendations
- Smart reminders help maintain data quality
- Validation warnings proactively identify issues
- Core metrics calculations have unit tests
- Report generation has integration tests

---

## 📋 Overview

Sprint 8 focuses on two critical areas that must be addressed before production use:

1. **Security & Privacy**: Protect sensitive data (secrets, PII) from being exposed to external LLM APIs
2. **Data Quality & Completeness**: Ensure data is complete, validated, and proactively maintained

These improvements are essential for:

- Protecting company secrets and sensitive information
- Ensuring reliable insights from complete data
- Building trust in the tool's accuracy
- Meeting enterprise security requirements

**Key Features**:

- Secret detection in commit messages before LLM processing
- Optional data redaction for sensitive information
- Database encryption at rest
- Local LLM support (Ollama/LocalAI)
- Data completeness scoring and dashboard
- Smart reminders for missing data
- Proactive validation warnings
- Unit tests for critical calculations
- Integration tests for report generation

**Exclusions** (deferred to future sprints):

- Complete test coverage (only critical paths)
- Advanced GitHub/GitLab API integration (quality-008 is optional)
- Calendar integration
- Performance optimizations

---

## 📋 Tasks Breakdown

### Task Group 1: Secret Detection & Data Protection (3-4 days)

#### Day 1: Secret Detection Service

**File**: `backend/app/services/secret_detector.py`

**Status**: ✅ **COMPLETED**

Create secret detection service using regex patterns:

```python
import re
from typing import List, Dict, Optional
from enum import Enum


class SecretType(Enum):
    API_KEY = "api_key"
    PASSWORD = "password"
    TOKEN = "token"
    AWS_KEY = "aws_key"
    PRIVATE_KEY = "private_key"
    DATABASE_URL = "database_url"
    EMAIL = "email"
    INTERNAL_URL = "internal_url"


class SecretDetector:
    """Detect secrets and sensitive information in text"""

    # Patterns for common secrets
    PATTERNS = {
        SecretType.API_KEY: [
            r'api[_-]?key\s*[:=]\s*["\']?([a-zA-Z0-9_\-]{20,})["\']?',
            r'apikey\s*[:=]\s*["\']?([a-zA-Z0-9_\-]{20,})["\']?',
        ],
        SecretType.PASSWORD: [
            r'password\s*[:=]\s*["\']?([^\s"\']{8,})["\']?',
            r'pwd\s*[:=]\s*["\']?([^\s"\']{8,})["\']?',
        ],
        SecretType.TOKEN: [
            r'token\s*[:=]\s*["\']?([a-zA-Z0-9_\-]{20,})["\']?',
            r'bearer\s+([a-zA-Z0-9_\-\.]{20,})',
        ],
        SecretType.AWS_KEY: [
            r'AKIA[0-9A-Z]{16}',
            r'aws[_-]?access[_-]?key[_-]?id\s*[:=]\s*["\']?([A-Z0-9]{20})["\']?',
        ],
        SecretType.PRIVATE_KEY: [
            r'-----BEGIN\s+(RSA\s+)?PRIVATE\s+KEY-----',
            r'ssh-rsa\s+[A-Za-z0-9+/=]{100,}',
        ],
        SecretType.DATABASE_URL: [
            r'postgresql://[^\s]+',
            r'mysql://[^\s]+',
            r'mongodb://[^\s]+',
        ],
        SecretType.EMAIL: [
            r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
        ],
        SecretType.INTERNAL_URL: [
            r'https?://(?:internal|dev|staging|test)\.(?:paypal|paypalcorp)\.(?:com|net)',
            r'https?://[a-z0-9-]+\.(?:paypal|paypalcorp)\.(?:com|net)',
        ],
    }

    def detect_secrets(self, text: str) -> List[Dict]:
        """
        Detect secrets in text.

        Returns:
            List of dicts with keys: type, pattern, matched_text, position
        """
        secrets = []

        for secret_type, patterns in self.PATTERNS.items():
            for pattern in patterns:
                matches = re.finditer(pattern, text, re.IGNORECASE)
                for match in matches:
                    secrets.append({
                        'type': secret_type.value,
                        'pattern': pattern,
                        'matched_text': match.group(0)[:50] + '...' if len(match.group(0)) > 50 else match.group(0),
                        'position': match.start(),
                    })

        return secrets

    def has_secrets(self, text: str) -> bool:
        """Quick check if text contains secrets"""
        return len(self.detect_secrets(text)) > 0

    def redact_secrets(self, text: str, replacement: str = "[REDACTED]") -> str:
        """
        Redact secrets from text.

        Args:
            text: Text to redact
            replacement: String to replace secrets with

        Returns:
            Text with secrets redacted
        """
        redacted = text
        secrets = self.detect_secrets(text)

        # Sort by position descending to avoid index shifting
        secrets.sort(key=lambda x: x['position'], reverse=True)

        for secret in secrets:
            # Find the actual match
            pattern = secret['pattern']
            matches = list(re.finditer(pattern, redacted, re.IGNORECASE))
            if matches:
                # Replace last match (most recent position)
                match = matches[-1]
                redacted = redacted[:match.start()] + replacement + redacted[match.end():]

        return redacted
```

**Tests**: Create `backend/tests/test_secret_detector.py`

---

#### Day 2: Integrate Secret Detection into LLM Service

**File**: `backend/app/analysis/llm_service.py`

**Status**: ✅ **COMPLETED**

Modify LLM service to check for secrets before sending:

```python
from ..services.secret_detector import SecretDetector, SecretType

class LLMProvider(ABC):
    def __init__(self, api_key: str, enable_secret_detection: bool = True):
        self.api_key = api_key
        self.secret_detector = SecretDetector() if enable_secret_detection else None

    def _sanitize_for_llm(self, text: str, redact: bool = False) -> tuple[str, List[Dict]]:
        """
        Sanitize text before sending to LLM.

        Returns:
            Tuple of (sanitized_text, detected_secrets)
        """
        if not self.secret_detector:
            return text, []

        secrets = self.secret_detector.detect_secrets(text)

        if secrets:
            if redact:
                sanitized = self.secret_detector.redact_secrets(text)
            else:
                sanitized = text
            return sanitized, secrets

        return text, []

    def _check_secrets_before_send(self, text: str, raise_on_secret: bool = True) -> tuple[str, List[Dict]]:
        """
        Check for secrets and optionally raise error.

        Raises:
            ValueError if secrets detected and raise_on_secret=True
        """
        sanitized, secrets = self._sanitize_for_llm(text, redact=False)

        if secrets and raise_on_secret:
            secret_types = ', '.join(set(s['type'] for s in secrets))
            raise ValueError(
                f"Secrets detected in text: {secret_types}. "
                "Enable redaction or remove secrets before sending to LLM."
            )

        return sanitized, secrets
```

Update all LLM methods to use secret detection:

```python
def summarize_commits(self, commits: List[Commit], ...):
    # ... existing code ...

    commit_texts = []
    for commit in commits[:50]:
        commit_message = commit.message[:100]

        # Check for secrets
        try:
            sanitized_message, secrets = self._check_secrets_before_send(
                commit_message,
                raise_on_secret=True  # Block by default
            )
            commit_texts.append(f"- {commit.type or 'Unknown'}: {sanitized_message}")
        except ValueError as e:
            # Log warning and skip this commit
            logger.warning(f"Skipping commit {commit.hash[:8]}: {str(e)}")
            continue

    # ... rest of method ...
```

**API Endpoint**: Add endpoint to check secrets in text:

**File**: `backend/app/api/security.py` (new file)

```python
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel
from ..database import get_db
from ..services.secret_detector import SecretDetector

router = APIRouter(prefix="/api/security", tags=["security"])

class SecretCheckRequest(BaseModel):
    text: str

class SecretCheckResponse(BaseModel):
    has_secrets: bool
    secrets: List[Dict]
    redacted_text: Optional[str] = None

@router.post("/check-secrets", response_model=SecretCheckResponse)
def check_secrets(
    request: SecretCheckRequest,
    db: Session = Depends(get_db)
):
    """Check if text contains secrets"""
    detector = SecretDetector()
    secrets = detector.detect_secrets(request.text)

    return SecretCheckResponse(
        has_secrets=len(secrets) > 0,
        secrets=secrets,
        redacted_text=detector.redact_secrets(request.text) if secrets else None
    )
```

---

#### Day 3: Data Redaction UI & Settings

**File**: `frontend/src/components/SecuritySettings.tsx` (new)

**Status**: ✅ **COMPLETED**

Create settings component for security options:

```typescript
interface SecuritySettings {
  enableSecretDetection: boolean;
  autoRedactSecrets: boolean;
  blockOnSecret: boolean;
  redactEmails: boolean;
  redactInternalUrls: boolean;
}

export function SecuritySettings() {
  const [settings, setSettings] = useState<SecuritySettings>({
    enableSecretDetection: true,
    autoRedactSecrets: false,
    blockOnSecret: true,
    redactEmails: false,
    redactInternalUrls: false,
  });

  // ... implementation
}
```

**File**: `frontend/src/components/ReportGenerator.tsx`

Add toggle for redaction before generating reports:

```typescript
<label>
  <input
    type='checkbox'
    checked={redactSensitiveInfo}
    onChange={(e) => setRedactSensitiveInfo(e.target.checked)}
  />
  Redact sensitive information before sending to LLM
</label>
```

**File**: `backend/app/api/reports.py`

Add `redact_sensitive` parameter to report generation endpoint.

---

#### Day 4: Database Encryption (Optional)

**File**: `backend/app/database.py`

**Status**: ✅ **COMPLETED** (Optional - can be deferred)

Add support for SQLCipher encryption:

```python
from sqlalchemy import create_engine
from sqlalchemy.pool import StaticPool
import os

def get_encrypted_engine(db_path: str, password: str):
    """Create encrypted SQLite engine using SQLCipher"""
    try:
        from pysqlcipher3 import dbapi2 as sqlite3
    except ImportError:
        raise ImportError(
            "pysqlcipher3 not installed. Install with: pip install pysqlcipher3"
        )

    # SQLCipher connection string
    conn_string = f"sqlite+pysqlcipher://:{password}@{db_path}?cipher_compatibility=4"

    engine = create_engine(
        conn_string,
        poolclass=StaticPool,
        connect_args={
            'check_same_thread': False,
            'cipher_compatibility': 4
        }
    )

    return engine
```

**File**: `backend/app/config.py`

Add encryption settings:

```python
class Settings:
    # ... existing settings ...

    # Database encryption
    DB_ENCRYPTION_ENABLED: bool = False
    DB_ENCRYPTION_PASSWORD: Optional[str] = None
```

**Note**: This is optional and can be deferred if SQLCipher adds complexity.

---

### Task Group 2: Local LLM Support (2-3 days)

#### Day 1-2: Ollama Provider Implementation

**File**: `backend/app/analysis/llm_service.py`

**Status**: ✅ **COMPLETED**

Add Ollama provider:

```python
class OllamaProvider(LLMProvider):
    def __init__(self, base_url: str = "http://localhost:11434", model: str = "llama2"):
        self.base_url = base_url
        self.model = model

    def _get_client(self):
        import httpx
        return httpx.Client(base_url=self.base_url, timeout=120.0)

    def summarize_commits(self, commits: List[Commit], ...):
        # Similar implementation to OpenAIProvider
        # but using Ollama API format
        client = self._get_client()

        # Format commits
        commit_texts = []
        for commit in commits[:50]:
            commit_texts.append(f"- {commit.type or 'Unknown'}: {commit.message[:100]}")

        prompt = f"""Transform the following technical commits into a professional performance summary.

Commits:
{chr(10).join(commit_texts)}

Generate 5-7 bullet points highlighting key achievements:"""

        response = client.post(
            "/api/generate",
            json={
                "model": self.model,
                "prompt": prompt,
                "stream": False
            }
        )

        if response.status_code == 200:
            result = response.json()
            return result.get("response", "Error generating summary")
        else:
            raise Exception(f"Ollama API error: {response.status_code}")
```

**File**: `backend/app/config.py`

Add Ollama settings:

```python
class Settings:
    # ... existing settings ...

    # LLM Provider selection
    LLM_PROVIDER: str = "openai"  # "openai" | "gemini" | "ollama" | "local"
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_MODEL: str = "llama2"
```

**File**: `backend/app/analysis/llm_service.py`

Update provider factory:

```python
def get_llm_provider(settings: Settings) -> LLMProvider:
    """Factory function to get LLM provider based on settings"""
    provider = settings.LLM_PROVIDER.lower()

    if provider == "openai":
        if not settings.OPENAI_API_KEY:
            raise ValueError("OPENAI_API_KEY not set")
        return OpenAIProvider(api_key=settings.OPENAI_API_KEY)

    elif provider == "gemini":
        if not settings.GEMINI_API_KEY:
            raise ValueError("GEMINI_API_KEY not set")
        return GeminiProvider(api_key=settings.GEMINI_API_KEY)

    elif provider == "ollama":
        return OllamaProvider(
            base_url=settings.OLLAMA_BASE_URL,
            model=settings.OLLAMA_MODEL
        )

    else:
        raise ValueError(f"Unknown LLM provider: {provider}")
```

**File**: `frontend/src/components/Settings.tsx`

Add LLM provider selection:

```typescript
<select value={llmProvider} onChange={(e) => setLlmProvider(e.target.value)}>
  <option value='openai'>OpenAI (GPT-4)</option>
  <option value='gemini'>Google Gemini</option>
  <option value='ollama'>Ollama (Local)</option>
</select>
```

---

### Task Group 3: Data Completeness & Quality (3-4 days)

#### Day 1: Data Completeness Calculator

**File**: `backend/app/analysis/data_quality.py`

**Status**: ✅ **COMPLETED**

Create data completeness analyzer:

```python
from typing import Dict, List
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from ..models import Commit, FrictionLog, ManualEntry, CareerMoment, Goal

def calculate_data_completeness(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None
) -> Dict:
    """
    Calculate data completeness score (0-100).

    Checks:
    - Commits categorized
    - Friction logs with resolution
    - Manual entries with collaborators (for code reviews)
    - Career moments documented
    - Goals with status
    """
    if not start_date:
        start_date = datetime.now() - timedelta(days=90)
    if not end_date:
        end_date = datetime.now()

    # Get data
    commits = db.query(Commit).filter(
        Commit.date >= start_date,
        Commit.date <= end_date
    ).all()

    friction_logs = db.query(FrictionLog).filter(
        FrictionLog.date >= start_date,
        FrictionLog.date <= end_date
    ).all()

    manual_entries = db.query(ManualEntry).filter(
        ManualEntry.date >= start_date,
        ManualEntry.date <= end_date
    ).all()

    # Calculate scores
    total_score = 0
    max_score = 0
    issues = []
    recommendations = []

    # 1. Commits categorized (40% weight)
    max_score += 40
    uncategorized = [c for c in commits if c.type == 'Unknown' or not c.type]
    if commits:
        categorized_pct = (len(commits) - len(uncategorized)) / len(commits) * 100
        total_score += (categorized_pct / 100) * 40
        if uncategorized:
            issues.append({
                'type': 'uncategorized_commits',
                'count': len(uncategorized),
                'message': f"{len(uncategorized)} commits without category"
            })
            recommendations.append("Categorize commits to improve impact analysis")

    # 2. Friction logs with resolution (20% weight)
    max_score += 20
    if friction_logs:
        incidents = [f for f in friction_logs if f.type == 'incident']
        resolved = [f for f in incidents if f.resolution]
        if incidents:
            resolved_pct = len(resolved) / len(incidents) * 100
            total_score += (resolved_pct / 100) * 20
            unresolved = [f for f in incidents if not f.resolution]
            if unresolved:
                issues.append({
                    'type': 'unresolved_incidents',
                    'count': len(unresolved),
                    'message': f"{len(unresolved)} incidents without resolution"
                })
                recommendations.append("Add resolution to incidents to improve MTTR tracking")

    # 3. Manual entries completeness (20% weight)
    max_score += 20
    code_reviews = [m for m in manual_entries if m.type == 'code_review']
    if code_reviews:
        with_collaborators = [m for m in code_reviews if m.collaborators]
        complete_pct = len(with_collaborators) / len(code_reviews) * 100
        total_score += (complete_pct / 100) * 20
        incomplete = [m for m in code_reviews if not m.collaborators]
        if incomplete:
            issues.append({
                'type': 'incomplete_code_reviews',
                'count': len(incomplete),
                'message': f"{len(incomplete)} code reviews without collaborators"
            })
            recommendations.append("Add collaborators to code reviews for better collaboration metrics")

    # 4. Career moments documented (10% weight)
    max_score += 10
    moments = db.query(CareerMoment).filter(
        CareerMoment.date >= start_date,
        CareerMoment.date <= end_date
    ).count()
    # Recommend documenting moments if there are significant commits but no moments
    if len(commits) > 50 and moments == 0:
        recommendations.append("Document career moments to enrich your performance narrative")
        total_score += 5  # Partial credit
    else:
        total_score += 10

    # 5. Goals tracking (10% weight)
    max_score += 10
    goals = db.query(Goal).filter(
        Goal.created_at >= start_date
    ).all()
    if goals:
        with_status = [g for g in goals if g.status]
        if goals:
            tracked_pct = len(with_status) / len(goals) * 100
            total_score += (tracked_pct / 100) * 10

    overall_score = (total_score / max_score * 100) if max_score > 0 else 100

    return {
        'overall_score': round(overall_score, 1),
        'breakdown': {
            'commits_categorized': {
                'score': round((len(commits) - len(uncategorized)) / len(commits) * 100, 1) if commits else 100,
                'total': len(commits),
                'incomplete': len(uncategorized)
            },
            'incidents_resolved': {
                'score': round(len(resolved) / len(incidents) * 100, 1) if incidents else 100,
                'total': len(incidents),
                'incomplete': len(unresolved) if incidents else 0
            },
            'code_reviews_complete': {
                'score': round(len(with_collaborators) / len(code_reviews) * 100, 1) if code_reviews else 100,
                'total': len(code_reviews),
                'incomplete': len(incomplete) if code_reviews else 0
            }
        },
        'issues': issues,
        'recommendations': recommendations,
        'period': {
            'start': start_date.isoformat(),
            'end': end_date.isoformat()
        }
    }
```

---

#### Day 2: Data Completeness API & Dashboard

**File**: `backend/app/api/data_quality.py` (new)

**Status**: ✅ **COMPLETED**

```python
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from ..database import get_db
from ..analysis.data_quality import calculate_data_completeness

router = APIRouter(prefix="/api/data-quality", tags=["data-quality"])

@router.get("/completeness")
def get_data_completeness(
    days: int = Query(90, ge=1, le=365),
    db: Session = Depends(get_db)
):
    """Get data completeness score and recommendations"""
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)

    return calculate_data_completeness(db, start_date, end_date)
```

**File**: `frontend/src/components/DataQualityDashboard.tsx` (new)

**Status**: ✅ **COMPLETED**

Create dashboard component showing:

- Overall completeness score (0-100%)
- Breakdown by category
- List of issues
- Recommendations

---

#### Day 3: Smart Reminders System

**File**: `backend/app/analysis/data_quality.py`

**Status**: ✅ **COMPLETED**

Add reminder generator:

```python
def generate_smart_reminders(
    db: Session,
    days: int = 7
) -> List[Dict]:
    """
    Generate contextual reminders based on patterns.

    Examples:
    - "You haven't logged friction this week" (if commits but no friction)
    - "You have 5 code reviews but no manual entries"
    - "3 incidents without resolution"
    """
    reminders = []
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)

    # Check for commits without friction logs
    commits = db.query(Commit).filter(
        Commit.date >= start_date
    ).count()

    friction_logs = db.query(FrictionLog).filter(
        FrictionLog.date >= start_date
    ).count()

    if commits > 10 and friction_logs == 0:
        reminders.append({
            'type': 'missing_friction',
            'priority': 'medium',
            'message': f"You have {commits} commits this week but no friction logs. Consider logging blockers or wins.",
            'action': 'log_friction'
        })

    # Check for incidents without resolution
    incidents = db.query(FrictionLog).filter(
        FrictionLog.date >= start_date,
        FrictionLog.type == 'incident',
        FrictionLog.resolution == None
    ).all()

    if incidents:
        reminders.append({
            'type': 'unresolved_incidents',
            'priority': 'high',
            'message': f"You have {len(incidents)} incident(s) without resolution. Add resolution to improve MTTR tracking.",
            'action': 'resolve_incidents',
            'count': len(incidents)
        })

    # Check for hotfix commits without friction logs
    hotfix_commits = db.query(Commit).filter(
        Commit.date >= start_date,
        Commit.message.ilike('%hotfix%')
    ).all()

    if hotfix_commits:
        # Check if any have associated friction logs
        hotfix_with_friction = 0
        for commit in hotfix_commits:
            # Check if there's a friction log around the same time
            friction = db.query(FrictionLog).filter(
                FrictionLog.date >= commit.date - timedelta(hours=24),
                FrictionLog.date <= commit.date + timedelta(hours=24),
                FrictionLog.type == 'incident'
            ).first()
            if friction:
                hotfix_with_friction += 1

        if hotfix_with_friction < len(hotfix_commits):
            reminders.append({
                'type': 'hotfix_without_friction',
                'priority': 'medium',
                'message': f"You have {len(hotfix_commits) - hotfix_with_friction} hotfix commit(s) without associated incident logs.",
                'action': 'log_incident'
            })

    return reminders
```

**File**: `backend/app/api/data_quality.py`

Add reminders endpoint:

```python
@router.get("/reminders")
def get_reminders(
    days: int = Query(7, ge=1, le=30),
    db: Session = Depends(get_db)
):
    """Get smart reminders for data quality"""
    from ..analysis.data_quality import generate_smart_reminders
    return generate_smart_reminders(db, days)
```

**File**: `frontend/src/components/RemindersPanel.tsx` (new)

Display reminders in dashboard sidebar.

---

#### Day 4: Validation Warnings

**File**: `backend/app/analysis/data_quality.py`

**Status**: ✅ **COMPLETED**

Add validation warnings:

```python
def generate_validation_warnings(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None
) -> List[Dict]:
    """
    Generate proactive validation warnings.

    Examples:
    - "3 incidents without resolution - add resolution for better MTTR"
    - "Commits of hotfix without friction log"
    - "Manual entries without collaborators (code reviews)"
    """
    warnings = []

    if not start_date:
        start_date = datetime.now() - timedelta(days=90)
    if not end_date:
        end_date = datetime.now()

    # Incidents without resolution
    incidents = db.query(FrictionLog).filter(
        FrictionLog.date >= start_date,
        FrictionLog.date <= end_date,
        FrictionLog.type == 'incident',
        FrictionLog.resolution == None
    ).all()

    if incidents:
        warnings.append({
            'type': 'incident_no_resolution',
            'severity': 'medium',
            'message': f"{len(incidents)} incident(s) without resolution",
            'recommendation': 'Add resolution to improve MTTR calculation',
            'count': len(incidents),
            'items': [{'id': i.id, 'date': i.date.isoformat()} for i in incidents[:5]]
        })

    # Code reviews without collaborators
    code_reviews = db.query(ManualEntry).filter(
        ManualEntry.date >= start_date,
        ManualEntry.date <= end_date,
        ManualEntry.type == 'code_review',
        ManualEntry.collaborators == None
    ).all()

    if code_reviews:
        warnings.append({
            'type': 'code_review_no_collaborators',
            'severity': 'low',
            'message': f"{len(code_reviews)} code review(s) without collaborators",
            'recommendation': 'Add collaborators to improve collaboration metrics',
            'count': len(code_reviews)
        })

    # Hotfix commits without incident logs
    hotfix_commits = db.query(Commit).filter(
        Commit.date >= start_date,
        Commit.date <= end_date,
        Commit.message.ilike('%hotfix%')
    ).all()

    if hotfix_commits:
        # Check which ones don't have associated incidents
        hotfix_without_incident = []
        for commit in hotfix_commits:
            incident = db.query(FrictionLog).filter(
                FrictionLog.date >= commit.date - timedelta(hours=48),
                FrictionLog.date <= commit.date + timedelta(hours=24),
                FrictionLog.type == 'incident'
            ).first()
            if not incident:
                hotfix_without_incident.append(commit)

        if hotfix_without_incident:
            warnings.append({
                'type': 'hotfix_without_incident',
                'severity': 'medium',
                'message': f"{len(hotfix_without_incident)} hotfix commit(s) without associated incident log",
                'recommendation': 'Log incident to track change failure rate',
                'count': len(hotfix_without_incident)
            })

    return warnings
```

**File**: `backend/app/api/data_quality.py`

Add warnings endpoint:

```python
@router.get("/warnings")
def get_validation_warnings(
    days: int = Query(90, ge=1, le=365),
    db: Session = Depends(get_db)
):
    """Get validation warnings"""
    from ..analysis.data_quality import generate_validation_warnings
    from datetime import datetime, timedelta

    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)

    return generate_validation_warnings(db, start_date, end_date)
```

---

### Task Group 4: Testing & Reliability (2-3 days)

#### Day 1: Unit Tests for Metrics Calculations

**File**: `backend/tests/test_metrics.py` (new)

**Status**: ✅ **COMPLETED**

Create unit tests for critical metric calculations:

```python
import pytest
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from app.analysis.metrics import calculate_performance_metrics
from app.analysis.dora_metrics import calculate_dora_metrics
from app.analysis.space_metrics import calculate_space_metrics
from app.models import Commit, FrictionLog, ManualEntry

def test_dora_metrics_empty_data(db: Session):
    """Test DORA metrics with no data"""
    metrics = calculate_dora_metrics(db)

    assert metrics['deployment_frequency'] == 0
    assert metrics['lead_time'] is None
    assert metrics['change_failure_rate'] == 0
    assert metrics['mttr'] is None

def test_dora_metrics_with_commits(db: Session):
    """Test DORA metrics with sample commits"""
    # Create test commits
    commit1 = Commit(
        hash="abc123",
        message="feat: add new feature",
        date=datetime.now() - timedelta(days=5),
        files_changed=10,
        insertions=100,
        deletions=20,
        type="feature"
    )
    db.add(commit1)
    db.commit()

    metrics = calculate_dora_metrics(db)
    assert metrics['deployment_frequency'] >= 0

def test_space_metrics_calculation(db: Session):
    """Test SPACE metrics calculation"""
    metrics = calculate_space_metrics(db)

    assert 'satisfaction' in metrics
    assert 'performance' in metrics
    assert 'activity' in metrics
    assert 'collaboration' in metrics
    assert 'efficiency' in metrics

    # All scores should be 0-10
    for key, value in metrics.items():
        if isinstance(value, (int, float)):
            assert 0 <= value <= 10

def test_metrics_edge_cases(db: Session):
    """Test metrics with edge cases"""
    # Test with single commit
    commit = Commit(
        hash="single",
        message="test",
        date=datetime.now(),
        files_changed=1,
        insertions=1,
        deletions=0,
        type="fix"
    )
    db.add(commit)
    db.commit()

    metrics = calculate_performance_metrics(db)
    assert metrics is not None
```

**File**: `backend/tests/test_data_quality.py` (new)

Test data quality calculations:

```python
def test_data_completeness_empty(db: Session):
    """Test completeness with no data"""
    from app.analysis.data_quality import calculate_data_completeness

    result = calculate_data_completeness(db)
    assert result['overall_score'] == 100  # Perfect if no data

def test_data_completeness_with_uncategorized(db: Session):
    """Test completeness with uncategorized commits"""
    from app.analysis.data_quality import calculate_data_completeness
    from app.models import Commit
    from datetime import datetime

    commit = Commit(
        hash="test",
        message="wip",
        date=datetime.now(),
        files_changed=1,
        insertions=1,
        deletions=0,
        type="Unknown"
    )
    db.add(commit)
    db.commit()

    result = calculate_data_completeness(db)
    assert result['overall_score'] < 100
    assert len(result['issues']) > 0
```

---

#### Day 2: Integration Tests for Report Generation

**File**: `backend/tests/test_report_generation.py` (new)

**Status**: ✅ **COMPLETED**

Create integration tests:

```python
import pytest
from datetime import datetime, timedelta
from app.services.report_generator import ReportGenerator
from app.models import Commit, FrictionLog, ManualEntry

def test_report_generation_with_mock_llm(db: Session, monkeypatch):
    """Test report generation with mocked LLM"""
    # Create test data
    commit = Commit(
        hash="test123",
        message="feat: add feature",
        date=datetime.now(),
        files_changed=5,
        insertions=50,
        deletions=10,
        type="feature"
    )
    db.add(commit)
    db.commit()

    # Mock LLM response
    def mock_llm_summary(*args, **kwargs):
        return "Test summary"

    monkeypatch.setattr(
        "app.analysis.llm_service.OpenAIProvider.summarize_commits",
        mock_llm_summary
    )

    generator = ReportGenerator(db)
    report = generator.generate_report(
        start_date=datetime.now() - timedelta(days=30),
        end_date=datetime.now()
    )

    assert report is not None
    assert 'executive_summary' in report
    assert 'metrics' in report

def test_report_generation_fallback_on_llm_error(db: Session, monkeypatch):
    """Test report generation falls back when LLM fails"""
    # Mock LLM to raise error
    def mock_llm_error(*args, **kwargs):
        raise Exception("LLM API error")

    monkeypatch.setattr(
        "app.analysis.llm_service.OpenAIProvider.summarize_commits",
        mock_llm_error
    )

    generator = ReportGenerator(db)
    report = generator.generate_report(
        start_date=datetime.now() - timedelta(days=30),
        end_date=datetime.now()
    )

    # Should still generate report with template fallback
    assert report is not None
    assert 'executive_summary' in report

def test_report_export_formats(db: Session):
    """Test report export in different formats"""
    generator = ReportGenerator(db)

    # Generate report
    report_data = generator.generate_report(
        start_date=datetime.now() - timedelta(days=30),
        end_date=datetime.now()
    )

    # Test Markdown export
    markdown = generator.export_markdown(report_data)
    assert markdown is not None
    assert "#" in markdown  # Should have headers

    # Test JSON export
    json_data = generator.export_json(report_data)
    assert json_data is not None
    assert 'executive_summary' in json_data
```

---

#### Day 3: Test Setup & CI Integration

**File**: `backend/pytest.ini` (new)

**Status**: ✅ **COMPLETED**

```ini
[pytest]
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
addopts =
    -v
    --tb=short
    --strict-markers
markers =
    unit: Unit tests
    integration: Integration tests
    slow: Slow running tests
```

**File**: `backend/tests/conftest.py` (new)

```python
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.database import Base
from app.database import get_db

# Create test database
SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"
engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

@pytest.fixture
def db():
    """Create test database session"""
    Base.metadata.create_all(bind=engine)
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()
        Base.metadata.drop_all(bind=engine)
```

**File**: `backend/requirements.txt`

Add testing dependencies:

```
pytest>=7.4.0
pytest-asyncio>=0.21.0
pytest-cov>=4.1.0
```

---

## 🎯 Implementation Order

### Week 1: Security Foundations

1. **Day 1-2**: Secret detection service
2. **Day 3**: Integrate secret detection into LLM service
3. **Day 4**: Data redaction UI and settings
4. **Day 5**: Local LLM support (Ollama)

### Week 2: Data Quality

1. **Day 1**: Data completeness calculator
2. **Day 2**: Data completeness API and dashboard
3. **Day 3**: Smart reminders system
4. **Day 4**: Validation warnings

### Week 3: Testing

1. **Day 1**: Unit tests for metrics
2. **Day 2**: Integration tests for reports
3. **Day 3**: Test setup and documentation

---

## ✅ Success Criteria Checklist

### Security & Privacy

- [ ] Secret detection prevents API keys, passwords, tokens from being sent to LLM
- [ ] Data redaction option available in UI
- [ ] Commits with secrets are flagged and blocked by default
- [ ] Local LLM (Ollama) can be used as alternative provider
- [ ] Settings page allows configuration of security options

### Data Quality

- [ ] Data completeness dashboard shows score (0-100%)
- [ ] Breakdown by category (commits, friction, manual entries)
- [ ] Smart reminders appear based on patterns
- [ ] Validation warnings proactively identify issues
- [ ] Recommendations guide users to improve data quality

### Testing

- [ ] Unit tests for DORA metrics calculations
- [ ] Unit tests for SPACE metrics calculations
- [ ] Unit tests for data quality calculations
- [ ] Integration tests for report generation
- [ ] Tests handle edge cases (empty data, errors)
- [ ] Test coverage > 60% for critical paths

---

## 📝 Notes & Considerations

### Secret Detection

- **False positives**: Some patterns may match non-secrets (e.g., long commit hashes)
- **Solution**: Allow users to whitelist false positives
- **Performance**: Regex patterns are fast, but consider caching for large batches

### Data Quality

- **Reminders frequency**: Don't spam users - show reminders once per day max
- **Recommendations**: Keep actionable and specific
- **Scoring**: Balance between completeness and not being too strict

### Testing

- **Test data**: Use fixtures to create consistent test scenarios
- **Mocking**: Mock LLM APIs to avoid costs and external dependencies
- **Coverage**: Focus on critical paths first (metrics, reports)

### Local LLM

- **Performance**: Local LLMs are slower - set appropriate timeouts
- **Model selection**: Recommend models that work well for summarization
- **Fallback**: If Ollama unavailable, fall back to cloud provider

---

## 🚀 Next Steps After Sprint 8

After completing Sprint 8, the tool will be:

- ✅ Secure (secret detection, redaction, local LLM option)
- ✅ Data quality validated (completeness tracking, reminders)
- ✅ Tested (critical paths covered)

**Recommended next sprint**: Sprint 9 (Narrative Quality & Context Enrichment) to improve report quality, or continue with integration ecosystem (Sprint 10).

---

## 📚 Related Documentation

- `docs/IMPROVEMENT_ROADMAP.md` - Overall roadmap
- `docs/SPRINT_7_FINAL_IMPROVEMENTS.md` - Previous sprint
- `docs/METRICS_SPECIFICATION.md` - Metrics definitions
