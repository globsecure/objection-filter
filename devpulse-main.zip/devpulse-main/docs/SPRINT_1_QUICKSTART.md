# 🚀 Sprint 1 Quick Start - Friction Tracker & Manual Entries

**Goal**: Make DevPulse immediately useful by capturing the context that git history misses.

**Timeline**: 1-2 weeks

**Status**: ✅ **COMPLETO** - Implementado em 26/12/2024

**Success Criteria**: You can log your entire workday (commits + context) in < 5 minutes.

---

## ✅ Implementation Summary

Sprint 1 foi implementado com sucesso! Todas as funcionalidades principais estão funcionais:

### ✅ Friction Tracker
- ✅ Tabela `friction_logs` criada (migration `7065c5d1b1a2`)
- ✅ API endpoints implementados (`POST /api/friction`, `GET /api/friction`, `GET /api/friction/stats`)
- ✅ Componente `FrictionLogger` criado (`frontend/src/components/FrictionLogger.tsx`)
- ✅ Componente `FrictionDashboard` criado (`frontend/src/components/FrictionDashboard.tsx`)
- ✅ Página atualizada com tabs (`frontend/src/pages/FrictionPage.tsx`)

### ✅ Manual Entries
- ✅ Tabela `manual_entries` criada (migration `7065c5d1b1a2`)
- ✅ API endpoints CRUD implementados (`backend/app/api/manual_entries.py`)
- ✅ Componente `ManualEntryForm` criado com campos condicionais (`frontend/src/components/ManualEntryForm.tsx`)
- ✅ Página `ManualEntriesPage` criada (`frontend/src/pages/ManualEntriesPage.tsx`)

### ✅ Unified Timeline
- ✅ Componente `WorkTimeline` criado (`frontend/src/components/WorkTimeline.tsx`)
- ✅ Integra commits + friction logs + manual entries
- ✅ Página `TimelinePage` criada (`frontend/src/pages/TimelinePage.tsx`)
- ✅ Agrupamento por data e ordenação cronológica

### 📁 Arquivos Criados/Modificados

**Backend:**
- `backend/app/models.py` - Adicionados modelos `FrictionLog` e `ManualEntry`
- `backend/app/schemas.py` - Adicionados schemas Pydantic
- `backend/app/api/friction.py` - Endpoints FrictionLog adicionados
- `backend/app/api/manual_entries.py` - Novo arquivo com CRUD completo
- `backend/app/main.py` - Router de manual entries registrado
- `backend/alembic/versions/7065c5d1b1a2_*.py` - Migration criada

**Frontend:**
- `frontend/src/types/index.ts` - Interfaces TypeScript adicionadas
- `frontend/src/services/api.ts` - Métodos API adicionados
- `frontend/src/components/FrictionLogger.tsx` - Novo componente
- `frontend/src/components/FrictionDashboard.tsx` - Novo componente
- `frontend/src/components/ManualEntryForm.tsx` - Novo componente
- `frontend/src/components/WorkTimeline.tsx` - Novo componente
- `frontend/src/pages/FrictionPage.tsx` - Atualizado com tabs
- `frontend/src/pages/ManualEntriesPage.tsx` - Nova página
- `frontend/src/pages/TimelinePage.tsx` - Nova página
- `frontend/src/App.tsx` - Rotas e navegação adicionadas

---

---

## 📋 Tasks Breakdown

### Task Group 1: Friction Tracker (3-4 days)

#### Day 1: Database Schema ✅ COMPLETO

**File**: `backend/app/models.py`

**Status**: ✅ Implementado

Add new model:

```python
class FrictionLog(Base):
    __tablename__ = "friction_logs"

    id = Column(Integer, primary_key=True, index=True)
    date = Column(DateTime, default=datetime.utcnow, nullable=False)
    type = Column(String)  # 'blocker' | 'learning' | 'win' | 'incident'
    description = Column(Text, nullable=False)
    impact_level = Column(Integer)  # 1-5 scale
    tags = Column(String)  # comma-separated
    resolution = Column(Text)  # optional: how it was resolved
    created_at = Column(DateTime, default=datetime.utcnow)
```

**File**: `backend/app/schemas.py`

Add Pydantic schemas:

```python
class FrictionLogBase(BaseModel):
    date: datetime
    type: str
    description: str
    impact_level: int
    tags: Optional[str] = None
    resolution: Optional[str] = None

class FrictionLogCreate(FrictionLogBase):
    pass

class FrictionLogResponse(FrictionLogBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True
```

Run migration:

```bash
cd backend
source venv/bin/activate
alembic revision --autogenerate -m "add friction logs table"
alembic upgrade head
```

**✅ Implementado**: Migration `7065c5d1b1a2_add_friction_logs_and_manual_entries_.py` criada e aplicada.

---

#### Day 2: API Endpoints ✅ COMPLETO

**File**: `backend/app/api/friction.py` (ENHANCED - endpoints adicionados ao arquivo existente)

**Status**: ✅ Implementado - Endpoints FrictionLog adicionados ao arquivo existente que já tinha DailyLog endpoints

```python
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, timedelta
from ..database import get_db
from ..models import FrictionLog
from ..schemas import FrictionLogCreate, FrictionLogResponse

router = APIRouter(prefix="/api/friction", tags=["friction"])

@router.post("/", response_model=FrictionLogResponse)
def create_friction_log(
    friction: FrictionLogCreate,
    db: Session = Depends(get_db)
):
    """Log a friction point"""
    db_friction = FrictionLog(**friction.model_dump())
    db.add(db_friction)
    db.commit()
    db.refresh(db_friction)
    return db_friction

@router.get("/", response_model=List[FrictionLogResponse])
def get_friction_logs(
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    type: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """Get friction logs with optional filters"""
    query = db.query(FrictionLog)

    if start_date:
        query = query.filter(FrictionLog.date >= start_date)
    if end_date:
        query = query.filter(FrictionLog.date <= end_date)
    if type:
        query = query.filter(FrictionLog.type == type)

    return query.order_by(FrictionLog.date.desc()).all()

@router.get("/stats")
def get_friction_stats(
    days: int = 30,
    db: Session = Depends(get_db)
):
    """Get friction statistics"""
    start = datetime.now() - timedelta(days=days)
    logs = db.query(FrictionLog).filter(FrictionLog.date >= start).all()

    from collections import Counter
    types_count = Counter(log.type for log in logs)

    return {
        "total": len(logs),
        "by_type": dict(types_count),
        "avg_impact": sum(log.impact_level for log in logs) / len(logs) if logs else 0,
        "unresolved": len([log for log in logs if not log.resolution])
    }
```

Register in `backend/app/main.py`:

```python
from .api import friction

app.include_router(friction.router)
```

---

#### Day 3: Frontend Component ✅ COMPLETO

**File**: `frontend/src/components/FrictionLogger.tsx`

**Status**: ✅ Implementado - Componente criado com formulário otimizado para < 30s

```typescript
import React, { useState } from 'react';
import { api } from '../services/api';

interface FrictionForm {
  type: 'blocker' | 'learning' | 'win' | 'incident';
  description: string;
  impact_level: number;
  tags: string;
  resolution?: string;
}

export function FrictionLogger() {
  const [form, setForm] = useState<FrictionForm>({
    type: 'blocker',
    description: '',
    impact_level: 3,
    tags: '',
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await api.createFrictionLog({
        ...form,
        date: new Date().toISOString(),
      });

      // Reset form
      setForm({
        type: 'blocker',
        description: '',
        impact_level: 3,
        tags: '',
      });

      alert('Friction logged successfully!');
    } catch (error) {
      alert('Failed to log friction');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className='bg-white rounded-lg shadow p-6'>
      <h2 className='text-xl font-bold mb-4'>Log Friction Point</h2>

      <form onSubmit={handleSubmit} className='space-y-4'>
        {/* Type selector */}
        <div>
          <label className='block text-sm font-medium mb-2'>Type</label>
          <div className='flex gap-2'>
            {(['blocker', 'learning', 'win', 'incident'] as const).map(
              (type) => (
                <button
                  key={type}
                  type='button'
                  onClick={() => setForm({ ...form, type })}
                  className={`px-4 py-2 rounded ${
                    form.type === type
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-200 text-gray-700'
                  }`}
                >
                  {type === 'blocker' && '🚫'}
                  {type === 'learning' && '💡'}
                  {type === 'win' && '🎉'}
                  {type === 'incident' && '🔥'} {type.charAt(0).toUpperCase() + type.slice(1)}
                </button>
              )
            )}
          </div>
        </div>

        {/* Description */}
        <div>
          <label className='block text-sm font-medium mb-2'>
            What happened?
          </label>
          <textarea
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            placeholder='e.g., Build pipeline was down for 2 hours blocking deployment'
            className='w-full border rounded px-3 py-2 min-h-[100px]'
            required
          />
        </div>

        {/* Impact level */}
        <div>
          <label className='block text-sm font-medium mb-2'>
            Impact Level: {form.impact_level}/5
          </label>
          <input
            type='range'
            min='1'
            max='5'
            value={form.impact_level}
            onChange={(e) =>
              setForm({ ...form, impact_level: parseInt(e.target.value) })
            }
            className='w-full'
          />
          <div className='flex justify-between text-xs text-gray-500'>
            <span>Minor</span>
            <span>Major</span>
          </div>
        </div>

        {/* Tags */}
        <div>
          <label className='block text-sm font-medium mb-2'>
            Tags (comma-separated)
          </label>
          <input
            type='text'
            value={form.tags}
            onChange={(e) => setForm({ ...form, tags: e.target.value })}
            placeholder='ci-cd, devops, infrastructure'
            className='w-full border rounded px-3 py-2'
          />
        </div>

        {/* Resolution (optional) */}
        {(form.type === 'blocker' || form.type === 'incident') && (
          <div>
            <label className='block text-sm font-medium mb-2'>
              Resolution (optional)
            </label>
            <input
              type='text'
              value={form.resolution || ''}
              onChange={(e) => setForm({ ...form, resolution: e.target.value })}
              placeholder='How was it resolved?'
              className='w-full border rounded px-3 py-2'
            />
          </div>
        )}

        <button
          type='submit'
          disabled={loading}
          className='w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600 disabled:opacity-50'
        >
          {loading ? 'Logging...' : 'Log Friction'}
        </button>
      </form>
    </div>
  );
}
```

---

#### Day 4: Friction Dashboard View ✅ COMPLETO

**File**: `frontend/src/components/FrictionDashboard.tsx`

**Status**: ✅ Implementado - Dashboard com stats, filtros e timeline de logs

```typescript
import React, { useEffect, useState } from 'react';
import { api, FrictionLog } from '../services/api';

export function FrictionDashboard() {
  const [logs, setLogs] = useState<FrictionLog[]>([]);
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const [logsData, statsData] = await Promise.all([
      api.getFrictionLogs(),
      api.getFrictionStats(),
    ]);
    setLogs(logsData);
    setStats(statsData);
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'blocker':
        return '🚫';
      case 'learning':
        return '💡';
      case 'win':
        return '🎉';
      case 'incident':
        return '🔥';
      default:
        return '📝';
    }
  };

  const getImpactColor = (level: number) => {
    if (level >= 4) return 'text-red-600';
    if (level >= 3) return 'text-orange-600';
    return 'text-gray-600';
  };

  return (
    <div className='space-y-6'>
      {/* Stats Summary */}
      {stats && (
        <div className='grid grid-cols-4 gap-4'>
          <div className='bg-white rounded-lg shadow p-4'>
            <div className='text-2xl font-bold'>{stats.total}</div>
            <div className='text-sm text-gray-600'>Total Logs</div>
          </div>
          {Object.entries(stats.by_type).map(([type, count]) => (
            <div key={type} className='bg-white rounded-lg shadow p-4'>
              <div className='text-2xl font-bold'>
                {getIcon(type)} {count as number}
              </div>
              <div className='text-sm text-gray-600 capitalize'>{type}s</div>
            </div>
          ))}
        </div>
      )}

      {/* Logs Timeline */}
      <div className='bg-white rounded-lg shadow'>
        <div className='p-4 border-b'>
          <h2 className='text-xl font-bold'>Recent Friction Logs</h2>
        </div>
        <div className='divide-y'>
          {logs.map((log) => (
            <div key={log.id} className='p-4 hover:bg-gray-50'>
              <div className='flex items-start gap-3'>
                <div className='text-2xl'>{getIcon(log.type)}</div>
                <div className='flex-1'>
                  <div className='flex items-center gap-2'>
                    <span className='font-medium capitalize'>{log.type}</span>
                    <span
                      className={`text-sm ${getImpactColor(log.impact_level)}`}
                    >
                      Impact: {log.impact_level}/5
                    </span>
                    <span className='text-sm text-gray-500'>
                      {new Date(log.date).toLocaleDateString()}
                    </span>
                  </div>
                  <p className='mt-1 text-gray-700'>{log.description}</p>
                  {log.tags && (
                    <div className='mt-2 flex gap-2'>
                      {log.tags.split(',').map((tag) => (
                        <span
                          key={tag}
                          className='px-2 py-1 bg-gray-100 text-xs rounded'
                        >
                          {tag.trim()}
                        </span>
                      ))}
                    </div>
                  )}
                  {log.resolution && (
                    <div className='mt-2 text-sm text-green-600'>
                      ✅ {log.resolution}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
```

Add to `frontend/src/services/api.ts`:

```typescript
export interface FrictionLog {
  id: number;
  date: string;
  type: string;
  description: string;
  impact_level: number;
  tags?: string;
  resolution?: string;
}

export const api = {
  // ... existing methods ...

  createFrictionLog: async (
    data: Omit<FrictionLog, 'id'>
  ): Promise<FrictionLog> => {
    const response = await fetch(`${API_BASE}/friction`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return response.json();
  },

  getFrictionLogs: async (): Promise<FrictionLog[]> => {
    const response = await fetch(`${API_BASE}/friction`);
    return response.json();
  },

  getFrictionStats: async (): Promise<any> => {
    const response = await fetch(`${API_BASE}/friction/stats`);
    return response.json();
  },
};
```

---

### Task Group 2: Manual Entries (3-4 days)

#### Day 5: Database Schema ✅ COMPLETO

**File**: `backend/app/models.py`

**Status**: ✅ Implementado - Modelo ManualEntry adicionado junto com FrictionLog

```python
class ManualEntry(Base):
    __tablename__ = "manual_entries"

    id = Column(Integer, primary_key=True, index=True)
    date = Column(DateTime, nullable=False)
    type = Column(String, nullable=False)  # 'code_review' | 'design_doc' | 'mentoring' | 'incident' | 'meeting'
    title = Column(String, nullable=False)
    description = Column(Text)
    impact = Column(Text)  # Business impact description
    collaborators = Column(String)  # Comma-separated names
    links = Column(String)  # URLs (PR, doc, Jira, etc)
    duration_minutes = Column(Integer)  # Optional: time spent
    created_at = Column(DateTime, default=datetime.utcnow)
```

Schema:

```python
class ManualEntryBase(BaseModel):
    date: datetime
    type: str
    title: str
    description: Optional[str] = None
    impact: Optional[str] = None
    collaborators: Optional[str] = None
    links: Optional[str] = None
    duration_minutes: Optional[int] = None

class ManualEntryCreate(ManualEntryBase):
    pass

class ManualEntryResponse(ManualEntryBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True
```

---

#### Day 6-7: API & Frontend ✅ COMPLETO

**Status**: ✅ Implementado

- ✅ Created `backend/app/api/manual_entries.py` - CRUD completo implementado
- ✅ Created `frontend/src/components/ManualEntryForm.tsx` - Formulário com campos condicionais
- ✅ Created `frontend/src/components/WorkTimeline.tsx` - Timeline unificada implementada
- ✅ Created `frontend/src/pages/ManualEntriesPage.tsx` - Página completa com listagem

---

#### Day 8: Integration & Testing ✅ COMPLETO

**Status**: ✅ Implementado - Timeline unificada criada e integrada

**Create unified timeline view** that shows:

```
Dec 26, 2024
├─ 09:30 - Commit: "Add user authentication" (feature)
├─ 11:00 - Code Review: "Reviewed payment gateway PR for @john"
├─ 14:00 - Friction Log: "CI pipeline was slow (3/5 impact)"
└─ 16:00 - Commit: "Fix authentication bug" (bugfix)
```

---

## 🎯 Testing Your Implementation

### Manual Test Plan

1. **Friction Logger Test**:

```bash
# Terminal 1: Start backend
cd backend
source venv/bin/activate
uvicorn app.main:app --reload

# Terminal 2: Test API
curl -X POST http://localhost:8000/api/friction \
  -H "Content-Type: application/json" \
  -d '{
    "date": "2024-12-26T10:00:00",
    "type": "blocker",
    "description": "Database migration failed",
    "impact_level": 4,
    "tags": "database,infrastructure"
  }'
```

2. **Frontend Test**:

- Open `http://localhost:5173`
- Navigate to Friction page
- Log 3 different types of friction
- Verify they appear in dashboard
- Check stats update correctly

3. **Integration Test**:

- Log a commit (via git scan)
- Log a manual entry (code review)
- Log a friction (blocker)
- View unified timeline
- Verify all three appear on same day

---

## 🎨 UI Mockup Goals

### Friction Logger (Simple Form)

```
┌─────────────────────────────────┐
│ Log Friction Point              │
├─────────────────────────────────┤
│ Type: [🚫][💡][🎉][🔥]         │
│                                 │
│ Description:                    │
│ ┌─────────────────────────────┐ │
│ │                             │ │
│ └─────────────────────────────┘ │
│                                 │
│ Impact: ●●●○○ (3/5)            │
│                                 │
│ Tags: ci-cd, infrastructure     │
│                                 │
│ [Log Friction]                  │
└─────────────────────────────────┘
```

### Timeline View (Integrated)

```
┌─────────────────────────────────────┐
│ Work Timeline - Dec 26, 2024       │
├─────────────────────────────────────┤
│ 09:30 📝 Commit                     │
│       "Add user authentication"     │
│       +234 -12 lines                │
│                                     │
│ 11:00 👀 Code Review                │
│       Payment gateway PR            │
│       with @john                    │
│                                     │
│ 14:00 🚫 Blocker                    │
│       CI pipeline slow (3/5)        │
│       Resolved: Upgraded runners    │
│                                     │
│ 16:00 📝 Commit                     │
│       "Fix auth bug"                │
└─────────────────────────────────────┘
```

---

## 📊 Success Metrics for Sprint 1

After completing Sprint 1, you should be able to:

✅ **Daily Usage** (< 5 minutes/day):

- Scan your git repos (1 min)
- Log 1-2 friction points (2 min)
- Log 1-2 manual entries (2 min)

✅ **Data Capture**:

- 100% of your git commits
- 80%+ of code reviews you did
- Major blockers/incidents documented
- Key wins captured

✅ **Visibility**:

- Timeline shows your full workday
- Patterns emerge (when are you blocked?)
- Context for every commit

---

## 🚀 After Sprint 1: What's Next?

With Friction + Manual Entries working, you unlock:

1. **Sprint 2**: Manager Report Generator

   - Now has rich data to work with
   - Can generate "Challenges Overcome" section
   - Can include collaboration work

2. **Sprint 3**: DORA Metrics

   - Can correlate failures with friction logs
   - Can track MTTR using friction incidents

3. **Sprint 4**: SPACE Metrics
   - Collaboration score from manual entries
   - Satisfaction trends from friction patterns

---

## 💡 Pro Tips

1. **Make it a habit**: Log friction RIGHT WHEN IT HAPPENS (not end of day)
2. **Use shortcuts**: Create keyboard shortcuts for quick logging
3. **Be honest**: Log failures too - they make the best review stories
4. **Tag consistently**: Use same tags for easier analysis later
5. **Weekly review**: Every Friday, review your week's logs and add context

---

## 🆘 Common Issues

### Issue: "I forget to log things"

**Solution**: Add browser notification at end of day: "Did you log today's friction?"

### Issue: "Too slow to log"

**Solution**: Create quick-add modal (Cmd+K shortcut) with minimal fields

### Issue: "Not sure what to log"

**Solution**: Log these consistently:

- Every PR you review (manual entry)
- Every time you're blocked > 30 min (friction)
- Every incident/outage you handle (friction + manual entry)
- Every design doc you write (manual entry)
- Every "aha moment" (friction - learning)

---

---

## 🎉 Sprint 1 Complete!

**Status**: ✅ Todas as tarefas principais foram implementadas com sucesso!

### Próximos Passos

1. **Testar a implementação**:
   - Iniciar backend: `cd backend && uvicorn app.main:app --reload`
   - Iniciar frontend: `cd frontend && npm run dev`
   - Navegar para `/friction`, `/manual-entries`, e `/timeline`

2. **Sprint 2**: Manager Report Generator
   - Agora temos dados ricos (commits + friction + manual entries) para gerar relatórios
   - Próximo passo: integrar friction logs e manual entries no report generator

3. **Melhorias Futuras**:
   - Adicionar friction logs ao Manager Report (friction-005)
   - Integrar manual entries nas métricas SPACE (manual-005)

**Ready to start? Begin with `friction-001` - the database schema. It's all downhill from there!**

**✅ Sprint 1 está completo! Pronto para Sprint 2.**
