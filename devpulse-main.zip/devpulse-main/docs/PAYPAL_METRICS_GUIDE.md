# PayPal Metrics Guide - DevPulse

**Objetivo**: Guia completo de uso das métricas PayPal implementadas no DevPulse para alinhamento com critérios de avaliação T24 (Senior) e T25 (Staff).

---

## 📊 Métricas Implementadas

### 1. Say/Do Ratio Tracker

**O que é**: Métrica que calcula a porcentagem de goals completados vs. goals ativos em um quarter.

**Target PayPal**: ≥95% para high performers

**Como usar**:
- Acesse `/api/paypal/say-do-ratio` ou use o componente `SayDoRatioWidget`
- O sistema calcula automaticamente baseado nos goals criados no quarter
- Warning aparece se ratio < 95%

**API Endpoint**:
```bash
GET /api/paypal/say-do-ratio?quarter_start=2025-01-01&quarter_end=2025-03-31
```

**Response**:
```json
{
  "ratio": 92.5,
  "completed": 37,
  "total": 40,
  "warning": true,
  "quarter_start": "2025-01-01T00:00:00",
  "quarter_end": "2025-03-31T23:59:59",
  "target": 95
}
```

---

### 2. Risk Radar

**O que é**: Sistema que detecta goals em risco de perder deadline.

**Como funciona**:
- Analisa goals ativos com deadline nas próximas 2 semanas
- Verifica se há commits linked nos últimos 5 dias
- Alerta se goal está ativo mas sem atividade recente

**Como usar**:
- Acesse `/api/paypal/risk-radar` ou use o componente `RiskRadarWidget`
- Review semanal recomendado para identificar goals em risco

**API Endpoint**:
```bash
GET /api/paypal/risk-radar?days_ahead=14
```

**Response**:
```json
[
  {
    "goal_id": 5,
    "title": "Implement payment refactoring",
    "deadline": "2025-02-15T00:00:00",
    "days_until_deadline": 7,
    "progress": 0.3,
    "risk_reasons": [
      "No commits linked in last 5 days",
      "Low progress (<50%) with less than 7 days remaining"
    ],
    "recommendation": "Update status or increase effort"
  }
]
```

---

### 3. Cross-Team Detective

**O que é**: Calcula porcentagem de trabalho feito em repos cross-team (shared-lib, infra, core-platform).

**Por quê importa**: T25 (Staff) requer prova de impacto além do squad primário.

**Como usar**:
1. Tag seus repos com `shared-lib`, `infra`, ou `core-platform` nas tags
2. Acesse `/api/paypal/cross-team-work` ou use o componente `CrossTeamDetective`
3. Veja breakdown por repo

**API Endpoint**:
```bash
GET /api/paypal/cross-team-work?start_date=2025-01-01&end_date=2025-03-31
```

**Response**:
```json
{
  "cross_team_percentage": 25.5,
  "cross_team_count": 51,
  "total_count": 200,
  "breakdown": [
    {
      "repo_id": 3,
      "repo_name": "auth-shared-lib",
      "tags": "shared-lib,paypal",
      "commit_count": 35
    }
  ]
}
```

---

### 4. Impact Labeling with AI

**O que é**: Classifica ManualEntry como "Team-level" (T24) ou "Org-level" (T25) impact.

**Como funciona**:
- Analisa description e impact do entry
- Usa keywords para classificar (pode usar LLM no futuro)
- Salva em campo `impact_scope` do ManualEntry

**Como usar**:
- Auto-label ao criar/editar ManualEntry via endpoint
- Ou manualmente classificar entries existentes

**API Endpoint**:
```bash
POST /api/paypal/label-impact/{entry_id}?user_id=default
```

**Response**:
```json
{
  "entry_id": 12,
  "impact_scope": "org",
  "success": true
}
```

**Campos**:
- `team`: Impacto apenas no time/squad (T24/Senior)
- `org`: Impacto na organização inteira (T25/Staff)

---

### 5. Mentorship Graph

**O que é**: Conta e lista mentees distintos baseado em ManualEntry (mentoring) e Feedback logs.

**Target PayPal**: ≥2 mentees distintos

**Como usar**:
- Log ManualEntry com type='mentoring' e adicione mentees em `collaborators`
- Acesse `/api/paypal/mentees` ou use o componente `MentorshipGraph`
- Veja lista de mentees e contagem

**API Endpoint**:
```bash
GET /api/paypal/mentees?start_date=2025-01-01&end_date=2025-03-31
```

**Response**:
```json
{
  "mentee_count": 3,
  "mentees": ["John Doe", "Jane Smith", "Bob Johnson"],
  "target": 2
}
```

---

### 6. Code Review Depth Analyzer

**O que é**: Analisa profundidade de code reviews classificando como "superficial" vs "arquitetural".

**Como funciona**:
- Analisa ManualEntry type='code_review'
- Keywords superficiais: "LGTM", "looks good", "approved"
- Keywords arquiteturais: "architecture", "design", "pattern", "guidance"

**Como usar**:
- Acesse `/api/paypal/code-review-depth` para ver análise
- Use para quantificar qualidade de colaboração

**API Endpoint**:
```bash
GET /api/paypal/code-review-depth?start_date=2025-01-01&end_date=2025-03-31
```

**Response**:
```json
{
  "architectural_percentage": 35.5,
  "superficial_percentage": 45.2,
  "architectural_count": 11,
  "superficial_count": 14,
  "total_count": 31,
  "unclassified_count": 6
}
```

---

### 7. Promotion Readiness Score

**O que é**: Score de 0-100% indicando readiness para promoção T24→T25 baseado em 4 critérios.

**Critérios verificados**:
1. ✅ Mentees ≥ 2
2. ✅ Say/Do Ratio ≥ 95%
3. ✅ Cross-team work (commits em shared-lib/infra/core-platform)
4. ✅ Org-level impact (ManualEntry com impact_scope='org')

**Como usar**:
- Acesse `/api/paypal/promotion-readiness` ou use o componente `PromotionReadinessScore`
- Veja score, gaps específicos e recomendações

**API Endpoint**:
```bash
GET /api/paypal/promotion-readiness?quarter_start=2025-01-01&quarter_end=2025-03-31
```

**Response**:
```json
{
  "score": 75.0,
  "checks": {
    "mentees": true,
    "say_do_ratio": true,
    "cross_team_work": true,
    "org_level_impact": false
  },
  "gaps": ["org_level_impact"],
  "recommendations": [
    "Need manual entries demonstrating org-level impact (not just team-level)"
  ],
  "details": {
    "mentees": {"mentee_count": 3, "mentees": [...], "target": 2},
    "say_do_ratio": {"ratio": 96.5, "completed": 28, "total": 29},
    "cross_team_work": {"cross_team_percentage": 25.5, ...},
    "org_level_impact_count": 0
  }
}
```

---

## 🎯 Workflow Recomendado

### Para Performance Reviews

1. **Quarter Start**: Configure goals e defina quarter dates
2. **Weekly**: 
   - Review Risk Radar para identificar goals em risco
   - Log mentoring activities com mentees
   - Classify impact scope de manual entries importantes
3. **Monthly**: 
   - Check Say/Do Ratio e ajuste goals se necessário
   - Review Cross-Team work percentage
   - Check Promotion Readiness Score
4. **Quarter End**: 
   - Generate Promotion Readiness Score completo
   - Use métricas no Manager Report
   - Identifique gaps para próximo quarter

### Para Promoção T24→T25

1. Verifique Promotion Readiness Score
2. Identifique gaps específicos
3. Trabalhe nos gaps:
   - Se falta mentees: aumente atividades de mentoring
   - Se Say/Do < 95%: ajuste goals para serem mais realistas
   - Se falta cross-team work: contribua para repos shared-lib/infra
   - Se falta org-level impact: foque em projetos que impactam múltiplos times
4. Documente achievements com ManualEntry classificados como org-level

---

## 🔧 Configuração

### Tagging Repos para Cross-Team Detection

```bash
# Via API
PATCH /api/repositories/{repo_id}/tags
Body: ["shared-lib", "paypal", "team-a"]

# Ou via UI: Settings > Repositories > Edit Tags
```

Tags reconhecidas como cross-team:
- `shared-lib`
- `infra`
- `core-platform`

### Classificando Impact Scope

**Via API**:
```bash
POST /api/paypal/label-impact/{entry_id}
```

**Manualmente** (quando criar/editar ManualEntry):
- Adicione campo `impact_scope` com valor `team` ou `org`

---

## 📈 Integração com Manager Report

As métricas PayPal podem ser incluídas no Manager Report:

1. Say/Do Ratio aparece na seção "Execution & Delivery"
2. Cross-Team work aparece na seção "Strategic Impact"
3. Mentorship aparece na seção "Leadership & One Team"
4. Promotion Readiness Score pode ser adicionado como seção separada

---

## 🐛 Troubleshooting

### Say/Do Ratio muito baixo
- Verifique se goals estão sendo marcados como "completed" quando terminados
- Considere ajustar goals para serem mais realistas
- Use Risk Radar para identificar goals em risco antes do deadline

### Cross-Team percentage = 0%
- Verifique se repos estão taggeados corretamente
- Tags devem incluir: `shared-lib`, `infra`, ou `core-platform`
- Verifique se há commits nesses repos no período analisado

### Mentees count = 0
- Certifique-se de logar ManualEntry com type='mentoring'
- Adicione mentees no campo `collaborators` (comma-separated)
- Exemplo: `collaborators: "John Doe, Jane Smith"`

### Promotion Readiness Score baixo
- Use o campo `gaps` para identificar critérios faltando
- Siga as `recommendations` para melhorar score
- Foque em um gap por vez

---

## 📚 Referências

- [PROJECT_PHASE_3.md](PROJECT_PHASE_3.md) - Contexto estratégico das métricas PayPal
- [IMPROVEMENT_ROADMAP.md](IMPROVEMENT_ROADMAP.md) - Roadmap completo de features
- [SPRINT_8_SECURITY_DATA_QUALITY.md](SPRINT_8_SECURITY_DATA_QUALITY.md) - Features de segurança

---

**Última atualização**: Janeiro 2025
**Status**: Todas as métricas implementadas e prontas para uso

