# 🚀 Project DevPulse - Phase 2: Intelligence & Framework Integration

This phase transforms raw git data into **career-defining insights**. We are moving from simple commit listing to high-level performance analysis based on the **SPACE** and **DORA** frameworks mentioned in the "Felipe Adamoli Meetup."

## 📌 Phase Overview

The goal of this phase is to provide **context**. A manager at PayPal doesn't just want to see "10 commits"; they want to see "10 commits that improved system stability (DORA) while maintaining high collaboration and flow (SPACE)."

---

## 🛠 Phase 2: Detailed Tasks (The "Intelligence" Layer)

### Task 2.1: Personal DORA Metrics & Flow Analysis

- **Objective:** Implement algorithms to calculate speed and stability from local git history.
- **Sub-tasks:**
- **Cycle Time Engine:** Calculate the time from the first commit on a feature branch to the final merge. This identifies bottlenecks.
- **Deployment Frequency Proxy:** Count how often you merge to the main branch (local "production" simulation).
- **Focus Time (SPACE - Efficiency):** Analyze commit timestamps to identify "Deep Work" blocks (consecutive hours of coding) vs. fragmented work (high interruptions).

### Task 2.2: AI-Powered "Impact Narratives"

- **Objective:** Use LLMs (OpenAI/Gemini) to translate technical jargon into business value.
- **Sub-tasks:**
- **Commit Summarizer:** Send a batch of 15 commits to an LLM to generate a single paragraph starting with: _"This week, I focused on improving [System X], resulting in [Benefit Y]."_
- **Impact Categorization:** Automatically tag work as: **Revenue-driving**, **Risk Reduction (Bugfixes)**, or **Tech Debt (Scalability)**.

### Task 2.3: Human Context & Friction Tracking (SPACE - Satisfaction)

- **Objective:** Capture the "Why" behind the "What."
- **Sub-tasks:**
- **Friction Logger:** Create a simple UI component (Friction Tracker) to log daily blockers (e.g., "Long build times," "Vague requirements," "Too many meetings").
- **Health Score:** A weekly self-assessment slider (1-10) regarding "Satisfaction" and "Well-being" to cross-reference with commit volume.

---

## 🤖 Phase 2: Master Prompt for your Coding AI

Copy and paste this into your AI code editor to start building Phase 2:

> **Prompt:**
> "I am building Phase 2 of 'DevPulse', a personal performance tool. We need to implement the Intelligence Layer focusing on DORA and SPACE frameworks.
> **Instructions for Backend (FastAPI/Python):**
>
> 1. Create a service that analyzes git branch history to calculate 'Personal Cycle Time' (difference between the first commit and the merge date).
> 2. Integrate an LLM (OpenAI or Gemini API) to create a 'Weekly Impact Summary'. It should take a list of git messages and output 3 bullet points of achievements for a manager review.
> 3. Add a SQLite table for 'Daily Logs' to store qualitative data: satisfaction level (1-5) and specific blockers (text).
>
> **Instructions for Frontend (React/Tailwind):**
>
> 1. Create a 'Performance Insights' dashboard. It should show a 'Flow Score' based on commit frequency.
> 2. Build a 'Manager Report' view that combines the AI-generated impact summary with the DORA metrics (Cycle Time).
> 3. Add a 'Friction Input' form for me to log daily challenges.
>
> Follow the architecture from Phase 1. Ensure all calculations are done in Python and served via REST API."

---

## 📈 Key Metrics to Present in your 1:1 at PayPal

With Phase 2 complete, you will be able to say:

| Framework  | Metric            | What to say in the meeting                                                                                              |
| ---------- | ----------------- | ----------------------------------------------------------------------------------------------------------------------- |
| **DORA**   | **Cycle Time**    | "I've optimized my local testing flow, reducing my average delivery time from 4 days to 2 days."                        |
| **SPACE**  | **Communication** | "I spent 20% of my time reviewing peers' PRs, ensuring our team's code quality remains high."                           |
| **SPACE**  | **Efficiency**    | "I identified that my 'Flow' is highest between 9 AM and 11 AM, so I've moved my non-urgent meetings to the afternoon." |
| **IMPACT** | **AI Summary**    | "My technical work this month directly addressed 3 legacy bugs that were affecting customer checkout."                  |

---

### Next Step Recommendation:

Start by building the **Friction Logger (Task 2.3)**. It is the easiest to implement and provides immediate value by helping you remember what blocked you three months ago when you are sitting in your performance review.

**Do you want the Python code for the "Personal Cycle Time" calculator to start Task 2.1?**
