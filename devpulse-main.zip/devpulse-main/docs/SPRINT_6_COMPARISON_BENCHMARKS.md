# 🚀 Sprint 6 - Comparison & Benchmarks

**Goal**: Add comparison capabilities to show your metrics vs team averages vs industry benchmarks, with percentile rankings and historical quarter-over-quarter comparisons.

**Timeline**: 2-3 weeks

**Status**: ✅ **COMPLETE**

## ✅ Sprint 6 Completion Summary

**Status**: Completed (January 2025)

Sprint 6 successfully implemented all comparison and benchmarking capabilities to enable metrics comparison against team averages and industry standards:

### Features Delivered

1. **Database Models & Migrations** ✅

   - TeamBenchmark model for storing anonymized team metrics
   - IndustryBenchmark model for DORA industry standards (Elite/High/Medium/Low)
   - HistoricalSnapshot model for quarterly snapshots
   - Migration: `add_comparison_benchmarks`

2. **Benchmark Service** ✅

   - DORA industry benchmarks seeded on startup
   - Automatic seeding of Elite/High/Medium/Low thresholds for all DORA metrics

3. **Comparison Logic** ✅

   - Percentile calculation service
   - Industry category matching
   - Team average and percentile calculation
   - Historical period comparison with trend detection

4. **API Endpoints** ✅

   - Team benchmark CRUD operations
   - Bulk import endpoint
   - Comparison endpoint for metrics
   - Historical snapshot creation and retrieval
   - Historical period comparison endpoint

5. **Frontend Components** ✅

   - TeamBenchmarkForm with single and bulk import modes
   - ComparisonDashboard showing your vs team vs industry
   - PercentileRanking component with visual bars
   - HistoricalComparison component for quarter-over-quarter analysis
   - SnapshotCreator component for creating historical snapshots

6. **Integration** ✅
   - Comparison data integrated into Manager Report Generator
   - Benchmark summary section in reports
   - ComparisonPage with tab navigation
   - Added to Sidebar navigation

### Technical Implementation

- **New Models**: TeamBenchmark, IndustryBenchmark, HistoricalSnapshot
- **New API Endpoints**: `/api/benchmarks/*` (team, industry, compare, snapshot)
- **New Frontend Pages**: ComparisonPage
- **New Components**: TeamBenchmarkForm, ComparisonDashboard, PercentileRanking, HistoricalComparison, SnapshotCreator
- **Report Integration**: Benchmark comparison section in Manager Reports (Markdown and PDF)

### Success Criteria Validation

- ✅ Team benchmarks can be imported (single + bulk CSV)
- ✅ Comparison shows your metrics vs team vs industry
- ✅ DORA benchmarks correctly categorize (Elite/High/Medium/Low)
- ✅ Percentile ranking visual shows position clearly
- ✅ Historical snapshots can be created and compared
- ✅ Quarter-over-quarter trends are accurate
- ✅ Manager Report includes comparison data
- ✅ All API endpoints return correct data structures

**Success Criteria**:

- ✅ You can import anonymized team averages (manual input)
- ✅ Dashboard shows your metrics vs team vs industry (DORA benchmarks)
- ✅ Percentile ranking visual shows where you stand
- ✅ Historical comparison (Q1 vs Q2 vs Q3) shows growth trends
- ✅ You can say "My cycle time is in the top 25% of the team"
- ✅ Dashboard shows growth quarter-over-quarter

---

## 📋 Overview

Sprint 6 adds comparison and benchmarking capabilities to DevPulse, enabling you to:

1. **Import Team Averages**: Manually input anonymized team metrics for comparison
2. **Industry Benchmarks**: Compare against DORA industry standards (Elite/High/Medium/Low)
3. **Percentile Rankings**: Visual representation of where you stand relative to team
4. **Historical Comparisons**: Quarter-over-quarter growth analysis

**Key Features**:

- Team benchmark data import/export
- Real-time comparison calculations
- Percentile ranking visualization
- Quarter-over-quarter trend analysis
- Integration into Manager Reports

---

## 📋 Tasks Breakdown

### Task Group 1: Database Schema & Models (2 days)

#### Day 1: Benchmark Models

**File**: `backend/app/models.py`

Add benchmark models:

```python
class TeamBenchmark(Base):
    __tablename__ = "team_benchmarks"

    id = Column(Integer, primary_key=True, index=True)
    metric_name = Column(String, nullable=False, index=True)  # 'deployment_frequency', 'lead_time', etc.
    metric_value = Column(Float, nullable=False)
    metric_unit = Column(String)  # 'per_week', 'days', 'percentage', etc.
    period_start = Column(DateTime(timezone=True), nullable=False, index=True)
    period_end = Column(DateTime(timezone=True), nullable=False, index=True)
    team_name = Column(String, index=True)  # Optional: anonymized team identifier
    source = Column(String, default='manual')  # 'manual' | 'imported'
    notes = Column(Text)  # Optional context
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class IndustryBenchmark(Base):
    __tablename__ = "industry_benchmarks"

    id = Column(Integer, primary_key=True, index=True)
    metric_name = Column(String, nullable=False, index=True)
    category = Column(String, nullable=False)  # 'elite' | 'high' | 'medium' | 'low'
    min_value = Column(Float)  # Lower bound for category
    max_value = Column(Float)  # Upper bound for category (None for elite/low)
    source = Column(String, default='dora')  # 'dora' | 'custom'
    year = Column(Integer)  # Benchmark year
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class HistoricalSnapshot(Base):
    __tablename__ = "historical_snapshots"

    id = Column(Integer, primary_key=True, index=True)
    period_label = Column(String, nullable=False, index=True)  # 'Q1-2024', 'Q2-2024', etc.
    period_start = Column(DateTime(timezone=True), nullable=False)
    period_end = Column(DateTime(timezone=True), nullable=False)
    snapshot_data = Column(Text)  # JSON string with all metrics
    dora_metrics = Column(Text)  # JSON string with DORA metrics
    space_metrics = Column(Text)  # JSON string with SPACE metrics
    created_at = Column(DateTime(timezone=True), server_default=func.now())
```

**File**: `backend/app/schemas.py`

Add Pydantic schemas:

```python
class TeamBenchmarkBase(BaseModel):
    metric_name: str
    metric_value: float
    metric_unit: Optional[str] = None
    period_start: datetime
    period_end: datetime
    team_name: Optional[str] = None
    source: str = 'manual'
    notes: Optional[str] = None

class TeamBenchmarkCreate(TeamBenchmarkBase):
    pass

class TeamBenchmarkUpdate(BaseModel):
    metric_name: Optional[str] = None
    metric_value: Optional[float] = None
    metric_unit: Optional[str] = None
    period_start: Optional[datetime] = None
    period_end: Optional[datetime] = None
    team_name: Optional[str] = None
    source: Optional[str] = None
    notes: Optional[str] = None

class TeamBenchmark(TeamBenchmarkBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class IndustryBenchmarkBase(BaseModel):
    metric_name: str
    category: str  # elite | high | medium | low
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    source: str = 'dora'
    year: Optional[int] = None

class IndustryBenchmarkCreate(IndustryBenchmarkBase):
    pass

class IndustryBenchmark(IndustryBenchmarkBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True

class HistoricalSnapshotBase(BaseModel):
    period_label: str
    period_start: datetime
    period_end: datetime
    snapshot_data: Dict
    dora_metrics: Dict
    space_metrics: Dict

class HistoricalSnapshotCreate(HistoricalSnapshotBase):
    pass

class HistoricalSnapshot(HistoricalSnapshotBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True

class ComparisonResult(BaseModel):
    your_value: float
    team_average: Optional[float] = None
    team_percentile: Optional[float] = None  # 0-100
    industry_category: Optional[str] = None  # elite | high | medium | low
    industry_percentile: Optional[float] = None  # Estimated based on category
    trend: Optional[str] = None  # 'improving' | 'stable' | 'declining'
    trend_percentage: Optional[float] = None  # % change from previous period
```

**File**: `backend/alembic/versions/`

Create migration:

```python
"""add_comparison_benchmarks

Revision ID: add_comparison_benchmarks
Revises: <previous_revision>
Create Date: <date>

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import sqlite

def upgrade():
    # Team Benchmarks
    op.create_table(
        'team_benchmarks',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('metric_name', sa.String(), nullable=False),
        sa.Column('metric_value', sa.Float(), nullable=False),
        sa.Column('metric_unit', sa.String(), nullable=True),
        sa.Column('period_start', sa.DateTime(timezone=True), nullable=False),
        sa.Column('period_end', sa.DateTime(timezone=True), nullable=False),
        sa.Column('team_name', sa.String(), nullable=True),
        sa.Column('source', sa.String(), nullable=True),
        sa.Column('notes', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_team_benchmarks_metric_name'), 'team_benchmarks', ['metric_name'], unique=False)
    op.create_index(op.f('ix_team_benchmarks_period_start'), 'team_benchmarks', ['period_start'], unique=False)
    op.create_index(op.f('ix_team_benchmarks_team_name'), 'team_benchmarks', ['team_name'], unique=False)

    # Industry Benchmarks
    op.create_table(
        'industry_benchmarks',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('metric_name', sa.String(), nullable=False),
        sa.Column('category', sa.String(), nullable=False),
        sa.Column('min_value', sa.Float(), nullable=True),
        sa.Column('max_value', sa.Float(), nullable=True),
        sa.Column('source', sa.String(), nullable=True),
        sa.Column('year', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_industry_benchmarks_metric_name'), 'industry_benchmarks', ['metric_name'], unique=False)

    # Historical Snapshots
    op.create_table(
        'historical_snapshots',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('period_label', sa.String(), nullable=False),
        sa.Column('period_start', sa.DateTime(timezone=True), nullable=False),
        sa.Column('period_end', sa.DateTime(timezone=True), nullable=False),
        sa.Column('snapshot_data', sa.Text(), nullable=True),
        sa.Column('dora_metrics', sa.Text(), nullable=True),
        sa.Column('space_metrics', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_historical_snapshots_period_label'), 'historical_snapshots', ['period_label'], unique=False)

def downgrade():
    op.drop_index(op.f('ix_historical_snapshots_period_label'), table_name='historical_snapshots')
    op.drop_table('historical_snapshots')
    op.drop_index(op.f('ix_industry_benchmarks_metric_name'), table_name='industry_benchmarks')
    op.drop_table('industry_benchmarks')
    op.drop_index(op.f('ix_team_benchmarks_team_name'), table_name='team_benchmarks')
    op.drop_index(op.f('ix_team_benchmarks_period_start'), table_name='team_benchmarks')
    op.drop_index(op.f('ix_team_benchmarks_metric_name'), table_name='team_benchmarks')
    op.drop_table('team_benchmarks')
```

**Task**: `bench-001` (Database part)

---

#### Day 2: Seed Industry Benchmarks

**File**: `backend/app/services/benchmark_service.py`

Create service to seed DORA industry benchmarks:

```python
from sqlalchemy.orm import Session
from datetime import datetime
from ..models import IndustryBenchmark

DORA_BENCHMARKS = {
    'deployment_frequency': [
        {'category': 'elite', 'min_value': 1.0, 'max_value': None},  # Multiple per day
        {'category': 'high', 'min_value': 1/7, 'max_value': 1.0},  # Once per day to once per week
        {'category': 'medium', 'min_value': 1/30, 'max_value': 1/7},  # Once per week to once per month
        {'category': 'low', 'min_value': 0, 'max_value': 1/30},  # Less than once per month
    ],
    'lead_time': [
        {'category': 'elite', 'min_value': 0, 'max_value': 1.0},  # Less than 1 day
        {'category': 'high', 'min_value': 1.0, 'max_value': 7.0},  # 1 day to 1 week
        {'category': 'medium', 'min_value': 7.0, 'max_value': 30.0},  # 1 week to 1 month
        {'category': 'low', 'min_value': 30.0, 'max_value': None},  # More than 1 month
    ],
    'change_failure_rate': [
        {'category': 'elite', 'min_value': 0, 'max_value': 5.0},  # 0-5%
        {'category': 'high', 'min_value': 5.0, 'max_value': 10.0},  # 5-10%
        {'category': 'medium', 'min_value': 10.0, 'max_value': 15.0},  # 10-15%
        {'category': 'low', 'min_value': 15.0, 'max_value': 100.0},  # >15%
    ],
    'mttr': [
        {'category': 'elite', 'min_value': 0, 'max_value': 1.0},  # Less than 1 hour
        {'category': 'high', 'min_value': 1.0, 'max_value': 24.0},  # 1 hour to 1 day
        {'category': 'medium', 'min_value': 24.0, 'max_value': 168.0},  # 1 day to 1 week
        {'category': 'low', 'min_value': 168.0, 'max_value': None},  # More than 1 week
    ],
}

def seed_industry_benchmarks(db: Session):
    """Seed DORA industry benchmarks if they don't exist"""
    existing = db.query(IndustryBenchmark).filter(
        IndustryBenchmark.source == 'dora'
    ).first()

    if existing:
        return  # Already seeded

    current_year = datetime.now().year

    for metric_name, categories in DORA_BENCHMARKS.items():
        for cat_data in categories:
            benchmark = IndustryBenchmark(
                metric_name=metric_name,
                category=cat_data['category'],
                min_value=cat_data.get('min_value'),
                max_value=cat_data.get('max_value'),
                source='dora',
                year=current_year
            )
            db.add(benchmark)

    db.commit()
```

**Task**: `bench-001` (Seed data part)

---

### Task Group 2: Comparison Logic & Calculations (3-4 days)

#### Day 1: Comparison Service

**File**: `backend/app/services/comparison_service.py`

Create comparison calculation service:

```python
from sqlalchemy.orm import Session
from typing import Dict, List, Optional
from datetime import datetime
from statistics import mean, median
import json

from ..models import TeamBenchmark, IndustryBenchmark, HistoricalSnapshot
from ..analysis.dora_metrics import get_dora_metrics
from ..analysis.space_metrics import get_space_metrics


def calculate_percentile(value: float, values: List[float]) -> float:
    """Calculate percentile rank (0-100) of value in values list"""
    if not values:
        return None

    sorted_values = sorted(values)
    below = sum(1 for v in sorted_values if v < value)
    equal = sum(1 for v in sorted_values if v == value)

    percentile = (below + 0.5 * equal) / len(sorted_values) * 100
    return round(percentile, 1)


def get_industry_category(
    db: Session,
    metric_name: str,
    value: float
) -> Optional[str]:
    """Determine industry category (elite/high/medium/low) for a metric value"""
    benchmarks = db.query(IndustryBenchmark).filter(
        IndustryBenchmark.metric_name == metric_name
    ).order_by(
        IndustryBenchmark.min_value.asc()
    ).all()

    for benchmark in benchmarks:
        min_val = benchmark.min_value
        max_val = benchmark.max_value

        if min_val is not None and value < min_val:
            continue

        if max_val is None:
            return benchmark.category  # Elite or Low (unbounded)

        if min_val is not None and max_val is not None:
            if min_val <= value < max_val:
                return benchmark.category
        elif max_val is not None:
            if value < max_val:
                return benchmark.category

    return 'low'  # Default to low if not found


def compare_metric(
    db: Session,
    metric_name: str,
    your_value: float,
    period_start: datetime,
    period_end: datetime,
    team_name: Optional[str] = None
) -> Dict:
    """Compare your metric value against team and industry benchmarks"""

    # Get team benchmarks for same period
    team_query = db.query(TeamBenchmark).filter(
        TeamBenchmark.metric_name == metric_name,
        TeamBenchmark.period_start <= period_end,
        TeamBenchmark.period_end >= period_start
    )

    if team_name:
        team_query = team_query.filter(TeamBenchmark.team_name == team_name)

    team_benchmarks = team_query.all()

    # Calculate team average and percentile
    team_average = None
    team_percentile = None

    if team_benchmarks:
        team_values = [b.metric_value for b in team_benchmarks]
        team_average = mean(team_values)
        team_percentile = calculate_percentile(your_value, team_values)

    # Get industry category
    industry_category = get_industry_category(db, metric_name, your_value)

    # Estimate industry percentile based on category
    industry_percentile_map = {
        'elite': 90.0,  # Top 10%
        'high': 70.0,   # Top 30%
        'medium': 40.0, # Top 60%
        'low': 15.0,    # Bottom 40%
    }
    industry_percentile = industry_percentile_map.get(industry_category)

    return {
        'your_value': your_value,
        'team_average': team_average,
        'team_percentile': team_percentile,
        'industry_category': industry_category,
        'industry_percentile': industry_percentile,
    }


def compare_dora_metrics(
    db: Session,
    start_date: datetime,
    end_date: datetime,
    team_name: Optional[str] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """Compare all DORA metrics against team and industry"""
    from ..analysis.dora_metrics import get_dora_metrics

    your_metrics = get_dora_metrics(db, start_date, end_date, repo_id)

    comparisons = {}

    # Deployment Frequency
    df = your_metrics.get('deployment_frequency', {})
    if df.get('per_week'):
        comparisons['deployment_frequency'] = compare_metric(
            db, 'deployment_frequency', df['per_week'],
            start_date, end_date, team_name
        )

    # Lead Time
    lt = your_metrics.get('lead_time', {})
    if lt.get('average_days'):
        comparisons['lead_time'] = compare_metric(
            db, 'lead_time', lt['average_days'],
            start_date, end_date, team_name
        )

    # Change Failure Rate
    cfr = your_metrics.get('change_failure_rate', {})
    if cfr.get('failure_rate_percentage'):
        comparisons['change_failure_rate'] = compare_metric(
            db, 'change_failure_rate', cfr['failure_rate_percentage'],
            start_date, end_date, team_name
        )

    # MTTR
    mttr = your_metrics.get('mttr', {})
    if mttr.get('mean_hours'):
        comparisons['mttr'] = compare_metric(
            db, 'mttr', mttr['mean_hours'],
            start_date, end_date, team_name
        )

    return {
        'your_metrics': your_metrics,
        'comparisons': comparisons,
        'period': {
            'start': start_date.isoformat(),
            'end': end_date.isoformat(),
        }
    }
```

**Task**: `bench-002` (Backend logic part)

---

#### Day 2: Historical Comparison

**File**: `backend/app/services/comparison_service.py` (continued)

Add historical comparison functions:

```python
def create_historical_snapshot(
    db: Session,
    period_label: str,
    period_start: datetime,
    period_end: datetime,
    repo_id: Optional[int] = None
) -> HistoricalSnapshot:
    """Create a snapshot of current metrics for historical comparison"""

    # Get current metrics
    dora_metrics = get_dora_metrics(db, period_start, period_end, repo_id)
    space_metrics = get_space_metrics(db, period_start, period_end, repo_id)

    # Create snapshot data
    snapshot_data = {
        'dora': dora_metrics,
        'space': space_metrics,
        'period_label': period_label,
        'period_start': period_start.isoformat(),
        'period_end': period_end.isoformat(),
    }

    snapshot = HistoricalSnapshot(
        period_label=period_label,
        period_start=period_start,
        period_end=period_end,
        snapshot_data=json.dumps(snapshot_data),
        dora_metrics=json.dumps(dora_metrics),
        space_metrics=json.dumps(space_metrics)
    )

    db.add(snapshot)
    db.commit()
    db.refresh(snapshot)

    return snapshot


def compare_historical_periods(
    db: Session,
    period_labels: List[str]
) -> Dict:
    """Compare metrics across multiple historical periods"""

    snapshots = db.query(HistoricalSnapshot).filter(
        HistoricalSnapshot.period_label.in_(period_labels)
    ).order_by(HistoricalSnapshot.period_start.asc()).all()

    if len(snapshots) < 2:
        return {'error': 'Need at least 2 periods to compare'}

    comparisons = {}

    # Compare DORA metrics
    dora_metrics_list = []
    for snapshot in snapshots:
        dora_data = json.loads(snapshot.dora_metrics)
        dora_metrics_list.append({
            'period': snapshot.period_label,
            'metrics': dora_data
        })

    # Calculate trends for each metric
    metric_names = ['deployment_frequency', 'lead_time', 'change_failure_rate', 'mttr']

    for metric_name in metric_names:
        values = []
        for item in dora_metrics_list:
            metric_data = item['metrics'].get(metric_name, {})
            if metric_name == 'deployment_frequency':
                value = metric_data.get('per_week')
            elif metric_name == 'lead_time':
                value = metric_data.get('average_days')
            elif metric_name == 'change_failure_rate':
                value = metric_data.get('failure_rate_percentage')
            elif metric_name == 'mttr':
                value = metric_data.get('mean_hours')

            if value is not None:
                values.append({
                    'period': item['period'],
                    'value': value
                })

        if len(values) >= 2:
            # Calculate trend
            first_value = values[0]['value']
            last_value = values[-1]['value']

            if first_value > 0:
                trend_percentage = ((last_value - first_value) / first_value) * 100
            else:
                trend_percentage = 0

            # Determine trend direction
            if trend_percentage > 5:
                trend = 'improving' if metric_name in ['deployment_frequency'] else 'declining'
            elif trend_percentage < -5:
                trend = 'declining' if metric_name in ['deployment_frequency'] else 'improving'
            else:
                trend = 'stable'

            # For lead_time, change_failure_rate, mttr: lower is better
            if metric_name in ['lead_time', 'change_failure_rate', 'mttr']:
                if trend == 'improving':
                    trend = 'declining'
                elif trend == 'declining':
                    trend = 'improving'

            comparisons[metric_name] = {
                'values': values,
                'trend': trend,
                'trend_percentage': round(trend_percentage, 1),
                'first_value': first_value,
                'last_value': last_value,
            }

    return {
        'periods': [s.period_label for s in snapshots],
        'comparisons': comparisons,
        'snapshots': [
            {
                'period': s.period_label,
                'start': s.period_start.isoformat(),
                'end': s.period_end.isoformat(),
            }
            for s in snapshots
        ]
    }
```

**Task**: `bench-004` (Backend part)

---

### Task Group 3: API Endpoints (2-3 days)

#### Day 1: Team Benchmarks API

**File**: `backend/app/api/benchmarks.py`

Create CRUD API for team benchmarks:

```python
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
import json

from ..database import get_db
from ..models import TeamBenchmark, IndustryBenchmark, HistoricalSnapshot
from ..schemas import (
    TeamBenchmarkCreate, TeamBenchmarkUpdate, TeamBenchmark,
    IndustryBenchmark, HistoricalSnapshot, ComparisonResult
)
from ..services.comparison_service import (
    compare_dora_metrics, compare_historical_periods,
    create_historical_snapshot
)
from ..services.benchmark_service import seed_industry_benchmarks

router = APIRouter(prefix="/api/benchmarks", tags=["benchmarks"])


@router.post("/team", response_model=TeamBenchmark)
def create_team_benchmark(
    benchmark: TeamBenchmarkCreate,
    db: Session = Depends(get_db)
):
    """Create a new team benchmark entry"""
    db_benchmark = TeamBenchmark(**benchmark.dict())
    db.add(db_benchmark)
    db.commit()
    db.refresh(db_benchmark)
    return db_benchmark


@router.get("/team", response_model=List[TeamBenchmark])
def get_team_benchmarks(
    metric_name: Optional[str] = Query(None),
    team_name: Optional[str] = Query(None),
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    db: Session = Depends(get_db)
):
    """Get team benchmarks with optional filters"""
    query = db.query(TeamBenchmark)

    if metric_name:
        query = query.filter(TeamBenchmark.metric_name == metric_name)
    if team_name:
        query = query.filter(TeamBenchmark.team_name == team_name)
    if start_date:
        query = query.filter(TeamBenchmark.period_start >= start_date)
    if end_date:
        query = query.filter(TeamBenchmark.period_end <= end_date)

    return query.order_by(TeamBenchmark.period_start.desc()).all()


@router.put("/team/{benchmark_id}", response_model=TeamBenchmark)
def update_team_benchmark(
    benchmark_id: int,
    benchmark_update: TeamBenchmarkUpdate,
    db: Session = Depends(get_db)
):
    """Update a team benchmark"""
    benchmark = db.query(TeamBenchmark).filter(
        TeamBenchmark.id == benchmark_id
    ).first()

    if not benchmark:
        raise HTTPException(status_code=404, detail="Benchmark not found")

    update_data = benchmark_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(benchmark, field, value)

    benchmark.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(benchmark)
    return benchmark


@router.delete("/team/{benchmark_id}")
def delete_team_benchmark(
    benchmark_id: int,
    db: Session = Depends(get_db)
):
    """Delete a team benchmark"""
    benchmark = db.query(TeamBenchmark).filter(
        TeamBenchmark.id == benchmark_id
    ).first()

    if not benchmark:
        raise HTTPException(status_code=404, detail="Benchmark not found")

    db.delete(benchmark)
    db.commit()
    return {"message": "Benchmark deleted"}


@router.post("/team/import")
def import_team_benchmarks(
    benchmarks: List[TeamBenchmarkCreate],
    db: Session = Depends(get_db)
):
    """Import multiple team benchmarks at once"""
    created = []
    for benchmark_data in benchmarks:
        db_benchmark = TeamBenchmark(**benchmark_data.dict())
        db.add(db_benchmark)
        created.append(db_benchmark)

    db.commit()
    for b in created:
        db.refresh(b)

    return {
        "message": f"Imported {len(created)} benchmarks",
        "benchmarks": created
    }


@router.get("/industry", response_model=List[IndustryBenchmark])
def get_industry_benchmarks(
    metric_name: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """Get industry benchmarks (DORA standards)"""
    # Seed if not exists
    seed_industry_benchmarks(db)

    query = db.query(IndustryBenchmark)
    if metric_name:
        query = query.filter(IndustryBenchmark.metric_name == metric_name)

    return query.order_by(IndustryBenchmark.min_value.asc()).all()


@router.get("/compare")
def compare_metrics(
    start_date: datetime = Query(...),
    end_date: datetime = Query(...),
    team_name: Optional[str] = Query(None),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """Compare your metrics against team and industry benchmarks"""
    return compare_dora_metrics(
        db, start_date, end_date, team_name, repo_id
    )
```

**Task**: `bench-001` (API part)

---

#### Day 2: Historical Snapshots API

**File**: `backend/app/api/benchmarks.py` (continued)

Add historical snapshot endpoints:

```python
@router.post("/snapshot")
def create_snapshot(
    period_label: str = Query(...),
    period_start: datetime = Query(...),
    period_end: datetime = Query(...),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """Create a historical snapshot of current metrics"""
    snapshot = create_historical_snapshot(
        db, period_label, period_start, period_end, repo_id
    )
    return snapshot


@router.get("/snapshot", response_model=List[HistoricalSnapshot])
def get_snapshots(
    period_label: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """Get historical snapshots"""
    query = db.query(HistoricalSnapshot)
    if period_label:
        query = query.filter(HistoricalSnapshot.period_label == period_label)

    return query.order_by(HistoricalSnapshot.period_start.desc()).all()


@router.get("/compare/historical")
def compare_historical(
    periods: str = Query(...),  # Comma-separated: "Q1-2024,Q2-2024,Q3-2024"
    db: Session = Depends(get_db)
):
    """Compare metrics across multiple historical periods"""
    period_labels = [p.strip() for p in periods.split(',')]
    return compare_historical_periods(db, period_labels)
```

**File**: `backend/app/main.py`

Register router:

```python
from .api import benchmarks

app.include_router(benchmarks.router)
```

**Task**: `bench-004` (API part)

---

### Task Group 4: Frontend Components (4-5 days)

#### Day 1-2: Team Benchmark Import UI

**File**: `frontend/src/types/index.ts`

Add TypeScript interfaces:

```typescript
export interface TeamBenchmark {
  id: number;
  metric_name: string;
  metric_value: number;
  metric_unit?: string;
  period_start: string;
  period_end: string;
  team_name?: string;
  source: string;
  notes?: string;
  created_at: string;
  updated_at?: string;
}

export interface TeamBenchmarkCreate {
  metric_name: string;
  metric_value: number;
  metric_unit?: string;
  period_start: string;
  period_end: string;
  team_name?: string;
  source?: string;
  notes?: string;
}

export interface IndustryBenchmark {
  id: number;
  metric_name: string;
  category: 'elite' | 'high' | 'medium' | 'low';
  min_value?: number;
  max_value?: number;
  source: string;
  year?: number;
  created_at: string;
}

export interface ComparisonResult {
  your_value: number;
  team_average?: number;
  team_percentile?: number;
  industry_category?: string;
  industry_percentile?: number;
  trend?: string;
  trend_percentage?: number;
}

export interface HistoricalSnapshot {
  id: number;
  period_label: string;
  period_start: string;
  period_end: string;
  snapshot_data: any;
  dora_metrics: any;
  space_metrics: any;
  created_at: string;
}
```

**File**: `frontend/src/services/api.ts`

Add API methods:

```typescript
export const getTeamBenchmarks = async (params?: {
  metric_name?: string;
  team_name?: string;
  start_date?: string;
  end_date?: string;
}): Promise<TeamBenchmark[]> => {
  const response = await fetch(
    `${API_BASE}/benchmarks/team?${new URLSearchParams(params as any)}`
  );
  return response.json();
};

export const createTeamBenchmark = async (
  benchmark: TeamBenchmarkCreate
): Promise<TeamBenchmark> => {
  const response = await fetch(`${API_BASE}/benchmarks/team`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(benchmark),
  });
  return response.json();
};

export const importTeamBenchmarks = async (
  benchmarks: TeamBenchmarkCreate[]
): Promise<any> => {
  const response = await fetch(`${API_BASE}/benchmarks/team/import`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(benchmarks),
  });
  return response.json();
};

export const getIndustryBenchmarks = async (
  metric_name?: string
): Promise<IndustryBenchmark[]> => {
  const response = await fetch(
    `${API_BASE}/benchmarks/industry?${
      metric_name ? `metric_name=${metric_name}` : ''
    }`
  );
  return response.json();
};

export const compareMetrics = async (params: {
  start_date: string;
  end_date: string;
  team_name?: string;
  repo_id?: number;
}): Promise<any> => {
  const response = await fetch(
    `${API_BASE}/benchmarks/compare?${new URLSearchParams(params as any)}`
  );
  return response.json();
};

export const createSnapshot = async (params: {
  period_label: string;
  period_start: string;
  period_end: string;
  repo_id?: number;
}): Promise<HistoricalSnapshot> => {
  const response = await fetch(
    `${API_BASE}/benchmarks/snapshot?${new URLSearchParams(params as any)}`
  );
  return response.json();
};

export const getSnapshots = async (
  period_label?: string
): Promise<HistoricalSnapshot[]> => {
  const response = await fetch(
    `${API_BASE}/benchmarks/snapshot?${
      period_label ? `period_label=${period_label}` : ''
    }`
  );
  return response.json();
};

export const compareHistorical = async (periods: string): Promise<any> => {
  const response = await fetch(
    `${API_BASE}/benchmarks/compare/historical?periods=${periods}`
  );
  return response.json();
};
```

**File**: `frontend/src/components/TeamBenchmarkForm.tsx`

Create form for importing team benchmarks:

```typescript
import React, { useState } from 'react';
import { TeamBenchmarkCreate } from '../types';
import { createTeamBenchmark, importTeamBenchmarks } from '../services/api';

interface TeamBenchmarkFormProps {
  onSuccess?: () => void;
}

export const TeamBenchmarkForm: React.FC<TeamBenchmarkFormProps> = ({
  onSuccess,
}) => {
  const [formData, setFormData] = useState<TeamBenchmarkCreate>({
    metric_name: 'deployment_frequency',
    metric_value: 0,
    metric_unit: 'per_week',
    period_start: new Date().toISOString().split('T')[0],
    period_end: new Date().toISOString().split('T')[0],
    source: 'manual',
  });
  const [bulkMode, setBulkMode] = useState(false);
  const [bulkData, setBulkData] = useState('');
  const [loading, setLoading] = useState(false);

  const metricOptions = [
    {
      value: 'deployment_frequency',
      label: 'Deployment Frequency',
      unit: 'per_week',
    },
    { value: 'lead_time', label: 'Lead Time', unit: 'days' },
    {
      value: 'change_failure_rate',
      label: 'Change Failure Rate',
      unit: 'percentage',
    },
    { value: 'mttr', label: 'MTTR', unit: 'hours' },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (bulkMode) {
        // Parse CSV or JSON bulk data
        const lines = bulkData.split('\n').filter((l) => l.trim());
        const benchmarks: TeamBenchmarkCreate[] = lines.map((line) => {
          const [metric_name, value, start, end, team] = line.split(',');
          return {
            metric_name: metric_name.trim(),
            metric_value: parseFloat(value.trim()),
            metric_unit: metricOptions.find(
              (m) => m.value === metric_name.trim()
            )?.unit,
            period_start: start.trim(),
            period_end: end.trim(),
            team_name: team?.trim(),
            source: 'manual',
          };
        });
        await importTeamBenchmarks(benchmarks);
      } else {
        await createTeamBenchmark(formData);
      }
      onSuccess?.();
    } catch (error) {
      console.error('Error saving benchmark:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className='space-y-4'>
      <div className='flex gap-2 mb-4'>
        <button
          onClick={() => setBulkMode(false)}
          className={`px-4 py-2 rounded ${
            !bulkMode ? 'bg-blue-600 text-white' : 'bg-gray-200'
          }`}
        >
          Single Entry
        </button>
        <button
          onClick={() => setBulkMode(true)}
          className={`px-4 py-2 rounded ${
            bulkMode ? 'bg-blue-600 text-white' : 'bg-gray-200'
          }`}
        >
          Bulk Import
        </button>
      </div>

      <form onSubmit={handleSubmit} className='space-y-4'>
        {!bulkMode ? (
          <>
            <div>
              <label className='block text-sm font-medium mb-1'>Metric</label>
              <select
                value={formData.metric_name}
                onChange={(e) => {
                  const selected = metricOptions.find(
                    (m) => m.value === e.target.value
                  );
                  setFormData({
                    ...formData,
                    metric_name: e.target.value,
                    metric_unit: selected?.unit,
                  });
                }}
                className='w-full px-3 py-2 border rounded'
                required
              >
                {metricOptions.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className='block text-sm font-medium mb-1'>Value</label>
              <input
                type='number'
                step='0.01'
                value={formData.metric_value}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    metric_value: parseFloat(e.target.value),
                  })
                }
                className='w-full px-3 py-2 border rounded'
                required
              />
            </div>

            <div className='grid grid-cols-2 gap-4'>
              <div>
                <label className='block text-sm font-medium mb-1'>
                  Period Start
                </label>
                <input
                  type='date'
                  value={formData.period_start}
                  onChange={(e) =>
                    setFormData({ ...formData, period_start: e.target.value })
                  }
                  className='w-full px-3 py-2 border rounded'
                  required
                />
              </div>
              <div>
                <label className='block text-sm font-medium mb-1'>
                  Period End
                </label>
                <input
                  type='date'
                  value={formData.period_end}
                  onChange={(e) =>
                    setFormData({ ...formData, period_end: e.target.value })
                  }
                  className='w-full px-3 py-2 border rounded'
                  required
                />
              </div>
            </div>

            <div>
              <label className='block text-sm font-medium mb-1'>
                Team Name (optional)
              </label>
              <input
                type='text'
                value={formData.team_name || ''}
                onChange={(e) =>
                  setFormData({ ...formData, team_name: e.target.value })
                }
                className='w-full px-3 py-2 border rounded'
                placeholder='e.g., Team Alpha (anonymized)'
              />
            </div>
          </>
        ) : (
          <div>
            <label className='block text-sm font-medium mb-1'>
              Bulk Import (CSV format:
              metric_name,value,start_date,end_date,team_name)
            </label>
            <textarea
              value={bulkData}
              onChange={(e) => setBulkData(e.target.value)}
              className='w-full px-3 py-2 border rounded font-mono text-sm'
              rows={10}
              placeholder='deployment_frequency,3.5,2024-01-01,2024-03-31,Team Alpha&#10;lead_time,2.5,2024-01-01,2024-03-31,Team Alpha'
            />
          </div>
        )}

        <button
          type='submit'
          disabled={loading}
          className='px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50'
        >
          {loading
            ? 'Saving...'
            : bulkMode
            ? 'Import Benchmarks'
            : 'Create Benchmark'}
        </button>
      </form>
    </div>
  );
};
```

**Task**: `bench-001` (Frontend part)

---

#### Day 3: Comparison Dashboard

**File**: `frontend/src/components/ComparisonDashboard.tsx`

Create comparison visualization component:

```typescript
import React, { useEffect, useState } from 'react';
import { compareMetrics, getIndustryBenchmarks } from '../services/api';
import { ComparisonResult } from '../types';

interface ComparisonDashboardProps {
  startDate: string;
  endDate: string;
  teamName?: string;
  repoId?: number;
}

export const ComparisonDashboard: React.FC<ComparisonDashboardProps> = ({
  startDate,
  endDate,
  teamName,
  repoId,
}) => {
  const [comparisons, setComparisons] = useState<any>(null);
  const [industryBenchmarks, setIndustryBenchmarks] = useState<any>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [startDate, endDate, teamName, repoId]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [compData, industryData] = await Promise.all([
        compareMetrics({
          start_date: startDate,
          end_date: endDate,
          team_name: teamName,
          repo_id: repoId,
        }),
        getIndustryBenchmarks(),
      ]);
      setComparisons(compData);

      // Organize industry benchmarks by metric
      const organized: any = {};
      industryData.forEach((b: any) => {
        if (!organized[b.metric_name]) {
          organized[b.metric_name] = [];
        }
        organized[b.metric_name].push(b);
      });
      setIndustryBenchmarks(organized);
    } catch (error) {
      console.error('Error loading comparison data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div>Loading comparisons...</div>;
  if (!comparisons) return <div>No comparison data available</div>;

  const getCategoryColor = (category?: string) => {
    switch (category) {
      case 'elite':
        return 'bg-green-100 text-green-800 border-green-500';
      case 'high':
        return 'bg-blue-100 text-blue-800 border-blue-500';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-500';
      case 'low':
        return 'bg-red-100 text-red-800 border-red-500';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-500';
    }
  };

  const getPercentileColor = (percentile?: number) => {
    if (!percentile) return 'bg-gray-200';
    if (percentile >= 75) return 'bg-green-500';
    if (percentile >= 50) return 'bg-blue-500';
    if (percentile >= 25) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const metricLabels: Record<string, string> = {
    deployment_frequency: 'Deployment Frequency',
    lead_time: 'Lead Time for Changes',
    change_failure_rate: 'Change Failure Rate',
    mttr: 'Mean Time to Recovery',
  };

  const metricUnits: Record<string, string> = {
    deployment_frequency: 'per week',
    lead_time: 'days',
    change_failure_rate: '%',
    mttr: 'hours',
  };

  return (
    <div className='space-y-6'>
      <h2 className='text-2xl font-bold'>Metrics Comparison</h2>

      {Object.entries(comparisons.comparisons || {}).map(
        ([metricName, comp]: [string, any]) => (
          <div key={metricName} className='p-6 border rounded-lg'>
            <h3 className='text-xl font-semibold mb-4'>
              {metricLabels[metricName] || metricName}
            </h3>

            <div className='grid grid-cols-1 md:grid-cols-3 gap-4 mb-4'>
              {/* Your Value */}
              <div className='p-4 bg-blue-50 rounded'>
                <p className='text-sm text-gray-600 mb-1'>Your Value</p>
                <p className='text-2xl font-bold'>
                  {comp.your_value.toFixed(2)} {metricUnits[metricName]}
                </p>
              </div>

              {/* Team Average */}
              {comp.team_average !== null &&
                comp.team_average !== undefined && (
                  <div className='p-4 bg-gray-50 rounded'>
                    <p className='text-sm text-gray-600 mb-1'>Team Average</p>
                    <p className='text-2xl font-bold'>
                      {comp.team_average.toFixed(2)} {metricUnits[metricName]}
                    </p>
                    {comp.team_percentile !== null &&
                      comp.team_percentile !== undefined && (
                        <p className='text-sm text-gray-500 mt-1'>
                          You're in the top {100 - comp.team_percentile}%
                        </p>
                      )}
                  </div>
                )}

              {/* Industry Category */}
              {comp.industry_category && (
                <div
                  className={`p-4 rounded border-l-4 ${getCategoryColor(
                    comp.industry_category
                  )}`}
                >
                  <p className='text-sm mb-1'>Industry Category</p>
                  <p className='text-xl font-bold capitalize'>
                    {comp.industry_category}
                  </p>
                  {comp.industry_percentile && (
                    <p className='text-sm mt-1'>
                      Estimated top {100 - comp.industry_percentile}% globally
                    </p>
                  )}
                </div>
              )}
            </div>

            {/* Percentile Bar */}
            {comp.team_percentile !== null &&
              comp.team_percentile !== undefined && (
                <div className='mt-4'>
                  <div className='flex justify-between text-sm mb-1'>
                    <span>Team Percentile Ranking</span>
                    <span>{comp.team_percentile.toFixed(1)}th percentile</span>
                  </div>
                  <div className='w-full bg-gray-200 rounded-full h-4 relative'>
                    <div
                      className={`h-4 rounded-full ${getPercentileColor(
                        comp.team_percentile
                      )}`}
                      style={{ width: `${comp.team_percentile}%` }}
                    />
                    <div
                      className='absolute top-0 h-4 w-0.5 bg-black'
                      style={{ left: `${comp.team_percentile}%` }}
                    />
                  </div>
                  <div className='flex justify-between text-xs text-gray-500 mt-1'>
                    <span>0%</span>
                    <span>50%</span>
                    <span>100%</span>
                  </div>
                </div>
              )}
          </div>
        )
      )}
    </div>
  );
};
```

**Task**: `bench-002` (Frontend part)

---

#### Day 4: Percentile Ranking Visual

**File**: `frontend/src/components/PercentileRanking.tsx`

Create dedicated percentile ranking component:

```typescript
import React, { useEffect, useState } from 'react';
import { compareMetrics } from '../services/api';

interface PercentileRankingProps {
  startDate: string;
  endDate: string;
  teamName?: string;
  repoId?: number;
}

export const PercentileRanking: React.FC<PercentileRankingProps> = ({
  startDate,
  endDate,
  teamName,
  repoId,
}) => {
  const [comparisons, setComparisons] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [startDate, endDate, teamName, repoId]);

  const loadData = async () => {
    setLoading(true);
    try {
      const data = await compareMetrics({
        start_date: startDate,
        end_date: endDate,
        team_name: teamName,
        repo_id: repoId,
      });
      setComparisons(data);
    } catch (error) {
      console.error('Error loading percentile data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div>Loading percentile rankings...</div>;
  if (!comparisons) return <div>No data available</div>;

  const getPercentileLabel = (percentile?: number) => {
    if (!percentile) return 'N/A';
    if (percentile >= 90) return 'Top 10%';
    if (percentile >= 75) return 'Top 25%';
    if (percentile >= 50) return 'Top 50%';
    if (percentile >= 25) return 'Bottom 50%';
    return 'Bottom 25%';
  };

  const getPercentileColor = (percentile?: number) => {
    if (!percentile) return 'bg-gray-200';
    if (percentile >= 75) return 'bg-green-500';
    if (percentile >= 50) return 'bg-blue-500';
    if (percentile >= 25) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const metricLabels: Record<string, string> = {
    deployment_frequency: 'Deployment Frequency',
    lead_time: 'Lead Time',
    change_failure_rate: 'Change Failure Rate',
    mttr: 'MTTR',
  };

  return (
    <div className='space-y-4'>
      <h2 className='text-2xl font-bold'>Percentile Rankings</h2>
      <p className='text-gray-600'>Your position relative to team averages</p>

      <div className='grid gap-4'>
        {Object.entries(comparisons.comparisons || {}).map(
          ([metricName, comp]: [string, any]) => {
            if (
              comp.team_percentile === null ||
              comp.team_percentile === undefined
            ) {
              return null;
            }

            return (
              <div key={metricName} className='p-4 border rounded-lg'>
                <div className='flex justify-between items-center mb-2'>
                  <h3 className='font-semibold'>
                    {metricLabels[metricName] || metricName}
                  </h3>
                  <span
                    className={`px-3 py-1 rounded text-sm font-bold ${getPercentileColor(
                      comp.team_percentile
                    )} text-white`}
                  >
                    {getPercentileLabel(comp.team_percentile)}
                  </span>
                </div>

                <div className='relative'>
                  <div className='w-full bg-gray-200 rounded-full h-6'>
                    <div
                      className={`h-6 rounded-full ${getPercentileColor(
                        comp.team_percentile
                      )} transition-all`}
                      style={{ width: `${comp.team_percentile}%` }}
                    />
                  </div>
                  <div className='flex justify-between text-xs text-gray-500 mt-1'>
                    <span>0th percentile</span>
                    <span className='font-semibold'>
                      {comp.team_percentile.toFixed(1)}th percentile
                    </span>
                    <span>100th percentile</span>
                  </div>
                </div>

                <div className='mt-2 text-sm text-gray-600'>
                  <p>
                    Your value: <strong>{comp.your_value.toFixed(2)}</strong>
                    {comp.team_average !== null &&
                      comp.team_average !== undefined && (
                        <>
                          {' '}
                          • Team average: <strong>
                            {comp.team_average.toFixed(2)}
                          </strong>
                        </>
                      )}
                  </p>
                </div>
              </div>
            );
          }
        )}
      </div>
    </div>
  );
};
```

**Task**: `bench-003`

---

#### Day 5: Historical Comparison

**File**: `frontend/src/components/HistoricalComparison.tsx`

Create historical comparison component:

```typescript
import React, { useEffect, useState } from 'react';
import {
  compareHistorical,
  getSnapshots,
  createSnapshot,
} from '../services/api';

interface HistoricalComparisonProps {
  periods: string[]; // e.g., ['Q1-2024', 'Q2-2024', 'Q3-2024']
}

export const HistoricalComparison: React.FC<HistoricalComparisonProps> = ({
  periods,
}) => {
  const [comparison, setComparison] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadComparison();
  }, [periods.join(',')]);

  const loadComparison = async () => {
    setLoading(true);
    try {
      const data = await compareHistorical(periods.join(','));
      setComparison(data);
    } catch (error) {
      console.error('Error loading historical comparison:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div>Loading historical comparison...</div>;
  if (!comparison) return <div>No historical data available</div>;

  const getTrendIcon = (trend?: string) => {
    switch (trend) {
      case 'improving':
        return '📈';
      case 'declining':
        return '📉';
      case 'stable':
        return '➡️';
      default:
        return '';
    }
  };

  const getTrendColor = (trend?: string) => {
    switch (trend) {
      case 'improving':
        return 'text-green-600';
      case 'declining':
        return 'text-red-600';
      case 'stable':
        return 'text-gray-600';
      default:
        return 'text-gray-600';
    }
  };

  const metricLabels: Record<string, string> = {
    deployment_frequency: 'Deployment Frequency',
    lead_time: 'Lead Time',
    change_failure_rate: 'Change Failure Rate',
    mttr: 'MTTR',
  };

  return (
    <div className='space-y-6'>
      <h2 className='text-2xl font-bold'>Quarter-over-Quarter Comparison</h2>

      {Object.entries(comparison.comparisons || {}).map(
        ([metricName, comp]: [string, any]) => (
          <div key={metricName} className='p-6 border rounded-lg'>
            <h3 className='text-xl font-semibold mb-4'>
              {metricLabels[metricName] || metricName}
            </h3>

            {/* Trend Indicator */}
            {comp.trend && (
              <div
                className={`mb-4 flex items-center gap-2 ${getTrendColor(
                  comp.trend
                )}`}
              >
                <span className='text-2xl'>{getTrendIcon(comp.trend)}</span>
                <span className='font-semibold capitalize'>{comp.trend}</span>
                {comp.trend_percentage !== null &&
                  comp.trend_percentage !== undefined && (
                    <span className='text-sm'>
                      ({comp.trend_percentage > 0 ? '+' : ''}
                      {comp.trend_percentage.toFixed(1)}%)
                    </span>
                  )}
              </div>
            )}

            {/* Values by Period */}
            <div className='grid grid-cols-2 md:grid-cols-4 gap-4'>
              {comp.values?.map((v: any, idx: number) => (
                <div key={idx} className='p-3 bg-gray-50 rounded'>
                  <p className='text-sm text-gray-600 mb-1'>{v.period}</p>
                  <p className='text-lg font-bold'>{v.value.toFixed(2)}</p>
                </div>
              ))}
            </div>

            {/* Growth Summary */}
            {comp.first_value !== null && comp.last_value !== null && (
              <div className='mt-4 p-3 bg-blue-50 rounded'>
                <p className='text-sm text-gray-600'>
                  From {comp.first_value.toFixed(2)} to{' '}
                  {comp.last_value.toFixed(2)}
                  {comp.trend_percentage !== null &&
                    comp.trend_percentage !== undefined && (
                      <span className='ml-2 font-semibold'>
                        ({comp.trend_percentage > 0 ? '+' : ''}
                        {comp.trend_percentage.toFixed(1)}% change)
                      </span>
                    )}
                </p>
              </div>
            )}
          </div>
        )
      )}
    </div>
  );
};
```

**File**: `frontend/src/components/SnapshotCreator.tsx`

Create component for creating snapshots:

```typescript
import React, { useState } from 'react';
import { createSnapshot } from '../services/api';

interface SnapshotCreatorProps {
  onSuccess?: () => void;
}

export const SnapshotCreator: React.FC<SnapshotCreatorProps> = ({
  onSuccess,
}) => {
  const [periodLabel, setPeriodLabel] = useState('');
  const [periodStart, setPeriodStart] = useState('');
  const [periodEnd, setPeriodEnd] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await createSnapshot({
        period_label: periodLabel,
        period_start: periodStart,
        period_end: periodEnd,
      });
      setPeriodLabel('');
      setPeriodStart('');
      setPeriodEnd('');
      onSuccess?.();
    } catch (error) {
      console.error('Error creating snapshot:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className='space-y-4 p-4 border rounded'>
      <h3 className='font-semibold'>Create Historical Snapshot</h3>

      <div>
        <label className='block text-sm font-medium mb-1'>Period Label</label>
        <input
          type='text'
          value={periodLabel}
          onChange={(e) => setPeriodLabel(e.target.value)}
          className='w-full px-3 py-2 border rounded'
          placeholder='e.g., Q1-2024'
          required
        />
      </div>

      <div className='grid grid-cols-2 gap-4'>
        <div>
          <label className='block text-sm font-medium mb-1'>Start Date</label>
          <input
            type='date'
            value={periodStart}
            onChange={(e) => setPeriodStart(e.target.value)}
            className='w-full px-3 py-2 border rounded'
            required
          />
        </div>
        <div>
          <label className='block text-sm font-medium mb-1'>End Date</label>
          <input
            type='date'
            value={periodEnd}
            onChange={(e) => setPeriodEnd(e.target.value)}
            className='w-full px-3 py-2 border rounded'
            required
          />
        </div>
      </div>

      <button
        type='submit'
        disabled={loading}
        className='px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50'
      >
        {loading ? 'Creating...' : 'Create Snapshot'}
      </button>
    </form>
  );
};
```

**Task**: `bench-004` (Frontend part)

---

### Task Group 5: Integration & Polish (2 days)

#### Day 1: Manager Report Integration

**File**: `backend/app/services/report_generator.py`

Add comparison data to report:

```python
def aggregate_report_data(
    db: Session,
    start_date: datetime,
    end_date: datetime,
    repo_id: Optional[int] = None
) -> Dict:
    # ... existing code ...

    # Comparison & Benchmarks
    from ..services.comparison_service import compare_dora_metrics

    comparison_data = compare_dora_metrics(
        db, start_date, end_date, None, repo_id
    )

    return {
        # ... existing data ...
        'comparisons': comparison_data.get('comparisons', {}),
        'benchmark_summary': {
            'team_percentiles': {
                metric: comp.get('team_percentile')
                for metric, comp in comparison_data.get('comparisons', {}).items()
                if comp.get('team_percentile') is not None
            },
            'industry_categories': {
                metric: comp.get('industry_category')
                for metric, comp in comparison_data.get('comparisons', {}).items()
                if comp.get('industry_category')
            }
        }
    }
```

Update report template to include comparison section:

```python
def generate_report_sections(data: Dict, llm_service) -> Dict:
    sections = {
        # ... existing sections ...
    }

    # Comparison & Benchmarks Section
    if data.get('comparisons'):
        benchmark_summary = []
        for metric_name, comp in data['comparisons'].items():
            summary = {
                'metric': metric_name,
                'your_value': comp.get('your_value'),
                'team_percentile': comp.get('team_percentile'),
                'industry_category': comp.get('industry_category'),
            }
            if summary['team_percentile']:
                summary['statement'] = f"Your {metric_name} is in the top {100 - summary['team_percentile']:.0f}% of the team"
            benchmark_summary.append(summary)

        sections['benchmarks'] = benchmark_summary

    return sections
```

**Task**: Integration

---

#### Day 2: Dashboard Page Integration

**File**: `frontend/src/pages/Dashboard.tsx`

Add comparison widgets to dashboard:

```typescript
import { ComparisonDashboard } from '../components/ComparisonDashboard';
import { PercentileRanking } from '../components/PercentileRanking';
import { HistoricalComparison } from '../components/HistoricalComparison';

// Add to dashboard layout
<ComparisonDashboard
  startDate={startDate}
  endDate={endDate}
  teamName={teamName}
  repoId={repoId}
/>

<PercentileRanking
  startDate={startDate}
  endDate={endDate}
  teamName={teamName}
  repoId={repoId}
/>
```

**File**: `frontend/src/pages/ComparisonPage.tsx`

Create dedicated comparison page:

```typescript
import React, { useState } from 'react';
import { ComparisonDashboard } from '../components/ComparisonDashboard';
import { PercentileRanking } from '../components/PercentileRanking';
import { HistoricalComparison } from '../components/HistoricalComparison';
import { SnapshotCreator } from '../components/SnapshotCreator';
import { TeamBenchmarkForm } from '../components/TeamBenchmarkForm';

export const ComparisonPage: React.FC = () => {
  const [startDate, setStartDate] = useState(
    new Date(new Date().getFullYear(), 0, 1).toISOString().split('T')[0]
  );
  const [endDate, setEndDate] = useState(
    new Date().toISOString().split('T')[0]
  );
  const [activeTab, setActiveTab] = useState<
    'compare' | 'percentile' | 'historical' | 'import'
  >('compare');

  return (
    <div className='container mx-auto p-6 space-y-6'>
      <h1 className='text-3xl font-bold'>Comparison & Benchmarks</h1>

      <div className='flex gap-2 mb-4'>
        <input
          type='date'
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
          className='px-3 py-2 border rounded'
        />
        <input
          type='date'
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
          className='px-3 py-2 border rounded'
        />
      </div>

      <div className='flex gap-2 mb-4'>
        {(['compare', 'percentile', 'historical', 'import'] as const).map(
          (tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded ${
                activeTab === tab ? 'bg-blue-600 text-white' : 'bg-gray-200'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          )
        )}
      </div>

      {activeTab === 'compare' && (
        <ComparisonDashboard startDate={startDate} endDate={endDate} />
      )}

      {activeTab === 'percentile' && (
        <PercentileRanking startDate={startDate} endDate={endDate} />
      )}

      {activeTab === 'historical' && (
        <div className='space-y-4'>
          <SnapshotCreator />
          <HistoricalComparison periods={['Q1-2024', 'Q2-2024', 'Q3-2024']} />
        </div>
      )}

      {activeTab === 'import' && <TeamBenchmarkForm />}
    </div>
  );
};
```

**File**: `frontend/src/App.tsx`

Add route for comparison page:

```typescript
import { ComparisonPage } from './pages/ComparisonPage';

// Add route
<Route path='/comparison' element={<ComparisonPage />} />;
```

**Task**: Integration

---

## 📋 Integration Checklist

After implementing all task groups, ensure:

- [ ] All new models have migrations created and applied
- [ ] Industry benchmarks are seeded on startup
- [ ] All API endpoints are registered in `main.py`
- [ ] Frontend types are updated in `types/index.ts`
- [ ] API service methods are added to `services/api.ts`
- [ ] All components are added to appropriate pages
- [ ] Manager Report Generator includes comparison data
- [ ] Navigation updated in `App.tsx` for comparison page

---

## 🎯 Success Criteria Validation

### Team Benchmarks

- ✅ You can import anonymized team averages manually
- ✅ Bulk import via CSV works
- ✅ Benchmarks are stored and queryable by period

### Comparison

- ✅ Dashboard shows your metrics vs team vs industry
- ✅ DORA benchmarks are correctly categorized (Elite/High/Medium/Low)
- ✅ Comparison calculations are accurate

### Percentile Rankings

- ✅ Visual percentile ranking shows where you stand
- ✅ You can say "My cycle time is in the top 25% of the team"
- ✅ Percentile bars are visually clear

### Historical Comparison

- ✅ You can create snapshots for quarters
- ✅ Quarter-over-quarter comparison shows trends
- ✅ Dashboard shows growth quarter-over-quarter
- ✅ Trend indicators (improving/declining/stable) are accurate

---

## 📝 Notes

- **Team Benchmark Privacy**: Team benchmarks are anonymized by design. Team names are optional and can be generic identifiers.
- **Industry Benchmarks**: DORA benchmarks are seeded from research data. These can be updated as new research becomes available.
- **Percentile Calculation**: Uses standard percentile rank formula: (below + 0.5 _ equal) / total _ 100
- **Historical Snapshots**: Snapshots should be created at the end of each quarter for accurate comparisons.
- **Bulk Import Format**: CSV format: `metric_name,value,start_date,end_date,team_name`

---

## 🚀 Next Steps

1. Start with database models and migrations (Task Group 1)
2. Seed industry benchmarks on application startup
3. Implement comparison logic (Task Group 2)
4. Build API endpoints (Task Group 3)
5. Create frontend components (Task Group 4)
6. Integrate into Manager Reports and Dashboard (Task Group 5)

---

**Status**: Ready for implementation. All tasks defined with clear acceptance criteria.
