# Architecture Documentation

## Overview

DevPulse follows Domain-Driven Design (DDD) principles for the backend and uses TypeScript for the frontend.

## Backend Architecture (DDD)

### Domain Layer (`backend/domain/`)

The core business logic, independent of infrastructure:

- **Entities** (`entities/`): Rich domain models with business logic
  - `Commit`: Represents a git commit with validation and business methods
  - `Repository`: Represents a git repository
  - `LogbookEntry`: Represents a daily learning entry
  - `CareerMoment`: Represents career milestones (wins, failures, pivots, learning)
  - `Goal`: Represents goals/OKRs with progress tracking
  - `Feedback`: Represents peer feedback entries

- **Value Objects** (`value_objects/`): Immutable objects representing domain concepts
  - `CommitType`: Enum for commit categories
  - `DateRange`: Value object for date ranges with validation

- **Domain Services** (`services/`): Services containing domain logic
  - `CommitCategorizer`: Categorizes commits based on message patterns

### Application Layer (`backend/application/`)

Orchestrates domain objects to fulfill use cases:

- **Interfaces** (`interfaces/`): Define contracts for infrastructure (ports)
  - `IRepositoryRepository`: Repository persistence interface
  - `ICommitRepository`: Commit persistence interface
  - `ILogbookRepository`: Logbook persistence interface
  - `ILLMService`: LLM service interface
  - `IGitCrawlerService`: Git crawling interface

- **Use Cases** (`use_cases/`): Application services that orchestrate domain objects
- **DTOs** (`dto/`): Data Transfer Objects for application boundaries

### Infrastructure Layer (`backend/infrastructure/`)

Implements interfaces defined in the application layer:

- **Persistence** (`persistence/`): SQLAlchemy implementations of repositories
- **External** (`external/`): External service integrations (Git, LLM APIs)
- **API** (`api/`): FastAPI endpoints (currently in `app/api/`)
  - `moments.py`: Career moments CRUD endpoints
  - `goals.py`: Goals & OKRs tracking endpoints
  - `feedback.py`: Peer feedback endpoints
  - `time_patterns.py`: Working hours and time pattern analysis endpoints
  - `user_context.py`: User context management endpoints (Sprint 9)
  - `templates.py`: Report template management endpoints (Sprint 9)
  - `reports.py`: Report generation and editing endpoints (Sprint 9)

- **Services** (`services/`): Business logic services
  - `context_enrichment.py`: Enriches LLM prompts with user context (Sprint 9)
  - `template_service.py`: Manages report templates (Sprint 9)
  - `translation_service.py`: Translates report content (Sprint 9)
  - `report_generator.py`: Generates performance reports with template and language support (Sprint 9)

## Frontend Architecture

### TypeScript Structure

- **Types** (`src/types/`): Centralized type definitions
- **Components** (`src/components/`): Reusable UI components
- **Pages** (`src/pages/`): Page-level components
- **Services** (`src/services/`): API client with typed functions
- **Utils** (`src/lib/`): Utility functions

### Key Principles

1. **Type Safety**: All API responses and component props are typed
2. **Separation of Concerns**: API logic separated from UI components
3. **Reusability**: Components are small and focused
4. **Error Handling**: Proper error handling with user-friendly messages

## Dependency Flow

```
Infrastructure → Application → Domain
     ↑              ↑
     └──────────────┘
```

- Domain has NO dependencies
- Application depends only on Domain
- Infrastructure implements Application interfaces

## Migration Status

The project is currently in a hybrid state:

- ✅ Domain layer created with entities, value objects, and services
- ✅ Application interfaces defined
- ⚠️ Infrastructure still uses old structure (`app/` directory)
- ✅ Frontend fully migrated to TypeScript

Next steps:
1. Migrate infrastructure to implement application interfaces
2. Create use cases in application layer
3. Refactor API endpoints to use use cases
4. Complete DDD migration

