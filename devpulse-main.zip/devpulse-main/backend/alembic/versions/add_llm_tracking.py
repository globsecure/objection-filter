"""add llm tracking tables

Revision ID: add_llm_tracking
Revises: add_comparison_benchmarks
Create Date: 2025-01-27 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'add_llm_tracking'
down_revision: Union[str, None] = 'add_comparison_benchmarks'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # LLM Usage Logs
    op.create_table(
        'llm_usage_logs',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('provider', sa.String(), nullable=False),
        sa.Column('model', sa.String(), nullable=False),
        sa.Column('operation', sa.String(), nullable=False),
        sa.Column('input_tokens', sa.Integer(), nullable=True),
        sa.Column('output_tokens', sa.Integer(), nullable=True),
        sa.Column('cost_usd', sa.Float(), nullable=True),
        sa.Column('request_duration_ms', sa.Integer(), nullable=True),
        sa.Column('success', sa.Boolean(), nullable=True),
        sa.Column('error_message', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('(CURRENT_TIMESTAMP)'), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_llm_usage_logs_provider'), 'llm_usage_logs', ['provider'], unique=False)
    op.create_index(op.f('ix_llm_usage_logs_operation'), 'llm_usage_logs', ['operation'], unique=False)
    op.create_index(op.f('ix_llm_usage_logs_created_at'), 'llm_usage_logs', ['created_at'], unique=False)

    # LLM Rate Limits
    op.create_table(
        'llm_rate_limits',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('provider', sa.String(), nullable=False),
        sa.Column('requests_per_minute', sa.Integer(), nullable=True),
        sa.Column('tokens_per_minute', sa.Integer(), nullable=True),
        sa.Column('requests_per_day', sa.Integer(), nullable=True),
        sa.Column('current_minute_requests', sa.Integer(), nullable=True),
        sa.Column('current_minute_tokens', sa.Integer(), nullable=True),
        sa.Column('current_day_requests', sa.Integer(), nullable=True),
        sa.Column('last_reset_minute', sa.DateTime(timezone=True), nullable=True),
        sa.Column('last_reset_day', sa.DateTime(timezone=True), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('(CURRENT_TIMESTAMP)'), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('provider')
    )


def downgrade() -> None:
    op.drop_table('llm_rate_limits')
    op.drop_index(op.f('ix_llm_usage_logs_created_at'), table_name='llm_usage_logs')
    op.drop_index(op.f('ix_llm_usage_logs_operation'), table_name='llm_usage_logs')
    op.drop_index(op.f('ix_llm_usage_logs_provider'), table_name='llm_usage_logs')
    op.drop_table('llm_usage_logs')

