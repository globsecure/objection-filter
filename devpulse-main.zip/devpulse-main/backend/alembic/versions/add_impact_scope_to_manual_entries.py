"""add impact_scope to manual_entries

Revision ID: add_impact_scope
Revises: add_user_settings
Create Date: 2025-01-XX XX:XX:XX.XXXXXX

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'add_impact_scope'
down_revision: Union[str, None] = 'add_user_settings'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column('manual_entries', sa.Column('impact_scope', sa.String(), nullable=True))
    op.create_index(op.f('ix_manual_entries_impact_scope'), 'manual_entries', ['impact_scope'], unique=False)


def downgrade() -> None:
    op.drop_index(op.f('ix_manual_entries_impact_scope'), table_name='manual_entries')
    op.drop_column('manual_entries', 'impact_scope')

