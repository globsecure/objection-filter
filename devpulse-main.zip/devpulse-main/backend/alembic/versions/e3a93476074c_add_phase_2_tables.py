"""add phase 2 tables

Revision ID: e3a93476074c
Revises: 
Create Date: 2025-12-26 17:15:08.359023

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'e3a93476074c'
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Add new columns to commits table (if they don't exist)
    conn = op.get_bind()
    inspector = sa.inspect(conn)
    commits_columns = [col['name'] for col in inspector.get_columns('commits')]
    
    if 'branch_name' not in commits_columns:
        op.add_column('commits', sa.Column('branch_name', sa.String(), nullable=True))
    if 'is_merge_commit' not in commits_columns:
        op.add_column('commits', sa.Column('is_merge_commit', sa.Boolean(), nullable=True, server_default='0'))
    if 'impact_category' not in commits_columns:
        op.add_column('commits', sa.Column('impact_category', sa.String(), nullable=True))
    
    # Create indexes (if they don't exist)
    indexes = [idx['name'] for idx in inspector.get_indexes('commits')]
    if 'ix_commits_branch_name' not in indexes:
        op.create_index(op.f('ix_commits_branch_name'), 'commits', ['branch_name'], unique=False)
    if 'ix_commits_impact_category' not in indexes:
        op.create_index(op.f('ix_commits_impact_category'), 'commits', ['impact_category'], unique=False)
    if 'ix_commits_is_merge_commit' not in indexes:
        op.create_index(op.f('ix_commits_is_merge_commit'), 'commits', ['is_merge_commit'], unique=False)
    
    # Create daily_logs table (if it doesn't exist)
    tables = inspector.get_table_names()
    if 'daily_logs' not in tables:
        op.create_table('daily_logs',
            sa.Column('id', sa.Integer(), nullable=False),
            sa.Column('date', sa.DateTime(timezone=True), server_default=sa.text('(CURRENT_TIMESTAMP)'), nullable=True),
            sa.Column('satisfaction_score', sa.Integer(), nullable=True),
            sa.Column('wellbeing_score', sa.Integer(), nullable=True),
            sa.Column('blockers', sa.Text(), nullable=True),
            sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('(CURRENT_TIMESTAMP)'), nullable=True),
            sa.PrimaryKeyConstraint('id')
        )
        op.create_index(op.f('ix_daily_logs_date'), 'daily_logs', ['date'], unique=False)
    
    # Create branch_metrics table (if it doesn't exist)
    if 'branch_metrics' not in tables:
        op.create_table('branch_metrics',
            sa.Column('id', sa.Integer(), nullable=False),
            sa.Column('repo_id', sa.Integer(), nullable=True),
            sa.Column('branch_name', sa.String(), nullable=True),
            sa.Column('first_commit_date', sa.DateTime(timezone=True), nullable=True),
            sa.Column('merge_date', sa.DateTime(timezone=True), nullable=True),
            sa.Column('merge_commit_hash', sa.String(), nullable=True),
            sa.Column('cycle_time_days', sa.Float(), nullable=True),
            sa.ForeignKeyConstraint(['repo_id'], ['repositories.id'], ),
            sa.PrimaryKeyConstraint('id')
        )
        op.create_index(op.f('ix_branch_metrics_repo_id'), 'branch_metrics', ['repo_id'], unique=False)
        op.create_index(op.f('ix_branch_metrics_branch_name'), 'branch_metrics', ['branch_name'], unique=False)


def downgrade() -> None:
    # Drop indexes
    op.drop_index(op.f('ix_branch_metrics_branch_name'), table_name='branch_metrics')
    op.drop_index(op.f('ix_branch_metrics_repo_id'), table_name='branch_metrics')
    op.drop_index(op.f('ix_daily_logs_date'), table_name='daily_logs')
    op.drop_index(op.f('ix_commits_impact_category'), table_name='commits')
    op.drop_index(op.f('ix_commits_is_merge_commit'), table_name='commits')
    op.drop_index(op.f('ix_commits_branch_name'), table_name='commits')
    
    # Drop tables
    op.drop_table('branch_metrics')
    op.drop_table('daily_logs')
    
    # Drop columns from commits table
    op.drop_column('commits', 'impact_category')
    op.drop_column('commits', 'is_merge_commit')
    op.drop_column('commits', 'branch_name')

