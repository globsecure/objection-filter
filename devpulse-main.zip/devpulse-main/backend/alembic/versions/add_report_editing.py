"""add report editing fields

Revision ID: add_report_editing
Revises: add_report_templates
Create Date: 2025-01-27 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'add_report_editing'
down_revision: Union[str, None] = 'add_report_templates'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Add original_report_data column
    op.add_column('saved_reports', sa.Column('original_report_data', sa.Text(), nullable=True))
    
    # Add edited_sections column (JSON)
    op.add_column('saved_reports', sa.Column('edited_sections', sa.Text(), nullable=True))
    
    # Add template_id column (ForeignKey)
    op.add_column('saved_reports', sa.Column('template_id', sa.Integer(), nullable=True))
    op.create_foreign_key(
        'fk_saved_reports_template_id',
        'saved_reports',
        'report_templates',
        ['template_id'],
        ['id']
    )


def downgrade() -> None:
    op.drop_constraint('fk_saved_reports_template_id', 'saved_reports', type_='foreignkey')
    op.drop_column('saved_reports', 'template_id')
    op.drop_column('saved_reports', 'edited_sections')
    op.drop_column('saved_reports', 'original_report_data')

