"""add user context table

Revision ID: add_user_context
Revises: add_saved_reports
Create Date: 2025-01-27 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'add_user_context'
down_revision: Union[str, None] = 'add_saved_reports'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        'user_context',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.String(), nullable=False),
        sa.Column('role', sa.String(), nullable=True),
        sa.Column('team', sa.String(), nullable=True),
        sa.Column('business_domain', sa.String(), nullable=True),
        sa.Column('company', sa.String(), nullable=True),
        sa.Column('preferred_language', sa.String(), server_default='en', nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('(CURRENT_TIMESTAMP)'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('user_id')
    )
    op.create_index(op.f('ix_user_context_user_id'), 'user_context', ['user_id'], unique=True)


def downgrade() -> None:
    op.drop_index(op.f('ix_user_context_user_id'), table_name='user_context')
    op.drop_table('user_context')

