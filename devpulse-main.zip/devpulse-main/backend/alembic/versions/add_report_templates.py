"""add report templates

Revision ID: add_report_templates
Revises: add_user_context
Create Date: 2025-01-27 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import json


# revision identifiers, used by Alembic.
revision: str = 'add_report_templates'
down_revision: Union[str, None] = 'add_user_context'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        'report_templates',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('template_type', sa.String(), nullable=True),
        sa.Column('sections', sa.Text(), nullable=True),
        sa.Column('prompt_overrides', sa.Text(), nullable=True),
        sa.Column('is_default', sa.Boolean(), server_default='0', nullable=True),
        sa.Column('user_id', sa.String(), server_default='default', nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('(CURRENT_TIMESTAMP)'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_report_templates_template_type'), 'report_templates', ['template_type'], unique=False)
    
    # Seed default templates
    conn = op.get_bind()
    
    # 1:1 Meeting Template (brief, focused)
    one_on_one_sections = json.dumps([
        "executive_summary",
        "key_achievements",
        "challenges",
        "goals"
    ])
    conn.execute(
        sa.text("""
            INSERT INTO report_templates (name, description, template_type, sections, is_default, user_id)
            VALUES ('1:1 Meeting', 'Brief summary for weekly 1:1 meetings', 'one_on_one', :sections, 1, 'default')
        """),
        {"sections": one_on_one_sections}
    )
    
    # Performance Review Template (comprehensive)
    perf_review_sections = json.dumps([
        "executive_summary",
        "key_achievements",
        "highlights",
        "goals",
        "challenges",
        "collaboration",
        "feedback",
        "metrics_snapshot",
        "work_patterns"
    ])
    conn.execute(
        sa.text("""
            INSERT INTO report_templates (name, description, template_type, sections, is_default, user_id)
            VALUES ('Performance Review', 'Comprehensive report for quarterly/annual reviews', 'performance_review', :sections, 0, 'default')
        """),
        {"sections": perf_review_sections}
    )


def downgrade() -> None:
    op.drop_index(op.f('ix_report_templates_template_type'), table_name='report_templates')
    op.drop_table('report_templates')

