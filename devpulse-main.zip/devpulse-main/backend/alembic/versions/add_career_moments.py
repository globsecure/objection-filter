"""add career_moments

Revision ID: add_career_moments
Revises: 7065c5d1b1a2
Create Date: 2025-01-27 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'add_career_moments'
down_revision: Union[str, None] = '7065c5d1b1a2'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        'career_moments',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('type', sa.String(), nullable=False),
        sa.Column('title', sa.String(), nullable=False),
        sa.Column('story', sa.Text(), nullable=True),
        sa.Column('impact', sa.Text(), nullable=True),
        sa.Column('witnesses', sa.String(), nullable=True),
        sa.Column('tags', sa.String(), nullable=True),
        sa.Column('related_commits', sa.String(), nullable=True),
        sa.Column('related_entries', sa.String(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('(CURRENT_TIMESTAMP)'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('(CURRENT_TIMESTAMP)'), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_career_moments_date'), 'career_moments', ['date'], unique=False)


def downgrade() -> None:
    op.drop_index(op.f('ix_career_moments_date'), table_name='career_moments')
    op.drop_table('career_moments')

