"""add user_settings table

Revision ID: add_user_settings
Revises: add_report_editing
Create Date: 2025-01-XX XX:XX:XX.XXXXXX

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'add_user_settings'
down_revision: Union[str, None] = 'add_report_editing'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        'user_settings',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.String(), nullable=True),
        sa.Column('enable_secret_detection', sa.Boolean(), nullable=True, server_default='1'),
        sa.Column('auto_redact_secrets', sa.Boolean(), nullable=True, server_default='0'),
        sa.Column('block_on_secret', sa.Boolean(), nullable=True, server_default='1'),
        sa.Column('redact_emails', sa.Boolean(), nullable=True, server_default='0'),
        sa.Column('redact_internal_urls', sa.Boolean(), nullable=True, server_default='0'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('(CURRENT_TIMESTAMP)'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('(CURRENT_TIMESTAMP)'), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_user_settings_user_id'), 'user_settings', ['user_id'], unique=True)


def downgrade() -> None:
    op.drop_index(op.f('ix_user_settings_user_id'), table_name='user_settings')
    op.drop_table('user_settings')

