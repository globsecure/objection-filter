"""add saved reports table

Revision ID: add_saved_reports
Revises: add_llm_tracking
Create Date: 2025-01-27 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'add_saved_reports'
down_revision: Union[str, None] = 'add_llm_tracking'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        'saved_reports',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(), nullable=False),
        sa.Column('period_start', sa.DateTime(timezone=True), nullable=False),
        sa.Column('period_end', sa.DateTime(timezone=True), nullable=False),
        sa.Column('quarter', sa.String(), nullable=True),
        sa.Column('report_data', sa.Text(), nullable=True),
        sa.Column('markdown_content', sa.Text(), nullable=True),
        sa.Column('pdf_path', sa.String(), nullable=True),
        sa.Column('repo_id', sa.Integer(), nullable=True),
        sa.Column('tags', sa.String(), nullable=True),
        sa.Column('notes', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('(CURRENT_TIMESTAMP)'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('(CURRENT_TIMESTAMP)'), nullable=True),
        sa.ForeignKeyConstraint(['repo_id'], ['repositories.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_saved_reports_period_start'), 'saved_reports', ['period_start'], unique=False)
    op.create_index(op.f('ix_saved_reports_period_end'), 'saved_reports', ['period_end'], unique=False)
    op.create_index(op.f('ix_saved_reports_quarter'), 'saved_reports', ['quarter'], unique=False)
    op.create_index(op.f('ix_saved_reports_created_at'), 'saved_reports', ['created_at'], unique=False)


def downgrade() -> None:
    op.drop_index(op.f('ix_saved_reports_created_at'), table_name='saved_reports')
    op.drop_index(op.f('ix_saved_reports_quarter'), table_name='saved_reports')
    op.drop_index(op.f('ix_saved_reports_period_end'), table_name='saved_reports')
    op.drop_index(op.f('ix_saved_reports_period_start'), table_name='saved_reports')
    op.drop_table('saved_reports')

