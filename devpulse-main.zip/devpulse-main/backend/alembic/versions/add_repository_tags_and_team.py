"""add repository tags and team

Revision ID: add_repo_tags_team
Revises: e3a93476074c
Create Date: 2025-01-27 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'add_repo_tags_team'
down_revision: Union[str, None] = 'e3a93476074c'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Check if columns already exist
    conn = op.get_bind()
    inspector = sa.inspect(conn)
    repos_columns = [col['name'] for col in inspector.get_columns('repositories')]
    
    if 'tags' not in repos_columns:
        op.add_column('repositories', sa.Column('tags', sa.String(), nullable=True))
    
    if 'team' not in repos_columns:
        op.add_column('repositories', sa.Column('team', sa.String(), nullable=True))
    
    # Create index for team (if it doesn't exist)
    indexes = [idx['name'] for idx in inspector.get_indexes('repositories')]
    if 'ix_repositories_team' not in indexes:
        op.create_index(op.f('ix_repositories_team'), 'repositories', ['team'], unique=False)


def downgrade() -> None:
    # Drop index
    op.drop_index(op.f('ix_repositories_team'), table_name='repositories')
    
    # Drop columns
    op.drop_column('repositories', 'team')
    op.drop_column('repositories', 'tags')

