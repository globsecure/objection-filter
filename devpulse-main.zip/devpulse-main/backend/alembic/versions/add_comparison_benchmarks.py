"""add_comparison_benchmarks

Revision ID: add_comparison_benchmarks
Revises: add_feedback
Create Date: 2025-01-27 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'add_comparison_benchmarks'
down_revision: Union[str, None] = 'add_feedback'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade():
    # Team Benchmarks
    op.create_table(
        'team_benchmarks',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('metric_name', sa.String(), nullable=False),
        sa.Column('metric_value', sa.Float(), nullable=False),
        sa.Column('metric_unit', sa.String(), nullable=True),
        sa.Column('period_start', sa.DateTime(timezone=True), nullable=False),
        sa.Column('period_end', sa.DateTime(timezone=True), nullable=False),
        sa.Column('team_name', sa.String(), nullable=True),
        sa.Column('source', sa.String(), nullable=True),
        sa.Column('notes', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_team_benchmarks_metric_name'), 'team_benchmarks', ['metric_name'], unique=False)
    op.create_index(op.f('ix_team_benchmarks_period_start'), 'team_benchmarks', ['period_start'], unique=False)
    op.create_index(op.f('ix_team_benchmarks_team_name'), 'team_benchmarks', ['team_name'], unique=False)

    # Industry Benchmarks
    op.create_table(
        'industry_benchmarks',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('metric_name', sa.String(), nullable=False),
        sa.Column('category', sa.String(), nullable=False),
        sa.Column('min_value', sa.Float(), nullable=True),
        sa.Column('max_value', sa.Float(), nullable=True),
        sa.Column('source', sa.String(), nullable=True),
        sa.Column('year', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_industry_benchmarks_metric_name'), 'industry_benchmarks', ['metric_name'], unique=False)

    # Historical Snapshots
    op.create_table(
        'historical_snapshots',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('period_label', sa.String(), nullable=False),
        sa.Column('period_start', sa.DateTime(timezone=True), nullable=False),
        sa.Column('period_end', sa.DateTime(timezone=True), nullable=False),
        sa.Column('snapshot_data', sa.Text(), nullable=True),
        sa.Column('dora_metrics', sa.Text(), nullable=True),
        sa.Column('space_metrics', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_historical_snapshots_period_label'), 'historical_snapshots', ['period_label'], unique=False)


def downgrade():
    op.drop_index(op.f('ix_historical_snapshots_period_label'), table_name='historical_snapshots')
    op.drop_table('historical_snapshots')
    op.drop_index(op.f('ix_industry_benchmarks_metric_name'), table_name='industry_benchmarks')
    op.drop_table('industry_benchmarks')
    op.drop_index(op.f('ix_team_benchmarks_team_name'), table_name='team_benchmarks')
    op.drop_index(op.f('ix_team_benchmarks_period_start'), table_name='team_benchmarks')
    op.drop_index(op.f('ix_team_benchmarks_metric_name'), table_name='team_benchmarks')
    op.drop_table('team_benchmarks')

