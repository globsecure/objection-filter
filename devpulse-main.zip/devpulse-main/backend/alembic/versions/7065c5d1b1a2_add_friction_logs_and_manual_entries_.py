"""add friction_logs and manual_entries tables

Revision ID: 7065c5d1b1a2
Revises: e3a93476074c
Create Date: 2025-12-26 17:30:21.256065

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '7065c5d1b1a2'
down_revision: Union[str, None] = 'e3a93476074c'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Create friction_logs table
    op.create_table(
        'friction_logs',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('type', sa.String(), nullable=False),
        sa.Column('description', sa.Text(), nullable=False),
        sa.Column('impact_level', sa.Integer(), nullable=True),
        sa.Column('tags', sa.String(), nullable=True),
        sa.Column('resolution', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('(CURRENT_TIMESTAMP)'), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_friction_logs_date'), 'friction_logs', ['date'], unique=False)
    op.create_index(op.f('ix_friction_logs_type'), 'friction_logs', ['type'], unique=False)
    
    # Create manual_entries table
    op.create_table(
        'manual_entries',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('type', sa.String(), nullable=False),
        sa.Column('title', sa.String(), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('impact', sa.Text(), nullable=True),
        sa.Column('collaborators', sa.String(), nullable=True),
        sa.Column('links', sa.String(), nullable=True),
        sa.Column('duration_minutes', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('(CURRENT_TIMESTAMP)'), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_manual_entries_date'), 'manual_entries', ['date'], unique=False)
    op.create_index(op.f('ix_manual_entries_type'), 'manual_entries', ['type'], unique=False)


def downgrade() -> None:
    op.drop_index(op.f('ix_manual_entries_type'), table_name='manual_entries')
    op.drop_index(op.f('ix_manual_entries_date'), table_name='manual_entries')
    op.drop_table('manual_entries')
    op.drop_index(op.f('ix_friction_logs_type'), table_name='friction_logs')
    op.drop_index(op.f('ix_friction_logs_date'), table_name='friction_logs')
    op.drop_table('friction_logs')

