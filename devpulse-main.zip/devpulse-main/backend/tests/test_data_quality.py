import pytest
from datetime import datetime, timedelta
from app.analysis.data_quality import (
    calculate_data_completeness,
    generate_smart_reminders,
    generate_validation_warnings
)
from app.models import Commit, FrictionLog, ManualEntry, CareerMoment, Goal


def test_data_completeness_empty(db):
    """Test completeness with no data"""
    result = calculate_data_completeness(db)
    assert result['overall_score'] == 100  # Perfect if no data
    assert 'breakdown' in result
    assert 'issues' in result
    assert 'recommendations' in result


def test_data_completeness_with_uncategorized(db):
    """Test completeness with uncategorized commits"""
    commit = Commit(
        hash="test",
        message="wip",
        date=datetime.now(),
        files_changed=1,
        insertions=1,
        deletions=0,
        type="Unknown"
    )
    db.add(commit)
    db.commit()
    
    result = calculate_data_completeness(db)
    assert result['overall_score'] < 100
    assert len(result['issues']) > 0
    assert 'uncategorized_commits' in [i['type'] for i in result['issues']]


def test_data_completeness_with_unresolved_incidents(db):
    """Test completeness with unresolved incidents"""
    incident = FrictionLog(
        date=datetime.now(),
        type="incident",
        description="Test incident",
        impact_level=3,
        resolution=None
    )
    db.add(incident)
    db.commit()
    
    result = calculate_data_completeness(db)
    assert result['overall_score'] < 100
    assert len(result['issues']) > 0
    assert 'unresolved_incidents' in [i['type'] for i in result['issues']]


def test_data_completeness_with_incomplete_reviews(db):
    """Test completeness with code reviews without collaborators"""
    review = ManualEntry(
        date=datetime.now(),
        type="code_review",
        title="Test Review",
        description="Test description",
        collaborators=None
    )
    db.add(review)
    db.commit()
    
    result = calculate_data_completeness(db)
    assert result['overall_score'] < 100
    assert len(result['issues']) > 0
    assert 'incomplete_code_reviews' in [i['type'] for i in result['issues']]


def test_smart_reminders_no_data(db):
    """Test reminders with no data"""
    reminders = generate_smart_reminders(db, days=7)
    assert isinstance(reminders, list)


def test_smart_reminders_with_commits_no_friction(db):
    """Test reminders when commits exist but no friction logs"""
    commit = Commit(
        hash="test",
        message="feat: add feature",
        date=datetime.now(),
        files_changed=5,
        insertions=50,
        deletions=10,
        type="feature"
    )
    db.add(commit)
    db.commit()
    
    reminders = generate_smart_reminders(db, days=7)
    assert isinstance(reminders, list)
    # May or may not have reminders depending on commit count


def test_smart_reminders_with_unresolved_incidents(db):
    """Test reminders for unresolved incidents"""
    incident = FrictionLog(
        date=datetime.now(),
        type="incident",
        description="Test incident",
        impact_level=3,
        resolution=None
    )
    db.add(incident)
    db.commit()
    
    reminders = generate_smart_reminders(db, days=7)
    assert len(reminders) > 0
    assert any(r['type'] == 'unresolved_incidents' for r in reminders)


def test_validation_warnings_empty(db):
    """Test warnings with no data"""
    warnings = generate_validation_warnings(db)
    assert isinstance(warnings, list)


def test_validation_warnings_with_incidents(db):
    """Test warnings for incidents without resolution"""
    incident = FrictionLog(
        date=datetime.now(),
        type="incident",
        description="Test incident",
        impact_level=3,
        resolution=None
    )
    db.add(incident)
    db.commit()
    
    warnings = generate_validation_warnings(db)
    assert len(warnings) > 0
    assert any(w['type'] == 'incident_no_resolution' for w in warnings)


def test_validation_warnings_with_incomplete_reviews(db):
    """Test warnings for code reviews without collaborators"""
    review = ManualEntry(
        date=datetime.now(),
        type="code_review",
        title="Test Review",
        description="Test description",
        collaborators=None
    )
    db.add(review)
    db.commit()
    
    warnings = generate_validation_warnings(db)
    assert len(warnings) > 0
    assert any(w['type'] == 'code_review_no_collaborators' for w in warnings)

