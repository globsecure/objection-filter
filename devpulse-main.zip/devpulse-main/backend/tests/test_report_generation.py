import pytest
from datetime import datetime, timedelta
from app.services.report_generator import generate_manager_report
from app.models import Commit, FrictionLog, ManualEntry


def test_report_generation_with_mock_llm(db, monkeypatch):
    """Test report generation with mocked LLM"""
    # Create test data
    commit = Commit(
        hash="test123",
        message="feat: add feature",
        date=datetime.now(),
        files_changed=5,
        insertions=50,
        deletions=10,
        type="feature"
    )
    db.add(commit)
    db.commit()
    
    # Mock LLM response
    def mock_llm_summary(*args, **kwargs):
        return "Test summary"
    
    monkeypatch.setattr(
        "app.analysis.llm_service.get_llm_provider",
        lambda **kwargs: type('MockProvider', (), {
            'generate_executive_summary': lambda *args, **kwargs: "Test executive summary",
            'generate_challenges_section': lambda *args, **kwargs: "Test challenges",
            'generate_collaboration_section': lambda *args, **kwargs: "Test collaboration",
            'summarize_commits': lambda *args, **kwargs: "- Test achievement"
        })()
    )
    
    report = generate_manager_report(
        db,
        start_date=datetime.now() - timedelta(days=30),
        end_date=datetime.now(),
        use_llm=True
    )
    
    assert report is not None
    assert hasattr(report, 'executive_summary')
    assert hasattr(report, 'key_achievements')
    assert hasattr(report, 'metrics_snapshot')


def test_report_generation_fallback_on_llm_error(db, monkeypatch):
    """Test report generation falls back when LLM fails"""
    # Mock LLM to raise error
    def mock_llm_error(*args, **kwargs):
        raise Exception("LLM API error")
    
    monkeypatch.setattr(
        "app.analysis.llm_service.get_llm_provider",
        lambda **kwargs: type('MockProvider', (), {
            'generate_executive_summary': lambda *args, **kwargs: (_ for _ in ()).throw(Exception("LLM API error")),
            'generate_challenges_section': lambda *args, **kwargs: (_ for _ in ()).throw(Exception("LLM API error")),
            'generate_collaboration_section': lambda *args, **kwargs: (_ for _ in ()).throw(Exception("LLM API error")),
            'summarize_commits': lambda *args, **kwargs: (_ for _ in ()).throw(Exception("LLM API error"))
        })()
    )
    
    # Should still generate report with template fallback
    report = generate_manager_report(
        db,
        start_date=datetime.now() - timedelta(days=30),
        end_date=datetime.now(),
        use_llm=True
    )
    
    assert report is not None
    assert hasattr(report, 'executive_summary')


def test_report_export_formats(db):
    """Test report export in different formats"""
    # Generate report
    report = generate_manager_report(
        db,
        start_date=datetime.now() - timedelta(days=30),
        end_date=datetime.now(),
        use_llm=False  # Use template-based generation
    )
    
    # Test Markdown export
    markdown = report.to_markdown()
    assert markdown is not None
    assert "#" in markdown or "##" in markdown  # Should have headers
    
    # Test JSON export
    json_data = report.to_dict()
    assert json_data is not None
    assert 'executive_summary' in json_data or 'period' in json_data

