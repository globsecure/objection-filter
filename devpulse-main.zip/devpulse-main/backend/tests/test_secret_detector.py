import pytest
from app.services.secret_detector import SecretDetector, SecretType


def test_detect_api_key():
    """Test detection of API keys"""
    detector = SecretDetector()
    text = "api_key: sk-1234567890abcdefghijklmnopqrstuvwxyz"
    secrets = detector.detect_secrets(text)
    
    assert len(secrets) > 0
    assert any(s['type'] == 'api_key' for s in secrets)


def test_detect_password():
    """Test detection of passwords"""
    detector = SecretDetector()
    text = "password: mySecretPassword123"
    secrets = detector.detect_secrets(text)
    
    assert len(secrets) > 0
    assert any(s['type'] == 'password' for s in secrets)


def test_detect_token():
    """Test detection of tokens"""
    detector = SecretDetector()
    text = "token: abc123def456ghi789jkl012mno345pqr678"
    secrets = detector.detect_secrets(text)
    
    assert len(secrets) > 0
    assert any(s['type'] == 'token' for s in secrets)


def test_detect_aws_key():
    """Test detection of AWS keys"""
    detector = SecretDetector()
    text = "AKIAIOSFODNN7EXAMPLE"
    secrets = detector.detect_secrets(text)
    
    assert len(secrets) > 0
    assert any(s['type'] == 'aws_key' for s in secrets)


def test_detect_private_key():
    """Test detection of private keys"""
    detector = SecretDetector()
    text = "-----BEGIN RSA PRIVATE KEY-----"
    secrets = detector.detect_secrets(text)
    
    assert len(secrets) > 0
    assert any(s['type'] == 'private_key' for s in secrets)


def test_detect_database_url():
    """Test detection of database URLs"""
    detector = SecretDetector()
    text = "postgresql://user:pass@localhost/dbname"
    secrets = detector.detect_secrets(text)
    
    assert len(secrets) > 0
    assert any(s['type'] == 'database_url' for s in secrets)


def test_detect_email():
    """Test detection of emails"""
    detector = SecretDetector()
    text = "Contact: user@example.com"
    secrets = detector.detect_secrets(text)
    
    assert len(secrets) > 0
    assert any(s['type'] == 'email' for s in secrets)


def test_has_secrets():
    """Test quick check for secrets"""
    detector = SecretDetector()
    
    assert detector.has_secrets("api_key: secret12345678901234567890")
    assert not detector.has_secrets("This is a normal commit message")


def test_redact_secrets():
    """Test redaction functionality"""
    detector = SecretDetector()
    text = "api_key: sk-1234567890abcdefghijklmnopqrstuvwxyz and password: secret123"
    redacted = detector.redact_secrets(text)
    
    assert "[REDACTED]" in redacted
    assert "sk-1234567890abcdefghijklmnopqrstuvwxyz" not in redacted
    assert "secret123" not in redacted


def test_redact_custom_replacement():
    """Test redaction with custom replacement"""
    detector = SecretDetector()
    text = "api_key: sk-1234567890abcdefghijklmnopqrstuvwxyz"
    redacted = detector.redact_secrets(text, replacement="[SECRET]")
    
    assert "[SECRET]" in redacted
    assert "sk-1234567890abcdefghijklmnopqrstuvwxyz" not in redacted


def test_no_secrets():
    """Test with text containing no secrets"""
    detector = SecretDetector()
    text = "This is a normal commit message without any secrets"
    secrets = detector.detect_secrets(text)
    
    assert len(secrets) == 0
    assert not detector.has_secrets(text)


def test_empty_string():
    """Test with empty string"""
    detector = SecretDetector()
    secrets = detector.detect_secrets("")
    
    assert len(secrets) == 0
    assert not detector.has_secrets("")


def test_multiple_secrets():
    """Test detection of multiple secrets"""
    detector = SecretDetector()
    text = "api_key: sk-1234567890abcdefghijklmnopqrstuvwxyz password: secret123 token: abc123def456"
    secrets = detector.detect_secrets(text)
    
    assert len(secrets) >= 3
    secret_types = [s['type'] for s in secrets]
    assert 'api_key' in secret_types
    assert 'password' in secret_types
    assert 'token' in secret_types

