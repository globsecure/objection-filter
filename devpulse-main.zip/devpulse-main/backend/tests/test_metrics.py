import pytest
from datetime import datetime, timedelta
from app.analysis.dora_metrics import get_dora_metrics
from app.analysis.space_metrics import get_space_metrics
from app.models import Commit, FrictionLog, ManualEntry


def test_dora_metrics_empty_data(db):
    """Test DORA metrics with no data"""
    metrics = get_dora_metrics(db)
    
    assert metrics is not None
    assert 'deployment_frequency' in metrics or metrics.get('deployment_frequency') is not None
    assert 'lead_time' in metrics or metrics.get('lead_time') is not None
    assert 'change_failure_rate' in metrics or metrics.get('change_failure_rate') is not None
    assert 'mttr' in metrics or metrics.get('mttr') is not None


def test_dora_metrics_with_commits(db):
    """Test DORA metrics with sample commits"""
    commit1 = Commit(
        hash="abc123",
        message="feat: add new feature",
        date=datetime.now() - timedelta(days=5),
        files_changed=10,
        insertions=100,
        deletions=20,
        type="feature"
    )
    db.add(commit1)
    db.commit()
    
    metrics = get_dora_metrics(db)
    assert metrics is not None
    assert 'deployment_frequency' in metrics or metrics.get('deployment_frequency') is not None


def test_space_metrics_calculation(db):
    """Test SPACE metrics calculation"""
    metrics = get_space_metrics(db)
    
    assert metrics is not None
    assert 'satisfaction' in metrics or metrics.get('satisfaction') is not None
    assert 'performance' in metrics or metrics.get('performance') is not None
    assert 'activity' in metrics or metrics.get('activity') is not None
    assert 'collaboration' in metrics or metrics.get('collaboration') is not None
    assert 'efficiency' in metrics or metrics.get('efficiency') is not None


def test_metrics_edge_cases(db):
    """Test metrics with edge cases"""
    # Test with single commit
    commit = Commit(
        hash="single",
        message="test",
        date=datetime.now(),
        files_changed=1,
        insertions=1,
        deletions=0,
        type="fix"
    )
    db.add(commit)
    db.commit()
    
    dora_metrics = get_dora_metrics(db)
    assert dora_metrics is not None
    
    space_metrics = get_space_metrics(db)
    assert space_metrics is not None

