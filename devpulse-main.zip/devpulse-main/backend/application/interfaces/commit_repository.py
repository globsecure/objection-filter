from abc import ABC, abstractmethod
from typing import List, Optional
from datetime import datetime

from ...domain.entities.commit import Commit
from ...domain.value_objects.commit_type import CommitType


class ICommitRepository(ABC):
    """Interface for commit persistence operations."""

    @abstractmethod
    def find_by_hash_and_repo(self, commit_hash: str, repo_id: int) -> Optional[Commit]:
        """Find a commit by hash and repository ID."""
        pass

    @abstractmethod
    def find_all(
        self,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        repo_id: Optional[int] = None,
        commit_type: Optional[CommitType] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Commit]:
        """Find commits with optional filters."""
        pass

    @abstractmethod
    def save(self, commit: Commit) -> Commit:
        """Save a commit."""
        pass

    @abstractmethod
    def save_many(self, commits: List[Commit]) -> List[Commit]:
        """Save multiple commits."""
        pass

