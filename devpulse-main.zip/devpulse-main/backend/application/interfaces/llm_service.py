from abc import ABC, abstractmethod
from typing import List

from ...domain.entities.commit import Commit


class ILLMService(ABC):
    """Interface for LLM service operations."""

    @abstractmethod
    def summarize_commits(self, commits: List[Commit]) -> str:
        """
        Generate a summary of commits using LLM.
        
        Args:
            commits: List of commits to summarize
            
        Returns:
            str: Generated summary text
        """
        pass

