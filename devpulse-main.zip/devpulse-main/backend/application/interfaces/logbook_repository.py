from abc import ABC, abstractmethod
from typing import List, Optional
from datetime import datetime

from ...domain.entities.logbook_entry import LogbookEntry


class ILogbookRepository(ABC):
    """Interface for logbook entry persistence operations."""

    @abstractmethod
    def find_all(
        self,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[LogbookEntry]:
        """Find logbook entries with optional filters."""
        pass

    @abstractmethod
    def save(self, entry: LogbookEntry) -> LogbookEntry:
        """Save a logbook entry."""
        pass

