from abc import ABC, abstractmethod
from typing import List, Optional

from ...domain.entities.repository import Repository


class IRepositoryRepository(ABC):
    """Interface for repository persistence operations."""

    @abstractmethod
    def find_by_path(self, path: str) -> Optional[Repository]:
        """Find a repository by its path."""
        pass

    @abstractmethod
    def find_all(self) -> List[Repository]:
        """Find all repositories."""
        pass

    @abstractmethod
    def save(self, repository: Repository) -> Repository:
        """Save a repository."""
        pass

    @abstractmethod
    def update(self, repository: Repository) -> Repository:
        """Update a repository."""
        pass

