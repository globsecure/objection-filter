from abc import ABC, abstractmethod
from typing import List, Dict


class IGitCrawlerService(ABC):
    """Interface for git repository crawling operations."""

    @abstractmethod
    def scan_directory(self, directory: str) -> List[Dict[str, str]]:
        """
        Scan a directory for git repositories.
        
        Args:
            directory: Path to directory to scan
            
        Returns:
            List of repository info dictionaries with 'path' and 'name' keys
        """
        pass

    @abstractmethod
    def extract_commits(self, repo_path: str, months_back: int) -> List[Dict]:
        """
        Extract commits from a git repository.
        
        Args:
            repo_path: Path to git repository
            months_back: Number of months to look back
            
        Returns:
            List of commit dictionaries
        """
        pass

