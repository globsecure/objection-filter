from git import Repo, InvalidGitRepositoryError, GitCommandError
from typing import Dict
from pathlib import Path


def validate_repository(repo_path: str) -> Dict:
    """
    Validate git repository for corruption and issues.
    """
    issues = []
    warnings = []
    
    try:
        repo = Repo(repo_path)
        
        # Check if repository is bare
        if repo.bare:
            warnings.append("Repository is bare (no working directory)")
        
        # Check for corruption
        try:
            repo.git.fsck('--full', '--strict')
        except GitCommandError as e:
            if 'corrupt' in str(e).lower() or 'error' in str(e).lower():
                issues.append(f"Repository corruption detected: {str(e)}")
        
        # Check for missing objects
        try:
            missing = repo.git.fsck('--unreachable', '--no-full')
            if missing:
                warnings.append("Unreachable objects found (may indicate issues)")
        except:
            pass
        
        # Check repository size
        repo_size = sum(f.stat().st_size for f in Path(repo_path).rglob('*') if f.is_file())
        if repo_size > 1_000_000_000:  # > 1GB
            warnings.append(f"Large repository size: {repo_size / 1_000_000_000:.2f} GB")
        
        # Check for empty repository
        try:
            commits = list(repo.iter_commits(max_count=1))
            if not commits:
                warnings.append("Repository has no commits")
        except:
            warnings.append("Could not read commits")
        
        return {
            'repo_path': repo_path,
            'valid': len(issues) == 0,
            'issues': issues,
            'warnings': warnings,
            'status': 'corrupt' if issues else 'warning' if warnings else 'healthy'
        }
    
    except InvalidGitRepositoryError:
        return {
            'repo_path': repo_path,
            'valid': False,
            'issues': ['Not a valid git repository'],
            'warnings': [],
            'status': 'invalid'
        }
    except Exception as e:
        return {
            'repo_path': repo_path,
            'valid': False,
            'issues': [f"Error validating repository: {str(e)}"],
            'warnings': [],
            'status': 'error'
        }

