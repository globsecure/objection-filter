from typing import List, Optional, Dict
import json
from sqlalchemy.orm import Session
from ..models import ReportTemplateConfig


class TemplateService:
    """Service to manage report templates"""
    
    def __init__(self, db: Session):
        self.db = db
    
    def get_template(self, template_id: int, user_id: str = "default") -> Optional[ReportTemplateConfig]:
        """Get template by ID"""
        return self.db.query(ReportTemplateConfig).filter(
            ReportTemplateConfig.id == template_id,
            ReportTemplateConfig.user_id == user_id
        ).first()
    
    def get_default_template(self, template_type: str = "performance_review", 
                            user_id: str = "default") -> Optional[ReportTemplateConfig]:
        """Get default template for type"""
        return self.db.query(ReportTemplateConfig).filter(
            ReportTemplateConfig.template_type == template_type,
            ReportTemplateConfig.is_default == True,
            ReportTemplateConfig.user_id == user_id
        ).first()
    
    def list_templates(self, user_id: str = "default") -> List[ReportTemplateConfig]:
        """List all templates for user"""
        return self.db.query(ReportTemplateConfig).filter(
            ReportTemplateConfig.user_id == user_id
        ).all()
    
    def create_template(self, name: str, description: str, template_type: str,
                       sections: List[str], prompt_overrides: Optional[Dict] = None,
                       user_id: str = "default") -> ReportTemplateConfig:
        """Create new template"""
        template = ReportTemplateConfig(
            name=name,
            description=description,
            template_type=template_type,
            sections=json.dumps(sections),
            prompt_overrides=json.dumps(prompt_overrides) if prompt_overrides else None,
            user_id=user_id
        )
        self.db.add(template)
        self.db.commit()
        self.db.refresh(template)
        return template
    
    def get_template_sections(self, template: ReportTemplateConfig) -> List[str]:
        """Get list of sections from template"""
        if not template.sections:
            return []  # Default: all sections
        return json.loads(template.sections)
    
    def get_prompt_overrides(self, template: ReportTemplateConfig) -> Dict:
        """Get prompt overrides from template"""
        if not template.prompt_overrides:
            return {}
        return json.loads(template.prompt_overrides)

