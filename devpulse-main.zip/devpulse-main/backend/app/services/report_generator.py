from io import BytesIO
from datetime import datetime
from typing import List, Dict, Optional
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from sqlalchemy.orm import Session

from ..models import Commit, FrictionLog, ManualEntry, CareerMoment, Goal, Feedback
from ..analysis.llm_service import get_llm_provider
from ..analysis.metrics import calculate_consistency


class ReportTemplate:
    """
    Structured report template with all sections.
    """
    
    def __init__(
        self,
        start_date: datetime,
        end_date: datetime,
        executive_summary: str,
        key_achievements: List[str],
        challenges_section: str,
        collaboration_section: str,
        metrics_snapshot: Dict,
        commits: List[Commit],
        friction_logs: List[FrictionLog],
        manual_entries: List[ManualEntry],
        career_moments: List[CareerMoment] = None,
        top_moments: List[CareerMoment] = None,
        goals: List[Goal] = None,
        goals_summary: Dict = None,
        feedback: List[Feedback] = None,
        positive_feedback_quotes: List[Feedback] = None,
        time_patterns: Dict = None,
        comparisons: Dict = None,
        benchmark_summary: Dict = None
    ):
        self.start_date = start_date
        self.end_date = end_date
        self.executive_summary = executive_summary
        self.key_achievements = key_achievements
        self.challenges_section = challenges_section
        self.collaboration_section = collaboration_section
        self.metrics_snapshot = metrics_snapshot
        self.commits = commits
        self.friction_logs = friction_logs
        self.manual_entries = manual_entries
        self.career_moments = career_moments or []
        self.top_moments = top_moments or []
        self.goals = goals or []
        self.goals_summary = goals_summary or {}
        self.feedback = feedback or []
        self.positive_feedback_quotes = positive_feedback_quotes or []
        self.time_patterns = time_patterns or {}
        self.comparisons = comparisons or {}
        self.benchmark_summary = benchmark_summary or {}
        self.language = language
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON export."""
        return {
            'period': {
                'start': self.start_date.isoformat(),
                'end': self.end_date.isoformat()
            },
            'executive_summary': self.executive_summary,
            'key_achievements': self.key_achievements,
            'challenges_and_growth': self.challenges_section,
            'collaboration_highlights': self.collaboration_section,
            'metrics_snapshot': self.metrics_snapshot,
            'data_summary': {
                'total_commits': len(self.commits),
                'total_friction_logs': len(self.friction_logs),
                'total_manual_entries': len(self.manual_entries),
                'total_career_moments': len(self.career_moments)
            },
            'highlights': [
                {
                    'title': moment.title,
                    'date': moment.date.isoformat(),
                    'type': moment.type,
                    'story': moment.story,
                    'impact': moment.impact,
                }
                for moment in self.top_moments
            ] if self.top_moments else []
        }
    
    def to_markdown(self) -> str:
        """Convert to Markdown format."""
        # Format DORA metrics
        dora_section = ""
        dora = self.metrics_snapshot.get('dora', {})
        if dora:
            df = dora.get('deployment_frequency', {})
            lt = dora.get('lead_time', {})
            cfr = dora.get('change_failure_rate', {})
            mttr = dora.get('mttr', {})
            
            dora_section = f"""### DORA Metrics
- **Deployment Frequency**: {df.get('frequency_per_week', 0):.1f} per week ({df.get('total_deployments', 0)} total) - Category: {df.get('category', 'N/A') if isinstance(df, dict) and 'category' in df else 'N/A'}
- **Lead Time**: {lt.get('average_days', 0):.1f} days (median: {lt.get('median_days', 0):.1f} days) - Category: {lt.get('category', 'N/A') if isinstance(lt, dict) and 'category' in lt else 'N/A'}
- **Change Failure Rate**: {cfr.get('failure_rate', 0):.1f}% ({cfr.get('failed_deployments', 0)}/{cfr.get('total_deployments', 0)}) - Category: {cfr.get('category', 'N/A') if isinstance(cfr, dict) else 'N/A'}
- **MTTR**: {mttr.get('mean_hours', 0):.1f} hours (median: {mttr.get('median_hours', 0):.1f} hours) - Category: {mttr.get('category', 'N/A') if isinstance(mttr, dict) else 'N/A'}
"""
        else:
            dora_section = f"### DORA Metrics{chr(10)}- No DORA metrics available for this period{chr(10)}"
        
        # Format SPACE metrics
        space_section = ""
        space = self.metrics_snapshot.get('space', {})
        if space:
            sat = space.get('satisfaction', {})
            perf = space.get('performance', {})
            act = space.get('activity', {})
            collab = space.get('collaboration', {})
            eff = space.get('efficiency', {})
            
            space_section = f"""### SPACE Metrics
- **Satisfaction**: {sat.get('average_satisfaction', 0):.1f}/10 (trend: {sat.get('trend', 'stable')}) - {sat.get('total_entries', 0)} entries
- **Performance**: Quality Score {perf.get('quality_score', 0):.1f}/100 - {perf.get('commits', 0)} commits, {perf.get('code_reviews', 0)} code reviews
- **Activity**: Consistency {act.get('consistency_score', 0)*100:.0f}% - {act.get('active_days', 0)} active days, {act.get('longest_streak', 0)} day streak
- **Collaboration**: Score {collab.get('collaboration_score', 0):.1f}/100 - {collab.get('unique_collaborators', 0)} collaborators, {collab.get('code_reviews', 0)} reviews
- **Efficiency**: Flow Score {eff.get('score', 0):.1f}/100 - {eff.get('deep_work_hours', 0):.1f} deep work hours
"""
        else:
            space_section = f"### SPACE Metrics{chr(10)}- No SPACE metrics available for this period{chr(10)}"
        
        # Build markdown in parts to avoid f-string parsing issues
        period_str = f"{self.start_date.strftime('%B %d, %Y')} to {self.end_date.strftime('%B %d, %Y')}"
        
        achievements_text = chr(10).join(f"- {achievement}" for achievement in self.key_achievements) if self.key_achievements else "No achievements available."
        
        highlights_text = "No highlights available for this period."
        if self.top_moments:
            highlight_parts = []
            for moment in self.to_dict().get('highlights', []):
                highlight_parts.append(
                    f"### {moment['title']}{chr(10)}{chr(10)}**Date:** {moment['date']} | **Type:** {moment['type']}{chr(10)}{chr(10)}{moment.get('story', '')}{chr(10)}{chr(10)}{moment.get('impact', '')}"
                )
            highlights_text = chr(10).join(highlight_parts) if highlight_parts else highlights_text
        
        goals_text = "No goals tracked for this period."
        if self.goals:
            goal_parts = []
            for goal in self.goals[:5]:
                deadline_part = f" (Deadline: {goal.deadline.strftime('%Y-%m-%d')})" if goal.deadline else ""
                goal_parts.append(f"- **{goal.title}**: {goal.progress * 100:.0f}% complete - {goal.status}{deadline_part}")
            goals_text = chr(10).join(goal_parts) if goal_parts else goals_text
        
        goals_summary_text = f"{self.goals_summary.get('total', 0)} total goals, {self.goals_summary.get('active', 0)} active, {self.goals_summary.get('completed', 0)} completed ({self.goals_summary.get('completion_rate', 0) * 100:.0f}% completion rate)"
        
        feedback_text = "No peer feedback available for this period."
        if self.positive_feedback_quotes:
            feedback_parts = []
            for quote in self.positive_feedback_quotes:
                context_part = f" ({quote.context})" if quote.context else ""
                feedback_parts.append(f"> \"{quote.feedback_text}\" - {quote.from_who}{context_part}")
            feedback_text = chr(10).join(feedback_parts) if feedback_parts else feedback_text
        
        focus_time_text = "No work pattern data available."
        if self.time_patterns.get('working_hours', {}).get('best_focus_time'):
            focus_time = self.time_patterns.get('working_hours', {}).get('best_focus_time', {})
            focus_time_text = f"**Best Focus Time**: {focus_time.get('start', 'N/A')}:00 - {focus_time.get('end', 'N/A')}:00"
        
        after_hours_text = ""
        if self.time_patterns.get('after_hours'):
            after_hours = self.time_patterns.get('after_hours', {})
            after_hours_text = f"**After-Hours Work**: {after_hours.get('percentage_after_hours', 0):.1f}% of commits outside work hours"
        
        # Benchmark comparison section
        benchmark_section = ""
        if self.comparisons:
            benchmark_parts = []
            metric_labels = {
                'deployment_frequency': 'Deployment Frequency',
                'lead_time': 'Lead Time',
                'change_failure_rate': 'Change Failure Rate',
                'mttr': 'MTTR',
            }
            for metric_name, comp in self.comparisons.items():
                parts = []
                if comp.get('team_percentile') is not None:
                    percentile = comp.get('team_percentile')
                    parts.append(f"Top {100 - percentile:.0f}% of team")
                if comp.get('industry_category'):
                    parts.append(f"{comp.get('industry_category').capitalize()} industry category")
                if parts:
                    benchmark_parts.append(f"- **{metric_labels.get(metric_name, metric_name)}**: {', '.join(parts)}")
            if benchmark_parts:
                benchmark_section = f"""### Benchmark Comparison{chr(10)}{chr(10)}{chr(10).join(benchmark_parts)}{chr(10)}"""
        
        generated_time = datetime.now().strftime('%B %d, %Y at %H:%M')
        
        # Translate section names based on language
        section_translations = {
            "en": {
                "Performance Review Report": "Performance Review Report",
                "Executive Summary": "Executive Summary",
                "Key Achievements": "Key Achievements",
                "Highlights": "Highlights",
                "Goals & OKRs": "Goals & OKRs",
                "Challenges & Growth": "Challenges & Growth",
                "Collaboration Highlights": "Collaboration Highlights",
                "What Peers Say": "What Peers Say",
                "Metrics Snapshot": "Metrics Snapshot",
                "Work Patterns": "Work Patterns",
                "Data Summary": "Data Summary"
            },
            "pt": {
                "Performance Review Report": "Relatório de Avaliação de Desempenho",
                "Executive Summary": "Resumo Executivo",
                "Key Achievements": "Principais Conquistas",
                "Highlights": "Destaques",
                "Goals & OKRs": "Metas e OKRs",
                "Challenges & Growth": "Desafios e Crescimento",
                "Collaboration Highlights": "Destaques de Colaboração",
                "What Peers Say": "O que os Colegas Dizem",
                "Metrics Snapshot": "Visão Geral de Métricas",
                "Work Patterns": "Padrões de Trabalho",
                "Data Summary": "Resumo de Dados"
            }
        }
        
        translations = section_translations.get(self.language, section_translations["en"])
        
        md = f"""# {translations.get("Performance Review Report", "Performance Review Report")}

**Period**: {period_str}

---

## {translations.get("Executive Summary", "Executive Summary")}

{self.executive_summary}

---

## {translations.get("Key Achievements", "Key Achievements")}

{achievements_text}

---

## {translations.get("Highlights", "Highlights")}

{highlights_text}

---

## {translations.get("Goals & OKRs", "Goals & OKRs")}

{goals_text}

**Summary**: {goals_summary_text}

---

## {translations.get("Challenges & Growth", "Challenges & Growth")}

{self.challenges_section}

---

## {translations.get("Collaboration Highlights", "Collaboration Highlights")}

{self.collaboration_section}

---

## {translations.get("What Peers Say", "What Peers Say")}

{feedback_text}

---

## {translations.get("Metrics Snapshot", "Metrics Snapshot")}

{dora_section}

{space_section}

{benchmark_section}

---

## {translations.get("Work Patterns", "Work Patterns")}

{focus_time_text}

{after_hours_text}

---

## {translations.get("Data Summary", "Data Summary")}

- **Total Commits**: {len(self.commits)}
- **Friction Logs**: {len(self.friction_logs)}
- **Manual Entries**: {len(self.manual_entries)}
- **Career Moments**: {len(self.career_moments)}

---
*Generated by DevPulse on {generated_time}*
"""
        return md


def aggregate_report_data(
    db: Session,
    start_date: datetime,
    end_date: datetime,
    repo_id: Optional[int] = None
) -> Dict:
    """
    Aggregate commits, friction logs, and manual entries for report generation.
    """
    # Commits
    commit_query = db.query(Commit).filter(
        Commit.date >= start_date,
        Commit.date <= end_date
    )
    if repo_id:
        commit_query = commit_query.filter(Commit.repo_id == repo_id)
    commits = commit_query.order_by(Commit.date.desc()).all()
    
    # Friction Logs
    friction_query = db.query(FrictionLog).filter(
        FrictionLog.date >= start_date,
        FrictionLog.date <= end_date
    )
    friction_logs = friction_query.order_by(FrictionLog.date.desc()).all()
    
    # Manual Entries
    manual_query = db.query(ManualEntry).filter(
        ManualEntry.date >= start_date,
        ManualEntry.date <= end_date
    )
    manual_entries = manual_query.order_by(ManualEntry.date.desc()).all()
    
    # Career Moments
    moments_query = db.query(CareerMoment).filter(
        CareerMoment.date >= start_date,
        CareerMoment.date <= end_date
    )
    career_moments = moments_query.order_by(CareerMoment.date.desc()).all()
    
    # Get top 3 moments by type (prioritize wins)
    top_moments = sorted(
        career_moments,
        key=lambda m: (m.type == 'win', m.date),
        reverse=True
    )[:3]
    
    # Goals
    goals_query = db.query(Goal).filter(
        Goal.deadline >= start_date,
        Goal.deadline <= end_date
    )
    goals = goals_query.all()
    
    # Calculate goals achieved vs planned
    active_goals = [g for g in goals if g.status == 'active']
    completed_goals = [g for g in goals if g.status == 'completed']
    
    goals_summary = {
        'total': len(goals),
        'active': len(active_goals),
        'completed': len(completed_goals),
        'completion_rate': len(completed_goals) / len(goals) if goals else 0,
    }
    
    # Feedback
    feedback_query = db.query(Feedback).filter(
        Feedback.date >= start_date,
        Feedback.date <= end_date
    )
    feedback_list = feedback_query.order_by(Feedback.date.desc()).all()
    
    # Get top 5 positive feedback quotes
    positive_feedback = [
        f for f in feedback_list
        if f.category == 'positive'
    ][:5]
    
    # Time Patterns Analysis
    try:
        working_hours = analyze_working_hours(db, start_date, end_date, repo_id)
        after_hours = detect_after_hours_work(db, start_date, end_date, repo_id)
        time_patterns = {
            'working_hours': working_hours,
            'after_hours': after_hours,
        }
    except Exception:
        time_patterns = {}
    
    # Calculate basic stats
    commits_by_type = {}
    for commit in commits:
        commit_type = commit.type or 'Unknown'
        commits_by_type[commit_type] = commits_by_type.get(commit_type, 0) + 1
    
    friction_by_type = {}
    for friction in friction_logs:
        friction_type = friction.type
        friction_by_type[friction_type] = friction_by_type.get(friction_type, 0) + 1
    
    manual_by_type = {}
    for entry in manual_entries:
        entry_type = entry.type
        manual_by_type[entry_type] = manual_by_type.get(entry_type, 0) + 1
    
    # Comparison & Benchmarks
    try:
        from ..services.comparison_service import compare_dora_metrics
        comparison_data = compare_dora_metrics(
            db, start_date, end_date, None, repo_id
        )
        comparisons = comparison_data.get('comparisons', {})
        benchmark_summary = {
            'team_percentiles': {
                metric: comp.get('team_percentile')
                for metric, comp in comparisons.items()
                if comp.get('team_percentile') is not None
            },
            'industry_categories': {
                metric: comp.get('industry_category')
                for metric, comp in comparisons.items()
                if comp.get('industry_category')
            }
        }
    except Exception:
        comparisons = {}
        benchmark_summary = {}

    return {
        'commits': commits,
        'friction_logs': friction_logs,
        'manual_entries': manual_entries,
        'career_moments': career_moments,
        'top_moments': top_moments,
        'goals': goals,
        'goals_summary': goals_summary,
        'feedback': feedback_list,
        'positive_feedback_quotes': positive_feedback,
        'time_patterns': time_patterns,
        'comparisons': comparisons,
        'benchmark_summary': benchmark_summary,
        'stats': {
            'total_commits': len(commits),
            'commits_by_type': commits_by_type,
            'total_friction_logs': len(friction_logs),
            'friction_by_type': friction_by_type,
            'total_manual_entries': len(manual_entries),
            'manual_by_type': manual_by_type,
            'total_career_moments': len(career_moments),
            'date_range': {
                'start': start_date.isoformat(),
                'end': end_date.isoformat()
            }
        }
    }


def generate_fallback_summary(data: Dict) -> str:
    """Fallback summary without LLM."""
    stats = data['stats']
    return f"""During this period, I delivered {stats['total_commits']} commits across multiple features and improvements. I documented {stats['total_friction_logs']} friction points and completed {stats['total_manual_entries']} collaboration activities including code reviews and design work."""


def generate_fallback_challenges(friction_logs: List[FrictionLog]) -> str:
    """Fallback challenges section without LLM."""
    blockers = [f for f in friction_logs if f.type == 'blocker']
    incidents = [f for f in friction_logs if f.type == 'incident']
    
    challenges = []
    for friction in blockers + incidents[:5]:
        resolution = f" Resolved by: {friction.resolution}" if friction.resolution else ""
        challenges.append(f"- {friction.description[:100]}{resolution}")
    
    return "\n".join(challenges) if challenges else "No major challenges documented during this period."


def generate_fallback_collaboration(manual_entries: List[ManualEntry]) -> str:
    """Fallback collaboration section without LLM."""
    code_reviews = [e for e in manual_entries if e.type == 'code_review']
    design_docs = [e for e in manual_entries if e.type == 'design_doc']
    
    activities = []
    for entry in code_reviews + design_docs[:5]:
        collaborators = f" with {entry.collaborators}" if entry.collaborators else ""
        activities.append(f"- {entry.title}{collaborators}")
    
    return "\n".join(activities) if activities else "No collaboration activities documented during this period."


def generate_fallback_achievements(commits: List[Commit]) -> List[str]:
    """Fallback achievements from commits without LLM."""
    achievements = []
    commits_by_type = {}
    
    for commit in commits:
        commit_type = commit.type or 'Unknown'
        commits_by_type[commit_type] = commits_by_type.get(commit_type, 0) + 1
    
    for commit_type, count in sorted(commits_by_type.items(), key=lambda x: x[1], reverse=True)[:5]:
        achievements.append(f"Delivered {count} {commit_type} commits")
    
    return achievements


def generate_manager_report(
    db: Session,
    start_date: datetime,
    end_date: datetime,
    repo_id: Optional[int] = None,
    use_llm: bool = True,
    redact_sensitive: bool = False,
    template_id: Optional[int] = None,
    template_type: str = "performance_review",
    user_id: str = "default",
    language: Optional[str] = None
) -> ReportTemplate:
    """
    Generate complete manager report with all sections.
    
    Args:
        template_id: Specific template ID to use
        template_type: Template type if template_id not provided
        user_id: User ID for context and templates
    """
    from ..analysis.dora_metrics import get_dora_metrics
    from ..analysis.space_metrics import get_space_metrics
    from ..analysis.time_patterns import analyze_working_hours, detect_after_hours_work
    from ..services.template_service import TemplateService
    from ..services.translation_service import TranslationService
    
    # Get language preference
    translation_service = TranslationService(db)
    if not language:
        language = translation_service.get_user_language(user_id)
    
    # Aggregate data
    data = aggregate_report_data(db, start_date, end_date, repo_id)
    
    commits = data['commits']
    friction_logs = data['friction_logs']
    manual_entries = data['manual_entries']
    career_moments = data.get('career_moments', [])
    top_moments = data.get('top_moments', [])
    goals = data.get('goals', [])
    goals_summary = data.get('goals_summary', {})
    feedback = data.get('feedback', [])
    positive_feedback_quotes = data.get('positive_feedback_quotes', [])
    time_patterns = data.get('time_patterns', {})
    
    # Get metrics
    try:
        dora_metrics = get_dora_metrics(db, start_date, end_date, repo_id)
    except Exception:
        dora_metrics = None
    
    try:
        space_metrics = get_space_metrics(db, start_date, end_date, repo_id)
    except Exception:
        space_metrics = None
    
    metrics_snapshot = {
        'dora': dora_metrics,
        'space': space_metrics
    }
    
    # Get template
    template_service = TemplateService(db)
    template = None
    sections_to_include = []
    prompt_overrides = {}
    
    if template_id:
        template = template_service.get_template(template_id, user_id)
    else:
        template = template_service.get_default_template(template_type, user_id)
    
    # Get sections to include
    if template:
        sections_to_include = template_service.get_template_sections(template)
        prompt_overrides = template_service.get_prompt_overrides(template)
    else:
        # Default: all sections
        sections_to_include = [
            "executive_summary",
            "key_achievements",
            "highlights",
            "goals",
            "challenges",
            "collaboration",
            "feedback",
            "metrics_snapshot",
            "work_patterns"
        ]
        prompt_overrides = {}
    
    # Initialize section variables
    executive_summary = ""
    challenges_section = ""
    collaboration_section = ""
    key_achievements = []
    
    # Generate sections conditionally
    if use_llm:
        try:
            llm_provider = get_llm_provider(redact_sensitive)
            
            if "executive_summary" in sections_to_include:
                executive_summary = llm_provider.generate_executive_summary(
                    commits, friction_logs, manual_entries, start_date, end_date, db, user_id
                )
            
            if "challenges" in sections_to_include:
                challenges_section = llm_provider.generate_challenges_section(friction_logs, db, user_id)
            
            if "collaboration" in sections_to_include:
                collaboration_section = llm_provider.generate_collaboration_section(manual_entries, db, user_id)
            
            if "key_achievements" in sections_to_include:
                # Key achievements from commits (existing method)
                key_achievements_text = llm_provider.summarize_commits(commits, start_date, end_date, db, user_id)
                # Parse into bullet points
                key_achievements = [
                    line.strip('- ').strip()
                    for line in key_achievements_text.split('\n')
                    if line.strip().startswith('-')
                ]
                # If no bullet points found, use the whole text as one achievement
                if not key_achievements:
                    key_achievements = [key_achievements_text] if key_achievements_text else []
        except Exception as e:
            # Fallback to template-based generation
            if "executive_summary" in sections_to_include:
                executive_summary = generate_fallback_summary(data)
            if "challenges" in sections_to_include:
                challenges_section = generate_fallback_challenges(friction_logs)
            if "collaboration" in sections_to_include:
                collaboration_section = generate_fallback_collaboration(manual_entries)
            if "key_achievements" in sections_to_include:
                key_achievements = generate_fallback_achievements(commits)
    else:
        # Use template-based generation
        if "executive_summary" in sections_to_include:
            executive_summary = generate_fallback_summary(data)
        if "challenges" in sections_to_include:
            challenges_section = generate_fallback_challenges(friction_logs)
        if "collaboration" in sections_to_include:
            collaboration_section = generate_fallback_collaboration(manual_entries)
        if "key_achievements" in sections_to_include:
            key_achievements = generate_fallback_achievements(commits)
    
    comparisons = data.get('comparisons', {})
    benchmark_summary = data.get('benchmark_summary', {})

    return ReportTemplate(
        start_date=start_date,
        end_date=end_date,
        executive_summary=executive_summary,
        key_achievements=key_achievements,
        challenges_section=challenges_section,
        collaboration_section=collaboration_section,
        metrics_snapshot=metrics_snapshot,
        commits=commits,
        friction_logs=friction_logs,
        manual_entries=manual_entries,
        career_moments=career_moments,
        top_moments=top_moments,
        goals=goals,
        goals_summary=goals_summary,
        feedback=feedback,
        positive_feedback_quotes=positive_feedback_quotes,
        time_patterns=time_patterns,
        comparisons=comparisons,
        benchmark_summary=benchmark_summary,
        language=language
    )


def generate_pdf_report(
    db: Session,
    start_date: datetime,
    end_date: datetime,
    repo_id: Optional[int] = None,
    use_llm: bool = True,
    redact_sensitive: bool = False
) -> bytes:
    """
    Generate enhanced PDF report with all sections.
    """
    from reportlab.platypus import PageBreak
    
    # Generate report template
    report = generate_manager_report(db, start_date, end_date, repo_id, use_llm, redact_sensitive, template_id, template_type, user_id)
    
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    story = []
    styles = getSampleStyleSheet()
    
    # Custom styles
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=colors.HexColor('#1a1a1a'),
        spaceAfter=30,
    )
    
    heading_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=16,
        textColor=colors.HexColor('#2c3e50'),
        spaceAfter=12,
    )
    
    # Title
    story.append(Paragraph("DevPulse Performance Report", title_style))
    story.append(Spacer(1, 0.2 * inch))
    
    # Period
    period_text = f"Period: {start_date.strftime('%B %d, %Y')} to {end_date.strftime('%B %d, %Y')}"
    story.append(Paragraph(period_text, styles['Normal']))
    story.append(Spacer(1, 0.3 * inch))
    
    # Executive Summary
    story.append(Paragraph("Executive Summary", heading_style))
    story.append(Paragraph(report.executive_summary, styles['Normal']))
    story.append(Spacer(1, 0.3 * inch))
    
    # Key Achievements
    story.append(Paragraph("Key Achievements", heading_style))
    for achievement in report.key_achievements:
        story.append(Paragraph(f"• {achievement}", styles['Normal']))
    story.append(Spacer(1, 0.3 * inch))
    
    # Highlights (Career Moments)
    if report.top_moments:
        story.append(Paragraph("Highlights", heading_style))
        for moment in report.top_moments:
            story.append(Paragraph(f"<b>{moment.title}</b>", styles['Normal']))
            story.append(Paragraph(f"Date: {moment.date.strftime('%Y-%m-%d')} | Type: {moment.type}", styles['Normal']))
            if moment.story:
                story.append(Paragraph(moment.story, styles['Normal']))
            if moment.impact:
                story.append(Paragraph(f"Impact: {moment.impact}", styles['Normal']))
            story.append(Spacer(1, 0.2 * inch))
        story.append(Spacer(1, 0.3 * inch))
    
    # Challenges & Growth
    story.append(Paragraph("Challenges & Growth", heading_style))
    story.append(Paragraph(report.challenges_section, styles['Normal']))
    story.append(Spacer(1, 0.3 * inch))
    
    # Collaboration Highlights
    story.append(Paragraph("Collaboration Highlights", heading_style))
    story.append(Paragraph(report.collaboration_section, styles['Normal']))
    story.append(Spacer(1, 0.3 * inch))
    
    # What Peers Say
    if report.positive_feedback_quotes:
        story.append(Paragraph("What Peers Say", heading_style))
        for quote in report.positive_feedback_quotes:
            context_text = f" ({quote.context})" if quote.context else ""
            story.append(Paragraph(f'"{quote.feedback_text}" - {quote.from_who}{context_text}', styles['Normal']))
            story.append(Spacer(1, 0.1 * inch))
        story.append(Spacer(1, 0.3 * inch))
    
    # Goals & OKRs
    if report.goals:
        story.append(Paragraph("Goals & OKRs", heading_style))
        for goal in report.goals[:5]:
            story.append(Paragraph(f"<b>{goal.title}</b>: {goal.progress * 100:.0f}% complete - {goal.status}", styles['Normal']))
            if goal.target_metric:
                story.append(Paragraph(f"Target: {goal.target_metric}", styles['Normal']))
            if goal.current_metric:
                story.append(Paragraph(f"Current: {goal.current_metric}", styles['Normal']))
            story.append(Spacer(1, 0.1 * inch))
        summary = report.goals_summary
        if summary:
            story.append(Paragraph(
                f"Summary: {summary.get('total', 0)} total goals, {summary.get('active', 0)} active, "
                f"{summary.get('completed', 0)} completed ({summary.get('completion_rate', 0) * 100:.0f}% completion rate)",
                styles['Normal']
            ))
        story.append(Spacer(1, 0.3 * inch))
    
    # Metrics Snapshot
    story.append(Paragraph("Metrics Snapshot", heading_style))
    
    if report.metrics_snapshot.get('dora'):
        dora = report.metrics_snapshot['dora']
        story.append(Paragraph("DORA Metrics:", styles['Heading3']))
        if isinstance(dora, dict):
            df = dora.get('deployment_frequency', {})
            lt = dora.get('lead_time', {})
            cfr = dora.get('change_failure_rate', {})
            mttr = dora.get('mttr', {})
            
            if df:
                story.append(Paragraph(f"Deployment Frequency: {df.get('frequency_per_week', 0):.1f} per week ({df.get('total_deployments', 0)} total)", styles['Normal']))
            if lt:
                story.append(Paragraph(f"Lead Time: {lt.get('average_days', 0):.1f} days (median: {lt.get('median_days', 0):.1f} days)", styles['Normal']))
            if cfr:
                story.append(Paragraph(f"Change Failure Rate: {cfr.get('failure_rate', 0):.1f}% ({cfr.get('failed_deployments', 0)}/{cfr.get('total_deployments', 0)}) - {cfr.get('category', 'N/A')}", styles['Normal']))
            if mttr:
                story.append(Paragraph(f"MTTR: {mttr.get('mean_hours', 0):.1f} hours (median: {mttr.get('median_hours', 0):.1f} hours) - {mttr.get('category', 'N/A')}", styles['Normal']))
        story.append(Spacer(1, 0.2 * inch))
    
    if report.metrics_snapshot.get('space'):
        space = report.metrics_snapshot['space']
        story.append(Paragraph("SPACE Metrics:", styles['Heading3']))
        if isinstance(space, dict):
            sat = space.get('satisfaction', {})
            perf = space.get('performance', {})
            act = space.get('activity', {})
            collab = space.get('collaboration', {})
            eff = space.get('efficiency', {})
            
            if sat:
                story.append(Paragraph(f"Satisfaction: {sat.get('average_satisfaction', 0):.1f}/10 (trend: {sat.get('trend', 'stable')})", styles['Normal']))
            if perf:
                story.append(Paragraph(f"Performance: Quality Score {perf.get('quality_score', 0):.1f}/100 - {perf.get('commits', 0)} commits", styles['Normal']))
            if act:
                story.append(Paragraph(f"Activity: Consistency {act.get('consistency_score', 0)*100:.0f}% - {act.get('active_days', 0)} active days", styles['Normal']))
            if collab:
                story.append(Paragraph(f"Collaboration: Score {collab.get('collaboration_score', 0):.1f}/100 - {collab.get('unique_collaborators', 0)} collaborators", styles['Normal']))
            if eff:
                story.append(Paragraph(f"Efficiency: Flow Score {eff.get('score', 0):.1f}/100 - {eff.get('deep_work_hours', 0):.1f} deep work hours", styles['Normal']))
        story.append(Spacer(1, 0.2 * inch))
    
        story.append(Spacer(1, 0.3 * inch))
    
    # Work Patterns
    if report.time_patterns:
        story.append(Paragraph("Work Patterns", heading_style))
        working_hours = report.time_patterns.get('working_hours', {})
        after_hours = report.time_patterns.get('after_hours', {})
        
        if working_hours.get('best_focus_time'):
            focus_time = working_hours['best_focus_time']
            story.append(Paragraph(
                f"Best Focus Time: {focus_time.get('start', 'N/A')}:00 - {focus_time.get('end', 'N/A')}:00",
                styles['Normal']
            ))
        
        if after_hours:
            story.append(Paragraph(
                f"After-Hours Work: {after_hours.get('percentage_after_hours', 0):.1f}% of commits outside work hours",
                styles['Normal']
            ))
        
        story.append(Spacer(1, 0.3 * inch))
    
    # Data Summary
    story.append(Paragraph("Data Summary", heading_style))
    story.append(Paragraph(f"Total Commits: {len(report.commits)}", styles['Normal']))
    story.append(Paragraph(f"Friction Logs: {len(report.friction_logs)}", styles['Normal']))
    story.append(Paragraph(f"Manual Entries: {len(report.manual_entries)}", styles['Normal']))
    story.append(Paragraph(f"Career Moments: {len(report.career_moments)}", styles['Normal']))
    
    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()

