import shutil
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict
import sqlite3


def backup_database(
    db_path: str,
    backup_dir: Optional[str] = None,
    keep_backups: int = 7
) -> Dict:
    """
    Create a backup of the SQLite database.
    """
    db_path_obj = Path(db_path)
    if not db_path_obj.exists():
        return {'success': False, 'error': 'Database file not found'}
    
    if backup_dir is None:
        backup_dir = db_path_obj.parent / 'backups'
    else:
        backup_dir = Path(backup_dir)
    
    backup_dir.mkdir(parents=True, exist_ok=True)
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_filename = f"devpulse_backup_{timestamp}.db"
    backup_path = backup_dir / backup_filename
    
    try:
        # Use SQLite backup API for safe backup
        source = sqlite3.connect(db_path)
        backup = sqlite3.connect(backup_path)
        source.backup(backup)
        backup.close()
        source.close()
        
        # Clean up old backups
        backups = sorted(backup_dir.glob('devpulse_backup_*.db'), key=lambda p: p.stat().st_mtime, reverse=True)
        for old_backup in backups[keep_backups:]:
            old_backup.unlink()
        
        return {
            'success': True,
            'backup_path': str(backup_path),
            'backup_size': backup_path.stat().st_size,
            'timestamp': timestamp
        }
    except Exception as e:
        return {
            'success': False,
            'error': str(e)
        }

