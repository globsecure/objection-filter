# Pricing per 1K tokens (as of 2024)
PRICING = {
    'openai': {
        'gpt-3.5-turbo': {
            'input': 0.0005,  # $0.50 per 1M tokens
            'output': 0.0015  # $1.50 per 1M tokens
        },
        'gpt-4': {
            'input': 0.03,    # $30 per 1M tokens
            'output': 0.06    # $60 per 1M tokens
        },
        'gpt-4-turbo': {
            'input': 0.01,    # $10 per 1M tokens
            'output': 0.03   # $30 per 1M tokens
        }
    },
    'gemini': {
        'gemini-pro': {
            'input': 0.00025,  # $0.25 per 1M tokens
            'output': 0.0005   # $0.50 per 1M tokens
        }
    }
}


def calculate_cost(
    provider: str,
    model: str,
    input_tokens: int,
    output_tokens: int
) -> float:
    """Calculate cost in USD"""
    if provider not in PRICING:
        return 0.0
    
    if model not in PRICING[provider]:
        # Use default pricing
        return 0.0
    
    pricing = PRICING[provider][model]
    input_cost = (input_tokens / 1000) * pricing['input']
    output_cost = (output_tokens / 1000) * pricing['output']
    
    return round(input_cost + output_cost, 6)

