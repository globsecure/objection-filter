from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from typing import Optional, Dict
from ..models import LLMRateLimit, LLMUsageLog
from ..database import get_db


class RateLimitExceeded(Exception):
    """Raised when rate limit is exceeded"""
    pass


class LLMRateLimiter:
    def __init__(self, db: Session):
        self.db = db
    
    def check_rate_limit(
        self,
        provider: str,
        estimated_tokens: int = 0
    ) -> bool:
        """
        Check if request is within rate limits.
        Returns True if allowed, raises RateLimitExceeded if not.
        """
        limit = self.db.query(LLMRateLimit).filter(
            LLMRateLimit.provider == provider
        ).first()
        
        if not limit:
            # Create default limits
            limit = LLMRateLimit(
                provider=provider,
                requests_per_minute=60,
                tokens_per_minute=90000,
                requests_per_day=1000
            )
            self.db.add(limit)
            self.db.commit()
        
        now = datetime.utcnow()
        
        # Reset minute counter if needed
        if not limit.last_reset_minute or (now - limit.last_reset_minute).seconds >= 60:
            limit.current_minute_requests = 0
            limit.current_minute_tokens = 0
            limit.last_reset_minute = now
        
        # Reset day counter if needed
        if not limit.last_reset_day or (now - limit.last_reset_day).days >= 1:
            limit.current_day_requests = 0
            limit.last_reset_day = now
        
        # Check limits
        if limit.current_minute_requests >= limit.requests_per_minute:
            raise RateLimitExceeded(
                f"Rate limit exceeded: {limit.current_minute_requests}/{limit.requests_per_minute} requests per minute"
            )
        
        if limit.current_minute_tokens + estimated_tokens > limit.tokens_per_minute:
            raise RateLimitExceeded(
                f"Token limit exceeded: {limit.current_minute_tokens + estimated_tokens}/{limit.tokens_per_minute} tokens per minute"
            )
        
        if limit.current_day_requests >= limit.requests_per_day:
            raise RateLimitExceeded(
                f"Daily limit exceeded: {limit.current_day_requests}/{limit.requests_per_day} requests per day"
            )
        
        # Update counters
        limit.current_minute_requests += 1
        limit.current_minute_tokens += estimated_tokens
        limit.current_day_requests += 1
        limit.updated_at = now
        self.db.commit()
        
        return True
    
    def log_usage(
        self,
        provider: str,
        model: str,
        operation: str,
        input_tokens: int,
        output_tokens: int,
        cost_usd: float,
        duration_ms: int,
        success: bool = True,
        error_message: Optional[str] = None
    ):
        """Log LLM API usage"""
        log = LLMUsageLog(
            provider=provider,
            model=model,
            operation=operation,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=cost_usd,
            request_duration_ms=duration_ms,
            success=success,
            error_message=error_message
        )
        self.db.add(log)
        self.db.commit()
    
    def get_usage_stats(
        self,
        provider: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> Dict:
        """Get usage statistics"""
        query = self.db.query(LLMUsageLog)
        
        if provider:
            query = query.filter(LLMUsageLog.provider == provider)
        if start_date:
            query = query.filter(LLMUsageLog.created_at >= start_date)
        if end_date:
            query = query.filter(LLMUsageLog.created_at <= end_date)
        
        logs = query.all()
        
        total_requests = len(logs)
        successful_requests = len([l for l in logs if l.success])
        total_input_tokens = sum(l.input_tokens for l in logs)
        total_output_tokens = sum(l.output_tokens for l in logs)
        total_cost = sum(l.cost_usd for l in logs)
        avg_duration = sum(l.request_duration_ms for l in logs) / total_requests if total_requests > 0 else 0
        
        # Group by operation
        by_operation = {}
        for log in logs:
            if log.operation not in by_operation:
                by_operation[log.operation] = {
                    'count': 0,
                    'cost': 0.0,
                    'tokens': 0
                }
            by_operation[log.operation]['count'] += 1
            by_operation[log.operation]['cost'] += log.cost_usd
            by_operation[log.operation]['tokens'] += (log.input_tokens + log.output_tokens)
        
        return {
            'total_requests': total_requests,
            'successful_requests': successful_requests,
            'failed_requests': total_requests - successful_requests,
            'total_input_tokens': total_input_tokens,
            'total_output_tokens': total_output_tokens,
            'total_tokens': total_input_tokens + total_output_tokens,
            'total_cost_usd': round(total_cost, 4),
            'avg_duration_ms': round(avg_duration, 2),
            'by_operation': by_operation,
            'by_provider': self._group_by_provider(logs)
        }
    
    def _group_by_provider(self, logs: list) -> Dict:
        """Group usage stats by provider"""
        by_provider = {}
        for log in logs:
            if log.provider not in by_provider:
                by_provider[log.provider] = {
                    'count': 0,
                    'cost': 0.0,
                    'tokens': 0
                }
            by_provider[log.provider]['count'] += 1
            by_provider[log.provider]['cost'] += log.cost_usd
            by_provider[log.provider]['tokens'] += (log.input_tokens + log.output_tokens)
        return by_provider

