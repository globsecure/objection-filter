from sqlalchemy.orm import Session
from typing import Dict, List, Optional
from datetime import datetime
from statistics import mean
import json

from ..models import TeamBenchmark, IndustryBenchmark, HistoricalSnapshot
from ..analysis.dora_metrics import get_dora_metrics
from ..analysis.space_metrics import get_space_metrics


def calculate_percentile(value: float, values: List[float]) -> float:
    """Calculate percentile rank (0-100) of value in values list"""
    if not values:
        return None

    sorted_values = sorted(values)
    below = sum(1 for v in sorted_values if v < value)
    equal = sum(1 for v in sorted_values if v == value)

    percentile = (below + 0.5 * equal) / len(sorted_values) * 100
    return round(percentile, 1)


def get_industry_category(
    db: Session,
    metric_name: str,
    value: float
) -> Optional[str]:
    """Determine industry category (elite/high/medium/low) for a metric value"""
    benchmarks = db.query(IndustryBenchmark).filter(
        IndustryBenchmark.metric_name == metric_name
    ).order_by(
        IndustryBenchmark.min_value.asc()
    ).all()

    for benchmark in benchmarks:
        min_val = benchmark.min_value
        max_val = benchmark.max_value

        if min_val is not None and value < min_val:
            continue

        if max_val is None:
            return benchmark.category  # Elite or Low (unbounded)

        if min_val is not None and max_val is not None:
            if min_val <= value < max_val:
                return benchmark.category
        elif max_val is not None:
            if value < max_val:
                return benchmark.category

    return 'low'  # Default to low if not found


def compare_metric(
    db: Session,
    metric_name: str,
    your_value: float,
    period_start: datetime,
    period_end: datetime,
    team_name: Optional[str] = None
) -> Dict:
    """Compare your metric value against team and industry benchmarks"""

    # Get team benchmarks for same period
    team_query = db.query(TeamBenchmark).filter(
        TeamBenchmark.metric_name == metric_name,
        TeamBenchmark.period_start <= period_end,
        TeamBenchmark.period_end >= period_start
    )

    if team_name:
        team_query = team_query.filter(TeamBenchmark.team_name == team_name)

    team_benchmarks = team_query.all()

    # Calculate team average and percentile
    team_average = None
    team_percentile = None

    if team_benchmarks:
        team_values = [b.metric_value for b in team_benchmarks]
        team_average = mean(team_values)
        team_percentile = calculate_percentile(your_value, team_values)

    # Get industry category
    industry_category = get_industry_category(db, metric_name, your_value)

    # Estimate industry percentile based on category
    industry_percentile_map = {
        'elite': 90.0,  # Top 10%
        'high': 70.0,   # Top 30%
        'medium': 40.0, # Top 60%
        'low': 15.0,    # Bottom 40%
    }
    industry_percentile = industry_percentile_map.get(industry_category)

    return {
        'your_value': your_value,
        'team_average': team_average,
        'team_percentile': team_percentile,
        'industry_category': industry_category,
        'industry_percentile': industry_percentile,
    }


def compare_dora_metrics(
    db: Session,
    start_date: datetime,
    end_date: datetime,
    team_name: Optional[str] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """Compare all DORA metrics against team and industry"""
    your_metrics = get_dora_metrics(db, start_date, end_date, repo_id)

    comparisons = {}

    # Deployment Frequency
    df = your_metrics.get('deployment_frequency', {})
    if df.get('frequency_per_week'):
        comparisons['deployment_frequency'] = compare_metric(
            db, 'deployment_frequency', df['frequency_per_week'],
            start_date, end_date, team_name
        )

    # Lead Time
    lt = your_metrics.get('lead_time', {})
    if lt.get('average_days'):
        comparisons['lead_time'] = compare_metric(
            db, 'lead_time', lt['average_days'],
            start_date, end_date, team_name
        )

    # Change Failure Rate
    cfr = your_metrics.get('change_failure_rate', {})
    if cfr.get('failure_rate'):
        comparisons['change_failure_rate'] = compare_metric(
            db, 'change_failure_rate', cfr['failure_rate'],
            start_date, end_date, team_name
        )

    # MTTR
    mttr = your_metrics.get('mttr', {})
    if mttr.get('mean_hours'):
        comparisons['mttr'] = compare_metric(
            db, 'mttr', mttr['mean_hours'],
            start_date, end_date, team_name
        )

    return {
        'your_metrics': your_metrics,
        'comparisons': comparisons,
        'period': {
            'start': start_date.isoformat(),
            'end': end_date.isoformat(),
        }
    }


def create_historical_snapshot(
    db: Session,
    period_label: str,
    period_start: datetime,
    period_end: datetime,
    repo_id: Optional[int] = None
) -> HistoricalSnapshot:
    """Create a snapshot of current metrics for historical comparison"""

    # Get current metrics
    dora_metrics = get_dora_metrics(db, period_start, period_end, repo_id)
    space_metrics = get_space_metrics(db, period_start, period_end, repo_id)

    # Create snapshot data
    snapshot_data = {
        'dora': dora_metrics,
        'space': space_metrics,
        'period_label': period_label,
        'period_start': period_start.isoformat(),
        'period_end': period_end.isoformat(),
    }

    snapshot = HistoricalSnapshot(
        period_label=period_label,
        period_start=period_start,
        period_end=period_end,
        snapshot_data=json.dumps(snapshot_data),
        dora_metrics=json.dumps(dora_metrics),
        space_metrics=json.dumps(space_metrics)
    )

    db.add(snapshot)
    db.commit()
    db.refresh(snapshot)

    return snapshot


def compare_historical_periods(
    db: Session,
    period_labels: List[str]
) -> Dict:
    """Compare metrics across multiple historical periods"""

    snapshots = db.query(HistoricalSnapshot).filter(
        HistoricalSnapshot.period_label.in_(period_labels)
    ).order_by(HistoricalSnapshot.period_start.asc()).all()

    if len(snapshots) < 2:
        return {'error': 'Need at least 2 periods to compare'}

    comparisons = {}

    # Compare DORA metrics
    dora_metrics_list = []
    for snapshot in snapshots:
        dora_data = json.loads(snapshot.dora_metrics)
        dora_metrics_list.append({
            'period': snapshot.period_label,
            'metrics': dora_data
        })

    # Calculate trends for each metric
    metric_names = ['deployment_frequency', 'lead_time', 'change_failure_rate', 'mttr']

    for metric_name in metric_names:
        values = []
        for item in dora_metrics_list:
            metric_data = item['metrics'].get(metric_name, {})
            if metric_name == 'deployment_frequency':
                value = metric_data.get('frequency_per_week')
            elif metric_name == 'lead_time':
                value = metric_data.get('average_days')
            elif metric_name == 'change_failure_rate':
                value = metric_data.get('failure_rate')
            elif metric_name == 'mttr':
                value = metric_data.get('mean_hours')

            if value is not None:
                values.append({
                    'period': item['period'],
                    'value': value
                })

        if len(values) >= 2:
            # Calculate trend
            first_value = values[0]['value']
            last_value = values[-1]['value']

            if first_value > 0:
                trend_percentage = ((last_value - first_value) / first_value) * 100
            else:
                trend_percentage = 0

            # Determine trend direction
            if trend_percentage > 5:
                trend = 'improving' if metric_name in ['deployment_frequency'] else 'declining'
            elif trend_percentage < -5:
                trend = 'declining' if metric_name in ['deployment_frequency'] else 'improving'
            else:
                trend = 'stable'

            # For lead_time, change_failure_rate, mttr: lower is better
            if metric_name in ['lead_time', 'change_failure_rate', 'mttr']:
                if trend == 'improving':
                    trend = 'declining'
                elif trend == 'declining':
                    trend = 'improving'

            comparisons[metric_name] = {
                'values': values,
                'trend': trend,
                'trend_percentage': round(trend_percentage, 1),
                'first_value': first_value,
                'last_value': last_value,
            }

    return {
        'periods': [s.period_label for s in snapshots],
        'comparisons': comparisons,
        'snapshots': [
            {
                'period': s.period_label,
                'start': s.period_start.isoformat(),
                'end': s.period_end.isoformat(),
            }
            for s in snapshots
        ]
    }

