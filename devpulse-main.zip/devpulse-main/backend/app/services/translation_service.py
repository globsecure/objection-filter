from typing import Dict, Optional
from ..models import UserContext
from sqlalchemy.orm import Session


class TranslationService:
    """Service to translate report content"""
    
    # Simple translation dictionary (can be extended or use external API)
    TRANSLATIONS: Dict[str, Dict[str, str]] = {
        "sections": {
            "en": {
                "executive_summary": "Executive Summary",
                "key_achievements": "Key Achievements",
                "challenges": "Challenges & Growth",
                "collaboration": "Collaboration Highlights",
                "highlights": "Highlights",
                "goals": "Goals & OKRs",
                "feedback": "What Peers Say",
                "metrics_snapshot": "Metrics Snapshot",
                "work_patterns": "Work Patterns"
            },
            "pt": {
                "executive_summary": "Resumo Executivo",
                "key_achievements": "Principais Conquistas",
                "challenges": "Desafios e Crescimento",
                "collaboration": "Destaques de Colaboração",
                "highlights": "Destaques",
                "goals": "Metas e OKRs",
                "feedback": "O que os Colegas Dizem",
                "metrics_snapshot": "Visão Geral de Métricas",
                "work_patterns": "Padrões de Trabalho"
            }
        },
        "prompts": {
            "en": {
                "executive_summary_prompt": "Generate an executive summary for a performance review covering the period",
                "key_achievements_prompt": "Transform the following technical commits into a professional performance summary with impact-driven bullet points",
                "challenges_prompt": "Transform the following friction logs into a \"Challenges & Growth\" section for a performance review",
                "collaboration_prompt": "Transform the following collaboration activities into a \"Collaboration Highlights\" section"
            },
            "pt": {
                "executive_summary_prompt": "Gere um resumo executivo para uma avaliação de desempenho cobrindo o período",
                "key_achievements_prompt": "Transforme os seguintes commits técnicos em um resumo profissional de desempenho com pontos de impacto",
                "challenges_prompt": "Transforme os seguintes registros de fricção em uma seção \"Desafios e Crescimento\" para uma avaliação de desempenho",
                "collaboration_prompt": "Transforme as seguintes atividades de colaboração em uma seção \"Destaques de Colaboração\""
            }
        }
    }
    
    def __init__(self, db: Session):
        self.db = db
    
    def get_user_language(self, user_id: str = "default") -> str:
        """Get user's preferred language"""
        context = self.db.query(UserContext).filter(
            UserContext.user_id == user_id
        ).first()
        return context.preferred_language if context and context.preferred_language else "en"
    
    def translate_section_name(self, section_name: str, language: str) -> str:
        """Translate section name"""
        return self.TRANSLATIONS["sections"].get(language, {}).get(section_name, section_name)
    
    def translate_prompt(self, prompt_key: str, language: str) -> Optional[str]:
        """Get translated prompt"""
        return self.TRANSLATIONS["prompts"].get(language, {}).get(prompt_key)
    
    def translate_content_with_llm(self, content: str, target_language: str, 
                                   llm_provider) -> str:
        """
        Use LLM to translate content to target language.
        Fallback for complex translations.
        """
        if target_language == "en":
            return content  # Already in English
        
        prompt = f"Translate the following text to {target_language}. Keep the professional tone and technical terms in English if appropriate:\n\n{content}"
        
        # Use LLM to translate (simplified - would need proper implementation)
        # For now, return content as-is (placeholder)
        return content

