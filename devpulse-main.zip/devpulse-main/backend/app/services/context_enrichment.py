from typing import Optional, Dict
from sqlalchemy.orm import Session
from datetime import datetime
from ..models import UserContext, Goal


class ContextEnrichmentService:
    """Service to enrich LLM prompts with user context"""
    
    def __init__(self, db: Session):
        self.db = db
    
    def get_user_context(self, user_id: str = "default") -> Optional[UserContext]:
        """Get user context from database"""
        return self.db.query(UserContext).filter(
            UserContext.user_id == user_id
        ).first()
    
    def build_context_prompt(self, user_id: str = "default", 
                           start_date: Optional[datetime] = None,
                           end_date: Optional[datetime] = None) -> str:
        """
        Build context string to prepend to LLM prompts.
        
        Returns:
            Context string with role, team, domain, and quarter goals
        """
        context_obj = self.get_user_context(user_id)
        
        if not context_obj:
            return ""  # No context available
        
        context_parts = []
        
        # Basic context
        if context_obj.role:
            context_parts.append(f"Role: {context_obj.role}")
        if context_obj.team:
            context_parts.append(f"Team: {context_obj.team}")
        if context_obj.business_domain:
            context_parts.append(f"Business Domain: {context_obj.business_domain}")
        if context_obj.company:
            context_parts.append(f"Company: {context_obj.company}")
        
        # Quarter goals context
        if start_date and end_date:
            goals = self.db.query(Goal).filter(
                Goal.deadline >= start_date,
                Goal.deadline <= end_date,
                Goal.status != 'cancelled'
            ).all()
            
            if goals:
                goal_titles = [g.title for g in goals[:5]]  # Top 5 goals
                context_parts.append(f"\nQuarter Goals: {', '.join(goal_titles)}")
        
        if not context_parts:
            return ""
        
        return f"Context:\n{chr(10).join(context_parts)}\n\n"
    
    def update_user_context(self, user_id: str = "default", **kwargs) -> UserContext:
        """Update or create user context"""
        context = self.get_user_context(user_id)
        
        if not context:
            context = UserContext(user_id=user_id)
            self.db.add(context)
        
        for key, value in kwargs.items():
            if hasattr(context, key) and value:
                setattr(context, key, value)
        
        self.db.commit()
        self.db.refresh(context)
        return context

