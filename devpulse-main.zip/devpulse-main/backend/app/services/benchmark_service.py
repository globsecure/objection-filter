from sqlalchemy.orm import Session
from datetime import datetime
from ..models import IndustryBenchmark

DORA_BENCHMARKS = {
    'deployment_frequency': [
        {'category': 'elite', 'min_value': 1.0, 'max_value': None},  # Multiple per day
        {'category': 'high', 'min_value': 1/7, 'max_value': 1.0},  # Once per day to once per week
        {'category': 'medium', 'min_value': 1/30, 'max_value': 1/7},  # Once per week to once per month
        {'category': 'low', 'min_value': 0, 'max_value': 1/30},  # Less than once per month
    ],
    'lead_time': [
        {'category': 'elite', 'min_value': 0, 'max_value': 1.0},  # Less than 1 day
        {'category': 'high', 'min_value': 1.0, 'max_value': 7.0},  # 1 day to 1 week
        {'category': 'medium', 'min_value': 7.0, 'max_value': 30.0},  # 1 week to 1 month
        {'category': 'low', 'min_value': 30.0, 'max_value': None},  # More than 1 month
    ],
    'change_failure_rate': [
        {'category': 'elite', 'min_value': 0, 'max_value': 5.0},  # 0-5%
        {'category': 'high', 'min_value': 5.0, 'max_value': 10.0},  # 5-10%
        {'category': 'medium', 'min_value': 10.0, 'max_value': 15.0},  # 10-15%
        {'category': 'low', 'min_value': 15.0, 'max_value': 100.0},  # >15%
    ],
    'mttr': [
        {'category': 'elite', 'min_value': 0, 'max_value': 1.0},  # Less than 1 hour
        {'category': 'high', 'min_value': 1.0, 'max_value': 24.0},  # 1 hour to 1 day
        {'category': 'medium', 'min_value': 24.0, 'max_value': 168.0},  # 1 day to 1 week
        {'category': 'low', 'min_value': 168.0, 'max_value': None},  # More than 1 week
    ],
}

def seed_industry_benchmarks(db: Session):
    """Seed DORA industry benchmarks if they don't exist"""
    existing = db.query(IndustryBenchmark).filter(
        IndustryBenchmark.source == 'dora'
    ).first()

    if existing:
        return  # Already seeded

    current_year = datetime.now().year

    for metric_name, categories in DORA_BENCHMARKS.items():
        for cat_data in categories:
            benchmark = IndustryBenchmark(
                metric_name=metric_name,
                category=cat_data['category'],
                min_value=cat_data.get('min_value'),
                max_value=cat_data.get('max_value'),
                source='dora',
                year=current_year
            )
            db.add(benchmark)

    db.commit()

