import re
from typing import List, Dict, Optional
from enum import Enum


class SecretType(Enum):
    API_KEY = "api_key"
    PASSWORD = "password"
    TOKEN = "token"
    AWS_KEY = "aws_key"
    PRIVATE_KEY = "private_key"
    DATABASE_URL = "database_url"
    EMAIL = "email"
    INTERNAL_URL = "internal_url"


class SecretDetector:
    """Detect secrets and sensitive information in text"""
    
    # Patterns for common secrets
    PATTERNS = {
        SecretType.API_KEY: [
            r'api[_-]?key\s*[:=]\s*["\']?([a-zA-Z0-9_\-]{20,})["\']?',
            r'apikey\s*[:=]\s*["\']?([a-zA-Z0-9_\-]{20,})["\']?',
        ],
        SecretType.PASSWORD: [
            r'password\s*[:=]\s*["\']?([^\s"\']{8,})["\']?',
            r'pwd\s*[:=]\s*["\']?([^\s"\']{8,})["\']?',
        ],
        SecretType.TOKEN: [
            r'token\s*[:=]\s*["\']?([a-zA-Z0-9_\-]{20,})["\']?',
            r'bearer\s+([a-zA-Z0-9_\-\.]{20,})',
        ],
        SecretType.AWS_KEY: [
            r'AKIA[0-9A-Z]{16}',
            r'aws[_-]?access[_-]?key[_-]?id\s*[:=]\s*["\']?([A-Z0-9]{20})["\']?',
        ],
        SecretType.PRIVATE_KEY: [
            r'-----BEGIN\s+(RSA\s+)?PRIVATE\s+KEY-----',
            r'ssh-rsa\s+[A-Za-z0-9+/=]{100,}',
        ],
        SecretType.DATABASE_URL: [
            r'postgresql://[^\s]+',
            r'mysql://[^\s]+',
            r'mongodb://[^\s]+',
        ],
        SecretType.EMAIL: [
            r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
        ],
        SecretType.INTERNAL_URL: [
            r'https?://(?:internal|dev|staging|test)\.(?:paypal|paypalcorp)\.(?:com|net)',
            r'https?://[a-z0-9-]+\.(?:paypal|paypalcorp)\.(?:com|net)',
        ],
    }
    
    def detect_secrets(self, text: str) -> List[Dict]:
        """
        Detect secrets in text.
        
        Returns:
            List of dicts with keys: type, pattern, matched_text, position
        """
        secrets = []
        
        for secret_type, patterns in self.PATTERNS.items():
            for pattern in patterns:
                matches = re.finditer(pattern, text, re.IGNORECASE)
                for match in matches:
                    matched_text = match.group(0)
                    # Truncate long matches for display
                    display_text = matched_text[:50] + '...' if len(matched_text) > 50 else matched_text
                    
                    secrets.append({
                        'type': secret_type.value,
                        'pattern': pattern,
                        'matched_text': display_text,
                        'position': match.start(),
                    })
        
        return secrets
    
    def has_secrets(self, text: str) -> bool:
        """Quick check if text contains secrets"""
        return len(self.detect_secrets(text)) > 0
    
    def redact_secrets(self, text: str, replacement: str = "[REDACTED]") -> str:
        """
        Redact secrets from text.
        
        Args:
            text: Text to redact
            replacement: String to replace secrets with
            
        Returns:
            Text with secrets redacted
        """
        redacted = text
        secrets = self.detect_secrets(text)
        
        # Sort by position descending to avoid index shifting
        secrets.sort(key=lambda x: x['position'], reverse=True)
        
        for secret in secrets:
            # Find the actual match using the pattern
            pattern = secret['pattern']
            matches = list(re.finditer(pattern, redacted, re.IGNORECASE))
            if matches:
                # Replace last match (most recent position)
                match = matches[-1]
                redacted = redacted[:match.start()] + replacement + redacted[match.end():]
        
        return redacted

