import os
from pathlib import Path
from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    projects_dir: str = str(Path.home() / "Projects")
    llm_provider: str = "openai"
    openai_api_key: str = ""
    gemini_api_key: str = ""
    ollama_base_url: str = "http://localhost:11434"
    ollama_model: str = "llama2"
    database_url: str = "sqlite:///./devpulse.db"
    
    # Database encryption settings
    db_encryption_enabled: bool = False
    db_encryption_password: Optional[str] = None
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()

