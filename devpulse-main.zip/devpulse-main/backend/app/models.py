from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text, Boolean, Float
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from .database import Base


class Repository(Base):
    __tablename__ = "repositories"
    
    id = Column(Integer, primary_key=True, index=True)
    path = Column(String, unique=True, index=True)
    name = Column(String, index=True)
    tags = Column(String)  # Comma-separated tags: "frontend,paypal,team-a"
    team = Column(String, index=True)  # Optional: team/squad name
    last_scanned = Column(DateTime(timezone=True), server_default=func.now())
    
    commits = relationship("Commit", back_populates="repository")
    branch_metrics = relationship("BranchMetric", back_populates="repository")


class Commit(Base):
    __tablename__ = "commits"
    
    id = Column(Integer, primary_key=True, index=True)
    repo_id = Column(Integer, ForeignKey("repositories.id"), index=True)
    hash = Column(String, index=True)
    message = Column(Text)
    author = Column(String)
    date = Column(DateTime(timezone=True), index=True)
    files_changed = Column(Integer, default=0)
    insertions = Column(Integer, default=0)
    deletions = Column(Integer, default=0)
    type = Column(String, index=True)
    branch_name = Column(String, index=True)
    is_merge_commit = Column(Boolean, default=False, index=True)
    impact_category = Column(String, index=True)  # Revenue, Risk, TechDebt
    
    repository = relationship("Repository", back_populates="commits")


class LogbookEntry(Base):
    __tablename__ = "logbook_entries"
    
    id = Column(Integer, primary_key=True, index=True)
    date = Column(DateTime(timezone=True), index=True, server_default=func.now())
    content = Column(Text)


class Task(Base):
    __tablename__ = "tasks"
    
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    description = Column(Text)
    status = Column(String, default="todo", index=True)  # todo, in-progress, done
    priority = Column(String, default="medium")  # low, medium, high
    platform = Column(String, default="manual")  # manual, jira, other
    external_id = Column(String)  # For future Jira sync
    due_date = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class DailyLog(Base):
    __tablename__ = "daily_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    date = Column(DateTime(timezone=True), index=True, server_default=func.now())
    satisfaction_score = Column(Integer)  # 1-10
    wellbeing_score = Column(Integer)  # 1-10
    blockers = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class BranchMetric(Base):
    __tablename__ = "branch_metrics"
    
    id = Column(Integer, primary_key=True, index=True)
    repo_id = Column(Integer, ForeignKey("repositories.id"), index=True)
    branch_name = Column(String, index=True)
    first_commit_date = Column(DateTime(timezone=True))
    merge_date = Column(DateTime(timezone=True))
    merge_commit_hash = Column(String)
    cycle_time_days = Column(Float)
    
    repository = relationship("Repository", back_populates="branch_metrics")


class FrictionLog(Base):
    __tablename__ = "friction_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    date = Column(DateTime(timezone=True), nullable=False, index=True)
    type = Column(String, nullable=False, index=True)  # 'blocker' | 'learning' | 'win' | 'incident'
    description = Column(Text, nullable=False)
    impact_level = Column(Integer)  # 1-5 scale
    tags = Column(String)  # comma-separated
    resolution = Column(Text)  # optional: how it was resolved
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class ManualEntry(Base):
    __tablename__ = "manual_entries"
    
    id = Column(Integer, primary_key=True, index=True)
    date = Column(DateTime(timezone=True), nullable=False, index=True)
    type = Column(String, nullable=False, index=True)  # 'code_review' | 'design_doc' | 'mentoring' | 'incident' | 'meeting'
    title = Column(String, nullable=False)
    description = Column(Text)
    impact = Column(Text)  # Business impact description
    impact_scope = Column(String, index=True)  # 'team' | 'org' | None - PayPal T24 vs T25 classification
    collaborators = Column(String)  # Comma-separated names
    links = Column(String)  # URLs (PR, doc, Jira, etc)
    duration_minutes = Column(Integer)  # Optional: time spent
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class CareerMoment(Base):
    __tablename__ = "career_moments"
    
    id = Column(Integer, primary_key=True, index=True)
    date = Column(DateTime(timezone=True), nullable=False, index=True)
    type = Column(String, nullable=False)  # 'win' | 'failure' | 'pivot' | 'learning'
    title = Column(String, nullable=False)
    story = Column(Text)  # Rich text story
    impact = Column(Text)  # Business/technical impact description
    witnesses = Column(String)  # Comma-separated list of people who witnessed/validated
    tags = Column(String)  # Comma-separated tags
    related_commits = Column(String)  # JSON array of commit IDs
    related_entries = Column(String)  # JSON array of manual entry IDs
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class Goal(Base):
    __tablename__ = "goals"
    
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    description = Column(Text)
    deadline = Column(DateTime(timezone=True), nullable=False, index=True)
    status = Column(String, default="active")  # 'active' | 'completed' | 'cancelled'
    progress = Column(Float, default=0.0)  # 0.0 to 1.0
    target_metric = Column(String)  # e.g., "Reduce API latency 30%"
    current_metric = Column(String)  # e.g., "15% reduction achieved"
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class GoalLink(Base):
    __tablename__ = "goal_links"
    
    id = Column(Integer, primary_key=True, index=True)
    goal_id = Column(Integer, ForeignKey("goals.id"), nullable=False)
    commit_id = Column(Integer, ForeignKey("commits.id"), nullable=True)
    entry_id = Column(Integer, ForeignKey("manual_entries.id"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Feedback(Base):
    __tablename__ = "feedback"
    
    id = Column(Integer, primary_key=True, index=True)
    from_who = Column(String, nullable=False)  # Name of person giving feedback
    date = Column(DateTime(timezone=True), nullable=False, index=True)
    context = Column(String)  # e.g., "post-project", "code-review", "1-on-1"
    feedback_text = Column(Text, nullable=False)
    category = Column(String)  # 'positive' | 'constructive' | 'neutral'
    tags = Column(String)  # Comma-separated tags
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class TeamBenchmark(Base):
    __tablename__ = "team_benchmarks"

    id = Column(Integer, primary_key=True, index=True)
    metric_name = Column(String, nullable=False, index=True)  # 'deployment_frequency', 'lead_time', etc.
    metric_value = Column(Float, nullable=False)
    metric_unit = Column(String)  # 'per_week', 'days', 'percentage', etc.
    period_start = Column(DateTime(timezone=True), nullable=False, index=True)
    period_end = Column(DateTime(timezone=True), nullable=False, index=True)
    team_name = Column(String, index=True)  # Optional: anonymized team identifier
    source = Column(String, default='manual')  # 'manual' | 'imported'
    notes = Column(Text)  # Optional context
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class IndustryBenchmark(Base):
    __tablename__ = "industry_benchmarks"

    id = Column(Integer, primary_key=True, index=True)
    metric_name = Column(String, nullable=False, index=True)
    category = Column(String, nullable=False)  # 'elite' | 'high' | 'medium' | 'low'
    min_value = Column(Float)  # Lower bound for category
    max_value = Column(Float)  # Upper bound for category (None for elite/low)
    source = Column(String, default='dora')  # 'dora' | 'custom'
    year = Column(Integer)  # Benchmark year
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class HistoricalSnapshot(Base):
    __tablename__ = "historical_snapshots"

    id = Column(Integer, primary_key=True, index=True)
    period_label = Column(String, nullable=False, index=True)  # 'Q1-2024', 'Q2-2024', etc.
    period_start = Column(DateTime(timezone=True), nullable=False)
    period_end = Column(DateTime(timezone=True), nullable=False)
    snapshot_data = Column(Text)  # JSON string with all metrics
    dora_metrics = Column(Text)  # JSON string with DORA metrics
    space_metrics = Column(Text)  # JSON string with SPACE metrics
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class LLMUsageLog(Base):
    __tablename__ = "llm_usage_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    provider = Column(String, nullable=False, index=True)  # 'openai' | 'gemini'
    model = Column(String, nullable=False)  # 'gpt-3.5-turbo', 'gemini-pro', etc.
    operation = Column(String, nullable=False, index=True)  # 'executive_summary' | 'challenges' | 'collaboration'
    input_tokens = Column(Integer, default=0)
    output_tokens = Column(Integer, default=0)
    cost_usd = Column(Float, default=0.0)
    request_duration_ms = Column(Integer)
    success = Column(Boolean, default=True)
    error_message = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)


class LLMRateLimit(Base):
    __tablename__ = "llm_rate_limits"
    
    id = Column(Integer, primary_key=True, index=True)
    provider = Column(String, nullable=False, unique=True)
    requests_per_minute = Column(Integer, default=60)
    tokens_per_minute = Column(Integer, default=90000)
    requests_per_day = Column(Integer, default=1000)
    current_minute_requests = Column(Integer, default=0)
    current_minute_tokens = Column(Integer, default=0)
    current_day_requests = Column(Integer, default=0)
    last_reset_minute = Column(DateTime(timezone=True))
    last_reset_day = Column(DateTime(timezone=True))
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class UserContext(Base):
    __tablename__ = "user_context"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String, unique=True, index=True, default="default")  # Support multi-user in future
    role = Column(String)  # e.g., "Senior Software Engineer", "Staff Engineer"
    team = Column(String)  # e.g., "Payments Platform", "Checkout Squad"
    business_domain = Column(String)  # e.g., "E-commerce", "Financial Services"
    company = Column(String)  # e.g., "PayPal"
    preferred_language = Column(String, default="en")  # "en" or "pt"
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class ReportTemplateConfig(Base):
    __tablename__ = "report_templates"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)  # e.g., "1:1 Meeting", "Performance Review"
    description = Column(Text)
    template_type = Column(String, index=True)  # "one_on_one", "performance_review", "custom"
    sections = Column(Text)  # JSON: list of section names to include
    prompt_overrides = Column(Text)  # JSON: custom prompts for each section
    is_default = Column(Boolean, default=False)
    user_id = Column(String, default="default")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class SavedReport(Base):
    __tablename__ = "saved_reports"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)  # e.g., "Q1 2025 Performance Review"
    period_start = Column(DateTime(timezone=True), nullable=False, index=True)
    period_end = Column(DateTime(timezone=True), nullable=False, index=True)
    quarter = Column(String, index=True)  # e.g., "Q1-2025"
    report_data = Column(Text)  # JSON string of full report
    markdown_content = Column(Text)  # Cached markdown
    pdf_path = Column(String)  # Optional: path to saved PDF
    repo_id = Column(Integer, ForeignKey("repositories.id"), nullable=True)
    tags = Column(String)  # Comma-separated tags
    notes = Column(Text)  # User notes about this report
    original_report_data = Column(Text)  # JSON: original AI-generated data
    edited_sections = Column(Text)  # JSON: which sections were edited
    template_id = Column(Integer, ForeignKey("report_templates.id"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    
    template = relationship("ReportTemplateConfig")


class UserSettings(Base):
    __tablename__ = "user_settings"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String, unique=True, index=True, default="default")
    # Security settings
    enable_secret_detection = Column(Boolean, default=True)
    auto_redact_secrets = Column(Boolean, default=False)
    block_on_secret = Column(Boolean, default=True)
    redact_emails = Column(Boolean, default=False)
    redact_internal_urls = Column(Boolean, default=False)
    # Other settings can be added here
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

