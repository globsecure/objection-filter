from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .database import engine, Base, get_db
from .api import commits, metrics, reports, logbook, tasks, dora, space, friction, manual_entries, settings, repositories, validation, quality, backup, data_export, moments, goals, feedback, time_patterns, benchmarks, llm_usage, security, data_quality, user_context, templates, paypal
from .services.benchmark_service import seed_industry_benchmarks

Base.metadata.create_all(bind=engine)

app = FastAPI(title="DevPulse API", version="2.0.0")


@app.on_event("startup")
def startup_event():
    """Seed industry benchmarks on startup"""
    db = next(get_db())
    try:
        seed_industry_benchmarks(db)
    finally:
        db.close()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(commits.router, prefix="/api", tags=["commits"])
app.include_router(repositories.router, prefix="/api", tags=["repositories"])
app.include_router(metrics.router, prefix="/api/metrics", tags=["metrics"])
app.include_router(reports.router, prefix="/api/reports", tags=["reports"])
app.include_router(logbook.router, prefix="/api/logbook", tags=["logbook"])
app.include_router(tasks.router, prefix="/api/tasks", tags=["tasks"])
app.include_router(dora.router, prefix="/api/dora", tags=["dora"])
app.include_router(space.router, prefix="/api/space", tags=["space"])
app.include_router(friction.router, prefix="/api/friction", tags=["friction"])
app.include_router(manual_entries.router, prefix="/api/manual-entries", tags=["manual-entries"])
app.include_router(moments.router, prefix="/api/moments", tags=["moments"])
app.include_router(goals.router, prefix="/api/goals", tags=["goals"])
app.include_router(feedback.router, prefix="/api/feedback", tags=["feedback"])
app.include_router(time_patterns.router, prefix="/api/time-patterns", tags=["time-patterns"])
app.include_router(settings.router, prefix="/api/settings", tags=["settings"])
app.include_router(user_context.router, prefix="/api", tags=["user-context"])
app.include_router(templates.router, prefix="/api", tags=["templates"])
app.include_router(validation.router, prefix="/api/validation", tags=["validation"])
app.include_router(quality.router, prefix="/api/quality", tags=["quality"])
app.include_router(backup.router, prefix="/api/backup", tags=["backup"])
app.include_router(data_export.router, prefix="/api", tags=["export"])
app.include_router(benchmarks.router)
app.include_router(llm_usage.router, prefix="/api/llm", tags=["llm"])
app.include_router(security.router)
app.include_router(data_quality.router)
app.include_router(paypal.router)


@app.get("/")
def read_root():
    return {"message": "DevPulse API v2.0 - DORA & SPACE Metrics Enabled"}

