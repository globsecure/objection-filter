from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from .config import settings
import os

Base = declarative_base()


def get_encrypted_engine(db_path: str, password: str):
    """
    Create encrypted SQLite engine using SQLCipher.
    
    Args:
        db_path: Path to database file
        password: Encryption password
        
    Returns:
        SQLAlchemy engine with SQLCipher encryption
        
    Raises:
        ImportError: If pysqlcipher3 is not installed
    """
    try:
        from pysqlcipher3 import dbapi2 as sqlite3
    except ImportError:
        raise ImportError(
            "pysqlcipher3 not installed. Install with: pip install pysqlcipher3"
        )
    
    # SQLCipher connection string
    # Format: sqlite+pysqlcipher://:password@/path/to/database.db
    conn_string = f"sqlite+pysqlcipher://:{password}@{db_path}?cipher_compatibility=4"
    
    engine = create_engine(
        conn_string,
        poolclass=StaticPool,
        connect_args={
            'check_same_thread': False,
            'cipher_compatibility': 4
        }
    )
    
    return engine


def get_engine():
    """
    Get database engine, with encryption support if enabled.
    
    Returns:
        SQLAlchemy engine
    """
    if settings.db_encryption_enabled and settings.db_encryption_password:
        # Extract path from database_url
        # Format: sqlite:///./devpulse.db -> ./devpulse.db
        db_path = settings.database_url.replace("sqlite:///", "")
        if db_path.startswith("./"):
            db_path = os.path.abspath(db_path)
        
        return get_encrypted_engine(db_path, settings.db_encryption_password)
    else:
        # Standard SQLite engine
        return create_engine(
            settings.database_url,
            connect_args={"check_same_thread": False} if "sqlite" in settings.database_url else {}
        )


engine = get_engine()
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

