import re
from typing import Dict


def categorize_commit(commit_data: Dict) -> str:
    """
    Categorize a commit based on message patterns and file paths.
    Returns: Feature, Bugfix, Refactor, Documentation, Chore, or Unknown
    """
    message = commit_data.get('message', '').lower()
    
    patterns = {
        'Feature': [
            r'^feat[:\s]',
            r'^feature[:\s]',
            r'add\s+',
            r'new\s+',
            r'implement\s+',
            r'create\s+'
        ],
        'Bugfix': [
            r'^fix[:\s]',
            r'^bugfix[:\s]',
            r'^bug[:\s]',
            r'fix\s+',
            r'resolve\s+',
            r'correct\s+',
            r'patch\s+'
        ],
        'Refactor': [
            r'^refactor[:\s]',
            r'refactor\s+',
            r'cleanup\s+',
            r'restructure\s+',
            r'optimize\s+',
            r'improve\s+'
        ],
        'Documentation': [
            r'^docs[:\s]',
            r'^doc[:\s]',
            r'documentation',
            r'readme',
            r'comment\s+',
            r'update\s+.*readme',
            r'update\s+.*doc'
        ],
        'Chore': [
            r'^chore[:\s]',
            r'^ci[:\s]',
            r'^build[:\s]',
            r'update\s+dependencies',
            r'update\s+.*\.lock',
            r'merge\s+',
            r'^bump\s+'
        ]
    }
    
    for category, pattern_list in patterns.items():
        for pattern in pattern_list:
            if re.search(pattern, message, re.IGNORECASE):
                return category
    
    return 'Unknown'

