from sqlalchemy.orm import Session
from typing import List, Dict, Optional
from datetime import datetime
from statistics import mean, median
from ..models import Commit, Repository
from .dora_metrics import get_dora_metrics
from .space_metrics import get_space_metrics


def aggregate_dora_metrics(
    db: Session,
    repo_ids: Optional[List[int]] = None,
    tags: Optional[List[str]] = None,
    team: Optional[str] = None,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None
) -> Dict:
    """
    Aggregate DORA metrics across multiple repositories.
    """
    repos = _get_filtered_repositories(db, repo_ids, tags, team)
    
    if not repos:
        return {
            'repositories': [],
            'aggregated': None,
            'per_repo': []
        }
    
    per_repo_metrics = []
    total_deployments = 0
    total_lead_times = []
    total_failures = 0
    total_mttr_times = []
    
    for repo in repos:
        metrics = get_dora_metrics(db, start_date, end_date, repo.id)
        per_repo_metrics.append({
            'repo_id': repo.id,
            'repo_name': repo.name,
            'metrics': metrics
        })
        
        # Aggregate values
        df = metrics.get('deployment_frequency', {})
        lt = metrics.get('lead_time', {})
        cfr = metrics.get('change_failure_rate', {})
        mttr = metrics.get('mttr', {})
        
        total_deployments += df.get('total_deployments', 0)
        if lt.get('average_days'):
            total_lead_times.append(lt['average_days'])
        total_failures += cfr.get('failed_deployments', 0)
        if mttr.get('mean_hours'):
            total_mttr_times.append(mttr['mean_hours'])
    
    # Calculate aggregated metrics
    aggregated = {
        'deployment_frequency': {
            'total_deployments': total_deployments,
            'frequency_per_week': sum(m['metrics']['deployment_frequency'].get('frequency_per_week', 0) for m in per_repo_metrics) / len(per_repo_metrics) if per_repo_metrics else 0
        },
        'lead_time': {
            'average_days': sum(total_lead_times) / len(total_lead_times) if total_lead_times else 0,
            'median_days': median(total_lead_times) if total_lead_times else 0
        },
        'change_failure_rate': {
            'failure_rate': (total_failures / total_deployments * 100) if total_deployments > 0 else 0,
            'total_deployments': total_deployments,
            'failed_deployments': total_failures
        },
        'mttr': {
            'mean_hours': sum(total_mttr_times) / len(total_mttr_times) if total_mttr_times else 0,
            'median_hours': median(total_mttr_times) if total_mttr_times else 0
        }
    }
    
    return {
        'repositories': [{'id': r.id, 'name': r.name} for r in repos],
        'aggregated': aggregated,
        'per_repo': per_repo_metrics
    }


def aggregate_space_metrics(
    db: Session,
    repo_ids: Optional[List[int]] = None,
    tags: Optional[List[str]] = None,
    team: Optional[str] = None,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None
) -> Dict:
    """
    Aggregate SPACE metrics across multiple repositories.
    """
    repos = _get_filtered_repositories(db, repo_ids, tags, team)
    
    if not repos:
        return {
            'repositories': [],
            'aggregated': None,
            'per_repo': []
        }
    
    per_repo_metrics = []
    satisfaction_scores = []
    performance_scores = []
    activity_scores = []
    collaboration_scores = []
    efficiency_scores = []
    
    for repo in repos:
        metrics = get_space_metrics(db, start_date, end_date, repo.id)
        per_repo_metrics.append({
            'repo_id': repo.id,
            'repo_name': repo.name,
            'metrics': metrics
        })
        
        sat = metrics.get('satisfaction', {})
        perf = metrics.get('performance', {})
        act = metrics.get('activity', {})
        collab = metrics.get('collaboration', {})
        eff = metrics.get('efficiency', {})
        
        if sat.get('average_satisfaction'):
            satisfaction_scores.append(sat['average_satisfaction'] * 10)
        if perf.get('quality_score'):
            performance_scores.append(perf['quality_score'])
        if act.get('consistency_score'):
            activity_scores.append(act['consistency_score'] * 100)
        if collab.get('collaboration_score'):
            collaboration_scores.append(collab['collaboration_score'])
        if eff.get('score'):
            efficiency_scores.append(eff['score'])
    
    aggregated = {
        'satisfaction': mean(satisfaction_scores) if satisfaction_scores else 0,
        'performance': mean(performance_scores) if performance_scores else 0,
        'activity': mean(activity_scores) if activity_scores else 0,
        'collaboration': mean(collaboration_scores) if collaboration_scores else 0,
        'efficiency': mean(efficiency_scores) if efficiency_scores else 0
    }
    
    return {
        'repositories': [{'id': r.id, 'name': r.name} for r in repos],
        'aggregated': aggregated,
        'per_repo': per_repo_metrics
    }


def _get_filtered_repositories(
    db: Session,
    repo_ids: Optional[List[int]] = None,
    tags: Optional[List[str]] = None,
    team: Optional[str] = None
) -> List[Repository]:
    """Get repositories based on filters."""
    query = db.query(Repository)
    
    if repo_ids:
        query = query.filter(Repository.id.in_(repo_ids))
    if tags:
        for tag in tags:
            query = query.filter(Repository.tags.contains(tag))
    if team:
        query = query.filter(Repository.team == team)
    
    return query.all()

