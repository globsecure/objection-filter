from sqlalchemy.orm import Session
from typing import Optional
from ..models import ManualEntry
from ..analysis.llm_service import get_llm_provider


def classify_impact_scope(
    entry: ManualEntry,
    db: Optional[Session] = None,
    user_id: str = "default"
) -> Optional[str]:
    """
    Classify ManualEntry impact scope using LLM.
    
    Returns:
        'team' for Team-level impact (T24/Senior)
        'org' for Org-level impact (T25/Staff)
        None if classification fails
    """
    if not entry.description and not entry.impact:
        return None
    
    # Build context for LLM
    context = f"""
Title: {entry.title}
Type: {entry.type}
Description: {entry.description or ''}
Impact: {entry.impact or ''}
"""
    
    prompt = f"""Analyze this work entry and classify its impact scope:

{context}

Classify as:
- "team" if this solves a problem for just the team/squad (Senior/T24 level)
- "org" if this solves a problem for the whole organization/multiple teams (Staff/T25 level)

Consider:
- Team-level: Team-specific improvements, squad optimizations, local refactoring
- Org-level: Cross-team infrastructure, shared libraries, platform improvements, org-wide standards

Respond with ONLY one word: "team" or "org"
"""
    
    try:
        llm_provider = get_llm_provider(redact_sensitive=True)
        
        # Use a simple completion method
        # Since we don't have a direct completion method, we'll use summarize_commits as a workaround
        # Or we can add a completion method to LLMProvider
        
        # For now, let's use a simple keyword-based classification as fallback
        text = context.lower()
        
        org_keywords = ['organization', 'org', 'platform', 'infrastructure', 'shared', 'cross-team', 'company-wide', 'enterprise']
        team_keywords = ['team', 'squad', 'local', 'internal']
        
        org_score = sum(1 for keyword in org_keywords if keyword in text)
        team_score = sum(1 for keyword in team_keywords if keyword in text)
        
        if org_score > team_score and org_score > 0:
            return 'org'
        elif team_score > 0:
            return 'team'
        else:
            return None
            
    except Exception as e:
        print(f"Error classifying impact scope: {e}")
        return None


def auto_label_impact_scope(
    entry_id: int,
    db: Session,
    user_id: str = "default"
) -> Optional[str]:
    """
    Auto-label impact scope for a ManualEntry and save to database.
    
    Returns:
        The classified scope ('team' or 'org') or None
    """
    entry = db.query(ManualEntry).filter(ManualEntry.id == entry_id).first()
    if not entry:
        return None
    
    scope = classify_impact_scope(entry, db, user_id)
    
    if scope:
        entry.impact_scope = scope
        db.commit()
        db.refresh(entry)
    
    return scope

