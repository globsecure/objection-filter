from sqlalchemy.orm import Session
from sqlalchemy import func, and_, or_
from typing import List, Dict, Optional
from datetime import datetime, timedelta
from statistics import mean, median, stdev
from ..models import Commit, BranchMetric, Repository, FrictionLog


def calculate_cycle_time(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """
    Calculate cycle time metrics from branch metrics.
    """
    query = db.query(BranchMetric).filter(BranchMetric.cycle_time_days.isnot(None))
    
    if repo_id:
        query = query.filter(BranchMetric.repo_id == repo_id)
    if start_date:
        query = query.filter(BranchMetric.merge_date >= start_date)
    if end_date:
        query = query.filter(BranchMetric.merge_date <= end_date)
    
    metrics = query.all()
    
    if not metrics:
        return {
            'average_days': 0.0,
            'median_days': 0.0,
            'min_days': 0.0,
            'max_days': 0.0,
            'total_branches': 0,
            'trend': []
        }
    
    cycle_times = [m.cycle_time_days for m in metrics if m.cycle_time_days is not None]
    
    # Calculate trend (weekly averages)
    trend_data = []
    weekly_query = db.query(
        func.strftime('%Y-W%W', BranchMetric.merge_date).label('week'),
        func.avg(BranchMetric.cycle_time_days).label('avg_cycle_time'),
        func.count(BranchMetric.id).label('branch_count')
    ).filter(BranchMetric.cycle_time_days.isnot(None))
    
    if repo_id:
        weekly_query = weekly_query.filter(BranchMetric.repo_id == repo_id)
    if start_date:
        weekly_query = weekly_query.filter(BranchMetric.merge_date >= start_date)
    if end_date:
        weekly_query = weekly_query.filter(BranchMetric.merge_date <= end_date)
    
    weekly_results = weekly_query.group_by('week').order_by('week').all()
    
    for row in weekly_results:
        trend_data.append({
            'period': row.week,
            'value': round(row.avg_cycle_time, 2) if row.avg_cycle_time else 0,
            'branch_count': row.branch_count
        })
    
    return {
        'average_days': round(sum(cycle_times) / len(cycle_times), 2),
        'median_days': round(median(cycle_times), 2) if cycle_times else 0.0,
        'min_days': round(min(cycle_times), 2) if cycle_times else 0.0,
        'max_days': round(max(cycle_times), 2) if cycle_times else 0.0,
        'total_branches': len(metrics),
        'trend': trend_data
    }


def calculate_deployment_frequency(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """
    Calculate deployment frequency (merges to main branch).
    """
    query = db.query(Commit).filter(Commit.is_merge_commit == True)
    
    if repo_id:
        query = query.filter(Commit.repo_id == repo_id)
    if start_date:
        query = query.filter(Commit.date >= start_date)
    if end_date:
        query = query.filter(Commit.date <= end_date)
    
    merge_commits = query.all()
    total_deployments = len(merge_commits)
    
    if total_deployments == 0:
        return {
            'total_deployments': 0,
            'frequency_per_week': 0.0,
            'frequency_per_month': 0.0,
            'trend': []
        }
    
    # Calculate time span
    if merge_commits:
        dates = [c.date for c in merge_commits]
        first_date = min(dates)
        last_date = max(dates)
        days_span = max(1, (last_date - first_date).days)
        weeks = max(1, days_span / 7)
        months = max(1, days_span / 30)
    else:
        weeks = 1
        months = 1
    
    # Calculate trend (weekly counts)
    trend_query = db.query(
        func.strftime('%Y-W%W', Commit.date).label('week'),
        func.count(Commit.id).label('count')
    ).filter(Commit.is_merge_commit == True)
    
    if repo_id:
        trend_query = trend_query.filter(Commit.repo_id == repo_id)
    if start_date:
        trend_query = trend_query.filter(Commit.date >= start_date)
    if end_date:
        trend_query = trend_query.filter(Commit.date <= end_date)
    
    trend_results = trend_query.group_by('week').order_by('week').all()
    
    trend_data = [
        {'period': row.week, 'count': row.count}
        for row in trend_results
    ]
    
    return {
        'total_deployments': total_deployments,
        'frequency_per_week': round(total_deployments / weeks, 2),
        'frequency_per_month': round(total_deployments / months, 2),
        'trend': trend_data
    }


def get_branch_metrics_list(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None,
    limit: int = 50
) -> List[Dict]:
    """
    Get list of branch metrics for detailed analysis.
    """
    query = db.query(BranchMetric)
    
    if repo_id:
        query = query.filter(BranchMetric.repo_id == repo_id)
    if start_date:
        query = query.filter(BranchMetric.merge_date >= start_date)
    if end_date:
        query = query.filter(BranchMetric.merge_date <= end_date)
    
    metrics = query.order_by(BranchMetric.merge_date.desc()).limit(limit).all()
    
    return [
        {
            'id': m.id,
            'repo_id': m.repo_id,
            'branch_name': m.branch_name,
            'first_commit_date': m.first_commit_date.isoformat() if m.first_commit_date else None,
            'merge_date': m.merge_date.isoformat() if m.merge_date else None,
            'merge_commit_hash': m.merge_commit_hash,
            'cycle_time_days': round(m.cycle_time_days, 2) if m.cycle_time_days else None
        }
        for m in metrics
    ]


def get_cycle_time_distribution(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """
    Get distribution of cycle times for histogram visualization.
    """
    query = db.query(BranchMetric).filter(BranchMetric.cycle_time_days.isnot(None))
    
    if repo_id:
        query = query.filter(BranchMetric.repo_id == repo_id)
    if start_date:
        query = query.filter(BranchMetric.merge_date >= start_date)
    if end_date:
        query = query.filter(BranchMetric.merge_date <= end_date)
    
    metrics = query.all()
    
    # Create buckets: <1 day, 1-2, 2-3, 3-5, 5-7, 7-14, 14+
    buckets = {
        '<1 day': 0,
        '1-2 days': 0,
        '2-3 days': 0,
        '3-5 days': 0,
        '5-7 days': 0,
        '1-2 weeks': 0,
        '2+ weeks': 0
    }
    
    for m in metrics:
        ct = m.cycle_time_days
        if ct < 1:
            buckets['<1 day'] += 1
        elif ct < 2:
            buckets['1-2 days'] += 1
        elif ct < 3:
            buckets['2-3 days'] += 1
        elif ct < 5:
            buckets['3-5 days'] += 1
        elif ct < 7:
            buckets['5-7 days'] += 1
        elif ct < 14:
            buckets['1-2 weeks'] += 1
        else:
            buckets['2+ weeks'] += 1
    
    return {
        'distribution': [
            {'bucket': k, 'count': v}
            for k, v in buckets.items()
        ],
        'total': len(metrics)
    }


def _get_deployments(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> List[Commit]:
    """
    Helper function to get all deployments (merge commits).
    """
    query = db.query(Commit).filter(Commit.is_merge_commit == True)
    
    if repo_id:
        query = query.filter(Commit.repo_id == repo_id)
    if start_date:
        query = query.filter(Commit.date >= start_date)
    if end_date:
        query = query.filter(Commit.date <= end_date)
    
    return query.all()


def calculate_change_failure_rate(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """
    Calculate Change Failure Rate: % of deployments that result in incidents.
    
    Sources:
    1. Friction logs with type='incident' linked to commits
    2. Commits with keywords: revert, hotfix, rollback
    3. Revert commits (detected from commit messages)
    """
    # Get all deployments (merges to main)
    deployments = _get_deployments(db, start_date, end_date, repo_id)
    
    if not deployments:
        return {
            'failure_rate': 0.0,
            'total_deployments': 0,
            'failed_deployments': 0,
            'category': 'N/A',
            'incidents_count': 0,
            'revert_commits_count': 0
        }
    
    # Get incidents from friction logs
    incident_query = db.query(FrictionLog).filter(
        FrictionLog.type == 'incident'
    )
    if start_date:
        incident_query = incident_query.filter(FrictionLog.date >= start_date)
    if end_date:
        incident_query = incident_query.filter(FrictionLog.date <= end_date)
    incidents = incident_query.all()
    
    # Get revert/hotfix commits
    revert_keywords = ['revert', 'hotfix', 'rollback', 'fix critical', 'emergency']
    revert_query = db.query(Commit).filter(
        or_(*[Commit.message.ilike(f'%{kw}%') for kw in revert_keywords])
    )
    if start_date:
        revert_query = revert_query.filter(Commit.date >= start_date)
    if end_date:
        revert_query = revert_query.filter(Commit.date <= end_date)
    if repo_id:
        revert_query = revert_query.filter(Commit.repo_id == repo_id)
    revert_commits = revert_query.all()
    
    # Match incidents to deployments (within 24 hours)
    failed_deployments = set()
    for incident in incidents:
        # Find deployments within 24h before incident
        incident_time = incident.date
        for deploy in deployments:
            time_diff = abs((deploy.date - incident_time).total_seconds())
            if time_diff < 86400:  # 24 hours
                failed_deployments.add(deploy.id)
    
    # Add revert commits as failures
    for revert in revert_commits:
        # Find associated deployment
        for deploy in deployments:
            time_diff = abs((deploy.date - revert.date).total_seconds())
            if time_diff < 86400:
                failed_deployments.add(deploy.id)
    
    total_deployments = len(deployments)
    failed_count = len(failed_deployments)
    
    failure_rate = (failed_count / total_deployments * 100) if total_deployments > 0 else 0.0
    
    # Determine benchmark category
    if failure_rate <= 5:
        category = "Elite"
    elif failure_rate <= 10:
        category = "High"
    elif failure_rate <= 15:
        category = "Medium"
    else:
        category = "Low"
    
    return {
        'failure_rate': round(failure_rate, 2),
        'total_deployments': total_deployments,
        'failed_deployments': failed_count,
        'category': category,
        'incidents_count': len(incidents),
        'revert_commits_count': len(revert_commits)
    }


def calculate_mttr(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """
    Calculate Mean Time to Recovery from incidents.
    
    Uses friction logs with type='incident' and resolution timestamps.
    Falls back to time between incident and first fix commit.
    """
    # Get incidents from friction logs
    incident_query = db.query(FrictionLog).filter(
        FrictionLog.type == 'incident'
    )
    if start_date:
        incident_query = incident_query.filter(FrictionLog.date >= start_date)
    if end_date:
        incident_query = incident_query.filter(FrictionLog.date <= end_date)
    incidents = incident_query.all()
    
    if not incidents:
        return {
            'mean_hours': 0.0,
            'median_hours': 0.0,
            'min_hours': 0.0,
            'max_hours': 0.0,
            'total_incidents': 0,
            'resolved_incidents': 0,
            'category': 'N/A'
        }
    
    recovery_times = []
    
    for incident in incidents:
        recovery_time = None
        
        # Method 1: Look for fix commits after incident
        fix_query = db.query(Commit).filter(
            Commit.date > incident.date,
            Commit.date <= incident.date + timedelta(days=7),  # Within 7 days
            or_(
                Commit.message.ilike('%fix%'),
                Commit.message.ilike('%resolve%'),
                Commit.message.ilike('%patch%')
            )
        )
        if repo_id:
            fix_query = fix_query.filter(Commit.repo_id == repo_id)
        
        first_fix = fix_query.order_by(Commit.date.asc()).first()
        if first_fix:
            recovery_time = (first_fix.date - incident.date).total_seconds() / 3600  # hours
        
        if recovery_time is not None:
            recovery_times.append(recovery_time)
    
    if not recovery_times:
        return {
            'mean_hours': 0.0,
            'median_hours': 0.0,
            'min_hours': 0.0,
            'max_hours': 0.0,
            'total_incidents': len(incidents),
            'resolved_incidents': 0,
            'category': 'N/A'
        }
    
    mean_hours = mean(recovery_times)
    median_hours = median(recovery_times)
    
    # Determine benchmark category
    if mean_hours < 1:
        category = "Elite"
    elif mean_hours < 24:
        category = "High"
    elif mean_hours < 168:  # 1 week
        category = "Medium"
    else:
        category = "Low"
    
    return {
        'mean_hours': round(mean_hours, 2),
        'median_hours': round(median_hours, 2),
        'min_hours': round(min(recovery_times), 2),
        'max_hours': round(max(recovery_times), 2),
        'total_incidents': len(incidents),
        'resolved_incidents': len(recovery_times),
        'category': category
    }


def get_dora_metrics(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """
    Get complete DORA metrics summary (all 4 metrics).
    """
    return {
        'deployment_frequency': calculate_deployment_frequency(db, start_date, end_date, repo_id),
        'lead_time': calculate_cycle_time(db, start_date, end_date, repo_id),
        'change_failure_rate': calculate_change_failure_rate(db, start_date, end_date, repo_id),
        'mttr': calculate_mttr(db, start_date, end_date, repo_id)
    }

