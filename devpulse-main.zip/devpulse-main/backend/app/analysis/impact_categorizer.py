import re
from typing import Dict, Tuple, Optional, List
from enum import Enum


class ImpactCategory(str, Enum):
    REVENUE_DRIVING = "Revenue"
    RISK_REDUCTION = "Risk"
    TECH_DEBT = "TechDebt"
    UNKNOWN = "Unknown"


CATEGORY_PATTERNS: Dict[ImpactCategory, List[str]] = {
    ImpactCategory.REVENUE_DRIVING: [
        r'\bfeat(ure)?[:\s]',
        r'\bnew\s+feature',
        r'\badd(ed|ing)?\s+.*\b(feature|capability|functionality)',
        r'\bintegrat(e|ion)',
        r'\bcustomer',
        r'\buser\s+(experience|interface|facing)',
        r'\bui\b',
        r'\bux\b',
        r'\bpayment',
        r'\bcheckout',
        r'\bsubscription',
        r'\bpurchase',
        r'\bonboard',
        r'\bconversion',
        r'\bengagement',
        r'\bretention',
        r'\bmonetiz',
        r'\brevenue',
        r'\bsales',
        r'\bproduct\s+launch',
    ],
    ImpactCategory.RISK_REDUCTION: [
        r'\bfix(ed|es|ing)?[:\s]',
        r'\bbug(fix)?[:\s]',
        r'\bhotfix',
        r'\bpatch',
        r'\bresolv(e|ed|ing)',
        r'\bcorrect(ed|ing)?',
        r'\bsecurity',
        r'\bvulnerability',
        r'\bcve',
        r'\bauth(entication|orization)?',
        r'\bpermission',
        r'\bvalidat(e|ion)',
        r'\bsaniti(ze|zation)',
        r'\berror\s+handl',
        r'\bexception',
        r'\bcrash',
        r'\bstability',
        r'\breliability',
        r'\bfallback',
        r'\brecovery',
        r'\brollback',
        r'\btest(s|ing)?',
        r'\bvalidation',
        r'\bregression',
    ],
    ImpactCategory.TECH_DEBT: [
        r'\brefactor(ed|ing)?[:\s]',
        r'\bcleanup',
        r'\bclean\s+up',
        r'\brestructur(e|ing)',
        r'\breorganiz(e|ing)',
        r'\boptimiz(e|ation)',
        r'\bperformance',
        r'\bspeed\s+up',
        r'\bimprov(e|ed|ing)',
        r'\bscalability',
        r'\bscalable',
        r'\bmodular',
        r'\babstraction',
        r'\bdry\b',
        r'\bdecouple',
        r'\bdebt',
        r'\blegacy',
        r'\bmigrat(e|ion)',
        r'\bupgrad(e|ing)',
        r'\bdependenc(y|ies)',
        r'\bupdate\s+.*\b(package|library|version)',
        r'\bchore[:\s]',
        r'\bbuild[:\s]',
        r'\bci[:\s]',
        r'\binfrastructure',
        r'\bconfig',
        r'\bsetup',
    ],
}


def categorize_commit_impact(message: str, commit_type: Optional[str] = None) -> Tuple[ImpactCategory, float]:
    """
    Categorize a commit based on its message using pattern matching.
    Returns the category and confidence score (0.0 to 1.0).
    """
    message_lower = message.lower()
    scores: Dict[ImpactCategory, float] = {
        ImpactCategory.REVENUE_DRIVING: 0.0,
        ImpactCategory.RISK_REDUCTION: 0.0,
        ImpactCategory.TECH_DEBT: 0.0,
    }
    
    # Score based on pattern matches
    for category, patterns in CATEGORY_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, message_lower, re.IGNORECASE):
                scores[category] += 1.0
    
    # Boost based on commit type
    if commit_type:
        type_lower = commit_type.lower()
        if type_lower == "feature":
            scores[ImpactCategory.REVENUE_DRIVING] += 2.0
        elif type_lower == "bugfix":
            scores[ImpactCategory.RISK_REDUCTION] += 2.0
        elif type_lower in ["refactor", "chore"]:
            scores[ImpactCategory.TECH_DEBT] += 2.0
    
    # Normalize and find best match
    total_score = sum(scores.values())
    if total_score == 0:
        return ImpactCategory.UNKNOWN, 0.0
    
    best_category = max(scores, key=scores.get)
    confidence = scores[best_category] / (total_score + 1)  # +1 to dampen confidence
    
    # Require minimum confidence
    if confidence < 0.2:
        return ImpactCategory.UNKNOWN, confidence
    
    return best_category, min(confidence, 1.0)


def categorize_commits_batch(commits: List[Dict]) -> Dict[ImpactCategory, int]:
    """
    Categorize a batch of commits and return distribution.
    """
    distribution = {
        ImpactCategory.REVENUE_DRIVING: 0,
        ImpactCategory.RISK_REDUCTION: 0,
        ImpactCategory.TECH_DEBT: 0,
        ImpactCategory.UNKNOWN: 0,
    }
    
    for commit in commits:
        message = commit.get("message", "")
        commit_type = commit.get("type")
        category, _ = categorize_commit_impact(message, commit_type)
        distribution[category] += 1
    
    return distribution


def get_impact_summary(commits: List[Dict]) -> Dict:
    """
    Generate impact summary from commits.
    """
    distribution = categorize_commits_batch(commits)
    total = sum(distribution.values())
    
    return {
        "total_commits": total,
        "distribution": {
            "revenue_driving": distribution[ImpactCategory.REVENUE_DRIVING],
            "risk_reduction": distribution[ImpactCategory.RISK_REDUCTION],
            "tech_debt": distribution[ImpactCategory.TECH_DEBT],
            "unknown": distribution[ImpactCategory.UNKNOWN],
        },
        "percentages": {
            "revenue_driving": round(distribution[ImpactCategory.REVENUE_DRIVING] / total * 100, 1) if total > 0 else 0,
            "risk_reduction": round(distribution[ImpactCategory.RISK_REDUCTION] / total * 100, 1) if total > 0 else 0,
            "tech_debt": round(distribution[ImpactCategory.TECH_DEBT] / total * 100, 1) if total > 0 else 0,
            "unknown": round(distribution[ImpactCategory.UNKNOWN] / total * 100, 1) if total > 0 else 0,
        },
    }

