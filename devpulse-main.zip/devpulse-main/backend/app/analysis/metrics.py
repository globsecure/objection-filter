from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from typing import List, Dict
from datetime import datetime, timedelta
from ..models import Commit


def calculate_code_churn(db: Session, start_date: datetime = None, end_date: datetime = None) -> List[Dict]:
    """
    Calculate code churn over time.
    Code churn = (insertions + deletions) / total_lines
    """
    query = db.query(
        func.date(Commit.date).label('date'),
        func.sum(Commit.insertions + Commit.deletions).label('total_changes'),
        func.sum(Commit.insertions).label('total_insertions'),
        func.sum(Commit.deletions).label('total_deletions'),
        func.count(Commit.id).label('commit_count')
    ).group_by(func.date(Commit.date))
    
    if start_date:
        query = query.filter(Commit.date >= start_date)
    if end_date:
        query = query.filter(Commit.date <= end_date)
    
    results = query.order_by('date').all()
    
    return [
        {
            'date': row.date.isoformat() if isinstance(row.date, datetime) else str(row.date),
            'total_changes': row.total_changes or 0,
            'insertions': row.total_insertions or 0,
            'deletions': row.total_deletions or 0,
            'commit_count': row.commit_count or 0
        }
        for row in results
    ]


def calculate_consistency(db: Session, start_date: datetime = None, end_date: datetime = None) -> Dict:
    """
    Calculate delivery consistency metrics.
    """
    query = db.query(Commit)
    
    if start_date:
        query = query.filter(Commit.date >= start_date)
    if end_date:
        query = query.filter(Commit.date <= end_date)
    
    total_commits = query.count()
    
    if total_commits == 0:
        return {
            'total_commits': 0,
            'commits_per_week': 0,
            'commits_per_month': 0,
            'weeks_active': 0
        }
    
    first_commit = query.order_by(Commit.date.asc()).first()
    last_commit = query.order_by(Commit.date.desc()).first()
    
    if not first_commit or not last_commit:
        return {
            'total_commits': total_commits,
            'commits_per_week': 0,
            'commits_per_month': 0,
            'weeks_active': 0
        }
    
    days_diff = (last_commit.date - first_commit.date).days
    weeks_active = max(1, days_diff / 7)
    months_active = max(1, days_diff / 30)
    
    return {
        'total_commits': total_commits,
        'commits_per_week': round(total_commits / weeks_active, 2),
        'commits_per_month': round(total_commits / months_active, 2),
        'weeks_active': round(weeks_active, 1),
        'first_commit': first_commit.date.isoformat(),
        'last_commit': last_commit.date.isoformat()
    }


def get_cross_team_impact(db: Session, start_date: datetime = None, end_date: datetime = None) -> List[Dict]:
    """
    Detect commits affecting shared/common/lib directories (cross-team impact).
    """
    query = db.query(Commit).filter(
        Commit.message.ilike('%shared%') |
        Commit.message.ilike('%common%') |
        Commit.message.ilike('%lib%') |
        Commit.message.ilike('%library%')
    )
    
    if start_date:
        query = query.filter(Commit.date >= start_date)
    if end_date:
        query = query.filter(Commit.date <= end_date)
    
    commits = query.order_by(Commit.date.desc()).limit(50).all()
    
    return [
        {
            'id': commit.id,
            'hash': commit.hash,
            'message': commit.message,
            'date': commit.date.isoformat(),
            'repo_id': commit.repo_id,
            'type': commit.type
        }
        for commit in commits
    ]

