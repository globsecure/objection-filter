from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Tuple
from datetime import datetime
import time
import logging
from sqlalchemy.orm import Session
from ..models import Commit, FrictionLog, ManualEntry
from ..config import settings
from ..services.llm_rate_limiter import LLMRateLimiter, RateLimitExceeded
from ..services.llm_cost_calculator import calculate_cost
from ..services.secret_detector import SecretDetector
from ..services.context_enrichment import ContextEnrichmentService

logger = logging.getLogger(__name__)


class LLMProvider(ABC):
    def __init__(self, enable_secret_detection: bool = True, redact_mode: bool = False):
        self.secret_detector = SecretDetector() if enable_secret_detection else None
        self.redact_mode = redact_mode
    
    def _sanitize_for_llm(self, text: str, redact: bool = False) -> Tuple[str, List[Dict]]:
        """
        Sanitize text before sending to LLM.
        
        Returns:
            Tuple of (sanitized_text, detected_secrets)
        """
        if not self.secret_detector:
            return text, []
        
        secrets = self.secret_detector.detect_secrets(text)
        
        if secrets:
            if redact:
                sanitized = self.secret_detector.redact_secrets(text)
            else:
                sanitized = text
            return sanitized, secrets
        
        return text, []
    
    def _check_secrets_before_send(self, text: str, raise_on_secret: bool = True) -> Tuple[str, List[Dict]]:
        """
        Check for secrets and optionally raise error or redact.
        
        Raises:
            ValueError if secrets detected and raise_on_secret=True and not in redact_mode
        """
        # If in redact mode, always redact instead of raising
        if self.redact_mode:
            sanitized, secrets = self._sanitize_for_llm(text, redact=True)
            return sanitized, secrets
        
        sanitized, secrets = self._sanitize_for_llm(text, redact=False)
        
        if secrets and raise_on_secret:
            secret_types = ', '.join(set(s['type'] for s in secrets))
            raise ValueError(
                f"Secrets detected in text: {secret_types}. "
                "Enable redaction or remove secrets before sending to LLM."
            )
        
        return sanitized, secrets
    
    @abstractmethod
    def summarize_commits(self, commits: List[Commit], start_date: Optional[datetime] = None, end_date: Optional[datetime] = None, db: Optional[Session] = None, user_id: str = "default") -> str:
        pass
    
    @abstractmethod
    def generate_weekly_summary(self, commits: List[Commit], impact_distribution: Dict, db: Optional[Session] = None, user_id: str = "default") -> str:
        pass
    
    @abstractmethod
    def generate_executive_summary(
        self,
        commits: List[Commit],
        friction_logs: List[FrictionLog],
        manual_entries: List[ManualEntry],
        start_date: datetime,
        end_date: datetime,
        db: Optional[Session] = None,
        user_id: str = "default"
    ) -> str:
        pass
    
    @abstractmethod
    def generate_challenges_section(
        self,
        friction_logs: List[FrictionLog],
        db: Optional[Session] = None,
        user_id: str = "default"
    ) -> str:
        pass
    
    @abstractmethod
    def generate_collaboration_section(
        self,
        manual_entries: List[ManualEntry],
        db: Optional[Session] = None,
        user_id: str = "default"
    ) -> str:
        pass


class OpenAIProvider(LLMProvider):
    def __init__(self, api_key: str, enable_secret_detection: bool = True, redact_mode: bool = False):
        super().__init__(enable_secret_detection, redact_mode)
        self.api_key = api_key
    
    def _get_client(self):
        import os
        from openai import OpenAI
        
        original_proxies = {}
        proxy_vars = ['HTTP_PROXY', 'HTTPS_PROXY', 'http_proxy', 'https_proxy', 'ALL_PROXY', 'all_proxy']
        for var in proxy_vars:
            if var in os.environ:
                original_proxies[var] = os.environ.pop(var)
        
        client = OpenAI(api_key=self.api_key, timeout=60.0)
        return client, original_proxies
    
    def _restore_proxies(self, original_proxies):
        import os
        os.environ.update(original_proxies)
    
    def summarize_commits(self, commits: List[Commit], start_date: Optional[datetime] = None, end_date: Optional[datetime] = None, db: Optional[Session] = None, user_id: str = "default") -> str:
        rate_limiter = None
        if db:
            rate_limiter = LLMRateLimiter(db)
        
        start_time = time.time()
        model_name = "gpt-3.5-turbo"
        provider = "openai"
        operation = "summarize_commits"
        
        try:
            client, original_proxies = self._get_client()
            
            try:
                commit_texts = []
                for commit in commits[:50]:
                    commit_message = commit.message[:100]
                    
                    # Check for secrets
                    try:
                        sanitized_message, secrets = self._check_secrets_before_send(
                            commit_message,
                            raise_on_secret=True  # Block by default
                        )
                        commit_texts.append(f"- {commit.type or 'Unknown'}: {sanitized_message}")
                    except ValueError as e:
                        # Log warning and skip this commit
                        logger.warning(f"Skipping commit {commit.hash[:8]}: {str(e)}")
                        continue
                
                # Add context enrichment
                context_prompt = ""
                if db:
                    context_service = ContextEnrichmentService(db)
                    context_prompt = context_service.build_context_prompt(
                        user_id=user_id,
                        start_date=start_date,
                        end_date=end_date
                    )
                
                date_context = ""
                if start_date and end_date:
                    date_context = f"Period: {start_date.strftime('%B %d, %Y')} to {end_date.strftime('%B %d, %Y')}\n\n"
                
                prompt = f"""{context_prompt}{date_context}Transform the following technical commits into a professional performance summary with impact-driven bullet points. Focus on business value and achievements rather than technical details.

Commits:
{chr(10).join(commit_texts)}

Generate 5-7 bullet points highlighting key achievements and impact:"""
                
                # Check rate limit
                if rate_limiter:
                    estimated_tokens = len(prompt) // 4
                    rate_limiter.check_rate_limit(provider, estimated_tokens)
                
                response = client.chat.completions.create(
                    model=model_name,
                    messages=[
                        {"role": "system", "content": "You are a professional performance review assistant. Transform technical commits into business impact statements."},
                        {"role": "user", "content": prompt}
                    ],
                    max_tokens=500,
                    temperature=0.7
                )
                
                # Log usage
                duration_ms = int((time.time() - start_time) * 1000)
                if rate_limiter:
                    input_tokens = response.usage.prompt_tokens
                    output_tokens = response.usage.completion_tokens
                    cost = calculate_cost(provider, model_name, input_tokens, output_tokens)
                    rate_limiter.log_usage(
                        provider=provider,
                        model=model_name,
                        operation=operation,
                        input_tokens=input_tokens,
                        output_tokens=output_tokens,
                        cost_usd=cost,
                        duration_ms=duration_ms,
                        success=True
                    )
                
                return response.choices[0].message.content.strip()
            finally:
                self._restore_proxies(original_proxies)
        except RateLimitExceeded as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error: Rate limit exceeded. Please try again later."
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error generating summary: {str(e)}"
    
    def generate_weekly_summary(self, commits: List[Commit], impact_distribution: Dict, db: Optional[Session] = None) -> str:
        rate_limiter = None
        if db:
            rate_limiter = LLMRateLimiter(db)
        
        start_time = time.time()
        model_name = "gpt-3.5-turbo"
        provider = "openai"
        operation = "generate_weekly_summary"
        
        try:
            client, original_proxies = self._get_client()
            
            try:
                commit_texts = []
                for commit in commits[:30]:
                    commit_message = commit.message[:80]
                    
                    # Check for secrets
                    try:
                        sanitized_message, secrets = self._check_secrets_before_send(
                            commit_message,
                            raise_on_secret=True
                        )
                        category = getattr(commit, 'impact_category', None) or 'Unknown'
                        commit_texts.append(f"- [{category}] {commit.type or 'Unknown'}: {sanitized_message}")
                    except ValueError as e:
                        logger.warning(f"Skipping commit {commit.hash[:8]}: {str(e)}")
                        continue
                
                # Add context enrichment
                context_prompt = ""
                if db:
                    context_service = ContextEnrichmentService(db)
                    context_prompt = context_service.build_context_prompt(user_id=user_id)
                
                impact_context = f"""Impact Distribution:
- Revenue-driving features: {impact_distribution.get('revenue_driving', 0)} commits
- Risk reduction (bugfixes): {impact_distribution.get('risk_reduction', 0)} commits
- Technical debt: {impact_distribution.get('tech_debt', 0)} commits
"""
                
                prompt = f"""{context_prompt}Generate a weekly performance summary for a manager review. The summary should start with a sentence like "This week, I focused on improving [System X], resulting in [Benefit Y]."

{impact_context}

Commits:
{chr(10).join(commit_texts)}

Generate a professional summary with:
1. Opening statement (1 sentence starting with "This week, I focused on...")
2. 3-5 bullet points of key achievements with business impact
3. Brief mention of areas for next week (optional)

Format for a manager review meeting:"""
                
                # Check rate limit
                if rate_limiter:
                    estimated_tokens = len(prompt) // 4
                    rate_limiter.check_rate_limit(provider, estimated_tokens)
                
                response = client.chat.completions.create(
                    model=model_name,
                    messages=[
                        {"role": "system", "content": "You are a professional performance review assistant creating summaries for 1:1 meetings with managers. Focus on business value, impact, and clear communication."},
                        {"role": "user", "content": prompt}
                    ],
                    max_tokens=600,
                    temperature=0.7
                )
                
                # Log usage
                duration_ms = int((time.time() - start_time) * 1000)
                if rate_limiter:
                    input_tokens = response.usage.prompt_tokens
                    output_tokens = response.usage.completion_tokens
                    cost = calculate_cost(provider, model_name, input_tokens, output_tokens)
                    rate_limiter.log_usage(
                        provider=provider,
                        model=model_name,
                        operation=operation,
                        input_tokens=input_tokens,
                        output_tokens=output_tokens,
                        cost_usd=cost,
                        duration_ms=duration_ms,
                        success=True
                    )
                
                return response.choices[0].message.content.strip()
            finally:
                self._restore_proxies(original_proxies)
        except RateLimitExceeded as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error: Rate limit exceeded. Please try again later."
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error generating weekly summary: {str(e)}"
    
    def generate_executive_summary(
        self,
        commits: List[Commit],
        friction_logs: List[FrictionLog],
        manual_entries: List[ManualEntry],
        start_date: datetime,
        end_date: datetime,
        db: Optional[Session] = None,
        user_id: str = "default"
    ) -> str:
        rate_limiter = None
        if db:
            rate_limiter = LLMRateLimiter(db)
        
        start_time = time.time()
        model_name = "gpt-3.5-turbo"
        provider = "openai"
        operation = "executive_summary"
        
        try:
            client, original_proxies = self._get_client()
            
            try:
                # Format commits
                commit_texts = []
                for commit in commits[:50]:
                    commit_message = commit.message[:100]
                    try:
                        sanitized_message, _ = self._check_secrets_before_send(commit_message, raise_on_secret=True)
                        commit_texts.append(f"- {commit.type or 'Unknown'}: {sanitized_message}")
                    except ValueError as e:
                        logger.warning(f"Skipping commit {commit.hash[:8]}: {str(e)}")
                        continue
                
                # Format friction logs
                friction_texts = []
                for friction in friction_logs[:20]:
                    friction_desc = friction.description[:80]
                    try:
                        sanitized_desc, _ = self._check_secrets_before_send(friction_desc, raise_on_secret=True)
                        friction_texts.append(
                            f"- [{friction.type}] {sanitized_desc} "
                            f"(Impact: {friction.impact_level}/5)"
                        )
                    except ValueError as e:
                        logger.warning(f"Skipping friction log {friction.id}: {str(e)}")
                        continue
                
                # Format manual entries
                manual_texts = []
                for entry in manual_entries[:20]:
                    entry_desc = entry.description[:80] if entry.description else 'N/A'
                    try:
                        sanitized_desc, _ = self._check_secrets_before_send(entry_desc, raise_on_secret=True)
                        manual_texts.append(
                            f"- [{entry.type}] {entry.title}: {sanitized_desc}"
                        )
                    except ValueError as e:
                        logger.warning(f"Skipping manual entry {entry.id}: {str(e)}")
                        continue
                
                # Add context enrichment
                context_prompt = ""
                if db:
                    context_service = ContextEnrichmentService(db)
                    context_prompt = context_service.build_context_prompt(
                        user_id=user_id,
                        start_date=start_date,
                        end_date=end_date
                    )
                
                prompt = f"""{context_prompt}Generate an executive summary for a performance review covering the period {start_date.strftime('%B %d, %Y')} to {end_date.strftime('%B %d, %Y')}.

Technical Work (Commits):
{chr(10).join(commit_texts[:30])}

Challenges & Growth (Friction Logs):
{chr(10).join(friction_texts[:15])}

Collaboration & Invisible Work (Manual Entries):
{chr(10).join(manual_texts[:15])}

Generate a 3-4 sentence executive summary that:
1. Highlights overall impact and achievements
2. Mentions key challenges overcome
3. Notes collaboration contributions
4. Uses professional, manager-friendly language

Focus on business value and outcomes, not technical details."""
                
                # Check rate limit
                if rate_limiter:
                    estimated_tokens = len(prompt) // 4
                    rate_limiter.check_rate_limit(provider, estimated_tokens)
                
                response = client.chat.completions.create(
                    model=model_name,
                    messages=[
                        {"role": "system", "content": "You are a professional performance review assistant. Create executive summaries that highlight business value and achievements."},
                        {"role": "user", "content": prompt}
                    ],
                    max_tokens=300,
                    temperature=0.7
                )
                
                # Log usage
                duration_ms = int((time.time() - start_time) * 1000)
                if rate_limiter:
                    input_tokens = response.usage.prompt_tokens
                    output_tokens = response.usage.completion_tokens
                    cost = calculate_cost(provider, model_name, input_tokens, output_tokens)
                    rate_limiter.log_usage(
                        provider=provider,
                        model=model_name,
                        operation=operation,
                        input_tokens=input_tokens,
                        output_tokens=output_tokens,
                        cost_usd=cost,
                        duration_ms=duration_ms,
                        success=True
                    )
                
                return response.choices[0].message.content.strip()
            finally:
                self._restore_proxies(original_proxies)
        except RateLimitExceeded as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error: Rate limit exceeded. Please try again later."
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error generating executive summary: {str(e)}"
    
    def generate_challenges_section(
        self,
        friction_logs: List[FrictionLog],
        db: Optional[Session] = None,
        user_id: str = "default"
    ) -> str:
        rate_limiter = None
        if db:
            rate_limiter = LLMRateLimiter(db)
        
        start_time = time.time()
        model_name = "gpt-3.5-turbo"
        provider = "openai"
        operation = "challenges"
        
        try:
            client, original_proxies = self._get_client()
            
            try:
                blockers = [f for f in friction_logs if f.type == 'blocker']
                incidents = [f for f in friction_logs if f.type == 'incident']
                learnings = [f for f in friction_logs if f.type == 'learning']
                
                friction_texts = []
                for friction in blockers + incidents + learnings[:15]:
                    friction_desc = friction.description[:100]
                    try:
                        sanitized_desc, _ = self._check_secrets_before_send(friction_desc, raise_on_secret=True)
                        resolution_text = f" → Resolved: {friction.resolution}" if friction.resolution else ""
                        friction_texts.append(
                            f"- [{friction.type.upper()}] {sanitized_desc} "
                            f"(Impact: {friction.impact_level}/5){resolution_text}"
                        )
                    except ValueError as e:
                        logger.warning(f"Skipping friction log {friction.id}: {str(e)}")
                        continue
                
                # Add context enrichment
                context_prompt = ""
                if db:
                    context_service = ContextEnrichmentService(db)
                    context_prompt = context_service.build_context_prompt(user_id=user_id)
                
                prompt = f"""{context_prompt}Transform the following friction logs into a "Challenges & Growth" section for a performance review.

Friction Logs:
{chr(10).join(friction_texts)}

Generate 3-5 bullet points that:
1. Frame challenges as growth opportunities
2. Highlight problem-solving skills
3. Show how challenges were overcome
4. Emphasize learning and adaptation

Format: Professional, positive tone, focus on outcomes."""
                
                # Check rate limit
                if rate_limiter:
                    estimated_tokens = len(prompt) // 4
                    rate_limiter.check_rate_limit(provider, estimated_tokens)
                
                response = client.chat.completions.create(
                    model=model_name,
                    messages=[
                        {"role": "system", "content": "You are a professional performance review assistant. Transform challenges into growth narratives that highlight problem-solving and learning."},
                        {"role": "user", "content": prompt}
                    ],
                    max_tokens=400,
                    temperature=0.7
                )
                
                # Log usage
                duration_ms = int((time.time() - start_time) * 1000)
                if rate_limiter:
                    input_tokens = response.usage.prompt_tokens
                    output_tokens = response.usage.completion_tokens
                    cost = calculate_cost(provider, model_name, input_tokens, output_tokens)
                    rate_limiter.log_usage(
                        provider=provider,
                        model=model_name,
                        operation=operation,
                        input_tokens=input_tokens,
                        output_tokens=output_tokens,
                        cost_usd=cost,
                        duration_ms=duration_ms,
                        success=True
                    )
                
                return response.choices[0].message.content.strip()
            finally:
                self._restore_proxies(original_proxies)
        except RateLimitExceeded as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error: Rate limit exceeded. Please try again later."
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error generating challenges section: {str(e)}"
    
    def generate_collaboration_section(
        self,
        manual_entries: List[ManualEntry],
        db: Optional[Session] = None,
        user_id: str = "default"
    ) -> str:
        rate_limiter = None
        if db:
            rate_limiter = LLMRateLimiter(db)
        
        start_time = time.time()
        model_name = "gpt-3.5-turbo"
        provider = "openai"
        operation = "collaboration"
        
        try:
            client, original_proxies = self._get_client()
            
            try:
                code_reviews = [e for e in manual_entries if e.type == 'code_review']
                design_docs = [e for e in manual_entries if e.type == 'design_doc']
                mentoring = [e for e in manual_entries if e.type == 'mentoring']
                
                entry_texts = []
                for entry in code_reviews + design_docs + mentoring[:20]:
                    entry_desc = entry.description[:80] if entry.description else 'N/A'
                    try:
                        sanitized_desc, _ = self._check_secrets_before_send(entry_desc, raise_on_secret=True)
                        collaborators_text = f" with {entry.collaborators}" if entry.collaborators else ""
                        entry_texts.append(
                            f"- [{entry.type}] {entry.title}{collaborators_text}: {sanitized_desc}"
                        )
                    except ValueError as e:
                        logger.warning(f"Skipping manual entry {entry.id}: {str(e)}")
                        continue
                
                # Add context enrichment
                context_prompt = ""
                if db:
                    context_service = ContextEnrichmentService(db)
                    context_prompt = context_service.build_context_prompt(user_id=user_id)
                
                prompt = f"""{context_prompt}Transform the following collaboration activities into a "Collaboration Highlights" section.

Activities:
{chr(10).join(entry_texts)}

Generate 3-5 bullet points that:
1. Highlight teamwork and knowledge sharing
2. Show cross-functional contributions
3. Emphasize impact on team/org
4. Use specific examples with context

Format: Professional, emphasize collective impact."""
                
                # Check rate limit
                if rate_limiter:
                    estimated_tokens = len(prompt) // 4
                    rate_limiter.check_rate_limit(provider, estimated_tokens)
                
                response = client.chat.completions.create(
                    model=model_name,
                    messages=[
                        {"role": "system", "content": "You are a professional performance review assistant. Highlight collaboration and teamwork contributions."},
                        {"role": "user", "content": prompt}
                    ],
                    max_tokens=400,
                    temperature=0.7
                )
                
                # Log usage
                duration_ms = int((time.time() - start_time) * 1000)
                if rate_limiter:
                    input_tokens = response.usage.prompt_tokens
                    output_tokens = response.usage.completion_tokens
                    cost = calculate_cost(provider, model_name, input_tokens, output_tokens)
                    rate_limiter.log_usage(
                        provider=provider,
                        model=model_name,
                        operation=operation,
                        input_tokens=input_tokens,
                        output_tokens=output_tokens,
                        cost_usd=cost,
                        duration_ms=duration_ms,
                        success=True
                    )
                
                return response.choices[0].message.content.strip()
            finally:
                self._restore_proxies(original_proxies)
        except RateLimitExceeded as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error: Rate limit exceeded. Please try again later."
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error generating collaboration section: {str(e)}"


class GeminiProvider(LLMProvider):
    def __init__(self, api_key: str, enable_secret_detection: bool = True, redact_mode: bool = False):
        super().__init__(enable_secret_detection, redact_mode)
        self.api_key = api_key
    
    def summarize_commits(self, commits: List[Commit], start_date: Optional[datetime] = None, end_date: Optional[datetime] = None, db: Optional[Session] = None, user_id: str = "default") -> str:
        rate_limiter = None
        if db:
            rate_limiter = LLMRateLimiter(db)
        
        start_time = time.time()
        model_name = "gemini-pro"
        provider = "gemini"
        operation = "summarize_commits"
        
        try:
            import google.generativeai as genai
            genai.configure(api_key=self.api_key)
            
            commit_texts = []
            for commit in commits[:50]:
                commit_message = commit.message[:100]
                try:
                    sanitized_message, secrets = self._check_secrets_before_send(
                        commit_message,
                        raise_on_secret=True
                    )
                    commit_texts.append(f"- {commit.type or 'Unknown'}: {sanitized_message}")
                except ValueError as e:
                    logger.warning(f"Skipping commit {commit.hash[:8]}: {str(e)}")
                    continue
            
            # Add context enrichment
            context_prompt = ""
            if db:
                context_service = ContextEnrichmentService(db)
                context_prompt = context_service.build_context_prompt(
                    user_id=user_id,
                    start_date=start_date,
                    end_date=end_date
                )
            
            date_context = ""
            if start_date and end_date:
                date_context = f"Period: {start_date.strftime('%B %d, %Y')} to {end_date.strftime('%B %d, %Y')}\n\n"
            
            prompt = f"""{context_prompt}{date_context}Transform the following technical commits into a professional performance summary with impact-driven bullet points. Focus on business value and achievements rather than technical details.

Commits:
{chr(10).join(commit_texts)}

Generate 5-7 bullet points highlighting key achievements and impact:"""
            
            # Check rate limit
            if rate_limiter:
                estimated_tokens = len(prompt) // 4
                rate_limiter.check_rate_limit(provider, estimated_tokens)
            
            model = genai.GenerativeModel(model_name)
            response = model.generate_content(prompt)
            
            # Estimate tokens (Gemini doesn't provide usage info)
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                estimated_input_tokens = len(prompt) // 4
                estimated_output_tokens = len(response.text) // 4
                cost = calculate_cost(provider, model_name, estimated_input_tokens, estimated_output_tokens)
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=estimated_input_tokens,
                    output_tokens=estimated_output_tokens,
                    cost_usd=cost,
                    duration_ms=duration_ms,
                    success=True
                )
            
            return response.text.strip()
        except RateLimitExceeded as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error: Rate limit exceeded. Please try again later."
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error generating summary: {str(e)}"
    
    def generate_weekly_summary(self, commits: List[Commit], impact_distribution: Dict, db: Optional[Session] = None, user_id: str = "default") -> str:
        rate_limiter = None
        if db:
            rate_limiter = LLMRateLimiter(db)
        
        start_time = time.time()
        model_name = "gemini-pro"
        provider = "gemini"
        operation = "generate_weekly_summary"
        
        try:
            import google.generativeai as genai
            genai.configure(api_key=self.api_key)
            
            commit_texts = []
            for commit in commits[:30]:
                commit_message = commit.message[:80]
                try:
                    sanitized_message, secrets = self._check_secrets_before_send(
                        commit_message,
                        raise_on_secret=True
                    )
                    category = getattr(commit, 'impact_category', None) or 'Unknown'
                    commit_texts.append(f"- [{category}] {commit.type or 'Unknown'}: {sanitized_message}")
                except ValueError as e:
                    logger.warning(f"Skipping commit {commit.hash[:8]}: {str(e)}")
                    continue
            
            # Add context enrichment
            context_prompt = ""
            if db:
                context_service = ContextEnrichmentService(db)
                context_prompt = context_service.build_context_prompt(user_id=user_id)
            
            impact_context = f"""Impact Distribution:
- Revenue-driving features: {impact_distribution.get('revenue_driving', 0)} commits
- Risk reduction (bugfixes): {impact_distribution.get('risk_reduction', 0)} commits
- Technical debt: {impact_distribution.get('tech_debt', 0)} commits
"""
            
            prompt = f"""{context_prompt}Generate a weekly performance summary for a manager review. The summary should start with a sentence like "This week, I focused on improving [System X], resulting in [Benefit Y]."

{impact_context}

Commits:
{chr(10).join(commit_texts)}

Generate a professional summary with:
1. Opening statement (1 sentence starting with "This week, I focused on...")
2. 3-5 bullet points of key achievements with business impact
3. Brief mention of areas for next week (optional)

Format for a manager review meeting:"""
            
            # Check rate limit
            if rate_limiter:
                estimated_tokens = len(prompt) // 4
                rate_limiter.check_rate_limit(provider, estimated_tokens)
            
            model = genai.GenerativeModel(model_name)
            response = model.generate_content(prompt)
            
            # Estimate tokens (Gemini doesn't provide usage info)
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                estimated_input_tokens = len(prompt) // 4
                estimated_output_tokens = len(response.text) // 4
                cost = calculate_cost(provider, model_name, estimated_input_tokens, estimated_output_tokens)
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=estimated_input_tokens,
                    output_tokens=estimated_output_tokens,
                    cost_usd=cost,
                    duration_ms=duration_ms,
                    success=True
                )
            
            return response.text.strip()
        except RateLimitExceeded as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error: Rate limit exceeded. Please try again later."
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error generating weekly summary: {str(e)}"
    
    def generate_executive_summary(
        self,
        commits: List[Commit],
        friction_logs: List[FrictionLog],
        manual_entries: List[ManualEntry],
        start_date: datetime,
        end_date: datetime,
        db: Optional[Session] = None,
        user_id: str = "default"
    ) -> str:
        rate_limiter = None
        if db:
            rate_limiter = LLMRateLimiter(db)
        
        start_time = time.time()
        model_name = "gemini-pro"
        provider = "gemini"
        operation = "executive_summary"
        
        try:
            import google.generativeai as genai
            genai.configure(api_key=self.api_key)
            
            # Format commits
            commit_texts = []
            for commit in commits[:50]:
                commit_message = commit.message[:100]
                try:
                    sanitized_message, _ = self._check_secrets_before_send(commit_message, raise_on_secret=True)
                    commit_texts.append(f"- {commit.type or 'Unknown'}: {sanitized_message}")
                except ValueError as e:
                    logger.warning(f"Skipping commit {commit.hash[:8]}: {str(e)}")
                    continue
            
            # Format friction logs
            friction_texts = []
            for friction in friction_logs[:20]:
                friction_desc = friction.description[:80]
                try:
                    sanitized_desc, _ = self._check_secrets_before_send(friction_desc, raise_on_secret=True)
                    friction_texts.append(
                        f"- [{friction.type}] {sanitized_desc} "
                        f"(Impact: {friction.impact_level}/5)"
                    )
                except ValueError as e:
                    logger.warning(f"Skipping friction log {friction.id}: {str(e)}")
                    continue
            
            # Format manual entries
            manual_texts = []
            for entry in manual_entries[:20]:
                entry_desc = entry.description[:80] if entry.description else 'N/A'
                try:
                    sanitized_desc, _ = self._check_secrets_before_send(entry_desc, raise_on_secret=True)
                    manual_texts.append(
                        f"- [{entry.type}] {entry.title}: {sanitized_desc}"
                    )
                except ValueError as e:
                    logger.warning(f"Skipping manual entry {entry.id}: {str(e)}")
                    continue
            
            # Add context enrichment
            context_prompt = ""
            if db:
                context_service = ContextEnrichmentService(db)
                context_prompt = context_service.build_context_prompt(
                    user_id=user_id,
                    start_date=start_date,
                    end_date=end_date
                )
            
            prompt = f"""{context_prompt}Generate an executive summary for a performance review covering the period {start_date.strftime('%B %d, %Y')} to {end_date.strftime('%B %d, %Y')}.

Technical Work (Commits):
{chr(10).join(commit_texts[:30])}

Challenges & Growth (Friction Logs):
{chr(10).join(friction_texts[:15])}

Collaboration & Invisible Work (Manual Entries):
{chr(10).join(manual_texts[:15])}

Generate a 3-4 sentence executive summary that:
1. Highlights overall impact and achievements
2. Mentions key challenges overcome
3. Notes collaboration contributions
4. Uses professional, manager-friendly language

Focus on business value and outcomes, not technical details."""
            
            # Check rate limit
            if rate_limiter:
                estimated_tokens = len(prompt) // 4
                rate_limiter.check_rate_limit(provider, estimated_tokens)
            
            model = genai.GenerativeModel(model_name)
            response = model.generate_content(prompt)
            
            # Estimate tokens (Gemini doesn't provide usage info)
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                estimated_input_tokens = len(prompt) // 4
                estimated_output_tokens = len(response.text) // 4
                cost = calculate_cost(provider, model_name, estimated_input_tokens, estimated_output_tokens)
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=estimated_input_tokens,
                    output_tokens=estimated_output_tokens,
                    cost_usd=cost,
                    duration_ms=duration_ms,
                    success=True
                )
            
            return response.text.strip()
        except RateLimitExceeded as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error: Rate limit exceeded. Please try again later."
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error generating executive summary: {str(e)}"
    
    def generate_challenges_section(
        self,
        friction_logs: List[FrictionLog],
        db: Optional[Session] = None,
        user_id: str = "default"
    ) -> str:
        rate_limiter = None
        if db:
            rate_limiter = LLMRateLimiter(db)
        
        start_time = time.time()
        model_name = "gemini-pro"
        provider = "gemini"
        operation = "challenges"
        
        try:
            import google.generativeai as genai
            genai.configure(api_key=self.api_key)
            
            blockers = [f for f in friction_logs if f.type == 'blocker']
            incidents = [f for f in friction_logs if f.type == 'incident']
            learnings = [f for f in friction_logs if f.type == 'learning']
            
            friction_texts = []
            for friction in blockers + incidents + learnings[:15]:
                friction_desc = friction.description[:100]
                try:
                    sanitized_desc, _ = self._check_secrets_before_send(friction_desc, raise_on_secret=True)
                    resolution_text = f" → Resolved: {friction.resolution}" if friction.resolution else ""
                    friction_texts.append(
                        f"- [{friction.type.upper()}] {sanitized_desc} "
                        f"(Impact: {friction.impact_level}/5){resolution_text}"
                    )
                except ValueError as e:
                    logger.warning(f"Skipping friction log {friction.id}: {str(e)}")
                    continue
            
            # Add context enrichment
            context_prompt = ""
            if db:
                context_service = ContextEnrichmentService(db)
                context_prompt = context_service.build_context_prompt(user_id=user_id)
            
            prompt = f"""{context_prompt}Transform the following friction logs into a "Challenges & Growth" section for a performance review.

Friction Logs:
{chr(10).join(friction_texts)}

Generate 3-5 bullet points that:
1. Frame challenges as growth opportunities
2. Highlight problem-solving skills
3. Show how challenges were overcome
4. Emphasize learning and adaptation

Format: Professional, positive tone, focus on outcomes."""
            
            # Check rate limit
            if rate_limiter:
                estimated_tokens = len(prompt) // 4
                rate_limiter.check_rate_limit(provider, estimated_tokens)
            
            model = genai.GenerativeModel(model_name)
            response = model.generate_content(prompt)
            
            # Estimate tokens (Gemini doesn't provide usage info)
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                estimated_input_tokens = len(prompt) // 4
                estimated_output_tokens = len(response.text) // 4
                cost = calculate_cost(provider, model_name, estimated_input_tokens, estimated_output_tokens)
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=estimated_input_tokens,
                    output_tokens=estimated_output_tokens,
                    cost_usd=cost,
                    duration_ms=duration_ms,
                    success=True
                )
            
            return response.text.strip()
        except RateLimitExceeded as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error: Rate limit exceeded. Please try again later."
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error generating challenges section: {str(e)}"
    
    def generate_collaboration_section(
        self,
        manual_entries: List[ManualEntry],
        db: Optional[Session] = None,
        user_id: str = "default"
    ) -> str:
        rate_limiter = None
        if db:
            rate_limiter = LLMRateLimiter(db)
        
        start_time = time.time()
        model_name = "gemini-pro"
        provider = "gemini"
        operation = "collaboration"
        
        try:
            import google.generativeai as genai
            genai.configure(api_key=self.api_key)
            
            code_reviews = [e for e in manual_entries if e.type == 'code_review']
            design_docs = [e for e in manual_entries if e.type == 'design_doc']
            mentoring = [e for e in manual_entries if e.type == 'mentoring']
            
            entry_texts = []
            for entry in code_reviews + design_docs + mentoring[:20]:
                entry_desc = entry.description[:80] if entry.description else 'N/A'
                try:
                    sanitized_desc, _ = self._check_secrets_before_send(entry_desc, raise_on_secret=True)
                    collaborators_text = f" with {entry.collaborators}" if entry.collaborators else ""
                    entry_texts.append(
                        f"- [{entry.type}] {entry.title}{collaborators_text}: {sanitized_desc}"
                    )
                except ValueError as e:
                    logger.warning(f"Skipping manual entry {entry.id}: {str(e)}")
                    continue
            
            # Add context enrichment
            context_prompt = ""
            if db:
                context_service = ContextEnrichmentService(db)
                context_prompt = context_service.build_context_prompt(user_id=user_id)
            
            prompt = f"""{context_prompt}Transform the following collaboration activities into a "Collaboration Highlights" section.

Activities:
{chr(10).join(entry_texts)}

Generate 3-5 bullet points that:
1. Highlight teamwork and knowledge sharing
2. Show cross-functional contributions
3. Emphasize impact on team/org
4. Use specific examples with context

Format: Professional, emphasize collective impact."""
            
            # Check rate limit
            if rate_limiter:
                estimated_tokens = len(prompt) // 4
                rate_limiter.check_rate_limit(provider, estimated_tokens)
            
            model = genai.GenerativeModel(model_name)
            response = model.generate_content(prompt)
            
            # Estimate tokens (Gemini doesn't provide usage info)
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                estimated_input_tokens = len(prompt) // 4
                estimated_output_tokens = len(response.text) // 4
                cost = calculate_cost(provider, model_name, estimated_input_tokens, estimated_output_tokens)
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=estimated_input_tokens,
                    output_tokens=estimated_output_tokens,
                    cost_usd=cost,
                    duration_ms=duration_ms,
                    success=True
                )
            
            return response.text.strip()
        except RateLimitExceeded as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error: Rate limit exceeded. Please try again later."
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error generating collaboration section: {str(e)}"


class OllamaProvider(LLMProvider):
    def __init__(self, base_url: str = "http://localhost:11434", model: str = "llama2", enable_secret_detection: bool = True, redact_mode: bool = False):
        super().__init__(enable_secret_detection, redact_mode)
        self.base_url = base_url
        self.model = model
    
    def _get_client(self):
        import httpx
        return httpx.Client(base_url=self.base_url, timeout=120.0)
    
    def summarize_commits(self, commits: List[Commit], start_date: Optional[datetime] = None, end_date: Optional[datetime] = None, db: Optional[Session] = None, user_id: str = "default") -> str:
        rate_limiter = None
        if db:
            rate_limiter = LLMRateLimiter(db)
        
        start_time = time.time()
        model_name = self.model
        provider = "ollama"
        operation = "summarize_commits"
        
        try:
            client = self._get_client()
            
            commit_texts = []
            for commit in commits[:50]:
                commit_message = commit.message[:100]
                try:
                    sanitized_message, secrets = self._check_secrets_before_send(
                        commit_message,
                        raise_on_secret=True
                    )
                    commit_texts.append(f"- {commit.type or 'Unknown'}: {sanitized_message}")
                except ValueError as e:
                    logger.warning(f"Skipping commit {commit.hash[:8]}: {str(e)}")
                    continue
            
            # Add context enrichment
            context_prompt = ""
            if db:
                context_service = ContextEnrichmentService(db)
                context_prompt = context_service.build_context_prompt(
                    user_id=user_id,
                    start_date=start_date,
                    end_date=end_date
                )
            
            date_context = ""
            if start_date and end_date:
                date_context = f"Period: {start_date.strftime('%B %d, %Y')} to {end_date.strftime('%B %d, %Y')}\n\n"
            
            prompt = f"""{context_prompt}{date_context}Transform the following technical commits into a professional performance summary with impact-driven bullet points. Focus on business value and achievements rather than technical details.

Commits:
{chr(10).join(commit_texts)}

Generate 5-7 bullet points highlighting key achievements and impact:"""
            
            # Check rate limit
            if rate_limiter:
                estimated_tokens = len(prompt) // 4
                try:
                    rate_limiter.check_rate_limit(provider, estimated_tokens)
                except RateLimitExceeded:
                    pass  # Ollama doesn't have rate limits, but we track usage
            
            response = client.post(
                "/api/generate",
                json={
                    "model": model_name,
                    "prompt": prompt,
                    "stream": False
                }
            )
            
            if response.status_code == 200:
                result = response.json()
                response_text = result.get("response", "Error generating summary")
                
                # Log usage
                duration_ms = int((time.time() - start_time) * 1000)
                if rate_limiter:
                    estimated_input_tokens = len(prompt) // 4
                    estimated_output_tokens = len(response_text) // 4
                    cost = calculate_cost(provider, model_name, estimated_input_tokens, estimated_output_tokens)
                    rate_limiter.log_usage(
                        provider=provider,
                        model=model_name,
                        operation=operation,
                        input_tokens=estimated_input_tokens,
                        output_tokens=estimated_output_tokens,
                        cost_usd=cost,
                        duration_ms=duration_ms,
                        success=True
                    )
                
                return response_text
            else:
                raise Exception(f"Ollama API error: {response.status_code}")
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error generating summary: {str(e)}"
    
    def generate_weekly_summary(self, commits: List[Commit], impact_distribution: Dict, db: Optional[Session] = None, user_id: str = "default") -> str:
        rate_limiter = None
        if db:
            rate_limiter = LLMRateLimiter(db)
        
        start_time = time.time()
        model_name = self.model
        provider = "ollama"
        operation = "generate_weekly_summary"
        
        try:
            client = self._get_client()
            
            commit_texts = []
            for commit in commits[:30]:
                commit_message = commit.message[:80]
                try:
                    sanitized_message, secrets = self._check_secrets_before_send(
                        commit_message,
                        raise_on_secret=True
                    )
                    category = getattr(commit, 'impact_category', None) or 'Unknown'
                    commit_texts.append(f"- [{category}] {commit.type or 'Unknown'}: {sanitized_message}")
                except ValueError as e:
                    logger.warning(f"Skipping commit {commit.hash[:8]}: {str(e)}")
                    continue
            
            # Add context enrichment
            context_prompt = ""
            if db:
                context_service = ContextEnrichmentService(db)
                context_prompt = context_service.build_context_prompt(user_id=user_id)
            
            impact_context = f"""Impact Distribution:
- Revenue-driving features: {impact_distribution.get('revenue_driving', 0)} commits
- Risk reduction (bugfixes): {impact_distribution.get('risk_reduction', 0)} commits
- Technical debt: {impact_distribution.get('tech_debt', 0)} commits
"""
            
            prompt = f"""{context_prompt}Generate a weekly performance summary for a manager review. The summary should start with a sentence like "This week, I focused on improving [System X], resulting in [Benefit Y]."

{impact_context}

Commits:
{chr(10).join(commit_texts)}

Generate a professional summary with:
1. Opening statement (1 sentence starting with "This week, I focused on...")
2. 3-5 bullet points of key achievements with business impact
3. Brief mention of areas for next week (optional)

Format for a manager review meeting:"""
            
            if rate_limiter:
                estimated_tokens = len(prompt) // 4
                try:
                    rate_limiter.check_rate_limit(provider, estimated_tokens)
                except RateLimitExceeded:
                    pass
            
            response = client.post(
                "/api/generate",
                json={
                    "model": model_name,
                    "prompt": prompt,
                    "stream": False
                }
            )
            
            if response.status_code == 200:
                result = response.json()
                response_text = result.get("response", "Error generating summary")
                
                duration_ms = int((time.time() - start_time) * 1000)
                if rate_limiter:
                    estimated_input_tokens = len(prompt) // 4
                    estimated_output_tokens = len(response_text) // 4
                    cost = calculate_cost(provider, model_name, estimated_input_tokens, estimated_output_tokens)
                    rate_limiter.log_usage(
                        provider=provider,
                        model=model_name,
                        operation=operation,
                        input_tokens=estimated_input_tokens,
                        output_tokens=estimated_output_tokens,
                        cost_usd=cost,
                        duration_ms=duration_ms,
                        success=True
                    )
                
                return response_text
            else:
                raise Exception(f"Ollama API error: {response.status_code}")
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error generating weekly summary: {str(e)}"
    
    def generate_executive_summary(
        self,
        commits: List[Commit],
        friction_logs: List[FrictionLog],
        manual_entries: List[ManualEntry],
        start_date: datetime,
        end_date: datetime,
        db: Optional[Session] = None,
        user_id: str = "default"
    ) -> str:
        rate_limiter = None
        if db:
            rate_limiter = LLMRateLimiter(db)
        
        start_time = time.time()
        model_name = self.model
        provider = "ollama"
        operation = "executive_summary"
        
        try:
            client = self._get_client()
            
            commit_texts = []
            for commit in commits[:50]:
                commit_message = commit.message[:100]
                try:
                    sanitized_message, _ = self._check_secrets_before_send(commit_message, raise_on_secret=True)
                    commit_texts.append(f"- {commit.type or 'Unknown'}: {sanitized_message}")
                except ValueError as e:
                    logger.warning(f"Skipping commit {commit.hash[:8]}: {str(e)}")
                    continue
            
            friction_texts = []
            for friction in friction_logs[:20]:
                friction_desc = friction.description[:80]
                try:
                    sanitized_desc, _ = self._check_secrets_before_send(friction_desc, raise_on_secret=True)
                    friction_texts.append(
                        f"- [{friction.type}] {sanitized_desc} "
                        f"(Impact: {friction.impact_level}/5)"
                    )
                except ValueError as e:
                    logger.warning(f"Skipping friction log {friction.id}: {str(e)}")
                    continue
            
            manual_texts = []
            for entry in manual_entries[:20]:
                entry_desc = entry.description[:80] if entry.description else 'N/A'
                try:
                    sanitized_desc, _ = self._check_secrets_before_send(entry_desc, raise_on_secret=True)
                    manual_texts.append(
                        f"- [{entry.type}] {entry.title}: {sanitized_desc}"
                    )
                except ValueError as e:
                    logger.warning(f"Skipping manual entry {entry.id}: {str(e)}")
                    continue
            
            # Add context enrichment
            context_prompt = ""
            if db:
                context_service = ContextEnrichmentService(db)
                context_prompt = context_service.build_context_prompt(
                    user_id=user_id,
                    start_date=start_date,
                    end_date=end_date
                )
            
            prompt = f"""{context_prompt}Generate an executive summary for a performance review covering the period {start_date.strftime('%B %d, %Y')} to {end_date.strftime('%B %d, %Y')}.

Technical Work (Commits):
{chr(10).join(commit_texts[:30])}

Challenges & Growth (Friction Logs):
{chr(10).join(friction_texts[:15])}

Collaboration & Invisible Work (Manual Entries):
{chr(10).join(manual_texts[:15])}

Generate a 3-4 sentence executive summary that:
1. Highlights overall impact and achievements
2. Mentions key challenges overcome
3. Notes collaboration contributions
4. Uses professional, manager-friendly language

Focus on business value and outcomes, not technical details."""
            
            if rate_limiter:
                estimated_tokens = len(prompt) // 4
                try:
                    rate_limiter.check_rate_limit(provider, estimated_tokens)
                except RateLimitExceeded:
                    pass
            
            response = client.post(
                "/api/generate",
                json={
                    "model": model_name,
                    "prompt": prompt,
                    "stream": False
                }
            )
            
            if response.status_code == 200:
                result = response.json()
                response_text = result.get("response", "Error generating summary")
                
                duration_ms = int((time.time() - start_time) * 1000)
                if rate_limiter:
                    estimated_input_tokens = len(prompt) // 4
                    estimated_output_tokens = len(response_text) // 4
                    cost = calculate_cost(provider, model_name, estimated_input_tokens, estimated_output_tokens)
                    rate_limiter.log_usage(
                        provider=provider,
                        model=model_name,
                        operation=operation,
                        input_tokens=estimated_input_tokens,
                        output_tokens=estimated_output_tokens,
                        cost_usd=cost,
                        duration_ms=duration_ms,
                        success=True
                    )
                
                return response_text
            else:
                raise Exception(f"Ollama API error: {response.status_code}")
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error generating executive summary: {str(e)}"
    
    def generate_challenges_section(
        self,
        friction_logs: List[FrictionLog],
        db: Optional[Session] = None,
        user_id: str = "default"
    ) -> str:
        rate_limiter = None
        if db:
            rate_limiter = LLMRateLimiter(db)
        
        start_time = time.time()
        model_name = self.model
        provider = "ollama"
        operation = "challenges"
        
        try:
            client = self._get_client()
            
            blockers = [f for f in friction_logs if f.type == 'blocker']
            incidents = [f for f in friction_logs if f.type == 'incident']
            learnings = [f for f in friction_logs if f.type == 'learning']
            
            friction_texts = []
            for friction in blockers + incidents + learnings[:15]:
                friction_desc = friction.description[:100]
                try:
                    sanitized_desc, _ = self._check_secrets_before_send(friction_desc, raise_on_secret=True)
                    resolution_text = f" → Resolved: {friction.resolution}" if friction.resolution else ""
                    friction_texts.append(
                        f"- [{friction.type.upper()}] {sanitized_desc} "
                        f"(Impact: {friction.impact_level}/5){resolution_text}"
                    )
                except ValueError as e:
                    logger.warning(f"Skipping friction log {friction.id}: {str(e)}")
                    continue
            
            # Add context enrichment
            context_prompt = ""
            if db:
                context_service = ContextEnrichmentService(db)
                context_prompt = context_service.build_context_prompt(user_id=user_id)
            
            prompt = f"""{context_prompt}Transform the following friction logs into a "Challenges & Growth" section for a performance review.

Friction Logs:
{chr(10).join(friction_texts)}

Generate 3-5 bullet points that:
1. Frame challenges as growth opportunities
2. Highlight problem-solving skills
3. Show how challenges were overcome
4. Emphasize learning and adaptation

Format: Professional, positive tone, focus on outcomes."""
            
            if rate_limiter:
                estimated_tokens = len(prompt) // 4
                try:
                    rate_limiter.check_rate_limit(provider, estimated_tokens)
                except RateLimitExceeded:
                    pass
            
            response = client.post(
                "/api/generate",
                json={
                    "model": model_name,
                    "prompt": prompt,
                    "stream": False
                }
            )
            
            if response.status_code == 200:
                result = response.json()
                response_text = result.get("response", "Error generating summary")
                
                duration_ms = int((time.time() - start_time) * 1000)
                if rate_limiter:
                    estimated_input_tokens = len(prompt) // 4
                    estimated_output_tokens = len(response_text) // 4
                    cost = calculate_cost(provider, model_name, estimated_input_tokens, estimated_output_tokens)
                    rate_limiter.log_usage(
                        provider=provider,
                        model=model_name,
                        operation=operation,
                        input_tokens=estimated_input_tokens,
                        output_tokens=estimated_output_tokens,
                        cost_usd=cost,
                        duration_ms=duration_ms,
                        success=True
                    )
                
                return response_text
            else:
                raise Exception(f"Ollama API error: {response.status_code}")
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error generating challenges section: {str(e)}"
    
    def generate_collaboration_section(
        self,
        manual_entries: List[ManualEntry],
        db: Optional[Session] = None,
        user_id: str = "default"
    ) -> str:
        rate_limiter = None
        if db:
            rate_limiter = LLMRateLimiter(db)
        
        start_time = time.time()
        model_name = self.model
        provider = "ollama"
        operation = "collaboration"
        
        try:
            client = self._get_client()
            
            code_reviews = [e for e in manual_entries if e.type == 'code_review']
            design_docs = [e for e in manual_entries if e.type == 'design_doc']
            mentoring = [e for e in manual_entries if e.type == 'mentoring']
            
            entry_texts = []
            for entry in code_reviews + design_docs + mentoring[:20]:
                entry_desc = entry.description[:80] if entry.description else 'N/A'
                try:
                    sanitized_desc, _ = self._check_secrets_before_send(entry_desc, raise_on_secret=True)
                    collaborators_text = f" with {entry.collaborators}" if entry.collaborators else ""
                    entry_texts.append(
                        f"- [{entry.type}] {entry.title}{collaborators_text}: {sanitized_desc}"
                    )
                except ValueError as e:
                    logger.warning(f"Skipping manual entry {entry.id}: {str(e)}")
                    continue
            
            # Add context enrichment
            context_prompt = ""
            if db:
                context_service = ContextEnrichmentService(db)
                context_prompt = context_service.build_context_prompt(user_id=user_id)
            
            prompt = f"""{context_prompt}Transform the following collaboration activities into a "Collaboration Highlights" section.

Activities:
{chr(10).join(entry_texts)}

Generate 3-5 bullet points that:
1. Highlight teamwork and knowledge sharing
2. Show cross-functional contributions
3. Emphasize impact on team/org
4. Use specific examples with context

Format: Professional, emphasize collective impact."""
            
            if rate_limiter:
                estimated_tokens = len(prompt) // 4
                try:
                    rate_limiter.check_rate_limit(provider, estimated_tokens)
                except RateLimitExceeded:
                    pass
            
            response = client.post(
                "/api/generate",
                json={
                    "model": model_name,
                    "prompt": prompt,
                    "stream": False
                }
            )
            
            if response.status_code == 200:
                result = response.json()
                response_text = result.get("response", "Error generating summary")
                
                duration_ms = int((time.time() - start_time) * 1000)
                if rate_limiter:
                    estimated_input_tokens = len(prompt) // 4
                    estimated_output_tokens = len(response_text) // 4
                    cost = calculate_cost(provider, model_name, estimated_input_tokens, estimated_output_tokens)
                    rate_limiter.log_usage(
                        provider=provider,
                        model=model_name,
                        operation=operation,
                        input_tokens=estimated_input_tokens,
                        output_tokens=estimated_output_tokens,
                        cost_usd=cost,
                        duration_ms=duration_ms,
                        success=True
                    )
                
                return response_text
            else:
                raise Exception(f"Ollama API error: {response.status_code}")
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            if rate_limiter:
                rate_limiter.log_usage(
                    provider=provider,
                    model=model_name,
                    operation=operation,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_ms=duration_ms,
                    success=False,
                    error_message=str(e)
                )
            return f"Error generating collaboration section: {str(e)}"


def get_llm_provider(redact_sensitive: bool = False) -> LLMProvider:
    """
    Get the configured LLM provider instance.
    
    Args:
        redact_sensitive: If True, automatically redact secrets instead of blocking
    """
    provider_name = settings.llm_provider.lower()
    enable_secret_detection = True
    
    if provider_name == "openai":
        if not settings.openai_api_key:
            raise ValueError("OpenAI API key not configured")
        return OpenAIProvider(settings.openai_api_key, enable_secret_detection, redact_sensitive)
    elif provider_name == "gemini":
        if not settings.gemini_api_key:
            raise ValueError("Gemini API key not configured")
        return GeminiProvider(settings.gemini_api_key, enable_secret_detection, redact_sensitive)
    elif provider_name == "ollama":
        ollama_base_url = getattr(settings, 'ollama_base_url', 'http://localhost:11434')
        ollama_model = getattr(settings, 'ollama_model', 'llama2')
        return OllamaProvider(ollama_base_url, ollama_model, enable_secret_detection, redact_sensitive)
    else:
        raise ValueError(f"Unknown LLM provider: {provider_name}")

