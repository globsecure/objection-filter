from sqlalchemy.orm import Session
from typing import List, Dict, Optional
import re
from ..models import Commit, Repository


def detect_cross_repo_impacts(
    db: Session,
    repo_id: int,
    other_repos: Optional[List[int]] = None
) -> Dict:
    """
    Detect commits that might impact other repositories.
    Looks for:
    - Shared library references
    - Dependency updates
    - API changes
    - Common file patterns
    """
    repo = db.query(Repository).filter(Repository.id == repo_id).first()
    if not repo:
        return {'impacts': []}
    
    commits = db.query(Commit).filter(Commit.repo_id == repo_id).all()
    
    # Patterns that suggest cross-repo impact
    impact_patterns = [
        r'shared[_-]?lib',
        r'common[_-]?lib',
        r'@paypal/',
        r'package\.json',
        r'requirements\.txt',
        r'pom\.xml',
        r'api[_-]?v\d+',
        r'breaking[_-]?change',
        r'deprecat'
    ]
    
    impact_commits = []
    for commit in commits:
        message_lower = commit.message.lower()
        files_changed = commit.files_changed
        
        # Check commit message
        matches = []
        for pattern in impact_patterns:
            if re.search(pattern, message_lower):
                matches.append(pattern)
        
        # High file count might indicate library changes
        is_library_change = files_changed > 20 and any(x in message_lower for x in ['lib', 'package', 'dependency'])
        
        if matches or is_library_change:
            impact_commits.append({
                'commit_id': commit.id,
                'hash': commit.hash,
                'message': commit.message[:100] if commit.message else '',
                'date': commit.date.isoformat() if commit.date else None,
                'impact_indicators': matches,
                'files_changed': files_changed,
                'potential_impact': 'high' if len(matches) > 2 or is_library_change else 'medium'
            })
    
    return {
        'repo_id': repo_id,
        'repo_name': repo.name,
        'total_commits_analyzed': len(commits),
        'impact_commits': impact_commits,
        'impact_count': len(impact_commits)
    }

