from typing import Dict
import re


def score_commit_message(message: str) -> Dict:
    """
    Score commit message quality (0-100).
    
    Penalties:
    - Generic words without context: "wip", "fix", "update" (-10 each)
    - Very short messages (< 10 chars): -20
    - No capital letter at start: -5
    - All caps: -10
    
    Bonuses:
    - Conventional commits format: +20
    - Includes issue/ticket reference: +10
    - Descriptive (> 50 chars): +10
    - Multiple sentences: +5
    """
    score = 100.0
    message_lower = message.lower().strip()
    issues = []
    positives = []
    
    # Penalties
    generic_words = ['wip', 'fix', 'update', 'change', 'stuff', 'things']
    generic_count = sum(1 for word in generic_words if word in message_lower)
    if generic_count > 0 and len(message.split()) < 5:
        penalty = min(generic_count * 10, 30)
        score -= penalty
        issues.append(f"Generic words without context: -{penalty}")
    
    if len(message) < 10:
        score -= 20
        issues.append("Very short message: -20")
    
    if message and not message[0].isupper():
        score -= 5
        issues.append("No capital letter at start: -5")
    
    if message.isupper() and len(message) > 5:
        score -= 10
        issues.append("All caps: -10")
    
    # Bonuses
    # Conventional commits: type(scope): description
    conventional_pattern = r'^(feat|fix|docs|style|refactor|test|chore)(\(.+\))?:'
    if re.match(conventional_pattern, message):
        score += 20
        positives.append("Conventional commits format: +20")
    
    # Issue reference
    if re.search(r'#[0-9]+|\[[A-Z]+-[0-9]+\]', message):
        score += 10
        positives.append("Includes issue reference: +10")
    
    if len(message) > 50:
        score += 10
        positives.append("Descriptive message: +10")
    
    if message.count('.') > 1 or message.count('!') > 1:
        score += 5
        positives.append("Multiple sentences: +5")
    
    score = max(0, min(100, score))
    
    return {
        'score': round(score, 1),
        'grade': _get_grade(score),
        'issues': issues,
        'positives': positives,
        'message_length': len(message)
    }


def _get_grade(score: float) -> str:
    """Convert score to letter grade."""
    if score >= 90:
        return 'A'
    elif score >= 80:
        return 'B'
    elif score >= 70:
        return 'C'
    elif score >= 60:
        return 'D'
    else:
        return 'F'

