from sqlalchemy.orm import Session
from sqlalchemy import func, and_, extract
from typing import List, Dict, Optional
from datetime import datetime, timedelta
from collections import defaultdict
from statistics import mean, median, stdev
from ..models import Commit, DailyLog, ManualEntry


def analyze_focus_time(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """
    Analyze focus time patterns from commit timestamps.
    Identifies "Deep Work" blocks (consecutive hours of coding).
    """
    query = db.query(Commit)
    
    if repo_id:
        query = query.filter(Commit.repo_id == repo_id)
    if start_date:
        query = query.filter(Commit.date >= start_date)
    if end_date:
        query = query.filter(Commit.date <= end_date)
    
    commits = query.order_by(Commit.date.asc()).all()
    
    if not commits:
        return {
            'flow_score': {
                'score': 0.0,
                'deep_work_hours': 0.0,
                'fragmentation_score': 0.0,
                'optimal_hours': []
            },
            'focus_blocks': [],
            'hourly_distribution': []
        }
    
    # Analyze hourly distribution
    hourly_counts = defaultdict(int)
    for commit in commits:
        hour = commit.date.hour
        hourly_counts[hour] += 1
    
    hourly_distribution = [
        {'hour': h, 'count': hourly_counts.get(h, 0)}
        for h in range(24)
    ]
    
    # Find focus blocks (consecutive commits within 2 hours)
    focus_blocks = _identify_focus_blocks(commits)
    
    # Calculate flow score
    flow_score = _calculate_flow_score(commits, focus_blocks)
    
    return {
        'flow_score': flow_score,
        'focus_blocks': focus_blocks,
        'hourly_distribution': hourly_distribution
    }


def _identify_focus_blocks(commits: List) -> List[Dict]:
    """
    Identify focus blocks from commit patterns.
    A focus block is a period with multiple commits within 2-hour windows.
    """
    if not commits:
        return []
    
    blocks = []
    current_block_start = None
    current_block_end = None
    current_block_count = 0
    
    MAX_GAP_HOURS = 2
    
    for i, commit in enumerate(commits):
        if current_block_start is None:
            current_block_start = commit.date
            current_block_end = commit.date
            current_block_count = 1
            continue
        
        time_diff = (commit.date - current_block_end).total_seconds() / 3600
        
        if time_diff <= MAX_GAP_HOURS:
            # Continue current block
            current_block_end = commit.date
            current_block_count += 1
        else:
            # Save current block if it has enough commits
            if current_block_count >= 2:
                duration_hours = (current_block_end - current_block_start).total_seconds() / 3600
                blocks.append({
                    'start_hour': current_block_start.hour,
                    'end_hour': current_block_end.hour,
                    'commit_count': current_block_count,
                    'is_deep_work': current_block_count >= 3 and duration_hours >= 1,
                    'date': current_block_start.strftime('%Y-%m-%d'),
                    'duration_hours': round(duration_hours, 2)
                })
            
            # Start new block
            current_block_start = commit.date
            current_block_end = commit.date
            current_block_count = 1
    
    # Don't forget the last block
    if current_block_count >= 2:
        duration_hours = (current_block_end - current_block_start).total_seconds() / 3600
        blocks.append({
            'start_hour': current_block_start.hour,
            'end_hour': current_block_end.hour,
            'commit_count': current_block_count,
            'is_deep_work': current_block_count >= 3 and duration_hours >= 1,
            'date': current_block_start.strftime('%Y-%m-%d'),
            'duration_hours': round(duration_hours, 2)
        })
    
    return blocks


def _calculate_flow_score(commits: List, focus_blocks: List[Dict]) -> Dict:
    """
    Calculate flow score based on commit patterns.
    Higher score = more focused, less fragmented work.
    """
    if not commits:
        return {
            'score': 0.0,
            'deep_work_hours': 0.0,
            'fragmentation_score': 0.0,
            'optimal_hours': []
        }
    
    # Calculate deep work hours
    deep_work_hours = sum(
        block.get('duration_hours', 0)
        for block in focus_blocks
        if block.get('is_deep_work')
    )
    
    # Calculate fragmentation score (gaps between work sessions)
    total_gaps = 0
    large_gaps = 0  # Gaps > 2 hours during work hours (8am-8pm)
    
    for i in range(1, len(commits)):
        gap_hours = (commits[i].date - commits[i-1].date).total_seconds() / 3600
        
        # Only count gaps on the same day during work hours
        if commits[i].date.date() == commits[i-1].date.date():
            if 8 <= commits[i].date.hour <= 20:
                total_gaps += 1
                if gap_hours > 2:
                    large_gaps += 1
    
    fragmentation_score = large_gaps / max(1, total_gaps) if total_gaps > 0 else 0
    
    # Find optimal hours (hours with most commits)
    hourly_counts = defaultdict(int)
    for commit in commits:
        hourly_counts[commit.date.hour] += 1
    
    sorted_hours = sorted(hourly_counts.items(), key=lambda x: x[1], reverse=True)
    optimal_hours = [h for h, _ in sorted_hours[:4]]
    
    # Calculate overall flow score (0-100)
    # Higher deep work hours = higher score
    # Higher fragmentation = lower score
    deep_work_component = min(deep_work_hours * 5, 50)  # Max 50 points
    fragmentation_component = (1 - fragmentation_score) * 30  # Max 30 points
    consistency_component = min(len(focus_blocks) * 2, 20)  # Max 20 points
    
    flow_score = deep_work_component + fragmentation_component + consistency_component
    
    return {
        'score': round(flow_score, 1),
        'deep_work_hours': round(deep_work_hours, 1),
        'fragmentation_score': round(fragmentation_score, 2),
        'optimal_hours': sorted(optimal_hours)
    }


def get_optimal_hours(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """
    Get optimal working hours based on commit patterns.
    """
    query = db.query(Commit)
    
    if repo_id:
        query = query.filter(Commit.repo_id == repo_id)
    if start_date:
        query = query.filter(Commit.date >= start_date)
    if end_date:
        query = query.filter(Commit.date <= end_date)
    
    commits = query.all()
    
    hourly_counts = defaultdict(int)
    hourly_productivity = defaultdict(lambda: {'commits': 0, 'lines': 0})
    
    for commit in commits:
        hour = commit.date.hour
        hourly_counts[hour] += 1
        hourly_productivity[hour]['commits'] += 1
        hourly_productivity[hour]['lines'] += (commit.insertions + commit.deletions)
    
    # Find peak hours
    total_commits = sum(hourly_counts.values())
    avg_per_hour = total_commits / 24 if total_commits > 0 else 0
    
    peak_hours = [
        h for h, count in hourly_counts.items()
        if count > avg_per_hour * 1.5
    ]
    
    return {
        'peak_hours': sorted(peak_hours),
        'hourly_distribution': [
            {
                'hour': h,
                'commits': hourly_productivity[h]['commits'],
                'lines_changed': hourly_productivity[h]['lines'],
                'is_peak': h in peak_hours
            }
            for h in range(24)
        ],
        'recommendation': _generate_time_recommendation(peak_hours)
    }


def _generate_time_recommendation(peak_hours: List[int]) -> str:
    """
    Generate a recommendation based on peak hours.
    """
    if not peak_hours:
        return "Not enough data to determine optimal hours."
    
    morning_peak = any(6 <= h <= 11 for h in peak_hours)
    afternoon_peak = any(12 <= h <= 17 for h in peak_hours)
    evening_peak = any(18 <= h <= 23 for h in peak_hours)
    
    if morning_peak and not afternoon_peak:
        return "Your peak productivity is in the morning. Consider scheduling meetings after 12 PM."
    elif afternoon_peak and not morning_peak:
        return "Your peak productivity is in the afternoon. Consider using mornings for meetings."
    elif morning_peak and afternoon_peak:
        return "You have strong productivity in both morning and afternoon. Protect these hours for deep work."
    elif evening_peak:
        return "You tend to be productive in the evening. Ensure work-life balance is maintained."
    
    return "Your productivity is spread throughout the day."


def get_daily_activity(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> List[Dict]:
    """
    Get daily activity patterns (for heatmap visualization).
    """
    query = db.query(Commit)
    
    if repo_id:
        query = query.filter(Commit.repo_id == repo_id)
    if start_date:
        query = query.filter(Commit.date >= start_date)
    if end_date:
        query = query.filter(Commit.date <= end_date)
    
    commits = query.all()
    
    # Create day-hour matrix
    activity_matrix = defaultdict(lambda: defaultdict(int))
    
    for commit in commits:
        day = commit.date.weekday()  # 0=Monday, 6=Sunday
        hour = commit.date.hour
        activity_matrix[day][hour] += 1
    
    result = []
    day_names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    
    for day in range(7):
        for hour in range(24):
            result.append({
                'day': day,
                'day_name': day_names[day],
                'hour': hour,
                'count': activity_matrix[day][hour]
            })
    
    return result


def calculate_satisfaction_metrics(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None
) -> Dict:
    """
    Calculate Satisfaction & Wellbeing from DailyLog entries.
    """
    query = db.query(DailyLog)
    if start_date:
        query = query.filter(DailyLog.date >= start_date)
    if end_date:
        query = query.filter(DailyLog.date <= end_date)
    logs = query.order_by(DailyLog.date.asc()).all()
    
    if not logs:
        return {
            'average_satisfaction': 0.0,
            'average_wellbeing': 0.0,
            'trend': 'stable',
            'low_weeks_count': 0,
            'total_entries': 0,
            'scores_over_time': []
        }
    
    satisfaction_scores = [log.satisfaction_score for log in logs if log.satisfaction_score is not None]
    wellbeing_scores = [log.wellbeing_score for log in logs if log.wellbeing_score is not None]
    
    # Calculate trend (comparing first half vs second half)
    if len(satisfaction_scores) >= 4:
        first_half = mean(satisfaction_scores[:len(satisfaction_scores)//2])
        second_half = mean(satisfaction_scores[len(satisfaction_scores)//2:])
        if second_half > first_half + 0.5:
            trend = 'improving'
        elif second_half < first_half - 0.5:
            trend = 'declining'
        else:
            trend = 'stable'
    else:
        trend = 'stable'
    
    # Count low weeks (score < 5)
    low_weeks = len([s for s in satisfaction_scores if s and s < 5])
    
    return {
        'average_satisfaction': round(mean(satisfaction_scores), 2) if satisfaction_scores else 0.0,
        'average_wellbeing': round(mean(wellbeing_scores), 2) if wellbeing_scores else 0.0,
        'trend': trend,
        'low_weeks_count': low_weeks,
        'total_entries': len(logs),
        'scores_over_time': [
            {'date': log.date.isoformat(), 'satisfaction': log.satisfaction_score, 'wellbeing': log.wellbeing_score}
            for log in logs if log.satisfaction_score is not None
        ]
    }


def calculate_performance_metrics(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """
    Calculate Performance (Output) metrics combining commits and manual entries.
    """
    # Get commits
    commit_query = db.query(Commit)
    if start_date:
        commit_query = commit_query.filter(Commit.date >= start_date)
    if end_date:
        commit_query = commit_query.filter(Commit.date <= end_date)
    if repo_id:
        commit_query = commit_query.filter(Commit.repo_id == repo_id)
    commits = commit_query.all()
    
    # Get manual entries
    manual_query = db.query(ManualEntry)
    if start_date:
        manual_query = manual_query.filter(ManualEntry.date >= start_date)
    if end_date:
        manual_query = manual_query.filter(ManualEntry.date <= end_date)
    manual_entries = manual_query.all()
    
    # Calculate volume metrics
    total_commits = len(commits)
    total_insertions = sum(c.insertions for c in commits)
    total_deletions = sum(c.deletions for c in commits)
    merge_commits = len([c for c in commits if c.is_merge_commit])
    
    # Manual entry metrics
    code_reviews = len([e for e in manual_entries if e.type == 'code_review'])
    design_docs = len([e for e in manual_entries if e.type == 'design_doc'])
    mentoring = len([e for e in manual_entries if e.type == 'mentoring'])
    
    # Quality metrics
    revert_commits = len([c for c in commits if c.message and 'revert' in c.message.lower()])
    revert_rate = (revert_commits / total_commits * 100) if total_commits > 0 else 0.0
    
    # Calculate quality score (0-100)
    # Penalize revert rate, reward code reviews and design docs
    quality_score = 100.0
    quality_score -= min(revert_rate * 2, 20)  # Max 20 point penalty
    quality_score += min(code_reviews * 0.5, 10)  # Max 10 point bonus
    quality_score += min(design_docs * 1, 10)  # Max 10 point bonus
    quality_score = max(0, min(100, quality_score))  # Clamp to 0-100
    
    return {
        'commits': total_commits,
        'lines_changed': total_insertions + total_deletions,
        'net_change': total_insertions - total_deletions,
        'merge_commits': merge_commits,
        'code_reviews': code_reviews,
        'design_docs': design_docs,
        'mentoring_sessions': mentoring,
        'revert_rate': round(revert_rate, 2),
        'quality_score': round(quality_score, 2)
    }


def _calculate_longest_streak(commit_dates: List[datetime]) -> int:
    """
    Calculate longest streak of consecutive active days.
    """
    if not commit_dates:
        return 0
    
    unique_dates = sorted(set(d.date() for d in commit_dates))
    if not unique_dates:
        return 0
    
    longest_streak = 1
    current_streak = 1
    
    for i in range(1, len(unique_dates)):
        days_diff = (unique_dates[i] - unique_dates[i-1]).days
        if days_diff == 1:
            current_streak += 1
            longest_streak = max(longest_streak, current_streak)
        else:
            current_streak = 1
    
    return longest_streak


def calculate_activity_metrics(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """
    Calculate Activity (Volume) metrics with consistency and fragmentation analysis.
    """
    commit_query = db.query(Commit)
    if start_date:
        commit_query = commit_query.filter(Commit.date >= start_date)
    if end_date:
        commit_query = commit_query.filter(Commit.date <= end_date)
    if repo_id:
        commit_query = commit_query.filter(Commit.repo_id == repo_id)
    commits = commit_query.order_by(Commit.date.asc()).all()
    
    if not commits:
        return {
            'active_days': 0,
            'active_days_pct': 0.0,
            'avg_commits_per_day': 0.0,
            'consistency_score': 0.0,
            'longest_streak': 0,
            'fragmentation_score': 0.0,
            'total_commits': 0
        }
    
    # Get unique dates
    commit_dates_list = sorted(set(c.date for c in commits))
    if start_date and end_date:
        total_days = (end_date.date() - start_date.date()).days + 1
    else:
        total_days = (commit_dates_list[-1].date() - commit_dates_list[0].date()).days + 1 if commit_dates_list else 1
    active_days = len(commit_dates_list)
    
    # Commits per day
    commits_per_day = defaultdict(int)
    for commit in commits:
        commits_per_day[commit.date.date()] += 1
    
    # Consistency score (lower std dev = more consistent)
    daily_counts = list(commits_per_day.values())
    if len(daily_counts) > 1:
        mean_count = mean(daily_counts)
        std_dev = stdev(daily_counts)
        consistency_score = max(0, 1 - (std_dev / mean_count)) if mean_count > 0 else 0.0
    else:
        consistency_score = 1.0
    
    # Longest streak
    longest_streak = _calculate_longest_streak(commit_dates_list)
    
    # Fragmentation: gaps between commits
    gaps = []
    for i in range(1, len(commit_dates_list)):
        gap = (commit_dates_list[i].date() - commit_dates_list[i-1].date()).days
        gaps.append(gap)
    
    # Fragmentation score: higher = more fragmented (more gaps > 1 day)
    if gaps:
        fragmentation_score = len([g for g in gaps if g > 1]) / len(gaps)
    else:
        fragmentation_score = 0.0
    
    return {
        'active_days': active_days,
        'active_days_pct': round((active_days / total_days * 100) if total_days > 0 else 0, 2),
        'avg_commits_per_day': round(len(commits) / active_days if active_days > 0 else 0, 2),
        'consistency_score': round(consistency_score, 2),
        'longest_streak': longest_streak,
        'fragmentation_score': round(fragmentation_score, 2),
        'total_commits': len(commits)
    }


def calculate_collaboration_metrics(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None
) -> Dict:
    """
    Calculate Communication & Collaboration metrics from manual entries.
    """
    query = db.query(ManualEntry)
    if start_date:
        query = query.filter(ManualEntry.date >= start_date)
    if end_date:
        query = query.filter(ManualEntry.date <= end_date)
    entries = query.all()
    
    # Count by type
    code_reviews = [e for e in entries if e.type == 'code_review']
    design_docs = [e for e in entries if e.type == 'design_doc']
    mentoring = [e for e in entries if e.type == 'mentoring']
    meetings = [e for e in entries if e.type == 'meeting']
    
    # Count unique collaborators
    all_collaborators = set()
    for entry in entries:
        if entry.collaborators:
            collaborators = [c.strip() for c in entry.collaborators.split(',')]
            all_collaborators.update(collaborators)
    
    # Calculate collaboration score (0-100)
    # Based on variety and frequency of collaboration activities
    collaboration_score = 0.0
    collaboration_score += min(len(code_reviews) * 2, 30)  # Max 30 points
    collaboration_score += min(len(design_docs) * 3, 25)  # Max 25 points
    collaboration_score += min(len(mentoring) * 5, 25)  # Max 25 points
    collaboration_score += min(len(all_collaborators) * 2, 20)  # Max 20 points
    collaboration_score = min(100, collaboration_score)
    
    return {
        'code_reviews': len(code_reviews),
        'design_docs': len(design_docs),
        'mentoring_sessions': len(mentoring),
        'meetings': len(meetings),
        'unique_collaborators': len(all_collaborators),
        'collaboration_score': round(collaboration_score, 2),
        'total_collaboration_activities': len(entries)
    }


def get_space_metrics(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """
    Get complete SPACE metrics summary (all 5 dimensions).
    """
    focus_analysis = analyze_focus_time(db, start_date, end_date, repo_id)
    
    return {
        'satisfaction': calculate_satisfaction_metrics(db, start_date, end_date),
        'performance': calculate_performance_metrics(db, start_date, end_date, repo_id),
        'activity': calculate_activity_metrics(db, start_date, end_date, repo_id),
        'collaboration': calculate_collaboration_metrics(db, start_date, end_date),
        'efficiency': focus_analysis['flow_score']
    }

