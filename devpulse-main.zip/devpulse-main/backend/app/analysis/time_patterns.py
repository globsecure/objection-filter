from datetime import datetime, timedelta
from typing import Dict, List, Optional
from sqlalchemy.orm import Session
from collections import defaultdict

from ..models import Commit


def detect_timezone(commits: List[Commit]) -> Optional[str]:
    """Detect timezone from commit patterns"""
    if not commits:
        return None
    
    # Analyze commit hour distribution
    hour_distribution = defaultdict(int)
    for commit in commits:
        if commit.date:
            hour_distribution[commit.date.hour] += 1
    
    # Most common working hours (assume 9-17 in local time)
    # This is a heuristic - could be improved with more sophisticated analysis
    most_common_hour = max(hour_distribution.items(), key=lambda x: x[1])[0] if hour_distribution else None
    
    # Simple heuristic: if most commits are 9-17, likely in that timezone
    # For now, return UTC and let user configure
    return "UTC"


def analyze_working_hours(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """Analyze working hours patterns from commits"""
    query = db.query(Commit)
    
    if start_date:
        query = query.filter(Commit.date >= start_date)
    if end_date:
        query = query.filter(Commit.date <= end_date)
    if repo_id:
        query = query.filter(Commit.repo_id == repo_id)
    
    commits = query.all()
    
    # Hour distribution (0-23)
    hour_distribution = defaultdict(int)
    day_of_week_distribution = defaultdict(int)  # 0=Monday, 6=Sunday
    
    for commit in commits:
        if commit.date:
            hour_distribution[commit.date.hour] += 1
            day_of_week_distribution[commit.date.weekday()] += 1
    
    # Find most productive hours
    sorted_hours = sorted(hour_distribution.items(), key=lambda x: x[1], reverse=True)
    top_hours = [h for h, _ in sorted_hours[:3]]
    
    # Best focus time (consecutive hours with high activity)
    best_start_hour = None
    best_end_hour = None
    max_consecutive = 0
    current_start = None
    current_count = 0
    
    for hour in range(24):
        count = hour_distribution[hour]
        if count > 0:
            if current_start is None:
                current_start = hour
            current_count += count
        else:
            if current_start is not None and current_count > max_consecutive:
                max_consecutive = current_count
                best_start_hour = current_start
                best_end_hour = hour - 1
            current_start = None
            current_count = 0
    
    # Handle case where best time extends to end of day
    if current_start is not None and current_count > max_consecutive:
        best_start_hour = current_start
        best_end_hour = 23
    
    return {
        "hour_distribution": dict(hour_distribution),
        "day_of_week_distribution": dict(day_of_week_distribution),
        "top_hours": top_hours,
        "best_focus_time": {
            "start": best_start_hour,
            "end": best_end_hour,
        } if best_start_hour else None,
        "total_commits": len(commits),
    }


def detect_after_hours_work(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None,
    work_start_hour: int = 9,
    work_end_hour: int = 17
) -> Dict:
    """Detect commits made outside normal working hours"""
    query = db.query(Commit)
    
    if start_date:
        query = query.filter(Commit.date >= start_date)
    if end_date:
        query = query.filter(Commit.date <= end_date)
    if repo_id:
        query = query.filter(Commit.repo_id == repo_id)
    
    commits = query.all()
    
    after_hours = []
    weekend_work = []
    
    for commit in commits:
        if commit.date:
            hour = commit.date.hour
            weekday = commit.date.weekday()
            
            # After hours (before 9 AM or after 5 PM on weekdays)
            if weekday < 5:  # Monday-Friday
                if hour < work_start_hour or hour >= work_end_hour:
                    after_hours.append(commit)
            
            # Weekend work
            if weekday >= 5:  # Saturday-Sunday
                weekend_work.append(commit)
    
    return {
        "after_hours_count": len(after_hours),
        "weekend_count": len(weekend_work),
        "after_hours_commits": [c.id for c in after_hours[:10]],  # Sample
        "weekend_commits": [c.id for c in weekend_work[:10]],
        "percentage_after_hours": len(after_hours) / len(commits) * 100 if commits else 0,
        "percentage_weekend": len(weekend_work) / len(commits) * 100 if commits else 0,
    }

