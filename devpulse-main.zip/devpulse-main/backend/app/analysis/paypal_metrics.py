from sqlalchemy.orm import Session
from typing import Dict, List, Optional
from datetime import datetime, timedelta
from ..models import Goal, GoalLink, Commit, ManualEntry, Repository, Feedback
from ..analysis.llm_service import get_llm_provider


def calculate_say_do_ratio(
    db: Session,
    quarter_start: Optional[datetime] = None,
    quarter_end: Optional[datetime] = None
) -> Dict:
    """
    Calculate Say/Do Ratio for goals in a quarter.
    
    Say/Do Ratio = (completed goals / total active goals) * 100
    Target: >= 95% for high performers (PayPal expectation)
    
    Args:
        db: Database session
        quarter_start: Start of quarter (defaults to current quarter start)
        quarter_end: End of quarter (defaults to current quarter end)
        
    Returns:
        Dict with ratio, completed count, total count, and warning flag
    """
    if not quarter_start or not quarter_end:
        # Default to current quarter
        now = datetime.now()
        quarter = (now.month - 1) // 3
        quarter_start = datetime(now.year, quarter * 3 + 1, 1)
        if quarter == 3:
            quarter_end = datetime(now.year + 1, 1, 1)
        else:
            quarter_end = datetime(now.year, (quarter + 1) * 3 + 1, 1)
    
    # Get all goals created in the quarter
    goals = db.query(Goal).filter(
        Goal.created_at >= quarter_start,
        Goal.created_at <= quarter_end
    ).all()
    
    # Filter to active goals (active, completed, cancelled)
    # Exclude goals that were never started
    active_goals = [g for g in goals if g.status in ['active', 'completed', 'cancelled']]
    
    if not active_goals:
        return {
            'ratio': 100.0,
            'completed': 0,
            'total': 0,
            'warning': False,
            'quarter_start': quarter_start.isoformat(),
            'quarter_end': quarter_end.isoformat()
        }
    
    completed = [g for g in active_goals if g.status == 'completed']
    ratio = (len(completed) / len(active_goals)) * 100
    
    return {
        'ratio': round(ratio, 1),
        'completed': len(completed),
        'total': len(active_goals),
        'warning': ratio < 95,
        'quarter_start': quarter_start.isoformat(),
        'quarter_end': quarter_end.isoformat(),
        'target': 95
    }


def get_risk_radar(
    db: Session,
    days_ahead: int = 14
) -> List[Dict]:
    """
    Detect goals at risk of missing deadline.
    
    Checks:
    - Goals with deadline in next N days
    - Goals without commits linked in last 5 days
    - Goals that are active but have no recent activity
    
    Args:
        db: Database session
        days_ahead: Number of days ahead to check (default: 14)
        
    Returns:
        List of goals at risk with risk reasons
    """
    now = datetime.now()
    future_date = now + timedelta(days=days_ahead)
    
    # Get active goals with deadline in next N days
    at_risk_goals = db.query(Goal).filter(
        Goal.status == 'active',
        Goal.deadline >= now,
        Goal.deadline <= future_date
    ).all()
    
    risks = []
    
    for goal in at_risk_goals:
        risk_reasons = []
        
        # Check for commits linked in last 5 days
        five_days_ago = now - timedelta(days=5)
        recent_links = db.query(GoalLink).filter(
            GoalLink.goal_id == goal.id,
            GoalLink.created_at >= five_days_ago
        ).all()
        
        if not recent_links:
            risk_reasons.append("No commits linked in last 5 days")
        
        # Check if goal has any commits linked at all
        all_links = db.query(GoalLink).filter(GoalLink.goal_id == goal.id).all()
        if not all_links:
            risk_reasons.append("No commits linked to this goal")
        
        # Check progress
        if goal.progress < 0.5 and (goal.deadline - now).days < 7:
            risk_reasons.append("Low progress (<50%) with less than 7 days remaining")
        
        if risk_reasons:
            days_until_deadline = (goal.deadline - now).days
            risks.append({
                'goal_id': goal.id,
                'title': goal.title,
                'deadline': goal.deadline.isoformat(),
                'days_until_deadline': days_until_deadline,
                'progress': goal.progress,
                'risk_reasons': risk_reasons,
                'recommendation': 'Update status or increase effort'
            })
    
    return risks


def get_cross_team_work_percentage(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None
) -> Dict:
    """
    Calculate percentage of work done in cross-team repositories.
    
    Cross-team repos are identified by tags: 'shared-lib', 'infra', 'core-platform'
    
    Args:
        db: Database session
        start_date: Start date for analysis
        end_date: End date for analysis
        
    Returns:
        Dict with percentage, counts, and breakdown by repo
    """
    if not start_date:
        start_date = datetime.now() - timedelta(days=90)
    if not end_date:
        end_date = datetime.now()
    
    # Get all commits in period
    all_commits = db.query(Commit).filter(
        Commit.date >= start_date,
        Commit.date <= end_date
    ).all()
    
    if not all_commits:
        return {
            'cross_team_percentage': 0.0,
            'cross_team_count': 0,
            'total_count': 0,
            'breakdown': []
        }
    
    # Get cross-team repos
    cross_team_tags = ['shared-lib', 'infra', 'core-platform']
    cross_team_repos = db.query(Repository).filter(
        Repository.tags.isnot(None)
    ).all()
    
    cross_team_repo_ids = set()
    for repo in cross_team_repos:
        if repo.tags:
            tags = [t.strip() for t in repo.tags.split(',')]
            if any(tag in cross_team_tags for tag in tags):
                cross_team_repo_ids.add(repo.id)
    
    # Count commits in cross-team repos
    cross_team_commits = [c for c in all_commits if c.repo_id in cross_team_repo_ids]
    
    # Breakdown by repo
    breakdown = {}
    for commit in cross_team_commits:
        repo_id = commit.repo_id
        if repo_id not in breakdown:
            repo = db.query(Repository).filter(Repository.id == repo_id).first()
            breakdown[repo_id] = {
                'repo_id': repo_id,
                'repo_name': repo.name if repo else 'Unknown',
                'tags': repo.tags if repo else '',
                'commit_count': 0
            }
        breakdown[repo_id]['commit_count'] += 1
    
    percentage = (len(cross_team_commits) / len(all_commits)) * 100 if all_commits else 0
    
    return {
        'cross_team_percentage': round(percentage, 1),
        'cross_team_count': len(cross_team_commits),
        'total_count': len(all_commits),
        'breakdown': list(breakdown.values())
    }


def count_distinct_mentees(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None
) -> Dict:
    """
    Count distinct mentees from ManualEntry (mentoring) and Feedback logs.
    
    Args:
        db: Database session
        start_date: Start date for analysis
        end_date: End date for analysis
        
    Returns:
        Dict with mentee count and list of mentees
    """
    if not start_date:
        start_date = datetime.now() - timedelta(days=365)
    if not end_date:
        end_date = datetime.now()
    
    mentees = set()
    
    # Get mentees from ManualEntry (type='mentoring')
    mentoring_entries = db.query(ManualEntry).filter(
        ManualEntry.type == 'mentoring',
        ManualEntry.date >= start_date,
        ManualEntry.date <= end_date,
        ManualEntry.collaborators.isnot(None)
    ).all()
    
    for entry in mentoring_entries:
        if entry.collaborators:
            # Collaborators is comma-separated
            for name in entry.collaborators.split(','):
                mentees.add(name.strip())
    
    # Get mentees from Feedback logs (from_who field)
    feedback_entries = db.query(Feedback).filter(
        Feedback.date >= start_date,
        Feedback.date <= end_date
    ).all()
    
    # Note: Feedback.from_who might be mentees, but we need to distinguish
    # For now, we'll focus on ManualEntry mentoring type
    
    return {
        'mentee_count': len(mentees),
        'mentees': sorted(list(mentees)),
        'target': 2  # PayPal requirement: at least 2 juniors
    }


def analyze_code_review_depth(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None
) -> Dict:
    """
    Analyze code review depth by classifying reviews as superficial vs architectural.
    
    Superficial keywords: "LGTM", "looks good", "approved", "nice"
    Architectural keywords: "architecture", "design", "pattern", "structure", "guidance"
    
    Args:
        db: Database session
        start_date: Start date for analysis
        end_date: End date for analysis
        
    Returns:
        Dict with percentages and counts
    """
    if not start_date:
        start_date = datetime.now() - timedelta(days=90)
    if not end_date:
        end_date = datetime.now()
    
    code_reviews = db.query(ManualEntry).filter(
        ManualEntry.type == 'code_review',
        ManualEntry.date >= start_date,
        ManualEntry.date <= end_date
    ).all()
    
    if not code_reviews:
        return {
            'architectural_percentage': 0.0,
            'superficial_percentage': 0.0,
            'architectural_count': 0,
            'superficial_count': 0,
            'total_count': 0
        }
    
    superficial_keywords = ['lgtm', 'looks good', 'approved', 'nice', 'ok', 'fine']
    architectural_keywords = ['architecture', 'design', 'pattern', 'structure', 'guidance', 'approach', 'strategy']
    
    architectural_count = 0
    superficial_count = 0
    
    for review in code_reviews:
        text = (review.description or '').lower() + ' ' + (review.impact or '').lower()
        
        has_architectural = any(keyword in text for keyword in architectural_keywords)
        has_superficial = any(keyword in text for keyword in superficial_keywords)
        
        if has_architectural:
            architectural_count += 1
        elif has_superficial and not has_architectural:
            superficial_count += 1
    
    total_classified = architectural_count + superficial_count
    if total_classified == 0:
        architectural_percentage = 0.0
        superficial_percentage = 0.0
    else:
        architectural_percentage = (architectural_count / total_classified) * 100
        superficial_percentage = (superficial_count / total_classified) * 100
    
    return {
        'architectural_percentage': round(architectural_percentage, 1),
        'superficial_percentage': round(superficial_percentage, 1),
        'architectural_count': architectural_count,
        'superficial_count': superficial_count,
        'total_count': len(code_reviews),
        'unclassified_count': len(code_reviews) - total_classified
    }


def calculate_promotion_readiness(
    db: Session,
    quarter_start: Optional[datetime] = None,
    quarter_end: Optional[datetime] = None
) -> Dict:
    """
    Calculate Promotion Readiness Score based on PayPal T24/T25 criteria.
    
    Checks:
    - Has >= 2 distinct mentees
    - Say/Do ratio >= 95%
    - Has cross-team work (shared-lib/infra/core-platform)
    - Has org-level impact manual entries
    
    Args:
        db: Database session
        quarter_start: Quarter start date
        quarter_end: Quarter end date
        
    Returns:
        Dict with score (0-100), checks, gaps, and recommendations
    """
    checks = {}
    gaps = []
    recommendations = []
    
    # Check 1: Mentees >= 2
    mentees_data = count_distinct_mentees(db, quarter_start, quarter_end)
    checks['mentees'] = mentees_data['mentee_count'] >= 2
    if not checks['mentees']:
        gaps.append('mentees')
        recommendations.append(f"Need to mentor at least 2 juniors (currently: {mentees_data['mentee_count']})")
    
    # Check 2: Say/Do ratio >= 95%
    say_do_data = calculate_say_do_ratio(db, quarter_start, quarter_end)
    checks['say_do_ratio'] = say_do_data['ratio'] >= 95
    if not checks['say_do_ratio']:
        gaps.append('say_do_ratio')
        recommendations.append(f"Say/Do ratio must be >= 95% (currently: {say_do_data['ratio']}%)")
    
    # Check 3: Cross-team work
    cross_team_data = get_cross_team_work_percentage(db, quarter_start, quarter_end)
    checks['cross_team_work'] = cross_team_data['cross_team_count'] > 0
    if not checks['cross_team_work']:
        gaps.append('cross_team_work')
        recommendations.append("Need contributions to shared-lib, infra, or core-platform repos")
    
    # Check 4: Org-level impact
    if not quarter_start:
        quarter_start = datetime.now() - timedelta(days=90)
    if not quarter_end:
        quarter_end = datetime.now()
    
    # Check for manual entries with org-level impact
    org_level_entries = db.query(ManualEntry).filter(
        ManualEntry.date >= quarter_start,
        ManualEntry.date <= quarter_end,
        ManualEntry.impact_scope == 'org'
    ).count()
    
    checks['org_level_impact'] = org_level_entries > 0
    if not checks['org_level_impact']:
        gaps.append('org_level_impact')
        recommendations.append("Need manual entries demonstrating org-level impact (not just team-level)")
    
    # Calculate score
    score = (sum(checks.values()) / len(checks)) * 100
    
    return {
        'score': round(score, 1),
        'checks': checks,
        'gaps': gaps,
        'recommendations': recommendations,
        'details': {
            'mentees': mentees_data,
            'say_do_ratio': say_do_data,
            'cross_team_work': cross_team_data,
            'org_level_impact_count': org_level_entries
        }
    }

