from sqlalchemy.orm import Session
from typing import Dict, List, Optional
from datetime import datetime, timedelta
from ..models import Commit, FrictionLog, ManualEntry, Repository, CareerMoment, Goal


def calculate_data_completeness(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None
) -> Dict:
    """
    Calculate data completeness score (0-100) with weighted scoring.
    
    Checks:
    - Commits categorized (40% weight)
    - Friction logs with resolution (20% weight)
    - Manual entries with collaborators (for code reviews) (20% weight)
    - Career moments documented (10% weight)
    - Goals with status (10% weight)
    """
    if not start_date:
        start_date = datetime.now() - timedelta(days=90)
    if not end_date:
        end_date = datetime.now()
    
    # Get data
    commit_query = db.query(Commit)
    if repo_id:
        commit_query = commit_query.filter(Commit.repo_id == repo_id)
    commit_query = commit_query.filter(Commit.date >= start_date, Commit.date <= end_date)
    commits = commit_query.all()
    
    friction_query = db.query(FrictionLog).filter(
        FrictionLog.date >= start_date,
        FrictionLog.date <= end_date
    )
    friction_logs = friction_query.all()
    
    manual_query = db.query(ManualEntry).filter(
        ManualEntry.date >= start_date,
        ManualEntry.date <= end_date
    )
    manual_entries = manual_query.all()
    
    # Calculate scores
    total_score = 0
    max_score = 0
    issues = []
    recommendations = []
    
    # 1. Commits categorized (40% weight)
    max_score += 40
    uncategorized = [c for c in commits if c.type == 'Unknown' or not c.type]
    if commits:
        categorized_pct = (len(commits) - len(uncategorized)) / len(commits) * 100
        total_score += (categorized_pct / 100) * 40
        if uncategorized:
            issues.append({
                'type': 'uncategorized_commits',
                'count': len(uncategorized),
                'message': f"{len(uncategorized)} commits without category"
            })
            recommendations.append("Categorize commits to improve impact analysis")
    else:
        total_score += 40  # Perfect if no commits
    
    # 2. Friction logs with resolution (20% weight)
    max_score += 20
    incidents = [f for f in friction_logs if f.type == 'incident']
    resolved = [f for f in incidents if f.resolution]
    if incidents:
        resolved_pct = len(resolved) / len(incidents) * 100
        total_score += (resolved_pct / 100) * 20
        unresolved = [f for f in incidents if not f.resolution]
        if unresolved:
            issues.append({
                'type': 'unresolved_incidents',
                'count': len(unresolved),
                'message': f"{len(unresolved)} incidents without resolution"
            })
            recommendations.append("Add resolution to incidents to improve MTTR tracking")
    else:
        total_score += 20  # Perfect if no incidents
    
    # 3. Manual entries completeness (20% weight)
    max_score += 20
    code_reviews = [m for m in manual_entries if m.type == 'code_review']
    if code_reviews:
        with_collaborators = [m for m in code_reviews if m.collaborators]
        complete_pct = len(with_collaborators) / len(code_reviews) * 100
        total_score += (complete_pct / 100) * 20
        incomplete = [m for m in code_reviews if not m.collaborators]
        if incomplete:
            issues.append({
                'type': 'incomplete_code_reviews',
                'count': len(incomplete),
                'message': f"{len(incomplete)} code reviews without collaborators"
            })
            recommendations.append("Add collaborators to code reviews for better collaboration metrics")
    else:
        total_score += 20  # Perfect if no code reviews
    
    # 4. Career moments documented (10% weight)
    max_score += 10
    moments = db.query(CareerMoment).filter(
        CareerMoment.date >= start_date,
        CareerMoment.date <= end_date
    ).count()
    # Recommend documenting moments if there are significant commits but no moments
    if len(commits) > 50 and moments == 0:
        recommendations.append("Document career moments to enrich your performance narrative")
        total_score += 5  # Partial credit
    else:
        total_score += 10
    
    # 5. Goals tracking (10% weight)
    max_score += 10
    goals = db.query(Goal).filter(
        Goal.created_at >= start_date
    ).all()
    if goals:
        with_status = [g for g in goals if g.status]
        if goals:
            tracked_pct = len(with_status) / len(goals) * 100
            total_score += (tracked_pct / 100) * 10
    else:
        total_score += 10  # Perfect if no goals
    
    overall_score = (total_score / max_score * 100) if max_score > 0 else 100
    
    uncategorized_commits = [c for c in commits if c.type == 'Unknown' or not c.type]
    unresolved_incidents = [f for f in incidents if not f.resolution]
    incomplete_reviews = [m for m in code_reviews if not m.collaborators] if code_reviews else []
    
    return {
        'overall_score': round(overall_score, 1),
        'breakdown': {
            'commits_categorized': {
                'score': round((len(commits) - len(uncategorized_commits)) / len(commits) * 100, 1) if commits else 100,
                'total': len(commits),
                'incomplete': len(uncategorized_commits)
            },
            'incidents_resolved': {
                'score': round(len(resolved) / len(incidents) * 100, 1) if incidents else 100,
                'total': len(incidents),
                'incomplete': len(unresolved_incidents) if incidents else 0
            },
            'code_reviews_complete': {
                'score': round(len(with_collaborators) / len(code_reviews) * 100, 1) if code_reviews else 100,
                'total': len(code_reviews),
                'incomplete': len(incomplete_reviews) if code_reviews else 0
            }
        },
        'issues': issues,
        'recommendations': recommendations,
        'period': {
            'start': start_date.isoformat(),
            'end': end_date.isoformat()
        }
    }


def generate_smart_reminders(
    db: Session,
    days: int = 7
) -> List[Dict]:
    """
    Generate contextual reminders based on patterns.
    
    Examples:
    - "You haven't logged friction this week" (if commits but no friction)
    - "You have 5 code reviews but no manual entries"
    - "3 incidents without resolution"
    """
    reminders = []
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    
    # Check for commits without friction logs
    commits = db.query(Commit).filter(
        Commit.date >= start_date
    ).count()
    
    friction_logs = db.query(FrictionLog).filter(
        FrictionLog.date >= start_date
    ).count()
    
    if commits > 10 and friction_logs == 0:
        reminders.append({
            'type': 'missing_friction',
            'priority': 'medium',
            'message': f"You have {commits} commits this week but no friction logs. Consider logging blockers or wins.",
            'action': 'log_friction'
        })
    
    # Check for incidents without resolution
    incidents = db.query(FrictionLog).filter(
        FrictionLog.date >= start_date,
        FrictionLog.type == 'incident',
        FrictionLog.resolution == None
    ).all()
    
    if incidents:
        reminders.append({
            'type': 'unresolved_incidents',
            'priority': 'high',
            'message': f"You have {len(incidents)} incident(s) without resolution. Add resolution to improve MTTR tracking.",
            'action': 'resolve_incidents',
            'count': len(incidents)
        })
    
    # Check for hotfix commits without friction logs
    hotfix_commits = db.query(Commit).filter(
        Commit.date >= start_date,
        Commit.message.ilike('%hotfix%')
    ).all()
    
    if hotfix_commits:
        # Check if any have associated friction logs
        hotfix_with_friction = 0
        for commit in hotfix_commits:
            # Check if there's a friction log around the same time
            friction = db.query(FrictionLog).filter(
                FrictionLog.date >= commit.date - timedelta(hours=24),
                FrictionLog.date <= commit.date + timedelta(hours=24),
                FrictionLog.type == 'incident'
            ).first()
            if friction:
                hotfix_with_friction += 1
        
        if hotfix_with_friction < len(hotfix_commits):
            reminders.append({
                'type': 'hotfix_without_friction',
                'priority': 'medium',
                'message': f"You have {len(hotfix_commits) - hotfix_with_friction} hotfix commit(s) without associated incident logs.",
                'action': 'log_incident'
            })
    
    return reminders


def generate_validation_warnings(
    db: Session,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None
) -> List[Dict]:
    """
    Generate proactive validation warnings.
    
    Examples:
    - "3 incidents without resolution - add resolution for better MTTR"
    - "Commits of hotfix without friction log"
    - "Manual entries without collaborators (code reviews)"
    - "Goals without commits linked"
    - "Manual entries without impact scope classification"
    """
    warnings = []
    
    if not start_date:
        start_date = datetime.now() - timedelta(days=90)
    if not end_date:
        end_date = datetime.now()
    
    # Incidents without resolution
    incidents = db.query(FrictionLog).filter(
        FrictionLog.date >= start_date,
        FrictionLog.date <= end_date,
        FrictionLog.type == 'incident',
        FrictionLog.resolution == None
    ).all()
    
    if incidents:
        warnings.append({
            'type': 'incident_no_resolution',
            'severity': 'medium',
            'message': f"{len(incidents)} incident(s) without resolution",
            'recommendation': 'Add resolution to improve MTTR calculation and data completeness',
            'action_url': '/friction',
            'count': len(incidents),
            'items': [{'id': i.id, 'date': i.date.isoformat(), 'description': i.description[:50]} for i in incidents[:5]]
        })
    
    # Code reviews without collaborators
    code_reviews = db.query(ManualEntry).filter(
        ManualEntry.date >= start_date,
        ManualEntry.date <= end_date,
        ManualEntry.type == 'code_review',
        ManualEntry.collaborators == None
    ).all()
    
    if code_reviews:
        warnings.append({
            'type': 'code_review_no_collaborators',
            'severity': 'low',
            'message': f"{len(code_reviews)} code review(s) without collaborators",
            'recommendation': 'Add collaborators to improve collaboration metrics and PayPal "One Team" score',
            'action_url': '/manual-entries',
            'count': len(code_reviews),
            'items': [{'id': r.id, 'title': r.title, 'date': r.date.isoformat()} for r in code_reviews[:5]]
        })
    
    # Hotfix commits without incident logs
    hotfix_commits = db.query(Commit).filter(
        Commit.date >= start_date,
        Commit.date <= end_date,
        Commit.message.ilike('%hotfix%')
    ).all()
    
    if hotfix_commits:
        # Check which ones don't have associated incidents
        hotfix_without_incident = []
        for commit in hotfix_commits:
            incident = db.query(FrictionLog).filter(
                FrictionLog.date >= commit.date - timedelta(hours=48),
                FrictionLog.date <= commit.date + timedelta(hours=24),
                FrictionLog.type == 'incident'
            ).first()
            if not incident:
                hotfix_without_incident.append(commit)
        
        if hotfix_without_incident:
            warnings.append({
                'type': 'hotfix_without_incident',
                'severity': 'medium',
                'message': f"{len(hotfix_without_incident)} hotfix commit(s) without associated incident log",
                'recommendation': 'Log incident to track change failure rate and improve DORA metrics',
                'action_url': '/friction',
                'count': len(hotfix_without_incident),
                'items': [{'id': c.id, 'hash': c.hash[:8], 'date': c.date.isoformat()} for c in hotfix_without_incident[:5]]
            })
    
    # Goals without commits linked
    from ..models import Goal, GoalLink
    active_goals = db.query(Goal).filter(
        Goal.status == 'active',
        Goal.deadline >= start_date
    ).all()
    
    goals_without_commits = []
    for goal in active_goals:
        links = db.query(GoalLink).filter(GoalLink.goal_id == goal.id).count()
        if links == 0:
            goals_without_commits.append(goal)
    
    if goals_without_commits:
        warnings.append({
            'type': 'goals_without_commits',
            'severity': 'low',
            'message': f"{len(goals_without_commits)} active goal(s) without commits linked",
            'recommendation': 'Link commits to goals to track progress and improve Say/Do Ratio accuracy',
            'action_url': '/goals',
            'count': len(goals_without_commits),
            'items': [{'id': g.id, 'title': g.title, 'deadline': g.deadline.isoformat()} for g in goals_without_commits[:5]]
        })
    
    # Manual entries without impact scope (for PayPal metrics)
    manual_entries_without_scope = db.query(ManualEntry).filter(
        ManualEntry.date >= start_date,
        ManualEntry.date <= end_date,
        ManualEntry.impact_scope == None,
        ManualEntry.impact.isnot(None)
    ).all()
    
    if manual_entries_without_scope:
        warnings.append({
            'type': 'manual_entry_no_impact_scope',
            'severity': 'low',
            'message': f"{len(manual_entries_without_scope)} manual entry/entries without impact scope classification",
            'recommendation': 'Classify impact scope (team vs org) to improve PayPal Promotion Readiness Score',
            'action_url': '/manual-entries',
            'count': len(manual_entries_without_scope),
            'items': [{'id': e.id, 'title': e.title, 'type': e.type} for e in manual_entries_without_scope[:5]]
        })
    
    # Goals approaching deadline without recent activity
    from datetime import datetime
    now = datetime.now()
    goals_at_risk = []
    for goal in active_goals:
        if goal.deadline <= now + timedelta(days=14):
            # Check for commits linked in last 5 days
            five_days_ago = now - timedelta(days=5)
            recent_links = db.query(GoalLink).filter(
                GoalLink.goal_id == goal.id,
                GoalLink.created_at >= five_days_ago
            ).count()
            if recent_links == 0:
                goals_at_risk.append(goal)
    
    if goals_at_risk:
        warnings.append({
            'type': 'goals_at_risk',
            'severity': 'high',
            'message': f"{len(goals_at_risk)} goal(s) approaching deadline without recent activity",
            'recommendation': 'Review goals and update status or increase effort to maintain Say/Do Ratio',
            'action_url': '/goals',
            'count': len(goals_at_risk),
            'items': [{'id': g.id, 'title': g.title, 'deadline': g.deadline.isoformat(), 'days_until': (g.deadline - now).days} for g in goals_at_risk[:5]]
        })
    
    return warnings

