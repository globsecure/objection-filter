from pydantic import BaseModel
from datetime import datetime
from typing import Optional, List, Dict, Any


class RepositoryBase(BaseModel):
    path: str
    name: str
    tags: Optional[str] = None
    team: Optional[str] = None


class RepositoryCreate(RepositoryBase):
    pass


class Repository(RepositoryBase):
    id: int
    last_scanned: datetime
    
    class Config:
        from_attributes = True


class RepositoryUpdate(BaseModel):
    tags: Optional[List[str]] = None
    team: Optional[str] = None


class CommitBase(BaseModel):
    hash: str
    message: str
    author: str
    date: datetime
    files_changed: int
    insertions: int
    deletions: int
    type: Optional[str] = None
    branch_name: Optional[str] = None
    is_merge_commit: Optional[bool] = False
    impact_category: Optional[str] = None


class CommitCreate(CommitBase):
    repo_id: int


class Commit(CommitBase):
    id: int
    repo_id: int
    
    class Config:
        from_attributes = True


class LogbookEntryBase(BaseModel):
    content: str
    date: Optional[datetime] = None


class LogbookEntryCreate(LogbookEntryBase):
    pass


class LogbookEntry(LogbookEntryBase):
    id: int
    
    class Config:
        from_attributes = True


class CrawlRequest(BaseModel):
    directory: Optional[str] = None
    months_back: int = 3
    auto_tags: Optional[bool] = True


class CommitFilter(BaseModel):
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    repo_id: Optional[int] = None
    commit_type: Optional[str] = None
    limit: int = 100
    offset: int = 0


class TaskBase(BaseModel):
    title: str
    description: Optional[str] = None
    status: Optional[str] = "todo"
    priority: Optional[str] = "medium"
    platform: Optional[str] = "manual"
    external_id: Optional[str] = None
    due_date: Optional[datetime] = None


class TaskCreate(TaskBase):
    pass


class TaskUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    priority: Optional[str] = None
    platform: Optional[str] = None
    external_id: Optional[str] = None
    due_date: Optional[datetime] = None


class Task(TaskBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True


# Daily Logs (Friction Tracking)
class DailyLogBase(BaseModel):
    date: Optional[datetime] = None
    satisfaction_score: int  # 1-10
    wellbeing_score: int  # 1-10
    blockers: Optional[str] = None


class DailyLogCreate(DailyLogBase):
    pass


class DailyLog(DailyLogBase):
    id: int
    created_at: datetime
    
    class Config:
        from_attributes = True


# Branch Metrics (DORA)
class BranchMetricBase(BaseModel):
    branch_name: str
    first_commit_date: datetime
    merge_date: Optional[datetime] = None
    merge_commit_hash: Optional[str] = None
    cycle_time_days: Optional[float] = None


class BranchMetricCreate(BranchMetricBase):
    repo_id: int


class BranchMetric(BranchMetricBase):
    id: int
    repo_id: int
    
    class Config:
        from_attributes = True


# DORA Metrics Response
class CycleTimeMetrics(BaseModel):
    average_days: float
    median_days: float
    min_days: float
    max_days: float
    total_branches: int
    trend: List[dict]


class DeploymentFrequency(BaseModel):
    total_deployments: int
    frequency_per_week: float
    frequency_per_month: float
    trend: List[dict]


class ChangeFailureRate(BaseModel):
    failure_rate: float
    total_deployments: int
    failed_deployments: int
    category: str
    incidents_count: int
    revert_commits_count: int


class MttrMetrics(BaseModel):
    mean_hours: float
    median_hours: float
    min_hours: float
    max_hours: float
    total_incidents: int
    resolved_incidents: int
    category: str


class DoraMetrics(BaseModel):
    deployment_frequency: DeploymentFrequency
    lead_time: CycleTimeMetrics
    change_failure_rate: ChangeFailureRate
    mttr: MttrMetrics


# SPACE Metrics Response
class FocusTimeBlock(BaseModel):
    start_hour: int
    end_hour: int
    commit_count: int
    is_deep_work: bool


class FlowScore(BaseModel):
    score: float  # 0-100
    deep_work_hours: float
    fragmentation_score: float
    optimal_hours: List[int]


class SatisfactionMetrics(BaseModel):
    average_satisfaction: float
    average_wellbeing: float
    trend: str
    low_weeks_count: int
    total_entries: int
    scores_over_time: List[dict]


class PerformanceMetrics(BaseModel):
    commits: int
    lines_changed: int
    net_change: int
    merge_commits: int
    code_reviews: int
    design_docs: int
    mentoring_sessions: int
    revert_rate: float
    quality_score: float


class ActivityMetrics(BaseModel):
    active_days: int
    active_days_pct: float
    avg_commits_per_day: float
    consistency_score: float
    longest_streak: int
    fragmentation_score: float
    total_commits: int


class CollaborationMetrics(BaseModel):
    code_reviews: int
    design_docs: int
    mentoring_sessions: int
    meetings: int
    unique_collaborators: int
    collaboration_score: float
    total_collaboration_activities: int


class SpaceMetrics(BaseModel):
    satisfaction: SatisfactionMetrics
    performance: PerformanceMetrics
    activity: ActivityMetrics
    collaboration: CollaborationMetrics
    efficiency: FlowScore


# Impact Categories
class ImpactCategoryDistribution(BaseModel):
    revenue_driving: int
    risk_reduction: int
    tech_debt: int
    unknown: int


# Health Trends
class HealthTrendPoint(BaseModel):
    date: str
    satisfaction_avg: float
    wellbeing_avg: float
    commit_count: int


# Friction Logs (Sprint 1)
class FrictionLogBase(BaseModel):
    date: datetime
    type: str  # 'blocker' | 'learning' | 'win' | 'incident'
    description: str
    impact_level: int  # 1-5 scale
    tags: Optional[str] = None
    resolution: Optional[str] = None


class FrictionLogCreate(FrictionLogBase):
    pass


class FrictionLogResponse(FrictionLogBase):
    id: int
    created_at: datetime
    
    class Config:
        from_attributes = True


# Manual Entries (Sprint 1)
class ManualEntryBase(BaseModel):
    date: datetime
    type: str  # 'code_review' | 'design_doc' | 'mentoring' | 'incident' | 'meeting'
    title: str
    description: Optional[str] = None
    impact: Optional[str] = None
    collaborators: Optional[str] = None
    links: Optional[str] = None
    duration_minutes: Optional[int] = None


class ManualEntryCreate(ManualEntryBase):
    pass


class ManualEntryResponse(ManualEntryBase):
    id: int
    created_at: datetime
    
    class Config:
        from_attributes = True


class ManualEntryUpdate(BaseModel):
    date: Optional[datetime] = None
    type: Optional[str] = None
    title: Optional[str] = None
    description: Optional[str] = None
    impact: Optional[str] = None
    collaborators: Optional[str] = None
    links: Optional[str] = None
    duration_minutes: Optional[int] = None


# Career Moments (Sprint 5)
class CareerMomentBase(BaseModel):
    date: datetime
    type: str  # win | failure | pivot | learning
    title: str
    story: Optional[str] = None
    impact: Optional[str] = None
    witnesses: Optional[str] = None
    tags: Optional[str] = None
    related_commits: Optional[List[int]] = None
    related_entries: Optional[List[int]] = None


class CareerMomentCreate(CareerMomentBase):
    pass


class CareerMomentUpdate(BaseModel):
    date: Optional[datetime] = None
    type: Optional[str] = None
    title: Optional[str] = None
    story: Optional[str] = None
    impact: Optional[str] = None
    witnesses: Optional[str] = None
    tags: Optional[str] = None
    related_commits: Optional[List[int]] = None
    related_entries: Optional[List[int]] = None


class CareerMoment(CareerMomentBase):
    id: int
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


# Goals & OKRs (Sprint 5)
class GoalBase(BaseModel):
    title: str
    description: Optional[str] = None
    deadline: datetime
    status: str = "active"
    progress: float = 0.0
    target_metric: Optional[str] = None
    current_metric: Optional[str] = None


class GoalCreate(GoalBase):
    pass


class GoalUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    deadline: Optional[datetime] = None
    status: Optional[str] = None
    progress: Optional[float] = None
    target_metric: Optional[str] = None
    current_metric: Optional[str] = None


class Goal(GoalBase):
    id: int
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class GoalLinkCreate(BaseModel):
    goal_id: int
    commit_id: Optional[int] = None
    entry_id: Optional[int] = None


# Peer Feedback (Sprint 5)
class FeedbackBase(BaseModel):
    from_who: str
    date: datetime
    context: Optional[str] = None
    feedback_text: str
    category: Optional[str] = None
    tags: Optional[str] = None


class FeedbackCreate(FeedbackBase):
    pass


class FeedbackUpdate(BaseModel):
    from_who: Optional[str] = None
    date: Optional[datetime] = None
    context: Optional[str] = None
    feedback_text: Optional[str] = None
    category: Optional[str] = None
    tags: Optional[str] = None


class Feedback(FeedbackBase):
    id: int
    created_at: datetime
    
    class Config:
        from_attributes = True


# Benchmark Models (Sprint 6)
class TeamBenchmarkBase(BaseModel):
    metric_name: str
    metric_value: float
    metric_unit: Optional[str] = None
    period_start: datetime
    period_end: datetime
    team_name: Optional[str] = None
    source: str = 'manual'
    notes: Optional[str] = None


class TeamBenchmarkCreate(TeamBenchmarkBase):
    pass


class TeamBenchmarkUpdate(BaseModel):
    metric_name: Optional[str] = None
    metric_value: Optional[float] = None
    metric_unit: Optional[str] = None
    period_start: Optional[datetime] = None
    period_end: Optional[datetime] = None
    team_name: Optional[str] = None
    source: Optional[str] = None
    notes: Optional[str] = None


class TeamBenchmark(TeamBenchmarkBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class IndustryBenchmarkBase(BaseModel):
    metric_name: str
    category: str  # elite | high | medium | low
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    source: str = 'dora'
    year: Optional[int] = None


class IndustryBenchmarkCreate(IndustryBenchmarkBase):
    pass


class IndustryBenchmark(IndustryBenchmarkBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True


class HistoricalSnapshotBase(BaseModel):
    period_label: str
    period_start: datetime
    period_end: datetime
    snapshot_data: Dict
    dora_metrics: Dict
    space_metrics: Dict


class HistoricalSnapshotCreate(BaseModel):
    period_label: str
    period_start: datetime
    period_end: datetime


class HistoricalSnapshot(HistoricalSnapshotBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True


class ComparisonResult(BaseModel):
    your_value: float
    team_average: Optional[float] = None
    team_percentile: Optional[float] = None  # 0-100
    industry_category: Optional[str] = None  # elite | high | medium | low
    industry_percentile: Optional[float] = None  # Estimated based on category
    trend: Optional[str] = None  # 'improving' | 'stable' | 'declining'
    trend_percentage: Optional[float] = None  # % change from previous period


# LLM Usage & Rate Limiting (Sprint 7)
class LLMUsageStats(BaseModel):
    total_requests: int
    successful_requests: int
    failed_requests: int
    total_input_tokens: int
    total_output_tokens: int
    total_tokens: int
    total_cost_usd: float
    avg_duration_ms: float
    by_operation: Dict[str, Dict[str, float]]
    by_provider: Dict[str, Dict[str, float]]


class RateLimitStatus(BaseModel):
    providers: List[Dict[str, Any]]
    message: Optional[str] = None


class RateLimitUpdate(BaseModel):
    provider: str
    requests_per_minute: Optional[int] = None
    tokens_per_minute: Optional[int] = None
    requests_per_day: Optional[int] = None


# Saved Reports (Sprint 7)
class SavedReportCreate(BaseModel):
    name: str
    period_start: datetime
    period_end: datetime
    quarter: Optional[str] = None
    repo_id: Optional[int] = None
    tags: Optional[str] = None
    notes: Optional[str] = None


class SavedReportUpdate(BaseModel):
    name: Optional[str] = None
    tags: Optional[str] = None
    notes: Optional[str] = None


class SavedReport(BaseModel):
    id: int
    name: str
    period_start: datetime
    period_end: datetime
    quarter: Optional[str] = None
    repo_id: Optional[int] = None
    tags: Optional[str] = None
    notes: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class UserContextSchema(BaseModel):
    user_id: str
    role: Optional[str] = None
    team: Optional[str] = None
    business_domain: Optional[str] = None
    company: Optional[str] = None
    preferred_language: str = "en"
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True


class UserContextUpdate(BaseModel):
    role: Optional[str] = None
    team: Optional[str] = None
    business_domain: Optional[str] = None
    company: Optional[str] = None
    preferred_language: Optional[str] = None


class ReportComparison(BaseModel):
    reports: List[Dict[str, Any]]
    comparison_summary: Dict[str, Any]


class ReportTemplateConfigSchema(BaseModel):
    id: int
    name: str
    description: Optional[str] = None
    template_type: str
    sections: List[str]
    prompt_overrides: Optional[Dict[str, str]] = None
    is_default: bool
    user_id: str
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True


class ReportTemplateConfigCreate(BaseModel):
    name: str
    description: Optional[str] = None
    template_type: str
    sections: List[str]
    prompt_overrides: Optional[Dict[str, str]] = None


class ReportTemplateConfigUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    template_type: Optional[str] = None
    sections: Optional[List[str]] = None
    prompt_overrides: Optional[Dict[str, str]] = None
    is_default: Optional[bool] = None


class ReportEditRequest(BaseModel):
    section: str
    edited_content: str


class ReportVersionResponse(BaseModel):
    original: Dict[str, Any]
    current: Dict[str, Any]
    edited_sections: Dict[str, Any]
    edit_count: int

