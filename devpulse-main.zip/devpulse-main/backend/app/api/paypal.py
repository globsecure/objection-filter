from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from datetime import datetime
from typing import Optional
from ..database import get_db
from ..analysis.paypal_metrics import (
    calculate_say_do_ratio,
    get_risk_radar,
    get_cross_team_work_percentage,
    count_distinct_mentees,
    analyze_code_review_depth,
    calculate_promotion_readiness
)
from ..analysis.impact_labeling import auto_label_impact_scope

router = APIRouter(prefix="/api/paypal", tags=["paypal"])


@router.get("/say-do-ratio")
def get_say_do_ratio(
    quarter_start: Optional[datetime] = Query(None),
    quarter_end: Optional[datetime] = Query(None),
    db: Session = Depends(get_db)
):
    """Get Say/Do Ratio for goals in a quarter"""
    return calculate_say_do_ratio(db, quarter_start, quarter_end)


@router.get("/risk-radar")
def get_risk_radar_endpoint(
    days_ahead: int = Query(14, ge=1, le=90),
    db: Session = Depends(get_db)
):
    """Get goals at risk of missing deadline"""
    return get_risk_radar(db, days_ahead)


@router.get("/cross-team-work")
def get_cross_team_work(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    db: Session = Depends(get_db)
):
    """Get cross-team work percentage"""
    return get_cross_team_work_percentage(db, start_date, end_date)


@router.get("/mentees")
def get_mentees(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    db: Session = Depends(get_db)
):
    """Get distinct mentees count"""
    return count_distinct_mentees(db, start_date, end_date)


@router.get("/code-review-depth")
def get_code_review_depth(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    db: Session = Depends(get_db)
):
    """Analyze code review depth"""
    return analyze_code_review_depth(db, start_date, end_date)


@router.get("/promotion-readiness")
def get_promotion_readiness(
    quarter_start: Optional[datetime] = Query(None),
    quarter_end: Optional[datetime] = Query(None),
    db: Session = Depends(get_db)
):
    """Calculate Promotion Readiness Score"""
    return calculate_promotion_readiness(db, quarter_start, quarter_end)


@router.post("/label-impact/{entry_id}")
def label_impact_scope(
    entry_id: int,
    user_id: str = Query("default"),
    db: Session = Depends(get_db)
):
    """Auto-label impact scope for a ManualEntry"""
    scope = auto_label_impact_scope(entry_id, db, user_id)
    if scope:
        return {"entry_id": entry_id, "impact_scope": scope, "success": True}
    else:
        return {"entry_id": entry_id, "impact_scope": None, "success": False, "message": "Could not classify impact scope"}

