from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional
from datetime import datetime

from ..database import get_db
from ..analysis.dora_metrics import (
    calculate_cycle_time,
    calculate_deployment_frequency,
    calculate_change_failure_rate,
    calculate_mttr,
    get_branch_metrics_list,
    get_cycle_time_distribution,
    get_dora_metrics
)
from ..analysis.aggregation import aggregate_dora_metrics
from typing import List

router = APIRouter()


@router.get("/cycle-time")
def get_cycle_time(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get cycle time metrics for merged branches.
    """
    return calculate_cycle_time(db, start_date, end_date, repo_id)


@router.get("/deployment-frequency")
def get_deployment_frequency(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get deployment frequency metrics (merges to main branch).
    """
    return calculate_deployment_frequency(db, start_date, end_date, repo_id)


@router.get("/branch-metrics")
def get_branch_metrics(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_id: Optional[int] = Query(None),
    limit: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db)
):
    """
    Get detailed branch metrics list.
    """
    return get_branch_metrics_list(db, start_date, end_date, repo_id, limit)


@router.get("/cycle-time-distribution")
def get_cycle_time_dist(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get cycle time distribution for histogram visualization.
    """
    return get_cycle_time_distribution(db, start_date, end_date, repo_id)


@router.get("/change-failure-rate")
def get_change_failure_rate(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get Change Failure Rate metric.
    """
    return calculate_change_failure_rate(db, start_date, end_date, repo_id)


@router.get("/mttr")
def get_mttr(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get Mean Time to Recovery (MTTR) metric.
    """
    return calculate_mttr(db, start_date, end_date, repo_id)


@router.get("/summary")
def get_dora_summary(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get complete DORA metrics summary (all 4 metrics).
    """
    return get_dora_metrics(db, start_date, end_date, repo_id)


@router.get("/trends")
def get_dora_trends(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_id: Optional[int] = Query(None),
    group_by: str = Query("week"),  # day, week, month
    db: Session = Depends(get_db)
):
    """
    Get DORA metrics trends over time.
    """
    from datetime import timedelta
    
    if not start_date or not end_date:
        # Default to last 3 months if not provided
        end_date = datetime.now()
        start_date = end_date - timedelta(days=90)
    
    # Get metrics for each period
    trends = []
    current_start = start_date
    
    while current_start < end_date:
        if group_by == "day":
            period_end = min(current_start + timedelta(days=1), end_date)
            period_label = current_start.strftime('%Y-%m-%d')
        elif group_by == "month":
            # Move to start of next month
            if current_start.month == 12:
                period_end = datetime(current_start.year + 1, 1, 1)
            else:
                period_end = datetime(current_start.year, current_start.month + 1, 1)
            period_end = min(period_end, end_date)
            period_label = current_start.strftime('%Y-%m')
        else:  # week
            period_end = min(current_start + timedelta(days=7), end_date)
            period_label = current_start.strftime('%Y-W%W')
        
        metrics = get_dora_metrics(db, current_start, period_end, repo_id)
        trends.append({
            'period': period_label,
            'deployment_frequency': metrics['deployment_frequency']['frequency_per_week'],
            'lead_time': metrics['lead_time']['average_days'],
            'change_failure_rate': metrics['change_failure_rate']['failure_rate'],
            'mttr': metrics['mttr']['mean_hours']
        })
        
        current_start = period_end
    
    return {
        'group_by': group_by,
        'trends': trends
    }


@router.get("/compare")
def compare_dora_periods(
    period1_start: datetime = Query(...),
    period1_end: datetime = Query(...),
    period2_start: datetime = Query(...),
    period2_end: datetime = Query(...),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Compare DORA metrics between two periods.
    """
    period1_metrics = get_dora_metrics(db, period1_start, period1_end, repo_id)
    period2_metrics = get_dora_metrics(db, period2_start, period2_end, repo_id)
    
    def calculate_change(old_val, new_val):
        if old_val == 0:
            return 0.0 if new_val == 0 else 100.0
        return round(((new_val - old_val) / old_val) * 100, 2)
    
    return {
        'period1': {
            'start': period1_start.isoformat(),
            'end': period1_end.isoformat(),
            'metrics': period1_metrics
        },
        'period2': {
            'start': period2_start.isoformat(),
            'end': period2_end.isoformat(),
            'metrics': period2_metrics
        },
        'changes': {
            'deployment_frequency': calculate_change(
                period1_metrics['deployment_frequency']['frequency_per_week'],
                period2_metrics['deployment_frequency']['frequency_per_week']
            ),
            'lead_time': calculate_change(
                period1_metrics['lead_time']['average_days'],
                period2_metrics['lead_time']['average_days']
            ),
            'change_failure_rate': calculate_change(
                period1_metrics['change_failure_rate']['failure_rate'],
                period2_metrics['change_failure_rate']['failure_rate']
            ),
            'mttr': calculate_change(
                period1_metrics['mttr']['mean_hours'],
                period2_metrics['mttr']['mean_hours']
            )
        }
    }


@router.get("/aggregate")
def get_aggregated_dora_metrics(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_ids: Optional[List[int]] = Query(None),
    tags: Optional[List[str]] = Query(None),
    team: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get aggregated DORA metrics across multiple repositories.
    Filter by repository IDs, tags, or team.
    """
    return aggregate_dora_metrics(
        db,
        repo_ids=repo_ids,
        tags=tags,
        team=team,
        start_date=start_date,
        end_date=end_date
    )

