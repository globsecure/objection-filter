from fastapi import APIRouter, Depends, HTTPException, Response, Query, Body
from sqlalchemy.orm import Session
from typing import Optional
from datetime import datetime
from pydantic import BaseModel
import json

from ..database import get_db
from ..models import Commit, SavedReport
from ..schemas import SavedReportCreate, SavedReportUpdate, ReportEditRequest, ReportVersionResponse
from ..analysis.llm_service import get_llm_provider
from ..analysis.impact_categorizer import get_impact_summary
from ..analysis.dora_metrics import get_dora_metrics
from ..analysis.space_metrics import get_space_metrics
from ..services.report_generator import (
    generate_manager_report,
    generate_pdf_report,
    aggregate_report_data,
    ReportTemplate
)

router = APIRouter()


class ReportRequest(BaseModel):
    start_date: datetime
    end_date: datetime
    repo_id: Optional[int] = None
    include_metrics: Optional[bool] = True
    use_llm: Optional[bool] = True
    format: Optional[str] = "json"  # json, markdown, pdf
    redact_sensitive: Optional[bool] = False  # Redact sensitive information before sending to LLM
    template_id: Optional[int] = None
    template_type: Optional[str] = "performance_review"
    user_id: Optional[str] = "default"
    language: Optional[str] = None  # Override user preference


@router.post("/generate")
def generate_report(
    request: ReportRequest,
    db: Session = Depends(get_db)
):
    """
    Generate manager report in requested format.
    """
    try:
        report = generate_manager_report(
            db,
            request.start_date,
            request.end_date,
            request.repo_id,
            request.use_llm,
            request.redact_sensitive,
            request.template_id,
            request.template_type or "performance_review",
            request.user_id or "default",
            request.language
        )
        
        if request.format == "markdown":
            return {
                "format": "markdown",
                "content": report.to_markdown(),
                "metadata": report.to_dict()['data_summary']
            }
        elif request.format == "pdf":
            pdf_bytes = generate_pdf_report(
                db,
                request.start_date,
                request.end_date,
                request.repo_id,
                request.use_llm,
                request.redact_sensitive
            )
            return Response(
                content=pdf_bytes,
                media_type="application/pdf",
                headers={
                    "Content-Disposition": f"attachment; filename=devpulse_report_{request.start_date.date()}_to_{request.end_date.date()}.pdf"
                }
            )
        else:  # json
            return {
                "format": "json",
                "report": report.to_dict()
            }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating report: {str(e)}")


@router.post("/preview")
def preview_report(
    request: ReportRequest,
    db: Session = Depends(get_db)
):
    """
    Preview report data without generating full report (faster).
    """
    try:
        data = aggregate_report_data(
            db,
            request.start_date,
            request.end_date,
            request.repo_id
        )
        
        return {
            "data_summary": data['stats'],
            "sample_commits": len(data['commits'][:5]),
            "sample_friction": len(data['friction_logs'][:5]),
            "sample_manual": len(data['manual_entries'][:5]),
            "will_include_llm": request.use_llm
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error previewing report: {str(e)}")


@router.post("/pdf")
def generate_pdf_report_endpoint(
    request: ReportRequest,
    db: Session = Depends(get_db)
):
    """
    Generate PDF report for performance review (legacy endpoint, use /generate with format=pdf).
    """
    try:
        pdf_bytes = generate_pdf_report(
            db,
            request.start_date,
            request.end_date,
            request.repo_id,
            request.use_llm if hasattr(request, 'use_llm') else True,
            request.redact_sensitive if hasattr(request, 'redact_sensitive') else False
        )
        
        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={
                "Content-Disposition": f"attachment; filename=devpulse_report_{request.start_date.date()}_to_{request.end_date.date()}.pdf"
            }
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating PDF: {str(e)}")


def _generate_quarter(start_date: datetime, end_date: datetime) -> str:
    """Generate quarter identifier from date range"""
    year = start_date.year
    if start_date.month <= 3:
        quarter = "Q1"
    elif start_date.month <= 6:
        quarter = "Q2"
    elif start_date.month <= 9:
        quarter = "Q3"
    else:
        quarter = "Q4"
    
    return f"{quarter}-{year}"


def _generate_comparison_summary(comparisons: list) -> dict:
    """Generate summary comparing multiple reports"""
    if len(comparisons) < 2:
        return {}
    
    # Extract key metrics for comparison
    dora_metrics = []
    space_scores = []
    
    for comp in comparisons:
        dora = comp['metrics'].get('dora', {})
        space = comp['metrics'].get('space', {})
        
        if dora:
            dora_metrics.append({
                'quarter': comp['quarter'],
                'deployment_frequency': dora.get('deployment_frequency', {}).get('per_week', 0),
                'lead_time_days': dora.get('lead_time', {}).get('avg_days', 0)
            })
        
        if space:
            # Calculate overall SPACE score
            scores = space.get('satisfaction', {}).get('average_satisfaction', 0)
            space_scores.append({
                'quarter': comp['quarter'],
                'satisfaction': scores
            })
    
    return {
        'dora_trends': dora_metrics,
        'space_trends': space_scores,
        'improvements': _identify_improvements(dora_metrics, space_scores)
    }


def _identify_improvements(dora_metrics: list, space_scores: list) -> list:
    """Identify improvements across quarters"""
    improvements = []
    
    if len(dora_metrics) >= 2:
        # Compare deployment frequency
        latest = dora_metrics[-1]
        previous = dora_metrics[-2]
        
        if latest['deployment_frequency'] > previous['deployment_frequency']:
            improvements.append({
                'metric': 'deployment_frequency',
                'change': f"+{latest['deployment_frequency'] - previous['deployment_frequency']:.1f} per week",
                'trend': 'improving'
            })
    
    return improvements


@router.post("/save")
def save_report(
    request: ReportRequest,
    name: str = Query(..., description="Report name"),
    quarter: Optional[str] = Query(None, description="Quarter identifier (e.g., Q1-2025)"),
    tags: Optional[str] = Query(None, description="Comma-separated tags"),
    notes: Optional[str] = Query(None, description="User notes"),
    db: Session = Depends(get_db)
):
    """Save a generated report for future reference"""
    try:
        # Generate report
        report = generate_manager_report(
            db,
            request.start_date,
            request.end_date,
            request.repo_id,
            request.use_llm,
            getattr(request, 'redact_sensitive', False),
            request.template_id,
            request.template_type or "performance_review",
            request.user_id or "default",
            request.language
        )
        
        # Save to database
        report_dict = report.to_dict()
        saved_report = SavedReport(
            name=name,
            period_start=request.start_date,
            period_end=request.end_date,
            quarter=quarter or _generate_quarter(request.start_date, request.end_date),
            report_data=json.dumps(report_dict),
            markdown_content=report.to_markdown(),
            repo_id=request.repo_id,
            tags=tags,
            notes=notes,
            original_report_data=json.dumps(report_dict),  # Store original for comparison
            template_id=request.template_id
        )
        db.add(saved_report)
        db.commit()
        db.refresh(saved_report)
        
        return {
            "id": saved_report.id,
            "name": saved_report.name,
            "quarter": saved_report.quarter,
            "created_at": saved_report.created_at.isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error saving report: {str(e)}")


@router.get("/saved")
def list_saved_reports(
    quarter: Optional[str] = Query(None),
    repo_id: Optional[int] = Query(None),
    limit: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """List all saved reports"""
    query = db.query(SavedReport)
    
    if quarter:
        query = query.filter(SavedReport.quarter == quarter)
    if repo_id:
        query = query.filter(SavedReport.repo_id == repo_id)
    
    reports = query.order_by(SavedReport.created_at.desc()).limit(limit).all()
    
    return [
        {
            "id": r.id,
            "name": r.name,
            "quarter": r.quarter,
            "period_start": r.period_start.isoformat(),
            "period_end": r.period_end.isoformat(),
            "tags": r.tags.split(",") if r.tags else [],
            "created_at": r.created_at.isoformat()
        }
        for r in reports
    ]


@router.get("/saved/{report_id}")
def get_saved_report(
    report_id: int,
    format: str = Query("json", regex="^(json|markdown)$"),
    db: Session = Depends(get_db)
):
    """Retrieve a saved report"""
    report = db.query(SavedReport).filter(SavedReport.id == report_id).first()
    
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    
    if format == "markdown":
        return {
            "format": "markdown",
            "content": report.markdown_content,
            "metadata": {
                "id": report.id,
                "name": report.name,
                "quarter": report.quarter,
                "created_at": report.created_at.isoformat()
            }
        }
    else:
        return {
            "format": "json",
            "report": json.loads(report.report_data),
            "metadata": {
                "id": report.id,
                "name": report.name,
                "quarter": report.quarter,
                "created_at": report.created_at.isoformat()
            }
        }


@router.delete("/saved/{report_id}")
def delete_saved_report(
    report_id: int,
    db: Session = Depends(get_db)
):
    """Delete a saved report"""
    report = db.query(SavedReport).filter(SavedReport.id == report_id).first()
    
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    
    db.delete(report)
    db.commit()
    
    return {"message": "Report deleted successfully"}


@router.get("/saved/compare")
def compare_reports(
    report_ids: str = Query(..., description="Comma-separated report IDs"),
    db: Session = Depends(get_db)
):
    """Compare multiple saved reports"""
    ids = [int(id.strip()) for id in report_ids.split(",")]
    reports = db.query(SavedReport).filter(SavedReport.id.in_(ids)).all()
    
    if len(reports) != len(ids):
        raise HTTPException(status_code=404, detail="One or more reports not found")
    
    # Extract metrics for comparison
    comparisons = []
    for report in reports:
        data = json.loads(report.report_data)
        metrics = data.get('metrics_snapshot', {})
        
        comparisons.append({
            "id": report.id,
            "name": report.name,
            "quarter": report.quarter,
            "period": {
                "start": report.period_start.isoformat(),
                "end": report.period_end.isoformat()
            },
            "metrics": {
                "dora": metrics.get('dora', {}),
                "space": metrics.get('space', {}),
                "summary": data.get('data_summary', {})
            }
        })
    
    return {
        "reports": comparisons,
        "comparison_summary": _generate_comparison_summary(comparisons)
    }


@router.post("/{report_id}/edit")
def edit_report_section(
    report_id: int,
    edit_request: ReportEditRequest = Body(...),
    db: Session = Depends(get_db)
):
    """
    Edit a specific section of a saved report.
    
    Args:
        report_id: ID of saved report
        edit_request: Request body with section name and edited content
    """
    report = db.query(SavedReport).filter(SavedReport.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    
    # Parse report data
    report_data = json.loads(report.report_data)
    
    # Get original data if available, otherwise use current as original
    if report.original_report_data:
        original_data = json.loads(report.original_report_data)
    else:
        original_data = report_data.copy()
        report.original_report_data = json.dumps(original_data)
    
    # Update section
    section = edit_request.section
    report_data[section] = edit_request.edited_content
    
    # Track edited sections
    edited_sections = json.loads(report.edited_sections) if report.edited_sections else {}
    edited_sections[section] = {
        "edited_at": datetime.now().isoformat(),
        "original": original_data.get(section, ""),
        "edited": edit_request.edited_content
    }
    
    # Save updated report
    report.report_data = json.dumps(report_data)
    report.edited_sections = json.dumps(edited_sections)
    report.updated_at = datetime.now()
    db.commit()
    
    return {"message": "Section updated", "section": section}


@router.get("/{report_id}/versions")
def get_report_versions(
    report_id: int,
    db: Session = Depends(get_db)
):
    """Get comparison of original vs edited report"""
    report = db.query(SavedReport).filter(SavedReport.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    
    report_data = json.loads(report.report_data)
    original_data = json.loads(report.original_report_data) if report.original_report_data else report_data
    edited_sections = json.loads(report.edited_sections) if report.edited_sections else {}
    
    return {
        "original": original_data,
        "current": report_data,
        "edited_sections": edited_sections,
        "edit_count": len(edited_sections)
    }

