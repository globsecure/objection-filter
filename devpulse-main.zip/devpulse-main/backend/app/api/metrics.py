from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import Optional, List, Dict
from datetime import datetime

from ..database import get_db
from ..models import Commit, Repository
from ..analysis.metrics import calculate_code_churn, calculate_consistency, get_cross_team_impact

router = APIRouter()


@router.get("/churn")
def get_churn_metrics(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get code churn metrics over time.
    """
    return calculate_code_churn(db, start_date, end_date)


@router.get("/consistency")
def get_consistency_metrics(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get delivery consistency metrics.
    """
    return calculate_consistency(db, start_date, end_date)


@router.get("/cross-team")
def get_cross_team_impact_commits(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get commits with cross-team impact.
    """
    return get_cross_team_impact(db, start_date, end_date)


@router.get("/commit-types")
def get_commit_types_distribution(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get distribution of commit types (Feature, Bugfix, etc.).
    """
    query = db.query(
        Commit.type,
        func.count(Commit.id).label('count')
    ).group_by(Commit.type)
    
    if start_date:
        query = query.filter(Commit.date >= start_date)
    if end_date:
        query = query.filter(Commit.date <= end_date)
    
    results = query.all()
    
    return [
        {
            'type': row.type or 'Unknown',
            'count': row.count
        }
        for row in results
    ]


@router.get("/repository-stats")
def get_repository_stats(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get commit statistics per repository.
    """
    query = db.query(
        Repository.id,
        Repository.name,
        func.count(Commit.id).label('commit_count'),
        func.sum(Commit.insertions + Commit.deletions).label('total_changes')
    ).join(Commit, Repository.id == Commit.repo_id, isouter=True)
    
    if start_date:
        query = query.filter(Commit.date >= start_date)
    if end_date:
        query = query.filter(Commit.date <= end_date)
    
    query = query.group_by(Repository.id, Repository.name)
    results = query.all()
    
    return [
        {
            'repository_id': row.id,
            'repository_name': row.name,
            'commit_count': row.commit_count or 0,
            'total_changes': row.total_changes or 0
        }
        for row in results
    ]


@router.get("/trends")
def get_commit_trends(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    group_by: str = Query("day", regex="^(day|week|month)$"),
    db: Session = Depends(get_db)
):
    """
    Get commit trends over time grouped by day, week, or month.
    """
    base_query = db.query(Commit)
    
    if start_date:
        base_query = base_query.filter(Commit.date >= start_date)
    if end_date:
        base_query = base_query.filter(Commit.date <= end_date)
    
    # Use SQLite-compatible date formatting
    if group_by == "day":
        date_expr = func.date(Commit.date)
    elif group_by == "week":
        # SQLite: strftime('%Y-W%W', date) groups by week
        date_expr = func.strftime('%Y-W%W', Commit.date)
    else:  # month
        # SQLite: strftime('%Y-%m', date) groups by month
        date_expr = func.strftime('%Y-%m', Commit.date)
    
    query = base_query.with_entities(
        date_expr.label('period'),
        func.count(Commit.id).label('commit_count'),
        func.sum(Commit.insertions).label('insertions'),
        func.sum(Commit.deletions).label('deletions')
    ).group_by('period').order_by('period')
    
    results = query.all()
    
    return [
        {
            'period': row.period.isoformat() if isinstance(row.period, datetime) else str(row.period),
            'commit_count': row.commit_count or 0,
            'insertions': row.insertions or 0,
            'deletions': row.deletions or 0
        }
        for row in results
    ]

