from fastapi import APIRouter, Depends, Query, Body
from sqlalchemy.orm import Session
from typing import Optional
from datetime import datetime
from pydantic import BaseModel

from ..database import get_db
from ..analysis.commit_quality import score_commit_message
from ..analysis.data_quality import calculate_data_completeness

router = APIRouter()


class CommitScoreRequest(BaseModel):
    message: str


@router.post("/commit-score")
def score_commit(
    request: CommitScoreRequest
):
    """
    Score a commit message for quality (0-100).
    """
    return score_commit_message(request.message)


@router.get("/completeness")
def get_data_completeness(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Calculate data completeness metrics.
    """
    return calculate_data_completeness(db, start_date, end_date, repo_id)

