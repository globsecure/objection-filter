from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from ..database import get_db
from ..models import ReportTemplateConfig
from ..schemas import ReportTemplateConfigSchema, ReportTemplateConfigCreate, ReportTemplateConfigUpdate
from ..services.template_service import TemplateService

router = APIRouter()


@router.get("/report-templates")
def list_templates(
    user_id: str = "default",
    db: Session = Depends(get_db)
):
    """List all templates for user"""
    template_service = TemplateService(db)
    templates = template_service.list_templates(user_id)
    
    return [
        {
            "id": t.id,
            "name": t.name,
            "description": t.description,
            "template_type": t.template_type,
            "sections": template_service.get_template_sections(t),
            "prompt_overrides": template_service.get_prompt_overrides(t),
            "is_default": t.is_default,
            "created_at": t.created_at.isoformat() if t.created_at else None,
            "updated_at": t.updated_at.isoformat() if t.updated_at else None
        }
        for t in templates
    ]


@router.get("/report-templates/{template_id}")
def get_template(
    template_id: int,
    user_id: str = "default",
    db: Session = Depends(get_db)
):
    """Get template details"""
    template_service = TemplateService(db)
    template = template_service.get_template(template_id, user_id)
    
    if not template:
        raise HTTPException(status_code=404, detail="Template not found")
    
    return {
        "id": template.id,
        "name": template.name,
        "description": template.description,
        "template_type": template.template_type,
        "sections": template_service.get_template_sections(template),
        "prompt_overrides": template_service.get_prompt_overrides(template),
        "is_default": template.is_default,
        "created_at": template.created_at.isoformat() if template.created_at else None,
        "updated_at": template.updated_at.isoformat() if template.updated_at else None
    }


@router.post("/report-templates")
def create_template(
    template: ReportTemplateConfigCreate,
    user_id: str = "default",
    db: Session = Depends(get_db)
):
    """Create custom template"""
    template_service = TemplateService(db)
    
    new_template = template_service.create_template(
        name=template.name,
        description=template.description,
        template_type=template.template_type,
        sections=template.sections,
        prompt_overrides=template.prompt_overrides,
        user_id=user_id
    )
    
    return {
        "id": new_template.id,
        "name": new_template.name,
        "description": new_template.description,
        "template_type": new_template.template_type,
        "sections": template_service.get_template_sections(new_template),
        "prompt_overrides": template_service.get_prompt_overrides(new_template),
        "is_default": new_template.is_default,
        "created_at": new_template.created_at.isoformat() if new_template.created_at else None
    }


@router.put("/report-templates/{template_id}")
def update_template(
    template_id: int,
    update: ReportTemplateConfigUpdate,
    user_id: str = "default",
    db: Session = Depends(get_db)
):
    """Update template"""
    template_service = TemplateService(db)
    template = template_service.get_template(template_id, user_id)
    
    if not template:
        raise HTTPException(status_code=404, detail="Template not found")
    
    import json
    update_dict = update.dict(exclude_unset=True)
    
    if "sections" in update_dict:
        template.sections = json.dumps(update_dict["sections"])
    if "prompt_overrides" in update_dict:
        template.prompt_overrides = json.dumps(update_dict["prompt_overrides"]) if update_dict["prompt_overrides"] else None
    
    for key, value in update_dict.items():
        if key not in ["sections", "prompt_overrides"] and hasattr(template, key):
            setattr(template, key, value)
    
    db.commit()
    db.refresh(template)
    
    return {
        "id": template.id,
        "name": template.name,
        "description": template.description,
        "template_type": template.template_type,
        "sections": template_service.get_template_sections(template),
        "prompt_overrides": template_service.get_prompt_overrides(template),
        "is_default": template.is_default,
        "updated_at": template.updated_at.isoformat() if template.updated_at else None
    }


@router.delete("/report-templates/{template_id}")
def delete_template(
    template_id: int,
    user_id: str = "default",
    db: Session = Depends(get_db)
):
    """Delete template"""
    template_service = TemplateService(db)
    template = template_service.get_template(template_id, user_id)
    
    if not template:
        raise HTTPException(status_code=404, detail="Template not found")
    
    db.delete(template)
    db.commit()
    
    return {"message": "Template deleted successfully"}

