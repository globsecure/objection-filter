from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import Optional, List
from datetime import datetime
from pydantic import BaseModel

from ..database import get_db
from ..models import DailyLog, Commit, FrictionLog
from ..schemas import DailyLog as DailyLogSchema, DailyLogCreate, FrictionLogCreate, FrictionLogResponse
from collections import Counter

router = APIRouter()


# FrictionLog endpoints (Sprint 1)
@router.post("/", response_model=FrictionLogResponse)
def create_friction_log(
    friction: FrictionLogCreate,
    db: Session = Depends(get_db)
):
    """
    Create a friction log entry (blocker/learning/win/incident).
    """
    if friction.impact_level < 1 or friction.impact_level > 5:
        raise HTTPException(status_code=400, detail="Impact level must be between 1 and 5")
    
    if friction.type not in ['blocker', 'learning', 'win', 'incident']:
        raise HTTPException(status_code=400, detail="Type must be one of: blocker, learning, win, incident")
    
    db_friction = FrictionLog(**friction.model_dump())
    db.add(db_friction)
    db.commit()
    db.refresh(db_friction)
    return db_friction


@router.get("/", response_model=List[FrictionLogResponse])
def get_friction_logs(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    type: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get friction logs with optional filters.
    """
    query = db.query(FrictionLog)
    
    if start_date:
        query = query.filter(FrictionLog.date >= start_date)
    if end_date:
        query = query.filter(FrictionLog.date <= end_date)
    if type:
        query = query.filter(FrictionLog.type == type)
    
    return query.order_by(FrictionLog.date.desc()).all()


@router.get("/stats")
def get_friction_stats(
    days: int = Query(30, ge=1, le=365),
    db: Session = Depends(get_db)
):
    """
    Get friction statistics for the specified number of days.
    """
    from datetime import timedelta
    start = datetime.now() - timedelta(days=days)
    logs = db.query(FrictionLog).filter(FrictionLog.date >= start).all()
    
    types_count = Counter(log.type for log in logs)
    
    return {
        "total": len(logs),
        "by_type": dict(types_count),
        "avg_impact": sum(log.impact_level for log in logs) / len(logs) if logs else 0,
        "unresolved": len([log for log in logs if not log.resolution])
    }


# DailyLog endpoints (existing - keep for backward compatibility)
@router.post("/log", response_model=DailyLogSchema)
def create_daily_log(
    log: DailyLogCreate,
    db: Session = Depends(get_db)
):
    """
    Create a daily friction/health log entry.
    """
    if not 1 <= log.satisfaction_score <= 10:
        raise HTTPException(status_code=400, detail="Satisfaction score must be between 1 and 10")
    if not 1 <= log.wellbeing_score <= 10:
        raise HTTPException(status_code=400, detail="Wellbeing score must be between 1 and 10")
    
    db_log = DailyLog(
        date=log.date or datetime.now(),
        satisfaction_score=log.satisfaction_score,
        wellbeing_score=log.wellbeing_score,
        blockers=log.blockers
    )
    db.add(db_log)
    db.commit()
    db.refresh(db_log)
    return db_log


@router.get("/logs", response_model=List[DailyLogSchema])
def list_daily_logs(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    limit: int = Query(30, ge=1, le=365),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db)
):
    """
    List daily logs with optional date filtering.
    """
    query = db.query(DailyLog)
    
    if start_date:
        query = query.filter(DailyLog.date >= start_date)
    if end_date:
        query = query.filter(DailyLog.date <= end_date)
    
    return query.order_by(DailyLog.date.desc()).offset(offset).limit(limit).all()


@router.get("/logs/{log_id}", response_model=DailyLogSchema)
def get_daily_log(
    log_id: int,
    db: Session = Depends(get_db)
):
    """
    Get a specific daily log entry.
    """
    log = db.query(DailyLog).filter(DailyLog.id == log_id).first()
    if not log:
        raise HTTPException(status_code=404, detail="Log not found")
    return log


@router.delete("/logs/{log_id}")
def delete_daily_log(
    log_id: int,
    db: Session = Depends(get_db)
):
    """
    Delete a daily log entry.
    """
    log = db.query(DailyLog).filter(DailyLog.id == log_id).first()
    if not log:
        raise HTTPException(status_code=404, detail="Log not found")
    
    db.delete(log)
    db.commit()
    return {"message": "Log deleted successfully"}


@router.get("/health-trends")
def get_health_trends(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get health score trends over time with commit correlation.
    """
    query = db.query(
        func.date(DailyLog.date).label('date'),
        func.avg(DailyLog.satisfaction_score).label('satisfaction_avg'),
        func.avg(DailyLog.wellbeing_score).label('wellbeing_avg')
    ).group_by(func.date(DailyLog.date))
    
    if start_date:
        query = query.filter(DailyLog.date >= start_date)
    if end_date:
        query = query.filter(DailyLog.date <= end_date)
    
    results = query.order_by('date').all()
    
    # Get commit counts per day for correlation
    commit_query = db.query(
        func.date(Commit.date).label('date'),
        func.count(Commit.id).label('commit_count')
    ).group_by(func.date(Commit.date))
    
    if start_date:
        commit_query = commit_query.filter(Commit.date >= start_date)
    if end_date:
        commit_query = commit_query.filter(Commit.date <= end_date)
    
    commit_results = {
        str(r.date): r.commit_count
        for r in commit_query.all()
    }
    
    return [
        {
            'date': str(row.date),
            'satisfaction_avg': round(row.satisfaction_avg, 1) if row.satisfaction_avg else 0,
            'wellbeing_avg': round(row.wellbeing_avg, 1) if row.wellbeing_avg else 0,
            'commit_count': commit_results.get(str(row.date), 0)
        }
        for row in results
    ]


@router.get("/blocker-analysis")
def analyze_blockers(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Analyze most common blockers from daily logs.
    """
    query = db.query(DailyLog).filter(DailyLog.blockers.isnot(None))
    
    if start_date:
        query = query.filter(DailyLog.date >= start_date)
    if end_date:
        query = query.filter(DailyLog.date <= end_date)
    
    logs = query.all()
    
    # Simple keyword extraction for blockers
    blocker_keywords = {}
    common_blockers = [
        'meetings', 'meeting', 'calls', 'call',
        'requirements', 'unclear', 'vague',
        'build', 'builds', 'ci', 'pipeline',
        'review', 'reviews', 'pr', 'approval',
        'dependencies', 'dependency', 'waiting',
        'context', 'switching', 'interruptions',
        'documentation', 'docs',
        'testing', 'tests',
        'deployment', 'deploy',
        'infrastructure', 'infra'
    ]
    
    for log in logs:
        if log.blockers:
            blocker_lower = log.blockers.lower()
            for keyword in common_blockers:
                if keyword in blocker_lower:
                    # Normalize similar keywords
                    normalized = keyword
                    if keyword in ['meetings', 'meeting', 'calls', 'call']:
                        normalized = 'meetings'
                    elif keyword in ['requirements', 'unclear', 'vague']:
                        normalized = 'unclear requirements'
                    elif keyword in ['build', 'builds', 'ci', 'pipeline']:
                        normalized = 'build/CI issues'
                    elif keyword in ['review', 'reviews', 'pr', 'approval']:
                        normalized = 'PR reviews/approval'
                    elif keyword in ['dependencies', 'dependency', 'waiting']:
                        normalized = 'waiting on dependencies'
                    elif keyword in ['context', 'switching', 'interruptions']:
                        normalized = 'context switching'
                    elif keyword in ['documentation', 'docs']:
                        normalized = 'documentation'
                    elif keyword in ['testing', 'tests']:
                        normalized = 'testing'
                    elif keyword in ['deployment', 'deploy']:
                        normalized = 'deployment'
                    elif keyword in ['infrastructure', 'infra']:
                        normalized = 'infrastructure'
                    
                    blocker_keywords[normalized] = blocker_keywords.get(normalized, 0) + 1
    
    # Sort by frequency
    sorted_blockers = sorted(blocker_keywords.items(), key=lambda x: x[1], reverse=True)
    
    return {
        'total_logs_with_blockers': len(logs),
        'blockers': [
            {'category': k, 'count': v}
            for k, v in sorted_blockers[:10]
        ],
        'recent_blockers': [
            {
                'date': log.date.isoformat(),
                'blocker': log.blockers[:100] if log.blockers else None,
                'satisfaction': log.satisfaction_score
            }
            for log in logs[:5]
        ]
    }


@router.get("/summary")
def get_friction_summary(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get friction/health summary for the period.
    """
    query = db.query(DailyLog)
    
    if start_date:
        query = query.filter(DailyLog.date >= start_date)
    if end_date:
        query = query.filter(DailyLog.date <= end_date)
    
    logs = query.all()
    
    if not logs:
        return {
            'total_entries': 0,
            'avg_satisfaction': 0,
            'avg_wellbeing': 0,
            'entries_with_blockers': 0,
            'trend': 'neutral'
        }
    
    satisfaction_scores = [l.satisfaction_score for l in logs]
    wellbeing_scores = [l.wellbeing_score for l in logs]
    blockers_count = sum(1 for l in logs if l.blockers)
    
    # Calculate trend (compare first half vs second half)
    mid = len(logs) // 2
    if mid > 0:
        first_half_avg = sum(satisfaction_scores[:mid]) / mid
        second_half_avg = sum(satisfaction_scores[mid:]) / (len(logs) - mid)
        
        if second_half_avg > first_half_avg + 0.5:
            trend = 'improving'
        elif second_half_avg < first_half_avg - 0.5:
            trend = 'declining'
        else:
            trend = 'stable'
    else:
        trend = 'neutral'
    
    return {
        'total_entries': len(logs),
        'avg_satisfaction': round(sum(satisfaction_scores) / len(logs), 1),
        'avg_wellbeing': round(sum(wellbeing_scores) / len(logs), 1),
        'entries_with_blockers': blockers_count,
        'trend': trend
    }

