from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional

from ..database import get_db
from ..models import Repository
from ..schemas import Repository as RepositorySchema, RepositoryUpdate

router = APIRouter()


@router.get("/repositories", response_model=List[RepositorySchema])
def list_repositories(
    tags: Optional[str] = Query(None, description="Comma-separated tags filter"),
    team: Optional[str] = Query(None, description="Filter by team name"),
    db: Session = Depends(get_db)
):
    """
    List repositories with optional filtering by tags or team.
    """
    query = db.query(Repository)
    
    if tags:
        tag_list = [t.strip() for t in tags.split(',')]
        # Filter repositories that have any of the specified tags
        for tag in tag_list:
            query = query.filter(Repository.tags.contains(tag))
    
    if team:
        query = query.filter(Repository.team == team)
    
    return query.all()


@router.patch("/repositories/{repo_id}/tags")
def update_repository_tags(
    repo_id: int,
    tags: List[str],
    db: Session = Depends(get_db)
):
    """
    Update repository tags.
    """
    repo = db.query(Repository).filter(Repository.id == repo_id).first()
    if not repo:
        raise HTTPException(status_code=404, detail="Repository not found")
    
    repo.tags = ','.join(tags) if tags else None
    db.commit()
    db.refresh(repo)
    
    return {
        "id": repo.id,
        "tags": tags,
        "tags_string": repo.tags
    }


@router.patch("/repositories/{repo_id}/team")
def update_repository_team(
    repo_id: int,
    team: str,
    db: Session = Depends(get_db)
):
    """
    Update repository team.
    """
    repo = db.query(Repository).filter(Repository.id == repo_id).first()
    if not repo:
        raise HTTPException(status_code=404, detail="Repository not found")
    
    repo.team = team
    db.commit()
    db.refresh(repo)
    
    return {
        "id": repo.id,
        "team": repo.team
    }


@router.get("/repositories/{repo_id}", response_model=RepositorySchema)
def get_repository(
    repo_id: int,
    db: Session = Depends(get_db)
):
    """
    Get a specific repository by ID.
    """
    repo = db.query(Repository).filter(Repository.id == repo_id).first()
    if not repo:
        raise HTTPException(status_code=404, detail="Repository not found")
    return repo

