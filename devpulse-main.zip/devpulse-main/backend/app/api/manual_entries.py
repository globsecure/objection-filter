from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from typing import Optional, List
from datetime import datetime

from ..database import get_db
from ..models import ManualEntry
from ..schemas import ManualEntryCreate, ManualEntryResponse, ManualEntryUpdate

router = APIRouter()


@router.post("/", response_model=ManualEntryResponse)
def create_manual_entry(
    entry: ManualEntryCreate,
    db: Session = Depends(get_db)
):
    """
    Create a manual entry (code review, design doc, mentoring, incident, meeting).
    """
    valid_types = ['code_review', 'design_doc', 'mentoring', 'incident', 'meeting']
    if entry.type not in valid_types:
        raise HTTPException(
            status_code=400,
            detail=f"Type must be one of: {', '.join(valid_types)}"
        )
    
    db_entry = ManualEntry(**entry.model_dump())
    db.add(db_entry)
    db.commit()
    db.refresh(db_entry)
    return db_entry


@router.get("/", response_model=List[ManualEntryResponse])
def list_manual_entries(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    type: Optional[str] = Query(None),
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db)
):
    """
    List manual entries with optional filters.
    """
    query = db.query(ManualEntry)
    
    if start_date:
        query = query.filter(ManualEntry.date >= start_date)
    if end_date:
        query = query.filter(ManualEntry.date <= end_date)
    if type:
        query = query.filter(ManualEntry.type == type)
    
    return query.order_by(ManualEntry.date.desc()).offset(offset).limit(limit).all()


@router.get("/{entry_id}", response_model=ManualEntryResponse)
def get_manual_entry(
    entry_id: int,
    db: Session = Depends(get_db)
):
    """
    Get a specific manual entry.
    """
    entry = db.query(ManualEntry).filter(ManualEntry.id == entry_id).first()
    if not entry:
        raise HTTPException(status_code=404, detail="Manual entry not found")
    return entry


@router.put("/{entry_id}", response_model=ManualEntryResponse)
def update_manual_entry(
    entry_id: int,
    entry_update: ManualEntryUpdate,
    db: Session = Depends(get_db)
):
    """
    Update a manual entry.
    """
    entry = db.query(ManualEntry).filter(ManualEntry.id == entry_id).first()
    if not entry:
        raise HTTPException(status_code=404, detail="Manual entry not found")
    
    update_data = entry_update.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(entry, field, value)
    
    db.commit()
    db.refresh(entry)
    return entry


@router.delete("/{entry_id}")
def delete_manual_entry(
    entry_id: int,
    db: Session = Depends(get_db)
):
    """
    Delete a manual entry.
    """
    entry = db.query(ManualEntry).filter(ManualEntry.id == entry_id).first()
    if not entry:
        raise HTTPException(status_code=404, detail="Manual entry not found")
    
    db.delete(entry)
    db.commit()
    return {"message": "Manual entry deleted successfully"}

