from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List, Dict, Optional
from ..database import get_db
from ..services.secret_detector import SecretDetector

router = APIRouter(prefix="/api/security", tags=["security"])


class SecretCheckRequest(BaseModel):
    text: str


class SecretCheckResponse(BaseModel):
    has_secrets: bool
    secrets: List[Dict]
    redacted_text: Optional[str] = None


@router.post("/check-secrets", response_model=SecretCheckResponse)
def check_secrets(
    request: SecretCheckRequest,
    db: Session = Depends(get_db)
):
    """Check if text contains secrets"""
    detector = SecretDetector()
    secrets = detector.detect_secrets(request.text)
    
    return SecretCheckResponse(
        has_secrets=len(secrets) > 0,
        secrets=secrets,
        redacted_text=detector.redact_secrets(request.text) if secrets else None
    )

