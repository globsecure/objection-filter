from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Optional
from ..database import get_db
from ..models import UserContext
from ..schemas import UserContextSchema, UserContextUpdate
from ..services.context_enrichment import ContextEnrichmentService

router = APIRouter()


@router.get("/user-context")
def get_user_context(
    user_id: str = "default",
    db: Session = Depends(get_db)
):
    """Get current user context"""
    context_service = ContextEnrichmentService(db)
    context = context_service.get_user_context(user_id)
    
    if not context:
        return {
            "user_id": user_id,
            "role": None,
            "team": None,
            "business_domain": None,
            "company": None,
            "preferred_language": "en"
        }
    
    return {
        "user_id": context.user_id,
        "role": context.role,
        "team": context.team,
        "business_domain": context.business_domain,
        "company": context.company,
        "preferred_language": context.preferred_language or "en",
        "created_at": context.created_at.isoformat() if context.created_at else None,
        "updated_at": context.updated_at.isoformat() if context.updated_at else None
    }


@router.put("/user-context")
def update_user_context(
    update: UserContextUpdate,
    user_id: str = "default",
    db: Session = Depends(get_db)
):
    """Update user context"""
    context_service = ContextEnrichmentService(db)
    
    update_dict = update.dict(exclude_unset=True)
    context = context_service.update_user_context(user_id=user_id, **update_dict)
    
    return {
        "user_id": context.user_id,
        "role": context.role,
        "team": context.team,
        "business_domain": context.business_domain,
        "company": context.company,
        "preferred_language": context.preferred_language or "en",
        "updated_at": context.updated_at.isoformat() if context.updated_at else None
    }

