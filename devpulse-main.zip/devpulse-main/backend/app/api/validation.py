from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from typing import Optional

from ..database import get_db
from ..models import Repository
from ..validation.git_validator import validate_repository

router = APIRouter()


@router.get("/repository")
def validate_repo(
    repo_path: Optional[str] = Query(None, description="Path to repository"),
    repo_id: Optional[int] = Query(None, description="Repository ID from database"),
    db: Session = Depends(get_db)
):
    """
    Validate a git repository for corruption and issues.
    Provide either repo_path or repo_id.
    """
    if not repo_path and not repo_id:
        raise HTTPException(status_code=400, detail="Either repo_path or repo_id must be provided")
    
    if repo_id:
        repo = db.query(Repository).filter(Repository.id == repo_id).first()
        if not repo:
            raise HTTPException(status_code=404, detail="Repository not found")
        repo_path = repo.path
    
    return validate_repository(repo_path)

