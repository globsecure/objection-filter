from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, timezone
import json

from ..database import get_db
from ..models import CareerMoment
from ..schemas import CareerMomentCreate, CareerMomentUpdate, CareerMoment as CareerMomentSchema

router = APIRouter()


@router.post("", response_model=CareerMomentSchema)
def create_moment(
    moment: CareerMomentCreate,
    db: Session = Depends(get_db)
):
    """Create a new career moment"""
    db_moment = CareerMoment(
        date=moment.date,
        type=moment.type,
        title=moment.title,
        story=moment.story,
        impact=moment.impact,
        witnesses=moment.witnesses,
        tags=moment.tags,
        related_commits=json.dumps(moment.related_commits or []),
        related_entries=json.dumps(moment.related_entries or [])
    )
    db.add(db_moment)
    db.commit()
    db.refresh(db_moment)
    
    # Parse JSON fields for response
    if db_moment.related_commits:
        db_moment.related_commits = json.loads(db_moment.related_commits)
    if db_moment.related_entries:
        db_moment.related_entries = json.loads(db_moment.related_entries)
    
    return db_moment


@router.get("", response_model=List[CareerMomentSchema])
def get_moments(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    type: Optional[str] = Query(None),
    tags: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """Get all career moments with optional filters"""
    query = db.query(CareerMoment)
    
    if start_date:
        query = query.filter(CareerMoment.date >= start_date)
    if end_date:
        query = query.filter(CareerMoment.date <= end_date)
    if type:
        query = query.filter(CareerMoment.type == type)
    if tags:
        tag_list = [t.strip() for t in tags.split(",")]
        for tag in tag_list:
            query = query.filter(CareerMoment.tags.contains(tag))
    
    moments = query.order_by(CareerMoment.date.desc()).all()
    
    # Parse JSON fields
    for moment in moments:
        if moment.related_commits:
            moment.related_commits = json.loads(moment.related_commits)
        if moment.related_entries:
            moment.related_entries = json.loads(moment.related_entries)
    
    return moments


@router.get("/{moment_id}", response_model=CareerMomentSchema)
def get_moment(moment_id: int, db: Session = Depends(get_db)):
    """Get a specific career moment"""
    moment = db.query(CareerMoment).filter(CareerMoment.id == moment_id).first()
    if not moment:
        raise HTTPException(status_code=404, detail="Career moment not found")
    
    if moment.related_commits:
        moment.related_commits = json.loads(moment.related_commits)
    if moment.related_entries:
        moment.related_entries = json.loads(moment.related_entries)
    
    return moment


@router.put("/{moment_id}", response_model=CareerMomentSchema)
def update_moment(
    moment_id: int,
    moment_update: CareerMomentUpdate,
    db: Session = Depends(get_db)
):
    """Update a career moment"""
    moment = db.query(CareerMoment).filter(CareerMoment.id == moment_id).first()
    if not moment:
        raise HTTPException(status_code=404, detail="Career moment not found")
    
    update_data = moment_update.model_dump(exclude_unset=True)
    if 'related_commits' in update_data:
        update_data['related_commits'] = json.dumps(update_data['related_commits'])
    if 'related_entries' in update_data:
        update_data['related_entries'] = json.dumps(update_data['related_entries'])
    
    for field, value in update_data.items():
        setattr(moment, field, value)
    
    moment.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(moment)
    
    # Parse JSON fields for response
    if moment.related_commits:
        moment.related_commits = json.loads(moment.related_commits)
    if moment.related_entries:
        moment.related_entries = json.loads(moment.related_entries)
    
    return moment


@router.delete("/{moment_id}")
def delete_moment(moment_id: int, db: Session = Depends(get_db)):
    """Delete a career moment"""
    moment = db.query(CareerMoment).filter(CareerMoment.id == moment_id).first()
    if not moment:
        raise HTTPException(status_code=404, detail="Career moment not found")
    
    db.delete(moment)
    db.commit()
    return {"message": "Career moment deleted"}


@router.get("/stats/summary")
def get_moments_stats(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    db: Session = Depends(get_db)
):
    """Get statistics about career moments"""
    query = db.query(CareerMoment)
    
    if start_date:
        query = query.filter(CareerMoment.date >= start_date)
    if end_date:
        query = query.filter(CareerMoment.date <= end_date)
    
    moments = query.all()
    
    stats = {
        "total": len(moments),
        "by_type": {},
        "by_quarter": {}
    }
    
    for moment in moments:
        # Count by type
        stats["by_type"][moment.type] = stats["by_type"].get(moment.type, 0) + 1
        
        # Count by quarter
        quarter = f"Q{(moment.date.month - 1) // 3 + 1}-{moment.date.year}"
        stats["by_quarter"][quarter] = stats["by_quarter"].get(quarter, 0) + 1
    
    return stats

