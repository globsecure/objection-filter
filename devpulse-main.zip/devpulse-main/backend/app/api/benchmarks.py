from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, date
import json

from ..database import get_db
from ..models import TeamBenchmark, IndustryBenchmark, HistoricalSnapshot
from ..schemas import (
    TeamBenchmarkCreate, TeamBenchmarkUpdate, TeamBenchmark,
    IndustryBenchmark as IndustryBenchmarkSchema, HistoricalSnapshot as HistoricalSnapshotSchema, ComparisonResult
)
from ..services.comparison_service import (
    compare_dora_metrics, compare_historical_periods,
    create_historical_snapshot
)
from ..services.benchmark_service import seed_industry_benchmarks

router = APIRouter(prefix="/api/benchmarks", tags=["benchmarks"])


@router.post("/team", response_model=TeamBenchmark)
def create_team_benchmark(
    benchmark: TeamBenchmarkCreate,
    db: Session = Depends(get_db)
):
    """Create a new team benchmark entry"""
    db_benchmark = TeamBenchmark(**benchmark.model_dump())
    db.add(db_benchmark)
    db.commit()
    db.refresh(db_benchmark)
    return db_benchmark


@router.get("/team", response_model=List[TeamBenchmark])
def get_team_benchmarks(
    metric_name: Optional[str] = Query(None),
    team_name: Optional[str] = Query(None),
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    db: Session = Depends(get_db)
):
    """Get team benchmarks with optional filters"""
    query = db.query(TeamBenchmark)

    if metric_name:
        query = query.filter(TeamBenchmark.metric_name == metric_name)
    if team_name:
        query = query.filter(TeamBenchmark.team_name == team_name)
    if start_date:
        query = query.filter(TeamBenchmark.period_start >= start_date)
    if end_date:
        query = query.filter(TeamBenchmark.period_end <= end_date)

    return query.order_by(TeamBenchmark.period_start.desc()).all()


@router.put("/team/{benchmark_id}", response_model=TeamBenchmark)
def update_team_benchmark(
    benchmark_id: int,
    benchmark_update: TeamBenchmarkUpdate,
    db: Session = Depends(get_db)
):
    """Update a team benchmark"""
    benchmark = db.query(TeamBenchmark).filter(
        TeamBenchmark.id == benchmark_id
    ).first()

    if not benchmark:
        raise HTTPException(status_code=404, detail="Benchmark not found")

    update_data = benchmark_update.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(benchmark, field, value)

    benchmark.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(benchmark)
    return benchmark


@router.delete("/team/{benchmark_id}")
def delete_team_benchmark(
    benchmark_id: int,
    db: Session = Depends(get_db)
):
    """Delete a team benchmark"""
    benchmark = db.query(TeamBenchmark).filter(
        TeamBenchmark.id == benchmark_id
    ).first()

    if not benchmark:
        raise HTTPException(status_code=404, detail="Benchmark not found")

    db.delete(benchmark)
    db.commit()
    return {"message": "Benchmark deleted"}


@router.post("/team/import")
def import_team_benchmarks(
    benchmarks: List[TeamBenchmarkCreate],
    db: Session = Depends(get_db)
):
    """Import multiple team benchmarks at once"""
    created = []
    for benchmark_data in benchmarks:
        db_benchmark = TeamBenchmark(**benchmark_data.model_dump())
        db.add(db_benchmark)
        created.append(db_benchmark)

    db.commit()
    for b in created:
        db.refresh(b)

    return {
        "message": f"Imported {len(created)} benchmarks",
        "benchmarks": created
    }


@router.get("/industry", response_model=List[IndustryBenchmarkSchema])
def get_industry_benchmarks(
    metric_name: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """Get industry benchmarks (DORA standards)"""
    # Seed if not exists
    seed_industry_benchmarks(db)

    query = db.query(IndustryBenchmark)
    if metric_name:
        query = query.filter(IndustryBenchmark.metric_name == metric_name)

    return query.order_by(IndustryBenchmark.min_value.asc()).all()


@router.get("/compare")
def compare_metrics(
    start_date: str = Query(..., description="Start date in YYYY-MM-DD format"),
    end_date: str = Query(..., description="End date in YYYY-MM-DD format"),
    team_name: Optional[str] = Query(None),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """Compare your metrics against team and industry benchmarks"""
    try:
        # Parse date strings to datetime objects
        start_dt = datetime.fromisoformat(f"{start_date}T00:00:00")
        end_dt = datetime.fromisoformat(f"{end_date}T23:59:59")
    except ValueError as e:
        raise HTTPException(status_code=422, detail=f"Invalid date format: {str(e)}. Expected YYYY-MM-DD")
    
    return compare_dora_metrics(
        db, start_dt, end_dt, team_name, repo_id
    )


@router.post("/snapshot")
def create_snapshot(
    period_label: str = Query(...),
    period_start: str = Query(..., description="Start date in YYYY-MM-DD format"),
    period_end: str = Query(..., description="End date in YYYY-MM-DD format"),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """Create a historical snapshot of current metrics"""
    try:
        # Parse date strings to datetime objects
        start_dt = datetime.fromisoformat(f"{period_start}T00:00:00")
        end_dt = datetime.fromisoformat(f"{period_end}T23:59:59")
    except ValueError as e:
        raise HTTPException(status_code=422, detail=f"Invalid date format: {str(e)}. Expected YYYY-MM-DD")
    
    snapshot = create_historical_snapshot(
        db, period_label, start_dt, end_dt, repo_id
    )
    return {
        "id": snapshot.id,
        "period_label": snapshot.period_label,
        "period_start": snapshot.period_start.isoformat(),
        "period_end": snapshot.period_end.isoformat(),
        "created_at": snapshot.created_at.isoformat(),
    }


@router.get("/snapshot", response_model=List[HistoricalSnapshotSchema])
def get_snapshots(
    period_label: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """Get historical snapshots"""
    query = db.query(HistoricalSnapshot)
    if period_label:
        query = query.filter(HistoricalSnapshot.period_label == period_label)

    snapshots = query.order_by(HistoricalSnapshot.period_start.desc()).all()
    
    # Convert to schema format
    result = []
    for snapshot in snapshots:
        result.append({
            "id": snapshot.id,
            "period_label": snapshot.period_label,
            "period_start": snapshot.period_start,
            "period_end": snapshot.period_end,
            "snapshot_data": json.loads(snapshot.snapshot_data) if snapshot.snapshot_data else {},
            "dora_metrics": json.loads(snapshot.dora_metrics) if snapshot.dora_metrics else {},
            "space_metrics": json.loads(snapshot.space_metrics) if snapshot.space_metrics else {},
            "created_at": snapshot.created_at,
        })
    
    return result


@router.get("/compare/historical")
def compare_historical(
    periods: str = Query(...),  # Comma-separated: "Q1-2024,Q2-2024,Q3-2024"
    db: Session = Depends(get_db)
):
    """Compare metrics across multiple historical periods"""
    period_labels = [p.strip() for p in periods.split(',')]
    return compare_historical_periods(db, period_labels)

