from fastapi import APIRouter, Depends, Query, HTTPException, Body
from sqlalchemy.orm import Session
from typing import List, Optional, Dict
from datetime import datetime
from pydantic import BaseModel

from ..database import get_db
from ..models import Commit, FrictionLog, ManualEntry, Repository

router = APIRouter()


class ImportDataRequest(BaseModel):
    data: Dict
    overwrite: bool = False


@router.get("/export")
def export_data(
    format: str = Query("json", description="Export format: json or csv"),
    include_commits: bool = Query(True, description="Include commits"),
    include_friction_logs: bool = Query(True, description="Include friction logs"),
    include_manual_entries: bool = Query(True, description="Include manual entries"),
    include_repositories: bool = Query(True, description="Include repositories"),
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Export data for migration or backup.
    """
    data = {}
    
    if include_repositories:
        repos = db.query(Repository).all()
        data['repositories'] = [
            {
                'id': r.id,
                'path': r.path,
                'name': r.name,
                'tags': r.tags,
                'team': r.team,
                'last_scanned': r.last_scanned.isoformat() if r.last_scanned else None
            }
            for r in repos
        ]
    
    if include_commits:
        commit_query = db.query(Commit)
        if repo_id:
            commit_query = commit_query.filter(Commit.repo_id == repo_id)
        if start_date:
            commit_query = commit_query.filter(Commit.date >= start_date)
        if end_date:
            commit_query = commit_query.filter(Commit.date <= end_date)
        commits = commit_query.all()
        data['commits'] = [
            {
                'hash': c.hash,
                'message': c.message,
                'author': c.author,
                'date': c.date.isoformat() if c.date else None,
                'repo_id': c.repo_id,
                'files_changed': c.files_changed,
                'insertions': c.insertions,
                'deletions': c.deletions,
                'type': c.type,
                'branch_name': c.branch_name,
                'is_merge_commit': c.is_merge_commit,
                'impact_category': c.impact_category
            }
            for c in commits
        ]
    
    if include_friction_logs:
        friction_query = db.query(FrictionLog)
        if start_date:
            friction_query = friction_query.filter(FrictionLog.date >= start_date)
        if end_date:
            friction_query = friction_query.filter(FrictionLog.date <= end_date)
        logs = friction_query.all()
        data['friction_logs'] = [
            {
                'date': log.date.isoformat() if log.date else None,
                'type': log.type,
                'description': log.description,
                'impact_level': log.impact_level,
                'tags': log.tags,
                'resolution': log.resolution,
                'created_at': log.created_at.isoformat() if log.created_at else None
            }
            for log in logs
        ]
    
    if include_manual_entries:
        manual_query = db.query(ManualEntry)
        if start_date:
            manual_query = manual_query.filter(ManualEntry.date >= start_date)
        if end_date:
            manual_query = manual_query.filter(ManualEntry.date <= end_date)
        entries = manual_query.all()
        data['manual_entries'] = [
            {
                'date': entry.date.isoformat() if entry.date else None,
                'type': entry.type,
                'title': entry.title,
                'description': entry.description,
                'impact': entry.impact,
                'collaborators': entry.collaborators,
                'links': entry.links,
                'duration_minutes': entry.duration_minutes,
                'created_at': entry.created_at.isoformat() if entry.created_at else None
            }
            for entry in entries
        ]
    
    if format == "json":
        return {
            'format': 'json',
            'exported_at': datetime.now().isoformat(),
            'data': data
        }
    elif format == "csv":
        # Basic CSV conversion (can be enhanced)
        raise HTTPException(status_code=501, detail="CSV export not yet implemented")
    else:
        raise HTTPException(status_code=400, detail=f"Unsupported format: {format}")


@router.post("/import")
def import_data(
    request: ImportDataRequest,
    db: Session = Depends(get_db)
):
    """
    Import data from export.
    Note: This is a basic implementation. In production, add validation and transaction handling.
    """
    data = request.data
    imported = {
        'repositories': 0,
        'commits': 0,
        'friction_logs': 0,
        'manual_entries': 0
    }
    
    try:
        # Import repositories
        if 'repositories' in data:
            for repo_data in data['repositories']:
                existing = db.query(Repository).filter(Repository.path == repo_data['path']).first()
                if not existing:
                    repo = Repository(
                        path=repo_data['path'],
                        name=repo_data['name'],
                        tags=repo_data.get('tags'),
                        team=repo_data.get('team')
                    )
                    db.add(repo)
                    imported['repositories'] += 1
        
        # Import commits (requires repositories to exist first)
        if 'commits' in data:
            for commit_data in data['commits']:
                existing = db.query(Commit).filter(
                    Commit.hash == commit_data['hash'],
                    Commit.repo_id == commit_data['repo_id']
                ).first()
                if not existing or request.overwrite:
                    if existing and request.overwrite:
                        db.delete(existing)
                    commit = Commit(
                        repo_id=commit_data['repo_id'],
                        hash=commit_data['hash'],
                        message=commit_data['message'],
                        author=commit_data['author'],
                        date=datetime.fromisoformat(commit_data['date']) if commit_data.get('date') else None,
                        files_changed=commit_data.get('files_changed', 0),
                        insertions=commit_data.get('insertions', 0),
                        deletions=commit_data.get('deletions', 0),
                        type=commit_data.get('type'),
                        branch_name=commit_data.get('branch_name'),
                        is_merge_commit=commit_data.get('is_merge_commit', False),
                        impact_category=commit_data.get('impact_category')
                    )
                    db.add(commit)
                    imported['commits'] += 1
        
        # Import friction logs
        if 'friction_logs' in data:
            for log_data in data['friction_logs']:
                log = FrictionLog(
                    date=datetime.fromisoformat(log_data['date']) if log_data.get('date') else datetime.now(),
                    type=log_data['type'],
                    description=log_data['description'],
                    impact_level=log_data.get('impact_level'),
                    tags=log_data.get('tags'),
                    resolution=log_data.get('resolution')
                )
                db.add(log)
                imported['friction_logs'] += 1
        
        # Import manual entries
        if 'manual_entries' in data:
            for entry_data in data['manual_entries']:
                entry = ManualEntry(
                    date=datetime.fromisoformat(entry_data['date']) if entry_data.get('date') else datetime.now(),
                    type=entry_data['type'],
                    title=entry_data['title'],
                    description=entry_data.get('description'),
                    impact=entry_data.get('impact'),
                    collaborators=entry_data.get('collaborators'),
                    links=entry_data.get('links'),
                    duration_minutes=entry_data.get('duration_minutes')
                )
                db.add(entry)
                imported['manual_entries'] += 1
        
        db.commit()
        
        return {
            'success': True,
            'imported': imported,
            'imported_at': datetime.now().isoformat()
        }
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Import failed: {str(e)}")

