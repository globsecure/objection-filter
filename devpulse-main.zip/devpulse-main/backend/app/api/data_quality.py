from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from ..database import get_db
from ..analysis.data_quality import (
    calculate_data_completeness,
    generate_smart_reminders,
    generate_validation_warnings
)

router = APIRouter(prefix="/api/data-quality", tags=["data-quality"])


@router.get("/completeness")
def get_data_completeness(
    days: int = Query(90, ge=1, le=365),
    db: Session = Depends(get_db)
):
    """Get data completeness score and recommendations"""
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    
    return calculate_data_completeness(db, start_date, end_date)


@router.get("/reminders")
def get_reminders(
    days: int = Query(7, ge=1, le=30),
    db: Session = Depends(get_db)
):
    """Get smart reminders for data quality"""
    return generate_smart_reminders(db, days)


@router.get("/warnings")
def get_validation_warnings(
    days: int = Query(90, ge=1, le=365),
    db: Session = Depends(get_db)
):
    """Get validation warnings"""
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    
    return generate_validation_warnings(db, start_date, end_date)

