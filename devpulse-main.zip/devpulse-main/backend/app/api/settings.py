from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional
from ..config import settings
from ..database import get_db
from ..models import UserSettings

router = APIRouter()


class SecuritySettingsRequest(BaseModel):
    enable_secret_detection: bool = True
    auto_redact_secrets: bool = False
    block_on_secret: bool = True
    redact_emails: bool = False
    redact_internal_urls: bool = False


class SecuritySettingsResponse(BaseModel):
    enable_secret_detection: bool
    auto_redact_secrets: bool
    block_on_secret: bool
    redact_emails: bool
    redact_internal_urls: bool


@router.get("/config")
def get_config():
    """
    Get current configuration (without sensitive values).
    Returns configuration structure and status.
    """
    return {
        "projects_dir": settings.projects_dir,
        "llm_provider": settings.llm_provider,
        "database_url": settings.database_url,
        "has_openai_key": bool(settings.openai_api_key),
        "has_gemini_key": bool(settings.gemini_api_key),
        "env_file": ".env",
        "instructions": {
            "file_location": "backend/.env",
            "required_vars": [
                "PROJECTS_DIR",
                "LLM_PROVIDER",
                "OPENAI_API_KEY (if using OpenAI)",
                "GEMINI_API_KEY (if using Gemini)",
                "DATABASE_URL"
            ],
            "note": "Edit the .env file directly to update configuration. Restart the server after changes."
        }
    }


@router.get("/security", response_model=SecuritySettingsResponse)
def get_security_settings(user_id: str = "default", db: Session = Depends(get_db)):
    """Get security settings for user"""
    user_settings = db.query(UserSettings).filter(UserSettings.user_id == user_id).first()
    
    if not user_settings:
        # Return defaults
        return SecuritySettingsResponse(
            enable_secret_detection=True,
            auto_redact_secrets=False,
            block_on_secret=True,
            redact_emails=False,
            redact_internal_urls=False
        )
    
    return SecuritySettingsResponse(
        enable_secret_detection=user_settings.enable_secret_detection,
        auto_redact_secrets=user_settings.auto_redact_secrets,
        block_on_secret=user_settings.block_on_secret,
        redact_emails=user_settings.redact_emails,
        redact_internal_urls=user_settings.redact_internal_urls
    )


@router.put("/security", response_model=SecuritySettingsResponse)
def update_security_settings(
    request: SecuritySettingsRequest,
    user_id: str = "default",
    db: Session = Depends(get_db)
):
    """Update security settings for user"""
    user_settings = db.query(UserSettings).filter(UserSettings.user_id == user_id).first()
    
    if not user_settings:
        user_settings = UserSettings(
            user_id=user_id,
            enable_secret_detection=request.enable_secret_detection,
            auto_redact_secrets=request.auto_redact_secrets,
            block_on_secret=request.block_on_secret,
            redact_emails=request.redact_emails,
            redact_internal_urls=request.redact_internal_urls
        )
        db.add(user_settings)
    else:
        user_settings.enable_secret_detection = request.enable_secret_detection
        user_settings.auto_redact_secrets = request.auto_redact_secrets
        user_settings.block_on_secret = request.block_on_secret
        user_settings.redact_emails = request.redact_emails
        user_settings.redact_internal_urls = request.redact_internal_urls
    
    db.commit()
    db.refresh(user_settings)
    
    return SecuritySettingsResponse(
        enable_secret_detection=user_settings.enable_secret_detection,
        auto_redact_secrets=user_settings.auto_redact_secrets,
        block_on_secret=user_settings.block_on_secret,
        redact_emails=user_settings.redact_emails,
        redact_internal_urls=user_settings.redact_internal_urls
    )


@router.get("/encryption-status")
def get_encryption_status():
    """Get database encryption status"""
    encryption_available = False
    try:
        import pysqlcipher3
        encryption_available = True
    except ImportError:
        pass
    
    return {
        "encryption_enabled": settings.db_encryption_enabled,
        "encryption_available": encryption_available,
        "instructions": {
            "install": "pip install pysqlcipher3",
            "enable": "Set DB_ENCRYPTION_ENABLED=true and DB_ENCRYPTION_PASSWORD=your_password in .env",
            "note": "Encryption must be enabled before creating the database. Migrating existing databases requires manual steps."
        }
    }

