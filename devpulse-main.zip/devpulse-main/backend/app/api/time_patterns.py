from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional
from datetime import datetime

from ..database import get_db
from ..analysis.time_patterns import (
    analyze_working_hours,
    detect_after_hours_work,
    detect_timezone
)

router = APIRouter()


@router.get("/working-hours")
def get_working_hours(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """Get working hours analysis"""
    return analyze_working_hours(db, start_date, end_date, repo_id)


@router.get("/after-hours")
def get_after_hours(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_id: Optional[int] = Query(None),
    work_start_hour: int = Query(9, ge=0, le=23),
    work_end_hour: int = Query(17, ge=0, le=23),
    db: Session = Depends(get_db)
):
    """Get after-hours work analysis"""
    return detect_after_hours_work(
        db, start_date, end_date, repo_id, work_start_hour, work_end_hour
    )

