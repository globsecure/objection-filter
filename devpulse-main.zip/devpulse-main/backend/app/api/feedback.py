from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime

from ..database import get_db
from ..models import Feedback
from ..schemas import FeedbackCreate, FeedbackUpdate, Feedback as FeedbackSchema

router = APIRouter()


@router.post("", response_model=FeedbackSchema)
def create_feedback(feedback: FeedbackCreate, db: Session = Depends(get_db)):
    """Create a new feedback entry"""
    db_feedback = Feedback(**feedback.model_dump())
    db.add(db_feedback)
    db.commit()
    db.refresh(db_feedback)
    return db_feedback


@router.get("", response_model=List[FeedbackSchema])
def get_feedback(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    category: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """Get all feedback with optional filters"""
    query = db.query(Feedback)
    
    if start_date:
        query = query.filter(Feedback.date >= start_date)
    if end_date:
        query = query.filter(Feedback.date <= end_date)
    if category:
        query = query.filter(Feedback.category == category)
    
    return query.order_by(Feedback.date.desc()).all()


@router.get("/stats/trends")
def get_feedback_trends(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    db: Session = Depends(get_db)
):
    """Get feedback trends over time"""
    query = db.query(Feedback)
    
    if start_date:
        query = query.filter(Feedback.date >= start_date)
    if end_date:
        query = query.filter(Feedback.date <= end_date)
    
    feedback_list = query.all()
    
    trends = {
        "total": len(feedback_list),
        "by_category": {},
        "by_month": {},
    }
    
    for feedback in feedback_list:
        category = feedback.category or "neutral"
        trends["by_category"][category] = trends["by_category"].get(category, 0) + 1
        
        month_key = feedback.date.strftime("%Y-%m")
        trends["by_month"][month_key] = trends["by_month"].get(month_key, 0) + 1
    
    return trends

