from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import and_
from typing import List, Optional
from datetime import datetime
from pathlib import Path

from ..database import get_db
from ..models import Repository, Commit, BranchMetric
from ..schemas import (
    Repository as RepositorySchema,
    Commit as CommitSchema,
    CrawlRequest,
    CommitFilter
)
from ..crawler.git_crawler import scan_directory, extract_commits, extract_branch_metrics, detect_repository_tags, get_latest_commit_hash
from ..analysis.cross_repo_analyzer import detect_cross_repo_impacts
from ..crawler.commit_analyzer import analyze_commit
from ..analysis.categorizer import categorize_commit
from ..analysis.impact_categorizer import categorize_commit_impact
from ..config import settings

router = APIRouter()


@router.post("/crawl")
def crawl_repositories(
    request: CrawlRequest,
    db: Session = Depends(get_db)
):
    """
    Scan directory for git repositories and extract commits.
    Enhanced to support multiple repos with tags.
    """
    directory = request.directory or settings.projects_dir
    auto_tags = request.auto_tags if request.auto_tags is not None else True
    
    repositories = scan_directory(directory)
    total_commits = 0
    total_branch_metrics = 0
    results = []
    
    for repo_info in repositories:
        try:
            # Normalize path for comparison (resolve symlinks and use absolute path)
            normalized_path = str(Path(repo_info['path']).absolute().resolve())
            
            # Auto-detect tags from path/name
            detected_tags = detect_repository_tags(normalized_path, repo_info['name']) if auto_tags else []
            
            # Check if repository already exists (by normalized path)
            db_repo = db.query(Repository).filter(Repository.path == normalized_path).first()
            
            # If not found by exact path, check if any existing repo resolves to the same path
            # This handles cases where paths were stored with different formats (relative vs absolute, symlinks, etc.)
            if not db_repo:
                # Only check repos that might match (same name or similar path)
                # This is more efficient than checking all repos
                potential_duplicates = db.query(Repository).filter(
                    Repository.name == repo_info['name']
                ).all()
                
                for existing_repo in potential_duplicates:
                    try:
                        existing_normalized = str(Path(existing_repo.path).absolute().resolve())
                        if existing_normalized == normalized_path:
                            # Found duplicate with different path format, update it
                            db_repo = existing_repo
                            db_repo.path = normalized_path
                            db.commit()
                            break
                    except (ValueError, OSError):
                        # Path doesn't exist anymore or is invalid, skip
                        continue
            
            # Get latest commit hash from git to check for changes
            latest_commit_hash = get_latest_commit_hash(normalized_path)
            
            if db_repo and latest_commit_hash:
                # Check if we already have the latest commit
                existing_latest = db.query(Commit).filter(
                    Commit.repo_id == db_repo.id,
                    Commit.hash == latest_commit_hash
                ).first()
                
                if existing_latest:
                    # Repository is up to date, skip scanning
                    results.append({
                        'repo_id': db_repo.id,
                        'name': db_repo.name,
                        'tags': db_repo.tags.split(',') if db_repo.tags else [],
                        'commits_added': 0,
                        'status': 'skipped',
                        'message': 'No new commits since last scan'
                    })
                    continue
            
            if not db_repo:
                db_repo = Repository(
                    path=normalized_path,
                    name=repo_info['name'],
                    tags=','.join(detected_tags) if detected_tags else None
                )
                db.add(db_repo)
                db.commit()
                db.refresh(db_repo)
            else:
                # Update tags if not set
                if not db_repo.tags and detected_tags:
                    db_repo.tags = ','.join(detected_tags)
                    db.commit()
            
            commits_data = extract_commits(normalized_path, request.months_back)
            repo_commits_added = 0
            
            for commit_data in commits_data:
                existing_commit = db.query(Commit).filter(
                    Commit.hash == commit_data['hash'],
                    Commit.repo_id == db_repo.id
                ).first()
                
                if not existing_commit:
                    commit_type = categorize_commit(commit_data)
                    impact_category, _ = categorize_commit_impact(
                        commit_data['message'],
                        commit_type
                    )
                    
                    db_commit = Commit(
                        repo_id=db_repo.id,
                        hash=commit_data['hash'],
                        message=commit_data['message'],
                        author=commit_data['author'],
                        date=commit_data['date'],
                        files_changed=commit_data['files_changed'],
                        insertions=commit_data['insertions'],
                        deletions=commit_data['deletions'],
                        type=commit_type,
                        branch_name=commit_data.get('branch_name'),
                        is_merge_commit=commit_data.get('is_merge_commit', False),
                        impact_category=impact_category.value
                    )
                    db.add(db_commit)
                    total_commits += 1
                    repo_commits_added += 1
            
            # Extract branch metrics for DORA analysis
            branch_metrics_data = extract_branch_metrics(normalized_path, request.months_back * 2)
            
            for bm_data in branch_metrics_data:
                existing_bm = db.query(BranchMetric).filter(
                    BranchMetric.merge_commit_hash == bm_data['merge_commit_hash'],
                    BranchMetric.repo_id == db_repo.id
                ).first()
                
                if not existing_bm:
                    db_bm = BranchMetric(
                        repo_id=db_repo.id,
                        branch_name=bm_data['branch_name'],
                        first_commit_date=bm_data['first_commit_date'],
                        merge_date=bm_data['merge_date'],
                        merge_commit_hash=bm_data['merge_commit_hash'],
                        cycle_time_days=bm_data['cycle_time_days']
                    )
                    db.add(db_bm)
                    total_branch_metrics += 1
            
            db_repo.last_scanned = datetime.now()
            db.commit()
            
            results.append({
                'repo_id': db_repo.id,
                'name': db_repo.name,
                'tags': db_repo.tags.split(',') if db_repo.tags else [],
                'commits_added': repo_commits_added,
                'status': 'success'
            })
        except Exception as e:
            results.append({
                'repo_id': None,
                'name': repo_info['name'],
                'status': 'error',
                'error': str(e)
            })
    
    return {
        "repositories_found": len(repositories),
        "commits_added": total_commits,
        "branch_metrics_added": total_branch_metrics,
        "results": results
    }


@router.get("/repositories", response_model=List[RepositorySchema])
def list_repositories(db: Session = Depends(get_db)):
    """
    List all discovered repositories.
    """
    repositories = db.query(Repository).all()
    return repositories


@router.get("/commits", response_model=List[CommitSchema])
def list_commits(
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    repo_id: Optional[int] = None,
    commit_type: Optional[str] = None,
    limit: int = 100,
    offset: int = 0,
    db: Session = Depends(get_db)
):
    """
    List commits with optional filters.
    """
    query = db.query(Commit)
    
    if start_date:
        query = query.filter(Commit.date >= start_date)
    if end_date:
        query = query.filter(Commit.date <= end_date)
    if repo_id:
        query = query.filter(Commit.repo_id == repo_id)
    if commit_type:
        query = query.filter(Commit.type == commit_type)
    
    commits = query.order_by(Commit.date.desc()).offset(offset).limit(limit).all()
    return commits


@router.get("/cross-repo-impacts")
def get_cross_repo_impacts(
    repo_id: int,
    other_repos: Optional[List[int]] = None,
    db: Session = Depends(get_db)
):
    """
    Detect commits that might impact other repositories.
    Analyzes commit messages and patterns for cross-repo indicators.
    """
    return detect_cross_repo_impacts(db, repo_id, other_repos)

