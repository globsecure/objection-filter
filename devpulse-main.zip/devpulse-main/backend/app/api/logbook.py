from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
from pydantic import BaseModel

from ..database import get_db
from ..models import LogbookEntry
from ..schemas import LogbookEntry as LogbookEntrySchema, LogbookEntryCreate

router = APIRouter()


@router.post("", response_model=LogbookEntrySchema)
def create_logbook_entry(
    entry: LogbookEntryCreate,
    db: Session = Depends(get_db)
):
    """
    Create a new logbook entry.
    """
    db_entry = LogbookEntry(
        content=entry.content,
        date=entry.date or datetime.now()
    )
    db.add(db_entry)
    db.commit()
    db.refresh(db_entry)
    return db_entry


@router.get("", response_model=List[LogbookEntrySchema])
def list_logbook_entries(
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    limit: int = 100,
    offset: int = 0,
    db: Session = Depends(get_db)
):
    """
    List logbook entries with optional date filters.
    """
    query = db.query(LogbookEntry)
    
    if start_date:
        query = query.filter(LogbookEntry.date >= start_date)
    if end_date:
        query = query.filter(LogbookEntry.date <= end_date)
    
    entries = query.order_by(LogbookEntry.date.desc()).offset(offset).limit(limit).all()
    return entries


@router.get("/{entry_id}", response_model=LogbookEntrySchema)
def get_logbook_entry(
    entry_id: int,
    db: Session = Depends(get_db)
):
    """
    Get a specific logbook entry by ID.
    """
    entry = db.query(LogbookEntry).filter(LogbookEntry.id == entry_id).first()
    if not entry:
        raise HTTPException(status_code=404, detail="Logbook entry not found")
    return entry

