from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional

from ..database import get_db
from ..services.backup_service import backup_database
from ..config import settings
from pathlib import Path

router = APIRouter()


@router.post("/create")
def create_backup(
    keep_backups: int = Query(7, ge=1, le=30, description="Number of backups to keep"),
    db: Session = Depends(get_db)
):
    """
    Create a backup of the database.
    """
    # Get database path from settings
    db_url = settings.database_url
    if db_url.startswith('sqlite:///'):
        db_path = db_url.replace('sqlite:///', '')
        # Handle relative paths
        if not Path(db_path).is_absolute():
            db_path = Path(__file__).parent.parent.parent / db_path
        else:
            db_path = Path(db_path)
    else:
        # Try default location
        db_path = Path(__file__).parent.parent.parent / 'devpulse.db'
    
    if not db_path.exists():
        return {'success': False, 'error': f'Database file not found at {db_path}'}
    
    result = backup_database(str(db_path), keep_backups=keep_backups)
    return result

