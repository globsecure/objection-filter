from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional
from datetime import datetime

from ..database import get_db
from ..analysis.space_metrics import (
    analyze_focus_time,
    get_optimal_hours,
    get_daily_activity,
    get_space_metrics,
    calculate_satisfaction_metrics,
    calculate_performance_metrics,
    calculate_activity_metrics,
    calculate_collaboration_metrics
)
from ..analysis.aggregation import aggregate_space_metrics
from typing import List

router = APIRouter()


@router.get("/focus-time")
def get_focus_time(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get focus time analysis with deep work blocks.
    """
    return analyze_focus_time(db, start_date, end_date, repo_id)


@router.get("/flow-score")
def get_flow_score(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get flow score based on commit patterns.
    """
    result = analyze_focus_time(db, start_date, end_date, repo_id)
    return result['flow_score']


@router.get("/optimal-hours")
def get_optimal_working_hours(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get optimal working hours based on commit patterns.
    """
    return get_optimal_hours(db, start_date, end_date, repo_id)


@router.get("/daily-activity")
def get_daily_activity_heatmap(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get daily activity patterns for heatmap visualization.
    """
    return get_daily_activity(db, start_date, end_date, repo_id)


@router.get("/satisfaction")
def get_satisfaction(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get Satisfaction & Wellbeing metrics.
    """
    return calculate_satisfaction_metrics(db, start_date, end_date)


@router.get("/performance")
def get_performance(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get Performance (Output) metrics.
    """
    return calculate_performance_metrics(db, start_date, end_date, repo_id)


@router.get("/activity")
def get_activity(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get Activity (Volume) metrics.
    """
    return calculate_activity_metrics(db, start_date, end_date, repo_id)


@router.get("/collaboration")
def get_collaboration(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get Collaboration metrics.
    """
    return calculate_collaboration_metrics(db, start_date, end_date)


@router.get("/summary")
def get_space_summary(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_id: Optional[int] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get complete SPACE metrics summary (all 5 dimensions).
    """
    return get_space_metrics(db, start_date, end_date, repo_id)


@router.get("/trends")
def get_space_trends(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_id: Optional[int] = Query(None),
    group_by: str = Query("week"),  # day, week, month
    db: Session = Depends(get_db)
):
    """
    Get SPACE metrics trends over time.
    """
    from datetime import timedelta
    
    if not start_date or not end_date:
        # Default to last 3 months if not provided
        end_date = datetime.now()
        start_date = end_date - timedelta(days=90)
    
    # Get metrics for each period
    trends = []
    current_start = start_date
    
    while current_start < end_date:
        if group_by == "day":
            period_end = min(current_start + timedelta(days=1), end_date)
            period_label = current_start.strftime('%Y-%m-%d')
        elif group_by == "month":
            # Move to start of next month
            if current_start.month == 12:
                period_end = datetime(current_start.year + 1, 1, 1)
            else:
                period_end = datetime(current_start.year, current_start.month + 1, 1)
            period_end = min(period_end, end_date)
            period_label = current_start.strftime('%Y-%m')
        else:  # week
            period_end = min(current_start + timedelta(days=7), end_date)
            period_label = current_start.strftime('%Y-W%W')
        
        metrics = get_space_metrics(db, current_start, period_end, repo_id)
        trends.append({
            'period': period_label,
            'satisfaction': metrics['satisfaction']['average_satisfaction'],
            'performance_score': metrics['performance']['quality_score'],
            'activity_score': metrics['activity']['consistency_score'] * 100,  # Normalize to 0-100
            'collaboration_score': metrics['collaboration']['collaboration_score'],
            'efficiency_score': metrics['efficiency']['score']
        })
        
        current_start = period_end
    
    return {
        'group_by': group_by,
        'trends': trends
    }


@router.get("/aggregate")
def get_aggregated_space_metrics(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    repo_ids: Optional[List[int]] = Query(None),
    tags: Optional[List[str]] = Query(None),
    team: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get aggregated SPACE metrics across multiple repositories.
    Filter by repository IDs, tags, or team.
    """
    return aggregate_space_metrics(
        db,
        repo_ids=repo_ids,
        tags=tags,
        team=team,
        start_date=start_date,
        end_date=end_date
    )

