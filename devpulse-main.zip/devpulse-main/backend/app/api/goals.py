from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, timezone

from ..database import get_db
from ..models import Goal, GoalLink, Commit, ManualEntry
from ..schemas import GoalCreate, GoalUpdate, Goal as GoalSchema, GoalLinkCreate

router = APIRouter()


@router.post("", response_model=GoalSchema)
def create_goal(goal: GoalCreate, db: Session = Depends(get_db)):
    """Create a new goal"""
    db_goal = Goal(**goal.model_dump())
    db.add(db_goal)
    db.commit()
    db.refresh(db_goal)
    return db_goal


@router.get("", response_model=List[GoalSchema])
def get_goals(
    status: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """Get all goals with optional status filter"""
    query = db.query(Goal)
    if status:
        query = query.filter(Goal.status == status)
    return query.order_by(Goal.deadline.asc()).all()


@router.get("/{goal_id}", response_model=GoalSchema)
def get_goal(goal_id: int, db: Session = Depends(get_db)):
    """Get a specific goal with linked items"""
    goal = db.query(Goal).filter(Goal.id == goal_id).first()
    if not goal:
        raise HTTPException(status_code=404, detail="Goal not found")
    return goal


@router.put("/{goal_id}", response_model=GoalSchema)
def update_goal(
    goal_id: int,
    goal_update: GoalUpdate,
    db: Session = Depends(get_db)
):
    """Update a goal"""
    goal = db.query(Goal).filter(Goal.id == goal_id).first()
    if not goal:
        raise HTTPException(status_code=404, detail="Goal not found")
    
    update_data = goal_update.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(goal, field, value)
    
    goal.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(goal)
    return goal


@router.post("/link", response_model=dict)
def link_to_goal(link: GoalLinkCreate, db: Session = Depends(get_db)):
    """Link a commit or manual entry to a goal"""
    goal = db.query(Goal).filter(Goal.id == link.goal_id).first()
    if not goal:
        raise HTTPException(status_code=404, detail="Goal not found")
    
    if link.commit_id:
        commit = db.query(Commit).filter(Commit.id == link.commit_id).first()
        if not commit:
            raise HTTPException(status_code=404, detail="Commit not found")
    
    if link.entry_id:
        entry = db.query(ManualEntry).filter(ManualEntry.id == link.entry_id).first()
        if not entry:
            raise HTTPException(status_code=404, detail="Manual entry not found")
    
    db_link = GoalLink(**link.model_dump())
    db.add(db_link)
    db.commit()
    return {"message": "Linked successfully"}


@router.get("/{goal_id}/progress")
def get_goal_progress(goal_id: int, db: Session = Depends(get_db)):
    """Get progress details for a goal"""
    goal = db.query(Goal).filter(Goal.id == goal_id).first()
    if not goal:
        raise HTTPException(status_code=404, detail="Goal not found")
    
    links = db.query(GoalLink).filter(GoalLink.goal_id == goal_id).all()
    
    commits = [link.commit_id for link in links if link.commit_id]
    entries = [link.entry_id for link in links if link.entry_id]
    
    return {
        "goal": goal,
        "linked_commits": len(commits),
        "linked_entries": len(entries),
        "total_work_items": len(commits) + len(entries),
    }

