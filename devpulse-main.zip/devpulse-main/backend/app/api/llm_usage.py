from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional
from datetime import datetime
from ..database import get_db
from ..models import LLMRateLimit
from ..services.llm_rate_limiter import LLMRateLimiter
from ..schemas import LLMUsageStats, RateLimitStatus, RateLimitUpdate

router = APIRouter()


@router.get("/usage", response_model=LLMUsageStats)
def get_llm_usage_stats(
    provider: Optional[str] = Query(None, description="Filter by provider"),
    start_date: Optional[datetime] = Query(None, description="Start date filter"),
    end_date: Optional[datetime] = Query(None, description="End date filter"),
    db: Session = Depends(get_db)
):
    """Get LLM usage statistics"""
    rate_limiter = LLMRateLimiter(db)
    stats = rate_limiter.get_usage_stats(provider, start_date, end_date)
    return stats


@router.get("/rate-limits", response_model=RateLimitStatus)
def get_rate_limits(
    provider: Optional[str] = Query(None, description="Filter by provider"),
    db: Session = Depends(get_db)
):
    """Get current rate limit status"""
    query = db.query(LLMRateLimit)
    if provider:
        query = query.filter(LLMRateLimit.provider == provider)
    
    limits = query.all()
    
    if not limits:
        return {
            "providers": [],
            "message": "No rate limits configured"
        }
    
    return {
        "providers": [
            {
                "provider": limit.provider,
                "requests_per_minute": limit.requests_per_minute,
                "tokens_per_minute": limit.tokens_per_minute,
                "requests_per_day": limit.requests_per_day,
                "current_minute_requests": limit.current_minute_requests,
                "current_minute_tokens": limit.current_minute_tokens,
                "current_day_requests": limit.current_day_requests,
                "last_reset_minute": limit.last_reset_minute.isoformat() if limit.last_reset_minute else None,
                "last_reset_day": limit.last_reset_day.isoformat() if limit.last_reset_day else None
            }
            for limit in limits
        ]
    }


@router.put("/rate-limits")
def update_rate_limits(
    update: RateLimitUpdate,
    db: Session = Depends(get_db)
):
    """Update rate limits for a provider"""
    limit = db.query(LLMRateLimit).filter(
        LLMRateLimit.provider == update.provider
    ).first()
    
    if not limit:
        limit = LLMRateLimit(provider=update.provider)
        db.add(limit)
    
    if update.requests_per_minute is not None:
        limit.requests_per_minute = update.requests_per_minute
    if update.tokens_per_minute is not None:
        limit.tokens_per_minute = update.tokens_per_minute
    if update.requests_per_day is not None:
        limit.requests_per_day = update.requests_per_day
    
    db.commit()
    db.refresh(limit)
    
    return {
        "provider": limit.provider,
        "requests_per_minute": limit.requests_per_minute,
        "tokens_per_minute": limit.tokens_per_minute,
        "requests_per_day": limit.requests_per_day,
        "message": "Rate limits updated successfully"
    }

