from typing import Dict


def analyze_commit(commit_data: Dict) -> Dict:
    """
    Analyze a commit and calculate basic metrics.
    """
    files_changed = commit_data.get('files_changed', 0)
    insertions = commit_data.get('insertions', 0)
    deletions = commit_data.get('deletions', 0)
    
    return {
        'files_changed': files_changed,
        'insertions': insertions,
        'deletions': deletions,
        'net_lines': insertions - deletions,
        'total_changes': insertions + deletions
    }

