import os
import re
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
from git import Repo, InvalidGitRepositoryError
from git.exc import GitCommandError


def scan_directory(directory: str) -> List[Dict[str, str]]:
    """
    Recursively scan directory for .git folders and return repository paths.
    Returns normalized absolute paths to avoid duplicates.
    """
    repositories = []
    directory_path = Path(directory)
    seen_paths = set()
    
    if not directory_path.exists():
        return repositories
    
    for root, dirs, files in os.walk(directory_path):
        if '.git' in dirs:
            repo_path = Path(root)
            try:
                repo = Repo(root)
                if not repo.bare:
                    # Normalize path to absolute and resolve symlinks
                    abs_path = str(repo_path.absolute().resolve())
                    # Avoid duplicates by path
                    if abs_path not in seen_paths:
                        seen_paths.add(abs_path)
                        repositories.append({
                            'path': abs_path,
                            'name': repo_path.name
                        })
            except (InvalidGitRepositoryError, GitCommandError):
                continue
    
    return repositories


def _get_branch_for_commit(repo: Repo, commit) -> Optional[str]:
    """
    Try to determine the branch name for a commit.
    """
    try:
        # Check if commit is on HEAD branch
        if repo.head.is_valid():
            head_branch = repo.active_branch.name
            if commit in repo.iter_commits(head_branch):
                return head_branch
        
        # Check other branches
        for branch in repo.branches:
            try:
                if commit in repo.iter_commits(branch.name, max_count=1000):
                    return branch.name
            except:
                continue
    except:
        pass
    
    return None


def _is_merge_commit(commit) -> bool:
    """
    Check if a commit is a merge commit (has multiple parents).
    """
    return len(commit.parents) > 1


def _extract_merged_branch_name(message: str) -> Optional[str]:
    """
    Extract merged branch name from merge commit message.
    """
    patterns = [
        r"Merge branch '([^']+)'",
        r"Merge branch \"([^\"]+)\"",
        r"Merge pull request #\d+ from ([^\s]+)",
        r"Merge ([^\s]+) into",
    ]
    
    for pattern in patterns:
        match = re.search(pattern, message)
        if match:
            return match.group(1)
    
    return None


def extract_commits(repo_path: str, months_back: int = 3) -> List[Dict]:
    """
    Extract commits from a git repository from the last N months.
    Returns list of commit dictionaries with metadata including branch info.
    """
    commits = []
    
    try:
        repo = Repo(repo_path)
        if repo.bare:
            return commits
        
        cutoff_date = datetime.now() - timedelta(days=months_back * 30)
        
        # Get current branch name
        try:
            current_branch = repo.active_branch.name
        except TypeError:
            current_branch = "HEAD"
        
        for commit in repo.iter_commits():
            commit_date = datetime.fromtimestamp(commit.committed_date)
            
            if commit_date < cutoff_date:
                break
            
            stats = commit.stats.total
            is_merge = _is_merge_commit(commit)
            
            # Try to determine branch name
            branch_name = current_branch
            if is_merge:
                merged_branch = _extract_merged_branch_name(commit.message)
                if merged_branch:
                    branch_name = merged_branch
            
            commits.append({
                'hash': commit.hexsha,
                'message': commit.message.strip(),
                'author': commit.author.name,
                'date': commit_date,
                'files_changed': len(commit.stats.files),
                'insertions': stats['insertions'],
                'deletions': stats['deletions'],
                'branch_name': branch_name,
                'is_merge_commit': is_merge,
            })
    
    except (InvalidGitRepositoryError, GitCommandError) as e:
        print(f"Error processing repository {repo_path}: {e}")
    
    return commits


def extract_branch_metrics(repo_path: str, months_back: int = 6) -> List[Dict]:
    """
    Extract branch lifecycle metrics for merged branches.
    Returns list of branch metrics including cycle time.
    """
    branch_metrics = []
    
    try:
        repo = Repo(repo_path)
        if repo.bare:
            return branch_metrics
        
        cutoff_date = datetime.now() - timedelta(days=months_back * 30)
        
        # Find merge commits and analyze their branches
        for commit in repo.iter_commits():
            commit_date = datetime.fromtimestamp(commit.committed_date)
            
            if commit_date < cutoff_date:
                break
            
            if not _is_merge_commit(commit):
                continue
            
            merged_branch = _extract_merged_branch_name(commit.message)
            if not merged_branch:
                continue
            
            # Try to find the first commit of the merged branch
            first_commit_date = None
            try:
                # Get the parent that's not on the main branch
                if len(commit.parents) >= 2:
                    branch_parent = commit.parents[1]
                    
                    # Walk back to find the branch point
                    branch_commits = []
                    current = branch_parent
                    main_commits = set(c.hexsha for c in repo.iter_commits(commit.parents[0], max_count=1000))
                    
                    while current and len(branch_commits) < 500:
                        if current.hexsha in main_commits:
                            break
                        branch_commits.append(current)
                        if current.parents:
                            current = current.parents[0]
                        else:
                            break
                    
                    if branch_commits:
                        first_commit = branch_commits[-1]
                        first_commit_date = datetime.fromtimestamp(first_commit.committed_date)
            except Exception:
                pass
            
            if first_commit_date:
                cycle_time_days = (commit_date - first_commit_date).total_seconds() / 86400
            else:
                cycle_time_days = None
            
            branch_metrics.append({
                'branch_name': merged_branch,
                'first_commit_date': first_commit_date,
                'merge_date': commit_date,
                'merge_commit_hash': commit.hexsha,
                'cycle_time_days': cycle_time_days,
            })
    
    except (InvalidGitRepositoryError, GitCommandError) as e:
        print(f"Error processing repository {repo_path}: {e}")
    
    return branch_metrics


def get_main_branch_name(repo_path: str) -> str:
    """
    Determine the main branch name (main, master, etc.)
    """
    try:
        repo = Repo(repo_path)
        for name in ['main', 'master', 'develop', 'trunk']:
            try:
                repo.heads[name]
                return name
            except:
                continue
        # Fallback to active branch
        return repo.active_branch.name
    except:
        return 'main'


def get_latest_commit_hash(repo_path: str) -> Optional[str]:
    """
    Get the latest commit hash from a git repository.
    Returns None if repository is invalid or empty.
    """
    try:
        repo = Repo(repo_path)
        if repo.bare or not repo.heads:
            return None
        return repo.head.commit.hexsha
    except (InvalidGitRepositoryError, GitCommandError, ValueError):
        return None


def detect_repository_tags(path: str, name: str) -> List[str]:
    """
    Auto-detect repository tags from path and name.
    """
    tags = []
    path_lower = path.lower()
    name_lower = name.lower()
    
    # Technology tags
    if any(x in path_lower or x in name_lower for x in ['frontend', 'ui', 'web', 'react', 'vue', 'angular']):
        tags.append('frontend')
    if any(x in path_lower or x in name_lower for x in ['backend', 'api', 'server', 'service']):
        tags.append('backend')
    if any(x in path_lower or x in name_lower for x in ['infra', 'infrastructure', 'terraform', 'k8s', 'kubernetes']):
        tags.append('infra')
    if any(x in path_lower or x in name_lower for x in ['mobile', 'ios', 'android', 'react-native']):
        tags.append('mobile')
    
    # Organization tags (customize for your org)
    if 'paypal' in path_lower or 'paypal' in name_lower:
        tags.append('paypal')
    
    return tags


def count_merges_to_main(repo_path: str, months_back: int = 3) -> List[Dict]:
    """
    Count merge commits to main branch per period (deployment frequency proxy).
    Returns daily counts of merges.
    """
    merge_counts = []
    
    try:
        repo = Repo(repo_path)
        if repo.bare:
            return merge_counts
        
        main_branch = get_main_branch_name(repo_path)
        cutoff_date = datetime.now() - timedelta(days=months_back * 30)
        
        daily_merges: Dict[str, int] = {}
        
        for commit in repo.iter_commits(main_branch):
            commit_date = datetime.fromtimestamp(commit.committed_date)
            
            if commit_date < cutoff_date:
                break
            
            if _is_merge_commit(commit):
                date_str = commit_date.strftime('%Y-%m-%d')
                daily_merges[date_str] = daily_merges.get(date_str, 0) + 1
        
        # Convert to sorted list
        for date_str in sorted(daily_merges.keys()):
            merge_counts.append({
                'date': date_str,
                'count': daily_merges[date_str]
            })
    
    except (InvalidGitRepositoryError, GitCommandError) as e:
        print(f"Error processing repository {repo_path}: {e}")
    
    return merge_counts

