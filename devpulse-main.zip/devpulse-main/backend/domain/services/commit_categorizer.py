import re
from typing import Dict

from ..value_objects.commit_type import CommitType


class CommitCategorizer:
    """
    Domain service for categorizing commits based on message patterns.
    """

    PATTERNS: Dict[CommitType, list] = {
        CommitType.FEATURE: [
            r'^feat[:\s]',
            r'^feature[:\s]',
            r'add\s+',
            r'new\s+',
            r'implement\s+',
            r'create\s+',
        ],
        CommitType.BUGFIX: [
            r'^fix[:\s]',
            r'^bugfix[:\s]',
            r'^bug[:\s]',
            r'fix\s+',
            r'resolve\s+',
            r'correct\s+',
            r'patch\s+',
        ],
        CommitType.REFACTOR: [
            r'^refactor[:\s]',
            r'refactor\s+',
            r'cleanup\s+',
            r'restructure\s+',
            r'optimize\s+',
            r'improve\s+',
        ],
        CommitType.DOCUMENTATION: [
            r'^docs[:\s]',
            r'^doc[:\s]',
            r'documentation',
            r'readme',
            r'comment\s+',
            r'update\s+.*readme',
            r'update\s+.*doc',
        ],
        CommitType.CHORE: [
            r'^chore[:\s]',
            r'^ci[:\s]',
            r'^build[:\s]',
            r'update\s+dependencies',
            r'update\s+.*\.lock',
            r'merge\s+',
            r'^bump\s+',
        ],
    }

    @classmethod
    def categorize(cls, message: str) -> CommitType:
        """
        Categorize a commit based on its message.
        
        Args:
            message: The commit message
            
        Returns:
            CommitType: The categorized commit type
        """
        message_lower = message.lower()

        for commit_type, patterns in cls.PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, message_lower, re.IGNORECASE):
                    return commit_type

        return CommitType.UNKNOWN

