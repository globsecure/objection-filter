from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from ..value_objects.commit_type import CommitType


@dataclass
class Commit:
    """
    Commit entity representing a git commit.
    """
    id: Optional[int]
    repo_id: int
    hash: str
    message: str
    author: str
    date: datetime
    files_changed: int
    insertions: int
    deletions: int
    type: Optional[CommitType] = None

    def __post_init__(self):
        if not self.hash:
            raise ValueError("Commit hash cannot be empty")
        if not self.message:
            raise ValueError("Commit message cannot be empty")
        if not self.author:
            raise ValueError("Commit author cannot be empty")
        if self.files_changed < 0:
            raise ValueError("Files changed cannot be negative")
        if self.insertions < 0:
            raise ValueError("Insertions cannot be negative")
        if self.deletions < 0:
            raise ValueError("Deletions cannot be negative")

    @property
    def net_lines(self) -> int:
        """Calculate net lines changed."""
        return self.insertions - self.deletions

    @property
    def total_changes(self) -> int:
        """Calculate total lines changed."""
        return self.insertions + self.deletions

