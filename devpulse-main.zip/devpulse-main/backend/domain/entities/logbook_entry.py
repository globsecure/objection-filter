from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass
class LogbookEntry:
    """
    Logbook entry entity representing a daily learning/achievement note.
    """
    id: Optional[int]
    content: str
    date: datetime

    def __post_init__(self):
        if not self.content or not self.content.strip():
            raise ValueError("Logbook entry content cannot be empty")

