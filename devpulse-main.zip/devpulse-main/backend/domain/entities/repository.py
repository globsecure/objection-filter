from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass
class Repository:
    """
    Repository entity representing a git repository.
    """
    id: Optional[int]
    path: str
    name: str
    last_scanned: Optional[datetime] = None

    def __post_init__(self):
        if not self.path:
            raise ValueError("Repository path cannot be empty")
        if not self.name:
            raise ValueError("Repository name cannot be empty")

