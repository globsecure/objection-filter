from enum import Enum


class CommitType(str, Enum):
    """
    Value object representing commit types.
    """
    FEATURE = "Feature"
    BUGFIX = "Bugfix"
    REFACTOR = "Refactor"
    DOCUMENTATION = "Documentation"
    CHORE = "Chore"
    UNKNOWN = "Unknown"

