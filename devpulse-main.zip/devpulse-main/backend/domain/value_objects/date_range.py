from dataclasses import dataclass
from datetime import datetime


@dataclass(frozen=True)
class DateRange:
    """
    Value object representing a date range.
    """
    start_date: datetime
    end_date: datetime

    def __post_init__(self):
        if self.start_date > self.end_date:
            raise ValueError("Start date must be before or equal to end date")

    def contains(self, date: datetime) -> bool:
        """Check if a date is within this range."""
        return self.start_date <= date <= self.end_date

