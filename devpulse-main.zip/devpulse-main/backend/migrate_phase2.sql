-- Migration script to add Phase 2 columns and tables
-- Run this with: sqlite3 backend/devpulse.db < backend/migrate_phase2.sql

-- Add new columns to commits table
ALTER TABLE commits ADD COLUMN branch_name VARCHAR;
ALTER TABLE commits ADD COLUMN is_merge_commit BOOLEAN DEFAULT 0;
ALTER TABLE commits ADD COLUMN impact_category VARCHAR;

-- Create indexes for new columns
CREATE INDEX IF NOT EXISTS ix_commits_branch_name ON commits(branch_name);
CREATE INDEX IF NOT EXISTS ix_commits_is_merge_commit ON commits(is_merge_commit);
CREATE INDEX IF NOT EXISTS ix_commits_impact_category ON commits(impact_category);

-- Create daily_logs table
CREATE TABLE IF NOT EXISTS daily_logs (
    id INTEGER PRIMARY KEY,
    date DATETIME DEFAULT CURRENT_TIMESTAMP,
    satisfaction_score INTEGER,
    wellbeing_score INTEGER,
    blockers TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS ix_daily_logs_date ON daily_logs(date);

-- Create branch_metrics table
CREATE TABLE IF NOT EXISTS branch_metrics (
    id INTEGER PRIMARY KEY,
    repo_id INTEGER,
    branch_name VARCHAR,
    first_commit_date DATETIME,
    merge_date DATETIME,
    merge_commit_hash VARCHAR,
    cycle_time_days REAL,
    FOREIGN KEY (repo_id) REFERENCES repositories(id)
);

CREATE INDEX IF NOT EXISTS ix_branch_metrics_repo_id ON branch_metrics(repo_id);
CREATE INDEX IF NOT EXISTS ix_branch_metrics_branch_name ON branch_metrics(branch_name);

