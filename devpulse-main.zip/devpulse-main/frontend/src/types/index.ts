export interface Repository {
  id: number
  path: string
  name: string
  last_scanned: string
}

export interface Commit {
  id: number
  repo_id: number
  hash: string
  message: string
  author: string
  date: string
  files_changed: number
  insertions: number
  deletions: number
  type: CommitType | null
}

export type CommitType = 'Feature' | 'Bugfix' | 'Refactor' | 'Documentation' | 'Chore' | 'Unknown'

export interface LogbookEntry {
  id: number
  date: string
  content: string
}

export interface CrawlRequest {
  directory?: string
  months_back?: number
}

export interface CrawlResponse {
  repositories_found: number
  commits_added: number
}

export interface ChurnDataPoint {
  date: string
  total_changes: number
  insertions: number
  deletions: number
  commit_count: number
}

export interface ConsistencyMetrics {
  total_commits: number
  commits_per_week: number
  commits_per_month: number
  weeks_active: number
  first_commit?: string
  last_commit?: string
}

export interface CrossTeamImpactCommit {
  id: number
  hash: string
  message: string
  date: string
  repo_id: number
  type: CommitType | null
}

export interface ReportRequest {
  start_date: string
  end_date: string
  repo_id?: number
}

export interface ReportResponse {
  summary: string
  commit_count: number
  start_date: string
  end_date: string
}

export interface DashboardStats {
  totalCommits: number
  thisWeek: number
  thisMonth: number
  repos: number
}

export interface Task {
  id: number
  title: string
  description: string | null
  status: TaskStatus
  priority: TaskPriority
  platform: TaskPlatform
  external_id: string | null
  due_date: string | null
  created_at: string
  updated_at: string | null
}

export type TaskStatus = 'todo' | 'in-progress' | 'done'
export type TaskPriority = 'low' | 'medium' | 'high'
export type TaskPlatform = 'manual' | 'jira' | 'other'

export interface CommitTypeDistribution {
  type: string
  count: number
}

export interface RepositoryStat {
  repository_id: number
  repository_name: string
  commit_count: number
  total_changes: number
}

export interface CommitTrend {
  period: string
  commit_count: number
  insertions: number
  deletions: number
}

// Phase 2: DORA Metrics
export interface CycleTimeMetrics {
  average_days: number
  median_days: number
  min_days: number
  max_days: number
  total_branches: number
  trend: Array<{ period: string; value: number }>
}

export interface DeploymentFrequency {
  total_deployments: number
  frequency_per_week: number
  frequency_per_month: number
  trend: Array<{ period: string; count: number }>
}

export interface ChangeFailureRate {
  failure_rate: number
  total_deployments: number
  failed_deployments: number
  category: string
  incidents_count: number
  revert_commits_count: number
}

export interface MttrMetrics {
  mean_hours: number
  median_hours: number
  min_hours: number
  max_hours: number
  total_incidents: number
  resolved_incidents: number
  category: string
}

export interface DoraMetrics {
  deployment_frequency: DeploymentFrequency
  lead_time: CycleTimeMetrics
  change_failure_rate: ChangeFailureRate
  mttr: MttrMetrics
}

export interface BranchMetric {
  id: number
  repo_id: number
  branch_name: string
  first_commit_date: string
  merge_date: string | null
  merge_commit_hash: string | null
  cycle_time_days: number | null
}

// Phase 2: SPACE Metrics
export interface FocusTimeBlock {
  start_hour: number
  end_hour: number
  commit_count: number
  is_deep_work: boolean
}

export interface FlowScore {
  score: number
  deep_work_hours: number
  fragmentation_score: number
  optimal_hours: number[]
}

export interface SatisfactionMetrics {
  average_satisfaction: number
  average_wellbeing: number
  trend: string
  low_weeks_count: number
  total_entries: number
  scores_over_time: Array<{ date: string; satisfaction: number; wellbeing: number }>
}

export interface PerformanceMetrics {
  commits: number
  lines_changed: number
  net_change: number
  merge_commits: number
  code_reviews: number
  design_docs: number
  mentoring_sessions: number
  revert_rate: number
  quality_score: number
}

export interface ActivityMetrics {
  active_days: number
  active_days_pct: number
  avg_commits_per_day: number
  consistency_score: number
  longest_streak: number
  fragmentation_score: number
  total_commits: number
}

export interface CollaborationMetrics {
  code_reviews: number
  design_docs: number
  mentoring_sessions: number
  meetings: number
  unique_collaborators: number
  collaboration_score: number
  total_collaboration_activities: number
}

export interface SpaceMetrics {
  satisfaction: SatisfactionMetrics
  performance: PerformanceMetrics
  activity: ActivityMetrics
  collaboration: CollaborationMetrics
  efficiency: FlowScore
}

// Phase 2: Friction Tracking
export interface DailyLog {
  id: number
  date: string
  satisfaction_score: number
  wellbeing_score: number
  blockers: string | null
  created_at: string
}

export interface DailyLogCreate {
  date?: string
  satisfaction_score: number
  wellbeing_score: number
  blockers?: string
}

export interface HealthTrendPoint {
  date: string
  satisfaction_avg: number
  wellbeing_avg: number
  commit_count: number
}

// Phase 2: Impact Categories
export type ImpactCategory = 'Revenue' | 'Risk' | 'TechDebt' | 'Unknown'

export interface ImpactCategoryDistribution {
  revenue_driving: number
  risk_reduction: number
  tech_debt: number
  unknown: number
}

export interface ImpactSummary {
  total_commits: number
  distribution: ImpactCategoryDistribution
  percentages: {
    revenue_driving: number
    risk_reduction: number
    tech_debt: number
    unknown: number
  }
}

// Phase 2: Enhanced Report
export interface EnhancedReportResponse {
  summary: string
  weekly_summary: string
  commit_count: number
  start_date: string
  end_date: string
  dora_metrics: DoraMetrics | null
  space_metrics: SpaceMetrics | null
  impact_summary: ImpactSummary
}

// Sprint 1: Friction Logs
export interface FrictionLog {
  id: number
  date: string
  type: 'blocker' | 'learning' | 'win' | 'incident'
  description: string
  impact_level: number
  tags?: string
  resolution?: string
  created_at: string
}

export interface FrictionLogCreate {
  date: string
  type: 'blocker' | 'learning' | 'win' | 'incident'
  description: string
  impact_level: number
  tags?: string
  resolution?: string
}

export interface FrictionLogStats {
  total: number
  by_type: Record<string, number>
  avg_impact: number
  unresolved: number
}

// Sprint 1: Manual Entries
export interface ManualEntry {
  id: number
  date: string
  type: 'code_review' | 'design_doc' | 'mentoring' | 'incident' | 'meeting'
  title: string
  description?: string
  impact?: string
  collaborators?: string
  links?: string
  duration_minutes?: number
  created_at: string
}

export interface ManualEntryCreate {
  date: string
  type: 'code_review' | 'design_doc' | 'mentoring' | 'incident' | 'meeting'
  title: string
  description?: string
  impact?: string
  collaborators?: string
  links?: string
  duration_minutes?: number
}

// Sprint 5: Career Moments
export interface CareerMoment {
  id: number
  date: string
  type: 'win' | 'failure' | 'pivot' | 'learning'
  title: string
  story?: string
  impact?: string
  witnesses?: string
  tags?: string
  related_commits?: number[]
  related_entries?: number[]
  created_at: string
  updated_at: string
}

export interface CareerMomentCreate {
  date: string
  type: 'win' | 'failure' | 'pivot' | 'learning'
  title: string
  story?: string
  impact?: string
  witnesses?: string
  tags?: string
  related_commits?: number[]
  related_entries?: number[]
}

// Sprint 5: Goals & OKRs
export interface Goal {
  id: number
  title: string
  description?: string
  deadline: string
  status: 'active' | 'completed' | 'cancelled'
  progress: number
  target_metric?: string
  current_metric?: string
  created_at: string
  updated_at: string
}

export interface GoalCreate {
  title: string
  description?: string
  deadline: string
  status?: string
  progress?: number
  target_metric?: string
  current_metric?: string
}

export interface GoalLink {
  goal_id: number
  commit_id?: number
  entry_id?: number
}

// Sprint 5: Peer Feedback
export interface Feedback {
  id: number
  from_who: string
  date: string
  context?: string
  feedback_text: string
  category?: 'positive' | 'constructive' | 'neutral'
  tags?: string
  created_at: string
}

export interface FeedbackCreate {
  from_who: string
  date: string
  context?: string
  feedback_text: string
  category?: string
  tags?: string
}

// Sprint 5: Time Patterns
export interface WorkingHoursAnalysis {
  hour_distribution: Record<number, number>
  day_of_week_distribution: Record<number, number>
  top_hours: number[]
  best_focus_time: {
    start: number
    end: number
  } | null
  total_commits: number
}

export interface AfterHoursAnalysis {
  after_hours_count: number
  weekend_count: number
  after_hours_commits: number[]
  weekend_commits: number[]
  percentage_after_hours: number
  percentage_weekend: number
}

// Sprint 6: Benchmarks & Comparisons
export interface TeamBenchmark {
  id: number
  metric_name: string
  metric_value: number
  metric_unit?: string
  period_start: string
  period_end: string
  team_name?: string
  source: string
  notes?: string
  created_at: string
  updated_at?: string
}

export interface TeamBenchmarkCreate {
  metric_name: string
  metric_value: number
  metric_unit?: string
  period_start: string
  period_end: string
  team_name?: string
  source?: string
  notes?: string
}

export interface IndustryBenchmark {
  id: number
  metric_name: string
  category: 'elite' | 'high' | 'medium' | 'low'
  min_value?: number
  max_value?: number
  source: string
  year?: number
  created_at: string
}

export interface ComparisonResult {
  your_value: number
  team_average?: number
  team_percentile?: number
  industry_category?: string
  industry_percentile?: number
  trend?: string
  trend_percentage?: number
}

export interface HistoricalSnapshot {
  id: number
  period_label: string
  period_start: string
  period_end: string
  snapshot_data: any
  dora_metrics: any
  space_metrics: any
  created_at: string
}

// Saved Reports (Sprint 7)
export interface SavedReport {
  id: number
  name: string
  quarter: string
  period_start: string
  period_end: string
  tags: string[]
  created_at: string
}

export interface ReportComparison {
  reports: Array<{
    id: number
    name: string
    quarter: string
    period: {
      start: string
      end: string
    }
    metrics: {
      dora: any
      space: any
      summary: any
    }
  }>
  comparison_summary: {
    dora_trends: Array<{
      quarter: string
      deployment_frequency: number
      lead_time_days: number
    }>
    space_trends: Array<{
      quarter: string
      satisfaction: number
    }>
    improvements: Array<{
      metric: string
      change: string
      trend: string
    }>
  }
}

