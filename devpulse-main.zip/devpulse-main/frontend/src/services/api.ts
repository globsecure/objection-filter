import axios from 'axios'
import type {
  Repository,
  Commit,
  LogbookEntry,
  CrawlRequest,
  CrawlResponse,
  ChurnDataPoint,
  ConsistencyMetrics,
  CrossTeamImpactCommit,
  ReportRequest,
  ReportResponse,
  Task,
  CommitTypeDistribution,
  RepositoryStat,
  CommitTrend,
  CycleTimeMetrics,
  DeploymentFrequency,
  ChangeFailureRate,
  MttrMetrics,
  DoraMetrics,
  BranchMetric,
  FlowScore,
  SatisfactionMetrics,
  PerformanceMetrics,
  ActivityMetrics,
  CollaborationMetrics,
  SpaceMetrics,
  DailyLog,
  DailyLogCreate,
  HealthTrendPoint,
  EnhancedReportResponse,
  FrictionLog,
  FrictionLogCreate,
  FrictionLogStats,
  ManualEntry,
  FocusTimeBlock,
  ManualEntryCreate,
  CareerMoment,
  CareerMomentCreate,
  Goal,
  GoalCreate,
  GoalLink,
  Feedback,
  FeedbackCreate,
  WorkingHoursAnalysis,
  AfterHoursAnalysis,
  TeamBenchmark,
  TeamBenchmarkCreate,
  IndustryBenchmark,
  ComparisonResult,
  HistoricalSnapshot,
} from '../types'

const api = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json',
  },
})

export const commitsApi = {
  crawl: (request: CrawlRequest): Promise<CrawlResponse> =>
    api.post('/crawl', request).then((res) => res.data),
  
  list: (params?: {
    start_date?: string
    end_date?: string
    repo_id?: number
    commit_type?: string
    limit?: number
    offset?: number
  }): Promise<Commit[]> =>
    api.get('/commits', { params }).then((res) => res.data),
  
  listRepositories: (params?: {
    tags?: string
    team?: string
  }): Promise<Repository[]> =>
    api.get('/repositories', { params }).then((res) => res.data),
  
  updateRepositoryTags: (repoId: number, tags: string[]): Promise<{ id: number; tags: string[] }> =>
    api.patch(`/repositories/${repoId}/tags`, tags).then((res) => res.data),
  
  updateRepositoryTeam: (repoId: number, team: string): Promise<{ id: number; team: string }> =>
    api.patch(`/repositories/${repoId}/team`, team).then((res) => res.data),
  
  getCrossRepoImpacts: (params: {
    repo_id: number
    other_repos?: number[]
  }): Promise<any> =>
    api.get('/commits/cross-repo-impacts', { params }).then((res) => res.data),
}

export const metricsApi = {
  getChurn: (params?: {
    start_date?: string
    end_date?: string
  }): Promise<ChurnDataPoint[]> =>
    api.get('/metrics/churn', { params }).then((res) => res.data),
  
  getConsistency: (params?: {
    start_date?: string
    end_date?: string
  }): Promise<ConsistencyMetrics> =>
    api.get('/metrics/consistency', { params }).then((res) => res.data),
  
  getCrossTeamImpact: (params?: {
    start_date?: string
    end_date?: string
  }): Promise<CrossTeamImpactCommit[]> =>
    api.get('/metrics/cross-team', { params }).then((res) => res.data),
  
  getCommitTypes: (params?: {
    start_date?: string
    end_date?: string
  }): Promise<CommitTypeDistribution[]> =>
    api.get('/metrics/commit-types', { params }).then((res) => res.data),
  
  getRepositoryStats: (params?: {
    start_date?: string
    end_date?: string
  }): Promise<RepositoryStat[]> =>
    api.get('/metrics/repository-stats', { params }).then((res) => res.data),
  
  getTrends: (params?: {
    start_date?: string
    end_date?: string
    group_by?: 'day' | 'week' | 'month'
  }): Promise<CommitTrend[]> =>
    api.get('/metrics/trends', { params }).then((res) => res.data),
}

export const reportsApi = {
  generate: (request: ReportRequest & { include_metrics?: boolean }): Promise<EnhancedReportResponse> =>
    api.post('/reports/generate', request).then((res) => res.data),
  
  generatePDF: (request: ReportRequest): Promise<Blob> =>
    api.post('/reports/pdf', request, { responseType: 'blob' }).then((res) => res.data),
  
  previewReport: (request: ReportRequest & { use_llm?: boolean; format?: string; redact_sensitive?: boolean }): Promise<any> =>
    api.post('/reports/preview', request).then((res) => res.data),
  
  generateReport: (request: ReportRequest & { use_llm?: boolean; format?: string; redact_sensitive?: boolean }): Promise<any> =>
    api.post('/reports/generate', request).then((res) => res.data),
  
  generateReportPDF: (request: ReportRequest & { use_llm?: boolean; redact_sensitive?: boolean }): Promise<Blob> =>
    api.post('/reports/generate', { ...request, format: 'pdf' }, { responseType: 'blob' }).then((res) => res.data),
  
  // Saved Reports (Sprint 7)
  saveReport: (request: ReportRequest & { use_llm?: boolean }, name: string, quarter?: string, tags?: string, notes?: string): Promise<any> =>
    api.post(`/reports/save?name=${encodeURIComponent(name)}${quarter ? `&quarter=${encodeURIComponent(quarter)}` : ''}${tags ? `&tags=${encodeURIComponent(tags)}` : ''}${notes ? `&notes=${encodeURIComponent(notes)}` : ''}`, request).then((res) => res.data),
  
  getSavedReports: (quarter?: string, repoId?: number): Promise<any[]> =>
    api.get('/reports/saved', { params: { quarter, repo_id: repoId } }).then((res) => res.data),
  
  getSavedReport: (id: number, format: 'json' | 'markdown' = 'json'): Promise<any> =>
    api.get(`/reports/saved/${id}`, { params: { format } }).then((res) => res.data),
  
  deleteSavedReport: (id: number): Promise<void> =>
    api.delete(`/reports/saved/${id}`).then(() => undefined),
  
  compareReports: (reportIds: string): Promise<any> =>
    api.get('/reports/saved/compare', { params: { report_ids: reportIds } }).then((res) => res.data),
  
  // Report Editing (Sprint 9)
  editReportSection: (reportId: number, section: string, editedContent: string): Promise<any> =>
    api.post(`/reports/${reportId}/edit`, { section, edited_content: editedContent }).then((res) => res.data),
  
  getReportVersions: (reportId: number): Promise<any> =>
    api.get(`/reports/${reportId}/versions`).then((res) => res.data),
}

export const logbookApi = {
  create: (entry: { content: string; date?: string }): Promise<LogbookEntry> =>
    api.post('/logbook', entry).then((res) => res.data),
  
  list: (params?: {
    start_date?: string
    end_date?: string
    limit?: number
    offset?: number
  }): Promise<LogbookEntry[]> =>
    api.get('/logbook', { params }).then((res) => res.data),
}

export const tasksApi = {
  create: (task: {
    title: string
    description?: string
    status?: string
    priority?: string
    platform?: string
    external_id?: string
    due_date?: string
  }): Promise<Task> =>
    api.post('/tasks', task).then((res) => res.data),
  
  list: (params?: {
    status?: string
    priority?: string
    platform?: string
    limit?: number
    offset?: number
  }): Promise<Task[]> =>
    api.get('/tasks', { params }).then((res) => res.data),
  
  get: (id: number): Promise<Task> =>
    api.get(`/tasks/${id}`).then((res) => res.data),
  
  update: (id: number, task: Partial<Task>): Promise<Task> =>
    api.put(`/tasks/${id}`, task).then((res) => res.data),
  
  delete: (id: number): Promise<void> =>
    api.delete(`/tasks/${id}`).then(() => undefined),
}

// DORA Metrics API
export const doraApi = {
  getCycleTime: (params?: {
    start_date?: string
    end_date?: string
    repo_id?: number
  }): Promise<CycleTimeMetrics> =>
    api.get('/dora/cycle-time', { params }).then((res) => res.data),
  
  getDeploymentFrequency: (params?: {
    start_date?: string
    end_date?: string
    repo_id?: number
  }): Promise<DeploymentFrequency> =>
    api.get('/dora/deployment-frequency', { params }).then((res) => res.data),
  
  getChangeFailureRate: (params?: {
    start_date?: string
    end_date?: string
    repo_id?: number
  }): Promise<ChangeFailureRate> =>
    api.get('/dora/change-failure-rate', { params }).then((res) => res.data),
  
  getMttr: (params?: {
    start_date?: string
    end_date?: string
    repo_id?: number
  }): Promise<MttrMetrics> =>
    api.get('/dora/mttr', { params }).then((res) => res.data),
  
  getTrends: (params?: {
    start_date?: string
    end_date?: string
    repo_id?: number
    group_by?: string
  }): Promise<{
    group_by: string
    trends: Array<{
      period: string
      deployment_frequency: number
      lead_time: number
      change_failure_rate: number
      mttr: number
    }>
  }> =>
    api.get('/dora/trends', { params }).then((res) => res.data),
  
  getCompare: (params: {
    period1_start: string
    period1_end: string
    period2_start: string
    period2_end: string
    repo_id?: number
  }): Promise<{
    period1: { start: string; end: string; metrics: DoraMetrics }
    period2: { start: string; end: string; metrics: DoraMetrics }
    changes: {
      deployment_frequency: number
      lead_time: number
      change_failure_rate: number
      mttr: number
    }
  }> =>
    api.get('/dora/compare', { params }).then((res) => res.data),
  
  getBranchMetrics: (params?: {
    start_date?: string
    end_date?: string
    repo_id?: number
    limit?: number
  }): Promise<BranchMetric[]> =>
    api.get('/dora/branch-metrics', { params }).then((res) => res.data),
  
  getCycleTimeDistribution: (params?: {
    start_date?: string
    end_date?: string
    repo_id?: number
  }): Promise<{ distribution: Array<{ bucket: string; count: number }>; total: number }> =>
    api.get('/dora/cycle-time-distribution', { params }).then((res) => res.data),
  
  getSummary: (params?: {
    start_date?: string
    end_date?: string
    repo_id?: number
  }): Promise<DoraMetrics> =>
    api.get('/dora/summary', { params }).then((res) => res.data),
  
  getAggregate: (params?: {
    start_date?: string
    end_date?: string
    repo_ids?: number[]
    tags?: string[]
    team?: string
  }): Promise<any> =>
    api.get('/dora/aggregate', { params }).then((res) => res.data),
}

// SPACE Metrics API
export const spaceApi = {
  getSatisfaction: (params?: {
    start_date?: string
    end_date?: string
  }): Promise<SatisfactionMetrics> =>
    api.get('/space/satisfaction', { params }).then((res) => res.data),
  
  getPerformance: (params?: {
    start_date?: string
    end_date?: string
    repo_id?: number
  }): Promise<PerformanceMetrics> =>
    api.get('/space/performance', { params }).then((res) => res.data),
  
  getActivity: (params?: {
    start_date?: string
    end_date?: string
    repo_id?: number
  }): Promise<ActivityMetrics> =>
    api.get('/space/activity', { params }).then((res) => res.data),
  
  getCollaboration: (params?: {
    start_date?: string
    end_date?: string
  }): Promise<CollaborationMetrics> =>
    api.get('/space/collaboration', { params }).then((res) => res.data),
  
  getTrends: (params?: {
    start_date?: string
    end_date?: string
    repo_id?: number
    group_by?: string
  }): Promise<{
    group_by: string
    trends: Array<{
      period: string
      satisfaction: number
      performance_score: number
      activity_score: number
      collaboration_score: number
      efficiency_score: number
    }>
  }> =>
    api.get('/space/trends', { params }).then((res) => res.data),
  
  getFocusTime: (params?: {
    start_date?: string
    end_date?: string
    repo_id?: number
  }): Promise<{
    flow_score: FlowScore
    focus_blocks: FocusTimeBlock[]
    hourly_distribution: Array<{ hour: number; count: number }>
  }> =>
    api.get('/space/focus-time', { params }).then((res) => res.data),
  
  getFlowScore: (params?: {
    start_date?: string
    end_date?: string
    repo_id?: number
  }): Promise<FlowScore> =>
    api.get('/space/flow-score', { params }).then((res) => res.data),
  
  getOptimalHours: (params?: {
    start_date?: string
    end_date?: string
    repo_id?: number
  }): Promise<{
    peak_hours: number[]
    hourly_distribution: Array<{ hour: number; commits: number; lines_changed: number; is_peak: boolean }>
    recommendation: string
  }> =>
    api.get('/space/optimal-hours', { params }).then((res) => res.data),
  
  getDailyActivity: (params?: {
    start_date?: string
    end_date?: string
    repo_id?: number
  }): Promise<Array<{ day: number; day_name: string; hour: number; count: number }>> =>
    api.get('/space/daily-activity', { params }).then((res) => res.data),
  
  getSummary: (params?: {
    start_date?: string
    end_date?: string
    repo_id?: number
  }): Promise<SpaceMetrics> =>
    api.get('/space/summary', { params }).then((res) => res.data),
  
  getAggregate: (params?: {
    start_date?: string
    end_date?: string
    repo_ids?: number[]
    tags?: string[]
    team?: string
  }): Promise<any> =>
    api.get('/space/aggregate', { params }).then((res) => res.data),
}

// Friction/Health Tracking API
export const frictionApi = {
  // DailyLog endpoints (existing)
  createLog: (log: DailyLogCreate): Promise<DailyLog> =>
    api.post('/friction/log', log).then((res) => res.data),
  
  listLogs: (params?: {
    start_date?: string
    end_date?: string
    limit?: number
    offset?: number
  }): Promise<DailyLog[]> =>
    api.get('/friction/logs', { params }).then((res) => res.data),
  
  getLog: (id: number): Promise<DailyLog> =>
    api.get(`/friction/logs/${id}`).then((res) => res.data),
  
  deleteLog: (id: number): Promise<void> =>
    api.delete(`/friction/logs/${id}`).then(() => undefined),
  
  getHealthTrends: (params?: {
    start_date?: string
    end_date?: string
  }): Promise<HealthTrendPoint[]> =>
    api.get('/friction/health-trends', { params }).then((res) => res.data),
  
  analyzeBlockers: (params?: {
    start_date?: string
    end_date?: string
  }): Promise<{
    total_logs_with_blockers: number
    blockers: Array<{ category: string; count: number }>
    recent_blockers: Array<{ date: string; blocker: string | null; satisfaction: number }>
  }> =>
    api.get('/friction/blocker-analysis', { params }).then((res) => res.data),
  
  getSummary: (params?: {
    start_date?: string
    end_date?: string
  }): Promise<{
    total_entries: number
    avg_satisfaction: number
    avg_wellbeing: number
    entries_with_blockers: number
    trend: string
  }> =>
    api.get('/friction/summary', { params }).then((res) => res.data),
  
  // FrictionLog endpoints (Sprint 1)
  createFrictionLog: (log: FrictionLogCreate): Promise<FrictionLog> =>
    api.post('/friction', log).then((res) => res.data),
  
  getFrictionLogs: (params?: {
    start_date?: string
    end_date?: string
    type?: string
  }): Promise<FrictionLog[]> =>
    api.get('/friction', { params }).then((res) => res.data),
  
  getFrictionStats: (params?: {
    days?: number
  }): Promise<FrictionLogStats> =>
    api.get('/friction/stats', { params }).then((res) => res.data),
}

// Manual Entries API (Sprint 1)
export const manualEntriesApi = {
  create: (entry: ManualEntryCreate): Promise<ManualEntry> =>
    api.post('/manual-entries', entry).then((res) => res.data),
  
  list: (params?: {
    start_date?: string
    end_date?: string
    type?: string
    limit?: number
    offset?: number
  }): Promise<ManualEntry[]> =>
    api.get('/manual-entries', { params }).then((res) => res.data),
  
  get: (id: number): Promise<ManualEntry> =>
    api.get(`/manual-entries/${id}`).then((res) => res.data),
  
  update: (id: number, entry: Partial<ManualEntryCreate>): Promise<ManualEntry> =>
    api.put(`/manual-entries/${id}`, entry).then((res) => res.data),
  
  delete: (id: number): Promise<void> =>
    api.delete(`/manual-entries/${id}`).then(() => undefined),
}

// Career Moments API (Sprint 5)
export const momentsApi = {
  create: (moment: CareerMomentCreate): Promise<CareerMoment> =>
    api.post('/moments', moment).then((res) => res.data),
  
  list: (params?: {
    start_date?: string
    end_date?: string
    type?: string
    tags?: string
  }): Promise<CareerMoment[]> =>
    api.get('/moments', { params }).then((res) => res.data),
  
  get: (id: number): Promise<CareerMoment> =>
    api.get(`/moments/${id}`).then((res) => res.data),
  
  update: (id: number, moment: Partial<CareerMomentCreate>): Promise<CareerMoment> =>
    api.put(`/moments/${id}`, moment).then((res) => res.data),
  
  delete: (id: number): Promise<void> =>
    api.delete(`/moments/${id}`).then(() => undefined),
  
  getStats: (params?: {
    start_date?: string
    end_date?: string
  }): Promise<{
    total: number
    by_type: Record<string, number>
    by_quarter: Record<string, number>
  }> =>
    api.get('/moments/stats/summary', { params }).then((res) => res.data),
}

// Goals & OKRs API (Sprint 5)
export const goalsApi = {
  create: (goal: GoalCreate): Promise<Goal> =>
    api.post('/goals', goal).then((res) => res.data),
  
  list: (params?: {
    status?: string
  }): Promise<Goal[]> =>
    api.get('/goals', { params }).then((res) => res.data),
  
  get: (id: number): Promise<Goal> =>
    api.get(`/goals/${id}`).then((res) => res.data),
  
  update: (id: number, goal: Partial<GoalCreate>): Promise<Goal> =>
    api.put(`/goals/${id}`, goal).then((res) => res.data),
  
  link: (link: GoalLink): Promise<{ message: string }> =>
    api.post('/goals/link', link).then((res) => res.data),
  
  getProgress: (id: number): Promise<{
    goal: Goal
    linked_commits: number
    linked_entries: number
    total_work_items: number
  }> =>
    api.get(`/goals/${id}/progress`).then((res) => res.data),
}

// Peer Feedback API (Sprint 5)
export const feedbackApi = {
  create: (feedback: FeedbackCreate): Promise<Feedback> =>
    api.post('/feedback', feedback).then((res) => res.data),
  
  list: (params?: {
    start_date?: string
    end_date?: string
    category?: string
  }): Promise<Feedback[]> =>
    api.get('/feedback', { params }).then((res) => res.data),
  
  getTrends: (params?: {
    start_date?: string
    end_date?: string
  }): Promise<{
    total: number
    by_category: Record<string, number>
    by_month: Record<string, number>
  }> =>
    api.get('/feedback/stats/trends', { params }).then((res) => res.data),
}

// Time Patterns API (Sprint 5)
export const timePatternsApi = {
  getWorkingHours: (params?: {
    start_date?: string
    end_date?: string
    repo_id?: number
  }): Promise<WorkingHoursAnalysis> =>
    api.get('/time-patterns/working-hours', { params }).then((res) => res.data),
  
  getAfterHours: (params?: {
    start_date?: string
    end_date?: string
    repo_id?: number
    work_start_hour?: number
    work_end_hour?: number
  }): Promise<AfterHoursAnalysis> =>
    api.get('/time-patterns/after-hours', { params }).then((res) => res.data),
}

// Settings API
export const settingsApi = {
  getConfig: (): Promise<{
    projects_dir: string
    llm_provider: string
    database_url: string
    has_openai_key: boolean
    has_gemini_key: boolean
    env_file: string
    instructions: {
      file_location: string
      required_vars: string[]
      note: string
    }
  }> =>
    api.get('/settings/config').then((res) => res.data),
  
  getSecuritySettings: (userId: string = 'default'): Promise<{
    enable_secret_detection: boolean
    auto_redact_secrets: boolean
    block_on_secret: boolean
    redact_emails: boolean
    redact_internal_urls: boolean
  }> =>
    api.get('/settings/security', { params: { user_id: userId } }).then((res) => res.data),
  
  updateSecuritySettings: (settings: {
    enable_secret_detection: boolean
    auto_redact_secrets: boolean
    block_on_secret: boolean
    redact_emails: boolean
    redact_internal_urls: boolean
  }, userId: string = 'default'): Promise<{
    enable_secret_detection: boolean
    auto_redact_secrets: boolean
    block_on_secret: boolean
    redact_emails: boolean
    redact_internal_urls: boolean
  }> =>
    api.put('/settings/security', settings, { params: { user_id: userId } }).then((res) => res.data),
}

// User Context API (Sprint 9)
export const userContextApi = {
  get: (userId: string = 'default'): Promise<any> =>
    api.get('/user-context', { params: { user_id: userId } }).then((res) => res.data),
  
  update: (userId: string = 'default', context: {
    role?: string
    team?: string
    business_domain?: string
    company?: string
    preferred_language?: string
  }): Promise<any> =>
    api.put('/user-context', context, { params: { user_id: userId } }).then((res) => res.data),
}

// Templates API (Sprint 9)
export const templatesApi = {
  list: (userId: string = 'default'): Promise<any[]> =>
    api.get('/report-templates', { params: { user_id: userId } }).then((res) => res.data),
  
  get: (templateId: number, userId: string = 'default'): Promise<any> =>
    api.get(`/report-templates/${templateId}`, { params: { user_id: userId } }).then((res) => res.data),
  
  create: (template: {
    name: string
    description?: string
    template_type: string
    sections: string[]
    prompt_overrides?: Record<string, string>
  }, userId: string = 'default'): Promise<any> =>
    api.post('/report-templates', template, { params: { user_id: userId } }).then((res) => res.data),
  
  update: (templateId: number, update: {
    name?: string
    description?: string
    template_type?: string
    sections?: string[]
    prompt_overrides?: Record<string, string>
    is_default?: boolean
  }, userId: string = 'default'): Promise<any> =>
    api.put(`/report-templates/${templateId}`, update, { params: { user_id: userId } }).then((res) => res.data),
  
  delete: (templateId: number, userId: string = 'default'): Promise<void> =>
    api.delete(`/report-templates/${templateId}`, { params: { user_id: userId } }).then(() => undefined),
}

// Security API
export const securityApi = {
  checkSecrets: (text: string): Promise<{
    has_secrets: boolean
    secrets: Array<{ type: string; matched_text: string; position: number }>
    redacted_text?: string
  }> =>
    api.post('/security/check-secrets', { text }).then((res) => res.data),
}

// PayPal Metrics API
export const paypalApi = {
  getSayDoRatio: (quarterStart?: string, quarterEnd?: string): Promise<{
    ratio: number
    completed: number
    total: number
    warning: boolean
    quarter_start: string
    quarter_end: string
    target: number
  }> =>
    api.get('/paypal/say-do-ratio', {
      params: {
        quarter_start: quarterStart,
        quarter_end: quarterEnd
      }
    }).then((res) => res.data),
  
  getRiskRadar: (daysAhead?: number): Promise<Array<{
    goal_id: number
    title: string
    deadline: string
    days_until_deadline: number
    progress: number
    risk_reasons: string[]
    recommendation: string
  }>> =>
    api.get('/paypal/risk-radar', {
      params: { days_ahead: daysAhead }
    }).then((res) => res.data),
  
  getCrossTeamWork: (startDate?: string, endDate?: string): Promise<{
    cross_team_percentage: number
    cross_team_count: number
    total_count: number
    breakdown: Array<{
      repo_id: number
      repo_name: string
      tags: string
      commit_count: number
    }>
  }> =>
    api.get('/paypal/cross-team-work', {
      params: {
        start_date: startDate,
        end_date: endDate
      }
    }).then((res) => res.data),
  
  getMentees: (startDate?: string, endDate?: string): Promise<{
    mentee_count: number
    mentees: string[]
    target: number
  }> =>
    api.get('/paypal/mentees', {
      params: {
        start_date: startDate,
        end_date: endDate
      }
    }).then((res) => res.data),
  
  getCodeReviewDepth: (startDate?: string, endDate?: string): Promise<{
    architectural_percentage: number
    superficial_percentage: number
    architectural_count: number
    superficial_count: number
    total_count: number
    unclassified_count: number
  }> =>
    api.get('/paypal/code-review-depth', {
      params: {
        start_date: startDate,
        end_date: endDate
      }
    }).then((res) => res.data),
  
  getPromotionReadiness: (quarterStart?: string, quarterEnd?: string): Promise<{
    score: number
    checks: {
      mentees: boolean
      say_do_ratio: boolean
      cross_team_work: boolean
      org_level_impact: boolean
    }
    gaps: string[]
    recommendations: string[]
    details: any
  }> =>
    api.get('/paypal/promotion-readiness', {
      params: {
        quarter_start: quarterStart,
        quarter_end: quarterEnd
      }
    }).then((res) => res.data),
}

// Data Quality API
export const dataQualityApi = {
  getCompleteness: (days?: number): Promise<{
    overall_score: number
    breakdown: {
      commits_categorized: { score: number; total: number; incomplete: number }
      incidents_resolved: { score: number; total: number; incomplete: number }
      code_reviews_complete: { score: number; total: number; incomplete: number }
    }
    issues: Array<{ type: string; count: number; message: string }>
    recommendations: string[]
    period: { start: string; end: string }
  }> =>
    api.get('/data-quality/completeness', { params: { days } }).then((res) => res.data),
  
  getReminders: (days?: number): Promise<Array<{
    type: string
    priority: string
    message: string
    action: string
    count?: number
  }>> =>
    api.get('/data-quality/reminders', { params: { days } }).then((res) => res.data),
  
  getWarnings: (days?: number): Promise<Array<{
    type: string
    severity: string
    message: string
    recommendation: string
    count: number
    items?: Array<{ id: number; date: string }>
  }>> =>
    api.get('/data-quality/warnings', { params: { days } }).then((res) => res.data),
}

// Quality & Validation API
export const qualityApi = {
  scoreCommitMessage: (message: string): Promise<{
    score: number
    grade: string
    issues: string[]
    positives: string[]
    message_length: number
  }> =>
    api.post('/quality/commit-score', { message }).then((res) => res.data),
  
  getCompleteness: (params?: {
    start_date?: string
    end_date?: string
    repo_id?: number
  }): Promise<any> =>
    api.get('/quality/completeness', { params }).then((res) => res.data),
}

// Validation API
export const validationApi = {
  validateRepository: (params: {
    repo_path?: string
    repo_id?: number
  }): Promise<any> =>
    api.get('/validation/repository', { params }).then((res) => res.data),
}

// Backup API
export const backupApi = {
  createBackup: (params?: {
    keep_backups?: number
  }): Promise<any> =>
    api.post('/backup/create', null, { params }).then((res) => res.data),
}

// Export API
export const exportApi = {
  exportData: (params?: {
    format?: string
    include_commits?: boolean
    include_friction_logs?: boolean
    include_manual_entries?: boolean
    include_repositories?: boolean
    start_date?: string
    end_date?: string
    repo_id?: number
  }): Promise<any> =>
    api.get('/export', { params }).then((res) => res.data),
  
  importData: (data: any, overwrite?: boolean): Promise<any> =>
    api.post('/import', { data, overwrite }).then((res) => res.data),
}

// Benchmarks API (Sprint 6)
export const benchmarksApi = {
  getTeamBenchmarks: (params?: {
    metric_name?: string
    team_name?: string
    start_date?: string
    end_date?: string
  }): Promise<TeamBenchmark[]> =>
    api.get('/benchmarks/team', { params }).then((res) => res.data),

  createTeamBenchmark: (benchmark: TeamBenchmarkCreate): Promise<TeamBenchmark> =>
    api.post('/benchmarks/team', benchmark).then((res) => res.data),

  updateTeamBenchmark: (id: number, benchmark: Partial<TeamBenchmarkCreate>): Promise<TeamBenchmark> =>
    api.put(`/benchmarks/team/${id}`, benchmark).then((res) => res.data),

  deleteTeamBenchmark: (id: number): Promise<any> =>
    api.delete(`/benchmarks/team/${id}`).then((res) => res.data),

  importTeamBenchmarks: (benchmarks: TeamBenchmarkCreate[]): Promise<any> =>
    api.post('/benchmarks/team/import', benchmarks).then((res) => res.data),

  getIndustryBenchmarks: (metric_name?: string): Promise<IndustryBenchmark[]> =>
    api.get('/benchmarks/industry', { params: { metric_name } }).then((res) => res.data),

  compareMetrics: (params: {
    start_date: string
    end_date: string
    team_name?: string
    repo_id?: number
  }): Promise<any> =>
    api.get('/benchmarks/compare', { params }).then((res) => res.data),

  createSnapshot: (params: {
    period_label: string
    period_start: string
    period_end: string
    repo_id?: number
  }): Promise<HistoricalSnapshot> =>
    api.post('/benchmarks/snapshot', null, { params }).then((res) => res.data),

  getSnapshots: (period_label?: string): Promise<HistoricalSnapshot[]> =>
    api.get('/benchmarks/snapshot', { params: { period_label } }).then((res) => res.data),

  compareHistorical: (periods: string): Promise<any> =>
    api.get('/benchmarks/compare/historical', { params: { periods } }).then((res) => res.data),
}

export default api

