import { useState } from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Dashboard from './pages/Dashboard'
import Review from './pages/Review'
import LogbookPage from './pages/LogbookPage'
import TasksPage from './pages/TasksPage'
import FrictionPage from './pages/FrictionPage'
import ManualEntriesPage from './pages/ManualEntriesPage'
import TimelinePage from './pages/TimelinePage'
import CareerMomentsPage from './pages/CareerMomentsPage'
import GoalsPage from './pages/GoalsPage'
import FeedbackPage from './pages/FeedbackPage'
import { ComparisonPage } from './pages/ComparisonPage'
import { SavedReportsPage } from './pages/SavedReportsPage'
import Settings from './pages/Settings'
import { Sidebar } from './components/Sidebar'

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        
        {/* Mobile menu button */}
        <div className="lg:hidden fixed top-4 left-4 z-30">
          <button
            onClick={() => setSidebarOpen(true)}
            className="bg-white p-2 rounded-md shadow-md text-gray-700 hover:bg-gray-100"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>

        <main className="lg:ml-64">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/logbook" element={<LogbookPage />} />
            <Route path="/tasks" element={<TasksPage />} />
            <Route path="/friction" element={<FrictionPage />} />
            <Route path="/manual-entries" element={<ManualEntriesPage />} />
            <Route path="/career-moments" element={<CareerMomentsPage />} />
            <Route path="/goals" element={<GoalsPage />} />
            <Route path="/feedback" element={<FeedbackPage />} />
            <Route path="/timeline" element={<TimelinePage />} />
            <Route path="/comparison" element={<ComparisonPage />} />
            <Route path="/review" element={<Review />} />
            <Route path="/saved-reports" element={<SavedReportsPage />} />
            <Route path="/settings" element={<Settings />} />
          </Routes>
        </main>
      </div>
    </Router>
  )
}

export default App

