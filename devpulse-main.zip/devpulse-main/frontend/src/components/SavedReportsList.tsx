import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { reportsApi } from '../services/api';

interface SavedReport {
  id: number;
  name: string;
  quarter: string;
  period_start: string;
  period_end: string;
  tags: string[];
  created_at: string;
}

interface SavedReportsListProps {
  onCompare?: (reportIds: number[]) => void;
}

export const SavedReportsList: React.FC<SavedReportsListProps> = ({ onCompare }) => {
  const [reports, setReports] = useState<SavedReport[]>([]);
  const [selectedReports, setSelectedReports] = useState<number[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    loadReports();
  }, []);

  const loadReports = async () => {
    try {
      const data = await reportsApi.getSavedReports();
      setReports(data);
    } catch (error) {
      console.error('Error loading reports:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to delete this report?')) return;
    
    try {
      await reportsApi.deleteSavedReport(id);
      setReports(reports.filter(r => r.id !== id));
    } catch (error) {
      console.error('Error deleting report:', error);
    }
  };

  const handleCompare = () => {
    if (selectedReports.length < 2) {
      alert('Please select at least 2 reports to compare');
      return;
    }

    if (onCompare) {
      onCompare(selectedReports);
    } else {
      // Navigate to comparison page with report IDs as query params
      navigate(`/saved-reports?compare=${selectedReports.join(',')}`);
    }
  };

  if (loading) {
    return <div>Loading saved reports...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Saved Reports</h2>
        {selectedReports.length >= 2 && (
          <button
            onClick={handleCompare}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Compare Selected ({selectedReports.length})
          </button>
        )}
      </div>

      <div className="grid gap-4">
        {reports.map((report) => (
          <div
            key={report.id}
            className="border rounded-lg p-4 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={selectedReports.includes(report.id)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedReports([...selectedReports, report.id]);
                      } else {
                        setSelectedReports(selectedReports.filter(id => id !== report.id));
                      }
                    }}
                  />
                  <h3 className="text-lg font-semibold">{report.name}</h3>
                  {report.quarter && (
                    <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-sm">
                      {report.quarter}
                    </span>
                  )}
                </div>
                <p className="text-sm text-gray-600 mt-1">
                  {new Date(report.period_start).toLocaleDateString()} - {new Date(report.period_end).toLocaleDateString()}
                </p>
                {report.tags && report.tags.length > 0 && (
                  <div className="flex gap-1 mt-2">
                    {report.tags.map((tag, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => window.open(`/api/reports/saved/${report.id}?format=markdown`, '_blank')}
                  className="px-3 py-1 text-sm bg-gray-100 hover:bg-gray-200 rounded"
                >
                  View
                </button>
                <button
                  onClick={() => handleDelete(report.id)}
                  className="px-3 py-1 text-sm bg-red-100 hover:bg-red-200 rounded text-red-700"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {reports.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          No saved reports yet. Generate and save a report to see it here.
        </div>
      )}
    </div>
  );
};

