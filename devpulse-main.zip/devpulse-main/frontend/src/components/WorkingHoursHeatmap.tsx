import React, { useEffect, useState } from 'react'
import { timePatternsApi } from '../services/api'
import type { WorkingHoursAnalysis, AfterHoursAnalysis } from '../types'

export const WorkingHoursHeatmap: React.FC = () => {
  const [workingHours, setWorkingHours] = useState<WorkingHoursAnalysis | null>(null)
  const [afterHours, setAfterHours] = useState<AfterHoursAnalysis | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      const [hours, after] = await Promise.all([
        timePatternsApi.getWorkingHours(),
        timePatternsApi.getAfterHours(),
      ])
      setWorkingHours(hours)
      setAfterHours(after)
    } catch (error) {
      console.error('Error loading time patterns:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) return <div>Loading time patterns...</div>

  const getIntensity = (count: number, max: number) => {
    if (max === 0) return 0
    return Math.min(count / max, 1)
  }

  const maxCount = Math.max(...Object.values(workingHours?.hour_distribution || {}), 1)

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-4">Working Hours Heatmap</h3>
        <div className="grid grid-cols-12 gap-1">
          {Array.from({ length: 24 }, (_, hour) => {
            const count = workingHours?.hour_distribution[hour] || 0
            const intensity = getIntensity(count, maxCount)
            return (
              <div
                key={hour}
                className="p-2 text-center text-xs border rounded"
                style={{
                  backgroundColor: `rgba(59, 130, 246, ${intensity * 0.7 + 0.1})`,
                  color: intensity > 0.5 ? 'white' : 'black',
                }}
                title={`${hour}:00 - ${count} commits`}
              >
                <div className="font-semibold">{hour}</div>
                <div>{count}</div>
              </div>
            )
          })}
        </div>
      </div>

      {workingHours?.best_focus_time && (
        <div className="p-4 bg-blue-50 rounded">
          <p className="font-semibold">Best Focus Time</p>
          <p className="text-lg">
            {workingHours.best_focus_time.start}:00 - {workingHours.best_focus_time.end}:00
          </p>
        </div>
      )}

      {afterHours && (
        <div className="p-4 bg-yellow-50 rounded">
          <p className="font-semibold">After-Hours Work</p>
          <p>After-hours commits: {afterHours.after_hours_count}</p>
          <p>Weekend commits: {afterHours.weekend_count}</p>
          <p>
            {afterHours.percentage_after_hours.toFixed(1)}% of commits outside work hours
          </p>
        </div>
      )}
    </div>
  )
}

