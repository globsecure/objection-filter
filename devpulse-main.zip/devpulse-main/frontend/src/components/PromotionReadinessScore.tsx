import { useState, useEffect } from 'react'
import { paypalApi } from '../services/api'

interface ReadinessData {
  score: number
  checks: {
    mentees: boolean
    say_do_ratio: boolean
    cross_team_work: boolean
    org_level_impact: boolean
  }
  gaps: string[]
  recommendations: string[]
  details: any
}

export function PromotionReadinessScore() {
  const [data, setData] = useState<ReadinessData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    setLoading(true)
    try {
      const result = await paypalApi.getPromotionReadiness()
      setData(result)
    } catch (error) {
      console.error('Error loading Promotion Readiness:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow">
        <div className="text-center py-4">Loading Promotion Readiness Score...</div>
      </div>
    )
  }

  if (!data) {
    return null
  }

  const scoreColor = (score: number) => {
    if (score >= 75) return 'text-green-600'
    if (score >= 50) return 'text-yellow-600'
    return 'text-red-600'
  }

  const scoreBgColor = (score: number) => {
    if (score >= 75) return 'bg-green-100'
    if (score >= 50) return 'bg-yellow-100'
    return 'bg-red-100'
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h3 className="text-xl font-semibold mb-4">Promotion Readiness Score</h3>
      
      <div className="space-y-4">
        <div className={`${scoreBgColor(data.score)} p-6 rounded-lg text-center`}>
          <div className={`text-5xl font-bold ${scoreColor(data.score)} mb-2`}>
            {data.score}%
          </div>
          <div className="text-sm text-gray-600">Readiness for T24/T25 Promotion</div>
        </div>

        <div>
          <h4 className="font-semibold mb-2">Criteria Checks</h4>
          <div className="space-y-2">
            <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
              <span>Mentees (≥2)</span>
              <span className={data.checks.mentees ? 'text-green-600' : 'text-red-600'}>
                {data.checks.mentees ? '✅' : '❌'}
              </span>
            </div>
            <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
              <span>Say/Do Ratio (≥95%)</span>
              <span className={data.checks.say_do_ratio ? 'text-green-600' : 'text-red-600'}>
                {data.checks.say_do_ratio ? '✅' : '❌'}
              </span>
            </div>
            <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
              <span>Cross-Team Work</span>
              <span className={data.checks.cross_team_work ? 'text-green-600' : 'text-red-600'}>
                {data.checks.cross_team_work ? '✅' : '❌'}
              </span>
            </div>
            <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
              <span>Org-Level Impact</span>
              <span className={data.checks.org_level_impact ? 'text-green-600' : 'text-red-600'}>
                {data.checks.org_level_impact ? '✅' : '❌'}
              </span>
            </div>
          </div>
        </div>

        {data.gaps.length > 0 && (
          <div>
            <h4 className="font-semibold mb-2 text-red-600">Gaps Identified</h4>
            <ul className="space-y-1">
              {data.gaps.map((gap, idx) => (
                <li key={idx} className="text-sm text-red-700">
                  • {gap.replace('_', ' ')}
                </li>
              ))}
            </ul>
          </div>
        )}

        {data.recommendations.length > 0 && (
          <div>
            <h4 className="font-semibold mb-2">Recommendations</h4>
            <ul className="space-y-1">
              {data.recommendations.map((rec, idx) => (
                <li key={idx} className="text-sm text-gray-700">
                  • {rec}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  )
}

