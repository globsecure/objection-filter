import React, { useState } from 'react'
import { feedbackApi } from '../services/api'
import type { FeedbackCreate } from '../types'

interface FeedbackFormProps {
  onSuccess?: () => void
  onCancel?: () => void
}

export const FeedbackForm: React.FC<FeedbackFormProps> = ({ onSuccess, onCancel }) => {
  const [formData, setFormData] = useState<FeedbackCreate>({
    from_who: '',
    date: new Date().toISOString().split('T')[0],
    context: '',
    feedback_text: '',
    category: 'positive',
    tags: '',
  })
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const payload: FeedbackCreate = {
        ...formData,
        date: `${formData.date}T12:00:00`,
      }
      await feedbackApi.create(payload)
      setFormData({
        from_who: '',
        date: new Date().toISOString().split('T')[0],
        context: '',
        feedback_text: '',
        category: 'positive',
        tags: '',
      })
      onSuccess?.()
    } catch (error) {
      console.error('Error saving feedback:', error)
      alert('Failed to save feedback. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 bg-white rounded-lg shadow p-6">
      <h2 className="text-xl font-bold mb-4">Add Peer Feedback</h2>

      <div>
        <label className="block text-sm font-medium mb-2">From</label>
        <input
          type="text"
          value={formData.from_who}
          onChange={(e) => setFormData({ ...formData, from_who: e.target.value })}
          className="w-full px-3 py-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="Name of person giving feedback"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Date</label>
        <input
          type="date"
          value={formData.date}
          onChange={(e) => setFormData({ ...formData, date: e.target.value })}
          className="w-full px-3 py-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Context</label>
        <input
          type="text"
          value={formData.context || ''}
          onChange={(e) => setFormData({ ...formData, context: e.target.value })}
          className="w-full px-3 py-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="e.g., post-project, code-review, 1-on-1"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Category</label>
        <select
          value={formData.category}
          onChange={(e) => setFormData({ ...formData, category: e.target.value })}
          className="w-full px-3 py-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="positive">Positive</option>
          <option value="constructive">Constructive</option>
          <option value="neutral">Neutral</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Feedback</label>
        <textarea
          value={formData.feedback_text}
          onChange={(e) => setFormData({ ...formData, feedback_text: e.target.value })}
          className="w-full px-3 py-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          rows={6}
          placeholder="Enter the feedback..."
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Tags</label>
        <input
          type="text"
          value={formData.tags || ''}
          onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
          className="w-full px-3 py-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="Comma-separated tags"
        />
      </div>

      <div className="flex gap-2">
        <button
          type="submit"
          disabled={loading}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
        >
          {loading ? 'Saving...' : 'Save Feedback'}
        </button>
        {onCancel && (
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400"
          >
            Cancel
          </button>
        )}
      </div>
    </form>
  )
}

