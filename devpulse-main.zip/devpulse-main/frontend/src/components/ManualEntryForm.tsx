import React, { useState } from 'react'
import { manualEntriesApi } from '../services/api'
import type { ManualEntryCreate } from '../types'

type EntryType = 'code_review' | 'design_doc' | 'mentoring' | 'incident' | 'meeting'

interface ManualEntryFormState {
  type: EntryType
  date: string
  title: string
  description: string
  impact: string
  collaborators: string
  links: string
  duration_minutes: string
}

export function ManualEntryForm() {
  const [form, setForm] = useState<ManualEntryFormState>({
    type: 'code_review',
    date: new Date().toISOString().split('T')[0],
    title: '',
    description: '',
    impact: '',
    collaborators: '',
    links: '',
    duration_minutes: '',
  })
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setSuccess(false)

    try {
      const payload: ManualEntryCreate = {
        date: `${form.date}T12:00:00`,
        type: form.type,
        title: form.title,
        description: form.description || undefined,
        impact: form.impact || undefined,
        collaborators: form.collaborators || undefined,
        links: form.links || undefined,
        duration_minutes: form.duration_minutes
          ? parseInt(form.duration_minutes)
          : undefined,
      }

      await manualEntriesApi.create(payload)

      // Reset form
      setForm({
        type: 'code_review',
        date: new Date().toISOString().split('T')[0],
        title: '',
        description: '',
        impact: '',
        collaborators: '',
        links: '',
        duration_minutes: '',
      })
      setSuccess(true)
      setTimeout(() => setSuccess(false), 3000)
    } catch (error) {
      console.error('Failed to create manual entry:', error)
      alert('Failed to create entry. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const getTypeLabel = (type: EntryType) => {
    const labels: Record<EntryType, string> = {
      code_review: 'Code Review',
      design_doc: 'Design Doc',
      mentoring: 'Mentoring',
      incident: 'Incident',
      meeting: 'Meeting',
    }
    return labels[type]
  }

  const getTypeIcon = (type: EntryType) => {
    const icons: Record<EntryType, string> = {
      code_review: '👀',
      design_doc: '📄',
      mentoring: '👥',
      incident: '🔥',
      meeting: '📅',
    }
    return icons[type]
  }

  const showCollaborators = ['code_review', 'mentoring', 'meeting'].includes(form.type)
  const showLinks = ['code_review', 'design_doc', 'incident'].includes(form.type)
  const showDuration = ['mentoring', 'meeting'].includes(form.type)
  const showImpact = form.type !== 'meeting'

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-xl font-bold mb-4">Add Manual Entry</h2>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Type selector */}
        <div>
          <label className="block text-sm font-medium mb-2">Type</label>
          <div className="flex gap-2 flex-wrap">
            {(
              [
                'code_review',
                'design_doc',
                'mentoring',
                'incident',
                'meeting',
              ] as EntryType[]
            ).map((type) => (
              <button
                key={type}
                type="button"
                onClick={() => setForm({ ...form, type })}
                className={`px-4 py-2 rounded transition-colors ${
                  form.type === type
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                {getTypeIcon(type)} {getTypeLabel(type)}
              </button>
            ))}
          </div>
        </div>

        {/* Date */}
        <div>
          <label className="block text-sm font-medium mb-2">Date</label>
          <input
            type="date"
            value={form.date}
            onChange={(e) => setForm({ ...form, date: e.target.value })}
            className="w-full border rounded px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            required
          />
        </div>

        {/* Title */}
        <div>
          <label className="block text-sm font-medium mb-2">Title</label>
          <input
            type="text"
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            placeholder={
              form.type === 'code_review'
                ? 'e.g., Reviewed payment gateway PR'
                : form.type === 'design_doc'
                ? 'e.g., API v2 Architecture Design'
                : form.type === 'mentoring'
                ? 'e.g., Pair programming session with junior dev'
                : form.type === 'incident'
                ? 'e.g., Production database outage'
                : 'e.g., Sprint planning meeting'
            }
            className="w-full border rounded px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            required
          />
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-medium mb-2">
            Description (optional)
          </label>
          <textarea
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            placeholder="Add more details..."
            className="w-full border rounded px-3 py-2 min-h-[100px] focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            rows={3}
          />
        </div>

        {/* Impact */}
        {showImpact && (
          <div>
            <label className="block text-sm font-medium mb-2">
              Business Impact (optional)
            </label>
            <textarea
              value={form.impact}
              onChange={(e) => setForm({ ...form, impact: e.target.value })}
              placeholder="Describe the business impact..."
              className="w-full border rounded px-3 py-2 min-h-[80px] focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              rows={2}
            />
          </div>
        )}

        {/* Collaborators */}
        {showCollaborators && (
          <div>
            <label className="block text-sm font-medium mb-2">
              Collaborators (comma-separated)
            </label>
            <input
              type="text"
              value={form.collaborators}
              onChange={(e) => setForm({ ...form, collaborators: e.target.value })}
              placeholder="e.g., @john, @jane"
              className="w-full border rounded px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        )}

        {/* Links */}
        {showLinks && (
          <div>
            <label className="block text-sm font-medium mb-2">
              Links (URLs, comma-separated)
            </label>
            <input
              type="text"
              value={form.links}
              onChange={(e) => setForm({ ...form, links: e.target.value })}
              placeholder={
                form.type === 'code_review'
                  ? 'e.g., https://github.com/org/repo/pull/123'
                  : form.type === 'design_doc'
                  ? 'e.g., https://docs.company.com/designs/api-v2'
                  : 'e.g., https://jira.company.com/INC-123'
              }
              className="w-full border rounded px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        )}

        {/* Duration */}
        {showDuration && (
          <div>
            <label className="block text-sm font-medium mb-2">
              Duration (minutes)
            </label>
            <input
              type="number"
              value={form.duration_minutes}
              onChange={(e) => setForm({ ...form, duration_minutes: e.target.value })}
              placeholder="e.g., 60"
              min="1"
              className="w-full border rounded px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        )}

        {/* Success message */}
        {success && (
          <div className="p-3 bg-green-50 text-green-700 rounded-lg text-sm">
            Entry created successfully!
          </div>
        )}

        <button
          type="submit"
          disabled={loading || !form.title.trim()}
          className="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {loading ? 'Creating...' : 'Create Entry'}
        </button>
      </form>
    </div>
  )
}

