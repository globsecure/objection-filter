import { useState, useEffect } from 'react'
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { spaceApi } from '../services/api'
import type { SpaceMetrics } from '../types'

interface SpaceDashboardProps {
  startDate?: string
  endDate?: string
  repoId?: number
  repoIds?: number[]
  tags?: string[]
  team?: string
  aggregated?: boolean
}

function SpaceDashboard({ startDate, endDate, repoId, repoIds, tags, team, aggregated }: SpaceDashboardProps) {
  const [metrics, setMetrics] = useState<SpaceMetrics | null>(null)
  const [trends, setTrends] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    loadMetrics()
  }, [startDate, endDate, repoId, repoIds, tags, team, aggregated])

  const loadMetrics = async () => {
    try {
      setLoading(true)
      setError(null)
      
      if (aggregated && (repoIds?.length || tags?.length || team)) {
        // Use aggregate endpoint
        const aggregateData = await spaceApi.getAggregate({
          start_date: startDate,
          end_date: endDate,
          repo_ids: repoIds,
          tags: tags,
          team: team
        })
        // Transform aggregate data to match SpaceMetrics format
        if (aggregateData.aggregated) {
          setMetrics({
            satisfaction: { average_satisfaction: aggregateData.aggregated.satisfaction / 10, average_wellbeing: 0, trend: 'stable', low_weeks_count: 0, total_entries: 0, scores_over_time: [] },
            performance: { commits: 0, lines_changed: 0, net_change: 0, merge_commits: 0, code_reviews: 0, design_docs: 0, mentoring_sessions: 0, revert_rate: 0, quality_score: aggregateData.aggregated.performance },
            activity: { active_days: 0, active_days_pct: 0, avg_commits_per_day: 0, consistency_score: aggregateData.aggregated.activity / 100, longest_streak: 0, fragmentation_score: 0, total_commits: 0 },
            collaboration: { code_reviews: 0, design_docs: 0, mentoring_sessions: 0, meetings: 0, unique_collaborators: 0, collaboration_score: aggregateData.aggregated.collaboration, total_collaboration_activities: 0 },
            efficiency: { score: aggregateData.aggregated.efficiency, deep_work_hours: 0, fragmentation_score: 0, optimal_hours: [] }
          } as SpaceMetrics)
        }
      } else {
        // Use single repo endpoint
        const [summaryData, trendsData] = await Promise.all([
          spaceApi.getSummary({ start_date: startDate, end_date: endDate, repo_id: repoId }),
          spaceApi.getTrends({ start_date: startDate, end_date: endDate, repo_id: repoId, group_by: 'week' })
        ])
        setMetrics(summaryData)
        setTrends(trendsData)
      }
    } catch (err) {
      setError('Failed to load SPACE metrics')
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const getScoreColor = (score: number) => {
    if (score >= 70) return 'text-emerald-600'
    if (score >= 40) return 'text-amber-600'
    return 'text-rose-600'
  }

  const getScoreBg = (score: number) => {
    if (score >= 70) return 'bg-emerald-50 border-emerald-200'
    if (score >= 40) return 'bg-amber-50 border-amber-200'
    return 'bg-rose-50 border-rose-200'
  }

  const DimensionCard = ({ title, score, subtitle, details }: {
    title: string
    score: number
    subtitle?: string
    details?: React.ReactNode
  }) => (
    <div className={`bg-white rounded-lg shadow p-6 border-2 ${getScoreBg(score)}`}>
      <h3 className="text-sm font-medium text-slate-600 mb-2">{title}</h3>
      <div className="flex items-baseline justify-between mb-2">
        <span className={`text-3xl font-bold ${getScoreColor(score)}`}>{score.toFixed(1)}</span>
        <span className="text-sm text-slate-500">/ 100</span>
      </div>
      {subtitle && <p className="text-sm text-slate-500">{subtitle}</p>}
      {details && <div className="mt-4 text-sm text-slate-600">{details}</div>}
    </div>
  )

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {[1, 2, 3, 4, 5].map(i => (
            <div key={i} className="animate-pulse bg-slate-200 rounded-lg h-32"></div>
          ))}
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="text-red-500 text-center py-8">{error}</div>
    )
  }

  if (!metrics) {
    return (
      <div className="text-slate-500 text-center py-8">
        <p>No SPACE metrics available yet.</p>
      </div>
    )
  }

  const { satisfaction, performance, activity, collaboration, efficiency } = metrics

  // Prepare radar chart data
  const radarData = [
    {
      dimension: 'Satisfaction',
      score: satisfaction.average_satisfaction * 10, // Scale 1-10 to 0-100
    },
    {
      dimension: 'Performance',
      score: performance.quality_score,
    },
    {
      dimension: 'Activity',
      score: activity.consistency_score * 100,
    },
    {
      dimension: 'Collaboration',
      score: collaboration.collaboration_score,
    },
    {
      dimension: 'Efficiency',
      score: efficiency.score,
    },
  ]

  return (
    <div className="space-y-6">
      {/* SPACE Radar Chart */}
      <div className="bg-white rounded-lg shadow p-6 border border-slate-200">
        <h3 className="text-lg font-semibold text-slate-800 mb-4">SPACE Framework Overview</h3>
        <ResponsiveContainer width="100%" height={400}>
          <RadarChart data={radarData}>
            <PolarGrid />
            <PolarAngleAxis dataKey="dimension" />
            <PolarRadiusAxis angle={90} domain={[0, 100]} />
            <Radar name="SPACE Score" dataKey="score" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.6} />
            <Tooltip />
          </RadarChart>
        </ResponsiveContainer>
      </div>

      {/* Individual Dimension Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <DimensionCard
          title="Satisfaction"
          score={satisfaction.average_satisfaction * 10}
          subtitle={`${satisfaction.total_entries} entries`}
          details={
            <div className="space-y-1">
              <div className="flex justify-between">
                <span>Wellbeing:</span>
                <span className="font-medium">{satisfaction.average_wellbeing.toFixed(1)}</span>
              </div>
              <div className="flex justify-between">
                <span>Trend:</span>
                <span className="font-medium capitalize">{satisfaction.trend}</span>
              </div>
            </div>
          }
        />
        <DimensionCard
          title="Performance"
          score={performance.quality_score}
          subtitle={`${performance.commits} commits`}
          details={
            <div className="space-y-1">
              <div className="flex justify-between">
                <span>Code Reviews:</span>
                <span className="font-medium">{performance.code_reviews}</span>
              </div>
              <div className="flex justify-between">
                <span>Revert Rate:</span>
                <span className="font-medium">{performance.revert_rate.toFixed(1)}%</span>
              </div>
            </div>
          }
        />
        <DimensionCard
          title="Activity"
          score={activity.consistency_score * 100}
          subtitle={`${activity.active_days} active days`}
          details={
            <div className="space-y-1">
              <div className="flex justify-between">
                <span>Longest Streak:</span>
                <span className="font-medium">{activity.longest_streak} days</span>
              </div>
              <div className="flex justify-between">
                <span>Fragmentation:</span>
                <span className="font-medium">{(activity.fragmentation_score * 100).toFixed(0)}%</span>
              </div>
            </div>
          }
        />
        <DimensionCard
          title="Collaboration"
          score={collaboration.collaboration_score}
          subtitle={`${collaboration.unique_collaborators} collaborators`}
          details={
            <div className="space-y-1">
              <div className="flex justify-between">
                <span>Code Reviews:</span>
                <span className="font-medium">{collaboration.code_reviews}</span>
              </div>
              <div className="flex justify-between">
                <span>Mentoring:</span>
                <span className="font-medium">{collaboration.mentoring_sessions}</span>
              </div>
            </div>
          }
        />
        <DimensionCard
          title="Efficiency"
          score={efficiency.score}
          subtitle={`${efficiency.deep_work_hours.toFixed(1)} deep work hrs`}
          details={
            <div className="space-y-1">
              <div className="flex justify-between">
                <span>Fragmentation:</span>
                <span className="font-medium">{(efficiency.fragmentation_score * 100).toFixed(0)}%</span>
              </div>
              <div className="flex justify-between">
                <span>Optimal Hours:</span>
                <span className="font-medium">{efficiency.optimal_hours.join(', ')}</span>
              </div>
            </div>
          }
        />
      </div>

      {/* Satisfaction Trend */}
      {satisfaction.scores_over_time && satisfaction.scores_over_time.length > 0 && (
        <div className="bg-white rounded-lg shadow p-6 border border-slate-200">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Satisfaction Trend</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={satisfaction.scores_over_time}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis domain={[0, 10]} />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="satisfaction" stroke="#10b981" name="Satisfaction" />
              <Line type="monotone" dataKey="wellbeing" stroke="#3b82f6" name="Wellbeing" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* SPACE Trends */}
      {trends && trends.trends && trends.trends.length > 0 && (
        <div className="bg-white rounded-lg shadow p-6 border border-slate-200">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">SPACE Metrics Trends</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={trends.trends}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="period" />
              <YAxis domain={[0, 100]} />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="satisfaction" stroke="#10b981" name="Satisfaction" />
              <Line type="monotone" dataKey="performance_score" stroke="#3b82f6" name="Performance" />
              <Line type="monotone" dataKey="activity_score" stroke="#8b5cf6" name="Activity" />
              <Line type="monotone" dataKey="collaboration_score" stroke="#f59e0b" name="Collaboration" />
              <Line type="monotone" dataKey="efficiency_score" stroke="#ef4444" name="Efficiency" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Detailed Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6 border border-slate-200">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Performance Details</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-600">Commits:</span>
              <span className="font-medium">{performance.commits}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Lines Changed:</span>
              <span className="font-medium">{performance.lines_changed.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Code Reviews:</span>
              <span className="font-medium">{performance.code_reviews}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Design Docs:</span>
              <span className="font-medium">{performance.design_docs}</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6 border border-slate-200">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Activity Details</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-600">Active Days:</span>
              <span className="font-medium">{activity.active_days} ({activity.active_days_pct.toFixed(1)}%)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Avg Commits/Day:</span>
              <span className="font-medium">{activity.avg_commits_per_day.toFixed(1)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Longest Streak:</span>
              <span className="font-medium">{activity.longest_streak} days</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Fragmentation:</span>
              <span className="font-medium">{(activity.fragmentation_score * 100).toFixed(1)}%</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6 border border-slate-200">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Collaboration Details</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-600">Code Reviews:</span>
              <span className="font-medium">{collaboration.code_reviews}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Design Docs:</span>
              <span className="font-medium">{collaboration.design_docs}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Mentoring Sessions:</span>
              <span className="font-medium">{collaboration.mentoring_sessions}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Unique Collaborators:</span>
              <span className="font-medium">{collaboration.unique_collaborators}</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6 border border-slate-200">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Efficiency Details</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-600">Flow Score:</span>
              <span className="font-medium">{efficiency.score.toFixed(1)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Deep Work Hours:</span>
              <span className="font-medium">{efficiency.deep_work_hours.toFixed(1)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Fragmentation Score:</span>
              <span className="font-medium">{(efficiency.fragmentation_score * 100).toFixed(1)}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Optimal Hours:</span>
              <span className="font-medium">{efficiency.optimal_hours.join(', ')}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SpaceDashboard

