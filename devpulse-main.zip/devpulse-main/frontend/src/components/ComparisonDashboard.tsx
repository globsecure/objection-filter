import React, { useEffect, useState } from 'react'
import { benchmarksApi } from '../services/api'

interface ComparisonDashboardProps {
  startDate: string
  endDate: string
  teamName?: string
  repoId?: number
}

export const ComparisonDashboard: React.FC<ComparisonDashboardProps> = ({
  startDate,
  endDate,
  teamName,
  repoId,
}) => {
  const [comparisons, setComparisons] = useState<any>(null)
  const [industryBenchmarks, setIndustryBenchmarks] = useState<any>({})
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [startDate, endDate, teamName, repoId])

  const loadData = async () => {
    setLoading(true)
    try {
      const [compData, industryData] = await Promise.all([
        benchmarksApi.compareMetrics({
          start_date: startDate,
          end_date: endDate,
          team_name: teamName,
          repo_id: repoId,
        }),
        benchmarksApi.getIndustryBenchmarks(),
      ])
      setComparisons(compData)

      // Organize industry benchmarks by metric
      const organized: any = {}
      industryData.forEach((b: any) => {
        if (!organized[b.metric_name]) {
          organized[b.metric_name] = []
        }
        organized[b.metric_name].push(b)
      })
      setIndustryBenchmarks(organized)
    } catch (error) {
      console.error('Error loading comparison data:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) return <div>Loading comparisons...</div>
  if (!comparisons) return <div>No comparison data available</div>

  const getCategoryColor = (category?: string) => {
    switch (category) {
      case 'elite':
        return 'bg-green-100 text-green-800 border-green-500'
      case 'high':
        return 'bg-blue-100 text-blue-800 border-blue-500'
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-500'
      case 'low':
        return 'bg-red-100 text-red-800 border-red-500'
      default:
        return 'bg-gray-100 text-gray-800 border-gray-500'
    }
  }

  const getPercentileColor = (percentile?: number) => {
    if (!percentile) return 'bg-gray-200'
    if (percentile >= 75) return 'bg-green-500'
    if (percentile >= 50) return 'bg-blue-500'
    if (percentile >= 25) return 'bg-yellow-500'
    return 'bg-red-500'
  }

  const metricLabels: Record<string, string> = {
    deployment_frequency: 'Deployment Frequency',
    lead_time: 'Lead Time for Changes',
    change_failure_rate: 'Change Failure Rate',
    mttr: 'Mean Time to Recovery',
  }

  const metricUnits: Record<string, string> = {
    deployment_frequency: 'per week',
    lead_time: 'days',
    change_failure_rate: '%',
    mttr: 'hours',
  }

  return (
    <div className='space-y-6'>
      <h2 className='text-2xl font-bold'>Metrics Comparison</h2>

      {Object.entries(comparisons.comparisons || {}).map(
        ([metricName, comp]: [string, any]) => (
          <div key={metricName} className='p-6 border rounded-lg'>
            <h3 className='text-xl font-semibold mb-4'>
              {metricLabels[metricName] || metricName}
            </h3>

            <div className='grid grid-cols-1 md:grid-cols-3 gap-4 mb-4'>
              {/* Your Value */}
              <div className='p-4 bg-blue-50 rounded'>
                <p className='text-sm text-gray-600 mb-1'>Your Value</p>
                <p className='text-2xl font-bold'>
                  {comp.your_value.toFixed(2)} {metricUnits[metricName]}
                </p>
              </div>

              {/* Team Average */}
              {comp.team_average !== null &&
                comp.team_average !== undefined && (
                  <div className='p-4 bg-gray-50 rounded'>
                    <p className='text-sm text-gray-600 mb-1'>Team Average</p>
                    <p className='text-2xl font-bold'>
                      {comp.team_average.toFixed(2)} {metricUnits[metricName]}
                    </p>
                    {comp.team_percentile !== null &&
                      comp.team_percentile !== undefined && (
                        <p className='text-sm text-gray-500 mt-1'>
                          You're in the top {100 - comp.team_percentile}%
                        </p>
                      )}
                  </div>
                )}

              {/* Industry Category */}
              {comp.industry_category && (
                <div
                  className={`p-4 rounded border-l-4 ${getCategoryColor(
                    comp.industry_category
                  )}`}
                >
                  <p className='text-sm mb-1'>Industry Category</p>
                  <p className='text-xl font-bold capitalize'>
                    {comp.industry_category}
                  </p>
                  {comp.industry_percentile && (
                    <p className='text-sm mt-1'>
                      Estimated top {100 - comp.industry_percentile}% globally
                    </p>
                  )}
                </div>
              )}
            </div>

            {/* Percentile Bar */}
            {comp.team_percentile !== null &&
              comp.team_percentile !== undefined && (
                <div className='mt-4'>
                  <div className='flex justify-between text-sm mb-1'>
                    <span>Team Percentile Ranking</span>
                    <span>{comp.team_percentile.toFixed(1)}th percentile</span>
                  </div>
                  <div className='w-full bg-gray-200 rounded-full h-4 relative'>
                    <div
                      className={`h-4 rounded-full ${getPercentileColor(
                        comp.team_percentile
                      )}`}
                      style={{ width: `${comp.team_percentile}%` }}
                    />
                  </div>
                  <div className='flex justify-between text-xs text-gray-500 mt-1'>
                    <span>0%</span>
                    <span>50%</span>
                    <span>100%</span>
                  </div>
                </div>
              )}
          </div>
        )
      )}
    </div>
  )
}

