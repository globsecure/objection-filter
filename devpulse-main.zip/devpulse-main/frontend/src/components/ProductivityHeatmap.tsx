import { useMemo } from 'react'
import { format, startOfYear, eachDayOfInterval, parseISO, getMonth } from 'date-fns'
import type { Commit } from '../types'

interface ProductivityHeatmapProps {
  commits: Commit[]
}

function ProductivityHeatmap({ commits }: ProductivityHeatmapProps) {
  const { heatmapData, weeks, monthLabels } = useMemo(() => {
    const yearStart = startOfYear(new Date())
    const today = new Date()
    const days = eachDayOfInterval({ start: yearStart, end: today })

    const commitMap = commits.reduce((acc, commit) => {
      const commitDate = typeof commit.date === 'string' ? parseISO(commit.date) : new Date(commit.date)
      const date = format(commitDate, 'yyyy-MM-dd')
      acc[date] = (acc[date] || 0) + 1
      return acc
    }, {} as Record<string, number>)

    const data = days.map((day) => ({
      date: day,
      count: commitMap[format(day, 'yyyy-MM-dd')] || 0,
    }))

    // Group into weeks
    const weekGroups: typeof data[][] = []
    for (let i = 0; i < data.length; i += 7) {
      weekGroups.push(data.slice(i, i + 7))
    }

    // Generate month labels (show month name for first week of each month)
    const labels: (string | null)[] = []
    let lastMonth = -1
    weekGroups.forEach((week) => {
      const firstDay = week[0]?.date
      if (firstDay) {
        const month = getMonth(firstDay)
        if (month !== lastMonth) {
          labels.push(format(firstDay, 'MMM'))
          lastMonth = month
        } else {
          labels.push(null)
        }
      } else {
        labels.push(null)
      }
    })

    return {
      heatmapData: data,
      weeks: weekGroups,
      monthLabels: labels,
    }
  }, [commits])

  const getIntensity = (count: number): string => {
    if (count === 0) return 'bg-gray-100'
    if (count <= 2) return 'bg-green-200'
    if (count <= 5) return 'bg-green-400'
    if (count <= 10) return 'bg-green-600'
    return 'bg-green-800'
  }

  const getIntensityLabel = (count: number): string => {
    if (count === 0) return '0 commits'
    if (count <= 2) return '1-2 commits'
    if (count <= 5) return '3-5 commits'
    if (count <= 10) return '6-10 commits'
    return '11+ commits'
  }

  return (
    <div>
      <div className="mb-4 text-sm text-gray-600">
        <p className="mb-2">
          <strong>Como ler:</strong> Cada quadrado representa um dia do ano. Cores mais escuras indicam mais commits.
          Passe o mouse sobre um quadrado para ver a data e o número de commits.
        </p>
        <p className="text-xs text-gray-500">
          O heatmap mostra a atividade desde o início do ano até hoje. Cada coluna representa uma semana (domingo a sábado).
        </p>
      </div>

      <div className="overflow-x-auto pb-2">
        <div className="inline-flex gap-1">
          {/* Month labels row */}
          <div className="flex flex-col gap-1 pr-2">
            <div className="h-4"></div>
            {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map((day, idx) => (
              <div key={idx} className="h-3 text-xs text-gray-500 flex items-center">
                {idx % 2 === 0 ? day : ''}
              </div>
            ))}
          </div>

          {/* Weeks */}
          <div className="flex gap-1">
            {weeks.map((week, weekIdx) => (
              <div key={weekIdx} className="flex flex-col gap-1">
                {/* Month label */}
                <div className="h-4 text-xs text-gray-600 font-medium">
                  {monthLabels[weekIdx] || ''}
                </div>
                {/* Days */}
                {week.map((day, dayIdx) => (
                  <div
                    key={dayIdx}
                    className={`w-3 h-3 rounded ${getIntensity(day.count)} cursor-pointer hover:ring-2 hover:ring-green-400 hover:ring-offset-1 transition-all`}
                    title={`${format(day.date, 'dd/MM/yyyy')}: ${day.count} commit${day.count !== 1 ? 's' : ''} (${getIntensityLabel(day.count)})`}
                  />
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="mt-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-3">
          <span className="text-gray-600 font-medium">Intensidade:</span>
          <div className="flex items-center gap-2">
            <div className="flex gap-1">
              <div className="w-3 h-3 bg-gray-100 rounded" title="0 commits" />
              <div className="w-3 h-3 bg-green-200 rounded" title="1-2 commits" />
              <div className="w-3 h-3 bg-green-400 rounded" title="3-5 commits" />
              <div className="w-3 h-3 bg-green-600 rounded" title="6-10 commits" />
              <div className="w-3 h-3 bg-green-800 rounded" title="11+ commits" />
            </div>
            <span className="text-gray-500">Menos → Mais</span>
          </div>
        </div>
        <div className="text-gray-500">
          Período: {format(startOfYear(new Date()), 'dd/MM/yyyy')} até {format(new Date(), 'dd/MM/yyyy')}
        </div>
      </div>
    </div>
  )
}

export default ProductivityHeatmap

