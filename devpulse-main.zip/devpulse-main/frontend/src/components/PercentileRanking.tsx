import React, { useEffect, useState } from 'react'
import { benchmarksApi } from '../services/api'

interface PercentileRankingProps {
  startDate: string
  endDate: string
  teamName?: string
  repoId?: number
}

export const PercentileRanking: React.FC<PercentileRankingProps> = ({
  startDate,
  endDate,
  teamName,
  repoId,
}) => {
  const [comparisons, setComparisons] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [startDate, endDate, teamName, repoId])

  const loadData = async () => {
    setLoading(true)
    try {
      const data = await benchmarksApi.compareMetrics({
        start_date: startDate,
        end_date: endDate,
        team_name: teamName,
        repo_id: repoId,
      })
      setComparisons(data)
    } catch (error) {
      console.error('Error loading percentile data:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) return <div>Loading percentile rankings...</div>
  if (!comparisons) return <div>No data available</div>

  const getPercentileLabel = (percentile?: number) => {
    if (!percentile) return 'N/A'
    if (percentile >= 90) return 'Top 10%'
    if (percentile >= 75) return 'Top 25%'
    if (percentile >= 50) return 'Top 50%'
    if (percentile >= 25) return 'Bottom 50%'
    return 'Bottom 25%'
  }

  const getPercentileColor = (percentile?: number) => {
    if (!percentile) return 'bg-gray-200'
    if (percentile >= 75) return 'bg-green-500'
    if (percentile >= 50) return 'bg-blue-500'
    if (percentile >= 25) return 'bg-yellow-500'
    return 'bg-red-500'
  }

  const metricLabels: Record<string, string> = {
    deployment_frequency: 'Deployment Frequency',
    lead_time: 'Lead Time',
    change_failure_rate: 'Change Failure Rate',
    mttr: 'MTTR',
  }

  return (
    <div className='space-y-4'>
      <h2 className='text-2xl font-bold'>Percentile Rankings</h2>
      <p className='text-gray-600'>Your position relative to team averages</p>

      <div className='grid gap-4'>
        {Object.entries(comparisons.comparisons || {}).map(
          ([metricName, comp]: [string, any]) => {
            if (
              comp.team_percentile === null ||
              comp.team_percentile === undefined
            ) {
              return null
            }

            return (
              <div key={metricName} className='p-4 border rounded-lg'>
                <div className='flex justify-between items-center mb-2'>
                  <h3 className='font-semibold'>
                    {metricLabels[metricName] || metricName}
                  </h3>
                  <span
                    className={`px-3 py-1 rounded text-sm font-bold ${getPercentileColor(
                      comp.team_percentile
                    )} text-white`}
                  >
                    {getPercentileLabel(comp.team_percentile)}
                  </span>
                </div>

                <div className='relative'>
                  <div className='w-full bg-gray-200 rounded-full h-6'>
                    <div
                      className={`h-6 rounded-full ${getPercentileColor(
                        comp.team_percentile
                      )} transition-all`}
                      style={{ width: `${comp.team_percentile}%` }}
                    />
                  </div>
                  <div className='flex justify-between text-xs text-gray-500 mt-1'>
                    <span>0th percentile</span>
                    <span className='font-semibold'>
                      {comp.team_percentile.toFixed(1)}th percentile
                    </span>
                    <span>100th percentile</span>
                  </div>
                </div>

                <div className='mt-2 text-sm text-gray-600'>
                  <p>
                    Your value: <strong>{comp.your_value.toFixed(2)}</strong>
                    {comp.team_average !== null &&
                      comp.team_average !== undefined && (
                        <>
                          {' '}
                          • Team average: <strong>
                            {comp.team_average.toFixed(2)}
                          </strong>
                        </>
                      )}
                  </p>
                </div>
              </div>
            )
          }
        )}
      </div>
    </div>
  )
}

