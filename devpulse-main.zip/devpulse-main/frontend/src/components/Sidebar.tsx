import { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'

interface MenuItem {
  label: string
  path: string
  icon?: string
}

interface MenuCategory {
  label: string
  icon?: string
  items: MenuItem[]
  defaultOpen?: boolean
}

const menuCategories: MenuCategory[] = [
  {
    label: 'Overview',
    icon: '📊',
    items: [
      { label: 'Dashboard', path: '/' }
    ],
    defaultOpen: true
  },
  {
    label: 'Tracking',
    icon: '📝',
    items: [
      { label: 'Logbook', path: '/logbook' },
      { label: 'Tasks', path: '/tasks' },
      { label: 'Manual Entries', path: '/manual-entries' }
    ],
    defaultOpen: true
  },
  {
    label: 'Insights',
    icon: '🔍',
    items: [
      { label: 'Timeline', path: '/timeline' },
      { label: 'Review', path: '/review' },
      { label: 'Saved Reports', path: '/saved-reports' },
      { label: 'Friction', path: '/friction' },
      { label: 'Comparison', path: '/comparison' }
    ],
    defaultOpen: true
  },
  {
    label: 'Career',
    icon: '🎯',
    items: [
      { label: 'Career Moments', path: '/career-moments' },
      { label: 'Goals', path: '/goals' },
      { label: 'Feedback', path: '/feedback' }
    ],
    defaultOpen: true
  },
  {
    label: 'Settings',
    icon: '⚙️',
    items: [
      { label: 'Settings', path: '/settings' }
    ],
    defaultOpen: true
  }
]

interface SidebarProps {
  isOpen: boolean
  onClose: () => void
}

export function Sidebar({ isOpen, onClose }: SidebarProps) {
  const location = useLocation()
  const [openCategories, setOpenCategories] = useState<Set<string>>(
    new Set(menuCategories.map(cat => cat.label))
  )

  const toggleCategory = (categoryLabel: string) => {
    setOpenCategories(prev => {
      const next = new Set(prev)
      if (next.has(categoryLabel)) {
        next.delete(categoryLabel)
      } else {
        next.add(categoryLabel)
      }
      return next
    })
  }

  const isActive = (path: string) => {
    if (path === '/') {
      return location.pathname === '/'
    }
    return location.pathname.startsWith(path)
  }

  return (
    <>
      {/* Overlay for mobile */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <div
        className={`fixed left-0 top-0 h-screen bg-white border-r border-gray-200 overflow-y-auto z-50 transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } lg:translate-x-0 w-64`}
      >
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-gray-900">DevPulse</h1>
              <span className="ml-2 px-2 py-0.5 text-xs font-medium bg-indigo-100 text-indigo-700 rounded-full">v2</span>
            </div>
            <button
              onClick={onClose}
              className="lg:hidden text-gray-500 hover:text-gray-700"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        <nav className="p-4 space-y-2">
          {menuCategories.map((category) => {
            const isOpen = openCategories.has(category.label)
            const hasSubItems = category.items.length > 1

            return (
              <div key={category.label}>
                {hasSubItems ? (
                  <>
                    <button
                      onClick={() => toggleCategory(category.label)}
                      className="w-full flex items-center justify-between px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-md transition-colors"
                    >
                      <div className="flex items-center space-x-2">
                        {category.icon && <span>{category.icon}</span>}
                        <span>{category.label}</span>
                      </div>
                      <svg
                        className={`w-4 h-4 transition-transform ${isOpen ? 'transform rotate-90' : ''}`}
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </button>
                    {isOpen && (
                      <div className="ml-6 mt-1 space-y-1">
                        {category.items.map((item) => (
                          <Link
                            key={item.path}
                            to={item.path}
                            onClick={onClose}
                            className={`block px-3 py-2 text-sm rounded-md transition-colors ${
                              isActive(item.path)
                                ? 'bg-indigo-50 text-indigo-700 font-medium'
                                : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                            }`}
                          >
                            {item.label}
                          </Link>
                        ))}
                      </div>
                    )}
                  </>
                ) : (
                  <Link
                    to={category.items[0].path}
                    onClick={onClose}
                    className={`flex items-center space-x-2 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                      isActive(category.items[0].path)
                        ? 'bg-indigo-50 text-indigo-700'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    {category.icon && <span>{category.icon}</span>}
                    <span>{category.items[0].label}</span>
                  </Link>
                )}
              </div>
            )
          })}
        </nav>
      </div>
    </>
  )
}

