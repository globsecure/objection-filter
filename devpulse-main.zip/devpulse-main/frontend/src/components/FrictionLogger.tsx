import React, { useState } from 'react'
import { frictionApi } from '../services/api'
import type { FrictionLogCreate } from '../types'

interface FrictionForm {
  type: 'blocker' | 'learning' | 'win' | 'incident'
  description: string
  impact_level: number
  tags: string
  resolution?: string
}

export function FrictionLogger() {
  const [form, setForm] = useState<FrictionForm>({
    type: 'blocker',
    description: '',
    impact_level: 3,
    tags: '',
  })
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setSuccess(false)

    try {
      const payload: FrictionLogCreate = {
        date: new Date().toISOString(),
        type: form.type,
        description: form.description,
        impact_level: form.impact_level,
        tags: form.tags || undefined,
        resolution: form.resolution || undefined,
      }

      await frictionApi.createFrictionLog(payload)

      // Reset form
      setForm({
        type: 'blocker',
        description: '',
        impact_level: 3,
        tags: '',
      })
      setSuccess(true)
      setTimeout(() => setSuccess(false), 3000)
    } catch (error) {
      console.error('Failed to log friction:', error)
      alert('Failed to log friction. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'blocker':
        return '🚫'
      case 'learning':
        return '💡'
      case 'win':
        return '🎉'
      case 'incident':
        return '🔥'
      default:
        return '📝'
    }
  }

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-xl font-bold mb-4">Log Friction Point</h2>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Type selector */}
        <div>
          <label className="block text-sm font-medium mb-2">Type</label>
          <div className="flex gap-2 flex-wrap">
            {(['blocker', 'learning', 'win', 'incident'] as const).map((type) => (
              <button
                key={type}
                type="button"
                onClick={() => setForm({ ...form, type })}
                className={`px-4 py-2 rounded transition-colors ${
                  form.type === type
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                {getTypeIcon(type)} {type.charAt(0).toUpperCase() + type.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-medium mb-2">What happened?</label>
          <textarea
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            placeholder="e.g., Build pipeline was down for 2 hours blocking deployment"
            className="w-full border rounded px-3 py-2 min-h-[100px] focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            required
          />
        </div>

        {/* Impact level */}
        <div>
          <label className="block text-sm font-medium mb-2">
            Impact Level: {form.impact_level}/5
          </label>
          <input
            type="range"
            min="1"
            max="5"
            value={form.impact_level}
            onChange={(e) =>
              setForm({ ...form, impact_level: parseInt(e.target.value) })
            }
            className="w-full"
          />
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>Minor</span>
            <span>Major</span>
          </div>
        </div>

        {/* Tags */}
        <div>
          <label className="block text-sm font-medium mb-2">
            Tags (comma-separated)
          </label>
          <input
            type="text"
            value={form.tags}
            onChange={(e) => setForm({ ...form, tags: e.target.value })}
            placeholder="ci-cd, devops, infrastructure"
            className="w-full border rounded px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        {/* Resolution (optional) */}
        {(form.type === 'blocker' || form.type === 'incident') && (
          <div>
            <label className="block text-sm font-medium mb-2">
              Resolution (optional)
            </label>
            <input
              type="text"
              value={form.resolution || ''}
              onChange={(e) => setForm({ ...form, resolution: e.target.value })}
              placeholder="How was it resolved?"
              className="w-full border rounded px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        )}

        {/* Success message */}
        {success && (
          <div className="p-3 bg-green-50 text-green-700 rounded-lg text-sm">
            Friction logged successfully!
          </div>
        )}

        <button
          type="submit"
          disabled={loading || !form.description.trim()}
          className="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {loading ? 'Logging...' : 'Log Friction'}
        </button>
      </form>
    </div>
  )
}

