import React, { useState } from 'react'
import { goalsApi } from '../services/api'
import type { GoalCreate, Goal } from '../types'

interface GoalFormProps {
  initialData?: Goal
  onSuccess?: () => void
  onCancel?: () => void
}

export const GoalForm: React.FC<GoalFormProps> = ({
  initialData,
  onSuccess,
  onCancel,
}) => {
  const [formData, setFormData] = useState<GoalCreate>(
    initialData
      ? {
          ...initialData,
          deadline: initialData.deadline.split('T')[0],
        }
      : {
          title: '',
          description: '',
          deadline: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          status: 'active',
          progress: 0,
          target_metric: '',
          current_metric: '',
        }
  )
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const payload: GoalCreate = {
        ...formData,
        deadline: `${formData.deadline}T12:00:00`,
      }
      if (initialData) {
        await goalsApi.update(initialData.id, payload)
      } else {
        await goalsApi.create(payload)
      }
      onSuccess?.()
    } catch (error) {
      console.error('Error saving goal:', error)
      alert('Failed to save goal. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 bg-white rounded-lg shadow p-6">
      <h2 className="text-xl font-bold mb-4">
        {initialData ? 'Edit Goal' : 'Create Goal'}
      </h2>

      <div>
        <label className="block text-sm font-medium mb-2">Title</label>
        <input
          type="text"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          className="w-full px-3 py-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="e.g., Reduce checkout API latency 30%"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Description</label>
        <textarea
          value={formData.description || ''}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          className="w-full px-3 py-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          rows={3}
          placeholder="Add more details about this goal..."
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Deadline</label>
        <input
          type="date"
          value={formData.deadline}
          onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
          className="w-full px-3 py-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Status</label>
        <select
          value={formData.status}
          onChange={(e) => setFormData({ ...formData, status: e.target.value })}
          className="w-full px-3 py-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="active">Active</option>
          <option value="completed">Completed</option>
          <option value="cancelled">Cancelled</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Progress (0-100%)</label>
        <input
          type="number"
          min="0"
          max="100"
          value={formData.progress ? formData.progress * 100 : 0}
          onChange={(e) => setFormData({ ...formData, progress: parseFloat(e.target.value) / 100 })}
          className="w-full px-3 py-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Target Metric</label>
        <input
          type="text"
          value={formData.target_metric || ''}
          onChange={(e) => setFormData({ ...formData, target_metric: e.target.value })}
          className="w-full px-3 py-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="e.g., Reduce API latency 30%"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Current Metric</label>
        <input
          type="text"
          value={formData.current_metric || ''}
          onChange={(e) => setFormData({ ...formData, current_metric: e.target.value })}
          className="w-full px-3 py-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="e.g., 15% reduction achieved"
        />
      </div>

      <div className="flex gap-2">
        <button
          type="submit"
          disabled={loading}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
        >
          {loading ? 'Saving...' : initialData ? 'Update' : 'Create'}
        </button>
        {onCancel && (
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400"
          >
            Cancel
          </button>
        )}
      </div>
    </form>
  )
}

