import { useState, useEffect } from 'react'
import { settingsApi } from '../services/api'

interface SecuritySettings {
  enableSecretDetection: boolean
  autoRedactSecrets: boolean
  blockOnSecret: boolean
  redactEmails: boolean
  redactInternalUrls: boolean
}

export function SecuritySettings() {
  const [settings, setSettings] = useState<SecuritySettings>({
    enableSecretDetection: true,
    autoRedactSecrets: false,
    blockOnSecret: true,
    redactEmails: false,
    redactInternalUrls: false,
  })
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    loadSettings()
  }, [])

  const loadSettings = async () => {
    setLoading(true)
    try {
      const data = await settingsApi.getSecuritySettings()
      setSettings({
        enableSecretDetection: data.enable_secret_detection,
        autoRedactSecrets: data.auto_redact_secrets,
        blockOnSecret: data.block_on_secret,
        redactEmails: data.redact_emails,
        redactInternalUrls: data.redact_internal_urls,
      })
    } catch (error) {
      console.error('Failed to load settings:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleChange = (key: keyof SecuritySettings, value: boolean) => {
    setSettings(prev => ({ ...prev, [key]: value }))
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      await settingsApi.updateSecuritySettings({
        enable_secret_detection: settings.enableSecretDetection,
        auto_redact_secrets: settings.autoRedactSecrets,
        block_on_secret: settings.blockOnSecret,
        redact_emails: settings.redactEmails,
        redact_internal_urls: settings.redactInternalUrls,
      })
      alert('Settings saved successfully')
    } catch (error) {
      console.error('Failed to save settings:', error)
      alert('Failed to save settings')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h3 className="text-xl font-semibold mb-4">Security Settings</h3>
      
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Enable Secret Detection
            </label>
            <p className="text-sm text-gray-500">
              Automatically detect secrets before sending to LLM
            </p>
          </div>
          <input
            type="checkbox"
            checked={settings.enableSecretDetection}
            onChange={(e) => handleChange('enableSecretDetection', e.target.checked)}
            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
          />
        </div>

        <div className="flex items-center justify-between">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Block on Secret Detection
            </label>
            <p className="text-sm text-gray-500">
              Block commits with secrets instead of redacting
            </p>
          </div>
          <input
            type="checkbox"
            checked={settings.blockOnSecret}
            onChange={(e) => handleChange('blockOnSecret', e.target.checked)}
            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
          />
        </div>

        <div className="flex items-center justify-between">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Auto-Redact Secrets
            </label>
            <p className="text-sm text-gray-500">
              Automatically redact secrets instead of blocking
            </p>
          </div>
          <input
            type="checkbox"
            checked={settings.autoRedactSecrets}
            onChange={(e) => handleChange('autoRedactSecrets', e.target.checked)}
            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
          />
        </div>

        <div className="flex items-center justify-between">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Redact Email Addresses
            </label>
            <p className="text-sm text-gray-500">
              Redact email addresses from commit messages
            </p>
          </div>
          <input
            type="checkbox"
            checked={settings.redactEmails}
            onChange={(e) => handleChange('redactEmails', e.target.checked)}
            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
          />
        </div>

        <div className="flex items-center justify-between">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Redact Internal URLs
            </label>
            <p className="text-sm text-gray-500">
              Redact internal URLs from commit messages
            </p>
          </div>
          <input
            type="checkbox"
            checked={settings.redactInternalUrls}
            onChange={(e) => handleChange('redactInternalUrls', e.target.checked)}
            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
          />
        </div>

        <div className="pt-4">
          <button
            onClick={handleSave}
            disabled={loading || saving}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
          >
            {saving ? 'Saving...' : 'Save Settings'}
          </button>
        </div>
      </div>
    </div>
  )
}

