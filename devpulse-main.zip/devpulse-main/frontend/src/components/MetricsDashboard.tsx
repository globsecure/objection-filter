import { useState, useEffect } from 'react'
import { ComposedChart, Line, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { metricsApi } from '../services/api'
import type { ChurnDataPoint, ConsistencyMetrics } from '../types'
import { format, parseISO } from 'date-fns'

function MetricsDashboard() {
  const [churnData, setChurnData] = useState<ChurnDataPoint[]>([])
  const [consistencyData, setConsistencyData] = useState<ConsistencyMetrics | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadMetrics()
  }, [])

  const loadMetrics = async (): Promise<void> => {
    try {
      setLoading(true)
      const [churnRes, consistencyRes] = await Promise.all([
        metricsApi.getChurn(),
        metricsApi.getConsistency(),
      ])

      setChurnData(churnRes)
      setConsistencyData(consistencyRes)
    } catch (error) {
      console.error('Error loading metrics:', error)
    } finally {
      setLoading(false)
    }
  }

  const formatDate = (dateString: string): string => {
    try {
      const date = parseISO(dateString)
      return format(date, 'MMM dd')
    } catch {
      return dateString
    }
  }

  if (loading) {
    return <div className="text-center py-8">Loading metrics...</div>
  }

  return (
    <div className="space-y-6">
      <div>
        <h4 className="text-sm font-medium mb-4">Code Churn Over Time</h4>
        <ResponsiveContainer width="100%" height={250}>
          <ComposedChart data={churnData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis
              dataKey="date"
              tickFormatter={formatDate}
              stroke="#6b7280"
              style={{ fontSize: '12px' }}
            />
            <YAxis stroke="#6b7280" style={{ fontSize: '12px' }} />
            <Tooltip
              labelFormatter={(value) => formatDate(value)}
              contentStyle={{
                backgroundColor: '#fff',
                border: '1px solid #e5e7eb',
                borderRadius: '6px',
              }}
            />
            <Legend />
            <Bar dataKey="insertions" fill="#10b981" name="Insertions" />
            <Bar dataKey="deletions" fill="#ef4444" name="Deletions" />
            <Line
              type="monotone"
              dataKey="commit_count"
              stroke="#3b82f6"
              strokeWidth={2}
              name="Commits"
              dot={false}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {consistencyData && (
        <div>
          <h4 className="text-sm font-medium mb-4">Delivery Consistency</h4>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-lg border border-blue-200">
              <div className="text-sm text-blue-700 font-medium mb-1">Commits per Week</div>
              <div className="text-3xl font-bold text-blue-900">{consistencyData.commits_per_week}</div>
            </div>
            <div className="bg-gradient-to-br from-green-50 to-green-100 p-4 rounded-lg border border-green-200">
              <div className="text-sm text-green-700 font-medium mb-1">Commits per Month</div>
              <div className="text-3xl font-bold text-green-900">{consistencyData.commits_per_month}</div>
            </div>
          </div>
          {consistencyData.weeks_active > 0 && (
            <div className="mt-4 text-sm text-gray-600">
              Active for {Math.round(consistencyData.weeks_active)} weeks
            </div>
          )}
        </div>
      )}
    </div>
  )
}

export default MetricsDashboard


