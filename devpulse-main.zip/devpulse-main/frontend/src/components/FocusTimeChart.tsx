import { useState, useEffect } from 'react'
import { spaceApi } from '../services/api'
import type { SpaceMetrics } from '../types'

function FocusTimeChart() {
  const [metrics, setMetrics] = useState<SpaceMetrics | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    loadMetrics()
  }, [])

  const loadMetrics = async () => {
    try {
      setLoading(true)
      const data = await spaceApi.getFocusTime()
      setMetrics(data)
      setError(null)
    } catch (err) {
      setError('Failed to load focus time metrics')
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="animate-pulse">
        <div className="h-48 bg-slate-200 rounded"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="text-red-500 text-center py-4">{error}</div>
    )
  }

  if (!metrics) {
    return (
      <div className="text-slate-500 text-center py-8">
        <p>No focus time data available yet.</p>
      </div>
    )
  }

  const { flow_score, hourly_distribution } = metrics
  const maxCommits = Math.max(...hourly_distribution.map(h => h.count), 1)

  const getScoreColor = (score: number) => {
    if (score >= 70) return 'text-emerald-600'
    if (score >= 40) return 'text-amber-600'
    return 'text-rose-600'
  }

  const getScoreBg = (score: number) => {
    if (score >= 70) return 'from-emerald-50 to-emerald-100'
    if (score >= 40) return 'from-amber-50 to-amber-100'
    return 'from-rose-50 to-rose-100'
  }

  return (
    <div>
      <h3 className="text-lg font-semibold text-slate-800 mb-4">Focus Time (SPACE)</h3>

      {/* Flow Score */}
      <div className={`bg-gradient-to-br ${getScoreBg(flow_score.score)} rounded-xl p-4 mb-6`}>
        <div className="flex items-center justify-between">
          <div>
            <div className={`text-4xl font-bold ${getScoreColor(flow_score.score)}`}>
              {flow_score.score.toFixed(0)}
            </div>
            <div className="text-sm text-slate-600">Flow Score</div>
          </div>
          <div className="text-right space-y-1">
            <div className="text-sm">
              <span className="text-slate-500">Deep Work:</span>{' '}
              <span className="font-medium text-slate-700">{flow_score.deep_work_hours.toFixed(1)}h</span>
            </div>
            <div className="text-sm">
              <span className="text-slate-500">Fragmentation:</span>{' '}
              <span className="font-medium text-slate-700">{(flow_score.fragmentation_score * 100).toFixed(0)}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Optimal Hours */}
      {flow_score.optimal_hours.length > 0 && (
        <div className="mb-4">
          <div className="text-sm text-slate-600 mb-2">Optimal Work Hours</div>
          <div className="flex gap-2 flex-wrap">
            {flow_score.optimal_hours.map(hour => (
              <span
                key={hour}
                className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full text-sm font-medium"
              >
                {hour}:00 - {hour + 1}:00
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Hourly Distribution */}
      <div>
        <div className="text-sm text-slate-600 mb-2">Hourly Activity</div>
        <div className="flex items-end gap-px h-20">
          {hourly_distribution.map((hour, idx) => (
            <div
              key={idx}
              className={`flex-1 rounded-t transition-colors ${
                flow_score.optimal_hours.includes(hour.hour)
                  ? 'bg-indigo-500 hover:bg-indigo-600'
                  : 'bg-slate-300 hover:bg-slate-400'
              }`}
              style={{ height: `${(hour.count / maxCommits) * 100}%`, minHeight: hour.count > 0 ? '4px' : '0' }}
              title={`${hour.hour}:00 - ${hour.count} commits`}
            />
          ))}
        </div>
        <div className="flex justify-between text-xs text-slate-400 mt-1">
          <span>0:00</span>
          <span>6:00</span>
          <span>12:00</span>
          <span>18:00</span>
          <span>24:00</span>
        </div>
      </div>
    </div>
  )
}

export default FocusTimeChart

