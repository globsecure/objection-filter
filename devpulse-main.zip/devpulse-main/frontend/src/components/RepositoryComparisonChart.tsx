import { useState, useEffect } from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { metricsApi } from '../services/api'
import type { RepositoryStat } from '../types'

function RepositoryComparisonChart() {
  const [data, setData] = useState<RepositoryStat[]>([])
  const [loading, setLoading] = useState(true)
  const [metric, setMetric] = useState<'commit_count' | 'total_changes'>('commit_count')

  useEffect(() => {
    loadRepositoryStats()
  }, [])

  const loadRepositoryStats = async (): Promise<void> => {
    try {
      setLoading(true)
      const response = await metricsApi.getRepositoryStats()
      setData(response)
    } catch (error) {
      console.error('Error loading repository stats:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <div className="text-center py-8">Loading repository stats...</div>
  }

  const chartData = data.map((repo) => ({
    name: repo.repository_name.length > 15 
      ? repo.repository_name.substring(0, 15) + '...' 
      : repo.repository_name,
    fullName: repo.repository_name,
    commits: repo.commit_count,
    changes: repo.total_changes,
  }))

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h4 className="text-sm font-medium">Repository Comparison</h4>
        <select
          value={metric}
          onChange={(e) => setMetric(e.target.value as 'commit_count' | 'total_changes')}
          className="text-sm border rounded px-2 py-1"
        >
          <option value="commit_count">Commits</option>
          <option value="total_changes">Code Changes</option>
        </select>
      </div>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          <XAxis
            dataKey="name"
            stroke="#6b7280"
            style={{ fontSize: '12px' }}
            angle={-45}
            textAnchor="end"
            height={80}
          />
          <YAxis stroke="#6b7280" style={{ fontSize: '12px' }} />
          <Tooltip
            contentStyle={{
              backgroundColor: '#fff',
              border: '1px solid #e5e7eb',
              borderRadius: '6px',
            }}
            formatter={(value: number) => value.toLocaleString()}
            labelFormatter={(label) => {
              const repo = chartData.find((d) => d.name === label)
              return repo?.fullName || label
            }}
          />
          <Legend />
          <Bar
            dataKey={metric === 'commit_count' ? 'commits' : 'changes'}
            fill="#3b82f6"
            name={metric === 'commit_count' ? 'Commits' : 'Code Changes'}
            radius={[4, 4, 0, 0]}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}

export default RepositoryComparisonChart

