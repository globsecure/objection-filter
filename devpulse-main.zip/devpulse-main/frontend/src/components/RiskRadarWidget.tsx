import { useState, useEffect } from 'react'
import { paypalApi } from '../services/api'

interface RiskGoal {
  goal_id: number
  title: string
  deadline: string
  days_until_deadline: number
  progress: number
  risk_reasons: string[]
  recommendation: string
}

export function RiskRadarWidget() {
  const [risks, setRisks] = useState<RiskGoal[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    setLoading(true)
    try {
      const result = await paypalApi.getRiskRadar()
      setRisks(result)
    } catch (error) {
      console.error('Error loading Risk Radar:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow">
        <div className="text-center py-4">Loading Risk Radar...</div>
      </div>
    )
  }

  if (risks.length === 0) {
    return (
      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-xl font-semibold mb-4">Risk Radar</h3>
        <div className="text-center py-4 text-green-600">
          ✅ No goals at risk
        </div>
      </div>
    )
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h3 className="text-xl font-semibold mb-4">Risk Radar</h3>
      
      <div className="space-y-4">
        {risks.map((risk) => (
          <div key={risk.goal_id} className="border-l-4 border-yellow-500 pl-4 py-2">
            <div className="font-medium text-gray-900">{risk.title}</div>
            <div className="text-sm text-gray-600 mt-1">
              Due in {risk.days_until_deadline} days • Progress: {Math.round(risk.progress * 100)}%
            </div>
            <div className="mt-2">
              {risk.risk_reasons.map((reason, idx) => (
                <div key={idx} className="text-sm text-yellow-700">
                  ⚠️ {reason}
                </div>
              ))}
            </div>
            <div className="text-sm text-gray-600 mt-2 italic">
              {risk.recommendation}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

