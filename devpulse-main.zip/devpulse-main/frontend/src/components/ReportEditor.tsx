import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { reportsApi } from '../services/api';

interface ReportSection {
  name: string;
  content: string;
  isEditable: boolean;
}

export const ReportEditor: React.FC = () => {
  const { reportId } = useParams<{ reportId: string }>();
  const [sections, setSections] = useState<ReportSection[]>([]);
  const [editingSection, setEditingSection] = useState<string | null>(null);
  const [editedContent, setEditedContent] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (reportId) {
      loadReport();
    }
  }, [reportId]);

  const loadReport = async () => {
    try {
      setLoading(true);
      const report = await reportsApi.getSavedReport(parseInt(reportId!), 'json');
      const reportData = report.report || report;
      
      // Convert report data to sections
      const reportSections: ReportSection[] = [
        { name: 'executive_summary', content: reportData.executive_summary || '', isEditable: true },
        { name: 'key_achievements', content: Array.isArray(reportData.key_achievements) ? reportData.key_achievements.join('\n') : reportData.key_achievements || '', isEditable: true },
        { name: 'challenges_and_growth', content: reportData.challenges_and_growth || '', isEditable: true },
        { name: 'collaboration_highlights', content: reportData.collaboration_highlights || '', isEditable: true },
      ];
      
      setSections(reportSections);
      setError(null);
    } catch (err: any) {
      setError(err.message || 'Failed to load report');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (sectionName: string, currentContent: string) => {
    setEditingSection(sectionName);
    setEditedContent(currentContent);
  };

  const handleSave = async (sectionName: string) => {
    if (!reportId) return;
    
    try {
      setSaving(true);
      await reportsApi.editReportSection(parseInt(reportId), sectionName, editedContent);
      
      // Update local state
      setSections(sections.map(s => 
        s.name === sectionName 
          ? { ...s, content: editedContent }
          : s
      ));
      setEditingSection(null);
      setError(null);
    } catch (err: any) {
      setError(err.message || 'Failed to save edit');
    } finally {
      setSaving(false);
    }
  };

  const handleCancel = () => {
    setEditingSection(null);
    setEditedContent('');
  };

  const formatSectionName = (name: string): string => {
    return name.split('_').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  if (loading) {
    return <div className="p-4">Loading report...</div>;
  }

  if (error && !sections.length) {
    return <div className="p-4 text-red-600">Error: {error}</div>;
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">Edit Report</h2>
      
      {error && (
        <div className="mb-4 p-3 bg-red-100 text-red-700 rounded">
          {error}
        </div>
      )}
      
      {sections.map(section => (
        <div key={section.name} className="mb-8 border-b pb-6">
          <h3 className="text-xl font-semibold mb-3">
            {formatSectionName(section.name)}
          </h3>
          
          {editingSection === section.name ? (
            <div>
              <textarea
                value={editedContent}
                onChange={(e) => setEditedContent(e.target.value)}
                rows={10}
                className="w-full p-3 border rounded-md font-mono text-sm"
                disabled={saving}
              />
              <div className="mt-3 flex gap-2">
                <button
                  onClick={() => handleSave(section.name)}
                  disabled={saving}
                  className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:opacity-50"
                >
                  {saving ? 'Saving...' : 'Save'}
                </button>
                <button
                  onClick={handleCancel}
                  disabled={saving}
                  className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600 disabled:opacity-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div>
              <div className="prose max-w-none whitespace-pre-wrap bg-gray-50 p-4 rounded">
                {section.content || 'No content available'}
              </div>
              {section.isEditable && (
                <button
                  onClick={() => handleEdit(section.name, section.content)}
                  className="mt-3 px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300"
                >
                  Edit
                </button>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

