import React, { useEffect, useState } from 'react'
import { frictionApi } from '../services/api'
import type { FrictionLog, FrictionLogStats } from '../types'

export function FrictionDashboard() {
  const [logs, setLogs] = useState<FrictionLog[]>([])
  const [stats, setStats] = useState<FrictionLogStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [filterType, setFilterType] = useState<string>('')

  useEffect(() => {
    loadData()
  }, [filterType])

  const loadData = async () => {
    try {
      setLoading(true)
      const params = filterType ? { type: filterType } : undefined
      const [logsData, statsData] = await Promise.all([
        frictionApi.getFrictionLogs(params),
        frictionApi.getFrictionStats(),
      ])
      setLogs(logsData)
      setStats(statsData)
    } catch (error) {
      console.error('Failed to load friction data:', error)
    } finally {
      setLoading(false)
    }
  }

  const getIcon = (type: string) => {
    switch (type) {
      case 'blocker':
        return '🚫'
      case 'learning':
        return '💡'
      case 'win':
        return '🎉'
      case 'incident':
        return '🔥'
      default:
        return '📝'
    }
  }

  const getImpactColor = (level: number) => {
    if (level >= 4) return 'text-red-600 font-semibold'
    if (level >= 3) return 'text-orange-600'
    return 'text-gray-600'
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    })
  }

  if (loading) {
    return (
      <div className="animate-pulse space-y-4">
        <div className="h-32 bg-gray-200 rounded"></div>
        <div className="h-64 bg-gray-200 rounded"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Stats Summary */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div className="bg-white rounded-lg shadow p-4">
            <div className="text-2xl font-bold">{stats.total}</div>
            <div className="text-sm text-gray-600">Total Logs</div>
          </div>
          {Object.entries(stats.by_type).map(([type, count]) => (
            <div key={type} className="bg-white rounded-lg shadow p-4">
              <div className="text-2xl font-bold">
                {getIcon(type)} {count as number}
              </div>
              <div className="text-sm text-gray-600 capitalize">{type}s</div>
            </div>
          ))}
        </div>
      )}

      {/* Filter */}
      <div className="bg-white rounded-lg shadow p-4">
        <label className="block text-sm font-medium mb-2">Filter by Type</label>
        <select
          value={filterType}
          onChange={(e) => setFilterType(e.target.value)}
          className="w-full md:w-auto border rounded px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="">All Types</option>
          <option value="blocker">Blockers</option>
          <option value="learning">Learnings</option>
          <option value="win">Wins</option>
          <option value="incident">Incidents</option>
        </select>
      </div>

      {/* Logs Timeline */}
      <div className="bg-white rounded-lg shadow">
        <div className="p-4 border-b">
          <h2 className="text-xl font-bold">Recent Friction Logs</h2>
        </div>
        <div className="divide-y">
          {logs.length === 0 ? (
            <div className="p-8 text-center text-gray-500">
              No friction logs found. Start logging your friction points!
            </div>
          ) : (
            logs.map((log) => (
              <div key={log.id} className="p-4 hover:bg-gray-50 transition-colors">
                <div className="flex items-start gap-3">
                  <div className="text-2xl">{getIcon(log.type)}</div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium capitalize">{log.type}</span>
                      <span className={`text-sm ${getImpactColor(log.impact_level)}`}>
                        Impact: {log.impact_level}/5
                      </span>
                      <span className="text-sm text-gray-500">
                        {formatDate(log.date)}
                      </span>
                    </div>
                    <p className="mt-1 text-gray-700">{log.description}</p>
                    {log.tags && (
                      <div className="mt-2 flex gap-2 flex-wrap">
                        {log.tags.split(',').map((tag, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-1 bg-gray-100 text-xs rounded"
                          >
                            {tag.trim()}
                          </span>
                        ))}
                      </div>
                    )}
                    {log.resolution && (
                      <div className="mt-2 text-sm text-green-600">
                        ✅ Resolved: {log.resolution}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}

