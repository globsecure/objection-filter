import React, { useEffect, useState } from 'react'
import { commitsApi, frictionApi, manualEntriesApi, momentsApi } from '../services/api'
import type { Commit, FrictionLog, ManualEntry, CareerMoment } from '../types'

interface TimelineItem {
  id: string
  type: 'commit' | 'friction' | 'manual' | 'moment'
  date: Date
  data: Commit | FrictionLog | ManualEntry | CareerMoment
}

export function WorkTimeline() {
  const [items, setItems] = useState<TimelineItem[]>([])
  const [loading, setLoading] = useState(true)
  const [startDate, setStartDate] = useState<string>(
    new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  )
  const [endDate, setEndDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  )

  useEffect(() => {
    loadTimelineData()
  }, [startDate, endDate])

  const loadTimelineData = async () => {
    try {
      setLoading(true)
      const start = `${startDate}T00:00:00`
      const end = `${endDate}T23:59:59`

      const [commits, frictionLogs, manualEntries, moments] = await Promise.all([
        commitsApi.list({ start_date: start, end_date: end }),
        frictionApi.getFrictionLogs({ start_date: start, end_date: end }),
        manualEntriesApi.list({ start_date: start, end_date: end }),
        momentsApi.list({ start_date: start, end_date: end }),
      ])

      const timelineItems: TimelineItem[] = []

      // Add commits
      commits.forEach((commit) => {
        timelineItems.push({
          id: `commit-${commit.id}`,
          type: 'commit',
          date: new Date(commit.date),
          data: commit,
        })
      })

      // Add friction logs
      frictionLogs.forEach((log) => {
        timelineItems.push({
          id: `friction-${log.id}`,
          type: 'friction',
          date: new Date(log.date),
          data: log,
        })
      })

      // Add manual entries
      manualEntries.forEach((entry) => {
        timelineItems.push({
          id: `manual-${entry.id}`,
          type: 'manual',
          date: new Date(entry.date),
          data: entry,
        })
      })

      // Add career moments
      moments.forEach((moment) => {
        timelineItems.push({
          id: `moment-${moment.id}`,
          type: 'moment',
          date: new Date(moment.date),
          data: moment,
        })
      })

      // Sort by date (newest first)
      timelineItems.sort((a, b) => b.date.getTime() - a.date.getTime())

      setItems(timelineItems)
    } catch (error) {
      console.error('Failed to load timeline data:', error)
    } finally {
      setLoading(false)
    }
  }

  const groupByDate = (items: TimelineItem[]) => {
    const groups: Record<string, TimelineItem[]> = {}
    items.forEach((item) => {
      const dateKey = item.date.toISOString().split('T')[0]
      if (!groups[dateKey]) {
        groups[dateKey] = []
      }
      groups[dateKey].push(item)
    })
    return groups
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    })
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  const getIcon = (item: TimelineItem) => {
    if (item.type === 'commit') {
      return '📝'
    } else if (item.type === 'friction') {
      const log = item.data as FrictionLog
      switch (log.type) {
        case 'blocker':
          return '🚫'
        case 'learning':
          return '💡'
        case 'win':
          return '🎉'
        case 'incident':
          return '🔥'
        default:
          return '📝'
      }
    } else if (item.type === 'moment') {
      const moment = item.data as CareerMoment
      switch (moment.type) {
        case 'win':
          return '🏆'
        case 'failure':
          return '💔'
        case 'pivot':
          return '🔄'
        case 'learning':
          return '📚'
        default:
          return '⭐'
      }
    } else {
      const entry = item.data as ManualEntry
      switch (entry.type) {
        case 'code_review':
          return '👀'
        case 'design_doc':
          return '📄'
        case 'mentoring':
          return '👥'
        case 'incident':
          return '🔥'
        case 'meeting':
          return '📅'
        default:
          return '📝'
      }
    }
  }

  const renderItem = (item: TimelineItem) => {
    if (item.type === 'commit') {
      const commit = item.data as Commit
      return (
        <div className="flex items-start gap-3 p-3 hover:bg-gray-50 rounded">
          <div className="text-xl">{getIcon(item)}</div>
          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-medium text-sm text-gray-500">
                {formatTime(item.date)}
              </span>
              <span className="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded">
                Commit
              </span>
              {commit.type && (
                <span className="text-xs px-2 py-1 bg-gray-100 text-gray-700 rounded">
                  {commit.type}
                </span>
              )}
            </div>
            <p className="mt-1 text-gray-800">{commit.message}</p>
            <div className="mt-1 text-xs text-gray-500">
              +{commit.insertions} -{commit.deletions} lines
            </div>
          </div>
        </div>
      )
    } else if (item.type === 'moment') {
      const moment = item.data as CareerMoment
      const typeColors = {
        win: 'bg-green-100 text-green-700',
        failure: 'bg-red-100 text-red-700',
        pivot: 'bg-blue-100 text-blue-700',
        learning: 'bg-yellow-100 text-yellow-700',
      }
      return (
        <div className="flex items-start gap-3 p-3 hover:bg-gray-50 rounded border-l-4 border-l-blue-500">
          <div className="text-xl">{getIcon(item)}</div>
          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-medium text-sm text-gray-500">
                {formatTime(item.date)}
              </span>
              <span className={`text-xs px-2 py-1 rounded capitalize ${typeColors[moment.type]}`}>
                {moment.type}
              </span>
              <span className="text-xs px-2 py-1 bg-indigo-100 text-indigo-700 rounded">
                Career Moment
              </span>
            </div>
            <p className="mt-1 font-semibold text-gray-800">{moment.title}</p>
            {moment.story && (
              <p className="mt-1 text-sm text-gray-600">{moment.story}</p>
            )}
            {moment.impact && (
              <div className="mt-1 text-xs text-gray-500">
                <strong>Impact:</strong> {moment.impact}
              </div>
            )}
            {moment.witnesses && (
              <div className="mt-1 text-xs text-gray-500">
                Witnesses: {moment.witnesses}
              </div>
            )}
            {moment.tags && (
              <div className="mt-1 flex gap-1 flex-wrap">
                {moment.tags.split(',').map((tag, idx) => (
                  <span
                    key={idx}
                    className="text-xs px-2 py-0.5 bg-gray-100 text-gray-600 rounded"
                  >
                    {tag.trim()}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      )
    } else if (item.type === 'friction') {
      const log = item.data as FrictionLog
      return (
        <div className="flex items-start gap-3 p-3 hover:bg-gray-50 rounded">
          <div className="text-xl">{getIcon(item)}</div>
          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-medium text-sm text-gray-500">
                {formatTime(item.date)}
              </span>
              <span className="text-xs px-2 py-1 bg-orange-100 text-orange-700 rounded capitalize">
                {log.type}
              </span>
              <span className="text-xs px-2 py-1 bg-red-100 text-red-700 rounded">
                Impact: {log.impact_level}/5
              </span>
            </div>
            <p className="mt-1 text-gray-800">{log.description}</p>
            {log.tags && (
              <div className="mt-1 flex gap-1 flex-wrap">
                {log.tags.split(',').map((tag, idx) => (
                  <span
                    key={idx}
                    className="text-xs px-2 py-0.5 bg-gray-100 text-gray-600 rounded"
                  >
                    {tag.trim()}
                  </span>
                ))}
              </div>
            )}
            {log.resolution && (
              <div className="mt-1 text-xs text-green-600">
                ✅ {log.resolution}
              </div>
            )}
          </div>
        </div>
      )
    } else {
      const entry = item.data as ManualEntry
      return (
        <div className="flex items-start gap-3 p-3 hover:bg-gray-50 rounded">
          <div className="text-xl">{getIcon(item)}</div>
          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-medium text-sm text-gray-500">
                {formatTime(item.date)}
              </span>
              <span className="text-xs px-2 py-1 bg-purple-100 text-purple-700 rounded">
                {entry.type.replace('_', ' ')}
              </span>
              {entry.duration_minutes && (
                <span className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded">
                  {entry.duration_minutes} min
                </span>
              )}
            </div>
            <p className="mt-1 font-medium text-gray-800">{entry.title}</p>
            {entry.description && (
              <p className="mt-1 text-sm text-gray-600">{entry.description}</p>
            )}
            {entry.collaborators && (
              <div className="mt-1 text-xs text-gray-500">
                With: {entry.collaborators}
              </div>
            )}
            {entry.links && (
              <div className="mt-1">
                {entry.links.split(',').map((link, idx) => (
                  <a
                    key={idx}
                    href={link.trim()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-blue-600 hover:underline mr-2"
                  >
                    Link {idx + 1}
                  </a>
                ))}
              </div>
            )}
          </div>
        </div>
      )
    }
  }

  if (loading) {
    return (
      <div className="animate-pulse space-y-4">
        <div className="h-32 bg-gray-200 rounded"></div>
        <div className="h-64 bg-gray-200 rounded"></div>
      </div>
    )
  }

  const groupedItems = groupByDate(items)
  const sortedDates = Object.keys(groupedItems).sort(
    (a, b) => new Date(b).getTime() - new Date(a).getTime()
  )

  return (
    <div className="space-y-6">
      {/* Date Range Filter */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium mb-2">Start Date</label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full border rounded px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">End Date</label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full border rounded px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div className="flex items-end">
            <button
              onClick={loadTimelineData}
              className="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600 transition-colors"
            >
              Refresh
            </button>
          </div>
        </div>
      </div>

      {/* Timeline */}
      {sortedDates.length === 0 ? (
        <div className="bg-white rounded-lg shadow p-8 text-center text-gray-500">
          No items found for the selected date range.
        </div>
      ) : (
        <div className="space-y-6">
          {sortedDates.map((dateKey) => (
            <div key={dateKey} className="bg-white rounded-lg shadow">
              <div className="p-4 border-b bg-gray-50">
                <h3 className="text-lg font-semibold">{formatDate(dateKey)}</h3>
                <p className="text-sm text-gray-500">
                  {groupedItems[dateKey].length} item
                  {groupedItems[dateKey].length !== 1 ? 's' : ''}
                </p>
              </div>
              <div className="divide-y">
                {groupedItems[dateKey]
                  .sort((a, b) => b.date.getTime() - a.date.getTime())
                  .map((item) => (
                    <div key={item.id}>{renderItem(item)}</div>
                  ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

