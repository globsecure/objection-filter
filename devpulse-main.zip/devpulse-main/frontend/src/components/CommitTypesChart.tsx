import { useState, useEffect } from 'react'
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts'
import { metricsApi } from '../services/api'
import type { CommitTypeDistribution } from '../types'

const COLORS = {
  Feature: '#10b981',
  Bugfix: '#ef4444',
  Refactor: '#3b82f6',
  Documentation: '#8b5cf6',
  Chore: '#f59e0b',
  Unknown: '#6b7280',
}

function CommitTypesChart() {
  const [data, setData] = useState<CommitTypeDistribution[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadCommitTypes()
  }, [])

  const loadCommitTypes = async (): Promise<void> => {
    try {
      setLoading(true)
      const response = await metricsApi.getCommitTypes()
      setData(response)
    } catch (error) {
      console.error('Error loading commit types:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <div className="text-center py-8">Loading commit types...</div>
  }

  const chartData = data.map((item) => ({
    name: item.type,
    value: item.count,
  }))

  const getColor = (name: string): string => {
    return COLORS[name as keyof typeof COLORS] || COLORS.Unknown
  }

  return (
    <div>
      <h4 className="text-sm font-medium mb-4">Commit Types Distribution</h4>
      <ResponsiveContainer width="100%" height={300}>
        <PieChart>
          <Pie
            data={chartData}
            cx="50%"
            cy="50%"
            labelLine={false}
            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
            outerRadius={100}
            fill="#8884d8"
            dataKey="value"
          >
            {chartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={getColor(entry.name)} />
            ))}
          </Pie>
          <Tooltip
            contentStyle={{
              backgroundColor: '#fff',
              border: '1px solid #e5e7eb',
              borderRadius: '6px',
            }}
          />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
      <div className="mt-4 grid grid-cols-2 gap-2 text-sm">
        {chartData.map((item) => (
          <div key={item.name} className="flex items-center gap-2">
            <div
              className="w-3 h-3 rounded"
              style={{ backgroundColor: getColor(item.name) }}
            />
            <span className="text-gray-600">{item.name}:</span>
            <span className="font-medium">{item.value}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

export default CommitTypesChart

