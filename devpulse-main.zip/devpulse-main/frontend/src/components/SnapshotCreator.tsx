import React, { useState } from 'react'
import { benchmarksApi } from '../services/api'

interface SnapshotCreatorProps {
  onSuccess?: () => void
}

export const SnapshotCreator: React.FC<SnapshotCreatorProps> = ({
  onSuccess,
}) => {
  const [periodLabel, setPeriodLabel] = useState('')
  const [periodStart, setPeriodStart] = useState('')
  const [periodEnd, setPeriodEnd] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      await benchmarksApi.createSnapshot({
        period_label: periodLabel,
        period_start: periodStart,
        period_end: periodEnd,
      })
      setPeriodLabel('')
      setPeriodStart('')
      setPeriodEnd('')
      onSuccess?.()
    } catch (error) {
      console.error('Error creating snapshot:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className='space-y-4 p-4 border rounded'>
      <h3 className='font-semibold'>Create Historical Snapshot</h3>

      <div>
        <label className='block text-sm font-medium mb-1'>Period Label</label>
        <input
          type='text'
          value={periodLabel}
          onChange={(e) => setPeriodLabel(e.target.value)}
          className='w-full px-3 py-2 border rounded'
          placeholder='e.g., Q1-2024'
          required
        />
      </div>

      <div className='grid grid-cols-2 gap-4'>
        <div>
          <label className='block text-sm font-medium mb-1'>Start Date</label>
          <input
            type='date'
            value={periodStart}
            onChange={(e) => setPeriodStart(e.target.value)}
            className='w-full px-3 py-2 border rounded'
            required
          />
        </div>
        <div>
          <label className='block text-sm font-medium mb-1'>End Date</label>
          <input
            type='date'
            value={periodEnd}
            onChange={(e) => setPeriodEnd(e.target.value)}
            className='w-full px-3 py-2 border rounded'
            required
          />
        </div>
      </div>

      <button
        type='submit'
        disabled={loading}
        className='px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50'
      >
        {loading ? 'Creating...' : 'Create Snapshot'}
      </button>
    </form>
  )
}

