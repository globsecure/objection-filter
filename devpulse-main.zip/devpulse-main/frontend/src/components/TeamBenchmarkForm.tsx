import React, { useState } from 'react'
import { benchmarksApi } from '../services/api'
import type { TeamBenchmarkCreate } from '../types'

interface TeamBenchmarkFormProps {
  onSuccess?: () => void
}

export const TeamBenchmarkForm: React.FC<TeamBenchmarkFormProps> = ({
  onSuccess,
}) => {
  const [formData, setFormData] = useState<TeamBenchmarkCreate>({
    metric_name: 'deployment_frequency',
    metric_value: 0,
    metric_unit: 'per_week',
    period_start: new Date().toISOString().split('T')[0],
    period_end: new Date().toISOString().split('T')[0],
    source: 'manual',
  })
  const [bulkMode, setBulkMode] = useState(false)
  const [bulkData, setBulkData] = useState('')
  const [loading, setLoading] = useState(false)

  const metricOptions = [
    {
      value: 'deployment_frequency',
      label: 'Deployment Frequency',
      unit: 'per_week',
    },
    { value: 'lead_time', label: 'Lead Time', unit: 'days' },
    {
      value: 'change_failure_rate',
      label: 'Change Failure Rate',
      unit: 'percentage',
    },
    { value: 'mttr', label: 'MTTR', unit: 'hours' },
  ]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      if (bulkMode) {
        // Parse CSV or JSON bulk data
        const lines = bulkData.split('\n').filter((l) => l.trim())
        const benchmarks: TeamBenchmarkCreate[] = lines.map((line) => {
          const [metric_name, value, start, end, team] = line.split(',')
          return {
            metric_name: metric_name.trim(),
            metric_value: parseFloat(value.trim()),
            metric_unit: metricOptions.find(
              (m) => m.value === metric_name.trim()
            )?.unit,
            period_start: start.trim(),
            period_end: end.trim(),
            team_name: team?.trim(),
            source: 'manual',
          }
        })
        await benchmarksApi.importTeamBenchmarks(benchmarks)
      } else {
        await benchmarksApi.createTeamBenchmark(formData)
      }
      onSuccess?.()
    } catch (error) {
      console.error('Error saving benchmark:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className='space-y-4'>
      <div className='flex gap-2 mb-4'>
        <button
          onClick={() => setBulkMode(false)}
          className={`px-4 py-2 rounded ${
            !bulkMode ? 'bg-blue-600 text-white' : 'bg-gray-200'
          }`}
        >
          Single Entry
        </button>
        <button
          onClick={() => setBulkMode(true)}
          className={`px-4 py-2 rounded ${
            bulkMode ? 'bg-blue-600 text-white' : 'bg-gray-200'
          }`}
        >
          Bulk Import
        </button>
      </div>

      <form onSubmit={handleSubmit} className='space-y-4'>
        {!bulkMode ? (
          <>
            <div>
              <label className='block text-sm font-medium mb-1'>Metric</label>
              <select
                value={formData.metric_name}
                onChange={(e) => {
                  const selected = metricOptions.find(
                    (m) => m.value === e.target.value
                  )
                  setFormData({
                    ...formData,
                    metric_name: e.target.value,
                    metric_unit: selected?.unit,
                  })
                }}
                className='w-full px-3 py-2 border rounded'
                required
              >
                {metricOptions.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className='block text-sm font-medium mb-1'>Value</label>
              <input
                type='number'
                step='0.01'
                value={formData.metric_value}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    metric_value: parseFloat(e.target.value),
                  })
                }
                className='w-full px-3 py-2 border rounded'
                required
              />
            </div>

            <div className='grid grid-cols-2 gap-4'>
              <div>
                <label className='block text-sm font-medium mb-1'>
                  Period Start
                </label>
                <input
                  type='date'
                  value={formData.period_start}
                  onChange={(e) =>
                    setFormData({ ...formData, period_start: e.target.value })
                  }
                  className='w-full px-3 py-2 border rounded'
                  required
                />
              </div>
              <div>
                <label className='block text-sm font-medium mb-1'>
                  Period End
                </label>
                <input
                  type='date'
                  value={formData.period_end}
                  onChange={(e) =>
                    setFormData({ ...formData, period_end: e.target.value })
                  }
                  className='w-full px-3 py-2 border rounded'
                  required
                />
              </div>
            </div>

            <div>
              <label className='block text-sm font-medium mb-1'>
                Team Name (optional)
              </label>
              <input
                type='text'
                value={formData.team_name || ''}
                onChange={(e) =>
                  setFormData({ ...formData, team_name: e.target.value })
                }
                className='w-full px-3 py-2 border rounded'
                placeholder='e.g., Team Alpha (anonymized)'
              />
            </div>
          </>
        ) : (
          <div>
            <label className='block text-sm font-medium mb-1'>
              Bulk Import (CSV format:
              metric_name,value,start_date,end_date,team_name)
            </label>
            <textarea
              value={bulkData}
              onChange={(e) => setBulkData(e.target.value)}
              className='w-full px-3 py-2 border rounded font-mono text-sm'
              rows={10}
              placeholder='deployment_frequency,3.5,2024-01-01,2024-03-31,Team Alpha&#10;lead_time,2.5,2024-01-01,2024-03-31,Team Alpha'
            />
          </div>
        )}

        <button
          type='submit'
          disabled={loading}
          className='px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50'
        >
          {loading
            ? 'Saving...'
            : bulkMode
            ? 'Import Benchmarks'
            : 'Create Benchmark'}
        </button>
      </form>
    </div>
  )
}

