import React, { useState } from 'react'
import { momentsApi } from '../services/api'
import type { CareerMomentCreate, CareerMoment } from '../types'

type MomentType = 'win' | 'failure' | 'pivot' | 'learning'

interface CareerMomentFormProps {
  initialData?: CareerMoment
  onSuccess?: () => void
  onCancel?: () => void
}

export const CareerMomentForm: React.FC<CareerMomentFormProps> = ({
  initialData,
  onSuccess,
  onCancel,
}) => {
  const [formData, setFormData] = useState<CareerMomentCreate>(
    initialData
      ? {
          ...initialData,
          date: initialData.date.split('T')[0],
        }
      : {
          date: new Date().toISOString().split('T')[0],
          type: 'win',
          title: '',
          story: '',
          impact: '',
          witnesses: '',
          tags: '',
        }
  )
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const payload: CareerMomentCreate = {
        ...formData,
        date: `${formData.date}T12:00:00`,
      }
      if (initialData) {
        await momentsApi.update(initialData.id, payload)
      } else {
        await momentsApi.create(payload)
      }
      onSuccess?.()
    } catch (error) {
      console.error('Error saving moment:', error)
      alert('Failed to save moment. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const getTypeLabel = (type: MomentType) => {
    const labels: Record<MomentType, string> = {
      win: 'Win',
      failure: 'Failure',
      pivot: 'Pivot',
      learning: 'Learning',
    }
    return labels[type]
  }

  const getTypeColor = (type: MomentType) => {
    const colors: Record<MomentType, string> = {
      win: 'bg-green-500',
      failure: 'bg-red-500',
      pivot: 'bg-blue-500',
      learning: 'bg-yellow-500',
    }
    return colors[type]
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 bg-white rounded-lg shadow p-6">
      <h2 className="text-xl font-bold mb-4">
        {initialData ? 'Edit Career Moment' : 'Create Career Moment'}
      </h2>

      <div>
        <label className="block text-sm font-medium mb-2">Date</label>
        <input
          type="date"
          value={formData.date}
          onChange={(e) => setFormData({ ...formData, date: e.target.value })}
          className="w-full px-3 py-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Type</label>
        <div className="flex gap-2 flex-wrap">
          {(['win', 'failure', 'pivot', 'learning'] as MomentType[]).map((type) => (
            <button
              key={type}
              type="button"
              onClick={() => setFormData({ ...formData, type })}
              className={`px-4 py-2 rounded transition-colors ${
                formData.type === type
                  ? `${getTypeColor(type)} text-white`
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              {getTypeLabel(type)}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Title</label>
        <input
          type="text"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          className="w-full px-3 py-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="e.g., Shipped payments refactor that saved 20% API costs"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Story</label>
        <textarea
          value={formData.story || ''}
          onChange={(e) => setFormData({ ...formData, story: e.target.value })}
          className="w-full px-3 py-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          rows={6}
          placeholder="Tell the story of this moment..."
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Impact</label>
        <textarea
          value={formData.impact || ''}
          onChange={(e) => setFormData({ ...formData, impact: e.target.value })}
          className="w-full px-3 py-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          rows={4}
          placeholder="Describe the business/technical impact..."
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Witnesses</label>
        <input
          type="text"
          value={formData.witnesses || ''}
          onChange={(e) => setFormData({ ...formData, witnesses: e.target.value })}
          className="w-full px-3 py-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="Comma-separated list of people"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Tags</label>
        <input
          type="text"
          value={formData.tags || ''}
          onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
          className="w-full px-3 py-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="Comma-separated tags"
        />
      </div>

      <div className="flex gap-2">
        <button
          type="submit"
          disabled={loading}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
        >
          {loading ? 'Saving...' : initialData ? 'Update' : 'Create'}
        </button>
        {onCancel && (
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400"
          >
            Cancel
          </button>
        )}
      </div>
    </form>
  )
}

