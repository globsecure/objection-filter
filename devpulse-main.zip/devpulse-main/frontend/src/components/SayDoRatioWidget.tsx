import { useState, useEffect } from 'react'
import { paypalApi } from '../services/api'

interface SayDoRatioData {
  ratio: number
  completed: number
  total: number
  warning: boolean
  quarter_start: string
  quarter_end: string
  target: number
}

export function SayDoRatioWidget() {
  const [data, setData] = useState<SayDoRatioData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    setLoading(true)
    try {
      const result = await paypalApi.getSayDoRatio()
      setData(result)
    } catch (error) {
      console.error('Error loading Say/Do Ratio:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow">
        <div className="text-center py-4">Loading Say/Do Ratio...</div>
      </div>
    )
  }

  if (!data) {
    return null
  }

  const ratioColor = data.ratio >= data.target ? 'text-green-600' : 'text-red-600'
  const ratioBgColor = data.ratio >= data.target ? 'bg-green-100' : 'bg-red-100'

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h3 className="text-xl font-semibold mb-4">Say/Do Ratio</h3>
      
      <div className="space-y-4">
        <div className={`${ratioBgColor} p-4 rounded-lg`}>
          <div className="text-4xl font-bold ${ratioColor} mb-2">
            {data.ratio}%
          </div>
          <div className="text-sm text-gray-600">
            {data.completed} of {data.total} goals completed
          </div>
          {data.warning && (
            <div className="mt-2 text-sm text-red-700 font-medium">
              ⚠️ Risk of missing 'High Performer' execution target (Target: {data.target}%)
            </div>
          )}
        </div>

        <div className="text-xs text-gray-500">
          Quarter: {new Date(data.quarter_start).toLocaleDateString()} - {new Date(data.quarter_end).toLocaleDateString()}
        </div>
      </div>
    </div>
  )
}

