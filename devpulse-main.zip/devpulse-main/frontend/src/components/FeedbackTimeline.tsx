import React, { useEffect, useState } from 'react'
import { Feedback } from '../types'
import { feedbackApi } from '../services/api'

export const FeedbackTimeline: React.FC = () => {
  const [feedback, setFeedback] = useState<Feedback[]>([])
  const [trends, setTrends] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadFeedback()
    loadTrends()
  }, [])

  const loadFeedback = async () => {
    try {
      const data = await feedbackApi.list()
      setFeedback(data)
    } catch (error) {
      console.error('Error loading feedback:', error)
    } finally {
      setLoading(false)
    }
  }

  const loadTrends = async () => {
    try {
      const data = await feedbackApi.getTrends()
      setTrends(data)
    } catch (error) {
      console.error('Error loading trends:', error)
    }
  }

  if (loading) return <div>Loading feedback...</div>

  return (
    <div className="space-y-4">
      {trends && (
        <div className="p-4 bg-gray-50 rounded">
          <h3 className="font-semibold mb-2">Feedback Trends</h3>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-sm text-gray-600">Total</p>
              <p className="text-2xl font-bold">{trends.total}</p>
            </div>
            {Object.entries(trends.by_category || {}).map(([cat, count]) => (
              <div key={cat}>
                <p className="text-sm text-gray-600 capitalize">{cat}</p>
                <p className="text-2xl font-bold">{count as number}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="space-y-3">
        {feedback.length === 0 ? (
          <div className="text-center text-gray-500 py-8">
            No feedback found. Add your first feedback entry!
          </div>
        ) : (
          feedback.map((item) => (
            <div key={item.id} className="p-4 border rounded bg-white">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="font-semibold">{item.from_who}</p>
                  <p className="text-sm text-gray-600">
                    {new Date(item.date).toLocaleDateString()}
                    {item.context && ` • ${item.context}`}
                  </p>
                </div>
                {item.category && (
                  <span className={`px-2 py-1 rounded text-xs ${
                    item.category === 'positive' ? 'bg-green-100 text-green-800' :
                    item.category === 'constructive' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {item.category}
                  </span>
                )}
              </div>
              <p className="text-gray-700 whitespace-pre-wrap">{item.feedback_text}</p>
              {item.tags && (
                <div className="flex gap-1 mt-2">
                  {item.tags.split(',').map((tag, i) => (
                    <span key={i} className="px-2 py-1 bg-gray-200 rounded text-xs">
                      {tag.trim()}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  )
}

