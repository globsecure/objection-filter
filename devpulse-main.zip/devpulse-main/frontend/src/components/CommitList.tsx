import { useState } from 'react'
import { format } from 'date-fns'
import type { Commit, CommitType } from '../types'

interface CommitListProps {
  commits: Commit[]
}

const typeColors: Record<CommitType | 'Unknown', string> = {
  Feature: 'bg-green-100 text-green-800',
  Bugfix: 'bg-red-100 text-red-800',
  Refactor: 'bg-blue-100 text-blue-800',
  Documentation: 'bg-yellow-100 text-yellow-800',
  Chore: 'bg-gray-100 text-gray-800',
  Unknown: 'bg-gray-100 text-gray-800',
}

function CommitList({ commits }: CommitListProps) {
  const [filterType, setFilterType] = useState<string>('all')

  const filteredCommits = commits.filter((commit) => {
    if (filterType === 'all') return true
    return commit.type === filterType
  })

  const sortedCommits = [...filteredCommits].sort((a, b) => {
    return new Date(b.date).getTime() - new Date(a.date).getTime()
  })

  const typeCounts = commits.reduce((acc, commit) => {
    const type = commit.type || 'Unknown'
    acc[type] = (acc[type] || 0) + 1
    return acc
  }, {} as Record<string, number>)

  return (
    <div>
      <div className="mb-4 flex gap-4 items-center">
        <div>
          <label className="mr-2 text-sm font-medium">Filter by type:</label>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="border rounded-md px-3 py-1"
          >
            <option value="all">All</option>
            {Object.entries(typeCounts).map(([type, count]) => (
              <option key={type} value={type}>
                {type} ({count})
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Date
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Type
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Message
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Changes
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {sortedCommits.map((commit) => (
              <tr key={commit.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {format(new Date(commit.date), 'MMM dd, yyyy')}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span
                    className={`px-2 py-1 text-xs font-semibold rounded-full ${
                      typeColors[commit.type || 'Unknown']
                    }`}
                  >
                    {commit.type || 'Unknown'}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-gray-900">
                  {commit.message.substring(0, 80)}
                  {commit.message.length > 80 ? '...' : ''}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <span className="text-green-600">+{commit.insertions}</span>
                  {' '}
                  <span className="text-red-600">-{commit.deletions}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default CommitList

