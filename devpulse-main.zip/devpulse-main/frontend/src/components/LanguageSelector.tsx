import React, { useState, useEffect } from 'react';

interface LanguageSelectorProps {
  value?: string;
  onChange?: (language: string) => void;
}

export const LanguageSelector: React.FC<LanguageSelectorProps> = ({ value = 'en', onChange }) => {
  const [language, setLanguage] = useState(value);

  useEffect(() => {
    setLanguage(value);
  }, [value]);

  const handleChange = (newLanguage: string) => {
    setLanguage(newLanguage);
    if (onChange) {
      onChange(newLanguage);
    }
  };

  return (
    <div className="flex items-center gap-2">
      <label className="text-sm font-medium">Language:</label>
      <select
        value={language}
        onChange={(e) => handleChange(e.target.value)}
        className="px-3 py-1 border rounded-md bg-white"
      >
        <option value="en">English</option>
        <option value="pt">Português</option>
      </select>
    </div>
  );
};

