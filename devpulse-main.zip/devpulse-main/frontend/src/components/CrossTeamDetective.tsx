import { useState, useEffect } from 'react'
import { paypalApi } from '../services/api'

interface CrossTeamData {
  cross_team_percentage: number
  cross_team_count: number
  total_count: number
  breakdown: Array<{
    repo_id: number
    repo_name: string
    tags: string
    commit_count: number
  }>
}

export function CrossTeamDetective() {
  const [data, setData] = useState<CrossTeamData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    setLoading(true)
    try {
      const result = await paypalApi.getCrossTeamWork()
      setData(result)
    } catch (error) {
      console.error('Error loading Cross-Team Work:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow">
        <div className="text-center py-4">Loading Cross-Team Work...</div>
      </div>
    )
  }

  if (!data) {
    return null
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h3 className="text-xl font-semibold mb-4">Cross-Team Work</h3>
      
      <div className="space-y-4">
        <div className="bg-blue-50 p-4 rounded-lg">
          <div className="text-3xl font-bold text-blue-600 mb-2">
            {data.cross_team_percentage}%
          </div>
          <div className="text-sm text-gray-600">
            {data.cross_team_count} of {data.total_count} commits in cross-team repos
          </div>
        </div>

        {data.breakdown.length > 0 && (
          <div>
            <h4 className="font-semibold mb-2">Breakdown by Repository</h4>
            <div className="space-y-2">
              {data.breakdown.map((repo) => (
                <div key={repo.repo_id} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                  <div>
                    <div className="font-medium">{repo.repo_name}</div>
                    <div className="text-xs text-gray-500">{repo.tags}</div>
                  </div>
                  <div className="text-sm font-medium">{repo.commit_count} commits</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

