import { useState, useEffect } from 'react'
import { dataQualityApi } from '../services/api'

export function RemindersPanel() {
  const [reminders, setReminders] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [days, setDays] = useState(7)

  useEffect(() => {
    loadReminders()
  }, [days])

  const loadReminders = async () => {
    setLoading(true)
    try {
      const data = await dataQualityApi.getReminders(days)
      setReminders(data)
    } catch (error) {
      console.error('Error loading reminders:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="bg-white p-4 rounded-lg shadow">
        <div className="text-center py-4 text-sm text-gray-500">Loading reminders...</div>
      </div>
    )
  }

  if (reminders.length === 0) {
    return (
      <div className="bg-white p-4 rounded-lg shadow">
        <h3 className="font-semibold mb-2">Smart Reminders</h3>
        <p className="text-sm text-gray-500">No reminders at this time. Your data looks good!</p>
      </div>
    )
  }

  const priorityColors = {
    high: 'border-red-500 bg-red-50',
    medium: 'border-yellow-500 bg-yellow-50',
    low: 'border-blue-500 bg-blue-50',
  }

  const priorityIcons = {
    high: '🔴',
    medium: '🟡',
    low: '🔵',
  }

  return (
    <div className="bg-white p-4 rounded-lg shadow">
      <div className="flex justify-between items-center mb-3">
        <h3 className="font-semibold">Smart Reminders</h3>
        <select
          value={days}
          onChange={(e) => setDays(parseInt(e.target.value))}
          className="text-xs border rounded px-2 py-1"
        >
          <option value={7}>7 days</option>
          <option value={14}>14 days</option>
          <option value={30}>30 days</option>
        </select>
      </div>
      <div className="space-y-2">
        {reminders.map((reminder, idx) => (
          <div
            key={idx}
            className={`border-l-4 p-3 rounded text-sm ${priorityColors[reminder.priority as keyof typeof priorityColors] || priorityColors.medium}`}
          >
            <div className="flex items-start gap-2">
              <span>{priorityIcons[reminder.priority as keyof typeof priorityIcons] || '🟡'}</span>
              <div className="flex-1">
                <div className="font-medium">{reminder.message}</div>
                {reminder.count && (
                  <div className="text-xs text-gray-600 mt-1">Count: {reminder.count}</div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

