import { useState, useEffect } from 'react'
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { doraApi } from '../services/api'
import type { DoraMetrics } from '../types'

interface DoraDashboardProps {
  startDate?: string
  endDate?: string
  repoId?: number
  repoIds?: number[]
  tags?: string[]
  team?: string
  aggregated?: boolean
}

function DoraDashboard({ startDate, endDate, repoId, repoIds, tags, team, aggregated }: DoraDashboardProps) {
  const [metrics, setMetrics] = useState<DoraMetrics | null>(null)
  const [trends, setTrends] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    loadMetrics()
  }, [startDate, endDate, repoId, repoIds, tags, team, aggregated])

  const loadMetrics = async () => {
    try {
      setLoading(true)
      setError(null)
      
      if (aggregated && (repoIds?.length || tags?.length || team)) {
        // Use aggregate endpoint
        const aggregateData = await doraApi.getAggregate({
          start_date: startDate,
          end_date: endDate,
          repo_ids: repoIds,
          tags: tags,
          team: team
        })
        // Transform aggregate data to match DoraMetrics format
        if (aggregateData.aggregated) {
          setMetrics({
            deployment_frequency: aggregateData.aggregated.deployment_frequency,
            lead_time: aggregateData.aggregated.lead_time,
            change_failure_rate: aggregateData.aggregated.change_failure_rate,
            mttr: aggregateData.aggregated.mttr
          } as DoraMetrics)
        }
      } else {
        // Use single repo endpoint
        const [summaryData, trendsData] = await Promise.all([
          doraApi.getSummary({ start_date: startDate, end_date: endDate, repo_id: repoId }),
          doraApi.getTrends({ start_date: startDate, end_date: endDate, repo_id: repoId, group_by: 'week' })
        ])
        setMetrics(summaryData)
        setTrends(trendsData)
      }
    } catch (err) {
      setError('Failed to load DORA metrics')
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Elite':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300'
      case 'High':
        return 'bg-blue-100 text-blue-800 border-blue-300'
      case 'Medium':
        return 'bg-amber-100 text-amber-800 border-amber-300'
      case 'Low':
        return 'bg-rose-100 text-rose-800 border-rose-300'
      default:
        return 'bg-slate-100 text-slate-800 border-slate-300'
    }
  }

  const MetricCard = ({ title, value, unit, category, subtitle }: {
    title: string
    value: number | string
    unit?: string
    category?: string
    subtitle?: string
  }) => (
    <div className="bg-white rounded-lg shadow p-6 border border-slate-200">
      <h3 className="text-sm font-medium text-slate-600 mb-2">{title}</h3>
      <div className="flex items-baseline justify-between">
        <div>
          <span className="text-3xl font-bold text-slate-900">{value}</span>
          {unit && <span className="text-lg text-slate-600 ml-1">{unit}</span>}
        </div>
        {category && (
          <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${getCategoryColor(category)}`}>
            {category}
          </span>
        )}
      </div>
      {subtitle && <p className="text-sm text-slate-500 mt-2">{subtitle}</p>}
    </div>
  )

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="animate-pulse bg-slate-200 rounded-lg h-32"></div>
          ))}
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="text-red-500 text-center py-8">{error}</div>
    )
  }

  if (!metrics) {
    return (
      <div className="text-slate-500 text-center py-8">
        <p>No DORA metrics available yet.</p>
      </div>
    )
  }

  const { deployment_frequency, lead_time, change_failure_rate, mttr } = metrics

  return (
    <div className="space-y-6">
      {/* Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <MetricCard
          title="Deployment Frequency"
          value={deployment_frequency.frequency_per_week.toFixed(1)}
          unit="/week"
          category={deployment_frequency.frequency_per_week >= 1 ? 'Elite' : deployment_frequency.frequency_per_week >= 0.2 ? 'High' : deployment_frequency.frequency_per_week >= 0.05 ? 'Medium' : 'Low'}
          subtitle={`${deployment_frequency.total_deployments} total deployments`}
        />
        <MetricCard
          title="Lead Time"
          value={lead_time.average_days.toFixed(1)}
          unit="days"
          category={lead_time.average_days < 1 ? 'Elite' : lead_time.average_days < 7 ? 'High' : lead_time.average_days < 30 ? 'Medium' : 'Low'}
          subtitle={`${lead_time.total_branches} branches merged`}
        />
        <MetricCard
          title="Change Failure Rate"
          value={change_failure_rate.failure_rate.toFixed(1)}
          unit="%"
          category={change_failure_rate.category}
          subtitle={`${change_failure_rate.failed_deployments} of ${change_failure_rate.total_deployments} failed`}
        />
        <MetricCard
          title="MTTR"
          value={mttr.mean_hours.toFixed(1)}
          unit="hours"
          category={mttr.category}
          subtitle={`${mttr.resolved_incidents} of ${mttr.total_incidents} resolved`}
        />
      </div>

      {/* Trend Charts */}
      {trends && trends.trends && trends.trends.length > 0 && (
        <div className="bg-white rounded-lg shadow p-6 border border-slate-200">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">DORA Metrics Trends</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={trends.trends}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="period" />
              <YAxis yAxisId="left" />
              <YAxis yAxisId="right" orientation="right" />
              <Tooltip />
              <Legend />
              <Line yAxisId="left" type="monotone" dataKey="deployment_frequency" stroke="#10b981" name="Deploy Freq (/week)" />
              <Line yAxisId="left" type="monotone" dataKey="lead_time" stroke="#3b82f6" name="Lead Time (days)" />
              <Line yAxisId="right" type="monotone" dataKey="change_failure_rate" stroke="#ef4444" name="Failure Rate (%)" />
              <Line yAxisId="right" type="monotone" dataKey="mttr" stroke="#f59e0b" name="MTTR (hours)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Detailed Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6 border border-slate-200">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Deployment Frequency Details</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-600">Total Deployments:</span>
              <span className="font-medium">{deployment_frequency.total_deployments}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Per Week:</span>
              <span className="font-medium">{deployment_frequency.frequency_per_week.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Per Month:</span>
              <span className="font-medium">{deployment_frequency.frequency_per_month.toFixed(2)}</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6 border border-slate-200">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Lead Time Details</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-600">Average:</span>
              <span className="font-medium">{lead_time.average_days.toFixed(2)} days</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Median:</span>
              <span className="font-medium">{lead_time.median_days.toFixed(2)} days</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Min:</span>
              <span className="font-medium">{lead_time.min_days.toFixed(2)} days</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Max:</span>
              <span className="font-medium">{lead_time.max_days.toFixed(2)} days</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6 border border-slate-200">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Change Failure Rate Details</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-600">Failure Rate:</span>
              <span className="font-medium">{change_failure_rate.failure_rate.toFixed(2)}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Failed Deployments:</span>
              <span className="font-medium">{change_failure_rate.failed_deployments}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Incidents:</span>
              <span className="font-medium">{change_failure_rate.incidents_count}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Revert Commits:</span>
              <span className="font-medium">{change_failure_rate.revert_commits_count}</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6 border border-slate-200">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">MTTR Details</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-600">Mean:</span>
              <span className="font-medium">{mttr.mean_hours.toFixed(2)} hours</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Median:</span>
              <span className="font-medium">{mttr.median_hours.toFixed(2)} hours</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Resolved:</span>
              <span className="font-medium">{mttr.resolved_incidents} / {mttr.total_incidents}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default DoraDashboard

