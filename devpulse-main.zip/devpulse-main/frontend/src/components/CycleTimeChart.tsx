import { useState, useEffect } from 'react'
import { doraApi } from '../services/api'
import type { CycleTimeMetrics } from '../types'

function CycleTimeChart() {
  const [metrics, setMetrics] = useState<CycleTimeMetrics | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    loadMetrics()
  }, [])

  const loadMetrics = async () => {
    try {
      setLoading(true)
      const data = await doraApi.getCycleTime()
      setMetrics(data)
      setError(null)
    } catch (err) {
      setError('Failed to load cycle time metrics')
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="animate-pulse">
        <div className="h-48 bg-slate-200 rounded"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="text-red-500 text-center py-4">{error}</div>
    )
  }

  if (!metrics || metrics.total_branches === 0) {
    return (
      <div className="text-slate-500 text-center py-8">
        <p>No branch metrics available yet.</p>
        <p className="text-sm mt-2">Scan repositories to collect branch data.</p>
      </div>
    )
  }

  const maxValue = Math.max(...metrics.trend.map(t => t.value || 0), metrics.average_days)

  return (
    <div>
      <h3 className="text-lg font-semibold text-slate-800 mb-4">Cycle Time (DORA)</h3>
      
      {/* Stats Grid */}
      <div className="grid grid-cols-4 gap-3 mb-6">
        <div className="bg-gradient-to-br from-indigo-50 to-indigo-100 rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-indigo-700">{metrics.average_days.toFixed(1)}</div>
          <div className="text-xs text-indigo-600">Avg Days</div>
        </div>
        <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-emerald-700">{metrics.median_days.toFixed(1)}</div>
          <div className="text-xs text-emerald-600">Median Days</div>
        </div>
        <div className="bg-gradient-to-br from-amber-50 to-amber-100 rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-amber-700">{metrics.min_days.toFixed(1)}</div>
          <div className="text-xs text-amber-600">Min Days</div>
        </div>
        <div className="bg-gradient-to-br from-rose-50 to-rose-100 rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-rose-700">{metrics.max_days.toFixed(1)}</div>
          <div className="text-xs text-rose-600">Max Days</div>
        </div>
      </div>

      {/* Trend Chart */}
      {metrics.trend.length > 0 && (
        <div>
          <div className="text-sm text-slate-600 mb-2">Weekly Trend</div>
          <div className="flex items-end gap-1 h-32">
            {metrics.trend.slice(-12).map((point, idx) => (
              <div
                key={idx}
                className="flex-1 bg-indigo-500 rounded-t hover:bg-indigo-600 transition-colors relative group"
                style={{ height: `${(point.value / maxValue) * 100}%`, minHeight: '4px' }}
              >
                <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                  {point.value.toFixed(1)}d
                </div>
              </div>
            ))}
          </div>
          <div className="flex justify-between text-xs text-slate-400 mt-1">
            <span>{metrics.trend[0]?.period || ''}</span>
            <span>{metrics.trend[metrics.trend.length - 1]?.period || ''}</span>
          </div>
        </div>
      )}

      <div className="mt-4 text-center text-sm text-slate-500">
        Based on {metrics.total_branches} merged branches
      </div>
    </div>
  )
}

export default CycleTimeChart

