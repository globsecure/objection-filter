import React, { useEffect, useState } from 'react'
import { benchmarksApi } from '../services/api'

interface HistoricalComparisonProps {
  periods: string[] // e.g., ['Q1-2024', 'Q2-2024', 'Q3-2024']
}

export const HistoricalComparison: React.FC<HistoricalComparisonProps> = ({
  periods,
}) => {
  const [comparison, setComparison] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadComparison()
  }, [periods.join(',')])

  const loadComparison = async () => {
    setLoading(true)
    try {
      const data = await benchmarksApi.compareHistorical(periods.join(','))
      setComparison(data)
    } catch (error) {
      console.error('Error loading historical comparison:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) return <div>Loading historical comparison...</div>
  if (!comparison) return <div>No historical data available</div>

  const getTrendIcon = (trend?: string) => {
    switch (trend) {
      case 'improving':
        return '📈'
      case 'declining':
        return '📉'
      case 'stable':
        return '➡️'
      default:
        return ''
    }
  }

  const getTrendColor = (trend?: string) => {
    switch (trend) {
      case 'improving':
        return 'text-green-600'
      case 'declining':
        return 'text-red-600'
      case 'stable':
        return 'text-gray-600'
      default:
        return 'text-gray-600'
    }
  }

  const metricLabels: Record<string, string> = {
    deployment_frequency: 'Deployment Frequency',
    lead_time: 'Lead Time',
    change_failure_rate: 'Change Failure Rate',
    mttr: 'MTTR',
  }

  return (
    <div className='space-y-6'>
      <h2 className='text-2xl font-bold'>Quarter-over-Quarter Comparison</h2>

      {Object.entries(comparison.comparisons || {}).map(
        ([metricName, comp]: [string, any]) => (
          <div key={metricName} className='p-6 border rounded-lg'>
            <h3 className='text-xl font-semibold mb-4'>
              {metricLabels[metricName] || metricName}
            </h3>

            {/* Trend Indicator */}
            {comp.trend && (
              <div
                className={`mb-4 flex items-center gap-2 ${getTrendColor(
                  comp.trend
                )}`}
              >
                <span className='text-2xl'>{getTrendIcon(comp.trend)}</span>
                <span className='font-semibold capitalize'>{comp.trend}</span>
                {comp.trend_percentage !== null &&
                  comp.trend_percentage !== undefined && (
                    <span className='text-sm'>
                      ({comp.trend_percentage > 0 ? '+' : ''}
                      {comp.trend_percentage.toFixed(1)}%)
                    </span>
                  )}
              </div>
            )}

            {/* Values by Period */}
            <div className='grid grid-cols-2 md:grid-cols-4 gap-4'>
              {comp.values?.map((v: any, idx: number) => (
                <div key={idx} className='p-3 bg-gray-50 rounded'>
                  <p className='text-sm text-gray-600 mb-1'>{v.period}</p>
                  <p className='text-lg font-bold'>{v.value.toFixed(2)}</p>
                </div>
              ))}
            </div>

            {/* Growth Summary */}
            {comp.first_value !== null && comp.last_value !== null && (
              <div className='mt-4 p-3 bg-blue-50 rounded'>
                <p className='text-sm text-gray-600'>
                  From {comp.first_value.toFixed(2)} to{' '}
                  {comp.last_value.toFixed(2)}
                  {comp.trend_percentage !== null &&
                    comp.trend_percentage !== undefined && (
                      <span className='ml-2 font-semibold'>
                        ({comp.trend_percentage > 0 ? '+' : ''}
                        {comp.trend_percentage.toFixed(1)}% change)
                      </span>
                    )}
                </p>
              </div>
            )}
          </div>
        )
      )}
    </div>
  )
}

