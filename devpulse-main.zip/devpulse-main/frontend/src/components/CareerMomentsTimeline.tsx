import React, { useEffect, useState } from 'react'
import { CareerMoment } from '../types'
import { momentsApi } from '../services/api'

export const CareerMomentsTimeline: React.FC = () => {
  const [moments, setMoments] = useState<CareerMoment[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<{ type?: string; tags?: string }>({})

  useEffect(() => {
    loadMoments()
  }, [filter])

  const loadMoments = async () => {
    setLoading(true)
    try {
      const data = await momentsApi.list({
        type: filter.type,
        tags: filter.tags,
      })
      setMoments(data)
    } catch (error) {
      console.error('Error loading moments:', error)
    } finally {
      setLoading(false)
    }
  }

  const typeColors = {
    win: 'bg-green-100 border-green-500',
    failure: 'bg-red-100 border-red-500',
    pivot: 'bg-blue-100 border-blue-500',
    learning: 'bg-yellow-100 border-yellow-500',
  }

  if (loading) return <div>Loading moments...</div>

  return (
    <div className="space-y-4">
      <div className="flex gap-2 mb-4">
        <select
          value={filter.type || ''}
          onChange={(e) => setFilter({ ...filter, type: e.target.value || undefined })}
          className="px-3 py-2 border rounded"
        >
          <option value="">All Types</option>
          <option value="win">Wins</option>
          <option value="failure">Failures</option>
          <option value="pivot">Pivots</option>
          <option value="learning">Learning</option>
        </select>
        <input
          type="text"
          placeholder="Filter by tags..."
          value={filter.tags || ''}
          onChange={(e) => setFilter({ ...filter, tags: e.target.value || undefined })}
          className="px-3 py-2 border rounded flex-1"
        />
      </div>

      <div className="space-y-4">
        {moments.length === 0 ? (
          <div className="text-center text-gray-500 py-8">
            No career moments found. Create your first moment!
          </div>
        ) : (
          moments.map((moment) => (
            <div
              key={moment.id}
              className={`p-4 border-l-4 rounded ${typeColors[moment.type]}`}
            >
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-semibold text-lg">{moment.title}</h3>
                  <p className="text-sm text-gray-600">
                    {new Date(moment.date).toLocaleDateString()} • {moment.type}
                  </p>
                </div>
              </div>
              {moment.story && (
                <p className="text-gray-700 mb-2 whitespace-pre-wrap">{moment.story}</p>
              )}
              {moment.impact && (
                <div className="mt-2">
                  <p className="text-sm font-medium">Impact:</p>
                  <p className="text-gray-700">{moment.impact}</p>
                </div>
              )}
              {moment.witnesses && (
                <p className="text-sm text-gray-600 mt-2">
                  Witnesses: {moment.witnesses}
                </p>
              )}
              {moment.tags && (
                <div className="flex gap-1 mt-2">
                  {moment.tags.split(',').map((tag, i) => (
                    <span
                      key={i}
                      className="px-2 py-1 bg-gray-200 rounded text-xs"
                    >
                      {tag.trim()}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  )
}

