import { useState, useEffect } from 'react'
import { dataQualityApi } from '../services/api'

export function DataQualityDashboard() {
  const [completeness, setCompleteness] = useState<any>(null)
  const [warnings, setWarnings] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [days, setDays] = useState(90)

  useEffect(() => {
    loadData()
  }, [days])

  const loadData = async () => {
    setLoading(true)
    try {
      const [completenessData, warningsData] = await Promise.all([
        dataQualityApi.getCompleteness(days),
        dataQualityApi.getWarnings(days),
      ])
      setCompleteness(completenessData)
      setWarnings(warningsData)
    } catch (error) {
      console.error('Error loading data quality:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow">
        <div className="text-center py-8">Loading data quality metrics...</div>
      </div>
    )
  }

  const scoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600'
    if (score >= 60) return 'text-yellow-600'
    return 'text-red-600'
  }

  const scoreBgColor = (score: number) => {
    if (score >= 80) return 'bg-green-100'
    if (score >= 60) return 'bg-yellow-100'
    return 'bg-red-100'
  }

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold">Data Quality Dashboard</h3>
          <select
            value={days}
            onChange={(e) => setDays(parseInt(e.target.value))}
            className="border rounded-md px-3 py-1 text-sm"
          >
            <option value={30}>Last 30 days</option>
            <option value={90}>Last 90 days</option>
            <option value={180}>Last 180 days</option>
            <option value={365}>Last year</option>
          </select>
        </div>

        {completeness && (
          <>
            {/* Overall Score */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Overall Completeness Score</span>
                <span className={`text-2xl font-bold ${scoreColor(completeness.overall_score)}`}>
                  {completeness.overall_score}%
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-4">
                <div
                  className={`h-4 rounded-full ${scoreBgColor(completeness.overall_score)}`}
                  style={{ width: `${completeness.overall_score}%` }}
                ></div>
              </div>
            </div>

            {/* Breakdown */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="border rounded-lg p-4">
                <div className="text-sm text-gray-600 mb-1">Commits Categorized</div>
                <div className="text-2xl font-bold">
                  {completeness.breakdown.commits_categorized.score}%
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  {completeness.breakdown.commits_categorized.incomplete} incomplete
                </div>
              </div>
              <div className="border rounded-lg p-4">
                <div className="text-sm text-gray-600 mb-1">Incidents Resolved</div>
                <div className="text-2xl font-bold">
                  {completeness.breakdown.incidents_resolved.score}%
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  {completeness.breakdown.incidents_resolved.incomplete} unresolved
                </div>
              </div>
              <div className="border rounded-lg p-4">
                <div className="text-sm text-gray-600 mb-1">Code Reviews Complete</div>
                <div className="text-2xl font-bold">
                  {completeness.breakdown.code_reviews_complete.score}%
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  {completeness.breakdown.code_reviews_complete.incomplete} incomplete
                </div>
              </div>
            </div>

            {/* Issues */}
            {completeness.issues.length > 0 && (
              <div className="mb-6">
                <h4 className="font-semibold mb-2">Issues Found</h4>
                <ul className="space-y-2">
                  {completeness.issues.map((issue: any, idx: number) => (
                    <li key={idx} className="flex items-center gap-2 text-sm">
                      <span className="w-2 h-2 bg-red-500 rounded-full"></span>
                      <span>{issue.message}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Recommendations */}
            {completeness.recommendations.length > 0 && (
              <div>
                <h4 className="font-semibold mb-2">Recommendations</h4>
                <ul className="space-y-2">
                  {completeness.recommendations.map((rec: string, idx: number) => (
                    <li key={idx} className="flex items-start gap-2 text-sm">
                      <span className="text-blue-500">•</span>
                      <span>{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </>
        )}
      </div>

      {/* Warnings */}
      {warnings.length > 0 && (
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-xl font-semibold mb-4">Validation Warnings</h3>
          <div className="space-y-4">
            {warnings.map((warning, idx) => (
              <div
                key={idx}
                className={`border-l-4 p-4 rounded ${
                  warning.severity === 'high'
                    ? 'border-red-500 bg-red-50'
                    : warning.severity === 'medium'
                    ? 'border-yellow-500 bg-yellow-50'
                    : 'border-blue-500 bg-blue-50'
                }`}
              >
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="font-semibold">{warning.message}</div>
                    <div className="text-sm text-gray-600 mt-1">{warning.recommendation}</div>
                    {warning.items && warning.items.length > 0 && (
                      <div className="mt-2 text-xs text-gray-500">
                        Examples: {warning.items.slice(0, 3).map((item: any) => 
                          item.title || item.description || item.hash || `ID: ${item.id}`
                        ).join(', ')}
                      </div>
                    )}
                    {warning.action_url && (
                      <a
                        href={warning.action_url}
                        className="mt-2 inline-block text-sm text-blue-600 hover:text-blue-800 underline"
                      >
                        Go to {warning.action_url === '/friction' ? 'Friction Logs' : 
                                warning.action_url === '/goals' ? 'Goals' : 
                                warning.action_url === '/manual-entries' ? 'Manual Entries' : 'Fix'}
                      </a>
                    )}
                  </div>
                  <span className="text-sm font-medium ml-4">{warning.count}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

