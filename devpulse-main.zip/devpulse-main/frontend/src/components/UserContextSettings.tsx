import React, { useState, useEffect } from 'react';

interface UserContext {
  user_id: string;
  role?: string;
  team?: string;
  business_domain?: string;
  company?: string;
  preferred_language: string;
}

export const UserContextSettings: React.FC = () => {
  const [context, setContext] = useState<UserContext>({
    user_id: 'default',
    preferred_language: 'en'
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    loadContext();
  }, []);

  const loadContext = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/user-context?user_id=default');
      if (response.ok) {
        const data = await response.json();
        setContext(data);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to load user context');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      setError(null);
      setSuccess(false);
      
      const response = await fetch('/api/user-context?user_id=default', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          role: context.role || null,
          team: context.team || null,
          business_domain: context.business_domain || null,
          company: context.company || null,
          preferred_language: context.preferred_language || 'en',
        }),
      });

      if (response.ok) {
        setSuccess(true);
        setTimeout(() => setSuccess(false), 3000);
      } else {
        const data = await response.json();
        setError(data.detail || 'Failed to save user context');
      }
    } catch (err: any) {
      setError(err.message || 'Failed to save user context');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="p-4">Loading settings...</div>;
  }

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">User Context Settings</h2>
      
      {error && (
        <div className="mb-4 p-3 bg-red-100 text-red-700 rounded">
          {error}
        </div>
      )}
      
      {success && (
        <div className="mb-4 p-3 bg-green-100 text-green-700 rounded">
          Settings saved successfully!
        </div>
      )}
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">Role</label>
          <input
            type="text"
            value={context.role || ''}
            onChange={(e) => setContext({ ...context, role: e.target.value })}
            placeholder="e.g., Senior Software Engineer"
            className="w-full px-3 py-2 border rounded-md"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium mb-1">Team</label>
          <input
            type="text"
            value={context.team || ''}
            onChange={(e) => setContext({ ...context, team: e.target.value })}
            placeholder="e.g., Payments Platform"
            className="w-full px-3 py-2 border rounded-md"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium mb-1">Business Domain</label>
          <input
            type="text"
            value={context.business_domain || ''}
            onChange={(e) => setContext({ ...context, business_domain: e.target.value })}
            placeholder="e.g., E-commerce, Financial Services"
            className="w-full px-3 py-2 border rounded-md"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium mb-1">Company</label>
          <input
            type="text"
            value={context.company || ''}
            onChange={(e) => setContext({ ...context, company: e.target.value })}
            placeholder="e.g., PayPal"
            className="w-full px-3 py-2 border rounded-md"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium mb-1">Preferred Language</label>
          <select
            value={context.preferred_language}
            onChange={(e) => setContext({ ...context, preferred_language: e.target.value })}
            className="w-full px-3 py-2 border rounded-md"
          >
            <option value="en">English</option>
            <option value="pt">Português</option>
          </select>
        </div>
        
        <div className="pt-4">
          <button
            onClick={handleSave}
            disabled={saving}
            className="px-6 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:opacity-50"
          >
            {saving ? 'Saving...' : 'Save Settings'}
          </button>
        </div>
      </div>
      
      <div className="mt-6 p-4 bg-gray-50 rounded">
        <p className="text-sm text-gray-600">
          <strong>Note:</strong> These settings will be used to enrich AI-generated narratives in your performance reports. 
          The context helps the AI create more relevant and specific summaries tailored to your role, team, and business domain.
        </p>
      </div>
    </div>
  );
};

