import React, { useState, useEffect } from 'react';
import { reportsApi } from '../services/api';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface ComparisonProps {
  reportIds: number[];
}

export const ReportComparison: React.FC<ComparisonProps> = ({ reportIds }) => {
  const [comparison, setComparison] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadComparison();
  }, [reportIds]);

  const loadComparison = async () => {
    try {
      const data = await reportsApi.compareReports(reportIds.join(','));
      setComparison(data);
    } catch (error) {
      console.error('Error loading comparison:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div>Loading comparison...</div>;
  }

  if (!comparison) {
    return <div>No comparison data available</div>;
  }

  // Prepare chart data
  const doraData = comparison.comparison_summary?.dora_trends?.map((trend: any) => ({
    quarter: trend.quarter,
    deployment_frequency: trend.deployment_frequency,
    lead_time: trend.lead_time_days
  })) || [];

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Report Comparison</h2>

      {/* DORA Metrics Trend */}
      {doraData.length > 0 && (
        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-4">DORA Metrics Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={doraData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="quarter" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="deployment_frequency" stroke="#8884d8" name="Deployments/Week" />
              <Line type="monotone" dataKey="lead_time" stroke="#82ca9d" name="Lead Time (days)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Improvements Summary */}
      {comparison.comparison_summary?.improvements && (
        <div className="bg-green-50 p-4 rounded-lg">
          <h3 className="text-lg font-semibold mb-2">Key Improvements</h3>
          <ul className="list-disc list-inside space-y-1">
            {comparison.comparison_summary.improvements.map((imp: any, idx: number) => (
              <li key={idx}>
                <strong>{imp.metric}:</strong> {imp.change} ({imp.trend})
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Individual Report Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {comparison.reports.map((report: any) => (
          <div key={report.id} className="bg-white p-4 rounded-lg shadow">
            <h3 className="font-semibold">{report.name}</h3>
            <p className="text-sm text-gray-600">{report.quarter}</p>
            {/* Display key metrics */}
          </div>
        ))}
      </div>
    </div>
  );
};

