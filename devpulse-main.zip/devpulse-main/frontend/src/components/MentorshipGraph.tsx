import { useState, useEffect } from 'react'
import { paypalApi } from '../services/api'

interface MenteesData {
  mentee_count: number
  mentees: string[]
  target: number
}

export function MentorshipGraph() {
  const [data, setData] = useState<MenteesData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    setLoading(true)
    try {
      const result = await paypalApi.getMentees()
      setData(result)
    } catch (error) {
      console.error('Error loading Mentees:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow">
        <div className="text-center py-4">Loading Mentorship Graph...</div>
      </div>
    )
  }

  if (!data) {
    return null
  }

  const meetsTarget = data.mentee_count >= data.target
  const colorClass = meetsTarget ? 'text-green-600' : 'text-yellow-600'
  const bgClass = meetsTarget ? 'bg-green-100' : 'bg-yellow-100'

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h3 className="text-xl font-semibold mb-4">Mentorship Graph</h3>
      
      <div className="space-y-4">
        <div className={`${bgClass} p-4 rounded-lg`}>
          <div className={`text-4xl font-bold ${colorClass} mb-2`}>
            {data.mentee_count}
          </div>
          <div className="text-sm text-gray-600">
            Distinct mentees (Target: {data.target}+)
          </div>
          {!meetsTarget && (
            <div className="mt-2 text-sm text-yellow-700 font-medium">
              ⚠️ Need to mentor at least {data.target} juniors for PayPal requirement
            </div>
          )}
        </div>

        {data.mentees.length > 0 && (
          <div>
            <h4 className="font-semibold mb-2">Mentees</h4>
            <div className="space-y-1">
              {data.mentees.map((mentee, idx) => (
                <div key={idx} className="text-sm text-gray-700 p-2 bg-gray-50 rounded">
                  {mentee}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

