import { useState, useEffect } from 'react'
import { frictionApi } from '../services/api'
import type { HealthTrendPoint } from '../types'

function HealthScoreChart() {
  const [trends, setTrends] = useState<HealthTrendPoint[]>([])
  const [summary, setSummary] = useState<{
    total_entries: number
    avg_satisfaction: number
    avg_wellbeing: number
    entries_with_blockers: number
    trend: string
  } | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      setLoading(true)
      const [trendsData, summaryData] = await Promise.all([
        frictionApi.getHealthTrends(),
        frictionApi.getSummary()
      ])
      setTrends(trendsData)
      setSummary(summaryData)
      setError(null)
    } catch (err) {
      setError('Failed to load health metrics')
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="animate-pulse">
        <div className="h-48 bg-slate-200 rounded"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="text-red-500 text-center py-4">{error}</div>
    )
  }

  if (!summary || summary.total_entries === 0) {
    return (
      <div className="text-slate-500 text-center py-8">
        <p>No health data available yet.</p>
        <p className="text-sm mt-2">Start logging your daily satisfaction and blockers.</p>
      </div>
    )
  }

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'improving':
        return '↗️'
      case 'declining':
        return '↘️'
      case 'stable':
        return '→'
      default:
        return '•'
    }
  }

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case 'improving':
        return 'text-emerald-600 bg-emerald-50'
      case 'declining':
        return 'text-rose-600 bg-rose-50'
      default:
        return 'text-slate-600 bg-slate-50'
    }
  }

  return (
    <div>
      <h3 className="text-lg font-semibold text-slate-800 mb-4">Health & Wellbeing</h3>

      {/* Summary Stats */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <div className="bg-gradient-to-br from-violet-50 to-violet-100 rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-violet-700">
            {summary.avg_satisfaction.toFixed(1)}
          </div>
          <div className="text-xs text-violet-600">Avg Satisfaction</div>
        </div>
        <div className="bg-gradient-to-br from-cyan-50 to-cyan-100 rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-cyan-700">
            {summary.avg_wellbeing.toFixed(1)}
          </div>
          <div className="text-xs text-cyan-600">Avg Wellbeing</div>
        </div>
        <div className={`rounded-lg p-3 text-center ${getTrendColor(summary.trend)}`}>
          <div className="text-2xl font-bold">
            {getTrendIcon(summary.trend)}
          </div>
          <div className="text-xs capitalize">{summary.trend}</div>
        </div>
      </div>

      {/* Trend Lines */}
      {trends.length > 0 && (
        <div className="relative h-32 mb-4">
          <svg viewBox="0 0 100 40" className="w-full h-full" preserveAspectRatio="none">
            {/* Satisfaction Line */}
            <polyline
              fill="none"
              stroke="#8b5cf6"
              strokeWidth="0.5"
              points={trends.slice(-14).map((t, i, arr) => 
                `${(i / (arr.length - 1 || 1)) * 100},${40 - (t.satisfaction_avg / 10) * 40}`
              ).join(' ')}
            />
            {/* Wellbeing Line */}
            <polyline
              fill="none"
              stroke="#06b6d4"
              strokeWidth="0.5"
              points={trends.slice(-14).map((t, i, arr) => 
                `${(i / (arr.length - 1 || 1)) * 100},${40 - (t.wellbeing_avg / 10) * 40}`
              ).join(' ')}
            />
          </svg>
          <div className="absolute bottom-0 left-0 right-0 flex justify-between text-xs text-slate-400">
            <span>{trends[0]?.date || ''}</span>
            <span>{trends[trends.length - 1]?.date || ''}</span>
          </div>
        </div>
      )}

      {/* Legend */}
      <div className="flex justify-center gap-6 text-sm">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-violet-500"></div>
          <span className="text-slate-600">Satisfaction</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-cyan-500"></div>
          <span className="text-slate-600">Wellbeing</span>
        </div>
      </div>

      <div className="mt-4 text-center text-sm text-slate-500">
        {summary.total_entries} entries • {summary.entries_with_blockers} with blockers
      </div>
    </div>
  )
}

export default HealthScoreChart

