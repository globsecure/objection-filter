import { useState, useEffect } from 'react'
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { metricsApi } from '../services/api'
import type { CommitTrend } from '../types'
import { format, parseISO } from 'date-fns'

function CommitTrendsChart() {
  const [data, setData] = useState<CommitTrend[]>([])
  const [loading, setLoading] = useState(true)
  const [groupBy, setGroupBy] = useState<'day' | 'week' | 'month'>('day')

  useEffect(() => {
    loadTrends()
  }, [groupBy])

  const loadTrends = async (): Promise<void> => {
    try {
      setLoading(true)
      const response = await metricsApi.getTrends({ group_by: groupBy })
      setData(response)
    } catch (error) {
      console.error('Error loading trends:', error)
    } finally {
      setLoading(false)
    }
  }

  const formatDate = (dateString: string): string => {
    try {
      const date = parseISO(dateString)
      if (groupBy === 'day') {
        return format(date, 'MMM dd')
      } else if (groupBy === 'week') {
        return format(date, 'MMM dd')
      } else {
        return format(date, 'MMM yyyy')
      }
    } catch {
      return dateString
    }
  }

  if (loading) {
    return <div className="text-center py-8">Loading trends...</div>
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h4 className="text-sm font-medium">Commit Trends Over Time</h4>
        <select
          value={groupBy}
          onChange={(e) => setGroupBy(e.target.value as 'day' | 'week' | 'month')}
          className="text-sm border rounded px-2 py-1"
        >
          <option value="day">By Day</option>
          <option value="week">By Week</option>
          <option value="month">By Month</option>
        </select>
      </div>
      <ResponsiveContainer width="100%" height={300}>
        <AreaChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          <XAxis
            dataKey="period"
            tickFormatter={formatDate}
            stroke="#6b7280"
            style={{ fontSize: '12px' }}
          />
          <YAxis stroke="#6b7280" style={{ fontSize: '12px' }} />
          <Tooltip
            labelFormatter={(value) => formatDate(value)}
            contentStyle={{
              backgroundColor: '#fff',
              border: '1px solid #e5e7eb',
              borderRadius: '6px',
            }}
          />
          <Legend />
          <Area
            type="monotone"
            dataKey="commit_count"
            stroke="#3b82f6"
            fill="#3b82f6"
            fillOpacity={0.6}
            name="Commits"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  )
}

export default CommitTrendsChart

