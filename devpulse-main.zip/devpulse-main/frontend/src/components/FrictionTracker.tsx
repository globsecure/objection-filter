import { useState, useEffect } from 'react'
import { format } from 'date-fns'
import { frictionApi } from '../services/api'
import type { DailyLog } from '../types'

function FrictionTracker() {
  const [logs, setLogs] = useState<DailyLog[]>([])
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  // Form state
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'))
  const [satisfaction, setSatisfaction] = useState(7)
  const [wellbeing, setWellbeing] = useState(7)
  const [blockers, setBlockers] = useState('')

  useEffect(() => {
    loadLogs()
  }, [])

  const loadLogs = async () => {
    try {
      setLoading(true)
      const data = await frictionApi.listLogs({ limit: 7 })
      setLogs(data)
    } catch (err) {
      console.error('Failed to load logs:', err)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setSuccess(null)

    try {
      setSubmitting(true)
      await frictionApi.createLog({
        date: `${date}T12:00:00`,
        satisfaction_score: satisfaction,
        wellbeing_score: wellbeing,
        blockers: blockers || undefined
      })
      
      setSuccess('Log saved successfully!')
      setBlockers('')
      loadLogs()
      
      setTimeout(() => setSuccess(null), 3000)
    } catch (err) {
      setError('Failed to save log. Please try again.')
      console.error(err)
    } finally {
      setSubmitting(false)
    }
  }

  const getScoreColor = (score: number) => {
    if (score >= 7) return 'bg-emerald-500'
    if (score >= 4) return 'bg-amber-500'
    return 'bg-rose-500'
  }

  const getScoreLabel = (score: number) => {
    if (score >= 8) return 'Great'
    if (score >= 6) return 'Good'
    if (score >= 4) return 'Okay'
    if (score >= 2) return 'Low'
    return 'Poor'
  }

  return (
    <div className="space-y-6">
      {/* Input Form */}
      <form onSubmit={handleSubmit} className="bg-gradient-to-br from-slate-50 to-slate-100 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-slate-800 mb-4">Daily Check-in</h3>

        {/* Date */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-slate-700 mb-1">Date</label>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
          />
        </div>

        {/* Satisfaction Slider */}
        <div className="mb-4">
          <div className="flex justify-between items-center mb-2">
            <label className="text-sm font-medium text-slate-700">Satisfaction</label>
            <span className={`px-2 py-0.5 rounded-full text-white text-sm ${getScoreColor(satisfaction)}`}>
              {satisfaction} - {getScoreLabel(satisfaction)}
            </span>
          </div>
          <input
            type="range"
            min="1"
            max="10"
            value={satisfaction}
            onChange={(e) => setSatisfaction(Number(e.target.value))}
            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
          />
          <div className="flex justify-between text-xs text-slate-400 mt-1">
            <span>Frustrated</span>
            <span>Neutral</span>
            <span>Satisfied</span>
          </div>
        </div>

        {/* Wellbeing Slider */}
        <div className="mb-4">
          <div className="flex justify-between items-center mb-2">
            <label className="text-sm font-medium text-slate-700">Wellbeing</label>
            <span className={`px-2 py-0.5 rounded-full text-white text-sm ${getScoreColor(wellbeing)}`}>
              {wellbeing} - {getScoreLabel(wellbeing)}
            </span>
          </div>
          <input
            type="range"
            min="1"
            max="10"
            value={wellbeing}
            onChange={(e) => setWellbeing(Number(e.target.value))}
            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-cyan-600"
          />
          <div className="flex justify-between text-xs text-slate-400 mt-1">
            <span>Stressed</span>
            <span>Balanced</span>
            <span>Energized</span>
          </div>
        </div>

        {/* Blockers */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Blockers & Challenges (optional)
          </label>
          <textarea
            value={blockers}
            onChange={(e) => setBlockers(e.target.value)}
            placeholder="e.g., Too many meetings, unclear requirements, waiting on code review..."
            rows={3}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 resize-none"
          />
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={submitting}
          className="w-full py-2.5 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {submitting ? 'Saving...' : 'Save Check-in'}
        </button>

        {/* Feedback */}
        {error && (
          <div className="mt-3 p-3 bg-rose-50 text-rose-700 rounded-lg text-sm">
            {error}
          </div>
        )}
        {success && (
          <div className="mt-3 p-3 bg-emerald-50 text-emerald-700 rounded-lg text-sm">
            {success}
          </div>
        )}
      </form>

      {/* Recent Logs */}
      <div>
        <h3 className="text-lg font-semibold text-slate-800 mb-4">Recent Check-ins</h3>
        
        {loading ? (
          <div className="animate-pulse space-y-2">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-16 bg-slate-200 rounded-lg"></div>
            ))}
          </div>
        ) : logs.length === 0 ? (
          <div className="text-slate-500 text-center py-8">
            No check-ins yet. Start tracking your daily experience!
          </div>
        ) : (
          <div className="space-y-2">
            {logs.map(log => (
              <div
                key={log.id}
                className="bg-white border border-slate-200 rounded-lg p-4 hover:border-slate-300 transition-colors"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-slate-800">
                    {format(new Date(log.date), 'EEEE, MMM d')}
                  </span>
                  <div className="flex gap-2">
                    <span className={`px-2 py-0.5 rounded-full text-white text-xs ${getScoreColor(log.satisfaction_score)}`}>
                      Sat: {log.satisfaction_score}
                    </span>
                    <span className={`px-2 py-0.5 rounded-full text-white text-xs ${getScoreColor(log.wellbeing_score)}`}>
                      Well: {log.wellbeing_score}
                    </span>
                  </div>
                </div>
                {log.blockers && (
                  <p className="text-sm text-slate-600 line-clamp-2">
                    {log.blockers}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

export default FrictionTracker

