import { useState, useEffect } from 'react'
import { format } from 'date-fns'
import { logbookApi } from '../services/api'
import type { LogbookEntry } from '../types'

function Logbook() {
  const [entries, setEntries] = useState<LogbookEntry[]>([])
  const [newEntry, setNewEntry] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadEntries()
  }, [])

  const loadEntries = async (): Promise<void> => {
    try {
      setLoading(true)
      const response = await logbookApi.list({ limit: 30 })
      setEntries(response)
    } catch (error) {
      console.error('Error loading logbook:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault()
    if (!newEntry.trim()) return

    try {
      await logbookApi.create({ content: newEntry })
      setNewEntry('')
      await loadEntries()
    } catch (error) {
      console.error('Error creating entry:', error)
      alert('Error creating logbook entry')
    }
  }

  if (loading) {
    return <div className="text-center py-4">Loading...</div>
  }

  return (
    <div>
      <form onSubmit={handleSubmit} className="mb-6">
        <textarea
          value={newEntry}
          onChange={(e) => setNewEntry(e.target.value)}
          placeholder="What did you learn or achieve today?"
          className="w-full border rounded-md p-3 mb-2"
          rows={3}
        />
        <button
          type="submit"
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          Add Entry
        </button>
      </form>

      <div className="space-y-4">
        {entries.map((entry) => (
          <div key={entry.id} className="border-l-4 border-blue-500 pl-4 py-2">
            <div className="text-sm text-gray-500 mb-1">
              {format(new Date(entry.date), 'MMM dd, yyyy')}
            </div>
            <div className="text-gray-900">{entry.content}</div>
          </div>
        ))}
        {entries.length === 0 && (
          <div className="text-center text-gray-500 py-8">
            No logbook entries yet. Add your first entry above!
          </div>
        )}
      </div>
    </div>
  )
}

export default Logbook

