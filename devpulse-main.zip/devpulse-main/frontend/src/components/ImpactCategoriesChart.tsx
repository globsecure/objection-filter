import { useState, useEffect } from 'react'
import { commitsApi } from '../services/api'
import type { Commit, ImpactCategoryDistribution } from '../types'

interface Props {
  startDate?: string
  endDate?: string
}

function ImpactCategoriesChart({ startDate, endDate }: Props) {
  const [distribution, setDistribution] = useState<ImpactCategoryDistribution | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [startDate, endDate])

  const loadData = async () => {
    try {
      setLoading(true)
      const commits = await commitsApi.list({
        start_date: startDate,
        end_date: endDate,
        limit: 500
      })
      
      // Calculate distribution from commits
      const dist: ImpactCategoryDistribution = {
        revenue_driving: 0,
        risk_reduction: 0,
        tech_debt: 0,
        unknown: 0
      }
      
      commits.forEach((commit: Commit & { impact_category?: string }) => {
        const category = commit.impact_category || 'Unknown'
        switch (category) {
          case 'Revenue':
            dist.revenue_driving++
            break
          case 'Risk':
            dist.risk_reduction++
            break
          case 'TechDebt':
            dist.tech_debt++
            break
          default:
            dist.unknown++
        }
      })
      
      setDistribution(dist)
    } catch (err) {
      console.error('Failed to load impact categories:', err)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="animate-pulse">
        <div className="h-48 bg-slate-200 rounded"></div>
      </div>
    )
  }

  if (!distribution) {
    return (
      <div className="text-slate-500 text-center py-8">
        <p>No impact data available.</p>
      </div>
    )
  }

  const total = distribution.revenue_driving + distribution.risk_reduction + distribution.tech_debt + distribution.unknown
  
  if (total === 0) {
    return (
      <div className="text-slate-500 text-center py-8">
        <p>No commits in selected period.</p>
      </div>
    )
  }

  const categories = [
    { 
      name: 'Revenue-Driving', 
      value: distribution.revenue_driving, 
      color: 'bg-emerald-500',
      bgColor: 'bg-emerald-50',
      textColor: 'text-emerald-700',
      description: 'Features & improvements'
    },
    { 
      name: 'Risk Reduction', 
      value: distribution.risk_reduction, 
      color: 'bg-amber-500',
      bgColor: 'bg-amber-50',
      textColor: 'text-amber-700',
      description: 'Bugfixes & security'
    },
    { 
      name: 'Tech Debt', 
      value: distribution.tech_debt, 
      color: 'bg-indigo-500',
      bgColor: 'bg-indigo-50',
      textColor: 'text-indigo-700',
      description: 'Refactoring & maintenance'
    },
    { 
      name: 'Other', 
      value: distribution.unknown, 
      color: 'bg-slate-400',
      bgColor: 'bg-slate-50',
      textColor: 'text-slate-600',
      description: 'Uncategorized'
    },
  ]

  // Calculate percentages for the bar
  const barSegments = categories
    .filter(c => c.value > 0)
    .map(c => ({
      ...c,
      percentage: (c.value / total) * 100
    }))

  return (
    <div>
      <h3 className="text-lg font-semibold text-slate-800 mb-4">Impact Categories</h3>

      {/* Stacked Bar */}
      <div className="h-8 flex rounded-lg overflow-hidden mb-6">
        {barSegments.map((segment, idx) => (
          <div
            key={idx}
            className={`${segment.color} transition-all duration-300 hover:opacity-80`}
            style={{ width: `${segment.percentage}%` }}
            title={`${segment.name}: ${segment.value} commits (${segment.percentage.toFixed(1)}%)`}
          />
        ))}
      </div>

      {/* Category Cards */}
      <div className="grid grid-cols-2 gap-3">
        {categories.filter(c => c.value > 0).map((category, idx) => (
          <div
            key={idx}
            className={`${category.bgColor} rounded-lg p-3`}
          >
            <div className="flex items-center gap-2 mb-1">
              <div className={`w-3 h-3 rounded-full ${category.color}`}></div>
              <span className={`font-medium ${category.textColor}`}>{category.name}</span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className={`text-2xl font-bold ${category.textColor}`}>{category.value}</span>
              <span className="text-sm text-slate-500">
                ({((category.value / total) * 100).toFixed(0)}%)
              </span>
            </div>
            <div className="text-xs text-slate-500 mt-1">{category.description}</div>
          </div>
        ))}
      </div>

      <div className="mt-4 text-center text-sm text-slate-500">
        Total: {total} commits
      </div>
    </div>
  )
}

export default ImpactCategoriesChart

