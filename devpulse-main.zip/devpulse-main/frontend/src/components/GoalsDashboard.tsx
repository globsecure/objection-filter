import React, { useEffect, useState } from 'react'
import { Goal } from '../types'
import { goalsApi } from '../services/api'

export const GoalsDashboard: React.FC = () => {
  const [goals, setGoals] = useState<Goal[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<'all' | 'active' | 'completed' | 'cancelled'>('all')

  useEffect(() => {
    loadGoals()
  }, [filter])

  const loadGoals = async () => {
    setLoading(true)
    try {
      const status = filter === 'all' ? undefined : filter
      const data = await goalsApi.list(status ? { status } : undefined)
      setGoals(data)
    } catch (error) {
      console.error('Error loading goals:', error)
    } finally {
      setLoading(false)
    }
  }

  const getProgressColor = (progress: number) => {
    if (progress >= 0.8) return 'bg-green-500'
    if (progress >= 0.5) return 'bg-yellow-500'
    return 'bg-red-500'
  }

  if (loading) return <div>Loading goals...</div>

  return (
    <div className="space-y-4">
      <div className="flex gap-2 mb-4">
        {(['all', 'active', 'completed', 'cancelled'] as const).map((status) => (
          <button
            key={status}
            onClick={() => setFilter(status)}
            className={`px-4 py-2 rounded ${
              filter === status
                ? 'bg-blue-600 text-white'
                : 'bg-gray-200 hover:bg-gray-300'
            }`}
          >
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </button>
        ))}
      </div>

      <div className="grid gap-4">
        {goals.length === 0 ? (
          <div className="text-center text-gray-500 py-8">
            No goals found. Create your first goal!
          </div>
        ) : (
          goals.map((goal) => (
            <div key={goal.id} className="p-4 border rounded bg-white">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-semibold text-lg">{goal.title}</h3>
                  {goal.description && (
                    <p className="text-gray-600 text-sm mt-1">{goal.description}</p>
                  )}
                </div>
                <span className={`px-2 py-1 rounded text-xs ${
                  goal.status === 'completed' ? 'bg-green-100 text-green-800' :
                  goal.status === 'cancelled' ? 'bg-gray-100 text-gray-800' :
                  'bg-blue-100 text-blue-800'
                }`}>
                  {goal.status}
                </span>
              </div>

              <div className="mt-3">
                <div className="flex justify-between text-sm mb-1">
                  <span>Progress</span>
                  <span>{Math.round(goal.progress * 100)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full ${getProgressColor(goal.progress)}`}
                    style={{ width: `${goal.progress * 100}%` }}
                  />
                </div>
              </div>

              {goal.target_metric && (
                <div className="mt-2 text-sm">
                  <span className="font-medium">Target: </span>
                  <span>{goal.target_metric}</span>
                </div>
              )}

              {goal.current_metric && (
                <div className="mt-1 text-sm">
                  <span className="font-medium">Current: </span>
                  <span>{goal.current_metric}</span>
                </div>
              )}

              <div className="mt-2 text-sm text-gray-500">
                Deadline: {new Date(goal.deadline).toLocaleDateString()}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}

