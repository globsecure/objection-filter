import { useState } from 'react'
import { FrictionLogger } from '../components/FrictionLogger'
import { FrictionDashboard } from '../components/FrictionDashboard'
import FrictionTracker from '../components/FrictionTracker'
import HealthScoreChart from '../components/HealthScoreChart'

function FrictionPage() {
  const [activeTab, setActiveTab] = useState<'quick' | 'dashboard' | 'health'>('quick')

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h2 className="text-3xl font-bold text-gray-900 mb-2">Friction Tracker</h2>
      <p className="text-gray-600 mb-8">
        Track friction points, daily satisfaction, and blockers to gain insights for your performance reviews.
      </p>

      {/* Tabs */}
      <div className="border-b border-gray-200 mb-6">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('quick')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'quick'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Quick Log
          </button>
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'dashboard'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setActiveTab('health')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'health'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Health Tracking
          </button>
        </nav>
      </div>

      {/* Tab Content */}
      {activeTab === 'quick' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <FrictionLogger />
          </div>
          <div>
            <FrictionDashboard />
          </div>
        </div>
      )}

      {activeTab === 'dashboard' && (
        <div>
          <FrictionDashboard />
        </div>
      )}

      {activeTab === 'health' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <FrictionTracker />
          </div>
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-lg shadow">
              <HealthScoreChart />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default FrictionPage

