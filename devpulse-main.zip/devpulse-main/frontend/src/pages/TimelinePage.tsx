import { WorkTimeline } from '../components/WorkTimeline'

function TimelinePage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h2 className="text-3xl font-bold text-gray-900 mb-2">Work Timeline</h2>
      <p className="text-gray-600 mb-8">
        Unified view of your commits, friction logs, and manual entries.
      </p>
      <WorkTimeline />
    </div>
  )
}

export default TimelinePage

