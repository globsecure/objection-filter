import { useState, useEffect } from 'react'
import { ManualEntryForm } from '../components/ManualEntryForm'
import { manualEntriesApi } from '../services/api'
import type { ManualEntry } from '../types'

function ManualEntriesPage() {
  const [entries, setEntries] = useState<ManualEntry[]>([])
  const [loading, setLoading] = useState(true)
  const [filterType, setFilterType] = useState<string>('')
  const [showForm, setShowForm] = useState(false)

  useEffect(() => {
    loadEntries()
  }, [filterType])

  const loadEntries = async () => {
    try {
      setLoading(true)
      const params = filterType ? { type: filterType } : undefined
      const data = await manualEntriesApi.list(params)
      setEntries(data)
    } catch (error) {
      console.error('Failed to load manual entries:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to delete this entry?')) {
      return
    }

    try {
      await manualEntriesApi.delete(id)
      loadEntries()
    } catch (error) {
      console.error('Failed to delete entry:', error)
      alert('Failed to delete entry. Please try again.')
    }
  }

  const getTypeIcon = (type: string) => {
    const icons: Record<string, string> = {
      code_review: '👀',
      design_doc: '📄',
      mentoring: '👥',
      incident: '🔥',
      meeting: '📅',
    }
    return icons[type] || '📝'
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    })
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Manual Entries</h2>
          <p className="text-gray-600">
            Track code reviews, design docs, mentoring, incidents, and meetings.
          </p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition-colors"
        >
          {showForm ? 'Hide Form' : '+ Add Entry'}
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <div className="mb-8">
          <ManualEntryForm />
        </div>
      )}

      {/* Filter */}
      <div className="bg-white rounded-lg shadow p-4 mb-6">
        <label className="block text-sm font-medium mb-2">Filter by Type</label>
        <select
          value={filterType}
          onChange={(e) => setFilterType(e.target.value)}
          className="w-full md:w-auto border rounded px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="">All Types</option>
          <option value="code_review">Code Reviews</option>
          <option value="design_doc">Design Docs</option>
          <option value="mentoring">Mentoring</option>
          <option value="incident">Incidents</option>
          <option value="meeting">Meetings</option>
        </select>
      </div>

      {/* Entries List */}
      {loading ? (
        <div className="animate-pulse space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-32 bg-gray-200 rounded"></div>
          ))}
        </div>
      ) : entries.length === 0 ? (
        <div className="bg-white rounded-lg shadow p-8 text-center text-gray-500">
          No manual entries found. Create your first entry!
        </div>
      ) : (
        <div className="space-y-4">
          {entries.map((entry) => (
            <div
              key={entry.id}
              className="bg-white rounded-lg shadow p-6 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4 flex-1">
                  <div className="text-3xl">{getTypeIcon(entry.type)}</div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap mb-2">
                      <h3 className="text-lg font-semibold">{entry.title}</h3>
                      <span className="text-xs px-2 py-1 bg-purple-100 text-purple-700 rounded">
                        {entry.type.replace('_', ' ')}
                      </span>
                      <span className="text-sm text-gray-500">
                        {formatDate(entry.date)}
                      </span>
                      {entry.duration_minutes && (
                        <span className="text-sm text-gray-500">
                          {entry.duration_minutes} min
                        </span>
                      )}
                    </div>
                    {entry.description && (
                      <p className="text-gray-700 mb-2">{entry.description}</p>
                    )}
                    {entry.impact && (
                      <p className="text-sm text-gray-600 mb-2">
                        <strong>Impact:</strong> {entry.impact}
                      </p>
                    )}
                    {entry.collaborators && (
                      <p className="text-sm text-gray-600 mb-2">
                        <strong>Collaborators:</strong> {entry.collaborators}
                      </p>
                    )}
                    {entry.links && (
                      <div className="mt-2">
                        {entry.links.split(',').map((link, idx) => (
                          <a
                            key={idx}
                            href={link.trim()}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue-600 hover:underline mr-3"
                          >
                            Link {idx + 1} →
                          </a>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => handleDelete(entry.id)}
                  className="text-red-600 hover:text-red-800 text-sm"
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default ManualEntriesPage

