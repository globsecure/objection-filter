import { useState, useEffect } from 'react'
import { settingsApi } from '../services/api'
import { SecuritySettings } from '../components/SecuritySettings'

interface ConfigResponse {
  projects_dir: string
  llm_provider: string
  database_url: string
  has_openai_key: boolean
  has_gemini_key: boolean
  env_file: string
  instructions: {
    file_location: string
    required_vars: string[]
    note: string
  }
}

function Settings() {
  const [config, setConfig] = useState<ConfigResponse | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    settingsApi.getConfig()
      .then(setConfig)
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center py-8">Loading configuration...</div>
      </div>
    )
  }

  if (!config) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center py-8 text-red-600">Error loading configuration</div>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h2 className="text-3xl font-bold text-gray-900 mb-6">Settings & Configuration</h2>

      {/* Current Configuration */}
      <div className="bg-white p-6 rounded-lg shadow mb-6">
        <h3 className="text-xl font-semibold mb-4">Current Configuration</h3>
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Projects Directory</label>
              <div className="text-gray-900 bg-gray-50 p-2 rounded border font-mono text-sm">
                {config.projects_dir}
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">LLM Provider</label>
              <select
                value={config.llm_provider}
                onChange={(e) => {
                  // TODO: Implement API call to update provider
                  alert('LLM provider update requires backend restart. Update LLM_PROVIDER in .env file.')
                }}
                className="w-full border rounded-md px-3 py-2 text-sm"
              >
                <option value="openai">OpenAI (GPT-4)</option>
                <option value="gemini">Google Gemini</option>
                <option value="ollama">Ollama (Local)</option>
              </select>
              {config.llm_provider === 'ollama' && (
                <div className="mt-2 text-xs text-gray-500">
                  Make sure Ollama is running on http://localhost:11434
                </div>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Database URL</label>
              <div className="text-gray-900 bg-gray-50 p-2 rounded border font-mono text-sm">
                {config.database_url}
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">API Keys Status</label>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${config.has_openai_key ? 'bg-green-500' : 'bg-gray-300'}`}></span>
                  <span className="text-sm text-gray-700">OpenAI API Key: {config.has_openai_key ? 'Configured' : 'Not Set'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${config.has_gemini_key ? 'bg-green-500' : 'bg-gray-300'}`}></span>
                  <span className="text-sm text-gray-700">Gemini API Key: {config.has_gemini_key ? 'Configured' : 'Not Set'}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Environment Variables Instructions */}
      <div className="bg-blue-50 border-l-4 border-blue-500 p-6 rounded-lg shadow mb-6">
        <h3 className="text-xl font-semibold text-blue-900 mb-4">Environment Variables</h3>
        <div className="space-y-4">
          <div>
            <p className="text-sm font-medium text-blue-800 mb-2">Configuration File Location:</p>
            <code className="block bg-blue-100 p-2 rounded text-sm text-blue-900">
              {config.instructions.file_location}
            </code>
          </div>
          
          <div>
            <p className="text-sm font-medium text-blue-800 mb-2">Required Variables:</p>
            <ul className="list-disc list-inside space-y-1 text-sm text-blue-700">
              {config.instructions.required_vars.map((varName, idx) => (
                <li key={idx} className="font-mono">{varName}</li>
              ))}
            </ul>
          </div>

          <div className="bg-white p-4 rounded border border-blue-200">
            <p className="text-sm font-medium text-blue-800 mb-2">Example .env file:</p>
            <pre className="text-xs text-gray-800 bg-gray-50 p-3 rounded overflow-x-auto">
{`PROJECTS_DIR=${config.projects_dir}
LLM_PROVIDER=${config.llm_provider}
OPENAI_API_KEY=your_openai_api_key_here
GEMINI_API_KEY=your_gemini_api_key_here
DATABASE_URL=${config.database_url}`}
            </pre>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded p-3">
            <p className="text-sm text-yellow-800">
              <strong>Note:</strong> {config.instructions.note}
            </p>
          </div>
        </div>
      </div>

      {/* Security Settings */}
      <div className="mb-6">
        <SecuritySettings />
      </div>

      {/* Quick Actions */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-xl font-semibold mb-4">Quick Actions</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
            <div>
              <p className="font-medium text-gray-900">View .env file</p>
              <p className="text-sm text-gray-600">Open the configuration file in your editor</p>
            </div>
            <button
              onClick={() => {
                const path = config.instructions.file_location
                alert(`To edit your configuration:\n\n1. Open: ${path}\n2. Update the values\n3. Restart the backend server`)
              }}
              className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 text-sm font-medium"
            >
              Show Instructions
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Settings

