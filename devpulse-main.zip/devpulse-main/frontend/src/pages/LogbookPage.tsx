import { useState, useEffect } from 'react'
import { format } from 'date-fns'
import { logbookApi } from '../services/api'
import type { LogbookEntry } from '../types'

function LogbookPage() {
  const [entries, setEntries] = useState<LogbookEntry[]>([])
  const [newEntry, setNewEntry] = useState('')
  const [loading, setLoading] = useState(true)
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [searchQuery, setSearchQuery] = useState('')

  useEffect(() => {
    loadEntries()
  }, [startDate, endDate])

  const loadEntries = async (): Promise<void> => {
    try {
      setLoading(true)
      const params: {
        start_date?: string
        end_date?: string
        limit?: number
      } = { limit: 100 }

      if (startDate) {
        params.start_date = new Date(startDate).toISOString()
      }
      if (endDate) {
        params.end_date = new Date(endDate).toISOString()
      }

      const response = await logbookApi.list(params)
      setEntries(response)
    } catch (error) {
      console.error('Error loading logbook:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault()
    if (!newEntry.trim()) return

    try {
      await logbookApi.create({ content: newEntry })
      setNewEntry('')
      await loadEntries()
    } catch (error) {
      console.error('Error creating entry:', error)
      alert('Error creating logbook entry')
    }
  }

  const filteredEntries = entries.filter((entry) =>
    entry.content.toLowerCase().includes(searchQuery.toLowerCase())
  )

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">Loading...</div>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Daily Logbook</h2>

        <div className="bg-white p-6 rounded-lg shadow mb-6">
          <form onSubmit={handleSubmit}>
            <textarea
              value={newEntry}
              onChange={(e) => setNewEntry(e.target.value)}
              placeholder="What did you learn or achieve today?"
              className="w-full border rounded-md p-3 mb-4"
              rows={4}
            />
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              Add Entry
            </button>
          </form>
        </div>

        <div className="bg-white p-6 rounded-lg shadow mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium mb-1">Start Date</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full border rounded-md px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">End Date</label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full border rounded-md px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Search</label>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search entries..."
                className="w-full border rounded-md px-3 py-2"
              />
            </div>
          </div>
          {(startDate || endDate) && (
            <button
              onClick={() => {
                setStartDate('')
                setEndDate('')
              }}
              className="text-sm text-blue-600 hover:text-blue-800"
            >
              Clear Filters
            </button>
          )}
        </div>
      </div>

      <div className="space-y-4">
        {filteredEntries.length === 0 ? (
          <div className="text-center text-gray-500 py-8 bg-white rounded-lg shadow">
            {entries.length === 0
              ? 'No logbook entries yet. Add your first entry above!'
              : 'No entries match your search criteria.'}
          </div>
        ) : (
          filteredEntries.map((entry) => (
            <div
              key={entry.id}
              className="bg-white border-l-4 border-blue-500 pl-6 py-4 rounded-lg shadow hover:shadow-md transition-shadow"
            >
              <div className="flex justify-between items-start mb-2">
                <div className="text-sm text-gray-500 font-medium">
                  {format(new Date(entry.date), 'EEEE, MMMM dd, yyyy')}
                </div>
                <div className="text-xs text-gray-400">
                  {format(new Date(entry.date), 'h:mm a')}
                </div>
              </div>
              <div className="text-gray-900 whitespace-pre-wrap">{entry.content}</div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}

export default LogbookPage

