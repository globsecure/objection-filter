import { useState } from 'react'
import { CareerMomentForm } from '../components/CareerMomentForm'
import { CareerMomentsTimeline } from '../components/CareerMomentsTimeline'

function CareerMomentsPage() {
  const [showForm, setShowForm] = useState(false)
  const [refreshKey, setRefreshKey] = useState(0)

  const handleSuccess = () => {
    setShowForm(false)
    setRefreshKey((k) => k + 1)
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Career Moments</h2>
          <p className="text-gray-600">
            Document your wins, failures, pivots, and learning moments.
          </p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition-colors"
        >
          {showForm ? 'Hide Form' : '+ Add Moment'}
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <div className="mb-8">
          <CareerMomentForm
            onSuccess={handleSuccess}
            onCancel={() => setShowForm(false)}
          />
        </div>
      )}

      {/* Timeline */}
      <div key={refreshKey}>
        <CareerMomentsTimeline />
      </div>
    </div>
  )
}

export default CareerMomentsPage

