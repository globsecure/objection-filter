import { useState, useEffect } from 'react'
import { format } from 'date-fns'
import { commitsApi, reportsApi, doraApi, spaceApi, frictionApi } from '../services/api'
import type { Commit, CommitType, DoraMetrics, SpaceMetrics, ImpactSummary, EnhancedReportResponse, Repository } from '../types'

function Review() {
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [selectedRepoId, setSelectedRepoId] = useState<number | null>(null)
  const [repositories, setRepositories] = useState<Repository[]>([])
  const [commits, setCommits] = useState<Commit[]>([])
  const [report, setReport] = useState<EnhancedReportResponse | null>(null)
  const [managerReport, setManagerReport] = useState<any>(null)
  const [preview, setPreview] = useState<any>(null)
  const [doraMetrics, setDoraMetrics] = useState<DoraMetrics | null>(null)
  const [spaceMetrics, setSpaceMetrics] = useState<SpaceMetrics | null>(null)
  const [frictionSummary, setFrictionSummary] = useState<{
    total_entries: number
    avg_satisfaction: number
    avg_wellbeing: number
    trend: string
  } | null>(null)
  const [loading, setLoading] = useState(false)
  const [generating, setGenerating] = useState(false)
  const [previewLoading, setPreviewLoading] = useState(false)
  const [reportFormat, setReportFormat] = useState<'json' | 'markdown' | 'pdf'>('json')
  const [useLLM, setUseLLM] = useState(true)
  const [redactSensitive, setRedactSensitive] = useState(false)
  const [showSaveModal, setShowSaveModal] = useState(false)
  const [saveName, setSaveName] = useState('')
  const [saveQuarter, setSaveQuarter] = useState('')
  const [saveTags, setSaveTags] = useState('')
  const [saveNotes, setSaveNotes] = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    const now = new Date()
    const sixMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 6, 1)
    setStartDate(format(sixMonthsAgo, 'yyyy-MM-dd'))
    setEndDate(format(now, 'yyyy-MM-dd'))
    
    // Load repositories
    commitsApi.listRepositories().then(setRepositories).catch(console.error)
  }, [])

  const loadData = async (): Promise<void> => {
    if (!startDate || !endDate) return

    try {
      setLoading(true)
      const params = {
        start_date: `${startDate}T00:00:00`,
        end_date: `${endDate}T23:59:59`,
        ...(selectedRepoId && { repo_id: selectedRepoId }),
      }
      
      const [commitsRes, doraRes, spaceRes, frictionRes] = await Promise.all([
        commitsApi.list({
          ...params,
          limit: 500,
        }),
        doraApi.getSummary(params).catch(() => null),
        spaceApi.getSummary(params).catch(() => null),
        frictionApi.getSummary({
          start_date: `${startDate}T00:00:00`,
          end_date: `${endDate}T23:59:59`,
        }).catch(() => null),
      ])
      
      setCommits(commitsRes)
      setDoraMetrics(doraRes)
      setSpaceMetrics(spaceRes)
      setFrictionSummary(frictionRes)
    } catch (error) {
      console.error('Error loading data:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (startDate && endDate) {
      loadData()
    }
  }, [startDate, endDate, selectedRepoId])

  const handlePreview = async (): Promise<void> => {
    if (!startDate || !endDate) {
      alert('Please select both start and end dates')
      return
    }

    try {
      setPreviewLoading(true)
      const previewData = await reportsApi.previewReport({
        start_date: `${startDate}T00:00:00`,
        end_date: `${endDate}T23:59:59`,
        repo_id: selectedRepoId || undefined,
        use_llm: useLLM,
        redact_sensitive: redactSensitive,
      })
      setPreview(previewData)
    } catch (error) {
      console.error('Error previewing report:', error)
      alert('Failed to preview report')
    } finally {
      setPreviewLoading(false)
    }
  }

  const handleGenerateReport = async (): Promise<void> => {
    if (!startDate || !endDate) {
      alert('Please select both start and end dates')
      return
    }

    try {
      setGenerating(true)
      if (reportFormat === 'pdf') {
        // Download PDF
        const blob = await reportsApi.generateReportPDF({
          start_date: `${startDate}T00:00:00`,
          end_date: `${endDate}T23:59:59`,
          repo_id: selectedRepoId || undefined,
          use_llm: useLLM,
          redact_sensitive: redactSensitive,
        })
        const repoName = selectedRepoId 
          ? repositories.find(r => r.id === selectedRepoId)?.name || 'repo'
          : 'all'
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `devpulse_report_${repoName}_${startDate}_to_${endDate}.pdf`
        a.click()
        window.URL.revokeObjectURL(url)
      } else {
        const reportData = await reportsApi.generateReport({
          start_date: `${startDate}T00:00:00`,
          end_date: `${endDate}T23:59:59`,
          repo_id: selectedRepoId || undefined,
          use_llm: useLLM,
          format: reportFormat,
          redact_sensitive: redactSensitive,
        })
        setManagerReport(reportData)
      }
    } catch (error) {
      console.error('Error generating report:', error)
      alert('Error generating report. Make sure LLM API keys are configured if using AI.')
    } finally {
      setGenerating(false)
    }
  }

  const handleGeneratePDF = async (): Promise<void> => {
    if (!startDate || !endDate) {
      alert('Please select both start and end dates')
      return
    }

    try {
      setGenerating(true)
      const blob = await reportsApi.generatePDF({
        start_date: `${startDate}T00:00:00`,
        end_date: `${endDate}T23:59:59`,
        repo_id: selectedRepoId || undefined,
      })

      const repoName = selectedRepoId 
        ? repositories.find(r => r.id === selectedRepoId)?.name || 'repo'
        : 'all'
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', `devpulse_report_${repoName}_${startDate}_to_${endDate}.pdf`)
      document.body.appendChild(link)
      link.click()
      link.remove()
      window.URL.revokeObjectURL(url)
    } catch (error) {
      console.error('Error generating PDF:', error)
      alert('Error generating PDF. Make sure LLM API keys are configured.')
    } finally {
      setGenerating(false)
    }
  }

  const commitsByType = commits.reduce((acc, commit) => {
    const type: CommitType = commit.type || 'Unknown'
    acc[type] = (acc[type] || 0) + 1
    return acc
  }, {} as Record<CommitType, number>)

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h2 className="text-3xl font-bold text-gray-900 mb-6">Performance Review</h2>

      {/* Report Configuration */}
      <div className="bg-white p-6 rounded-lg shadow mb-6">
        <h3 className="text-xl font-semibold mb-4">Report Configuration</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Repository</label>
            <select
              value={selectedRepoId || ''}
              onChange={(e) => setSelectedRepoId(e.target.value ? parseInt(e.target.value) : null)}
              className="w-full border rounded-md px-3 py-2"
            >
              <option value="">All Repositories</option>
              {repositories.map((repo) => (
                <option key={repo.id} value={repo.id}>
                  {repo.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Start Date</label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full border rounded-md px-3 py-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">End Date</label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full border rounded-md px-3 py-2"
            />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Format</label>
            <select
              value={reportFormat}
              onChange={(e) => setReportFormat(e.target.value as 'json' | 'markdown' | 'pdf')}
              className="w-full border rounded-md px-3 py-2"
            >
              <option value="json">JSON</option>
              <option value="markdown">Markdown</option>
              <option value="pdf">PDF</option>
            </select>
          </div>
          <div className="flex items-center gap-2 pt-8">
            <input
              type="checkbox"
              id="use_llm"
              checked={useLLM}
              onChange={(e) => setUseLLM(e.target.checked)}
              className="w-4 h-4"
            />
            <label htmlFor="use_llm" className="text-sm font-medium text-gray-700">
              Use AI for narrative generation
            </label>
          </div>
        </div>
        <div className="flex gap-4">
          <button
            onClick={handlePreview}
            disabled={previewLoading || !startDate || !endDate}
            className="px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {previewLoading ? 'Loading...' : 'Preview'}
          </button>
          <button
            onClick={handleGenerateReport}
            disabled={generating || !startDate || !endDate}
            className="px-6 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed font-medium"
          >
            {generating ? 'Generating...' : 'Generate Report'}
          </button>
        </div>
      </div>

      {/* Preview Section */}
      {preview && (
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <h3 className="text-xl font-semibold mb-4">Preview</h3>
          <div className="bg-gray-50 p-4 rounded text-sm overflow-auto">
            <pre className="whitespace-pre-wrap">{JSON.stringify(preview, null, 2)}</pre>
          </div>
        </div>
      )}

      {/* Manager Report Display */}
      {managerReport && reportFormat !== 'pdf' && (
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-semibold">Generated Report</h3>
            <button
              onClick={() => setShowSaveModal(true)}
              className="px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600"
            >
              Save Report
            </button>
          </div>
          {reportFormat === 'markdown' ? (
            <div className="bg-gray-50 p-4 rounded text-sm whitespace-pre-wrap overflow-auto">
              {managerReport.content}
            </div>
          ) : (
            <div className="space-y-6">
              {managerReport.report && (
                <>
                  <div>
                    <h4 className="font-bold text-lg mb-2">Executive Summary</h4>
                    <p className="text-gray-700 whitespace-pre-wrap">{managerReport.report.executive_summary}</p>
                  </div>
                  <div>
                    <h4 className="font-bold text-lg mb-2">Key Achievements</h4>
                    <ul className="list-disc list-inside space-y-1">
                      {managerReport.report.key_achievements?.map((a: string, i: number) => (
                        <li key={i} className="text-gray-700">{a}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-bold text-lg mb-2">Challenges & Growth</h4>
                    <div className="text-gray-700 whitespace-pre-wrap">{managerReport.report.challenges_and_growth}</div>
                  </div>
                  <div>
                    <h4 className="font-bold text-lg mb-2">Collaboration Highlights</h4>
                    <div className="text-gray-700 whitespace-pre-wrap">{managerReport.report.collaboration_highlights}</div>
                  </div>
                  {managerReport.report.metrics_snapshot && (
                    <div>
                      <h4 className="font-bold text-lg mb-2">Metrics Snapshot</h4>
                      <div className="bg-gray-50 p-4 rounded">
                        <pre className="text-sm">{JSON.stringify(managerReport.report.metrics_snapshot, null, 2)}</pre>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          )}
        </div>
      )}

      {loading ? (
        <div className="text-center py-8">Loading metrics...</div>
      ) : (
        <>
          {/* DORA Metrics Section */}
          <div className="bg-gradient-to-r from-indigo-50 to-indigo-100 p-6 rounded-lg shadow mb-6">
            <h3 className="text-xl font-semibold text-indigo-900 mb-4">DORA Metrics</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white rounded-lg p-4 text-center">
                <div className="text-sm text-gray-500">Avg Cycle Time</div>
                <div className="text-2xl font-bold text-indigo-700">
                  {doraMetrics?.lead_time?.average_days?.toFixed(1) || '—'} days
                </div>
              </div>
              <div className="bg-white rounded-lg p-4 text-center">
                <div className="text-sm text-gray-500">Median Cycle Time</div>
                <div className="text-2xl font-bold text-indigo-700">
                  {doraMetrics?.lead_time?.median_days?.toFixed(1) || '—'} days
                </div>
              </div>
              <div className="bg-white rounded-lg p-4 text-center">
                <div className="text-sm text-gray-500">Deployments/Week</div>
                <div className="text-2xl font-bold text-indigo-700">
                  {doraMetrics?.deployment_frequency?.frequency_per_week?.toFixed(1) || '—'}
                </div>
              </div>
              <div className="bg-white rounded-lg p-4 text-center">
                <div className="text-sm text-gray-500">Total Branches</div>
                <div className="text-2xl font-bold text-indigo-700">
                  {doraMetrics?.lead_time?.total_branches || '—'}
                </div>
              </div>
            </div>
          </div>

          {/* SPACE Metrics Section */}
          <div className="bg-gradient-to-r from-emerald-50 to-emerald-100 p-6 rounded-lg shadow mb-6">
            <h3 className="text-xl font-semibold text-emerald-900 mb-4">SPACE Metrics</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white rounded-lg p-4 text-center">
                <div className="text-sm text-gray-500">Flow Score</div>
                <div className="text-2xl font-bold text-emerald-700">
                  {spaceMetrics?.efficiency?.score?.toFixed(0) || '—'}
                </div>
              </div>
              <div className="bg-white rounded-lg p-4 text-center">
                <div className="text-sm text-gray-500">Deep Work Hours</div>
                <div className="text-2xl font-bold text-emerald-700">
                  {spaceMetrics?.efficiency?.deep_work_hours?.toFixed(1) || '—'}h
                </div>
              </div>
              <div className="bg-white rounded-lg p-4 text-center">
                <div className="text-sm text-gray-500">Fragmentation</div>
                <div className="text-2xl font-bold text-emerald-700">
                  {spaceMetrics?.efficiency?.fragmentation_score 
                    ? `${(spaceMetrics.efficiency.fragmentation_score * 100).toFixed(0)}%` 
                    : '—'}
                </div>
              </div>
              <div className="bg-white rounded-lg p-4 text-center">
                <div className="text-sm text-gray-500">Peak Hours</div>
                <div className="text-lg font-bold text-emerald-700">
                  {spaceMetrics?.efficiency?.optimal_hours?.slice(0, 2).map(h => `${h}:00`).join(', ') || '—'}
                </div>
              </div>
            </div>
          </div>

          {/* Health & Wellbeing Section */}
          {frictionSummary && frictionSummary.total_entries > 0 && (
            <div className="bg-gradient-to-r from-violet-50 to-violet-100 p-6 rounded-lg shadow mb-6">
              <h3 className="text-xl font-semibold text-violet-900 mb-4">Health & Wellbeing</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-white rounded-lg p-4 text-center">
                  <div className="text-sm text-gray-500">Avg Satisfaction</div>
                  <div className="text-2xl font-bold text-violet-700">
                    {frictionSummary.avg_satisfaction.toFixed(1)}/10
                  </div>
                </div>
                <div className="bg-white rounded-lg p-4 text-center">
                  <div className="text-sm text-gray-500">Avg Wellbeing</div>
                  <div className="text-2xl font-bold text-violet-700">
                    {frictionSummary.avg_wellbeing.toFixed(1)}/10
                  </div>
                </div>
                <div className="bg-white rounded-lg p-4 text-center">
                  <div className="text-sm text-gray-500">Trend</div>
                  <div className={`text-2xl font-bold ${
                    frictionSummary.trend === 'improving' ? 'text-emerald-600' :
                    frictionSummary.trend === 'declining' ? 'text-rose-600' : 'text-gray-600'
                  }`}>
                    {frictionSummary.trend === 'improving' ? '↗ Improving' :
                     frictionSummary.trend === 'declining' ? '↘ Declining' : '→ Stable'}
                  </div>
                </div>
                <div className="bg-white rounded-lg p-4 text-center">
                  <div className="text-sm text-gray-500">Check-ins</div>
                  <div className="text-2xl font-bold text-violet-700">
                    {frictionSummary.total_entries}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Commits Preview */}
          <div className="bg-white p-6 rounded-lg shadow mb-6">
            <h3 className="text-xl font-semibold mb-4">Commit Summary</h3>
            <div className="mb-4">
              <p className="text-gray-600">
                Found <strong>{commits.length}</strong> commits in selected period
              </p>
              <div className="mt-2 flex gap-2 flex-wrap">
                {Object.entries(commitsByType).map(([type, count]) => (
                  <span key={type} className="px-3 py-1 bg-gray-100 rounded-full text-sm">
                    {type}: {count}
                  </span>
                ))}
              </div>
            </div>
            <div className="max-h-64 overflow-y-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Date</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Type</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Message</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {commits.slice(0, 15).map((commit) => (
                    <tr key={commit.id}>
                      <td className="px-4 py-2 text-sm text-gray-500">
                        {format(new Date(commit.date), 'MMM dd, yyyy')}
                      </td>
                      <td className="px-4 py-2 text-sm">{commit.type || 'Unknown'}</td>
                      <td className="px-4 py-2 text-sm text-gray-900">
                        {commit.message.substring(0, 60)}
                        {commit.message.length > 60 ? '...' : ''}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Impact Categories (if report generated) */}
          {report?.impact_summary && (
            <div className="bg-white p-6 rounded-lg shadow mb-6">
              <h3 className="text-xl font-semibold mb-4">Impact Categories</h3>
              <div className="grid grid-cols-4 gap-4">
                <div className="bg-emerald-50 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-emerald-700">
                    {report.impact_summary.distribution.revenue_driving}
                  </div>
                  <div className="text-sm text-emerald-600">Revenue-Driving</div>
                  <div className="text-xs text-gray-500">
                    {report.impact_summary.percentages.revenue_driving}%
                  </div>
                </div>
                <div className="bg-amber-50 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-amber-700">
                    {report.impact_summary.distribution.risk_reduction}
                  </div>
                  <div className="text-sm text-amber-600">Risk Reduction</div>
                  <div className="text-xs text-gray-500">
                    {report.impact_summary.percentages.risk_reduction}%
                  </div>
                </div>
                <div className="bg-indigo-50 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-indigo-700">
                    {report.impact_summary.distribution.tech_debt}
                  </div>
                  <div className="text-sm text-indigo-600">Tech Debt</div>
                  <div className="text-xs text-gray-500">
                    {report.impact_summary.percentages.tech_debt}%
                  </div>
                </div>
                <div className="bg-gray-50 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-gray-700">
                    {report.impact_summary.distribution.unknown}
                  </div>
                  <div className="text-sm text-gray-600">Other</div>
                  <div className="text-xs text-gray-500">
                    {report.impact_summary.percentages.unknown}%
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* AI Summary */}
          <div className="bg-white p-6 rounded-lg shadow mb-6">
            <h3 className="text-xl font-semibold mb-4">AI-Generated Summary</h3>
            {report ? (
              <div className="space-y-6">
                {report.weekly_summary && (
                  <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Manager Review Summary</h4>
                    <div className="whitespace-pre-wrap text-gray-700">{report.weekly_summary}</div>
                  </div>
                )}
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">Detailed Achievements</h4>
                  <div className="whitespace-pre-wrap text-gray-700">{report.summary}</div>
                </div>
              </div>
            ) : (
              <div className="text-gray-500">
                Click "Generate Manager Report" to create an AI-powered summary of your achievements with DORA and SPACE metrics insights.
              </div>
            )}
          </div>

        </>
      )}

      {/* Save Report Modal */}
      {showSaveModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <h3 className="text-xl font-semibold mb-4">Save Report</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Report Name *</label>
                <input
                  type="text"
                  value={saveName}
                  onChange={(e) => setSaveName(e.target.value)}
                  placeholder="e.g., Q1 2025 Performance Review"
                  className="w-full border rounded-md px-3 py-2"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Quarter</label>
                <input
                  type="text"
                  value={saveQuarter}
                  onChange={(e) => setSaveQuarter(e.target.value)}
                  placeholder="e.g., Q1-2025"
                  className="w-full border rounded-md px-3 py-2"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tags (comma-separated)</label>
                <input
                  type="text"
                  value={saveTags}
                  onChange={(e) => setSaveTags(e.target.value)}
                  placeholder="e.g., performance, review, q1"
                  className="w-full border rounded-md px-3 py-2"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
                <textarea
                  value={saveNotes}
                  onChange={(e) => setSaveNotes(e.target.value)}
                  placeholder="Optional notes about this report"
                  className="w-full border rounded-md px-3 py-2"
                  rows={3}
                />
              </div>
            </div>
            <div className="flex gap-2 mt-6">
              <button
                onClick={async () => {
                  if (!saveName.trim()) {
                    alert('Please enter a report name');
                    return;
                  }
                  try {
                    setSaving(true);
                    const request = {
                      start_date: `${startDate}T00:00:00`,
                      end_date: `${endDate}T23:59:59`,
                      repo_id: selectedRepoId || undefined,
                      use_llm: useLLM,
                    };
                    await reportsApi.saveReport(
                      request,
                      saveName,
                      saveQuarter || undefined,
                      saveTags || undefined,
                      saveNotes || undefined
                    );
                    setShowSaveModal(false);
                    setSaveName('');
                    setSaveQuarter('');
                    setSaveTags('');
                    setSaveNotes('');
                    alert('Report saved successfully!');
                  } catch (error) {
                    console.error('Error saving report:', error);
                    alert('Error saving report. Please try again.');
                  } finally {
                    setSaving(false);
                  }
                }}
                disabled={saving}
                className="flex-1 px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 disabled:opacity-50"
              >
                {saving ? 'Saving...' : 'Save'}
              </button>
              <button
                onClick={() => {
                  setShowSaveModal(false);
                  setSaveName('');
                  setSaveQuarter('');
                  setSaveTags('');
                  setSaveNotes('');
                }}
                className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Review
