import React, { useState } from 'react'
import { ComparisonDashboard } from '../components/ComparisonDashboard'
import { PercentileRanking } from '../components/PercentileRanking'
import { HistoricalComparison } from '../components/HistoricalComparison'
import { SnapshotCreator } from '../components/SnapshotCreator'
import { TeamBenchmarkForm } from '../components/TeamBenchmarkForm'

export const ComparisonPage: React.FC = () => {
  const [startDate, setStartDate] = useState(
    new Date(new Date().getFullYear(), 0, 1).toISOString().split('T')[0]
  )
  const [endDate, setEndDate] = useState(
    new Date().toISOString().split('T')[0]
  )
  const [activeTab, setActiveTab] = useState<
    'compare' | 'percentile' | 'historical' | 'import'
  >('compare')

  return (
    <div className='container mx-auto p-6 space-y-6'>
      <h1 className='text-3xl font-bold'>Comparison & Benchmarks</h1>

      <div className='flex gap-2 mb-4'>
        <input
          type='date'
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
          className='px-3 py-2 border rounded'
        />
        <input
          type='date'
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
          className='px-3 py-2 border rounded'
        />
      </div>

      <div className='flex gap-2 mb-4'>
        {(['compare', 'percentile', 'historical', 'import'] as const).map(
          (tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded ${
                activeTab === tab ? 'bg-blue-600 text-white' : 'bg-gray-200'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          )
        )}
      </div>

      {activeTab === 'compare' && (
        <ComparisonDashboard startDate={startDate} endDate={endDate} />
      )}

      {activeTab === 'percentile' && (
        <PercentileRanking startDate={startDate} endDate={endDate} />
      )}

      {activeTab === 'historical' && (
        <div className='space-y-4'>
          <SnapshotCreator />
          <HistoricalComparison periods={['Q1-2024', 'Q2-2024', 'Q3-2024']} />
        </div>
      )}

      {activeTab === 'import' && <TeamBenchmarkForm />}
    </div>
  )
}

