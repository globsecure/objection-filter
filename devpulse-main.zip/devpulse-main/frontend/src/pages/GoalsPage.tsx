import { useState } from 'react'
import { GoalForm } from '../components/GoalForm'
import { GoalsDashboard } from '../components/GoalsDashboard'

function GoalsPage() {
  const [showForm, setShowForm] = useState(false)
  const [refreshKey, setRefreshKey] = useState(0)

  const handleSuccess = () => {
    setShowForm(false)
    setRefreshKey((k) => k + 1)
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Goals & OKRs</h2>
          <p className="text-gray-600">
            Track your goals and link them to your work.
          </p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition-colors"
        >
          {showForm ? 'Hide Form' : '+ Add Goal'}
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <div className="mb-8">
          <GoalForm
            onSuccess={handleSuccess}
            onCancel={() => setShowForm(false)}
          />
        </div>
      )}

      {/* Dashboard */}
      <div key={refreshKey}>
        <GoalsDashboard />
      </div>
    </div>
  )
}

export default GoalsPage

