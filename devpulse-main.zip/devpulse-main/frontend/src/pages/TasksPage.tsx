import { useState, useEffect } from 'react'
import { format } from 'date-fns'
import { tasksApi } from '../services/api'
import type { Task, TaskStatus, TaskPriority, TaskPlatform } from '../types'

function TasksPage() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editingTask, setEditingTask] = useState<Task | null>(null)
  const [filters, setFilters] = useState<{
    status?: TaskStatus
    priority?: TaskPriority
    platform?: TaskPlatform
  }>({})

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    status: 'todo' as TaskStatus,
    priority: 'medium' as TaskPriority,
    platform: 'manual' as TaskPlatform,
    due_date: '',
  })

  useEffect(() => {
    loadTasks()
  }, [filters])

  const loadTasks = async (): Promise<void> => {
    try {
      setLoading(true)
      const response = await tasksApi.list(filters)
      setTasks(response)
    } catch (error) {
      console.error('Error loading tasks:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault()
    try {
      if (editingTask) {
        await tasksApi.update(editingTask.id, formData)
      } else {
        await tasksApi.create(formData)
      }
      resetForm()
      await loadTasks()
    } catch (error) {
      console.error('Error saving task:', error)
      alert('Error saving task')
    }
  }

  const handleEdit = (task: Task): void => {
    setEditingTask(task)
    setFormData({
      title: task.title,
      description: task.description || '',
      status: task.status,
      priority: task.priority,
      platform: task.platform,
      due_date: task.due_date ? task.due_date.split('T')[0] : '',
    })
    setShowForm(true)
  }

  const handleDelete = async (id: number): Promise<void> => {
    if (!confirm('Are you sure you want to delete this task?')) return
    try {
      await tasksApi.delete(id)
      await loadTasks()
    } catch (error) {
      console.error('Error deleting task:', error)
      alert('Error deleting task')
    }
  }

  const handleStatusChange = async (task: Task, newStatus: TaskStatus): Promise<void> => {
    try {
      await tasksApi.update(task.id, { status: newStatus })
      await loadTasks()
    } catch (error) {
      console.error('Error updating task status:', error)
    }
  }

  const resetForm = (): void => {
    setFormData({
      title: '',
      description: '',
      status: 'todo',
      priority: 'medium',
      platform: 'manual',
      due_date: '',
    })
    setEditingTask(null)
    setShowForm(false)
  }

  const getStatusColor = (status: TaskStatus): string => {
    switch (status) {
      case 'todo':
        return 'bg-gray-100 text-gray-800'
      case 'in-progress':
        return 'bg-blue-100 text-blue-800'
      case 'done':
        return 'bg-green-100 text-green-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const getPriorityColor = (priority: TaskPriority): string => {
    switch (priority) {
      case 'low':
        return 'bg-green-100 text-green-800'
      case 'medium':
        return 'bg-yellow-100 text-yellow-800'
      case 'high':
        return 'bg-red-100 text-red-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">Loading...</div>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6 flex justify-between items-center">
        <h2 className="text-3xl font-bold text-gray-900">Tasks</h2>
        <button
          onClick={() => setShowForm(true)}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          Add Task
        </button>
      </div>

      <div className="mb-6 flex gap-4">
        <select
          value={filters.status || ''}
          onChange={(e) =>
            setFilters({ ...filters, status: e.target.value as TaskStatus || undefined })
          }
          className="border rounded-md px-3 py-2"
        >
          <option value="">All Statuses</option>
          <option value="todo">Todo</option>
          <option value="in-progress">In Progress</option>
          <option value="done">Done</option>
        </select>

        <select
          value={filters.priority || ''}
          onChange={(e) =>
            setFilters({ ...filters, priority: e.target.value as TaskPriority || undefined })
          }
          className="border rounded-md px-3 py-2"
        >
          <option value="">All Priorities</option>
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </select>

        <select
          value={filters.platform || ''}
          onChange={(e) =>
            setFilters({ ...filters, platform: e.target.value as TaskPlatform || undefined })
          }
          className="border rounded-md px-3 py-2"
        >
          <option value="">All Platforms</option>
          <option value="manual">Manual</option>
          <option value="jira">Jira</option>
          <option value="other">Other</option>
        </select>
      </div>

      {showForm && (
        <div className="bg-white p-6 rounded-lg shadow mb-6">
          <h3 className="text-xl font-semibold mb-4">
            {editingTask ? 'Edit Task' : 'New Task'}
          </h3>
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label className="block text-sm font-medium mb-1">Title</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full border rounded-md px-3 py-2"
                required
              />
            </div>
            <div className="mb-4">
              <label className="block text-sm font-medium mb-1">Description</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full border rounded-md px-3 py-2"
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-1">Status</label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value as TaskStatus })}
                  className="w-full border rounded-md px-3 py-2"
                >
                  <option value="todo">Todo</option>
                  <option value="in-progress">In Progress</option>
                  <option value="done">Done</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Priority</label>
                <select
                  value={formData.priority}
                  onChange={(e) => setFormData({ ...formData, priority: e.target.value as TaskPriority })}
                  className="w-full border rounded-md px-3 py-2"
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-1">Platform</label>
                <select
                  value={formData.platform}
                  onChange={(e) => setFormData({ ...formData, platform: e.target.value as TaskPlatform })}
                  className="w-full border rounded-md px-3 py-2"
                >
                  <option value="manual">Manual</option>
                  <option value="jira">Jira</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Due Date</label>
                <input
                  type="date"
                  value={formData.due_date}
                  onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
                  className="w-full border rounded-md px-3 py-2"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                {editingTask ? 'Update' : 'Create'}
              </button>
              <button
                type="button"
                onClick={resetForm}
                className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {tasks.map((task) => (
          <div key={task.id} className="bg-white p-6 rounded-lg shadow">
            <div className="flex justify-between items-start mb-2">
              <h3 className="text-lg font-semibold text-gray-900">{task.title}</h3>
              <div className="flex gap-1">
                <button
                  onClick={() => handleEdit(task)}
                  className="text-blue-600 hover:text-blue-800 text-sm"
                >
                  Edit
                </button>
                <button
                  onClick={() => handleDelete(task.id)}
                  className="text-red-600 hover:text-red-800 text-sm"
                >
                  Delete
                </button>
              </div>
            </div>
            {task.description && (
              <p className="text-gray-600 text-sm mb-3">{task.description}</p>
            )}
            <div className="flex flex-wrap gap-2 mb-3">
              <span className={`px-2 py-1 rounded text-xs font-medium ${getStatusColor(task.status)}`}>
                {task.status}
              </span>
              <span className={`px-2 py-1 rounded text-xs font-medium ${getPriorityColor(task.priority)}`}>
                {task.priority}
              </span>
              <span className="px-2 py-1 rounded text-xs font-medium bg-gray-100 text-gray-800">
                {task.platform}
              </span>
            </div>
            {task.due_date && (
              <div className="text-sm text-gray-500 mb-3">
                Due: {format(new Date(task.due_date), 'MMM dd, yyyy')}
              </div>
            )}
            <div className="flex gap-2">
              {(['todo', 'in-progress', 'done'] as TaskStatus[]).map((status) => (
                <button
                  key={status}
                  onClick={() => handleStatusChange(task, status)}
                  disabled={task.status === status}
                  className={`px-2 py-1 text-xs rounded ${
                    task.status === status
                      ? getStatusColor(status) + ' cursor-default'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      {tasks.length === 0 && (
        <div className="text-center text-gray-500 py-8">
          No tasks found. Create your first task above!
        </div>
      )}
    </div>
  )
}

export default TasksPage

