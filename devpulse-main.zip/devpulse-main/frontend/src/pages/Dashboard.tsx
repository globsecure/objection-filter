import { useState, useEffect } from 'react'
import { RemindersPanel } from '../components/RemindersPanel'
import { DataQualityDashboard } from '../components/DataQualityDashboard'
import { commitsApi, spaceApi } from '../services/api'
import CommitList from '../components/CommitList'
import MetricsDashboard from '../components/MetricsDashboard'
import ProductivityHeatmap from '../components/ProductivityHeatmap'
import CommitTrendsChart from '../components/CommitTrendsChart'
import CommitTypesChart from '../components/CommitTypesChart'
import RepositoryComparisonChart from '../components/RepositoryComparisonChart'
import CycleTimeChart from '../components/CycleTimeChart'
import FocusTimeChart from '../components/FocusTimeChart'
import HealthScoreChart from '../components/HealthScoreChart'
import ImpactCategoriesChart from '../components/ImpactCategoriesChart'
import { WorkingHoursHeatmap } from '../components/WorkingHoursHeatmap'
import type { Commit, Repository, DashboardStats, FlowScore } from '../types'

function Dashboard() {
  const [repositories, setRepositories] = useState<Repository[]>([])
  const [commits, setCommits] = useState<Commit[]>([])
  const [loading, setLoading] = useState(true)
  const [crawling, setCrawling] = useState(false)
  const [flowScore, setFlowScore] = useState<FlowScore | null>(null)
  const [stats, setStats] = useState<DashboardStats>({
    totalCommits: 0,
    thisWeek: 0,
    thisMonth: 0,
    repos: 0,
  })

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async (): Promise<void> => {
    try {
      setLoading(true)
      const [reposRes, commitsRes] = await Promise.all([
        commitsApi.listRepositories(),
        commitsApi.list({ limit: 100 }),
      ])

      setRepositories(reposRes)
      setCommits(commitsRes)

      const now = new Date()
      const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
      const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)

      const thisWeek = commitsRes.filter((c) => new Date(c.date) >= weekAgo).length
      const thisMonth = commitsRes.filter((c) => new Date(c.date) >= monthAgo).length

      setStats({
        totalCommits: commitsRes.length,
        thisWeek,
        thisMonth,
        repos: reposRes.length,
      })

      // Load flow score
      try {
        const flowData = await spaceApi.getFlowScore()
        setFlowScore(flowData)
      } catch (err) {
        console.log('Flow score not available:', err)
      }
    } catch (error) {
      console.error('Error loading data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleCrawl = async (): Promise<void> => {
    try {
      setCrawling(true)
      await commitsApi.crawl({ months_back: 3 })
      await loadData()
    } catch (error) {
      console.error('Error crawling:', error)
      alert('Error crawling repositories. Check console for details.')
    } finally {
      setCrawling(false)
    }
  }

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">Loading...</div>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6 flex justify-between items-center">
        <h2 className="text-3xl font-bold text-gray-900">Dashboard</h2>
        <button
          onClick={handleCrawl}
          disabled={crawling}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
        >
          {crawling ? 'Crawling...' : 'Scan Repositories'}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="text-sm text-gray-500">Total Commits</div>
          <div className="text-3xl font-bold text-gray-900">{stats.totalCommits}</div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="text-sm text-gray-500">This Week</div>
          <div className="text-3xl font-bold text-gray-900">{stats.thisWeek}</div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="text-sm text-gray-500">This Month</div>
          <div className="text-3xl font-bold text-gray-900">{stats.thisMonth}</div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="text-sm text-gray-500">Repositories</div>
          <div className="text-3xl font-bold text-gray-900">{stats.repos}</div>
        </div>
        <div className={`p-6 rounded-lg shadow ${
          flowScore && flowScore.score >= 70 
            ? 'bg-gradient-to-br from-emerald-50 to-emerald-100' 
            : flowScore && flowScore.score >= 40
            ? 'bg-gradient-to-br from-amber-50 to-amber-100'
            : 'bg-gradient-to-br from-slate-50 to-slate-100'
        }`}>
          <div className="text-sm text-gray-500">Flow Score</div>
          <div className={`text-3xl font-bold ${
            flowScore && flowScore.score >= 70 
              ? 'text-emerald-700' 
              : flowScore && flowScore.score >= 40
              ? 'text-amber-700'
              : 'text-slate-700'
          }`}>
            {flowScore ? flowScore.score.toFixed(0) : '—'}
          </div>
        </div>
      </div>

      {/* Data Quality & Reminders */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-2">
          <DataQualityDashboard />
        </div>
        <div>
          <RemindersPanel />
        </div>
      </div>

      {/* DORA & SPACE Metrics Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow">
          <CycleTimeChart />
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <FocusTimeChart />
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <HealthScoreChart />
        </div>
      </div>

      {/* Productivity Heatmap - Full Width */}
      <div className="bg-white p-6 rounded-lg shadow mb-8">
        <h3 className="text-xl font-semibold mb-4">Productivity Heatmap</h3>
        <ProductivityHeatmap commits={commits} />
      </div>

      {/* Working Hours Heatmap */}
      <div className="bg-white p-6 rounded-lg shadow mb-8">
        <WorkingHoursHeatmap />
      </div>

      {/* Impact Categories */}
      <div className="bg-white p-6 rounded-lg shadow mb-8">
        <ImpactCategoriesChart />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-xl font-semibold mb-4">Code Churn & Consistency</h3>
          <MetricsDashboard />
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <CommitTrendsChart />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow">
          <CommitTypesChart />
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <RepositoryComparisonChart />
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-xl font-semibold mb-4">Recent Commits</h3>
        <CommitList commits={commits} />
      </div>
    </div>
  )
}

export default Dashboard

