import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { SavedReportsList } from '../components/SavedReportsList';
import { ReportComparison } from '../components/ReportComparison';

export const SavedReportsPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [selectedReportIds, setSelectedReportIds] = useState<number[]>([]);

  useEffect(() => {
    const compareParam = searchParams.get('compare');
    if (compareParam) {
      const ids = compareParam.split(',').map(id => parseInt(id, 10)).filter(id => !isNaN(id));
      if (ids.length >= 2) {
        setSelectedReportIds(ids);
      }
    }
  }, [searchParams]);

  if (selectedReportIds.length >= 2) {
    return (
      <div className="p-6">
        <button
          onClick={() => {
            setSelectedReportIds([]);
            setSearchParams({});
          }}
          className="mb-4 px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded"
        >
          ← Back to List
        </button>
        <ReportComparison reportIds={selectedReportIds} />
      </div>
    );
  }

  return (
    <div className="p-6">
      <SavedReportsList onCompare={(ids) => setSelectedReportIds(ids)} />
    </div>
  );
};

