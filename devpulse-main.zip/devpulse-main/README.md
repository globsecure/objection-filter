# DevPulse - Personal Performance Intelligence

A local dashboard for developers to automate the collection of productivity evidence and generate performance reports.

## Features

- **Git Repository Scanner**: Automatically scans local directories for git repositories and extracts commit data
- **Commit Categorization**: Automatically categorizes commits (Feature, Bugfix, Refactor, Documentation, Chore)
- **Metrics Dashboard**: Tracks code churn, delivery consistency, and cross-team impact
- **Productivity Heatmap**: Visualize commit frequency over time
- **AI-Powered Reports**: Generate performance summaries using OpenAI, Google Gemini, or Ollama (local)
- **Context-Enriched Narratives**: AI-generated narratives include your role, team, business domain, and quarter goals
- **Template Customization**: Choose from different report templates (1:1 meetings vs performance reviews) or create custom templates
- **Human-in-the-Loop Editing**: Edit AI-generated sections before export with version tracking
- **Multi-Language Support**: Generate reports in English or Portuguese
- **Security & Privacy**: Secret detection, data redaction, and local LLM support for maximum privacy
- **Data Quality Dashboard**: Track data completeness, receive smart reminders, and validation warnings
- **PDF Export**: Generate professional PDF reports for performance reviews
- **Daily Logbook**: Track daily learnings and achievements

## Tech Stack

- **Backend**: FastAPI (Python) with Domain-Driven Design (DDD) architecture
- **Database**: SQLite
- **Frontend**: React + TypeScript + Vite + Tailwind CSS
- **Visualization**: Recharts
- **AI**: OpenAI / Google Gemini / Ollama (local) (configurable)

## Architecture

### Backend (DDD)
The backend follows Domain-Driven Design principles:

- **Domain Layer**: Core business logic, entities, value objects, domain services
- **Application Layer**: Use cases, DTOs, interfaces (ports)
- **Infrastructure Layer**: Repositories (adapters), external services, API layer

### Frontend (TypeScript)
- Fully typed with TypeScript
- Component-based React architecture
- Type-safe API client
- Modern React patterns (hooks, functional components)

## Quick Start

The easiest way to get started is using the Makefile:

```bash
# Setup everything (creates venv, installs dependencies)
make setup

# Run both backend and frontend servers
make run

# Or run them separately
make run-backend    # Backend only
make run-frontend   # Frontend only
```

See all available commands:
```bash
make help
```

## Manual Setup

### Backend

1. Navigate to the backend directory:
```bash
cd backend
```

2. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Create a `.env` file in the `backend` directory:
```env
PROJECTS_DIR=/path/to/your/projects
LLM_PROVIDER=openai  # Options: openai, gemini, ollama
OPENAI_API_KEY=your_api_key_here
GEMINI_API_KEY=your_gemini_key_here  # Optional
OLLAMA_BASE_URL=http://localhost:11434  # Optional, for local LLM
OLLAMA_MODEL=llama2  # Optional, for local LLM
DATABASE_URL=sqlite:///./devpulse.db
```

5. Run the backend server:
```bash
uvicorn app.main:app --reload
```

The API will be available at `http://localhost:8000`

### Frontend

1. Navigate to the frontend directory:
```bash
cd frontend
```

2. Install dependencies:
```bash
npm install
```

3. Run the development server:
```bash
npm run dev
```

The frontend will be available at `http://localhost:5173`

## Usage

1. Start both backend and frontend servers
2. Open the frontend in your browser
3. Click "Scan Repositories" to crawl your local git repositories
4. View your commits, metrics, and productivity heatmap on the Dashboard
5. Use Review Mode to generate performance reports for specific date ranges

## API Endpoints

### Commits
- `POST /api/crawl` - Scan directories and extract commits
- `GET /api/commits` - List commits with filters
- `GET /api/repositories` - List discovered repositories

### Metrics
- `GET /api/metrics/churn` - Code churn over time
- `GET /api/metrics/consistency` - Delivery consistency metrics
- `GET /api/metrics/cross-team` - Cross-team impact commits

### Reports
- `POST /api/reports/generate` - Generate AI summary (supports redaction, templates, language)
- `POST /api/reports/pdf` - Generate PDF report
- `POST /api/reports/{id}/edit` - Edit a report section
- `GET /api/reports/{id}/versions` - Get original vs edited comparison
- `GET /api/report-templates` - List report templates
- `POST /api/report-templates` - Create custom template

### User Context
- `GET /api/user-context` - Get user context (role, team, domain, language)
- `PUT /api/user-context` - Update user context

### Security
- `POST /api/security/check-secrets` - Check text for secrets and get redacted version

### Data Quality
- `GET /api/data-quality/completeness` - Get data completeness score
- `GET /api/data-quality/reminders` - Get smart reminders
- `GET /api/data-quality/warnings` - Get validation warnings

### Logbook
- `POST /api/logbook` - Create logbook entry
- `GET /api/logbook` - List logbook entries

## Makefile Commands

The project includes a comprehensive Makefile for common tasks:

- `make setup` - Setup both backend and frontend
- `make run` - Run both servers
- `make build` - Build frontend for production
- `make test` - Run all tests
- `make lint` - Lint code
- `make format` - Format code
- `make clean` - Clean generated files
- `make help` - Show all available commands

See the Makefile for complete documentation.

## License

MIT

